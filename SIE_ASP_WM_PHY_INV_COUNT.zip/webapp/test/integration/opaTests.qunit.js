/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"phyinvcount/SIE_ASP_WM_PHY_INV_COUNT/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});