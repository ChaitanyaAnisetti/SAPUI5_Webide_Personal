/*global QUnit*/

sap.ui.define([
	"phyinvcount/SIE_ASP_WM_PHY_INV_COUNT/controller/PhyINVCountMain.controller"
], function (Controller) {
	"use strict";

	QUnit.module("PhyINVCountMain Controller");

	QUnit.test("I should test the PhyINVCountMain controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});