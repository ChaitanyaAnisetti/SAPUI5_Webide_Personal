sap.ui.define([
	"phyinvcount/SIE_ASP_WM_PHY_INV_COUNT/test/unit/controller/PhyINVCountMain.controller"
], function () {
	"use strict";
});