sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"phyinvcount/SIE_ASP_WM_PHY_INV_COUNT/model/formatter"
], function (Controller, JSONModel, Filter, FilterOperator, MessageBox, formatter) {
	"use strict";

	return Controller.extend("phyinvcount.SIE_ASP_WM_PHY_INV_COUNT.controller.PhyINVCountItem", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf phyinvcount.SIE_ASP_WM_PHY_INV_COUNT.view.PhyINVCountItem
		 */
		formatter: formatter,
		onInit: function () {
			this._mainService = this.getOwnerComponent().getModel();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("RoutePhyINVCountItem").attachPatternMatched(this._onRouteMatched, this);
		},
		_onRouteMatched: function (oEvent) {
			var sInvCountNo = oEvent.getParameter("arguments").InvCountNo;
			var sWarehouseNo = oEvent.getParameter("arguments").WarehouseNo;
			this._getPhyInvItemSet(sInvCountNo, sWarehouseNo);
		},
		_getPhyInvItemSet: function (sInvCountNo, sWarehouseNo) {

			var that = this;
			var pageId = this.getView().byId("itemPage");
			pageId.setBusy(true);
			var oItemSetModel = new JSONModel();
			var aItemSetModelFilters = [];

			var sInvCountNoFilter = new Filter({
				path: "InvCountNo",
				operator: FilterOperator.EQ,
				value1: sInvCountNo
			});
			aItemSetModelFilters.push(sInvCountNoFilter);

			var sWarehouseFilter = new Filter({
				path: "WarehouseNo",
				operator: FilterOperator.EQ,
				value1: sWarehouseNo
			});
			aItemSetModelFilters.push(sWarehouseFilter);

			this._mainService.read("/PhyInvItemSet", {
				filters: aItemSetModelFilters,
				success: function (data) {
					pageId.setBusy(false);
					oItemSetModel.setData(data);
					that.getView().setModel(oItemSetModel, "oItemSetModel");
				},
				error: function (Error) {
					pageId.setBusy(false);
					sap.m.MessageBox.error(that.getView().getModel("i18n").getResourceBundle().getText("noDataFound"));

				}
			});
		},
		onNavBack: function (oEvent) {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("TargetPhyINVCountMain", true);
			}
		},
		onStartCountItemPress: function (oEvent) {
				var oSelectedItem = oEvent.getSource().getParent();
				var sPath = oSelectedItem.getBindingContextPath().split("/")[2];
				var sInvCountNo = this.getView().getModel("oItemSetModel").getData().results[sPath].InvCountNo;
				var sWarehouseNo = this.getView().getModel("oItemSetModel").getData().results[sPath].WarehouseNo;
				var sStorageBinTyp = this.getView().getModel("oItemSetModel").getData().results[sPath].StorageBinType;
					var sStorageBin = this.getView().getModel("oItemSetModel").getData().results[sPath].StorageBin;
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("RoutePhyINVCountItemDet", {
					InvCountNo: sInvCountNo,
					WarehouseNo: sWarehouseNo,
					StorageBinType: sStorageBinTyp,
					StorageBin : sStorageBin
				});
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf phyinvcount.SIE_ASP_WM_PHY_INV_COUNT.view.PhyINVCountItem
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf phyinvcount.SIE_ASP_WM_PHY_INV_COUNT.view.PhyINVCountItem
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf phyinvcount.SIE_ASP_WM_PHY_INV_COUNT.view.PhyINVCountItem
		 */
		//	onExit: function() {
		//
		//	}

	});

});