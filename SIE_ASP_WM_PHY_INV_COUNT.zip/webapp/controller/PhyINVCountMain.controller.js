sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"phyinvcount/SIE_ASP_WM_PHY_INV_COUNT/model/formatter",
], function (Controller, JSONModel, Filter, FilterOperator, MessageBox, formatter) {
	"use strict";

	return Controller.extend("phyinvcount.SIE_ASP_WM_PHY_INV_COUNT.controller.PhyINVCountMain", {
		formatter: formatter,
		onInit: function () {
			this._mainService = this.getOwnerComponent().getModel();
			this._checkAuthorisation();

		},
		_checkAuthorisation: function () {
			var GID = this.getOwnerComponent().getModel("localModel").getProperty("/Gid");
		//	var GID = "Z003DXZR";
			var that = this;
			var pageId = this.getView().byId("page");
			pageId.setBusy(true);

			this._mainService.read("/UserDefaultSet('" + GID + "')", {
				success: function (data) {
					pageId.setBusy(false);

					if (data.MsgType === "S") {
						that._WarehouseNo = data.WarehouseNo;
						that._getPhyInvHeaderSet();
					} else {
						sap.m.MessageBox.error(data.MsgDesc);

					}
				},
				error: function (Error) {
					pageId.setBusy(false);
					sap.m.MessageBox.error(that.getView().getModel("i18n").getResourceBundle().getText("oDataUserDefaultSetError"));

				}
			});

		},
		_getPhyInvHeaderSet: function () {
			var GID = this.getOwnerComponent().getModel("localModel").getProperty("/Gid");
			//	var GID = "Z003DXZR";

			//	var GID = "Z004CP9N";
			var that = this;
			var pageId = this.getView().byId("page");
			pageId.setBusy(true);
			var oHeaderSetModel = new JSONModel();
			var aHeaderSetModelFilters = [];

			var sGIDFilter = new Filter({
				path: "UserGID",
				operator: FilterOperator.EQ,
				value1: GID
			});
			aHeaderSetModelFilters.push(sGIDFilter);

			var sWarehouseFilter = new Filter({
				path: "WarehouseNo",
				operator: FilterOperator.EQ,
				value1: this._WarehouseNo
			});
			aHeaderSetModelFilters.push(sWarehouseFilter);

			this._mainService.read("/PhyInvHeaderSet", {
				filters: aHeaderSetModelFilters,
				success: function (data) {
					pageId.setBusy(false);
					if (data.results[0].Msgtype === "S") {
						oHeaderSetModel.setData(data);
						that.getView().setModel(oHeaderSetModel, "oHeaderSetModel");

					} else {
						sap.m.MessageBox.error(data.results[0].Msgdesc);
						return false;
					}
				},
				error: function (Error) {
					pageId.setBusy(false);
					sap.m.MessageBox.error(that.getView().getModel("i18n").getResourceBundle().getText("noDataFound"));
					return false;

				}
			});
		},
		onStartCountPress: function (oEvent) {
			var oSelectedItem = oEvent.getSource().getParent();
			var sPath = oSelectedItem.getBindingContextPath().split("/")[2];
			var sInvCountNo = this.getView().getModel("oHeaderSetModel").getData().results[sPath].InvCountNo;
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("RoutePhyINVCountItem", {
				InvCountNo: sInvCountNo,
				WarehouseNo: this._WarehouseNo
			});
		}
	});
});