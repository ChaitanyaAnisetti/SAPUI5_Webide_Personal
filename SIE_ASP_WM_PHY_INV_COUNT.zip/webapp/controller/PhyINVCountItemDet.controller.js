sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"phyinvcount/SIE_ASP_WM_PHY_INV_COUNT/model/formatter"
], function (Controller, JSONModel, Filter, FilterOperator, MessageBox, formatter) {
	"use strict";

	return Controller.extend("phyinvcount.SIE_ASP_WM_PHY_INV_COUNT.controller.PhyINVCountItemDet", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf phyinvcount.SIE_ASP_WM_PHY_INV_COUNT.view.PhyINVCountItemDet
		 */
		formatter: formatter,
		onInit: function () {
			this._mainService = this.getOwnerComponent().getModel();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("RoutePhyINVCountItemDet").attachPatternMatched(this._onRouteMatched, this);
		},
		_onRouteMatched: function (oEvent) {
			var sInvCountNo = oEvent.getParameter("arguments").InvCountNo;
			var sWarehouseNo = oEvent.getParameter("arguments").WarehouseNo;
			var sStorageBinType = oEvent.getParameter("arguments").StorageBinType;
			var sStorageBin = oEvent.getParameter("arguments").StorageBin;
			this._getPhyInvItemDetSet(sInvCountNo, sWarehouseNo, sStorageBinType, sStorageBin);
		},
		_getPhyInvItemDetSet: function (sInvCountNo, sWarehouseNo, sStorageBinType, sStorageBin) {
			var that = this;
			var pageId = this.getView().byId("phyInvItmDetPage");
			pageId.setBusy(true);
			var oItemDetSetModel = new JSONModel();
			var oItemDetSerNoSetModel = new JSONModel();
			var aItemDetSetModelFilters = [];

			var sInvCountNoFilter = new Filter({
				path: "InvCountNo",
				operator: FilterOperator.EQ,
				value1: sInvCountNo
			});
			aItemDetSetModelFilters.push(sInvCountNoFilter);

			var sWarehouseFilter = new Filter({
				path: "WarehouseNo",
				operator: FilterOperator.EQ,
				value1: sWarehouseNo
			});
			aItemDetSetModelFilters.push(sWarehouseFilter);

			var sStorageBinTypFilter = new Filter({
				path: "StorageBinType",
				operator: FilterOperator.EQ,
				value1: sStorageBinType
			});
			aItemDetSetModelFilters.push(sStorageBinTypFilter);

			var sStorageBinFilter = new Filter({
				path: "StorageBin",
				operator: FilterOperator.EQ,
				value1: sStorageBin
			});
			aItemDetSetModelFilters.push(sStorageBinFilter);

			this._mainService.read("/PhyInvItemDetSet", {
				filters: aItemDetSetModelFilters,
				urlParameters: {
					"$expand": "ITEMTOSERIALNO_NAV"
				},
				success: function (data) {
					pageId.setBusy(false);
					oItemDetSetModel.setData(data.results[0]);
					oItemDetSerNoSetModel.setData(data.results[0].ITEMTOSERIALNO_NAV);
					that.getView().setModel(oItemDetSetModel, "oItemDetSetModel");
					that.getView().setModel(oItemDetSerNoSetModel, "oItemDetSerNoSetModel");
				},
				error: function (Error) {
					pageId.setBusy(false);
					sap.m.MessageBox.error(that.getView().getModel("i18n").getResourceBundle().getText("noDataFound"));

				}
			});
		},
		onMaintainSerialNo: function (oEvent) {
			this.count = 0;
			if (!this._serialNo) {
				this._serialNo = sap.ui.xmlfragment("phyinvcount.SIE_ASP_WM_PHY_INV_COUNT.fragment.serialNo", this);
				this.getView().addDependent(this._serialNo);
			}
			this._serialNo.open();
		},
		fnCloseSrNo: function (oEvent) {
			if (this._serialNo) {
				this._serialNo.close();
				this._serialNo.destroy();
				this._serialNo = null;
			}
		},
		fnSaveSerNo: function () {

			if (this._serialNo) {
				this._serialNo.close();
				this._serialNo.destroy();
				this._serialNo = null;
			}
			this._sData = this.getView().getModel("oItemDetSetModel").getData();
			for (var i = 0; i < this._sData.ITEMTOSERIALNO_NAV.results.length; i++) {
				delete this._sData.ITEMTOSERIALNO_NAV.results[i].__metadata;
			}
		},
		onSaveResult: function (oEvent) {
			var that = this;
			var pageId = this.getView().byId("phyInvItmDetPage");
			pageId.setBusy(true);
			if(!(this._sData)){
					this._sData = this.getView().getModel("oItemDetSetModel").getData();
			}
			this._mainService.create("/PhyInvItemDetSet", this._sData, {
				success: function (data) {
					pageId.setBusy(false);
					if (data.MsgType === "S") {
						sap.m.MessageBox.success(data.MsgDesc);
					} else {
						sap.m.MessageBox.error(data.MsgDesc);
					}
				},
				error: function () {
					pageId.setBusy(false);
					sap.m.MessageBox.error(that.getView().getModel("i18n").getResourceBundle().getText("noDataFound"));
				}
			});
		},
		fnClearSrNo: function () {
			var aData = this.getView().getModel("oItemDetSerNoSetModel").getData();
			for (var i = 0; i < aData.results.length; i++) {
				aData.results[i].Serialno = "";
			}
			this.getView().getModel("oItemDetSerNoSetModel").setData(aData);
		},
		onMarkZeroCount: function () {
				this.getView().byId("idCountQTY").setValue("0.000");

			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf phyinvcount.SIE_ASP_WM_PHY_INV_COUNT.view.PhyINVCountItemDet
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf phyinvcount.SIE_ASP_WM_PHY_INV_COUNT.view.PhyINVCountItemDet
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf phyinvcount.SIE_ASP_WM_PHY_INV_COUNT.view.PhyINVCountItemDet
		 */
		//	onExit: function() {
		//
		//	}

	});

});