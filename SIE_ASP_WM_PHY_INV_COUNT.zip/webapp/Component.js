sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"phyinvcount/SIE_ASP_WM_PHY_INV_COUNT/model/models",
	"sap/ui/model/json/JSONModel"
], function (UIComponent, Device, models, JSONModel) {
	"use strict";

	return UIComponent.extend("phyinvcount.SIE_ASP_WM_PHY_INV_COUNT.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();
			var oLocalSet = new JSONModel();
			oLocalSet.setSizeLimit(10000);
			this.setModel(oLocalSet, "localModel");
			var Gid = "";
			if (sap && sap.ushell) {
				Gid = sap.ushell.Container.getService("UserInfo").getId();
			} else {
				Gid = "Z003DXZR";     /* Gid for local testing      Z004C4CT*/
			}
			this.getModel("localModel").setProperty("/Gid", Gid);
			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		}
	});
});