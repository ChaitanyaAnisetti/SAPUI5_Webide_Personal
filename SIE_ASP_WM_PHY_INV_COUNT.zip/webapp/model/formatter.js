sap.ui.define(["sap/ui/core/format/DateFormat"],
	function (DateFormat) {
		return {
			setButtonText: function (sCountType) {
				if (sCountType === "SC") {
					return this.getView().getModel("i18n").getResourceBundle().getText("StartCount");
				} else {
					return this.getView().getModel("i18n").getResourceBundle().getText("ChangeCount");
				}
			},
			setRowNo: function (oModel) {
				this.count = this.count + 1;
				return this.count;
			},
				controlSerNoButtonVisibility:function(sInd){
				var bVisible = false;
				if (sInd === "X") {
					bVisible = true;
				} 
				else 
				{
					bVisible = false;
				}
				return bVisible;	
			}
		};
	}
);