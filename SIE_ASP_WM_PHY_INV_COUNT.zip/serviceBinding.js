function initModel() {
	var sUrl = "/sap/opu/odata/sie/ASP_WM_PHY_INV_COUNT_SRV/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}