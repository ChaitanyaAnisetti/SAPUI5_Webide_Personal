sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function (Controller, MessageBox, MessageToast) {
	"use strict";

	return Controller.extend("com.crescent.zehs_approver.controller.View1", {
		onInit: function () {
			this.getMasterdData();
			this.Tabledata();
			this.bDescending = true;

			this.getView().byId("oRevbtnid").setVisible(false);

		},
		handleRefresh: function () {

			setTimeout(function () {

				this.getView().byId("pullToRefresh").hide();
				this.getMasterdData();

			}.bind(this), 2500);

		},
		getMasterdData: function () {
			var Url = '/sap/opu/odata/sap/ZEHS_WF_APPROVAL_SRV/ZWFHEADERSet';

			$.ajax({
				url: Url,
				type: "GET",
				dataType: "json",
				success: function (data) {
					var model = new sap.ui.model.json.JSONModel();

					this.getView().setModel(model, 'Master');

					model.setData(data.d);

					var total = data.d.results.length;
					var text = "Incident Management (" + total + ")";
					this.getView().byId("Master").setTitle(text);

				}.bind(this),
				error: function (request, error) {

				}
			});
		},
		onListItemPress: function (evt) {
			var rootKey = evt.getSource().getBindingContext('Master').getObject().RootKey;
			this.oTaskNo = evt.getSource().getBindingContext('Master').getObject().TaskNo;
			this.Wiid = evt.getSource().getBindingContext('Master').getObject().Wiid;

			// var x =	this.getView().byId("ocombid");

			if (this.oTaskNo === "35") {
				this.getView().byId("oRevbtnid").setVisible(true);
				this.getView().byId("Approve").setVisible(false);

			} else if (this.oTaskNo === "36") {
				this.getView().byId("oRevbtnid").setVisible(false);
				this.getView().byId("Approve").setVisible(true);

			}

			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZEHS_WF_APPROVAL_SRV");
			var that = this;
			var sTab = "ZWFITEMSet?$filter=IncRootKey eq '" + rootKey + "'";
			oModel.read(sTab, {
				success: function (odata, response) {
					var header = odata;
					var Calendar = new sap.ui.model.json.JSONModel(header);

					that.getView().byId("SimpleFormDisplay354").setModel(Calendar, 'Detail');
					//	that.Tabledata();

				},
				error: function (response) {

					var Message = $(response.response.body).find('message').first().text();

				}
			});

		},

		Tabledata: function () {

			var Url = '/sap/opu/odata/sap/ZEHS_WF_APPROVAL_SRV/ZSEVRITYSet';

			$.ajax({
				url: Url,
				type: "GET",
				dataType: "json",
				success: function (data) {
					var model = new sap.ui.model.json.JSONModel();
					model.setData(data.d.results);
					this.getView().setModel(model, 'Final');

				}.bind(this),
				error: function (request, error) {}
			});

		},

		handleViewSettingsDialogButtonPressed: function () {
			var oList = this.byId("idList"),
				oBinding = oList.getBinding("items");

			//	var sSortKey = "WfSubject";
			var sSortKey = "Wiid";
			this.bDescending = !this.bDescending; //switches the boolean back and forth from ascending to descending
			var bGroup = false;
			var aSorter = [];

			aSorter.push(new sap.ui.model.Sorter(sSortKey, this.bDescending, bGroup));
			oBinding.sort(aSorter);
			if (this.bDescending == true) {
				var msg = "WI_ID items sorted in descending order";
				return MessageToast.show(msg);
			} else if (this.bDescending == false) {
				var msg = "WI_ID items sorted in  ascending order";
				return MessageToast.show(msg);
			}

		},
		handleFilter: function (oEvent) {

			var aFilters = [];
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {

				var filter = ([new sap.ui.model.Filter([
					new sap.ui.model.Filter("WfSubject", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("Wiid", sap.ui.model.FilterOperator.Contains, sQuery)

				], false)]);
				aFilters.push(filter);

			}
			var oList = this.getView().byId("idList");
			var binding = oList.getBinding("items");
			binding.filter(aFilters, "Application");

		},

		onApprove: function () {
			this.getView().byId("SimpleFormDisplay354").getModel("Detail");

			var oIncrootkey = this.getView().byId("SimpleFormDisplay354").getModel("Detail").getData().results[0].IncRootKey;

			if (oIncrootkey === "" || oIncrootkey === "0" || oIncrootkey === undefined) {
				return MessageBox.information("Please select Incident Management Item from the list");

			}

			var oCategory = this.getView().byId("SimpleFormDisplay354").getModel("Detail").getData().results[0].Category;
			if (oCategory === "" || oCategory === "0" || oCategory === undefined) {
				return MessageBox.information("Please select Incident Management Item from the list");

			}

			var oSelectedItem = this.getView().byId("idProductsTable").getSelectedItem();

			if (oSelectedItem === null || oSelectedItem === "0" || oSelectedItem === undefined) {

				return MessageBox.information("Please select Incident Classification Item from the table");
			} else if (this.getView().byId("idProductsTable").getSelectedItems().length > 1) {
				return sap.m.MessageBox.warning("You are allowed to select only one item from Incident Classification table");
			} else {
				var oGroupObj = oSelectedItem.getBindingContext("Final").getObject("Code");
				if (oGroupObj === "" || oGroupObj === "0" || oGroupObj === undefined) {
					return MessageBox.information("Please select Incident Classification Item from the table");

				}
				var SevrObj = oSelectedItem.getCells()[1].getSelectedKey();
				if (SevrObj === "" || SevrObj === "0" || SevrObj === undefined) {
					return MessageBox.information("Please select Incident Classification Item from the table dropdown");

				}
			}

			//	var oApproveKey = this.Wiid;
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZEHS_WF_APPROVAL_SRV");
			var oApprove = {};
			oApprove.WiId = this.Wiid;

			oModel.create("/approveSet", oApprove, {
				method: "POST",
				success: function (data, oResponse) {

					MessageBox.success(data.message);
					var oJsdumModel1 = new sap.ui.model.json.JSONModel([]);
					this.getView().byId("SimpleFormDisplay354").setModel(oJsdumModel1, "Detail");

					this.getMasterdData();
					var oModelrf = this.getView().byId("idList").getModel("Master");

					oModelrf.refresh(true);

					//	alert(JSON.stringify(data));
				}.bind(this),
				error: function (data) {
					MessageBox.error(data.message);

				}.bind(this)

			});

		},

		onReview: function (oEvt) {

			this.getView().byId("SimpleFormDisplay354").getModel("Detail");

			var oIncrootkey = this.getView().byId("SimpleFormDisplay354").getModel("Detail").getData().results[0].IncRootKey;

			if (oIncrootkey === "" || oIncrootkey === "0" || oIncrootkey === undefined) {
				return MessageBox.information("Please select Incident Management Item from the list");

			}

			var oCategory = this.getView().byId("SimpleFormDisplay354").getModel("Detail").getData().results[0].Category;
			if (oCategory === "" || oCategory === "0" || oCategory === undefined) {
				return MessageBox.information("Please select Incident Management Item from the list");

			}

			var oSelectedItem = this.getView().byId("idProductsTable").getSelectedItem();

			if (oSelectedItem === null || oSelectedItem === "0" || oSelectedItem === undefined) {

				return MessageBox.information("Please select Incident Classification Item from the table");
			} else if (this.getView().byId("idProductsTable").getSelectedItems().length > 1) {
				return sap.m.MessageBox.warning("You are allowed to select only one item from Incident Classification table");
			} else {
				var oGroupObj = oSelectedItem.getBindingContext("Final").getObject("Code");
				if (oGroupObj === "" || oGroupObj === "0" || oGroupObj === undefined) {
					return MessageBox.information("Please select Incident Classification Item from the table");

				}
				var SevrObj = oSelectedItem.getCells()[1].getSelectedKey();
				if (SevrObj === "" || SevrObj === "0" || SevrObj === undefined) {
					return MessageBox.information("Please select Incident Classification Item from the table dropdown");

				}
			}

			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZEHS_WF_APPROVAL_SRV");
			var oEntry = {};
			oEntry.IncCategory = oCategory;
			oEntry.IncRootKey = oIncrootkey;

			oEntry.IncGroup = oGroupObj;
			oEntry.NmGroup = "";
			oEntry.Sevrity = "0";
			oEntry.WiId = this.Wiid;

			this.getView().byId("Approve").setVisible(true);

			oModel.create("/reviewSet", oEntry, {
				method: "POST",
				success: function (data, oResponse) {

					//	this.button();
					this.getView().byId("Approve").setEnabled(true);
					this.getView().byId("oRevbtnid").setVisible(false);
					MessageBox.success(data.Zmessage);
					this.getMasterdData();
					//	var oJsdumModel1 = new sap.ui.model.json.JSONModel([]);
					//	this.getView().byId("SimpleFormDisplay354").setModel(oJsdumModel1, "Detail");

					/*this.oTemplate = new sap.m.ColumnListItem({
						cells: [new sap.m.Text({
							text: ""
						}), new sap.m.Text({
							text: "{Code}"
						})]
					});

					this._oTable.bindItems({
						path: "/ZSGROUPSet",
						template: this.oTemplate
					});*/

					//alert(JSON.stringify(data));
				}.bind(this),
				error: function (data) {

					MessageBox.error(data.Zmessage);

				}

			});

		},

		handleConfirm: function (oEvent) {

			var mParams = oEvent.getParameters();
			var sPath = mParams.sortItem.getKey();
			var bDescending = mParams.sortDescending;

			this.aSorter = [];
			var oTable = this.getView().byId("idList");
			var oBinding = oTable.getBinding('items');
			this.aSorter.push(new sap.ui.model.Sorter(sPath, bDescending));
			oBinding.sort(this.aSorter);
			for (var i in this.aSorter) {
				var oId = 'id' + this.aSorter[i]['sPath'];
				if (bDescending == false) {
					this.getView().byId(oId).setIcon('sap-icon://sort-ascending');
				} else {
					this.getView().byId(oId).setIcon('sap-icon://sort-descending');
				}

			}

		},

	});
});