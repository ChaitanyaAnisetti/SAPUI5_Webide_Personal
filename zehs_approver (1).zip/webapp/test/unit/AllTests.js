sap.ui.define([
	"com/crescent/zehs_approver/test/unit/controller/View1.controller"
], function () {
	"use strict";
});