jQuery.sap.declare("cus.o2c.invdoc.display.s1.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("cus.o2c.invdoc.display.s1.Component", {
	metadata: {
		"manifest": "json"
	}
});