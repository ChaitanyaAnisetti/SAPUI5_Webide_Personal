/*eslint-disable sap-no-global-define*/
window["sap-ushell-config"] = {
	/*eslint-enable sap-no-global-define*/
	applications: {
		"C_CAInvcgDocDisp-display": {
			"additionalInformation": "SAPUI5.Component=cus.o2c.invdoc.display.s1",
			"applicationType": "URL",
			"url": "../",
			"description": "Display Invoicing Documents"
		},
		"masterDetail-display": {
			"additionalInformation": "SAPUI5.Component=cus.o2c.invdoc.display.s1",
			"applicationType": "URL",
			"url": "../"
		}
	}
};