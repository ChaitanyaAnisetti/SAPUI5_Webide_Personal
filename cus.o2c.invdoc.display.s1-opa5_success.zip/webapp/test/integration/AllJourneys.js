jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");

QUnit.config.autostart = false;
QUnit.config.testTimeout = 1000000;

sap.ui.require([
	"sap/ui/test/Opa5",
	"cus/o2c/invdoc/display/s1/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"cus/o2c/invdoc/display/s1/test/integration/pages/ListReport",
	"sap/suite/ui/generic/template/integration/testLibrary/ListReport/pages/ListReport",
	"sap/suite/ui/generic/template/integration/testLibrary/ObjectPage/pages/ObjectPage"
], function (Opa5, Common, ListReport) {
	"use strict";

	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "cus.o2c.invdoc.display.s1.view.",
		autoWait: true,
		appParams: {
			"sap-ui-animation": false
		},
		timeout: 90,
		testLibs: {
			fioriElementsTestLibrary: {
				Common: {
					appId: 'cus.o2c.invdoc.display.s1',
					entitySet: 'C_CAInvcgDocDisp'
				}
			}
		}
	});

	sap.ui.require([
		"cus/o2c/invdoc/display/s1/test/integration/testLibraryJourney",
		"cus/o2c/invdoc/display/s1/test/integration/NavigationFlow",
		"cus/o2c/invdoc/display/s1/test/integration/ListReportJourney"
	], function () {
		QUnit.start();
	});
});