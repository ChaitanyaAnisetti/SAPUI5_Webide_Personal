sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"cus/o2c/invdoc/display/s1/test/integration/pages/Common",
	"sap/ui/test/actions/Press",
	"sap/ui/model/resource/ResourceModel"
], function (Opa5, PropertyStrictEquals, AggregationFilled, Common, Press, ResourceModel) {
	"use strict";

	var sViewName = "ListReport";
	var sViewNamespace = "sap.suite.ui.generic.template.ListReport.view.";

	Opa5.createPageObjects({
		onTheListReportPage: {
			baseClass: Common,

			actions: {

				iClickTheButton: function (buttonText) {
					return this.waitFor({
						controlType: "sap.m.Button",
						viewName: sViewName,
						viewNamespace: sViewNamespace,
						matchers: [
							new PropertyStrictEquals({
								name: "text",
								value: buttonText
							})
						],
						actions: new Press(),
						errorMessage: "The button cannot be clicked"
					});
				},

				iClickTheButtonWithAnIcon: function (sIconUrl) {
					return this.waitFor({
						controlType: "sap.m.Button",
						viewName: sViewName,
						viewNamespace: sViewNamespace,
						matchers: [
							new PropertyStrictEquals({
								name: "icon",
								value: sIconUrl
							})
						],
						actions: new Press(),
						errorMessage: "The button cannot be clicked"
					});
				},

				iSelectFirstRowOfTable: function () {
					return this.waitFor({
						controlType: "sap.m.Table",
						viewName: sViewName,
						viewNamespace: sViewNamespace,
						matchers: [
							new AggregationFilled({
								name: "items"
							}),
							function (oTable) {
								var oContext;
								if (oTable.getItems()[0]) {
									oContext = oTable.getItems()[0].getBindingContext();
								}
								return !!oContext;
							}
						],
						success: function (aTables) {
							var oTable = aTables[0];
							var oFirstItem = oTable.getItems()[0];
							oTable.setSelectedItem(oFirstItem);
							QUnit.assert.ok("First row of table is selected");
						},
						errorMessage: "The first row cannot be selected"
					});
				},

				iSelectRowOfTable: function (iRowNumber) {
					return this.waitFor({
						controlType: "sap.m.Table",
						viewName: sViewName,
						viewNamespace: sViewNamespace,
						matchers: [
							new AggregationFilled({
								name: "items"
							}),
							function (oTable) {
								var oContext;
								if (oTable.getItems()[iRowNumber]) {
									oContext = oTable.getItems()[iRowNumber].getBindingContext();
								}
								return !!oContext;
							}
						],
						success: function (aTables) {
							var oTable = aTables[0];
							var oItem = oTable.getItems()[iRowNumber];
							oTable.setSelectedItem(oItem);
							oTable.fireSelectionChange({
								listItems: [oItem],
								selected: true
							});
							QUnit.assert.ok(iRowNumber + " row of table is selected");
						},
						errorMessage: "The first row cannot be selected"
					});
				},

				iDeselectRowOfTable: function (iRowNumber) {
					return this.waitFor({
						controlType: "sap.m.Table",
						viewName: sViewName,
						viewNamespace: sViewNamespace,
						matchers: [
							new AggregationFilled({
								name: "items"
							}),
							function (oTable) {
								var oContext;
								if (oTable.getItems()[iRowNumber]) {
									oContext = oTable.getItems()[iRowNumber].getBindingContext();
								}
								return !!oContext;
							}
						],
						success: function (aTables) {
							var oTable = aTables[0];
							var oItem = oTable.getItems()[iRowNumber];
							oTable.setSelectedItem(oItem, false);
							oTable.fireSelectionChange({
								listItems: [oItem],
								selected: true
							});
							QUnit.assert.ok(iRowNumber + " row of table is deselected");
						},
						errorMessage: "The desired row cannot be deselected"
					});
				},

				iSelectRowForAction: function () {
					return this.waitFor({
						controlType: "sap.m.Table",
						viewName: sViewName,
						viewNamespace: sViewNamespace,
						matchers: [
							new AggregationFilled({
								name: "items"
							}),
							function (oTable) {
								var oContext;
								if (oTable.getItems()[0]) {
									oContext = oTable.getItems()[0].getBindingContext();
								}
								return !!oContext;
							}
						],
						success: function (aTables) {
							var oTable = aTables[0];
							var aItems = oTable.getItems();
							var oSelectedItem;
							aItems.forEach(function (oItem) {
								var oObject = oItem.getBindingContext().getObject(oItem.getBindingContextPath());
								if (oObject.NumberOfPayments !== 0 && !oSelectedItem) {
									oSelectedItem = oItem;
								}
							});
							oTable.setSelectedItem(oSelectedItem);
							oTable.fireEvent("selectionChange");
							QUnit.assert.ok("a row of table is selected");
						},
						errorMessage: "no valid row found"
					});
				}

			},

			assertions: {
				theSalesOrdersAreLoadedInTheSmartTable: function () {
					return this.waitFor({
						controlType: "sap.m.Table",
						matchers: [
							new AggregationFilled({
								name: "items"
							}),
							function (oTable) {
								var oContext;
								if (oTable.getItems()[0]) {
									oContext = oTable.getItems()[0].getBindingContext();
								}
								return !!oContext;
							}
						],
						success: function (oTable) {
							var oFirstItem = oTable[0].getItems()[0].getBindingContext().getPath();
							var firstProduct = oTable[0].getItems()[0].getBindingContext().getObject(oFirstItem);
							QUnit.notEqual(oTable[0].getItems().length, 0, "Sales Orders are loaded in the Smart Table");
						},
						errorMessage: "Sales Orders were not loaded into the Smart Table"
					});
				},

				firstRowIsSelected: function () {
					return this.waitFor({
						controlType: "sap.m.Table",
						matchers: [
							new AggregationFilled({
								name: "items"
							}),
							function (oTable) {
								var oContext;
								if (oTable.getItems()[0]) {
									oContext = oTable.getItems()[0].getBindingContext();
								}
								return !!oContext;
							}
						],
						success: function (aTables) {
							var oTable = aTables[0];
							var oFirstItem = oTable.getItems()[0];
							var oSelectedItem = oTable.getSelectedItem();

							QUnit.equal(oFirstItem.getBindingContextPath(), oSelectedItem.getBindingContextPath(), "first Row of table is selected");
						},
						errorMessage: "First row of table is not selected"
					});
				},

				iShouldSeeAButtonWithAnIcon: function (sIconUrl) {
					this.waitFor({
						controlType: "sap.m.Button",
						viewName: sViewName,
						viewNamespace: sViewNamespace,
						matchers: new sap.ui.test.matchers.PropertyStrictEquals({
							name: "icon",
							value: sIconUrl
						}),
						success: function (aButtons) {
							ok(aButtons.length, "found button with the icon " + sIconUrl);
						},
						errorMessage: "could not find the button with the icon " + sIconUrl
					});
				},

				iShouldSeeAPopover: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Popover",
						success: function (aPopover) {
							ok(aPopover[0].getVisible(), "Found the Popover");
						},
						errorMessage: "The popover was not there"
					});
				},

				iSeeTheButtonWithAnIcon: function (sIconUrl) {
					return this.waitFor({
						controlType: "sap.m.Button",
						viewName: sViewName,
						viewNamespace: sViewNamespace,
						matchers: [
							new PropertyStrictEquals({
								name: "icon",
								value: sIconUrl
							})
						],
						success: function (aButtons) {
							QUnit.notEqual(aButtons.length, 0, "Found the button with the icon: " + sIconUrl);
						},
						errorMessage: "The button with icon " + sIconUrl + " cannot be clicked"
					});
				},

				iSeeTheActiveButtonWithID: function (sID) {
					return this.waitFor({
						controlType: "sap.m.Button",
						viewName: sViewName,
						viewNamespace: sViewNamespace,
						success: function (aButtons) {
							var oClearingButton;
							var sCompareID =
								"cus.o2c.invdoc.display.s1::sap.suite.ui.generic.template.ListReport.view.ListReport::C_CAInvcgDocDisp--" +
								sID;
							aButtons.forEach(function (oButton) {
								var sSelectedID = oButton.getId();
								if (sCompareID === sSelectedID) {
									oClearingButton = oButton;
								}
							});
							if (oClearingButton) {
								var bEnabled = oClearingButton.getEnabled();
								QUnit.notEqual(bEnabled, false, "Found the active button with the ID: " + sID);
							}

						},
						errorMessage: "The button with icon " + sID + " cannot be clicked"
					});
				}
			}
		}
	});
});