sap.ui.define([
	"sap/ui/test/opaQunit"
], function (opaTest) {
	"use strict";
	QUnit.module("ListReport Journey Second");

	opaTest("Load Content", function (Given, When, Then) {
		Given.iStartTheApp();

		When.onTheGenericListReport
			.iExecuteTheSearch();

		Then.onTheListReportPage
			.theSalesOrdersAreLoadedInTheSmartTable();
	});

	opaTest("Select first row of table", function (Given, When, Then) {
		When.onTheGenericListReport
			.iLookAtTheScreen();

		When.onTheListReportPage
			.iSelectFirstRowOfTable();

		Then.onTheListReportPage
			.firstRowIsSelected();
	});

	opaTest("Navigate to object page and press buttons", function (Given, When, Then) {
		When.onTheGenericListReport.iNavigateFromListItemByLineNo(0);

		// When.onTheGenericObjectPage
		// 	.iClickTheButtonWithId('action::ActionOnClickBillPrev');

		// When.onTheGenericObjectPage
		// 	.iClickTheButtonHavingLabel("Close");

		When.onTheGenericObjectPage
			.iClickTheButtonWithId('action::ActionOnClickBillReq');

		When.onTheGenericObjectPage
			.iChoosetheItemInComboBox("CABillgReqReasonText 1");

		// When.onTheGenericObjectPage
		// 	.iClickTheButtonHavingLabel("OK");

		// When.onTheGenericObjectPage
		// 	.iClickTheButtonHavingLabel("OK");

		When.onTheGenericObjectPage
			.iClickTheButtonHavingLabel("Cancel");

		// When.onTheGenericObjectPage
		// 	.iClickTheButtonWithId('action::ActionOnClickPrintLock');
	});

	opaTest("Navigate to object page and switch tabs and press functions", function (Given, When, Then) {
		When.onTheGenericObjectPage
			.iClickTheButtonHavingLabel("Items");

		When.onTheGenericObjectPage
			.iClickTheButtonHavingLabel("Posting Documents");

		When.onTheGenericObjectPage
			.iClickTheButtonHavingLabel("Source Documents");

		When.onTheGenericObjectPage
			.iClickTheButtonHavingLabel("References");

		When.onTheGenericObjectPage
			.iClickTheButtonHavingLabel("Invoicing History");

		When.onTheGenericObjectPage
			.iClickTheButtonHavingLabel("Consumption Items");

		When.onTheGenericObjectPage
			.iSelectListItemsByLineNo([1], true, "LI_CIT::responsiveTable");

		When.onTheGenericObjectPage
			.iClickTheButtonWithId("ActionGotoCITButton");

		Then.onTheGenericObjectPage
			.iShouldSeeTheDialogWithTitle("Error");

		When.onTheGenericObjectPage
			.iClickTheButtonHavingLabel("OK");

		When.onTheGenericObjectPage
			.iClickTheButtonHavingLabel("Billable Items");

		When.onTheGenericObjectPage
			.iSelectListItemsByLineNo([1], true, "LI_BIT::responsiveTable");

		When.onTheGenericObjectPage
			.iClickTheButtonWithId("ActionOnClickBIT");

		Then.onTheGenericObjectPage
			.iShouldSeeTheDialogWithTitle("Error");

		When.onTheGenericObjectPage
			.iClickTheButtonHavingLabel("OK");

		Then.onTheGenericListReport
			.iTeardownMyAppFrame();
	});
});