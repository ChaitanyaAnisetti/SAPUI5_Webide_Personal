sap.ui.define([
	"cus/o2c/invdoc/display/s1/ext/controller/Common",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function (
	Common,
	MessageBox,
	MessageToast
) {
	"use strict";

	return sap.ui.controller("cus.o2c.invdoc.display.s1.ext.controller.ObjectPageExt", {

		onAfterRendering: function () {
			var oModelCredDeb = this.getView().getModel("CredDebMemo");
			sap.ui.getCore().getMessageManager().registerMessageProcessor(oModelCredDeb);

			this.extensionAPI.attachPageDataLoaded(function (oEvent) {
				var printLockBtn = this.getView().byId("action::ActionOnClickPrintLock");
				if (printLockBtn) {
					printLockBtn.bindProperty("text", {
						path: "CAInvcgDocIsLockedForPrinting",
						formatter: this.formatPrintLockButtonText
					});
				}
			}.bind(this));
		},

		adaptNavigationParameterExtension: function (oSelectionVariant, oObjectInfo) {
			oSelectionVariant.removeSelectOption("CAInvcgBaseDate");
		},

		formatPrintLockButtonText: function (sLockStatus) {
			var resourceBundle = this.getModel("i18n").getResourceBundle();
			if (sLockStatus) {
				return resourceBundle.getText("removePrintLock");
			} else {
				return resourceBundle.getText("setPrintLock");
			}
		},

		onClickPrintLock: function (oEvent) {
			var that = this;
			var oModel = this.getView().getModel();
			var oContext = this.getView().getBindingContext();
			var sCAInvoicingDocument = oContext.getProperty("CAInvoicingDocument");
			// legacy call, should be changed to STANDARD together with OData impl
			oModel.callFunction("/PrintLock", {
				method: "POST",
				urlParameters: {
					CAInvoicingDocument: sCAInvoicingDocument
				},
				success: function (d, m) {
					oModel.refresh(true);

					if (m.headers["sap-message"]) {
						MessageToast.show(JSON.parse(m.headers["sap-message"]).message, {
							duration: 5000
						});
					}
				},
				error: function (e) {
					that.showError(e);
				}
			});

		},

		showError: function (e) {
			var sText = JSON.parse(e.response.responseText).error.message.value;
			MessageBox.show(sText, {
				icon: MessageBox.Icon.ERROR,
				title: "{i18n|sap.suite.ui.generic.template.ObjectPage|C_CAInvcgDocDisp>error}",
				actions: [MessageBox.Action.OK]
			});
		},

		onClickBIT: function (oEvent) {
			var aParameter = [];
			oEvent.getSource().getParent().getParent().getSelectedContexts().map(function (oBindingContext) {
				var oBindingObject = oBindingContext.getObject();
				aParameter.push({
					CABllbleItmSourceTransId: oBindingObject.CABllbleItmSourceTransId,
					CABllbleItmPackageUUID: oBindingObject.CABllbleItmPackageUUID,
					CABllbleItmPackNo: oBindingObject.CABllbleItmPackNo,
					CABllbleItmSourceTransType: oBindingObject.CABllbleItmSourceTransType
				});
			});
			this.extensionAPI.getNavigationController().navigateExternal("ConsumptionItemDisplay", aParameter);
		},

		onClickCIT: function (oEvent) {
			var aParameter = [];
			oEvent.getSource().getParent().getParent().getSelectedContexts().map(function (oBindingContext) {
				var oBindingObject = oBindingContext.getObject();
				aParameter.push({
					CACnsmpnItmID: oBindingObject.CACnsmpnItmID,
					CACnsmpnItmIDType: oBindingObject.CACnsmpnItmIDType,
					CACnsmpnItmPackageUUID: oBindingObject.CACnsmpnItmPackageUUID,
					CACnsmpnItmPackNo: oBindingObject.CACnsmpnItmPackNo
				});
			});
			this.extensionAPI.getNavigationController().navigateExternal("ConsumptionItemDisplay", aParameter);
		},

		_getCrossAppNavigator: function () {
			var fgetService = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
			return fgetService && fgetService("CrossApplicationNavigation");
		},

		onClickBillReq: function (oEvent) {
			var that = this;
			var oContext = oEvent.getSource().getBindingContext();
			var sInvoicingDocument = oContext.getObject().CAInvoicingDocument;

			var fragPath = "cus.o2c.invdoc.display.s1.ext.fragments.NavToCreateDebitCredit";
			var _oDialog = sap.ui.xmlfragment(that.createId("addCreditMemoFragment"),
				fragPath, {
					onOKPressed: function () {
						var oComboBox = that.getView().byId("addCreditMemoFragment--requestReasons");
						var oBundle = that.getView().getModel("i18n").getResourceBundle();
						var sCABillgReqReason = oComboBox.getSelectedKey();

						if (!sCABillgReqReason) {
							oComboBox.setValueState("Error");
							oComboBox.setValueStateText(oBundle.getText("selectReason"));
							return;
						}
						var aFilters = [];
						aFilters.push(
							new sap.ui.model.Filter({
								path: "CAInvoicingDocument",
								operator: sap.ui.model.FilterOperator.EQ,
								value1: sInvoicingDocument
							})
						);
						aFilters.push(
							new sap.ui.model.Filter({
								path: "IsActiveEntity",
								operator: sap.ui.model.FilterOperator.EQ,
								value1: false
							})
						);
						aFilters.push(
							new sap.ui.model.Filter({
								path: "CABillgReqReason",
								operator: sap.ui.model.FilterOperator.EQ,
								value1: sCABillgReqReason
							})
						);
						var oModelCredDeb = that.getView().getModel("CredDebMemo");
						//sap.ui.getCore().getMessageManager().registerMessageProcessor(oModelCredDeb);
						oModelCredDeb.read("/C_CABillgReqDocHeader", {
							filters: aFilters,
							success: function (oData) {
								var oCrossAppNavigator = that._getCrossAppNavigator();
								if (oData.results.length === 0) {
									// no credit/debit draft exists for given invoicing document -> create & navigate
									oModelCredDeb.getMetaModel().loaded().then(function () {
										// DraftController relies on loaded MetaModel of ODataModel
										var oDraftController = new sap.ui.generic.app.transaction.DraftController(oModelCredDeb);
										that.extensionAPI.securedExecution(function () {
											return new Promise(function (fnResolve, fnReject) {
												oDraftController.createNewDraftEntity("C_CABillgReqDocHeader", "/C_CABillgReqDocHeader", {
													CAInvoicingDocument: sInvoicingDocument,
													CABillgReqReason: sCABillgReqReason
												}).then(function (aResponse) {
													var path = aResponse && aResponse.context.sPath;
													// Calling the Semantic Object with the corresponding Service and the Variable for the Parameters
													oCrossAppNavigator.toExternal({
														target: {
															shellHash: "CABillgReqDocument-manage&" + path
														}
													});
													fnResolve();
												}).catch(function (oResponse) {
													that.showError(oResponse);
													fnReject();
												});
											});
										});
									});

								} else {
									// there's already a credit/debit draft for given invoicing document -> navigate
									var oNavParams = {};
									oNavParams.CAInvoicingDocument = sInvoicingDocument;
									oNavParams.CABillgReqReason = sCABillgReqReason;
									oNavParams.CABillgReqDocument = "000000000000";
									oNavParams.IsActiveEntity = false;
									if (oData.results.length === 1) {
										oNavParams.DraftUUID = oData.results[0].DraftUUID;
									}
									// Calling the Semantic Object with the corresponding Service and the Variable for the Parameters
									oCrossAppNavigator.toExternal({
										target: {
											semanticObject: "CABillgReqDocument",
											action: "manage"
										},
										params: oNavParams
									});
								}
							},
							error: that.showError
						});
					},
					onCancelPressed: function () {
						_oDialog.close();
						_oDialog.destroy();
					},
					afterClose: function () {
						_oDialog.destroy();
					}

				});

			that.extensionAPI.attachToView(_oDialog);
			_oDialog.open();
		},

		onClickBillPrev: function (oEvent) {
			Common.handleBillPreview([oEvent.getSource().getBindingContext()], this.getView());
		}

	});
});