sap.ui.define([
	"sap/m/MessageBox",
	"sap/m/PDFViewer"
], function (
	MessageBox,
	PDFViewer
) {
	"use strict";

	return {

		handleBillPreview: function (aBindingContext, oView) {
			var resourceBundle = oView.getModel("i18n").getResourceBundle();
			if (aBindingContext.length === 1) {
				this._pdfViewer = new PDFViewer();
				this._pdfViewer.setErrorPlaceholderMessage(resourceBundle.getText("message.Error.BillPreviewFailed"));
				oView.addDependent(this._pdfViewer);
				var sServiceUrl = aBindingContext[0].getModel().sServiceUrl;
				var sInvDocNumber = aBindingContext[0].getProperty("CAInvoicingDocument");
				var sURI = sServiceUrl + "/CAInvcgDocPdfSet" + "(Invdocno='" + sInvDocNumber + "')/$value";
				this._pdfViewer.setSource(sURI);
				this._pdfViewer.open();
			} else if (aBindingContext.length === 0) {
				MessageBox.error(resourceBundle.getText("message.Error.SelectionMissing"));
			} else {
				MessageBox.error(resourceBundle.getText("message.Error.NoSingleSelection"));
			}
		}

	};
});