sap.ui.define([
	"cus/o2c/invdoc/display/s1/ext/controller/Common"
], function (
	Common
) {
	"use strict";

	return sap.ui.controller("cus.o2c.invdoc.display.s1.ext.controller.ListReportExt", {

		onClickBillPrev: function (oEvent) {
			Common.handleBillPreview(this.extensionAPI.getSelectedContexts(), this.getView());
		}

	});
});