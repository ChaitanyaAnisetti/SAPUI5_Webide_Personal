/*&------------------------------------------------------------------------* 
* Author/Changed By   : ANI0006				        		       		   *
* Date                : 11-Nov-2021                                        *
* Project             : EAM Railinc EPA    					               *
* Description         : EPA Information - Fields Masking		           *
* Search Term         : ANI0006 2000014601                                 *
/*&------------------------------------------------------------------------*/
jQuery.sap.declare("com.sap.cp.lm.Component");
sap.ui.define(
	["sap/ui/core/UIComponent",
		"sap/ui/Device",
		"sap/ui/thirdparty/d3",
		"com/sap/cp/lm/model/models",
		"sap/ui/model/odata/v2/ODataModel",
		"com/sap/cp/lm/util/Constants",
		"com/sap/cp/lm/util/ErrorManager",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/controller/map/MapManager",
		"com/sap/cp/lm/controller/locomotives/LocomotiveManager",
		"com/sap/cp/lm/controller/craft/CraftManager",
		"com/sap/cp/lm/model/LocomotiveMaintenanceModel",
		"com/sap/cp/lm/model/work/WorkDataModel",
		"com/sap/cp/lm/model/alert/AlertDataModel",
		"com/sap/cp/lm/model/main/PersonalLinkModel",
		"com/sap/cp/lm/model/main/DefaultSettingModel",
		"com/sap/cp/lm/model/main/TrackSpotModel",
		"com/sap/cp/lm/model/material/MaterialModel"
		// "com/sap/cp/lm/model/map/MapDataModel"
	],
	function (UIComponent, Device, d3, models, ODataModel, Constants, ErrorManager, BusyIndicator, MapManager,
		LocomotiveManager, CraftManager, LocomotiveMaintenanceModel, WorkDataModel, AlertDataModel,
		PersonalLinkModel, DefaultSettingModel, TrackSpotModel, MaterialModel) {
		"use strict";

		return UIComponent.extend(
			"com.sap.cp.lm.Component", {

				metadata: {
					manifest: "json"
				},

				/**
				 * The component is initialized by UI5 automatically during the startup of
				 * the app and calls the init method once.
				 * @public
				 * @override
				 */
				init: function () {
					// call the base component's init function
					sap.ui.core.UIComponent.prototype.init.apply(this, arguments);

					//var mConfig = this.getMetadata().getConfig();
					// THis is temporary fix for FUllscreen app   
					//this._oManifest._oManifest["sap.ui"].fullWidth = true;

					var sServiceUrl = "/sap/opu/odata/sap/ZPM_LM_SRV/";
					var sPmFracardURl = "/sap/opu/odata/sap/ZPM_FRACARD_SRV";
					//Start: ANI0006 2000014601 - Create Engine Manufacturer OData model - oEngManf
					var sEngmanfServiceUrl = "/sap/opu/odata/sap/ZEAM_MANF_SEARCH_HELP_SRV";
					var oEngManf = new LocomotiveMaintenanceModel(sEngmanfServiceUrl, true);
					this.setModel(oEngManf, Constants.ENGINEMANF_MODEL);
					//End: ANI0006 2000014601 - Create Engine Manufacturer OData model - oEngManf
					// set the device model
					this.setModel(models.createDeviceModel(), "device");

					// create the locomotive maintenance model
					var oModel = new LocomotiveMaintenanceModel(sServiceUrl, true);
					// var bUseBatch = jQuery.sap.getUriParameters().get("useBatch");
					// oModel.setUseBatch(typeof bUseBatch == "undefined" || "true" === bUseBatch);
					oModel.setUseBatch(true);
					oModel.setRefreshAfterChange(false);

					this.setModel(oModel, Constants.LOCOMOTIVE_MODEL);
					this.setModel(oModel, Constants.ZPMLM_MODEL);

					//Create the Model for Blue Card View
					var oBlueCard = new LocomotiveMaintenanceModel(sPmFracardURl, true);
					this.setModel(oBlueCard, "blueCard");

					this.setModel(new sap.ui.model.json.JSONModel(), Constants.GLOBAL_MY_WORK);
					this.getModel(Constants.GLOBAL_MY_WORK).setProperty("/sTabSelected", "Locomotives");
					this.setModel(new sap.ui.model.json.JSONModel(), Constants.GLOBAL_MODEL);
					this.getModel(Constants.GLOBAL_MODEL).setProperty("/sSelectedView", "MyShop");
					this.setModel(new sap.ui.model.json.JSONModel(), Constants.GLOBAL_LOCOMOTIVE_MODEL);
					this.setModel(new sap.ui.model.json.JSONModel(), Constants.GLOBAL_CRAFT_MODEL);
					this.setModel(new sap.ui.model.json.JSONModel(), Constants.GLOBAL_SHIFT_MODEL);
					//Start: ANI0006 2000014601 - Create JSON Model for oEngManf 
                	this.setModel(new sap.ui.model.json.JSONModel(), Constants.GLOBAL_ENGINEMANF_MODEL);
					//End: ANI0006 2000014601 - Create JSON Model for oEngManf
                 	this.setModel(new sap.ui.model.json.JSONModel(), Constants.LOCOMOTIVE_WO_STATUS);
					this.getModel(Constants.LOCOMOTIVE_WO_STATUS).setProperty("/sWoStatusChanged", true);
					// set i18n model - For compatibility with UI5 library
					// version 1.28
					var i18nModel = new sap.ui.model.resource.ResourceModel({
						bundleName: "com.sap.cp.lm.i18n.i18n"
					});
					this.setModel(i18nModel, "i18n");

					//Constants model
					this.setModel(this.createConstantsModel(), "constants");

					// create version resource model
					var oVersionModel = new sap.ui.model.resource.ResourceModel({
						bundleName: "com.sap.cp.lm.version"
					});
					this.setModel(oVersionModel, Constants.VERSION_MODEL);
					com.sap.cp.lm.util.Formatter.setVersionModel(oVersionModel);
					com.sap.cp.lm.util.Formatter.setComponent(this);

					// initialize the Managers and Data Model access classes
					MapManager.init();
					// CommentManager.init(this.getGlobalModel());
					CraftManager.init(this.getMainModel(), this.getGlobalModel(), this.getGlobalMyWorkModel);

					com.sap.cp.lm.controller.locomotives.LocomotiveManager.init(this.getGlobalModel(), this.getGlobalLocomotiveModel(), this.getMainModel(),
						this.getGlobalWOStatusModel(), i18nModel);
					// com.sap.cp.lm.controller.locomotives.WorkOrderManager.init(this.getGlobalModel(), this.getGlobalLocomotiveModel(), i18nModel);
					//Start: ANI0006 2000014601 - Passing  to initialize  Engine Manufacturer OData Model
					com.sap.cp.lm.model.locomotives.LocomotiveDataModel.init(this.getMainModel(), this.getGlobalLocomotiveModel(), this.getGlobalModel(),
						this.getEngManfModel());
					//End: ANI0006 2000014601 - Passing  to initialize  Engine Manufacturer OData Model	
					com.sap.cp.lm.model.work.WorkDataModel.init(this.getMainModel(), this.getGlobalModel());
					com.sap.cp.lm.model.craft.CraftDataModel.init(this.getMainModel(), this.getGlobalCraftModel(), this.getGlobalModel());
					com.sap.cp.lm.model.material.MaterialModel.init(this.getMainModel(), this.getGlobalModel());

					AlertDataModel.init(this.getMainModel());
					PersonalLinkModel.init(this);
					DefaultSettingModel.init(this);
					TrackSpotModel.init(this);

					// create the routing based on the
					// url/hash
					this.getRouter().initialize();
					this.getRouter().getTargets().display("myShop");
					this._addExtensions();
				},

				/**
				 * Create a constants model that can be used in the binding expressions based on the 
				 * file util/Constants.js
				 * @public
				 * @returns {sap.ui.model.json.JSONModel} the constants model
				 */
				createConstantsModel: function () {
					var oModel = new sap.ui.model.json.JSONModel();
					oModel.setDefaultBindingMode("OneWay");
					oModel.setData(Constants);

					//Add support for getting constants without specifing the root context
					oModel.__getProperty = oModel.getProperty;
					oModel.getProperty = function (sPath) {
						var bShouldAddSlash = sPath && sPath.length > 0 && sPath[0] !== "/";
						var sPathArg = (bShouldAddSlash) ? ("/" + sPath) : sPath;
						return oModel.__getProperty.apply(this, [sPathArg]);
					};

					return oModel;
				},
				/**
				 * Return the main model
				 */
				getMainModel: function () {
					return this.getModel(Constants.LOCOMOTIVE_MODEL);
				},
				/**
				 * 
				 */
				//Start: ANI0006 2000014601 - Return the Engine Manufacturer OData model
				getEngManfModel: function () {
					return this.getModel(Constants.ENGINEMANF_MODEL);
				},
				//End: ANI0006 2000014601 - Return the Engine Manufacturer OData model
				//Start: ANI0006 2000014601 - Return the Engine Manufacturer JSON model
				getEngManfJsonModel: function () {
					return this.getModel(Constants.GLOBAL_ENGINEMANF_MODEL);
				},
				//End: ANI0006 2000014601 - Return the Engine Manufacturer JSON model
				

				/**
				 * Return the global model
				 */
				getGlobalModel: function () {
					return this.getModel(Constants.GLOBAL_MODEL);
				},

				/**
				 * Return the global locomotive model
				 */
				getGlobalLocomotiveModel: function () {
					return this.getModel(Constants.GLOBAL_LOCOMOTIVE_MODEL);
				},
				/**
				 * Return the Wo Status  model
				 */
				getGlobalWOStatusModel: function () {
					return this.getModel(Constants.LOCOMOTIVE_WO_STATUS);
				},

				/**
				 * Return the global shift model
				 */
				getGlobalShiftModel: function () {
					return this.getModel(Constants.GLOBAL_SHIFT_MODEL);
				},

				/**
				 * Return the global craft model
				 */
				getGlobalCraftModel: function () {
					return this.getModel(Constants.GLOBAL_CRAFT_MODEL);
				},

				/**
				 * Return the global my work
				 */
				getGlobalMyWorkModel: function () {
					return this.getModel(Constants.GLOBAL_MY_WORK);
				},

				/**
				 * Return the text value 
				 */
				getText: function (sKey, aArgs) {
					return this.getModel("i18n").getResourceBundle().getText(sKey, aArgs);
				},

				/**
				 * Return the global parameters model
				 */
				getGlobalParametersModel: function () {
					return this.getModel(Constants.GLOBAL_PARAMETERS_MODEL);
				},

				/**
				 * Is it running on the iPad mode
				 */
				isIPadMode: function () {
					if (sap.ui.Device.system.tablet && !sap.ui.Device.system.desktop) {
						return true;
					}
					return false;
				},

				/**
				 * This method can be called to determine whether the sapUiSizeCompact or sapUiSizeCozy
				 * design mode class should be set, which influences the size appearance
				 * of some controls.
				 * 
				 * @public
				 * @return {string} css class, either
				 *         'sapUiSizeCompact' or
				 *         'sapUiSizeCozy' - or an empty
				 *         string if no css class should
				 *         be set
				 */
				getContentDensityClass: function () {
					if (this._sContentDensityClass === undefined) {
						// check whether FLP has already set the content density
						// class; do nothing in this case
						if (jQuery(document.body).hasClass("sapUiSizeCozy") || jQuery(document.body)
							.hasClass("sapUiSizeCompact")) {
							this._sContentDensityClass = "";
						} else if (!Device.support.touch) { // apply
							// "compact" mode if touch is not supported
							this._sContentDensityClass = "sapUiSizeCompact";
						} else {
							// "cozy" in case of touch support; default for most sap.m controls, but
							// needed for desktop-first controls like
							// sap.ui.table.Table
							this._sContentDensityClass = "sapUiSizeCozy";
						}
					}
					return this._sContentDensityClass;
				},

				_addExtensions: function () {
					// add a new method to the date object.
					// converts a date to the SAP date format
					Date.prototype.toSAPDateString = function () {
						var yyyy = this.getFullYear().toString();
						var mm = (this.getMonth() + 1).toString(); // getMonth() is zero-based
						var dd = this.getDate().toString();
						return yyyy + (mm[1] ? mm : "0" + mm[0]) + (dd[1] ? dd : "0" + dd[0]); // padding
					};

					Date.prototype.toSAPTimeString = function () {
						var hh = this.getHours();
						var mm = this.getMinutes();
						return hh + ":" + mm + ":00";
					};
				}
			});
	});