/*&---------------------------------------------------------------------*    
 * Author         : KIR0084 MIKE KIRK                                    *
 * Date           : 23-Jun-2019                                          *
 * Project        : Locomotive Maintenance Phase 2                       *
 * Description    : LMP2-32: Change the Loco User Status                 *
 * Search Term    : LMP2-32
 *&----------------------------------------------------------------------*/
/*&---------------------------------------------------------------------*
 * Author         : BAJ0018                                              *
 * Date           : 04-Dec-2020                                          *
 * Project        : EAM-ASR3416050                                       *
 * Description    : removed operations from  turnover doc  print out     *
 * Search Term    : TURNOVERDOC
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*   
 * Author/Changed By   : SHE0272										*
 * Date                : 08 -Jul -2021									*
 * Project             : LLM2.23 - Primary Defect						*
 * Description         : New cell in the print to display primary reason*
 * Search Term         : LLM2.23										*
 *&----------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*   
 * Author/Changed By   : SHE0272											*
 * Date                : 19 -Aug -2021										*
 * Project             : LLM Project - Turn over filter fix					*
 * Description         : Turn over filter fix								*
 * Search Term         : LLM Project										*
 *&-------------------------------------------------------------------------*/
 /*&-----------------------------------------------------------------------*   
 * Author/Changed By   : SHE0272											*
 * Date                : 09 - Sep -2021										*
 * Project             : INC0110701 - Incident Fix							*
 * Description         : Incident Fix										*
 * Search Term         : INC0110701											*
 *&-------------------------------------------------------------------------*/

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
	"com/sap/cp/lm/controller/common/PrintManager",
	"com/sap/cp/lm/controller/myShop/common/WorkOrderComments",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter"

], function (Controller, Constants, Formatter, BusyIndicator, LocomotiveDataModel, PrintManager, WorkOrderComments, Filter,
	FilterOperator, Sorter) {
	"use strict";

	var _this;

	return Controller.extend(
		"com.sap.cp.lm.controller.turnoverDoc.turnoverDoc", {
			formatter: Formatter,

			//--------------------------------------------------------------------
			// Life cycle functions
			//--------------------------------------------------------------------

			/**
			 * Initializes the controller
			 */
			onInit: function () {
				_this = this;

				// set content density
				this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());

				$(window).on('resize', $.proxy(this.handleWindowResize, this));

				this._oModel = new sap.ui.model.json.JSONModel();
				this._oModel.setSizeLimit(5000);
				this.getView().setModel(this._oModel);

				this._oViewPropertiesModel = new sap.ui.model.json.JSONModel();
				this._initViewPropertiesModel();
				this.getView().setModel(this._oViewPropertiesModel, "viewProperties");

				this._oGlobalShiftModel = this.getOwnerComponent().getGlobalShiftModel();
				this.getView().setModel(this._oGlobalShiftModel, "shift");

				this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
				this._oGlobalModel.setProperty("/turnOverLocoMotiveView", true);
				this._oI18nModel = this.getOwnerComponent().getModel("i18n");

				this._bExpandAll = false;

				this._shopId = "";

				this.oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());
				this.oRouter.getTargets().attachDisplay(function (oEvent) {
					// Start - SHE0272 - INC0110701 - Setting the checkbox to false on user navigation
					if (oEvent.getParameter("name") === "turnoverDoc") {
						_this.getView().byId("idDeferred").setSelected(true);
						_this.getView().byId("idClosedWorkOrder").setSelected(true);
						_this.getView().byId("idRYRLocomotive").setSelected(false);
						_this._onTurnoverDocRouteMatched();
					} else if (_this._oGlobalModel.getProperty("/sSelectedView") === Constants.TURNOVERDOC) {
						// On page reopening, refresh the list.
						_this.getView().byId("idDeferred").setSelected(true);
						_this.getView().byId("idClosedWorkOrder").setSelected(true);
						_this.getView().byId("idRYRLocomotive").setSelected(false);
						_this._onTurnoverDocRouteMatched(true);
					}
					// End - SHE0272 - INC0110701 - Setting the checkbox to false on user navigation
				});

				// Load data for next and previous shift
				this.initShopShifts();

				// register to listen to change events of the globalmodel which contain the currentShop
				var binding = new sap.ui.model.Binding(this._oGlobalModel, "/", this._oGlobalModel.getContext("/"));
				binding.attachChange(function () {
					_this.onGlobalModelChange();
				});
			},

			initShopShifts: function () {
				var shopId = this._oGlobalModel.getProperty("/currentShop/Id");
				LocomotiveDataModel.fetchShopShifts(shopId, this._fetchShopShiftsSuccess, this._fetchShopShiftsFailure,
					this);
			},

			//--------------------------------------------------------------------
			// Private functions
			//--------------------------------------------------------------------

			/**
			 * Create the view properties model for this view. 
			 */
			_initViewPropertiesModel: function (bValue) {
				this._oViewPropertiesModel.setProperty("/HideComplete", true);
				this._oViewPropertiesModel.setProperty("/displayCraftTable", false);
			},

			refreshList: function (force) {
				var tempCurrentShop = this._oGlobalModel.getProperty("/currentShop");

				// check if the currentShop is different and if so reload
				if (force || (tempCurrentShop && tempCurrentShop.Id !== this._shopId)) {
					// the initial load of the application window.height is incorrect at onAfterRendering and calculating the height later
					this.handleWindowResize();
					this._shopId = tempCurrentShop.Id;

					this._fetchTurnoutReport();
					this._fetchKpiInformation();
					this._fetchCraftList();
					this.initShopShifts();
				}

				this.refreshExpandToggle();
			},

			_fetchKpiInformation: function () {
				var shopId = this._oGlobalModel.getProperty("/currentShop/Id");
				// LocomotiveDataModel.fetchShopKPIs(shopId, this._fetchKpiInformationSuccess, this._fetchTurnoutReportFailure,
				// 	this);
				LocomotiveDataModel.fetchSystemViewKPIs(shopId, this._fetchSystemViewKpiInformationSuccess, this._fetchTurnoutReportFailure,
					this);
			},

			_fetchSystemViewKpiInformationSuccess: function (oData) {
				this.getView().getModel().setProperty("/kpiInformation", oData.results[0]);
			},

			/**
			 * Reading the locomotives
			 */
			_fetchTurnoutReport: function () {
				this._aShoppedLocomotives = [];
				this._oGlobalLocomotiveModel = this.getOwnerComponent().getGlobalLocomotiveModel();

				var aFilterList = _this._prepareODataFilters();
				var aSorterList = []; //_this._prepareSorters(); 

				LocomotiveDataModel.fetchTurnoverDocReport(aFilterList, aSorterList, this._fetchTurnoutReportSuccess, this._fetchTurnoutReportFailure,
					this);
			},

			_prepareODataFilters: function () {
				var globalModel = _this._oGlobalModel;

				var aFilterList = [];
				aFilterList.push(new Filter({
					path: "ShopId",
					operator: FilterOperator.EQ,
					value1: globalModel.getProperty("/currentShop").Id
				}));

				// Start - SHE0272 - LLM Project - Turn over filter fix
				var deferredFilter = this.getView().byId("idDeferred").getSelected();
				if (deferredFilter) {
					aFilterList.push(new Filter({
						path: "DeferredFlag",
						operator: FilterOperator.EQ,
						value1: 'X'
					}));
				}
				var closedWorkOrderFilter = this.getView().byId("idClosedWorkOrder").getSelected();
				if (closedWorkOrderFilter) {
					aFilterList.push(new Filter({
						path: "ClosedFlag",
						operator: FilterOperator.EQ,
						value1: 'X'
					}));
				}
				var ryrLocomotiveFilter = this.getView().byId("idRYRLocomotive").getSelected();
				if (ryrLocomotiveFilter) {
					aFilterList.push(new Filter({
						path: "RyrFlag",
						operator: FilterOperator.EQ,
						value1: 'X'
					}));
				}
				// End - SHE0272 - LLM Project - Turn over filter fix

				return aFilterList;
			},

			_prepareCraftsFilters: function () {
				var itemFilterList = [];
				//   var craftShiftFilter = this.getView().byId("idShift").getSelectedItem();
				var craftSelectAvailableFilter = this.getView().byId("idCraftAvailable").getSelected();
				var craftSelectUnavailableFilter = this.getView().byId("idCraftUnavailable").getSelected();
				var craftShiftFilters = this.getView().byId("filterCraftShiftHBox").getItems().filter(function (obj) {
					return obj.getSelected();
				}).map(function (item) {
					return item.getBindingContext("global").getObject();
				});

				itemFilterList.push(new Filter({
					path: "",
					test: function (object) {
						// Filter for both work order numbers and then locomotives
						var success = true;

						// Filter on shifts
						var shiftMatch = false;

						craftShiftFilters.forEach(function (shiftFilter) {
							if (object.Shift === shiftFilter.ShiftName) {
								shiftMatch = true;
							}
						});

						if (!shiftMatch) {
							success = false;
						}

						if (!craftSelectUnavailableFilter && object.AvailabilityStatus !== "A") {
							success = false;
						}

						if (!craftSelectAvailableFilter && object.AvailabilityStatus === "A") {
							success = false;
						}

						if (object.UnavailReason === "BV" || object.UnavailReason === "OF") {
							success = false;
						}

						return success;
					}
				}));

				return itemFilterList;
			},

			onWorkOrderFilterChange: function () {
				var aFilters = _this._prepareFrontEndFilters();

				var locomotiveTree = this.getView().byId("TurnoverDocTree") || this.getView().byId("TurnoverDocTreeTable");

				if (locomotiveTree) {
					locomotiveTree.getBinding("rows").filter(aFilters);
				} else if (this.getView().byId("TurnoverDocList")) {
					this.getView().byId("TurnoverDocList").getBinding("items").filter(aFilters);
					this.getView().byId("TurnoverDocList").getItems().forEach(function (item) {
						item.getContent()[0].getContent()[0].getBinding("items").filter(aFilters);
					});
				}
			},

			onDeferredChange: function () {
				// SHE0272 - LLM Project - Turn over filter fix - Changed from UI filter to service call
				// this.onWorkOrderFilterChange();
				this._fetchTurnoutReport();
			},

			onWorkOrderStatusChange: function () {
				this.onWorkOrderFilterChange();
				//   this._fetchTurnoutReport();
				//   this._fetchCraftList();
			},

			onCraftFilterChange: function () {
				_this.getView().byId("TurnoverCraftList").getBinding("items").filter(_this._prepareCraftsFilters());
			},

			/*
			 * Work Order level filters do not speed up back end performance, so might as well handle in front end since its possible and much more responsive
			 */
			_prepareFrontEndFilters: function () {
				var itemFilterList = [];

				var workOrderFilterValue = this.getView().byId("idOrderNo").getValue();
				if (workOrderFilterValue) {
					itemFilterList.push(new Filter({
						path: "",
						test: function (object) {
							// Filter for both work order numbers and then locomotives
							return (
								(object.type === "Operation" && object.OrderNo.includes(workOrderFilterValue)) ||
								(object.type === "Order" && object.OrderNo.includes(workOrderFilterValue)) ||
								(object.type === "Loco" && object.OrderSet.filter(function (order) {
									return order.OrderNo.includes(workOrderFilterValue);
								}).length > 0)
							);
						}
					}));
				}

				if (this._bHideComplete) {
					itemFilterList.push(new Filter({
						path: "",
						test: function (object) {
							// Filter for both work order numbers and then locomotives
							return (
								(object.type === "Operation" && object.Status !== Constants.STATUS_COMPLETED) ||
								(object.type === "Order" && object.CompletedStatus) ||
								(object.type === "Loco" && object.OrderSet.filter(function (order) {
									return order.CompletedStatus;
								}).length > 0)
							);
						}
					}));
				}
				// Start - SHE0272 - LLM Project - Turn over filter fix - Commented UI filter.
				// var deferredFilter = this.getView().byId("idDeferred").getSelected();
				// if (deferredFilter) {
				// 	itemFilterList.push(new Filter({
				// 		path: "",
				// 		test: function (object) {
				// 			// Filter for both work order numbers and then locomotives
				// 			return (
				// 				(object.type === "Operation" && object.Status === Constants.STATUS_DEFERRED) ||
				// 				(object.type === "Order" && object.Status === Constants.STATUS_DEFERRED) ||
				// 				(object.type === "Loco" && object.OrderSet.filter(function (order) {
				// 					return order.Status === Constants.STATUS_DEFERRED;
				// 				}).length > 0)
				// 			);
				// 		}
				// 	}));
				// }
				// End - SHE0272 - LLM Project - Turn over filter fix - Commented UI filter.

				var workOrderStatuses = this.getView().byId("idLocomotiveStatus").getSelectedKeys();
				if (workOrderStatuses && workOrderStatuses.length > 0) {
					itemFilterList.push(new Filter({
						path: "",
						test: function (object) {
							// Filter for both work order numbers and then locomotives
							return (
								((object.type === "Operation") ||
									(object.type === "Order") ||
									(object.type === "Loco")) &&
								workOrderStatuses.filter(function (filterValue) {
									if (filterValue.endsWith("*")) {
										return object.LocoUserStatus.startsWith(filterValue.substring(0, filterValue.length - 1));
									} else {
										return object.LocoUserStatus === filterValue;
									}
								}).length > 0
							);
						}
					}));
				}

				return new Filter(itemFilterList, true);
			},

			_prepareSorters: function () {
				var thisView = _this.getView();
				var sortField = thisView.byId("idSortField").getSelectedKey();
				var sortOrder = thisView.byId("idSortOrder").getButtons().find(function (button) {
					return button.getSelected();
				}).getText();

				return [
					new Sorter(sortField || "EtrTs", sortOrder === "Descending", "", function (data1, data2) {
						if (sortField === "DwellHrs") {
							if ((+data1) === (+data2)) {
								return 0;
							} else if ((+data1) > (+data2)) {
								return 1;
							} else {
								return -1;
							}
						} else {
							if (data1 === data2) {
								return 0;
							} else if (data1 > data2) {
								return 1;
							} else {
								return -1;
							}
						}
					}),
					new Sorter("Activity", false)
				];
			},

			/**
			 * Handle shop shifts being loaded
			 */
			_fetchShopShiftsSuccess: function (oData) {
				var currentShift = this.getView().getModel("global").getProperty("/currentShift");
				var shiftObjects = this.getView().getModel("global").getProperty("/currentShiftFilters");
				var shiftSplit = currentShift.ShiftName.split("_");

				var nextShiftNumber = (+shiftSplit[1]) + 1;
				if (nextShiftNumber === 4) {
					nextShiftNumber = 1;
				}

				var nextShiftName = shiftSplit[0] + "_" + nextShiftNumber;

				var shiftItems = this.getView().byId("filterCraftShiftHBox").getItems()

				shiftItems.filter(function (listShift, index) {
					return index >= 0 && (nextShiftName === shiftObjects[index].ShiftName);
					//   && (shiftObjects[index-1].ShiftStart.getTime() <= currentDate
					//       && shiftObjects[index-1].ShiftEnd.getTime() >= currentDate);
				})[0].setSelected(true);

				// this.getView().byId("idShift").setSelectedIndex(0);
				this.setupTitleString();
			},

			_fetchTurnoutReportSuccess: function (oData) {
				var odataData = oData.results.map(function (loco) {

					loco.OrderSet = loco.OrderSet.results.map(function (order) {
						order.OperationSet = order.OperationSet.results.map(function (operation) {
							operation.TaskSet = operation.TaskSet.results;
							operation.AssignmentSet = operation.AssignmentSet.results;
							operation.CommentSet = operation.CommentSet.results;
							operation.LocoUserStatus = loco.LocoUserStatus;
							operation.type = "Operation";
							return operation;
						});
						order.CompletedStatus = order.OperationSet.filter(function (operation) {
							return operation.Status !== Constants.STATUS_COMPLETED;
						}).length > 0;
						order.LocoUserStatus = loco.LocoUserStatus;
						order.type = "Order";
						return order;
					});
					loco.type = "Loco";
					return loco;
				});

				// Because this list is large, we must unbind list, the bind with sorters and filters in place.
				// _this._setTableHeightDynamically();
				var turnoverDocList;
				_this._oModel.setProperty("/Shopped", odataData);
				_this._oModel.setSizeLimit(odataData.length);

				if (_this.getView().byId("TurnoverDocTreeTable")) {
					turnoverDocList = _this.getView().byId("TurnoverDocTreeTable");
					turnoverDocList.unbindRows();
					if (!this._oListFragment) {
						this._oListFragment = sap.ui.xmlfragment("com.sap.cp.lm.view.turnoverDoc.WorkOrderReportTreeTableItem", this);
					}

					turnoverDocList.bindRows({
						path: "/Shopped",
						parameters: {
							arrayNames: ['OperationSet', 'OrderSet']
						},
						filters: _this._prepareFrontEndFilters(),
						sorter: _this._prepareSorters(),
						templateShareable: true,
						template: this._oListFragment
					});
					turnoverDocList.setVisibleRowCountMode("Auto");
				}
			},

			_fetchTurnoutReportFailure: function (aErrorResponses) {

			},

			refreshCompleteToggle: function () {
				if (!this._bHideComplete) {
					this.byId("TurnoverDocToggleCompleteButton").setText(_this._oI18nModel.getProperty("HIDE_COMPLETE"));
				} else {
					this.byId("TurnoverDocToggleCompleteButton").setText(_this._oI18nModel.getProperty("SHOW_ALL"));
				}
			},

			refreshExpandToggle: function () {
				if (!this._bExpandAll) {
					this.byId("TurnoverDocToggleExpandButton").setText(_this._oI18nModel.getProperty("EXPAND_ALL"));
				} else {
					this.byId("TurnoverDocToggleExpandButton").setText(_this._oI18nModel.getProperty("COLLAPSE_ALL"));
				}
			},

			refreshToggleView: function () {
				if (!this._bViewCraft) {
					this.byId("TurnoverDocCraftButton").setText(_this._oI18nModel.getProperty("VIEW_CRAFTS"));
					this._oGlobalModel.setProperty("/turnOverLocoMotiveView", true);
				} else {
					this.byId("TurnoverDocCraftButton").setText(_this._oI18nModel.getProperty("VIEW_LOCOMOTIVES"));
					this._oGlobalModel.setProperty("/turnOverLocoMotiveView", false);
				}
			},

			togglePanels: function () {
				if (!this._bExpandAll) {
					this._collapseLocomotives();
				} else {
					this._expandLocomotives();
				}
			},

			toggleComplete: function () {
				this.onWorkOrderFilterChange();
			},

			//--------------------------------------------------------------------
			// Event handlers
			//--------------------------------------------------------------------

			_onTurnoverDocRouteMatched: function (force) {
				this._oGlobalModel.setProperty("/needDrawMap", true);
				_this.refreshList(force);
			},

			_fetchCraftList: function () {

				var oParams = {
					Shop: this._shopId
				};

				LocomotiveDataModel.fetchCraftWorkPlanListWithShift(_this.onSuccessCraftList, null, this, oParams);
			},

			onSuccessCraftList: function (oData) {
				var locoList = _this._oModel.getProperty("/Shopped");
				var craftSet = {};

				// Map crafts into person numbers to speed up search.
				oData.results.forEach(function (craft) {
					craftSet[craft.PersonNo] = craft;
					craftSet[craft.PersonNo].AssignmentSet = [];

					if (craft.UnavailReason) {
						// Add assignment entry so that unavailable reason appears in attributes
						craftSet[craft.PersonNo].AssignmentSet.push({
							AttributeText: Formatter.translateUnavailabilityReason(craft.UnavailReason),
							Unavailable: "true"
						});
					}
				});

				// Loop over locomotives and add in operations
				locoList.forEach(function (loco) {
					loco.OrderSet.forEach(function (order) {
						order.OperationSet.forEach(function (operation) {
							var assignment = {};
							assignment.LocoId = order.LocoId;
							assignment.OrderName = order.Descr + " (" + order.OrderNo + ")";
							assignment.OperationName = operation.Descr;
							assignment.AttributeText = assignment.OrderName + " - " + assignment.OperationName;
							assignment.Unavailable = "";
							operation.AssignmentSet.forEach(function (ass) {
								if (craftSet[ass.PersonNo] && craftSet[ass.PersonNo].AssignmentSet) {
									craftSet[ass.PersonNo].AssignmentSet.push(assignment);
								}
							});
						});
					});
				});

				_this.getView().getModel().setProperty("/CraftList", Object.values(craftSet));
				_this.getView().byId("TurnoverCraftList").getBinding("items").filter(_this._prepareCraftsFilters());
			},

			/**
			 * Sets height of the shop page
			 */
			handleWindowResize: function () {

			},

			/**
			 * when the global model is changed
			 */
			onGlobalModelChange: function () {
				_this.refreshList();
			},

			/**
			 * Map button pressed
			 */
			onMapPress: function () {
				_this.oRouter.getTargets().display("myShop");
			},

			/**
			 * Show/hide complete work orders
			 */
			onToggleComplete: function () {
				this._bHideComplete = !this._bHideComplete;

				this._oViewPropertiesModel.setProperty("/HideComplete", this._bHideComplete);

				this.toggleComplete();
				this.refreshCompleteToggle();
			},

			/**
			 * Expand panels
			 */
			onToggleExpand: function () {
				this._bExpandAll = !this._bExpandAll;

				this.togglePanels();
				this.refreshExpandToggle();
			},

			onToggleView: function () {
				this._bViewCraft = !this._bViewCraft;
				this._oViewPropertiesModel.setProperty("/displayCraftTable", this._bViewCraft);
				this._oGlobalModel.setProperty("/viewSpacers", this._oViewPropertiesModel.getData());

				this.refreshToggleView();
			},

			onSortChange: function () {
				if (_this.getView().byId("TurnoverDocTree")) {
					_this.getView().byId("TurnoverDocTree").getBinding("items").sort(_this._prepareSorters());
					// _this.getView().byId("TurnoverDocPrintTree").getBinding("items").sort(_this._prepareSorters());
				}
				if (_this.getView().byId("TurnoverDocTreeTable")) {
					_this.getView().byId("TurnoverDocTreeTable").getBinding("rows").sort(_this._prepareSorters());
				} else if (_this.getView().byId("TurnoverDocList")) {
					_this.getView().byId("TurnoverDocList").getBinding("items").sort(_this._prepareSorters());
				}
			},

			onClickCommentOpen: function (oEvent) {
				var oParams = {};
				var objectHeader = oEvent.getSource().getBindingContext().getObject();
				oParams.oWorkOrderHeader = objectHeader;
				oParams.fnFirstCommentAdded = _this.handleFilterApplyPress.bind(_this, true);
				oParams.readOnly = true;
				//oParams.oComments = objectHeader.CommentSet;

				var oWorkOrderComments = new WorkOrderComments(oParams);
				if (!_this._oI18nModel && _this.getOwnerComponent()) {
					_this._oI18nModel = _this.getOwnerComponent().getModel("i18n");
				}
				oWorkOrderComments.getFragment().setModel(_this._oI18nModel, "i18n");
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oWorkOrderComments);
				oWorkOrderComments.getFragment().open();
			},

			/**
			 * Print map
			 * @param(event) oEvent is the listener of the event
			 */
			onPressMapPrint: function (oEvent) {

				var craftsVisible = this.getView().byId("TurnoverDocCraftPanel").getVisible();
				setTimeout(function () {
					var sTitle = "CP Rail Turnover Report";
					var sShopNameandDate = this._oGlobalModel.getProperty("/currentShop/Name");
					sShopNameandDate += ", " + Formatter.changeDateFormatMMDDHHmm(Formatter.localDateAtCurrentShop(new Date()));
					var sHtmlContent = "<center> <h1>" + sTitle + "</h1> <p>" + sShopNameandDate + "</p> </center>" + "<p >" + _this._preparePrintHtmlContent();
					PrintManager.createPrintPage(sTitle, sHtmlContent, 1000);
				}.bind(this), 0);
			},

			_expandLocomotives: function (noExpandWorkOrders) {
				var locomotiveTree = this.getView().byId("TurnoverDocTree") || this.getView().byId("TurnoverDocTreeTable");
				var locomotiveList = this.getView().byId("TurnoverDocList");

				if (locomotiveTree) {
					locomotiveTree.expandToLevel(3);
				} else if (locomotiveList) {
					locomotiveList.getItems().forEach(function (item) {
						item.getContent()[0].setExpanded(true);
						if (!noExpandWorkOrders) {
							item.getContent()[0].getContent()[0].getItems().forEach(function (item2) {
								item2.getContent()[0].setExpanded(true);
							});
						}
					});
				}
			},

			_collapseLocomotives: function () {
				var locomotiveTree = this.getView().byId("TurnoverDocTree") || this.getView().byId("TurnoverDocTreeTable");
				var locomotiveList = this.getView().byId("TurnoverDocList");

				if (locomotiveTree) {
					locomotiveTree.collapseAll();
				} else if (locomotiveList) {
					locomotiveList.getItems().forEach(function (item) {
						item.getContent()[0].setExpanded(false);
						item.getContent()[0].getContent()[0].getItems().forEach(function (item2) {
							item2.getContent()[0].setExpanded(false);
						});
					});
				}
			},

			setupTitleString: function (shopName, shift) {
				this.getView().byId("TurnoverDocTitle").setText(this._oGlobalModel.getProperty("/currentShop/Name") + ", " + Formatter.changeDateFormatMMDDHHmm(
					Formatter.localDateAtCurrentShop(new Date())));
			},

			formatCommentString: function (createdBy, createdDate, comment) {
				return createdBy + " - " + Formatter.changeDateFormatMMDDHHmm(Formatter.localDateAtCurrentShop(createdDate)) + ": " + comment;
			},

			formatShiftSelected: function (shift, shiftListing) {
				var currentDate = new Date().getTime();
				return shiftListing.filter(function (listShift) {
					return (shift.ShiftName === listShift.ShiftName) && (listShift.ShiftStart.getTime() <= currentDate && listShift.ShiftEnd.getTime() >=
						currentDate);
				});
			},

			// reset button handler
			handleFilterResetPress: function () {
				this.getView().byId("idLocomotiveStatus").setSelectedKeys("DLA");
				this.getView().byId("idDeferred").setSelected(true); // SHE0272 - INC0110701 - Setting the checkbox to false on user navigation
				this.getView().byId("idClosedWorkOrder").setSelected(true);
				this.getView().byId("idRYRLocomotive").setSelected(false);
				this.getView().byId("idOrderNo").setValue("");
				this.onWorkOrderFilterChange();
			},

			// function will be triggered on click of Go button in filter panel
			handleFilterApplyPress: function () {
				_this._fetchTurnoutReport();
				_this._fetchKpiInformation();
				_this._fetchCraftList();
			},

			onShiftChange: function () {
				this.setupTitleString();
				this.handleFilterApplyPress();
			},

			_preparePrintHtmlContent: function () {
				var retStr = '<div style="width:100%" class="lmTurnoverDocTree sapMList">\n' +
					'<ul role="tree" tabindex="0" class="sapMListItems sapMListModeNone sapMListShowSeparatorsAll sapMListUl">';

				// The bindList function is used to return a filter and sorted list of information from a ui5 model
				var listBinding = _this._oModel.bindList("/Shopped", undefined, _this._prepareSorters(), _this._prepareFrontEndFilters(), {
					mode: sap.ui.model.BindingMode.OneTime
				});

				// Iterate over binding a prepare the list of model objects
				listBinding.aIndices.map(function (index) {
					// Add in path to current object
					listBinding.oList[index].sPath = "/Shopped/" + index;
					return listBinding.oList[index];
				}).forEach(function (loco) {
					retStr +=
						'<li tabindex="-1" role="treeitem" aria-level="1" aria-expanded="true" class="sapMCTI sapMLIB sapMLIB-CTX sapMLIBFocusable sapMLIBShowSeparator sapMLIBTypeInactive sapMTreeItemBase" style="padding-left:0rem">\n' +
						'<span role="presentation" aria-hidden="true" data-sap-ui-icon-content="" class="sapMTreeItemBaseExpander sapUiIcon sapUiIconMirrorInRTL sapUiIconPointer" style="font-family:\'SAP-icons\'"></span>\n' +
						'<div class="sapMLIBContent">\n' +
						'<div data-sap-ui-fastnavgroup="true" role="toolbar" class="sapMIBar sapMTB sapMTB-Auto-CTX sapMTBInactive sapMTBNewFlex sapMTBStandard" style="width:100%">\n' +
						'<div class="sapMBarChild sapMFlexBox sapMFlexBoxAlignContentStretch sapMFlexBoxAlignItemsStretch sapMFlexBoxBGTransparent sapMFlexBoxJustifyStart sapMFlexBoxWrapNoWrap sapMVBox sapMTBShrinkItem" style="width:100%">\n' +
						'<div class="sapMFlexBox sapMFlexBoxAlignContentStart sapMFlexBoxAlignItemsCenter sapMFlexBoxBGTransparent sapMFlexBoxJustifySpaceAround sapMFlexBoxWrapNoWrap sapMFlexItem sapMHBox">\n' +
						'<div style="order:0;flex-grow:0;flex-shrink:1;flex-basis:12%;min-height:auto;min-width:auto" class="sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto">\n' +
						'<span class="lmWorkPlanListItemDescription sapMText sapMTextBreakWord sapMTextMaxWidth sapUiSelectable sapUiSmallMarginEnd" style="text-align:left">' +
						loco.LocomotiveId + '</span></div>\n' +
						'<div style="order:0;flex-grow:0;flex-shrink:1;flex-basis:10%;min-height:auto;min-width:auto" class="lmNoPrintFlexItem sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto">\n' +
						'<span class="sapMText sapMTextMaxWidth sapUiMediumMarginEnd sapUiSelectable" style="text-align:left">Status: ' + loco.LocoUserStatus +
						'</span></div>\n' +
						'<div style="order:0;flex-grow:0;flex-shrink:1;flex-basis:4%;min-height:auto;min-width:auto" class="sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto">\n' +
						'<span class="sapMText sapMTextBreakWord sapMTextMaxWidth sapUiMediumMarginEnd sapUiSelectable" style="text-align:left">' +
						loco.ShopReason + '</span></div>\n' +
						'<div style="order:0;flex-grow:3;flex-shrink:1;flex-basis:12%;min-height:auto;min-width:auto" class="sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto">\n' +
						'<span class="sapMText sapMTextMaxWidth sapUiMediumMarginEnd sapUiSelectable" style="text-align:left">ETR: ' + com.sap.cp.lm.util
						.Formatter.changeTimestampToDayHour(loco.EtrTs, loco.EtrTz) + '</span></div>\n' +
						'<div style="order:0;flex-grow:5;flex-shrink:1;flex-basis:19%;min-height:auto;min-width:auto" class="sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto">\n' +
						'<span class="sapMText sapMTextMaxWidth sapUiMediumMarginEnd sapUiSelectable" style="text-align:left">Actual Dwell Time: ' +
						loco.DwellHrs + 'h</span></div>\n' +
						'<div style="order:0;flex-grow:0;flex-shrink:1;flex-basis:15%;min-height:auto;min-width:auto" class="lmNoPrintFlexItem sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto">\n' +
						'<span class="sapMText sapMTextMaxWidth sapUiMediumMarginEnd sapUiSelectable" style="text-align:left">Location: ' + loco.Spot +
						'/' + loco.Track + '</span></div>\n' +
						'<div style="order:0;flex-grow:0;flex-shrink:1;flex-basis:15%;min-height:auto;min-width:auto" class="lmProgressIndicatorContainer sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto">\n' +
						'<div tabindex="-1" class="lmProgressIndicator sapMPI sapMPIValueNormal" style="width:100%" role="progressbar" aria-valuemin="0" aria-valuenow="' +
						com.sap.cp.lm.util.Formatter.setLocomotiveProgressIndicator(loco.OrderSet, loco.ShopStatus) +
						'" aria-valuemax="100" aria-valuetext="' + com.sap.cp.lm.util.Formatter.setLocomotiveProgressIndicator(loco.OrderSet, loco.ShopStatus) +
						'% Entry successfully validated">\n' +
						'<div class="sapMPIBar sapMPIBarPositive" id="__indicator2-application-Test-url-component---turnoverDoc--TurnoverDocTree-0-bar" style="flex-basis:' +
						com.sap.cp.lm.util.Formatter.setLocomotiveProgressIndicator(loco.OrderSet, loco.ShopStatus) + '%">\n' +
						'<span class="sapMPIText sapMPITextLeft" id="__indicator2-application-Test-url-component---turnoverDoc--TurnoverDocTree-0-textLeft"></span></div>\n' +
						'<div class="sapMPIBarRemaining"><span class="sapMPIText sapMPITextRight" id="__indicator2-application-Test-url-component---turnoverDoc--TurnoverDocTree-0-textRight"></span></div></div></div>\n' +
						'<div style="order:0;flex-grow:0;flex-shrink:1;flex-basis:13%;min-height:auto;min-width:auto" class="sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto">\n' +
						'<span class="sapMText sapMTextMaxWidth sapUiSelectable sapUiSmallMarginBegin" style="text-align:left">' + com.sap.cp.lm.util.Formatter
						.setLocomotiveStatusText(loco.OrderSet, loco.ShopStatus) + '</span></div></div>\n' +
						'<span class="sapUiHiddenPlaceholder" style="display: none;" aria-hidden="true"></span>\n ' +
						'<span class="sapUiHiddenPlaceholder" data-sap-ui="sap-ui-invisible-__hbox16-application-Test-url-component---turnoverDoc--TurnoverDocTree-0" style="display: none;" aria-hidden="true"></span></div></div></div></li>';

					// The bindList function is used to return a filter and sorted list of information from a ui5 model
					var orderListBinding = _this._oModel.bindList(loco.sPath + "/OrderSet/", undefined, _this._prepareSorters(), _this._prepareFrontEndFilters(), {
						mode: sap.ui.model.BindingMode.OneTime
					});

					orderListBinding.aIndices.map(function (index) {
						orderListBinding.oList[index].sPath = loco.sPath + "/OrderSet/" + index;
						return orderListBinding.oList[index];
					}).forEach(function (order) {

						retStr +=
							'<li tabindex="-1" role="treeitem" aria-level="2" aria-expanded="true" class="sapMCTI sapMLIB sapMLIB-CTX sapMLIBFocusable sapMLIBShowSeparator sapMLIBTypeInactive sapMTreeItemBase sapMTreeItemBaseChildren" style="padding-left:1rem">\n' +
							'<span role="presentation" aria-hidden="true" data-sap-ui-icon-content="" class="sapMTreeItemBaseExpander sapUiIcon sapUiIconMirrorInRTL sapUiIconPointer" style="font-family:\'SAP-icons\'">\n' +
							'</span><div class="sapMLIBContent"><div data-sap-ui-fastnavgroup="true" role="toolbar" class="sapMIBar sapMTB sapMTB-Auto-CTX sapMTBInactive sapMTBNewFlex sapMTBStandard" style="width:100%">\n' +
							'<div class="sapMBarChild sapMFlexBox sapMFlexBoxAlignContentStretch sapMFlexBoxAlignItemsStretch sapMFlexBoxBGTransparent sapMFlexBoxJustifyStart sapMFlexBoxWrapNoWrap sapMVBox sapMTBShrinkItem" style="width:100%">\n' +
							'<span class="sapUiHiddenPlaceholder" style="display: none;" aria-hidden="true"></span>\n' +
							'<div class="sapMFlexBox sapMFlexBoxAlignContentStart sapMFlexBoxAlignItemsCenter sapMFlexBoxBGTransparent sapMFlexBoxJustifySpaceAround sapMFlexBoxWrapNoWrap sapMFlexItem sapMHBox">\n' +
							// Start SHE0272: LLM2.23 - Primary Defect - New cell in the print to display primary reason
							'<div style="order:0;flex-grow:1;flex-shrink:1;flex-basis:auto;min-height:auto;min-width:5%" class="sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto">\n' +
							'<span class="lmWorkPlanListItemDescription sapMText sapMTextBreakWord sapMTextMaxWidth sapUiSelectable sapUiSmallMarginEnd" style="text-align:left">' +
							com.sap.cp.lm.util.Formatter.setPrimaryReasonIndicator(order.PrimaryNotifFlag) + '</span></div>\n' +
							// End SHE0272: LLM2.23 - Primary Defect - New cell in the print to display primary reason
							'<div style="order:0;flex-grow:1;flex-shrink:1;flex-basis:auto;min-height:auto;min-width:15%" class="sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto">\n' +
							'<span class="lmWorkPlanListItemDescription sapMText sapMTextBreakWord sapMTextMaxWidth sapUiSelectable sapUiSmallMarginEnd" style="text-align:left">' +
							order.OrderNo + '</span></div>\n' +
							'<div style="order:0;flex-grow:0;flex-shrink:1;flex-basis:auto;min-height:auto;min-width:47%" class="sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto">\n' +
							'<span class="lmWorkPlanListItemDescription sapMText sapMTextMaxWidth sapUiSelectable sapUiSmallMarginEnd" style="text-align:left">' +
							order.Descr + '</span></div>\n' +
							'<div style="order:0;flex-grow:0;flex-shrink:1;flex-basis:auto;min-height:auto;min-width:18%" class="lmProgressIndicatorContainer sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto">\n' +
							'<div tabindex="-1" class="lmProgressIndicator sapMPI sapMPIValueMin" style="width:100%" role="progressbar" aria-valuemin="0" aria-valuenow="' +
							com.sap.cp.lm.util.Formatter.setProgressIndicator(order.Status, order.OperationSet) +
							'" aria-valuemax="100" aria-valuetext="' + com.sap.cp.lm.util.Formatter.setProgressIndicator(order.Status, order.OperationSet) +
							'%">\n' +
							'<div class="sapMPIBar sapMPIBarNegative" style="flex-basis:' + com.sap.cp.lm.util.Formatter.setProgressIndicator(order.Status,
								order.OperationSet) + '%"><span class="sapMPIText sapMPITextLeft"></span></div>\n' +
							'<div class="sapMPIBarRemaining"><span class="sapMPIText sapMPITextRight"></span></div></div></div>\n' +
							'<div style="order:0;flex-grow:0;flex-shrink:1;flex-basis:auto;min-height:auto;min-width:15%" class="sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto">\n' +
							'<span class="lmWorkPlanListItemDescription sapMText sapMTextMaxWidth sapUiSelectable sapUiSmallMarginBegin" style="text-align:left">' +
							com.sap.cp.lm.util.Formatter.setOperationStatusTextAndColor(order.Status, order.OperationSet) + '</span></div></div>\n' +
							'<span class="sapUiHiddenPlaceholder" data-sap-ui="sap-ui-invisible-__hbox16-application-Test-url-component---turnoverDoc--TurnoverDocTree-1" style="display: none;" aria-hidden="true"></span></div></div></div></li>';

						// The bindList function is used to return a filter and sorted list of information from a ui5 model
						//START - BAJ0018 - TURNOVERDOC
						// var operationListBinding = _this._oModel.bindList(order.sPath + "/OperationSet/", undefined, _this._prepareSorters(), _this._prepareFrontEndFilters(), {
						// 	mode: sap.ui.model.BindingMode.OneTime
						// });

						// operationListBinding.aIndices.map(function (index) {
						// 	operationListBinding.oList[index].sPath = order.sPath + "/OperationSet/" + index;
						// 	return operationListBinding.oList[index];
						// }).forEach(function (operation) {
						// 	retStr +=
						// 		'<li tabindex="-1" role="treeitem" aria-level="3" class="sapMCTI sapMLIB sapMLIB-CTX sapMLIBFocusable sapMLIBShowSeparator sapMLIBTypeInactive sapMTreeItemBase sapMTreeItemBaseChildren sapMTreeItemBaseLeaf" style="padding-left:2rem">\n' +
						// 		'<span role="presentation" aria-hidden="true" data-sap-ui-icon-content="" class="sapMTreeItemBaseExpander sapUiIcon sapUiIconMirrorInRTL sapUiIconPointer" style="font-family:\'SAP-icons\'"></span>\n' +
						// 		'<div class="sapMLIBContent"><div data-sap-ui-fastnavgroup="true" role="toolbar" class="sapMIBar sapMTB sapMTB-Auto-CTX sapMTBInactive sapMTBNewFlex sapMTBStandard" style="width:100%">\n' +
						// 		'<div class="sapMBarChild sapMFlexBox sapMFlexBoxAlignContentStretch sapMFlexBoxAlignItemsStretch sapMFlexBoxBGTransparent sapMFlexBoxJustifyStart sapMFlexBoxWrapNoWrap sapMVBox sapMTBShrinkItem" style="width:100%">\n' +
						// 		'<span class="sapUiHiddenPlaceholder" style="display: none;" aria-hidden="true"></span><span class="sapUiHiddenPlaceholder" style="display: none;" aria-hidden="true"></span>\n' +
						// 		'<div class="sapMFlexBox sapMFlexBoxAlignContentStart sapMFlexBoxAlignItemsCenter sapMFlexBoxBGTransparent sapMFlexBoxJustifySpaceAround sapMFlexBoxWrapNoWrap sapMFlexItem sapMHBox">\n' +
						// 		'<div style="order:0;flex-grow:0;flex-shrink:1;flex-basis:10%;min-height:auto;min-width:auto" class="sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto">\n' +
						// 		'<span class="lmWorkPlanListItemDescription sapMText sapMTextBreakWord sapMTextMaxWidth sapUiSelectable sapUiSmallMarginEnd" style="text-align:left">' +
						// 		operation.Activity + '</span></div>\n' +
						// 		'<div style="order:0;flex-grow:1;flex-shrink:1;flex-basis:40%;min-height:auto;min-width:auto" class="sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto">\n' +
						// 		'<span class="lmWorkPlanListItemDescription sapMText sapMTextMaxWidth sapUiSelectable sapUiSmallMarginEnd" style="text-align:left">' +
						// 		operation.Descr + '</span></div>\n' +
						// 		'<div style="order:0;flex-grow:1;flex-shrink:1;flex-basis:12%;min-height:auto;min-width:auto" class="sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto">\n' +
						// 		'<span class="lmWorkPlanListItemDescription sapMText sapMTextMaxWidth sapUiSelectable sapUiSmallMarginEnd" style="text-align:left">' +
						// 		com.sap.cp.lm.util.Formatter.setOperationStatusInMyShop(operation.Status, operation.TaskSet) + '</span></div>\n' +
						// 		'<div style="order:0;flex-grow:1;flex-shrink:1;flex-basis:33%;min-height:auto;min-width:auto" class="sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto">\n' +
						// 		'<span class="sapMText sapMTextMaxWidth sapUiSelectable" style="text-align:left">' + com.sap.cp.lm.util.Formatter.setOperationAssignment(
						// 			operation.AssignmentSet) + '</span></div></div></div></div></div></li>';
						// });
						//END - BAJ0018 - TURNOVERDOC
					});
				});

				retStr += '</ul>\n' +
					'</div>';

				retStr += "</p><p style=\"page-break-after: always\">";

				retStr +=
					'<div data-sap-ui-fastnavgroup="true" class="lmFixArrowAndToolbarposition lmWorkOrderReportListItem sapMPanel sapMPanelPaddingForExpanders" style="width:100%;height:auto" role="form" aria-labelledby="__title0">\n' +
					'<div data-sap-ui="__toolbar6" data-sap-ui-fastnavgroup="true" role="toolbar" class="sapMIBar sapMPanelHeaderTB sapMTB sapMTB-Transparent-CTX sapMTBInactive sapMTBNewFlex sapMTBStandard">\n' +
					'<div data-sap-ui="__title0" role="heading" class="sapMBarChild sapMTitle sapMTitleMaxWidth sapMTitleNoWrap sapMTitleStyleAuto sapMTitleTB sapUiSelectable sapMTBShrinkItem">\n' +
					'<span >Crafts Information</span></div></div>';

				retStr +=
					'<div class="sapMPanelBGTranslucent sapMPanelContent"><div style="width: auto; height: auto; overflow: auto hidden;" class="sapMScrollCont sapMScrollContH">\n' +
					'<div class="sapMScrollContScroll"><div data-sap-ui-fastnavgroup="true" style="width:100%" class="lmTurnoverDocCraftList lmWorkPlanList lmWorkPlanListLowRes sapMList sapMListBGSolid">\n' +
					'<div id="application-Test-url-component---turnoverDoc--TurnoverCraftList-before" tabindex="-1" class="sapMListDummyArea"></div>\n' +
					'<ul role="listbox" tabindex="0" class="sapMListHighlight sapMListItems sapMListModeNone sapMListShowSeparatorsAll sapMListUl">\n';

				// The bindList function is used to return a filter and sorted list of information from a ui5 model
				var listBinding = _this._oModel.bindList("/CraftList", undefined, undefined, _this._prepareCraftsFilters(), {
					mode: sap.ui.model.BindingMode.OneTime
				});

				listBinding.aIndices.map(function (index) {
					listBinding.oList[index].sPath = "/CraftList/" + index;
					return listBinding.oList[index];
				}).forEach(function (craft) {
					retStr +=
						'<li tabindex="0" role="option" class="lmWorkPlanListItem sapMLIB sapMLIB-CTX sapMLIBFocusable sapMLIBShowSeparator sapMLIBTypeInactive sapMObjLItem sapMObjLListModeDiv" aria-posinset="1" aria-setsize="56">\n' +
						'<div class="sapMLIBContent"><div class="sapMObjLTopRow"><div class="sapMObjLNumberDiv"></div><div style="display:-webkit-box;overflow:hidden"><span class="sapMObjLTitle sapMText sapMTextMaxWidth sapUiSelectable" style="text-align:left">\n' +
						'<span class="sapMTextLineClamp sapMTextMaxLine" style="-webkit-line-clamp:2">' + craft.Name +
						'</span></span></div></div><div style="clear: both;"></div>\n' +
						'<div class="sapMObjLBottomRow">\n';

					var operationListBinding = _this._oModel.bindList(craft.sPath + "/AssignmentSet/", undefined, undefined, undefined, {
						mode: sap.ui.model.BindingMode.OneTime
					});

					operationListBinding.aIndices.map(function (index) {
						operationListBinding.oList[index].sPath = craft.sPath + "/AssignmentSet/" + index;
						return operationListBinding.oList[index];
					}).forEach(function (assignment) {
						retStr +=
							'<div class="sapMObjLAttrRow"><div class="sapMObjLAttrDiv" style="width:100%"><div data-unavailable="" class="sapMObjectAttributeDiv">\n' +
							'<span id="__text137" data-sap-ui="__text137" class="sapMText sapMTextMaxWidth sapMTextNoWrap sapUiSelectable" style="text-align:left">\n' +
							assignment.LocoId + ':' + assignment.AttributeText +
							'</span></div></div></div>';
					}.bind(this));
					retStr += '</div></div></li>';
				}.bind(this));

				retStr += '</ul></div></div></div></div>';

				return retStr;
			}

		});
});