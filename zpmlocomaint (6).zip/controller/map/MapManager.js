/* #DontDelete : Yann */
/*&----------------------------------------------------------------------*    
 * Author         : KIR0084                                              *
 * Date           : 2019.04.01                                           *
 * Incidinet      : LMP2-34 - PM Loco Main phase 2              	     *
 * Description    : Hide Dwell  										 *
 *					Add Number of Crafts					   			 *
 *					Add Train Symbol									 *
 * Search Term    : LMP2-34                                              *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : KIR0084                                              *
 * Date           : 2019.04.01                                           *
 * Incidinet      : LMP2-34 - PM Loco Main phase 2              	     *
 * Description    : Hide Dwell  										 *
 *					Add Number of Crafts					   			 *
 *					Add Train Symbol									 *
 * Search Term    : LMP2-34                                              *
 *&----------------------------------------------------------------------*/
jQuery.sap.declare("com.sap.cp.lm.controller.map.MapManager");

sap.ui.define([
		"com/sap/cp/lm/util/Constants",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator"
	],
	function(Constants, LocomotiveDataModel, Filter, FilterOperator) {
		"use strict";

		var _this;

		return com.sap.cp.lm.controller.map.MapManager = {

			/**
			 * Initialize of MapManager class
			 */
			init: function(oComponent) {
				_this = this;
				this._dragDuration = 500;
				this.clickConflict = false;
				this.isMapReady = false;
				
				/* function that can be called for any D3 element which will bring it to the front
				 * similar to using Z index in CSS
				 */
				d3.selection.prototype.bringToFront = function() {
					return this.each(function() {
						this.parentNode.appendChild(this);
					});
				};
			},

			/** Map is only rendered once depending when the user presses My Shop or My Plan
			 * In the subsequent load of the map set following appropriate values.
			 * @param oParameters The parameters object
			 *  - main object where zoom happens
			 *  - Zoom function
			 *  - Drag and Drop function
			 *  - mode ex: MyPlan or MyShop
			 *  - onLocomotivePress function
			 *  - onSpotPress function
			 *  - onMoveLocomotive function
			 *  - oContext
			 */
			setSVGMain: function(oParameters) {
				_this = this;
				//main, fZoom, fDrag, mode, onSpotPress, onLocomotivePress,onConflictPress oContext){
				this._main = oParameters.main;
				this._mode = oParameters.mode;
				this._onLocomotivePress = oParameters.onLocomotivePress;
				this._onConflictPress = oParameters.onConflictPress;
				this._onSpotPress = oParameters.onSpotPress;
				this._onMoveLocomotive = oParameters.onMoveLocomotive;
				this._oContext = oParameters.oContext;
				this._requestSpot = false;

				if (oParameters.fZoom && oParameters.fDrag) {
					this._oD3Zoom = oParameters.fZoom;
					this._oD3Drag = oParameters.fDrag;
					// zoom and drag is done on the g
					this._main.call(this._oD3Zoom);
				}
			},

			/** Draw the map for the first time
			 * @param oParameters The parameters object
			 *		globalModel : the global Model
			 *      container: the div containing the map,
			 *		svgWidth: the svg width,
			 *		svgHeight: the svg height,
			 *		parentController: the parent controller MyShop/MyPlan/RequestSpot,
			 *		requestSpot: boolean for request spot
			 * @return oDragNZoom The object containing the zoom and drag n drop functions
			 */
			drawMap: function(oParameters) {
				// console.log("drawMap");

				this._oGlobalModel = oParameters.globalModel;
				
				if (this._oGlobalModel.getProperty("/sSelectedView") !== "MyShop"
				        && this._oGlobalModel.getProperty("/sSelectedView") !== "craft") {
					return;
				}

				// get the zoom factor for the current map
				var zoomFactor = 1; //parseInt(currentShop.ShopMap.Magnification);

				// read the station map svg and append it to the current map view
				var mapSVG = this._oGlobalModel.getProperty("/shopMapSVG");

				if (!mapSVG) {
					return;
				}

				this._spots = this._oGlobalModel.getProperty("/SpotSet");
				this._tracks = this._oGlobalModel.getProperty("/TrackSet");

				this._spotWorkCenterId = this._oGlobalModel.getProperty("/SpotWorkCenterSet");

				this.oParameters = (oParameters ? oParameters : {});
				var mapContainer = this.oParameters.container;

				this._parentController = this.oParameters.parentController;

				var width = mapSVG.viewBox.baseVal.width * zoomFactor;
				var height = mapSVG.viewBox.baseVal.height * zoomFactor;
				this._mapImageWidth = mapSVG.viewBox.baseVal.width;
				this._mapImageHeight = mapSVG.viewBox.baseVal.height;
				this._requestSpot = this.oParameters.requestSpot;

				// remove any previous map within that page
				d3.select("#" + mapContainer.sId).select("svg").remove();

				// zoom and drag n drop is done on the svg to remove jumpiness
				var oDragNZoom = this.d3DragZoom(this._main);
				this._oD3Zoom = oDragNZoom.zoom;
				this._oD3Drag = oDragNZoom.drag;

				// create the <svg> and <g>
				this._main = d3.select("#" + mapContainer.sId)
					.append("svg")
					.attr("width", width)
					.attr("height", height)
					.attr("class", "lmShopSVG")
					.call(this._oD3Zoom)
					.append("g")
					.attr("id", _this._mode + "Main");

				// add an overlay rectangle to listen to zoom of the map
				this._main.append("rect")
					.attr("width", width)
					.attr("height", height)
					.attr("class", "lmMapOverlay")
					.attr("id", _this._mode + "Main" + "_Overlay");

				// adding servicing spot background pattern
				this._main.append("pattern")
					.attr({
						id: "servicing_spot",
						width: "6",
						height: "6",
						patternUnits: "userSpaceOnUse",
						patternTransform: "rotate(45)"
					})
					.append("rect")
					.attr({
						width: "2",
						height: "6",
						transform: "translate(0,0)",
						fill: "#dfdfdf"
					});

				//d3.select("#" + mapContainer.sId).select("svg")
				this._main[0][0].appendChild(mapSVG.cloneNode(true));

				// calculate the width and height of a spot
				var spot = d3.select(".gisSpot")[0][0];

				//first check if bbbox is working 
				var testBox = null;

				//check if we can reach/use getBBox()
				try {
					if(spot) {
						testBox = spot.getBBox();
					}
				} catch (e) {
					
				}

				if (!testBox) {
					this._oGlobalModel.setProperty("/needDrawMap", true);
					console.log("no bbox");
					if(spot) {
						this._locoWidth  = parseFloat(spot.getAttribute("width"));
						this._locoHeight = parseFloat(spot.getAttribute("height"));
						//console.log(this._locoWidth + " " + this._locoHeight);
					}
					return oDragNZoom;
				} else {
					//console.log(testBox);
				}

				this._oGlobalModel.setProperty("/needDrawMap", false);

				var spotBBox = spot.getBBox();

				this._locoWidth  = spotBBox.width;
				this._locoHeight = spotBBox.height;

				// add a click handler for the spots
				d3.selectAll(".gisSpot")
					.attr("id", function() {
						return _this._mode + "__" + this.id;
					})
					.attr("fill", function() {
						var sWCId = this.id.split("__")[1];
						var sSpot = _this._spots[sWCId];
						// higlight the cells thats doesnt contain the correct workcenter values for track and spot
						if (sSpot && sSpot.Track && sSpot.Spot) {
							sSpot.found = true;
							return "#ffffff";
						} else {
							return "#ffcccc";
						}
					})
					.classed("gisSpot", false)
					.classed(_this._mode + "Spot", true)
					.on("click", function() {
						if (d3.event.defaultPrevented) return;

						// add the click action for the spot
						_this._onSpotPress.apply(_this._oContext, [this.id]);
					});

				// remove all the spots that doesn't correspond in the map
				var aMissingSpots = [];

				$.each(this._spots, function(i, oSpot) {
					// check if the spot is found

					if (!oSpot.found) {
						//console.log("Spot WorkCenter code " + oSpot.Spot + " not on the map ");
						aMissingSpots.push(oSpot.Track + "-" + oSpot.Spot);
						$.each(_this._tracks[oSpot.Track].Spots, function(j, oTrackSpot) {
							if (oTrackSpot && oTrackSpot.Spot === oSpot.Spot) {
								_this._tracks[oSpot.Track].Spots.splice(j, 1);
							}
						});
						delete _this._spotWorkCenterId[oSpot.TrackSpot];
						delete _this._spots[oSpot.Spot];

					}

				});

				if (aMissingSpots.length > 0) {
					_this._parentController.showMapWarning(aMissingSpots);
				} else {
					_this._parentController.hideMapWarning();
				}

				//bring all the spots to front
				d3.selectAll(".gisSpot").bringToFront();

				//bring all the text on the map visible
				d3.selectAll("text").bringToFront();

				// hide the Track/Spot text
				var gisSpotText = d3.selectAll(".gisSpotText");
				var gisSpotTextNodes = $(gisSpotText[0]);
				gisSpotTextNodes.hide(0, function() {});

				//match map background size with locomotive scale
				d3.select(".GISMapSVG").attr("width", width);
				d3.select(".GISMapSVG").attr("height", _this._mapImageHeight);

				// show disabled spots
				this.showDisabledServicingSpots();

				// show not configured spots
				this._showNotConfiguredSpots();

				this.isMapReady = true;
				
				return oDragNZoom; //"Veracode Scan Recommendation"
			},

			/**
			 * Show/Hide disabled spots
			 */
			showDisabledServicingSpots: function() {

				this._spots = this._oGlobalModel.getProperty("/SpotSet");
				this._spotWorkCenterId = this._oGlobalModel.getProperty("/SpotWorkCenterSet");

				// show disabled spots
				$.each(this._spots, function(i, spot) {
					// check if the spot is valid
					if (d3.select("#" + _this._mode + "__" + spot.Spot)[0][0]) {
						_this.onDisableEnableSpot(spot);
						if (spot.IsSvSpot) {
							// servicing spot add the pattern background on top of the spot
							var d3Spot = d3.select("#" + _this._mode + "__" + spot.Spot)[0][0];
							if(d3Spot) { 
								var spotBBox = d3Spot.getBBox();
								_this._main.selectAll(".servicingSpot")
									.data([spot])
									.enter()
									.append("rect")
									.attr("id", function(d, i) {
										return _this._mode + "_servicingSpot_" + d.Spot;
									})
									.attr("x", function(d, i) {
										return spotBBox.x;
									})
									.attr("y", function(d, i) {
										return spotBBox.y;
									})
									.attr("width", function(d, i) {
										return spotBBox.width;
									})
									.attr("height", function(d, i) {
										return spotBBox.height;
									})
									.style("pointer-events", "none")
									.attr("fill", "url(#servicing_spot)");
							}
						}
					}
				});
			},

			/**
			 * Reset the map by removing any translate or scale values
			 */
			resetMap: function() {
				var oMapContainer = $("#" + this.oParameters.container.sId);
				if (oMapContainer) {
					oMapContainer.scrollLeft(0);
					oMapContainer.scrollTop(0);
				}
				this._oD3Zoom.scale(1);
				this._oD3Zoom.translate([0, 0]);
				this._main.transition().attr("transform", "translate(" + this._oD3Zoom.translate() + ")scale(" + this._oD3Zoom.scale() + ")");
			},

			/**
			 * Hilight filtered locomotives on map
			 * */
			filterLocomotives: function(sSearchString) {
			    // KIR0084 Add undefined check because clearing filter isnt updating map
				if(sSearchString !== undefined) {
					var s = sSearchString.toLowerCase();
	
					var locos = d3.selectAll(".lmLoco")[0];
	
					$.each(locos, function(key, loco) {
	
						var d = loco.__data__;
						var _locomotiveId = d.LocomotiveId.toLowerCase();
	
						if (_locomotiveId.indexOf(s) === -1 || sSearchString === "") {
							_this._resetDraggingHighlight(d);
						} else {
							_this._addDraggingHighlight(d3.select(loco));
						}
					});
				}
			},

			/**
			 * Remove any previously rendered Locomotives on the map
			 */
			removeLocomotives: function() {
				d3.selectAll(".lmLoco").remove();
			},

			checkConflicts: function(locomotives) {
				for (var key in _this._locomotiveHashmap) {
					if (_this._locomotiveHashmap.hasOwnProperty(key)) {
						var oLocomotive = _this._locomotiveHashmap[key];
						if (oLocomotive.PlannedTrack || oLocomotive.PlannedSpot) {
							console.log("!! conflict !! " + oLocomotive.LocomotiveId + " should be at " + oLocomotive.PlannedTrack + "/" + oLocomotive.PlannedSpot);
							_this.showConflict(oLocomotive.LocomotiveId);
						} else {
							_this.hideConflict(oLocomotive.LocomotiveId);
						}
					}
				}
			},

			hideConflict: function(sLocomotiveId) {
				var conflictRect = d3.select("#" + this._mode + "_loco_" + sLocomotiveId + "_conflict")[0][0];
				d3.select(conflictRect).classed("lmHidden", true);

				var conflictTextRect = d3.select("#" + this._mode + "_loco_" + sLocomotiveId + "_conflict_text")[0][0];
				d3.select(conflictTextRect).classed("lmHidden", true);
			},

			showConflict: function(sLocomotiveId) {
				var conflictRect = d3.select("#" + this._mode + "_loco_" + sLocomotiveId + "_conflict")[0][0];
				d3.select(conflictRect).classed("lmHidden", false);

				var conflictTextRect = d3.select("#" + this._mode + "_loco_" + sLocomotiveId + "_conflict_text")[0][0];
				d3.select(conflictTextRect).classed("lmHidden", false);
			},

			displayPlannedLocomotives: function(locomotives) {
				if (this._oGlobalModel.getProperty("/sSelectedView") !== "MyShop") {
					return;
				}

				//loop through all new locomotives
				for (var i = 0; i < locomotives.length; i++) {
					var plannedLoco = locomotives[i];
					var oLocomotive = _this._locomotiveHashmap[plannedLoco.LocomotiveId];

					//Case 1 : loco is on the yard -> move it
					if (oLocomotive) {
						//place new dest in model
						oLocomotive.TrackSpot = plannedLoco.TrackSpot;
						oLocomotive.Spot = plannedLoco.Spot;
						oLocomotive.Track = plannedLoco.Track;
						oLocomotive.PlannedTrack = plannedLoco.PlannedTrack;
						oLocomotive.PlannedSpot = plannedLoco.PlannedSpot;

						//select locomotive representation
						var locoRect = d3.select("#" + this._mode + "_loco_" + oLocomotive.LocomotiveId)[0][0];
						var destTrackSpot = oLocomotive.Track + "-" + oLocomotive.Spot;

						d3.select(locoRect).transition()
							.attr("transform", function() {
								var aSpot = d3.select("#" + _this._mode + "__" + destTrackSpot)[0][0];
								if(aSpot) {
									var spotBBox = aSpot.getBBox();
									var tx = spotBBox.x;
									var ty = spotBBox.y;
									return "translate(" + tx + "," + ty + ")";
								} else {
									return "translate(0,0)";
								}
							})
							.duration(_this._dragDuration);
							
						//Start : Added by KIR0084 : Add Number of Crafts : LMP2-34
						oLocomotive.NbrCraftAssigned = plannedLoco.NbrCraftAssigned;
						var numCraftsBg = d3.select("#" + this._mode + "_loco_" + oLocomotive.LocomotiveId + "_numcrafts")[0][0];
						var numCraftsText = d3.select("#" + this._mode + "_loco_" + oLocomotive.LocomotiveId + "_numcrafts_text")[0][0];
						
						// Update class to hide crafts assigned
						d3.select(numCraftsBg).attr("class", function(d) {
							var numCraftsNum = (+ d.NbrCraftAssigned);
							var numCraftsClass = "lmLocoNumCrafts";
							
							if (numCraftsNum === 0) {
								numCraftsClass = "lmLocoNumCraftsInvis";
							}
							return numCraftsClass;
						});
						d3.select(numCraftsText).text(function(d) {
							var numCraftsNum = (+ d.NbrCraftAssigned);
							var displayNumCrafts = numCraftsNum;
							
							if (numCraftsNum === 0) {
								displayNumCrafts = "";
							}
							return displayNumCrafts;
						});
						//End : Added by KIR0084 : Add Number of Crafts : LMP2-34

						oLocomotive.checkMove = true;
					} else {
						//Case 2 : loco is NOT on the yard -> create it
						var newlocoRect = this._main.selectAll(".loco")
							.data([plannedLoco]);

						//fill up locomotive containers with svg elements
						newlocoRect = this.locoContainersFactory(newlocoRect);

						//check locomotive presence on the yard
						plannedLoco.checkMove = true;

						//add to hash map for conflict checking
						_this._locomotiveHashmap[plannedLoco.LocomotiveId] = plannedLoco;
					}
				}

				//Case 3 : remove all loco that left the yard
				for (var key in _this._locomotiveHashmap) {
					if (_this._locomotiveHashmap.hasOwnProperty(key)) {
						var oLoco = _this._locomotiveHashmap[key];
						if (!oLoco.checkMove || oLoco.checkMove !== true) {
							d3.select("#" + _this._mode + "_loco_" + oLoco.LocomotiveId).remove();
						}
					}
				}

				_this.checkConflicts();
			},

			/** Draw the locomotives on the map
			 * @param locomotives The array of locomotives
			 */

			drawLocomotives: function(locomotives) {
				// console.log("drawLocomotives");

				if (this._oGlobalModel.getProperty("/sSelectedView") !== "MyShop") {
					// console.log("drawLocomotives cancelled");
					return;
				}
				
				//security 
				if(!this._locoWidth || this._locoWidth === 0) {
					// calculate the width and height of a spot
					var spot = d3.select(".gisSpot")[0][0];
					if(spot) {
						var spotBBox = spot.getBBox();
						this._locoWidth  = spotBBox.width;
						this._locoHeight = spotBBox.height;
					}
				}

				this.removeLocomotives();

				_this._locomotives = [];
				_this._locomotiveHashmap = {};
				var locoWithSpot = {};

				//check if there is a locomotive already present in the spot and check if the workcentercode is valid
				for (var i = 0; i < locomotives.length; i++) {
					var oRect = d3.select("#" + _this._mode + "__" + locomotives[i].TrackSpot)[0][0];
					var oSpot = this._spots[locomotives[i].TrackSpot];

					if (!oSpot || !oRect) {
						//console.log("Invalid TrackSpot code " + locomotives[i].TrackSpot + " for Locomotive " + locomotives[i].LocomotiveId);
					} else if (!locoWithSpot[locomotives[i].TrackSpot]) {
						if (!oSpot.SpotDisabled) {
							locoWithSpot[locomotives[i].TrackSpot] = locomotives[i];
							_this._locomotives.push(locomotives[i]);
							_this._locomotiveHashmap[locomotives[i].LocomotiveId] = locomotives[i];
						} else {
							//console.log("Locomotive " + locomotives[i].LocomotiveId + " in a disabled spot");
						}
					} else {
						//console.log("Locomotive " + locomotives[i].LocomotiveId + " is not shown as its placed in the same spot " + locomotives[i].TrackSpot +
						//" as Locomotive " + locoWithSpot[locomotives[i].TrackSpot].LocomotiveId);
					}
				}

				// Create all locomotive containers
				var locoRect = this._main.selectAll(".loco")
					.data(this._locomotives);

				//fill up locomotive containers with svg elements
				locoRect = this.locoContainersFactory(locoRect);

				_this.checkConflicts();
				
				for (var j = 0; j < _this._locomotives.length; j++) {
					var locomotive = _this._locomotives[j];
					var oLoco = d3.select("#" + _this._mode + "_loco_" + locomotive.LocomotiveId);

					var oLocoBkg = d3.select("#" + _this._mode + "_loco_" + locomotive.LocomotiveId + "_background");
					
					if(locomotive.ShopStatus && locomotive.ShopStatus === "R") {  
						oLocoBkg.classed("lmLocoBackground", false);
						oLocoBkg.classed("lmLocoBackgroundGreen", true);
						_this._hideProgress(oLoco);
					}
					else if(locomotive.LocoUserStatus && (locomotive.LocoUserStatus === "ISRV" || locomotive.LocoUserStatus === "DLA" || locomotive.LocoUserStatus === "ES")) {  
						oLocoBkg.classed("lmLocoBackground", false);
						if(locomotive.ShopReason === "M") {
							oLocoBkg.classed("lmLocoBackgroundOrange", false);
							oLocoBkg.classed("lmLocoBackgroundBlue", true);
						} else {
							oLocoBkg.classed("lmLocoBackgroundOrange", true);
							oLocoBkg.classed("lmLocoBackgroundBlue", false);
						}
					}
				}
			},

			locoContainersFactory: function(locoRect) {
				locoRect.enter().append("g")
					.attr("id", function(d, i) {
						return _this._mode + "_loco_" + d.LocomotiveId;
					})
					.attr("class", function(d) {
						return "lmLoco";
					})
					.attr("transform", function(d, i) {
						var aSpot = d3.select("#" + _this._mode + "__" + d.TrackSpot)[0][0];
						if(aSpot) {
							var spotBBox = aSpot.getBBox();
							var tx = spotBBox.x;
							var ty = spotBBox.y;
							return "translate(" + tx + "," + ty + ")";
						} else {
							return "translate(0,0)";
						}
					});

				// add the drag operations on the locomotive containers
				d3.selectAll(".lmLoco").call(this._oD3Drag);

				//add background color
				locoRect.append("rect")
					.attr("id", function(d, i) {
						return _this._mode + "_loco_" + d.LocomotiveId + "_background";
					})
					.attr("class", "lmLocoBackground")
					.attr("x", function(d, i) {
						d.x = 0;
						return d.x;
					})
					.attr("y", function(d, i) {
						d.y = 0;
						return d.y;
					})
					.attr("width", function(d, i) {
						d.width = _this._locoWidth;
						return d.width;
					})
					.attr("height", function(d, i) {
						d.height = _this._locoHeight;
						return d.height;
					});

				//add locomotive ID label
				locoRect.append("text")
					.attr("id", function(d, i) {
						return _this._mode + "_loco_" + d.LocomotiveId + "_text";
					})
					.attr("class", "lmLocoTitle")
					.attr("dx", function(d, i) {
						return 4;
					})
					.attr("dy", function(d, i) {
						var dy = _this._locoHeight / 2; 
						
						// Service Groups must cause the train name to move up
						if (d.SrvcGrpDescr !== "") {
							dy -= 4;
						}
						
						return dy;
					})
					.text(function(d) {
						return d.LocomotiveId;
					});

				//Start : Added by KIR0084 : Display Servicing Group
				//display service group description
				locoRect.append("text")
					.attr("id", function(d, i) {
						return _this._mode + "_loco_" + d.LocomotiveId + "_srvcgrp";
					})
					.attr("class", "lmLocoTextSmall")
					.attr("dx", function(d, i) {
						return 4;
					})
					.attr("dy", function(d, i) {
						return 22;
					})
					.text(function(d) {
						return d.SrvcGrpDescr;
					});
				//End : Added by KIR0084 : Display Servicing Group

				//Start : Added by KIR0084 : Hide Dwell : LMP2-34
				//add locomotive Dwell label
				// locoRect.append("text")
				// 	.attr("id", function(d, i) {
				// 		return _this._mode + "_loco_" + d.LocomotiveId + "_dwell";
				// 	})
				// 	.attr("class", "lmLocoTitle")
				// 	.attr("dx", function(d, i) {
				// 		return 4;
				// 	})
				// 	.attr("dy", function(d, i) {
				// 		return 20;
				// 	})
				// 	.text(function(d) {
				// 		return d.DwellHrs+"h";
				// 	});
				//End : Added by KIR0084 : Hide Dwell : LMP2-34
					
				//add progress bar
				var locoProgressHeight = _this._locoHeight * 0.2;

				//progress bar background
				locoRect.append("rect")
					.attr("id", function(d, i) {
						return _this._mode + "_loco_" + d.LocomotiveId + "_progress_container";
					})
					.attr("class", "lmLocoProgressBackground")
					.attr("x", function(d, i) {
						return 0;
					})
					.attr("y", function(d, i) {
						return _this._locoHeight - locoProgressHeight;
					})
					.attr("width", function(d, i) {
						return _this._locoWidth;
					})
					.attr("height", function(d, i) {
						return locoProgressHeight;
					});

				//progress bar status
				locoRect.append("rect")
					.attr("id", function(d, i) {
						return _this._mode + "_loco_" + d.LocomotiveId + "_progress";
					})
					.attr("class", "lmLocoProgress")
					.attr("x", function(d, i) {
						return 0;
					})
					.attr("y", function(d, i) {
						return _this._locoHeight - locoProgressHeight;
					})
					.attr("width", function(d, i) {
						var progressWidth = 0;

						if (d.PlannedHrs > 0) {
							progressWidth = d.CompletedHrs / d.PlannedHrs;
						}

						return _this._locoWidth * progressWidth;
					})
					.attr("height", function(d, i) {
						return locoProgressHeight;
					});

				// adding the direction background
				var directionSize = 12;

				locoRect.append("rect")
					.attr("id", function(d, i) {
						return _this._mode + "_loco_" + d.LocomotiveId + "_direction";
					})
					.attr("class", "lmLocoDirection ")
					.attr("x", function(d, i) {
						return d.width - directionSize;
						//return 0 - directionSize;
					})
					.attr("y", function(d, i) {
						return 0;
					})
					.attr("width", function(d, i) {
						return directionSize;
					})
					.attr("height", function(d, i) {
						return directionSize;
					});

				// adding the direction text
				locoRect.append("text")
					.attr("id", function(d, i) {
						return _this._mode + "_loco_" + d.LocomotiveId + "_direction_text";
					})
					.attr("class", "lmLocoDirectionText")
					.attr("dx", function(d, i) {
						return d.width - directionSize / 2;
						//return 0 - directionSize / 2;
					})
					.attr("dy", function(d, i) {
						return directionSize / 2 + 2;
					})
					.attr("text-anchor", "middle")
					.text(function(d) {
						var direction = d.Direction;
						return direction;
					});
					
				//Start : Added by KIR0084 : Add Number of Crafts : LMP2-34
				// adding number of crafts background
				locoRect.append("rect")
					.attr("id", function(d, i) {
						return _this._mode + "_loco_" + d.LocomotiveId + "_numcrafts";
					})
					.attr("class", function(d) {
						var numCraftsNum = (+ d.NbrCraftAssigned);
						var numCraftsClass = "lmLocoNumCrafts";
						
						if (numCraftsNum === 0) {
							numCraftsClass = "lmLocoNumCraftsInvis";
						}
						return numCraftsClass;
					})
					.attr("x", function(d, i) {
						return d.width - directionSize;
					})
					.attr("y", function(d, i) {
						return d.height - directionSize - 7;
					})
					.attr("width", function(d, i) {
						return directionSize;
					})
					.attr("height", function(d, i) {
						return directionSize;
					});

				// adding the number of crafts text
				locoRect.append("text")
					.attr("id", function(d, i) {
						return _this._mode + "_loco_" + d.LocomotiveId + "_numcrafts_text";
					})
					.attr("class", "lmLocoNumCraftsText")
					.attr("dx", function(d, i) {
						return d.width - directionSize / 2;
					})
					.attr("dy", function(d, i) {
						return d.height - (directionSize / 2) - 4;
					})
					.attr("text-anchor", "middle")
					.text(function(d) {
						var numCraftsNum = (+ d.NbrCraftAssigned);
						var displayNumCrafts = numCraftsNum;
						
						if (numCraftsNum === 0) {
							displayNumCrafts = "";
						}
						return displayNumCrafts;
					});
				//End : Added by KIR0084 : Add Number of Crafts : LMP2-34

				//add conflict marker

				locoRect.append("rect")
					.attr("id", function(d, i) {
						return _this._mode + "_loco_" + d.LocomotiveId + "_conflict";
					})
					.attr("class", "lmLocoConflict ")
					.attr("x", function(d, i) {
						return d.width - directionSize;
					})
					.attr("y", function(d, i) {
						return 0;
					})
					.attr("width", function(d, i) {
						return directionSize;
					})
					.attr("height", function(d, i) {
						return directionSize;
					})
					.on("click", function(d, i) {
						_this.clickConflict = true;

						if (d3.event.defaultPrevented) return;

						if (_this._onConflictPress) {
							_this._onConflictPress.apply(_this._oContext, [d]);
						}
					});

				// adding the direction text
				locoRect.append("text")
					.attr("id", function(d, i) {
						return _this._mode + "_loco_" + d.LocomotiveId + "_conflict_text";
					})
					.attr("class", "lmLocoConflictText")
					.attr("dx", function(d, i) {
						return d.width - directionSize / 2;
					})
					.attr("dy", function(d, i) {
						return directionSize / 2 + 2;
					})
					.attr("text-anchor", "middle")
					.text("!");

				//return completed locomotives
				return locoRect;
			},

			didDragEnough: function() {
				var startPoint = this._dragtStartPoint;
				var endPoint = this._dragtEndPoint;

				var threshold = 5;

				var xMove = Math.max(startPoint[0], endPoint[0]) - Math.min(startPoint[0], endPoint[0]);
				var yMove = Math.max(startPoint[1], endPoint[1]) - Math.min(startPoint[1], endPoint[1]);

				if (xMove >= threshold || yMove >= threshold) {
					return true;
				}

				return false;
			},

			/** Click event handler for the locomotive
			 * @param oLocomotive The object containing locomotive information
			 */
			onLocomotivePress: function(oLocomotive) {

				if (this.didDragEnough() === true) {
					return;
				}

				if (_this.clickConflict === true) {
					//let clickConflict callback run
					_this.clickConflict = false;
				} else {
					// call the onLocomotivePress callback
					if (_this._onLocomotivePress && _this._oContext) {
						_this._onLocomotivePress.apply(_this._oContext, [oLocomotive]);
					}
				}
			},

			/** Drag n Drop and Zoom for svg
			 * @param main The immediate child <g> node of the <svg>
			 * @param locoWidth The width of the locomotive
			 * @param locoHeight The height of the locomotive
			 * @return oDragNZoom The object containing the zoom and drag n drop functions
			 */
			d3DragZoom: function(main) {

				this._main = main;

				// zoom functionality
				this._oD3Zoom = d3.behavior.zoom().scaleExtent([0.5, 1.5]).on("zoom",
					function() {
						_this._zoomed();
					});

				// drag n drop functionality
				this._oD3Drag = d3.behavior.drag().origin(function() {
					return _this._dragOrigin(this);
				}).on("dragstart", function() {
					_this._dragStarted(this);
				}).on("drag", function(d) {
					_this._dragged(this);
				}).on("dragend", function() {
					_this._dragEnded(this);
				});

				return {
					zoom: this._oD3Zoom,
					drag: this._oD3Drag
				};
			},

			/** Drag origin event handler for D3.js
			 * @param d The locomotive object
			 * @return coordinates The X and Y coordinates
			 */
			_dragOrigin: function(d) {
				return {
					x: d3.select(d).attr("x"),
					y: d3.select(d).attr("y")
				};
			},

			/** Drag started event handler for D3.js
			 * Adds the border around the locomotive background rectangle
			 * @param d The locomotive object
			 * @return coordinates The X and Y coordinates
			 */
			_dragStarted: function(oObj) {
				var d = oObj.__data__;
				d3.event.sourceEvent.stopPropagation();
				var locoRect = d3.select("#" + this._mode + "_loco_" + d.LocomotiveId)[0][0];

				var transform = locoRect.attributes.transform.value;
				var t = this.getTranslation(transform);
				this._dragtStartPoint = t;

				d3.select(locoRect).classed("lmDragging", true);
				this._addDraggingHighlight(d3.select(locoRect));
				d3.select(locoRect).bringToFront();

				_this.locomotiveDeltaPosition = {
					"locomotive": d
				};

			},

			getTranslation: function(transform) {
				// Create a dummy g for calculation purposes only. This will never
				// be appended to the DOM and will be discarded once this function 
				// returns.
				var g = document.createElementNS("http://www.w3.org/2000/svg", "g");

				// Set the transform attribute to the provided string value.
				g.setAttributeNS(null, "transform", transform);

				// consolidate the SVGTransformList containing all transformations
				// to a single SVGTransform of type SVG_TRANSFORM_MATRIX and get
				// its SVGMatrix. 
				var matrix = g.transform.baseVal.consolidate().matrix;

				// As per definition values e and f are the ones for the translation.
				return [matrix.e, matrix.f];
			},

			/** Dragged event handler for D3.js
			 * Drag all the elements related to locomotive
			 * @param locoRect The locomotive graphic object
			 */
			_dragged: function(locoRect) {

				if (_this._parentController.canDrag() === false) {
					return;
				}

				//limit the dragging of rectangles within the boundary of the SVG
				//d3.event.x = Math.max(0, Math.min(svg.getBoundingClientRect().width, d3.event.x));
				//d3.event.y = Math.max(0, Math.min(svg.getBoundingClientRect().height-(this._locoHeight), d3.event.y));

				//deselect all spots
				d3.selectAll("." + _this._mode + "Spot").classed("lmSpotDetected", false);

				//get drag translation
				var transform = locoRect.attributes.transform.value;
				var t = this.getTranslation(transform);
				var tx = d3.event.dx + t[0];
				var ty = d3.event.dy + t[1];

				//apply dragging the loco rectangle
				d3.select(locoRect).attr("transform", "translate(" + tx + "," + ty + ")");

				//check what lies beneath the locomotive as it's been dragged around
				var locoCenter = _this._getCenter(locoRect);
				var dropSpot = _this._detectSpot(locoCenter);

				//highlight the spot
				if (dropSpot) {
					var spot = d3.select("#" + dropSpot)[0][0];
					d3.select(spot).classed("lmSpotDetected", true);
				}

				/* handle scroll map by dragging loco towards the borders */

				var mapContainer = $(".lmMapContainerPosition");

				var fZoomScale = this._oD3Zoom.scale();
				var iMoveDistance = 20;
				var iXEdgeDistance = (this._locoWidth * fZoomScale);
				var iYEdgeDistance = (this._locoHeight * fZoomScale);

				var w = mapContainer.width();
				var h = mapContainer.height();

				// Dragging X Direction
				if (tx + iXEdgeDistance - (Math.abs(_this._oD3Zoom.translate()[0]) / fZoomScale) > w / fZoomScale) {
					_this._oD3Zoom.translate([_this._oD3Zoom.translate()[0] - iMoveDistance, _this._oD3Zoom.translate()[1]]);
				} else if (-tx + iXEdgeDistance > _this._oD3Zoom.translate()[0] / fZoomScale) {
					_this._oD3Zoom.translate([_this._oD3Zoom.translate()[0] + iMoveDistance, _this._oD3Zoom.translate()[1]]);
				}

				// Dragging Y Direction
				if (ty + iYEdgeDistance - (Math.abs(_this._oD3Zoom.translate()[1]) / fZoomScale) >= h / fZoomScale) {
					_this._oD3Zoom.translate([_this._oD3Zoom.translate()[0], _this._oD3Zoom.translate()[1] - iMoveDistance]);
				} else if (-ty + iYEdgeDistance > _this._oD3Zoom.translate()[1] / fZoomScale) {
					_this._oD3Zoom.translate([_this._oD3Zoom.translate()[0], _this._oD3Zoom.translate()[1] + iMoveDistance]);
				}

				_this._zoomed();
			},

			_getCenter: function(locoRect) {
				var transform = locoRect.attributes.transform.value;
				var t = this.getTranslation(transform);
				return [t[0] + (_this._locoWidth) / 2, t[1] + (_this._locoHeight) / 2];
			},

			_resetHighlight: function(d, highlight) {
				d3.select("#" + _this._mode + "_loco_" + d.LocomotiveId + "_" + highlight).remove();
			},

			_addHighlight: function(locoRect, highlight) {
				
				var sClass = "lmLoco" + highlight;
				
				locoRect.append("rect")
					.attr("id", function(d, i) {
						return _this._mode + "_loco_" + d.LocomotiveId + "_" + highlight;
					})
					.attr("class", sClass)
					.attr("x", function(d, i) {
						d.x = 0;
						return d.x;
					})
					.attr("y", function(d, i) {
						d.y = 0;
						return d.y;
					})
					.attr("width", function(d, i) {
						d.width = _this._locoWidth;
						return d.width;
					})
					.attr("height", function(d, i) {
						d.height = _this._locoHeight;
						return d.height;
					});

			},
			
			_resetDraggingHighlight: function(d) {
				_this._resetHighlight(d,"Dragging");
			},

			_addDraggingHighlight: function(locoRect) {
				_this._addHighlight(locoRect,"Dragging");
			},

			_resetReleasedHighlight: function(d) {
				_this._resetHighlight(d,"Released");
			},

			_addReleasedHighlight: function(locoRect) {
				_this._addHighlight(locoRect,"Released");
				_this._hideProgress(locoRect);
			},
			
			_addServicedHighlight: function(locoRect) {
				_this._addHighlight(locoRect,"Serviced");
				_this._hideProgress(locoRect);
			},

			_resetServicedHighlight: function(d) {
				_this._resetHighlight(d,"Serviced");
			},
			
			_hideProgress:function(locoRect) {
				var LocomotiveId = locoRect[0][0].__data__.LocomotiveId;
				d3.select("#" + _this._mode + "_loco_" + LocomotiveId + "_progress_container").remove();
				d3.select("#" + _this._mode + "_loco_" + LocomotiveId + "_progress").remove();
			},
			/**
			 * Move the locomotive and all the associated elements
			 * @param oLocomotive	The locomotive object
			 * @param dropSpot		The spot object where the drop happens
			 */

			_moveLoco: function(oLocomotive, dropSpot) {

				//select locomotive representation
				var locoRect = d3.select("#" + this._mode + "_loco_" + oLocomotive.LocomotiveId)[0][0];

				//by default prepare for walk back
				var destTrackSpot = oLocomotive.Track + "-" + oLocomotive.Spot;

				//if there is a valid dropspot move the loco to it
				if (dropSpot !== null) {
					//console.log("updating to dropSpot");
					var spotId = dropSpot.split("__")[1];
					destTrackSpot = spotId;

					// update the new track and spot within the model
					for (var i = 0; i < _this._locomotives.length; i++) {
						var locomotive = _this._locomotives[i];
						if (locomotive.LocomotiveId === oLocomotive.LocomotiveId) {
							//console.log(locomotive.LocomotiveId + " updated to " + spotId);
							locomotive.TrackSpot = spotId;
							var spot = this._spots[spotId];
							//console.log(spot);
							locomotive.TrackSpot = spot.TrackSpot;
							locomotive.Spot = spot.Spot;
							locomotive.Track = spot.Track;

							if (locomotive.PlannedTrack === locomotive.Track && locomotive.PlannedSpot === locomotive.Spot) {
								locomotive.PlannedTrack = null;
								locomotive.PlannedSpot = null;
							}

							_this._locomotiveHashmap[oLocomotive.LocomotiveId] = locomotive;

							break;
						}
					}
				}

				//animate the end of the drag/drop
				d3.select(locoRect).transition()
					.attr("transform", function() {
						var aSpot = d3.select("#" + _this._mode + "__" + destTrackSpot)[0][0];
						if(aSpot) {
							var spotBBox = aSpot.getBBox();
							var tx = spotBBox.x;
							var ty = spotBBox.y;
							return "translate(" + tx + "," + ty + ")";
						} else {
							return "translate(0,0)";
						}
					})
					.duration(_this._dragDuration)
					.each("end", function() {
						//reset locomotive visual state
						_this._resetDraggingHighlight(oLocomotive);
						d3.select(locoRect).classed("lmDragging", false);
						d3.select(".lmSpotDetected").classed("lmSpotDetected", false);

						_this.checkConflicts();
					});

			},

			/**
			 * Error while moving the Locmotive to new spot
			 */
			onDragError: function() {
				//console.log("onDragError");

				//animate back to the origin
				var oLocomotive = _this.locomotiveDeltaPosition.locomotive;
				if (oLocomotive) {
					//console.log("walk back");
					_this._moveLoco(oLocomotive, null);
				}

				// fetch the locomotives again as the data you see might be outdated
				_this._parentController.refreshLocomotives();
			},

			/**
			 * Successful move locomotive from one spot to another
			 */
			onDragSuccess: function(oData) {
				//console.log("onDragSuccess");

				var oLocomotive = _this.locomotiveDeltaPosition.locomotive;
				if (oLocomotive) {
					_this._moveLoco(oLocomotive, _this.locomotiveDeltaPosition.dropSpot);
				}

				if (this._oContext) {
					this._oContext.getView().setBusy(false);
				}
			},

			/** Drag end event handler for D3.js
			 * Locomotive drag end check if its dropped into a valid spot
			 * @param d The locomotive object
			 */
			_dragEnded: function(oObj) {
				
				var d = oObj.__data__;
				
				var locoRect = d3.select("#" + this._mode + "_loco_" + d.LocomotiveId)[0][0];

				var transform = locoRect.attributes.transform.value;
				var t = this.getTranslation(transform);
				this._dragtEndPoint = t;

				setTimeout(function() {
					_this.onLocomotivePress(d);
				}, 100);

				//check what lies beneath the locomotive for dropping
				var locoCenter = _this._getCenter(locoRect);
				var dropSpot = _this._detectSpot(locoCenter);

				//check drop is accepted
				if (dropSpot) {
					_this._updateLocomotivePosition(d, dropSpot);
				} else {
					//back to the origin
					_this._moveLoco(d, null);
				}
			},

			_updateLocomotivePosition: function(oLocomotive, dropSpot) {
				//console.log("_updateLocomotivePosition");
				var sShopId = this._oGlobalModel.getProperty("/currentShop").Id;
				var newTrackSpot = dropSpot.split("__")[1];
				var aChunks = newTrackSpot.split("-");
				var sToTrack = aChunks[0];
				var sToSpot = aChunks[1];

				//check if the locomotive will actually moved from it's old position
				if (oLocomotive.Track === sToTrack && oLocomotive.Spot === sToSpot) {
					_this._moveLoco(oLocomotive, null);
					return;
				}

				//prepare payload for the call to service	
				var oPayload = {
					"ShopId": sShopId,
					"LocoId": oLocomotive.LocomotiveId,
					"ToTrack": sToTrack,
					"ToSpot": sToSpot,
					"ToDirection": oLocomotive.Direction
				};

				//store old state in case service return a no go for the update
				_this.locomotiveDeltaPosition = {
					"locomotive": oLocomotive,
					"dropSpot": dropSpot
				};

				//call service from view controller
				if (_this._onMoveLocomotive && _this._oContext) {
					_this._onMoveLocomotive.apply(_this._oContext, [oLocomotive, oPayload, _this.onDragSuccess, _this.onDragError]);
				}
			},

			/** Zoom event handler for D3.js
			 * zooming the main <g> node of the svg
			 */
			_zoomed: function() {
				var fZoomScale = this._oD3Zoom.scale();
				var svg = $(".lmShopSVG");

				// limit the map drag to the size of the actual svg
				if (this._oD3Zoom.translate()[0] >= 0) {
					this._oD3Zoom.translate([0, this._oD3Zoom.translate()[1]]);
				} else if (this._oD3Zoom.translate()[0] < -svg.width() * fZoomScale + $(".lmMapContainerPosition").width()) {
					this._oD3Zoom.translate([-svg.width() * fZoomScale + $(".lmMapContainerPosition").width(), this._oD3Zoom.translate()[1]]);
				}

				var iMaxHeight = svg.height() < $(".lmMapContainerPosition").height() ? svg.height() : $(".lmMapContainerPosition").height();
				if (this._oD3Zoom.translate()[1] >= 0) {
					this._oD3Zoom.translate([this._oD3Zoom.translate()[0], 0]);
				} else if (this._oD3Zoom.translate()[1] < -svg.height() * fZoomScale + iMaxHeight) {
					this._oD3Zoom.translate([this._oD3Zoom.translate()[0], -svg.height() * fZoomScale + iMaxHeight]);
				}

				this._main.attr("transform", "translate(" + this._oD3Zoom.translate() + ")scale(" + this._oD3Zoom.scale() + ")");
			},

			/** Calculate if the point is inside the rect
			 * @param point The x and y coordinates of the centroid of the locomotive
			 * @param rect The rectangle node to be compared for
			 * @return boolean true/false
			 */
			_pointInside: function(point, rect) {
				var x = point[0];
				var y = point[1];

				if(rect) {
					var rectBBox = rect.getBBox();
					var left = rectBBox.x;
					var bottom = rectBBox.y;
					var right = rectBBox.x + rectBBox.width;
					var top = rectBBox.y + rectBBox.height;
	
					if ((x >= left && x <= right) && (y >= bottom && y <= top)) {
						return true;
					}
				}
				return false;
			},

			/** Check to see if the position belong to a spot
			 * @param oPoint The x and y coordinates of the point to check
			 * @return dropSpot The spot object
			 */
			_detectSpot: function(point) {
				var dropSpot = null;
				var spots = d3.selectAll("." + _this._mode + "Spot")[0];

				$.each(spots, function(key, rect) {
					var inside = _this._pointInside(point, rect);
					if (inside) {
						// if the spot is disabled cannot drop a locomotive
						var WorkCenterCode = rect.id.split("__")[1];

						// check if a locomotive is already there
						var locoExist = d3.select("#" + _this._mode + "_loco_" + WorkCenterCode)[0][0];
						if (!locoExist) {
							var workCenter = _this._spots[WorkCenterCode];
							if (workCenter) {
								dropSpot = workCenter.SpotDisabled === true ? null : rect.id;
							} else {
								console.log("Error while retrieving Spot " + WorkCenterCode);
							}
						}
						return false;
					}
				});

				return dropSpot;
			},

			_showNotConfiguredSpots: function() {
				//console.log("_showNotConfiguredSpots");

				var spots = d3.selectAll("." + _this._mode + "Spot")[0];
				var _notConfig = [];

				$.each(spots, function(key, rect) {
					var TrackSpot = rect.id.split("__")[1];

					var workCenter = _this._spots[TrackSpot];

					if (!workCenter) {
						_notConfig.push(rect);
					}
				});

				// Create all containers
				var spotRect = this._main.selectAll(".noConfig")
					.data(_notConfig);

				spotRect.enter().append("g")
					.attr("id", function(d, i) {
						var TrackSpot = d.id.split("__")[1];
						return _this._mode + "_spotNotConfigured_" + TrackSpot;
					})
					.attr("class", function(d) {
						return "lmNotConfigured";
					})
					.attr("transform", function(d, i) {
						var TrackSpot = d.id.split("__")[1];
						var aSpot = d3.select("#" + _this._mode + "__" + TrackSpot)[0][0];
						if(aSpot) {
							var spotBBox = aSpot.getBBox();
							var tx = spotBBox.x;
							var ty = spotBBox.y;
							return "translate(" + tx + "," + ty + ")";
						} else {
							return "translate(0,0)";
						}
					});

				spotRect.append("rect")
					.attr("id", function(d, i) {
						var TrackSpot = d.id.split("__")[1];
						return _this._mode + "_notConfiguedSpot_" + TrackSpot;
					})
					.attr("class", "lmNotConfigBkg");

				spotRect.append("text")
					.attr("id", function(d, i) {
						var TrackSpot = d.id.split("__")[1];
						return _this._mode + "_notConfiguedSpotTitle_" + TrackSpot;
					})
					.attr("class", "lmNotConfigTitle")
					.attr("dx", function(d, i) {
						return 4;
					})
					.attr("dy", function(d, i) {
						return 8;
					})
					.text(function(d) {
						var TrackSpot = d.id.split("__")[1];
						return TrackSpot;
					});

				spotRect.append("text")
					.attr("id", function(d, i) {
						var TrackSpot = d.id.split("__")[1];
						return _this._mode + "_notConfiguedSpotText_" + TrackSpot;
					})
					.attr("class", "lmNotConfigText")
					.attr("dx", function(d, i) {
						return 1;
					})
					.attr("dy", function(d, i) {
						return 16;
					})
					.text(function(d) {
						return "not configured";
					});

			},

			/** Disable a spot on the map
			 * @param spot The spot object
			 */
			disableSpot: function(spot) {
				var d3Spot = d3.select("#" + _this._mode + "__" + spot.Spot)[0][0];
				if(d3Spot) {
					var spotBBox = d3Spot.getBBox();
					this._main.selectAll(".disabled")
						.data([spot])
						.enter()
						.append("rect")
						.attr("id", function(d, i) {
							return _this._mode + "_disabled_" + d.Spot;
						})
						.attr("x", function(d, i) {
							return spotBBox.x;
						})
						.attr("y", function(d, i) {
							return spotBBox.y;
						})
						.attr("width", function(d, i) {
							return _this._locoWidth;
						})
						.attr("height", function(d, i) {
							return _this._locoHeight;
						})
						.attr("class", "lmDisabled")
						.attr("fill", "url(#servicing_spot)");
				} else {
					return "translate(0,0)";
				}
			},

			/**
			 * return locoRect size status
			 */
			isLocoSizeSet:function() {
				if(!this._locoWidth || this._locoWidth === 0 || !this._locoHeight || this._locoHeight === 0) {
					return false;
				}
				return true;
			},
			
			/**
			 * To reset all the spots according to its SpotDisabled field
			 */
			resetSpots: function() {
				// show/hide disabled spots
				$.each(this._spots, function(i, spot) {
					// check if the spot is valid
					if (d3.select("#" + _this._mode + "__" + spot.Spot)[0][0])
						_this.onDisableEnableSpot(spot);
				});
			},

			/** Enable/Disable Spot
			 */
			onDisableEnableSpot: function(oSpot) {
				// check if the spot is disabled
				if (oSpot.SpotDisabled) {
					_this.disableSpot(oSpot);
				} else {
					d3.select("#" + _this._mode + "_disabled_" + oSpot.Spot).remove();
				}
			},

			/**
			 * Show/Hide Spot with its track and spot number
			 * */
			toggleSpotText: function(show) {
				var spotText = d3.selectAll(".gisSpotText");
				var $spotTextNodes = $(spotText[0]);
				if (show) {
					//show track spot info
					$spotTextNodes.show(this._dragDuration);
				} else {
					//hide track spot info
					$spotTextNodes.hide(this._dragDuration);
				}
			}
		};
	});