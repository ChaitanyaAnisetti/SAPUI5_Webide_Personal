/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.21                                           *
* Project        : Locomotive Maintenance                               *
* Description    : Controller for Details Overview that displays all    *
*                  work orders and tasks on a table.                    *
*&----------------------------------------------------------------------*/

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
	"com/sap/cp/lm/controller/common/PrintManager"

], function(Controller, Constants, Formatter, BusyIndicator, LocomotiveDataModel, PrintManager) {
	"use strict";

	var _this;

	return Controller.extend(
		"com.sap.cp.lm.controller.map.detailOverview.DetailOverview", {
			
			//--------------------------------------------------------------------
			// Life cycle functions
			//--------------------------------------------------------------------
			
			/**
			 * Initializes the controller
			 */
			onInit: function() {
				_this = this;

				$(window).on('resize', $.proxy(this.handleWindowResize, this));

				this._oModel = new sap.ui.model.json.JSONModel();
				this.getView().setModel(this._oModel);

				this._oViewPropertiesModel = new sap.ui.model.json.JSONModel();
				this._initViewPropertiesModel();

				this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
				this._oGlobalModel.setProperty("/viewSpacers", this._oViewPropertiesModel.getData());

				this._bExpandAll = false;

				this._shopId = "";

				this.oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());
				this.oRouter.getTargets().attachDisplay(function(oEvent) {
					if (oEvent.getParameter("name") === "detailOverview") {
						_this._onDetailOverviewRouteMatched();
					}
				});

				// register to listen to change events of the globalmodel which contain the currentShop
				var binding = new sap.ui.model.Binding(this._oGlobalModel, "/", this._oGlobalModel.getContext("/"));
				binding.attachChange(function() {
					_this.onGlobalModelChange();
				});
			},
			
			//--------------------------------------------------------------------
			// Private functions
			//--------------------------------------------------------------------
			
			/**
			 * Create the view properties model for this view. 
			 */
			_initViewPropertiesModel: function(bValue) {
				this._oViewPropertiesModel.setProperty("/HideComplete", true);

				this._oViewPropertiesModel.setProperty("/OperationNumber", {
					visible: false,
					width: "6%"
				});
				this._oViewPropertiesModel.setProperty("/Operation", {
					visible: true,
					width: "30%"
				});
				this._oViewPropertiesModel.setProperty("/TaskCount", {
					visible: true,
					width: "7%"
				});
				this._oViewPropertiesModel.setProperty("/PlannedStart", {
					visible: true,
					width: "7%"
				});
				this._oViewPropertiesModel.setProperty("/Spot", {
					visible: true,
					width: "7%"
				});
				this._oViewPropertiesModel.setProperty("/Workers", {
					visible: true,
					width: "7%"
				});
				this._oViewPropertiesModel.setProperty("/EstimatedTime", {
					visible: true,
					width: "11%"
				});
				this._oViewPropertiesModel.setProperty("/Materials", {
					visible: true,
					width: "9%"
				});
    			this._oViewPropertiesModel.setProperty("/CompletedBy", {
    				visible: true,
    				width: "8%"
    			});
    			this._oViewPropertiesModel.setProperty("/ConfirmedBy", {
    				visible: true,
    				width: "8%"
    			});
				this._oViewPropertiesModel.setProperty("/Status", {
					visible: true,
					width: "11%"
				});
			},
			
			refreshList: function() {
				var tempCurrentShop = this._oGlobalModel.getProperty("/currentShop");

				// check if the currentShop is different and if so reload
				if (tempCurrentShop && tempCurrentShop.Id !== this._shopId) {
					// the initial load of the application window.height is incorrect at onAfterRendering and calculating the height later
					this.handleWindowResize();
					this._shopId = tempCurrentShop.Id;

					this._fetchTurnoutReport();
				}

				this.refreshExpandToggle();
			},
			
			/**
			 * Reading the locomotives
			 */
			_fetchTurnoutReport: function() {
				this._aShoppedLocomotives = [];
				this._oGlobalLocomotiveModel = this.getOwnerComponent().getGlobalLocomotiveModel();
				$.each(this._oGlobalLocomotiveModel.oData.Shopped, function(i, loco) {
					if (loco.Track && loco.Spot && loco.Track !== "" && loco.Spot !== "") {
						loco.TrackSpot = loco.Track + "-" + loco.Spot;
						_this._aShoppedLocomotives.push(loco);
					}
				});

				if (this._aShoppedLocomotives) {
					_this._oModel.setProperty("/Shopped", this._aShoppedLocomotives);
				}

				LocomotiveDataModel.fetchTurnoutReport(this._aShoppedLocomotives, this._fetchTurnoutReportSuccess, this._fetchTurnoutReportFailure,
					this);
			},
			
			_fetchTurnoutReportSuccess: function(oData) {
				$.each(this._aShoppedLocomotives, function(i, oLocomotive) {
					var sEquipNo = oLocomotive.Equipment;
					if(!sEquipNo) {
						sEquipNo = oLocomotive.EquipNo;
					}
					var eqNb = Formatter.removeLeadingZeroes(sEquipNo);
					_this._aShoppedLocomotives[i] = oData[eqNb];
				});

				_this._oModel.setProperty("/Shopped", this._aShoppedLocomotives);
			},

			_fetchTurnoutReportFailure: function(aErrorResponses) {

			},
			
			toggleComplete: function() {
				var aListItem = $('.lmDetailsList');
				for (var i = 0; i < aListItem.length; i++) {
					var oListItem = sap.ui.getCore().byId(aListItem[i].id);
					if (oListItem) {
						var sPath = oListItem.getBindingContext().getPath();
						var oLocomotive = oListItem.getModel().getProperty(sPath);
						var bHide = false;
						
						if (!oLocomotive.WorkOrders) {
							bHide = true;
						} else {
							var checksum = 0;
							for (var j = 0; j < oLocomotive.WorkOrders.length; j++) {
								var oWO = oLocomotive.WorkOrders[j];
								var sStatus = oWO.Status;
								if (sStatus) {
									if (sStatus === Constants.STATUS_COMPLETED) {
										checksum += 1;
									}
								}
							}
							
							if(checksum === oLocomotive.WorkOrders.length) {
								bHide = true;
							}
						}
						
						if(bHide === true) {
							if (this._bHideComplete) {
								oListItem.addStyleClass("lmHidden");
							} else {
								oListItem.removeStyleClass("lmHidden");
							}	
						}
					}
				}
			},

			refreshCompleteToggle: function() {
				if (!this._bHideComplete) {
					this.byId("DetailOverviewToggleCompleteButton").setText("Hide Complete");
				} else {
					this.byId("DetailOverviewToggleCompleteButton").setText("Show All");
				}
			},
			
			refreshExpandToggle: function() {
				if (!this._bExpandAll) {
					this.byId("DetailOverviewToggleExpandButton").setText("Expand All");
				} else {
					this.byId("DetailOverviewToggleExpandButton").setText("Close All");
				}
			},

			togglePanels: function() {
				var aPanels = $('.sapMPanel');
				for (var i = 0; i < aPanels.length; i++) {
					var oPanel = sap.ui.getCore().byId(aPanels[i].id);
					if (oPanel) {
						oPanel.setExpanded(this._bExpandAll);
					}
				}
			},
			
			//--------------------------------------------------------------------
			// Event handlers
			//--------------------------------------------------------------------

			_onDetailOverviewRouteMatched: function() {
				_this.refreshList();
			},

			/**
			 * Sets height of the shop page
			 */
			handleWindowResize: function() {

			},

			/**
			 * when the global model is changed
			 */
			onGlobalModelChange: function() {
				_this.refreshList();
			},

			/**
			 * Map button pressed
			 */
			onMapPress: function() {
				_this.oRouter.getTargets().display("myShop");
			},

			/**
			 * Show/hide complete work orders
			 */
			onToggleComplete: function() {
				this._bHideComplete = !this._bHideComplete;

				this._oViewPropertiesModel.setProperty("/HideComplete", this._bHideComplete);

				this.toggleComplete();
				this.refreshCompleteToggle();
			},
			
			/**
			 * Expand panels
			 */
			onToggleExpand: function() {
				this._bExpandAll = !this._bExpandAll;

				this.togglePanels();
				this.refreshExpandToggle();
			},
			
			/**
			 * Print map
			 * @param(event) oEvent is the listener of the event
			 */
			onPressMapPrint: function(oEvent) {
				var oHtmlDialog = $("#" + this.byId("DetailOverviewList").sId);
				
				var sHtmlContent = oHtmlDialog[0].outerHTML;
				var sTitle = "Turnover Report print";
				
				PrintManager.createPrintPage(sTitle, sHtmlContent, 6000);
			}

		});
});