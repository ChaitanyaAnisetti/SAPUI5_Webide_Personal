sap.ui.define([
               "jquery.sap.global",
               "sap/ui/core/Fragment",
               "sap/ui/core/mvc/Controller",
               "sap/ui/model/Filter",
               "sap/ui/model/json/JSONModel",
               "com/sap/cp/lm/util/Constants",
               "com/sap/cp/lm/util/BusyIndicator",
               "com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
               "com/sap/cp/lm/controller/map/MapManager",
               "com/sap/cp/lm/controller/locomotives/LocomotiveManager",
               "com/sap/cp/lm/util/Formatter"
               ], function(jQuery, Fragment, Controller, Filter, JSONModel, Constants, BusyIndicator, LocomotiveDataModel, MapManager,
            		   LocomotiveManager, Formatter) {
	"use strict";
	var _this;
	sap.ui.controller("com.sap.cp.lm.controller.map.MyPlanDetails", {

		/**
		 * Function is called when Controller is loaded only for the first time 
		 */
		onInit: function() {

			this._shiftWidth = 60,
			this._shiftPaddingLeft = 5,
			this._shiftTop = 5,
			this._shiftHeight = 40,
			this._dragbarWidth = 6,
			this._shiftDateLeft = 5,
			this._shiftDateTop = 15,
			this._shiftSpotTop = 35;
			this._woHeight = 47;
			this._operationHeight = 45;

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());
			this.getView().setModel(new sap.ui.model.json.JSONModel({}),"locoDetailModel");
			$(window).on('resize', $.proxy(this.handleWindowResize, this));
			var that = _this = this;
			this._oGlobalLocomotiveModel = this.getOwnerComponent().getGlobalLocomotiveModel();
			this._oI18nModel = this.getOwnerComponent().getModel("i18n");
			this.oEventBus = sap.ui.getCore().getEventBus();
			this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
			this._oWOStatusModel = this.getOwnerComponent().getGlobalWOStatusModel();

			this._oGanttContainer = this.getView().byId("MyPlanGanttContainer");
			this._oListContainer = this.getView().byId("MyPlanListContainer");
			$("#"+this._oGanttContainer.sId).on("scroll", function () {
				$("#"+this._oListContainer.sId).scrollTop($(this).scrollTop());
			});

			this.onGlobalModelChange();
			// register to listen to change events of the globalmodel which contain the currentShop
			var binding = new sap.ui.model.Binding(this._oGlobalModel, "/", this._oGlobalModel.getContext("/"));
			binding.attachChange(function() {
				_this.onGlobalModelChange();
			});

			oRouter.getTargets().attachDisplay(function(oEvent) {				
				if (oEvent.getParameter("name") === "MyPlanDetails") {

					_this.oLocomotiveNumber = oEvent.getParameter("data");

					if(!_this.oLocomotiveNumber)
					{
						var oModel= new sap.ui.model.json.JSONModel();
						that.getView().setModel(oModel);
					}
					else{
						this._dataLoaded = false;
						BusyIndicator.showBusyIndicator();
						var sExpand = "WorkPlan/WorkOrderSet/OperationSet/MaterialSet,WorkPlan/ShiftSet"
						LocomotiveDataModel.fetchLocomotiveDetails(that.loadData, that.onloadDataError, that, that.oLocomotiveNumber, sExpand);
					}
				}
			});	

			//this.getView().setModel(new sap.ui.model.json.JSONModel(),"locoDetailModel");
			this.oWOList = this.byId("idWOList");
			//Attach a handler for when the data is refreshed
			this.oWOList.attachUpdateFinished(this._afterDataReceived, this);
		},

		onAfterRendering: function(){
			$("#"+this._oGanttContainer.sId).on("scroll", function () {
				$("#"+_this._oListContainer.sId).scrollTop($(this).scrollTop());
			});
			$("#"+this._oListContainer.sId).on("scroll", function () {
				$("#"+_this._oGanttContainer.sId).scrollTop($(this).scrollTop());
			});
		},

		handleWindowResize: function() {
			this._myPlanDetailsPage = this.byId("MyPlanDetailPage");							
			// adjust the height of the MyPlan view
			var frameHeight = $(window).height(); 
			//var headerToolbar = $("#" + this.byId("MyPlanToolbar").sId);
		},

		/**
		 * when the global model is changed
		 */ 
		onGlobalModelChange: function(){
			var tempCurrentRole = this._oGlobalModel.getProperty("/role");
			// check if the currentRole is different and if so reload the map
			if (tempCurrentRole && tempCurrentRole !== this._sRole){
				this.sRole = tempCurrentRole;
				var sRoleModel =  new sap.ui.model.json.JSONModel();
				sRoleModel.setProperty("/SelectedRole", this.sRole); 
				this.getView().setModel(sRoleModel ,"Role");
			}
		},

		_zoomed: function(){
			this._main.attr("transform", "translate(" + this._oD3Zoom.translate() +")scale(" + this._oD3Zoom.scale() + ")");
		},

		_dragOrigin : function(d) {
			return {
				x : d3.select(d).attr("x"),
				y : d3.select(d).attr("y"),
			};
		},

		_dragStarted : function(d) {
			d3.event.sourceEvent.stopPropagation();
		},

		_dragged : function(d) {
			var operationRect = d3.select("#operation_" + d.WorkOrderNum + "_" + d.OperationNumber)[0][0];
			var operationLeftResizeRect = d3.select("#operation_left_" + d.WorkOrderNum + "_" + d.OperationNumber)[0][0];
			var operationRightResizeRect = d3.select("#operation_right_" + d.WorkOrderNum + "_" + d.OperationNumber)[0][0];
			// dragging the operation background rectangle
			var dragX = Math.max(this._currentShiftX, Math.min(this._svgWidth - d.width, d3.event.x));
			d3.select(operationRect).attr("x", d.x = dragX).attr("y",
					d.y = d.y);
			d3.select(operationLeftResizeRect) 
			.attr("x", function(d) { return d.x - (_this._dragbarWidth/2); });			
			d3.select(operationRightResizeRect).attr("x", function(d) { return dragX + d.width - (_this._dragbarWidth/2); });

		},

		_draggedLeftResize: function(d){
			var operationRect = d3.select("#operation_" + d.WorkOrderNum + "_" + d.OperationNumber)[0][0];
			var operationLeftResizeRect = d3.select("#operation_left_" + d.WorkOrderNum + "_" + d.OperationNumber)[0][0];

			var oldx = d.x; 
			//Max x on the right is x + width - dragbarw
			//Max x on the left is 0 - (dragbarw/2)
			d.x = Math.max(this._currentShiftX, Math.min(d.x + d.width - (_this._dragbarWidth / 2), d3.event.x)); 
			d.width = d.width + (oldx - d.x);

			d3.select(operationLeftResizeRect)
			.attr("x", function(d) { return d.x - (_this._dragbarWidth / 2); });

			d3.select(operationRect)
			.attr("x", function(d) { return d.x; })
			.attr("width", d.width);						
		},

		_draggedRightResize: function(d){
			var operationRect = d3.select("#operation_" + d.WorkOrderNum + "_" + d.OperationNumber)[0][0];
			var operationRightResizeRect = d3.select("#operation_right_" + d.WorkOrderNum + "_" + d.OperationNumber)[0][0];

			//Max x on the left is x - width 
			//Max x on the right is width of screen + (dragbarw/2)
			var dragx = Math.max(d.x + (_this._dragbarWidth/2), Math.min(_this._svgWidth, d.x + d.width + d3.event.dx));

			//recalculate width
			d.width = dragx - d.x;

			//move the right drag handle
			d3.select(operationRightResizeRect)
			.attr("x", function(d) { return dragx - (_this._dragbarWidth/2) });

			d3.select(operationRect)
			.attr("width", d.width);	
		},

		/** Drag end event handler for D3.js
		 * Locomotive drag end check if its dropped into a valid spot
		 * @param d The locomotive object 
		 */
		_dragEnded : function(d) {
		},

		drawOperations: function(){
			var oLocoDetailModel = this.oWOList.getBinding("items").getModel();
			this._operations = [];
			var operationY = this._shiftTop + this._shiftHeight;
			for (var i = 0; i < oLocoDetailModel.getData().detailsData.WorkPlan.WorkOrderSet.results.length; i++){
				var aOperations = oLocoDetailModel.getData().detailsData.WorkPlan.WorkOrderSet.results[i].OperationSet;
				operationY = operationY + this._woHeight;
				for (var j = 0; j < aOperations.results.length && oLocoDetailModel.getData().detailsData.WorkPlan.WorkOrderSet.results[i].WOExpanded ; j++){
					var oOperation = aOperations.results[j];
					oOperation.WOIndex = i+1;
					oOperation.OperationIndex = j;
					if (oOperation.ScheduledStart){
						var diff  = new Date(oOperation.ScheduledStart - this._workPlanStartDate),
						days  = diff/1000/60/60/24;
						oOperation.x = days*3*this._shiftWidth + this._shiftPaddingLeft;
						oOperation.y = operationY;
						diff = new Date(oOperation.ScheduledEnd - oOperation.ScheduledStart);
						var hours = diff/1000/60/60;
						oOperation.width = (this._shiftWidth/8) * hours; // TODO hard coded shift duration
						this._operations.push(oOperation);					
					}
					operationY = operationY + this._operationHeight;
				}				
			}
			
			d3.selectAll(".lmOperation").remove();
			d3.selectAll(".lmOperationLeftResize").remove();
			d3.selectAll(".lmOperationRightResize").remove();
			
			
			//draw operations
			var rectOperation = this._main.selectAll(".operationContainer")
			.data(this._operations);

			rectOperation.enter().append("rect")
			.attr("id", function(d, i) {
				return "operation_" + d.WorkOrderNum + "_" + d.OperationNumber;
			})
			.attr("x", function(d, i) {
				d.x = d.x ? d.x : 0;
				return d.x;
			})
			.attr("y", function(d, i) {
//				d.top = _this._shiftTop;
				d.y = d.y ? d.y : 0;
				return d.y;
			})
			.attr("width", function(d, i) {
				return d.width;
			})
			.attr("height", function(d, i) {
				d.height = _this._shiftHeight;
				return d.height;
			})
			.attr("class", function(d) { 
				return "lmOperation ";			
			});

			d3.selectAll(".lmOperation")
			.call(this._oD3Drag);

			//draw operations resize left
			var rectLeftResizeOperation = this._main.selectAll(".operationLeftResize")
			.data(this._operations);

			rectLeftResizeOperation.enter().append("rect")
			.attr("id", function(d, i) {
				return "operation_left_" + d.WorkOrderNum + "_" + d.OperationNumber;
			})
			.attr("x", function(d, i) {
				return d.x ? d.x - (_this._dragbarWidth/2) : 0;
			})
			.attr("y", function(d, i) {
				return d.y ? d.y : 0;
			})
			.attr("width", function(d, i) {
				return _this._dragbarWidth;
			})
			.attr("height", function(d, i) {
				return _this._shiftHeight;
			})
			.attr("class", function(d) { 
				return "lmOperationLeftResize ";			
			});

			d3.selectAll(".lmOperationLeftResize")
			.call(this._oD3DragLeftResize);

			//draw operations resize right
			var rectRightResizeOperation = this._main.selectAll(".operationRightResize")
			.data(this._operations);

			rectRightResizeOperation.enter().append("rect")
			.attr("id", function(d, i) {
				return "operation_right_" + d.WorkOrderNum + "_" + d.OperationNumber;
			})
			.attr("x", function(d, i) {
				return d.x ? d.x + d.width - (_this._dragbarWidth/2) : 0;
			})
			.attr("y", function(d, i) {
				return d.y = d.y ? d.y : 0;
			})
			.attr("width", function(d, i) {
				return _this._dragbarWidth;
			})
			.attr("height", function(d, i) {
				return _this._shiftHeight;
			})
			.attr("class", function(d) { 
				return "lmOperationRightResize ";			
			});

			d3.selectAll(".lmOperationRightResize")
			.call(this._oD3DragRightResize);
		},

		drawGanttChart: function(){
			//check how many shifts are there
			var oLocoDetailModel = this.getView().getModel("locoDetailModel");
			this._shifts = oLocoDetailModel.getData().detailsData.WorkPlan.ShiftSet.results;
			this._workPlanStartDate = this._shifts[0].StartDateTime;//oLocoDetailModel.getData().detailsData.WorkPlan.StartDate;

			var oWOListContainer = this.getView().byId("MyPlanListContainer");
			var iScrollHeight = $("#" + oWOListContainer.sId)[0].scrollHeight;
			d3.select("#" + this._oGanttContainer.sId).select("svg").remove();

			this._svgWidth = this._shiftWidth*this._shifts.length + this._shiftPaddingLeft*2;
			$("#" + this._oGanttContainer.sId).height("750");

			this._main = d3.select("#" + this._oGanttContainer.sId)
			.append("svg")
			.attr("width", this._svgWidth+"px")
			.attr("height", iScrollHeight+"px")
			.attr("class","lmGanttSVG")
			.attr("id","MyPlanGanttChartSVG")
			//.call(this._oD3Zoom)
			.append("g")
			.attr("id","MyPlanGanttChart");
			
			// draw the current shift
			var oCurrentShiftStartTime = this._oGlobalModel.getProperty("/currentShift").StartDateTime;
			var oCurrentShiftEndTime = this._oGlobalModel.getProperty("/currentShift").EndDateTime;
			var currentShiftdiff  = new Date(oCurrentShiftStartTime - this._workPlanStartDate),
						days  = Math.round(currentShiftdiff/1000/60/60/24);
			this._currentShiftX = days*3*this._shiftWidth + this._shiftPaddingLeft;
			this._main.append("rect")
			.attr("x", _this._currentShiftX)
			.attr("class", "lmCurrentShift")
			.attr("y", (_this._shiftTop + _this._shiftHeight))
			.attr("width", _this._shiftWidth)
			.attr("height", iScrollHeight);

			// draw the shift boxes
			var rectShift = this._main.selectAll(".shiftContainer")
			.data(this._shifts);

			rectShift.enter().append("rect")
			.attr("id", function(d, i) {
				return "shift_" + i;
			})
			.attr("x", function(d, i) {
				d.left = (_this._shiftWidth * i)+ _this._shiftPaddingLeft;
				d.x = d.left;
				return d.x;
			})
			.attr("y", function(d, i) {
				d.top = _this._shiftTop;
				d.y = d.top;
				return d.y;
			})
			.attr("width", function(d, i) {
				d.width = _this._shiftWidth;
				return d.width;
			})
			.attr("height", function(d, i) {
				d.height = _this._shiftHeight;
				return d.height;
			})
			.attr("class", function(d) { 
				return "lmShift";			
			});

			// adding the shift date text Ex: 11/01
			var shiftDate = this._main.selectAll(".shiftDate")
			.data(this._shifts);

			shiftDate.enter().append("text")
			.attr("id", function(d, i) {
				return "shift_" + i + "_date";
			})
			.attr("dx", function(d, i) {
				return d.left + _this._shiftDateLeft;
			})
			.attr("dy", function(d, i) {
				return d.top + _this._shiftDateTop;
			})
			.attr("class", "lmShiftDate")
			.text(function(d) {
				return d.StartDateTime.getDate()+"/"+(d.StartDateTime.getMonth()+1)+"-"+ d.StartDateTime.getHours() +":" + d.StartDateTime.getMinutes();
			});

			// adding the shift spot text Ex: 11/01
			var shiftDate = this._main.selectAll(".shiftDate")
			.data(this._shifts);

			shiftDate.enter().append("text")
			.attr("id", function(d, i) {
				return "shift_" + i + "_date";
			})
			.attr("dx", function(d, i) {
				return d.left + _this._shiftDateLeft;
			})
			.attr("dy", function(d, i) {
				return d.top + _this._shiftSpotTop;
			})
			.attr("class", "lmShiftDate")
			.text(function(d) {
				return d.ShiftName;
			});

			// drag n drop functionality
			this._oD3Drag = d3.behavior.drag().origin(function() {
				return _this._dragOrigin(this);
			}).on("dragstart", function() {
				_this._dragStarted(this.__data__);
			}).on("drag", function(d) {
				_this._dragged(this.__data__);
			}).on("dragend", function() {
				_this._dragEnded(this.__data__);
			});

			this._oD3DragLeftResize = d3.behavior.drag()
			.origin(Object)
			.on("drag", this._draggedLeftResize);

			this._oD3DragRightResize = d3.behavior.drag()
			.origin(Object)
			.on("drag", this._draggedRightResize);

			this.drawOperations();

		},

		_afterDataReceived: function(){
			this.drawGanttChart();			
		},
		
		onWOExpand: function(oEvent){
//			var sSelectedItemPath = oEvent.oSource.getBindingContext("locoDetailModel").getPath();
//			var oWO = oEvent.oSource.getBindingContext("locoDetailModel").getProperty(sSelectedItemPath);
//			oWO.WOExpanded = oEvent.getSource().getExpanded();
			if (this._dataLoaded){
				this.drawOperations();
				var oWOListContainer = this.getView().byId("MyPlanListContainer");
				var iScrollHeight = $("#" + oWOListContainer.sId)[0].scrollHeight;
				//d3.select("#" + this._oGanttContainer.sId).select("svg")
				document.getElementById("MyPlanGanttChartSVG").setAttribute("height", iScrollHeight +"px");
			}
			
		},

		/**
		 * Success callback for fetchLocomotiveDetails ,Sets model in View
		 * Loads data for the selected locomotive
		 * @params{object} oModel returned for the new selected Locomotive
		 */
		loadData: function(oModel) {
			for (var i = 0; i < oModel.getData().detailsData.WorkPlan.WorkOrderSet.results.length; i++){
				var oWO = oModel.getData().detailsData.WorkPlan.WorkOrderSet.results[i];
				oWO.WOExpanded = true;
			}
			BusyIndicator.hideBusyIndicator();
			this.getView().setModel(oModel,"locoDetailModel");
			this._dataLoaded = true;
		},

	});
});