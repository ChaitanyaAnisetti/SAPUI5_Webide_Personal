/*&---------------------------------------------------------------------*    
 * Author         : SAP Custom Development                               *
 * Date           : 2017.12.21                                           *
 * Project        : Locomotive Maintenance                               *
 * Description    : Controller for the Shopped tab view container.       *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author/Changed By   : Sandhya satavalekar                              *
 * Date                : 02-May-2019                                      *
 * Project             : Locomotive Maintenance Phase 2                   *
 * Description         : LMP2-03 : Notification History Tab 	             *
 * Search Term         : LMP2-03                                          *
 *&-----------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
* Author/Changed By   : BAJ0018				        		       		  *
* Date                : 21-August-2019                                    *
* Project             : Locomotive Maintenance Phase 3                    *
* Description         : Added logic for shopped KPI                       *
/*&-----------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
* Author/Changed By   : Steve Palme (PAL0121)       		       		  *
* Date                : 3/17/20		                                      *
* Project             : ASR3414893						                  *
* Description         : Add logic for setting WSA flag                    *
/*&-----------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : BAJ0018				        		       		   *
* Date                : 19 -Feb -2021                                      *
* Project             : BNB Project                                        *
* Description         : Added BNB Storage locations logic                  *
* Search Term         : BNB                                                *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : BAJ0018				        		       		   *
* Date                : 04 -Aug -2021                                      *
* Project             : LLM                                                *
* Description         : Fixed bug related to ETR update                    *
* Search Term         : ETRFIX                                              *
/*&------------------------------------------------------------------------*/
sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/Fragment",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/json/JSONModel",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/model/main/TrackSpotModel",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
	"com/sap/cp/lm/controller/map/MapManager",
	"com/sap/cp/lm/controller/locomotives/LocomotiveManager",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/controller/craft/CraftManager",
	"com/sap/cp/lm/model/craft/CraftDataModel",
	"com/sap/cp/lm/util/ErrorManager",
	"com/sap/cp/lm/controller/myShop/common/LocomotiveHeaderManager"
], function (jQuery, Fragment, Controller, Filter, JSONModel, Constants, TrackSpotModel, BusyIndicator, LocomotiveDataModel,
	MapManager, LocomotiveManager, Formatter, CraftManager, CraftDataModel,
	ErrorManager, LocomotiveHeaderManager) {
	"use strict";
	var _this;
	sap.ui.controller("com.sap.cp.lm.controller.myShop.shopped.ShoppedContainer", {

		formatter: Formatter,
		/**
		 * Function is called when Controller is loaded only for the first time 
		 */
		onInit: function () {
			_this = this;

			_this._oRouter = sap.ui.core.UIComponent.getRouterFor(_this.getView());
			_this.getView().setModel(new sap.ui.model.json.JSONModel({}));

			$(window).on('resize', $.proxy(_this.handleWindowResize, _this));

			_this._oI18nModel = _this.getOwnerComponent().getModel("i18n");

			_this._oGlobalModel = _this.getOwnerComponent().getGlobalModel();

			// register to listen to change events of the globalmodel which contain the currentShop
			var binding = new sap.ui.model.Binding(_this._oGlobalModel, "/", _this._oGlobalModel.getContext("/"));
			binding.attachChange(function () {
				_this.onGlobalModelChange();
			});

			_this._oRouter.getTargets().attachDisplay(function (oEvent) {
				if (oEvent.getParameter("name") === "locomotivesShoppedHome") {
					_this._oGlobalModel.setProperty("/readOnlyWorkPlan", false);
					_this._oGlobalModel.setProperty("/readFromWorkPlan", true); //Added by Sandhya LMP2-3
					_this._oGlobalModel.setProperty("/readFromWOHistory", false); //Added by Sandhya LMP2-3
					_this._oGlobalModel.setProperty("/isShopped", true);
					_this._oGlobalModel.setProperty("/isServiced", false);

					var oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");

					_this.loadLocomotiveDetails(oLocomotive);

					var forcedLocomotive = _this._oGlobalModel.getProperty("/forcedLocomotive");
					if (forcedLocomotive) {
						_this.refreshLocomotivesList();
					}
				}
			});

			_this.fetchETRUpdateCodes();

			_this.initLocomotiveHeader();

		},

		fetchETRUpdateCodes: function () {
			LocomotiveDataModel.fetchETRUpdateCodes(_this.fetchETRUpdateCodesSuccess, _this.fetchETRUpdateCodesFailure, _this);
		},

		fetchETRUpdateCodesSuccess: function (oData) {
			var ETRUpdateCodes = oData.results;
			_this.getView().getModel().setProperty("/ETRUpdateCodes", ETRUpdateCodes);
			//START - BAJ0018 - ETRFIX
			this._oGlobalModel.setProperty("/ETRUpdateCodes", ETRUpdateCodes);
			//END - BAJ0018 - ETRFIX
		},

		fetchETRUpdateCodesFailure: function (oData) {},

		//common
		refreshLocomotivesList: function () {
			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.publish("MyShopMasterPage", "onRefreshMasterList", {});
		},

		onDialogCancel: function (oEvent) {
			oEvent.getSource().getParent().close();
		},

		/**
		 * Fullscreen/exit full screen button pressed
		 */
		onToggleFullScreenPress: function (oEvent) {
			_this._bHideMaster = !_this._bHideMaster;
			// change the button icon
			if (_this._bHideMaster) {
				oEvent.getSource().setIcon("sap-icon://exit-full-screen");
			} else {
				oEvent.getSource().setIcon("sap-icon://full-screen");
			}

			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.publish("MyShopSC", "toggleSplitContainerShowMaster", {
				"hideMaster": _this._bHideMaster
			});
		},

		/**
		 * when the global model is changed
		 */
		onGlobalModelChange: function () {
			var tempCurrentRole = _this._oGlobalModel.getProperty("/role");
			// check if the currentRole is different and if so reload the map
			if (tempCurrentRole && tempCurrentRole !== _this.sRole) {
				_this.sRole = tempCurrentRole;
				var sRoleModel = new sap.ui.model.json.JSONModel();
				sRoleModel.setProperty("/SelectedRole", _this.sRole);
				_this.getView().setModel(sRoleModel, "Role");

				var oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
				if (oLocomotive) {
					_this.loadLocomotiveDetails(oLocomotive);
				}
			}
		},

		/*Function gets called when the global model for workorder status is changed */
		onWorkOrderStatusModelChange: function () {
			_this.enableRelease();
		},
		/*Function enables arelease button based on Work order status.If all WO is Completed and Defered it should be enable*/
		enableRelease: function () {
			var oWPResults = _this.getView().getModel().getProperty("/detailsData/WorkPlan/WorkOrderSet/results");
			var aGroupSet = _this.getView().getModel().getProperty("/detailsData/WorkPlan/GroupSet/results");
			var bWODefault = true;
			var bWO = false;
			var bGroupDefault = true;
			var bGroup = false;
			if (oWPResults !== undefined) {
				for (var i = 0; i < oWPResults.length; i++) {
					bWODefault = false;
					if (!oWPResults[i].GroupId || oWPResults[i].NotificationType === Constants.L5) {
						if ((oWPResults[i].Status === Constants.STATUS_COMPLETED) || (oWPResults[i].Status === Constants.STATUS_DEFERRED)) {
							bWO = true;
						} else {
							bWO = false;
							break;
						}
					}
				}
			}
			if (aGroupSet) {
				for (var j = 0; j < aGroupSet.length; j++) {
					bGroupDefault = false;
					if ((aGroupSet[j].Status === Constants.STATUS_COMPLETED || aGroupSet[j].Status === Constants.STATUS_DEFERRED)) {
						bGroup = true;
					} else {
						bGroup = false;
						break;
					}
				}
			}
			_this.getView().byId("btnRelease").setEnabled((bWODefault || bWO) && (bGroupDefault || bGroup));
		},

		/**
		 * Loads data for the selected locomotive when navigating to the shopped home page
		 * @params{object} oModel returned for the new selected Locomotive
		 */
		loadLocomotiveDetails: function (oLocomotive) {
			_this.sLocomotiveId = oLocomotive.LocomotiveId;

			var sEquipNo = oLocomotive.Equipment;
			if (!sEquipNo) {
				sEquipNo = oLocomotive.EquipNo;
			}
			_this.sEquipment = sEquipNo;

			_this.getView().getModel().setProperty("/detailsData/LocomotiveNumber", _this.sLocomotiveId);

			var sKey = _this.getView().byId("shoppedIconTabBar").getSelectedKey();
			_this._processSelectedTab(sKey);

			//START - BAJ0018 -BNB

			if (oLocomotive.BnbLoco) {
				_this.getView().byId("shoppedIconTabBar").getItems()[1].setVisible(false);
				_this.getView().byId("shoppedIconTabBar").getItems()[2].setVisible(false);
				_this.getView().byId("shoppedIconTabBar").getItems()[4].setVisible(false);
				_this.getView().byId("shoppedIconTabBar").getItems()[5].setVisible(false);
				
				_this.getView().byId("kpiBlock").setVisible(false);
				//_this.getView().byId("idWorkPlanReleaseBtn").setVisible(false);
			} else {
				_this.getView().byId("shoppedIconTabBar").getItems()[1].setVisible(true);
				_this.getView().byId("shoppedIconTabBar").getItems()[2].setVisible(true);
				_this.getView().byId("shoppedIconTabBar").getItems()[4].setVisible(true);
				_this.getView().byId("shoppedIconTabBar").getItems()[5].setVisible(true);
				
				_this.getView().byId("kpiBlock").setVisible(true);
			//	_this.getView().byId("idWorkPlanReleaseBtn").setVisible(false);
			}

			//END BAJ0018 - BNB

			/////////////////////Begin of Changes for ASR3414893 by PAL0121/////////////////////
			var oParam = {};
			var sWSAEquipment = _this._oGlobalModel.getProperty("/WSAEquipment");

			if (sWSAEquipment !== _this.sEquipment) {
				//Get characteristics and check for WSA when a new loco is selected
				oParam.Equipment = _this.sEquipment;
				LocomotiveDataModel.fetchLocoChar(_this.setWSAFlag, null, _this, oParam);
			}
			//////////////////////End of Changes for ASR3414893 by PAL0121//////////////////////

			//Added BAJ0018 Shopped KPI
			var kpiInformation = _this._oGlobalModel.getProperty("/kpiInformation");
			_this.getView().getModel().setData({
				kpiInformation: kpiInformation
			});
		},

		/**
		 * Success callback for fetchLocomotiveDetails ,Sets model in View
		 * Loads data for the selected locomotive
		 * @params{object} oModel returned for the new selected Locomotive
		 */
		loadData: function (oModel, oContext, sLocomotiveId, sEquipment) {

			//ask workplan tab to reload
			var oParameters = {
				iconTabBar: _this.getView().byId("shoppedIconTabBar"),
				bindPath: "/detailsData/results",
				model: oModel,
				parentView: Constants.LOCOMOTIVES,
				locomotiveNumber: sLocomotiveId,
				equipmentNo: sEquipment,
				Description: oModel.getData().detailsData.Description,
				shiftlist: true
			};

			_this.byId("locoWorkPlan").getController().loadData(oParameters);
			BusyIndicator.hideBusyIndicator();
		},

		/**
		 * Function gets fired once the document is rendered
		 * Cannot be removed as the Window needs to be resized
		 */
		onAfterRendering: function () {

		},
		/**
		 * Function gets fired when the window is resizes
		 */
		handleWindowResize: function () {

		},

		/**
		 * Common close function for all dialogs
		 */
		onClickCancel: function () {
			if (_this.UnplanSelected) {
				_this.UnplanSelected.close();
			}

			if (_this._placeLocomotiveDialog) {
				_this._placeLocomotiveDialog.destroy();
			}
			if (_this.oAddWODialog) {
				LocomotiveManager.onClickWOCancel(_this);
			}
			if (_this.oSelectTaskDialog) {
				_this.oSelectTaskDialog.destroy();
			}
			if (_this.oReleaseFrag) {
				_this.oReleaseFrag.destroy(true);
				_this.oReleaseFrag = null;
			}
			if (_this.oArriveShopService) {
				_this.oArriveShopService.close();
			}
			if (_this.oPredictDialog) {
				_this.oPredictDialog.close();
			}
			if (_this.oAddCraftDiag) {
				var oCraftTable = sap.ui.core.Fragment.byId("idAddCraftFrag", "idCraftTable");
				oCraftTable.removeSelections(true);
				_this.oAddCraftDiag.close();
			}
		},

		/**
		 * Handles selection of Icon Tab Bar
		 * @params(event) oEvent is returned on
		 * 				  icon tab bar selection changes
		 */
		onShoppedIconSelect: function (oEvent) {
			var sKey = oEvent.getParameters().key;
			_this._processSelectedTab(sKey);
		},

		addContentIconTabFilter: function (sIdFilter, sView) {

			var oView = this.getOwnerComponent().runAsOwner(function () {
				return sap.ui.view({
					viewName: sView,
					type: sap.ui.core.mvc.ViewType.XML
				});
			});

			oView.setModel(_this._oI18nModel, "i18n");

			this.byId(sIdFilter).destroyContent();
			this.byId(sIdFilter).addContent(oView);

			return oView.getController();
		},

		_processSelectedTab: function (sKey) {
			var sRole = _this._oGlobalModel.getProperty("/role");
			if (sKey === "workPlan") {
				_this._oGlobalModel.setProperty("/workplanFooterIsVisible", true);
				_this._oGlobalModel.setProperty("/readOnlyWorkPlan", false);
				_this._oGlobalModel.setProperty("/readFromWOHistory", false); //Added by Sandhya LMP2-3
				_this._oGlobalModel.setProperty("/readFromWorkPlan", true); //Added by Sandhya LMP2-3
				if (_this.getView().byId("btnAddWork")) _this.getView().byId("btnAddWork").setVisible(true);
				if (_this.getView().byId("btnRelease")) _this.getView().byId("btnRelease").setVisible(true);
				if (_this.getView().byId("btnGroupWork")) _this.getView().byId("btnGroupWork").setVisible(true);
				if (_this.getView().byId("replanUnplanHBox")) _this.getView().byId("replanUnplanHBox").setVisible(true);
				if (sRole === Constants.ROLE.CRAFT) {
					if (_this.getView().byId("btnRelease")) _this.getView().byId("btnRelease").setVisible(false);
					if (_this.getView().byId("btnGroupWork")) _this.getView().byId("btnGroupWork").setVisible(false);
				}
				BusyIndicator.showBusyIndicator();
				LocomotiveDataModel.fetchLocomotiveDetails(_this.loadData, null, _this, _this.sLocomotiveId, _this.sEquipment);
			}
			if (sKey === "history") {
				_this._oGlobalModel.setProperty("/workplanFooterIsVisible", false);
				_this._oGlobalModel.setProperty("/readOnlyWorkPlan", true);
				_this._oGlobalModel.setProperty("/readFromWOHistory", true); //Added by Sandhya LMP2-3
				_this._oGlobalModel.setProperty("/readFromWorkPlan", false); //Added by Sandhya LMP2-3
				_this._oGlobalModel.setProperty("/readFromNotifHistory", false); //Added by Sandhya LMP2-3
				_this.addContentIconTabFilter("idFilterWOHistory", "com.sap.cp.lm.view.common.workOrderHistory.WorkOrderHistory").fetchWOHistory();
			}
			//Start : Added by Sandhya : LMP2-3 : Notification History Tab
			if (sKey === "notifhistory") {
				_this._oGlobalModel.setProperty("/workplanFooterIsVisible", false);
				_this._oGlobalModel.setProperty("/readOnlyWorkPlan", true);
				_this._oGlobalModel.setProperty("/readFromWOHistory", true); //Added by Sandhya LMP2-3
				_this._oGlobalModel.setProperty("/readFromWorkPlan", false); //Added by Sandhya LMP2-3
				_this._oGlobalModel.setProperty("/readFromNotifHistory", true); //Added by Sandhya LMP2-3
				_this.addContentIconTabFilter("idFilterNotifHistory", "com.sap.cp.lm.view.common.NotificationHistory.NotificationHistory").fetchNotifHistory();
				//	 _this.addContentIconTabFilter("idFilterNotifHistory", "com.sap.cp.lm.view.common.workOrderHistory.WorkOrderHistory").fetchWOHistory();
			}
			//End:Added by Sandhya : LMP2-3 : Notification History Tab
			if (sKey === "defects") {
				_this.byId("locoDefects").getController().fetchLocomotiveDefects();
			}
			if (sKey === "wheelSheet") {
				_this.addContentIconTabFilter("idFilterlocoWheelSheet", "com.sap.cp.lm.view.myShop.common.wheelSheet.WheelSheetHistory").fetchLocomotiveWheelSheetHistory();
			}
			if (sKey === "details") {
				_this.addContentIconTabFilter("idFiltershoppedLocoDetails", "com.sap.cp.lm.view.myShop.common.details.Details").fetchLocomotiveDetails();
			}
		},

		/////////////////////Begin of Changes for ASR3414893 by PAL0121/////////////////////
		setWSAFlag: function (oData) {
			var i;
			var iLength = oData.results.length;

			_this._oGlobalModel.setProperty("/WSAEquipment", _this.sEquipment);

			for (i = 0; i < iLength; i++) {
				if (oData.results[i].Char_Name === "WARRANTY_SERVICE_AGREEMENT" && oData.results[i].Char_Value === "GE Warranty Service Agreement") {
					_this._oGlobalModel.setProperty("/isWSA", " WSA");
					return;
				}
			}

			_this._oGlobalModel.setProperty("/isWSA", "");
		},
		//////////////////////End of Changes for ASR3414893 by PAL0121//////////////////////

		/**
		 * Init toolbar header fragment and manager
		 */
		initLocomotiveHeader: function () {
			if (_this._oLocomotiveHeaderManager) {
				_this._oLocomotiveHeaderManager.destroy();
			}
			_this._oLocomotiveHeaderManager = new LocomotiveHeaderManager();
			_this._oLocomotiveHeaderManager = _this._oLocomotiveHeaderManager.init(_this);

			if (_this._oLocomotiveHeaderFragment) {
				_this._oLocomotiveHeaderFragment.destroy();
			}
			_this._oLocomotiveHeaderFragment = _this._oLocomotiveHeaderManager.getFragment();
			_this.byId("MyShopToolbar").addContent(_this._oLocomotiveHeaderFragment);
		}

	});
});