/*&--------------------------------------------------------------------------*    
 * Author/Changed By   : SAT0008			                                  *
 * Date                : 29-May-2019                                          *
 * Project             : Locomotive Maintenance Phase 2                       *
 * Description         : LMP2-40 : Add NOCO to notification screen            *
 * Search Term         : LMP2-40                                              *
 *&---------------------------------------------------------------------------*/
 /*&----------------------------------------------------------------------*    
 * Author         : SAT0008                                              *
 * Date           : 2019.05.25                                           *
 * Incidinet      : LMP2-12 - Notif Long Text		              	     *
 * Description    : Add long text for the notification                   *                   
 * Search Term    : LMP2-12                                              *
 *&----------------------------------------------------------------------*/
  /*&----------------------------------------------------------------------*    
 * Author         : SHE0272                                              *
 * Date           : 2021-07-23                                           *
 * Incidinet      : INC0099624						              	     *
 * Description    : Notification is not refreshing on switching page     *                   
 * Search Term    : INC0099624                                           *
 *&----------------------------------------------------------------------*/
 /*&----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2021.07.26                                           *
 * Description    : LMP-2.28 Update USER STATUS                          *                   
 * Search Term    : UPDSTATUS                                            *
 *&----------------------------------------------------------------------*/
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/BusyIndicator",
	"sap/ui/model/json/JSONModel",
	"com/sap/cp/lm/controller/myShop/common/AddDefectManager",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
	"com/sap/cp/lm/util/ErrorManager",
	"com/sap/cp/lm/controller/myShop/common/CloseOutCode",
	"com/sap/cp/lm/controller/myShop/common/IncidentNumberManager"

], function (Controller, Constants, BusyIndicator, JSONModel, AddDefectManager, Formatter, LocomotiveDataModel, ErrorManager,
	CloseOutCode, IncidentNumberManager) {
	"use strict";

	var _this;

	return Controller.extend("com.sap.cp.lm.controller.myShop.shopped.defects.Defects", {

		/**
		 * Function is called when Controller is loaded only for the first time 
		 */
		onInit: function () {
			_this = this;

			this.getView().setModel(new sap.ui.model.json.JSONModel());

			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());
			$(window).on('resize', $.proxy(this.handleWindowResize, this));

			this._oGlobalLocomotiveModel = this.getOwnerComponent().getGlobalLocomotiveModel();
			this._oI18nModel = this.getOwnerComponent().getModel("i18n");
			this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
			this.onGlobalModelChange();

			// register to listen to change events of the globalmodel which contain the currentShop
			var binding = new sap.ui.model.Binding(this._oGlobalModel, "/", this._oGlobalModel.getContext("/"));
			binding.attachChange(function () {
				_this.onGlobalModelChange();
			});

			this._oRouter.getTargets().attachDisplay(function (oEvent) {

				if (oEvent.getParameter("name") === "locomotivesShoppedHome") {
					_this.oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
					_this.getView().getModel().setProperty("/Locomotive", _this.oLocomotive);
					_this.fetchLocomotiveDefects(_this.oLocomotive);
				} else if (oEvent.getParameter("name") === "locomotivesServicingHome") {
					_this.oLocomotive = _this._oGlobalModel.getProperty("/currentServiceLocomotive");
					_this.getView().getModel().setProperty("/Locomotive", _this.oLocomotive);
					_this.fetchLocomotiveDefects(_this.oLocomotive);
				} else if (oEvent.getParameter("name") === "CraftList") {} else if (oEvent.getParameter("name") === "CraftBlankDetails") {

				}

			});
		},

		/**
		 * load locomotive defects from backend
		 */
		fetchLocomotiveDefects: function (oLocomotive) {
			if (oLocomotive) {
				_this.oLocomotive = oLocomotive;
			} else {
				_this.oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
			}

			_this.getView().getModel().setProperty("/Locomotive", _this.oLocomotive);

			LocomotiveDataModel.fetchLocomotiveDefects(_this.oLocomotive, _this._onFetchLocomotiveDefectsSuccess, _this._onFetchLocomotiveDefectsFailed,
				_this);
		},

		/**
		 * Success callback function for readInboundLocomotive
		 */
		_onFetchLocomotiveDefectsSuccess: function (oData) {
			BusyIndicator.hideBusyIndicator();
			var results = oData.results;

			for (var i = 0; i < results.length; i++) {
				var oDefect = results[i];
				oDefect.ShopGroup = 3;
			}

			_this.getView().getModel().setProperty("/Defects", results);
			
			/*SHE0272 - INC0099624 - Change to set the data to global model and binding the same to UI.
			This change is done beacuse initially above mentioned local model was binded
			and the same view is being used in 3 places. With the local model, data was 
			not getting refreshed once the user switch between these 3 screens. Made the
			changes in view to load data from global model*/
			
			_this._oGlobalModel.setProperty("/Defects", results);

			setTimeout(function () {
				_this.getView().getModel().refresh(true);
			}, 100);
		},

		/**
		 * Failed callback function for readInboundLocomotive
		 */
		_onFetchLocomotiveDefectsFailed: function (oData) {
			BusyIndicator.hideBusyIndicator();
		},

		/**
		 * when the global model is changed
		 */
		onGlobalModelChange: function () {

		},

		/**
		 * sets height of the shop page
		 */
		handleWindowResize: function () {

		},

		/**
		 * edit long text
		 */

		onEditDefectLongText: function (oEvent) {
			if (!_this._oLongtextDialog) {
				_this._oLongtextDialog = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.inbound.defects.DefectLongText",
					_this
				);
			}
			_this._oLongtextDialog.getContent()[0].getItems()[0].setValue(_this.getView().getModel("global").getObject(_this._currentDefectContext.sPath)
				.DefectLongText);		// SHE0272 - INC0099624	Notification is not refreshing on switching page
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), _this._oLongtextDialog);
			_this._oLongtextDialog.setContentWidth("40%");
			_this._oLongtextDialog.open();
		},

		onSaveLongText: function (oEvent) {
			var oDefectPayload = this._getselectedDefectPayload(_this._currentDefectContext);
			oDefectPayload.DefectLongText = oEvent.getSource().getParent().getContent()[0].getItems()[0].getValue();
			LocomotiveDataModel.UpdateDefect(_this._updateDefectLongtextSuccess, oDefectPayload, _this);
		},

		_updateDefectLongtextSuccess: function () {
			_this.getView().getModel("global").getObject(_this._currentDefectContext.sPath).DefectLongText = _this._oLongtextDialog.getContent()[0].getItems()[
				0].getValue();	// SHE0272 - INC0099624	Notification is not refreshing on switching page
			_this._oLongtextDialog.close();
		},

		onCancelLongText: function (oEvent) {
			_this._oLongtextDialog.close();
		},

		/**
		 * edit short text
		 */
		onClickEditShortText: function (oEvent) {
			var oShortTextField = oEvent.getSource().getParent().getParent().getItems()[0].getItems()[0];
			if (oShortTextField.getEnabled()) {
				this.onSaveShortText(oEvent.getSource().getBindingContext("global"));	// SHE0272 - INC0099624	Notification is not refreshing on switching page
			}
			oShortTextField.setEnabled(!oShortTextField.getEnabled());
		},

		onSaveShortText: function (oContext) {
			var oDefectPayload = this._getselectedDefectPayload(oContext);
			LocomotiveDataModel.UpdateDefect("", oDefectPayload, _this);
		},

		_getselectedDefectPayload: function (oContext) {
			var oDefectPayload = {};
			var aSelDefect = _this.getView().getModel("global").getObject(oContext.sPath);	// SHE0272 - INC0099624	Notification is not refreshing on switching page

			oDefectPayload.EquipNo = aSelDefect.EquipNo;
			oDefectPayload.WorkOrderNo = aSelDefect.WorkOrderNo;
			oDefectPayload.DefectLongText = aSelDefect.DefectLongText;
			oDefectPayload.FunctionalLoc = aSelDefect.FunctionalLoc;
			oDefectPayload.DefectNo = aSelDefect.DefectNo;
			oDefectPayload.DefectType = aSelDefect.DefectType;
			oDefectPayload.DefectDescr = aSelDefect.DefectDescr;
			oDefectPayload.Shop = aSelDefect.Shop;
			oDefectPayload.PlanDefectDur = aSelDefect.PlanDefectDur;
			oDefectPayload.PlanDefectUnit = aSelDefect.PlanDefectUnit;
			oDefectPayload.MandatoryDefect = aSelDefect.MandatoryDefect;
			oDefectPayload.NearingDueDate = aSelDefect.NearingDueDate;
			oDefectPayload.ReqStartTs = aSelDefect.ReqStartTs;
			oDefectPayload.ReqStartTz = aSelDefect.ReqStartTz;
			oDefectPayload.ObjectNo = aSelDefect.ObjectNo;
			oDefectPayload.DefectLongText = aSelDefect.DefectLongText;
			return oDefectPayload;
		},

		/**
		 * defects defering 
		 */
		onOpenPlannedWorkActionSheet: function (oEvent) {

			var oButton = oEvent.getSource();

			//identify current defect number
			_this._currentDefectNo = oButton.getCustomData()[0].getValue();
			_this._currentDefectDescr = oButton.getCustomData()[1].getValue();
			_this._ShopGroup = oButton.getCustomData()[2].getValue();
			_this._currentDefectContext = oEvent.getSource().getBindingContext("global");	// SHE0272 - INC0099624	Notification is not refreshing on switching page

			// create action sheet only once
			if (!_this._oActionSheet) {
				_this._oActionSheet = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.inbound.defects.PlannedWorkActionSheet",
					_this
				);
				_this.getView().addDependent(_this._oActionSheet);
			}
			// Start - SHE0272 - INC0099624	Notification is not refreshing on switching page
			var WorkActionModel = new sap.ui.model.json.JSONModel();
			WorkActionModel.setProperty("/", _this._currentDefectContext.getObject());
			_this._oActionSheet.setModel(WorkActionModel, "WorkActionModel");
			// End - SHE0272 - INC0099624	Notification is not refreshing on switching page
			_this._oActionSheet.setBindingContext(_this._currentDefectContext);

			_this._oActionSheet.openBy(oButton);
		},

		/**
		 * close out codes 
		 */
		onPressCloseOutCode: function (oEvent) {
			var aData = {};
			aData.sDefectNo = _this._currentDefectNo;
			aData.oController = this;
			aData.oGlobalModel = _this._oGlobalModel;
			aData.oSelectedContext = this._currentDefectContext;
			aData.oSourceViewModel = this.getView().getModel();
			aData.bfromDefectView = true;
			aData.bfromWorkPlanView = false;
			_this._oCloseOutCodeDialog = new CloseOutCode(aData);
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), _this._oCloseOutCodeDialog);
			_this._oCloseOutCodeDialog.getFragment().setContentWidth("60%");
			_this._oCloseOutCodeDialog.getFragment().open();
		},
		//This will save the changed defect back to this View's Data model
		SaveDefectBacktoModel: function(sPath, oDefect){
			this.getView().getModel().setProperty(sPath, oDefect);
			this.getView().getModel("global").setProperty(sPath, oDefect);	// SHE0272 - INC0099624	Notification is not refreshing on switching page
		},
		//Added by Sandhya : LMP2-40 : Add NOCO to notification screen
		onNotifComp: function (oEvent) {
			var oPayload = {
				"DefectNumber": _this._currentDefectNo
			};
			LocomotiveDataModel.CompleteNotif(oPayload, _this.onCompleteNotifSuccess, this);
			
		//	_this.fetchLocomotiveDefects();
		//	_this.getView().getModel().refresh(true);
		},
		
		onCompleteNotifSuccess: function () {
			_this.fetchLocomotiveDefects();
		},
		//End:Added by Sandhya : LMP2-40 : Add NOCO to notification screen
		
		
// Added by Sandhya : LMP2-12  :Inbound Notification Long Text
		onLongTextOpen: function(oEvent) {
			var sBindingPath = oEvent.getSource().getBindingContext("global").sPath;	// SHE0272 - INC0099624	Notification is not refreshing on switching page
			if (sBindingPath) {
				var oDataObject = this.getView().getModel("global").getObject(sBindingPath);	// SHE0272 - INC0099624	Notification is not refreshing on switching page
				if(oDataObject) {
					var oDialog = new sap.m.Dialog({
						title: "Defect Long Text"
					});
				}
				// Helper.openLongTextDialog(oDataObject);
			
				if(oDataObject.DefectLongText && oDataObject.DefectLongText.length > 0) {
						var longTextContent = new sap.m.HBox({
							width: "100%",
							items: [
								new sap.m.Text({
									text: oDataObject.DefectLongText
								})
							]
						});
				}
				oDialog.addContent(longTextContent);
				oDialog.addButton(new sap.m.Button({text: "Ok", press:function(){oDialog.close(); }}));
				oDialog.setContentHeight("500px");
				oDialog.open();
			}
		},
// End:Added by Sandhya : LMP2-12	
		onAddToWorkPlan: function (oEvent) {
			// var oContext = oEvent.getSource().getParent().getBindingContext();
			// var oDefect = oContext.oModel.getProperty(oContext.sPath);
			var oDefect = oEvent.getSource().getParent().getModel("WorkActionModel").getData();

			if (oDefect.WorkOrderNo && oDefect.WorkOrderNo.length > 0) {
				_this.doAddToPlan(oDefect);
			} else {
				_this.openOrderTypeDialog(oDefect);
			}
		},

		doAddToPlan: function (oDefect) {

			var oShop = _this._oGlobalModel.getProperty("/currentShop");

			var oPayload = {
				"DefectNo": oDefect.DefectNo,
				"ShopId": oShop.Id,
				"OrderType": oDefect.OrderType
			};

			LocomotiveDataModel.adoptShoppedLocomotiveDefect(oPayload, _this._editShoppedLocomotiveDefectSuccess, _this._editShoppedLocomotiveDefectFailed,
				_this);

		},

		_editShoppedLocomotiveDefectSuccess: function (oData) {
			_this.fetchLocomotiveDefects();

			if (this._oDeferDefectDialog && this._oDeferDefectDialog.isOpen()) {
				this._oDeferDefectDialog.close();
			}
		},

		_editShoppedLocomotiveDefectFailed: function (oData) {
			if (this._oDeferDefectDialog && this._oDeferDefectDialog.isOpen()) {
				this._oDeferDefectDialog.close();
			}
		},

		filterOrderTypes: function (oDefect) {
			var sDefectType = oDefect.DefectType;
			var aFiltered = [];
			var aDefectToOrderTypes = _this._oGlobalModel.getProperty("/DefectToOrderTypes");
			for (var i = 0; i < aDefectToOrderTypes.length; i++) {
				var defectToOrderType = aDefectToOrderTypes[i];
				if (defectToOrderType.Key === sDefectType) {
					aFiltered.push(defectToOrderType);
				}
			}
			return aFiltered;
		},

		openOrderTypeDialog: function (oDefect) {
			var aDefectToOrderTypes = _this.filterOrderTypes(oDefect);

			if (!_this.orderTypeDialog) {
				_this.orderTypeDialog = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.inbound.defects.AddToPlanDialog",
					_this
				);
			}

			if (_this.orderTypeDialog) {
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setProperty("/DefectToOrderTypes", aDefectToOrderTypes);
				oModel.setProperty("/Defect", oDefect);
				_this.orderTypeDialog.setModel(oModel);
			}

			_this.getView().addDependent(_this.orderTypeDialog);

			_this.orderTypeDialog.open();
		},

		onOrderTypeDialogCancel: function (oEvent) {
			var oOrderTypeDialogSelect = sap.ui.getCore().byId('orderTypeDialogSelect');
			oOrderTypeDialogSelect.clearSelection();
			_this.orderTypeDialog.close();
		},

		onOrderTypeDialogDone: function (oEvent) {
			var oOrderTypeDialogSelect = sap.ui.getCore().byId('orderTypeDialogSelect');
			var sOrderType = oOrderTypeDialogSelect.getSelectedKey();

			var oDefect = oEvent.getSource().getParent().getModel().getProperty("/Defect");

			oDefect.OrderType = sOrderType;

			_this.doAddToPlan(oDefect);

			oOrderTypeDialogSelect.clearSelection();

			_this.orderTypeDialog.close();
		},

		//----------------------------------------------------------------------
		// Private functions
		//----------------------------------------------------------------------

		/***
		 * Open add defect dialog
		 */

		onAddDefect: function (oData) {
			if (!_this.oAddDefectManager) {
				_this.oAddDefectManager = AddDefectManager.init(_this, _this.fetchLocomotiveDefects);
			}

			_this.oAddDefectManager.onAddAffectDialogOpen("DEFECT");
		},
       
       	//BAJ0018 - START - UPDSTATUS
		onEditStatus: function (oEvent) {
			if (!_this._oEditStatusDialog) {
				_this._oEditStatusDialog = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.inbound.defects.Status",
					_this
				);
			}
			var aDefectStatus = _this._oGlobalModel.getProperty("/DefectStatus");
			var aSelDefect = _this.getView().getModel("global").getObject(_this._currentDefectContext.sPath);
			var aDefectStatusFiltered = aDefectStatus.filter(function (status) {
				return status.Key === aSelDefect.DefectType;
			});
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setProperty("/DefectStatus", aDefectStatusFiltered);
			oModel.setProperty("/SelectedKey", aSelDefect.DefectUserStatus);
			_this._oEditStatusDialog.setModel(oModel);
			_this._oEditStatusDialog.open();
		},

		onCancelStatus: function (oEvent) {
			_this._oEditStatusDialog.close();
		},

		onSaveStatus: function (oEvent) {
			var oStatusPayload = {};
			var aSelDefect = _this.getView().getModel("global").getObject(_this._currentDefectContext.sPath);
			oStatusPayload.DefectNo = aSelDefect.DefectNo;
			var sSelectedKey = _this._oEditStatusDialog.getContent()[0].getItems()[0].getSelectedKey();
			var aDefectStatus = _this._oEditStatusDialog.getModel().getProperty("/DefectStatus");
			var aDefectStatusFiltered = aDefectStatus.filter(function (status) {
				return status.Value === sSelectedKey;
			});
			oStatusPayload.Status = aDefectStatusFiltered[0].StatusCode;
			_this.StatusCode = aDefectStatusFiltered[0].StatusCode;
			LocomotiveDataModel.UpdateDefectStatus(_this._updateDefectStatusSuccess, oStatusPayload, _this);
		},

		_updateDefectStatusSuccess: function () {
		
			_this.getView().getModel("global").getObject(_this._currentDefectContext.sPath).DefectUserStatusCode = 	_this.StatusCode;
			_this.getView().getModel("global").refresh();
			_this.getView().getModel("global").updateBindings(true);
			_this._oEditStatusDialog.close();
		},
		//BAJ0018 - START - UPDSTATUS	
		onClickIncidentNumber: function () {
			if (!_this.oIncidentNumberManager) {
				_this.oIncidentNumberManager = IncidentNumberManager.init(_this);
			}

			var oCurrentDefect = _this.getView().getModel().getObject(_this._currentDefectContext.sPath);

			_this.oIncidentNumberManager.onIncidentNumberDialogOpen(oCurrentDefect);
		}

	});
});