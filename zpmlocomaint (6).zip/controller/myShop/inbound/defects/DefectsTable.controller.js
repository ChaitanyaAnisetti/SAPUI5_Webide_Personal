// #DontDelete : Daya New controller class , Do not delete any method in this class
/*&----------------------------------------------------------------------*    
 * Author         : KIR0084                                              *
 * Date           : 2019.04.12                                           *
 * Incidinet      : LMP2-28 - Inbound Changes		              	     *
 * Description    : Add new button press handler for confirm inbound     *
 * Search Term    : LMP2-28                                              *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : SAT0008                                              *
 * Date           : 2019.05.25                                           *
 * Incidinet      : LMP2-12 - Notif Long Text		              	     *
 * Description    : Add long text for the notification                   *                   
 * Search Term    : LMP2-12                                              *
 *&----------------------------------------------------------------------*/
  /*&----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2021.07.26                                           *
 * Description    : LMP-2.28 Update USER STATUS                          *                   
 * Search Term    : UPDSTATUS                                            *
 *&----------------------------------------------------------------------*/
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageBox',
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/controller/map/MapManager",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
	"com/sap/cp/lm/controller/craft/CraftManager",
	"com/sap/cp/lm/controller/locomotives/LocomotiveManager",
	"com/sap/cp/lm/model/craft/CraftDataModel",
	"sap/m/MessageToast",
	// "com/sap/cp/lm/controller/locomotives/WorkOrderManager",
	// "com/sap/cp/lm/controller/locomotives/CommentManager",
	"com/sap/cp/lm/controller/common/ArriveManager",
	"com/sap/cp/lm/controller/myShop/common/AddDefectManager",
	"sap/ui/model/Filter",
	"com/sap/cp/lm/util/Helper",
	"sap/ui/model/FilterOperator",
	"com/sap/cp/lm/util/ErrorManager",
	"com/sap/cp/lm/controller/myShop/common/CloseOutCode",
	"com/sap/cp/lm/controller/myShop/common/IncidentNumberManager"

], function (Controller, MessageBox, Constants, Formatter, MapManager, BusyIndicator, LocomotiveDataModel,
	CraftManager, LocomotiveManager, CraftDataModel, MessageToast, ArriveManager, AddDefectManager, Filter, Helper, FilterOperator,
	ErrorManager, CloseOutCode, IncidentNumberManager) {
	"use strict";

	var _this;

	return Controller.extend(
		"com.sap.cp.lm.controller.myShop.inbound.defects.DefectsTable", {

			/**
			 * Initializes the controller
			 */
			onInit: function () {
				_this = this;

				this.getView().setModel(new sap.ui.model.json.JSONModel());

				this._oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());
				$(window).on('resize', $.proxy(this.handleWindowResize, this));

				this._oGlobalLocomotiveModel = this.getOwnerComponent().getGlobalLocomotiveModel();
				this._oI18nModel = this.getOwnerComponent().getModel("i18n");
				this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
				this.onGlobalModelChange();

				// register to listen to change events of the globalmodel which contain the currentShop
				var binding = new sap.ui.model.Binding(this._oGlobalModel, "/", this._oGlobalModel.getContext("/"));
				binding.attachChange(function () {
					_this.onGlobalModelChange();
				});

				this._oRouter.getTargets().attachDisplay(function (oEvent) {
					if (oEvent.getParameter("name") === "locomotivesInboundHome") {
						_this.oLocomotive = oEvent.getParameter("data");
						_this.getView().getModel().setProperty("/Locomotive", _this.oLocomotive);
						// _this._reloadInboundsLocomotiveDefects();
					}
				});

				var oEventBus = sap.ui.getCore().getEventBus();
				//Start : Added by KIR0084 : Confirm Inbound: LMP2-28
				oEventBus.subscribe("ArriveManager", "confirmInboundLocomotiveDone", _this.refreshLocomotiveHeader, this);
				oEventBus.subscribe("FleetDetails", "cancelInboundLocomotiveDone", _this.refreshLocomotiveHeader, this);
				oEventBus.subscribe("Fleet", "cancelInboundLocomotiveDone", _this.refreshLocomotiveHeader, this);
				//End : Added by KIR0084 : Confirm Inbound: LMP2-28

			},

			/**
			 * reload inbounds locomotives from backend
			 */
			_reloadInboundsLocomotiveDefects: function () {
				if (_this.oLocomotive) {
					LocomotiveDataModel.fetchLocomotiveDefects(_this.oLocomotive, _this._onFetchInboundLocomotiveDefectsSuccess, _this._onFetchInboundLocomotiveDefectsFailed,
						_this);
				}
			},

			fetchLocomotiveDefects: function (oLocomotive) {
				BusyIndicator.showBusyIndicator(); // LMP2-28

				LocomotiveDataModel.fetchLocomotiveDefects(_this.oLocomotive, _this._onFetchInboundLocomotiveDefectsSuccess, _this._onFetchInboundLocomotiveDefectsFailed,
					_this);
			},

			//Added by Sandhya : LMP2-40 : Add NOCO to notification screen
			onNotifComp: function (oEvent) {
				var oPayload = {
					"DefectNumber": _this._currentDefectNo
				};
				LocomotiveDataModel.CompleteNotif(oPayload, _this.onCompleteNotifSuccess, this);

				//	_this.fetchLocomotiveDefects();
				//	_this.getView().getModel().refresh(true);
			},
			onCompleteNotifSuccess: function () {
				_this.fetchLocomotiveDefects();
			},
			//End:Added by Sandhya : LMP2-40 : Add NOCO to notification screen
			/**
			 * Success callback function for readInboundLocomotive
			 */
			_onFetchInboundLocomotiveDefectsSuccess: function (oData) {
				BusyIndicator.hideBusyIndicator();
				var results = oData.results;

				/* manual sorting and grouping */
				var sortedDefects = _this._sortByShops(results);
				_this.getView().getModel().setProperty("/Defects", sortedDefects);
				_this._applyDefectFilter("inboundLocomotiveDefectsList", 1);
				_this._applyDefectFilter("inboundLocomotiveDefectsAllList", 2);
			},

			/**
			 * Apply Filters on Defect list
			 */
			_applyDefectFilter: function (sId, iValue) {
				var oDefectTable = this.getView().byId(sId);
				var oBinding = oDefectTable.getBinding("items");
				var aFilters = [];
				aFilters.push(new Filter("ShopGroup", FilterOperator.EQ, iValue));
				oBinding.filter(aFilters);
			},

			/**
			 * sort defects returned by the server to keep the ones
			 * planned for the current shop at the top of the list
			 */
			_sortByShops: function (oDefects) {
				//assign a ShopGroup id	to separate current shop from all others				
				for (var i = 0; i < oDefects.length; i++) {
					var bHasWorkOrder = true;

					if (oDefects[i].WorkOrderNo === null || oDefects[i].WorkOrderNo.length === 0) {
						bHasWorkOrder = false;
					}

					if (oDefects[i].Shop === _this._currentShop.Id && bHasWorkOrder) {
						oDefects[i].ShopGroup = 1;
					} else {
						oDefects[i].ShopGroup = 2;
					}
				}

				return oDefects;
			},

			/**
			 * Failed callback function for readInboundLocomotive
			 */
			_onFetchInboundLocomotiveDefectsFailed: function (oData) {
				//console.log("_onFetchInboundLocomotiveDefectsFailed");
				BusyIndicator.hideBusyIndicator();
			},

			// Added by Sandhya : LMP2-12  :Inbound Notification Long Text

			onLongTextOpen: function (oEvent) {
				var sBindingPath = oEvent.getSource().getBindingContext().sPath;
				if (sBindingPath) {
					var oDataObject = this.getView().getModel().getObject(sBindingPath);
					if (oDataObject) {
						var oDialog = new sap.m.Dialog({
							title: "Defect Long Text"
						});
					}
					// Helper.openLongTextDialog(oDataObject);

					if (oDataObject.DefectLongText && oDataObject.DefectLongText.length > 0) {
						var longTextContent = new sap.m.HBox({
							width: "100%",
							items: [
								new sap.m.Text({
									text: oDataObject.DefectLongText
								})
							]
						});
					}
					oDialog.addContent(longTextContent);
					oDialog.addButton(new sap.m.Button({
						text: "Ok",
						press: function () {
							oDialog.close();
						}
					}));
					oDialog.setContentHeight("500px");
					oDialog.open();
				}
			},
			// End:Added by Sandhya : LMP2-12		
			/**
			 * when the global model is changed
			 */
			onGlobalModelChange: function () {
				_this._currentShop = this._oGlobalModel.getProperty("/currentShop");

				//TODO : check if this is really needed
				/*
				var tempCurrentRole = this._oGlobalModel.getProperty("/role");
				// check if the currentRole is different and if so reload the map
				if (tempCurrentRole && tempCurrentRole !== this.sRole){
					this.sRole = tempCurrentRole;
					var sRoleModel =  new sap.ui.model.json.JSONModel();
					sRoleModel.setProperty("/SelectedRole", this.sRole); 
					this.getView().setModel(sRoleModel ,"Role");
					if (this.sLocomotiveId){
						BusyIndicator.showBusyIndicator();
						LocomotiveDataModel.fetchLocomotiveDetails(this.loadData, this.onloadDataError, this, this.sLocomotiveId);
					}				
				}
				*/
			},

			/**
			 * sets height of the shop page
			 */
			handleWindowResize: function () {

			},

			/**
			 * defects header factory
			 */

			getDefectsGroupHeader: function (oGroup) {
				return new sap.m.GroupHeaderListItem({
					title: oGroup.text,
					upperCase: false
				});
			},

			/**
			 * defects grouper 
			 * custom grouper for the xml list
			 */
			defectsGrouper: function (oContext) {
				var sShopGroup = oContext.getProperty("ShopGroup");

				var sText = this._oI18nModel.getProperty("WORK_PLANNED_TO_BE_COMPLETE");
				if (sShopGroup === 2) {
					sText = this._oI18nModel.getProperty("ALL_WORK");
				}
				return {
					key: sShopGroup,
					text: sText
				};
			},

			/**
			 * defects defering 
			 */
			onOpenPlannedWorkActionSheet: function (oEvent) {

				var oButton = oEvent.getSource();

				//identify current defect number
				_this._currentDefectNo = oButton.getCustomData()[0].getValue();
				_this._currentDefectDescr = oButton.getCustomData()[1].getValue();
				_this._ShopGroup = oButton.getCustomData()[2].getValue();
				_this._currentDefectContext = oEvent.getSource().getBindingContext();

				// create action sheet only once
				if (!_this._oActionSheet) {
					_this._oActionSheet = sap.ui.xmlfragment(
						"com.sap.cp.lm.view.myShop.inbound.defects.PlannedWorkActionSheet",
						_this
					);
					_this.getView().addDependent(_this._oActionSheet);
				}
				// Start - SHE0272 - INC0099624	Notification is not refreshing on switching page
				var WorkActionModel = new sap.ui.model.json.JSONModel();
				WorkActionModel.setProperty("/", _this._currentDefectContext.getObject());
				_this._oActionSheet.setModel(WorkActionModel, "WorkActionModel");
				// End - SHE0272 - INC0099624	Notification is not refreshing on switching page
				_this._oActionSheet.setBindingContext(_this._currentDefectContext);

				_this._oActionSheet.openBy(oButton);
			},

			onDeferDefect: function (oEvent) {

				var aSelDefect = _this.getView().getModel().getObject(_this._currentDefectContext.sPath);

				var sDefectNo = aSelDefect.DefectNo;
				var sDefectDescr = aSelDefect.DefectDescr;

				if (sDefectNo) {
					var deferalCodes = _this._oGlobalModel.getProperty("/DeferalCodes");
					var defaultDeferalCodeValue = _this._oGlobalModel.getProperty("/DefaultDeferalCodeValue");

					var allShops = _this._oGlobalModel.getProperty("/Shops");
					var currentShop = _this._oGlobalModel.getProperty("/currentShop");
					var shops = [];

					//cannot defer to itself -> filter out current shop
					for (var i = 0; i < allShops.length; i++) {
						if (allShops[i].Id !== currentShop.Id) {
							shops.push(allShops[i]);
						}
					}

					if (deferalCodes && shops) {
						if (!_this._oDeferDefectDialog) {
							_this._oDeferDefectDialog = sap.ui.xmlfragment(
								"com.sap.cp.lm.view.myShop.common.DeferDefectDialog",
								_this
							);
						}

						if (_this._oDeferDefectDialog) {
							var oModel = new sap.ui.model.json.JSONModel();
							oModel.setProperty("/DefaultDeferalCodeValue", defaultDeferalCodeValue);
							oModel.setProperty("/DeferalCodes", deferalCodes);
							oModel.setProperty("/Shops", shops);
							oModel.setProperty("/Title", sDefectDescr);
							_this._oDeferDefectDialog.setModel(oModel);
						}

						_this._oDeferDefectDialog.setBindingContext(_this._currentDefectContext);
						_this.getView().addDependent(_this._oDeferDefectDialog);

						_this._resetDialog();

						_this._oDeferDefectDialog.open();
					}
				}
			},

			_resetDialog: function () {
				var oContent = _this._oDeferDefectDialog.getContent();
				var aItems = oContent[0].getItems();

				aItems[4].setValue("");
				aItems[6].setSelectedKey(null);
			},

			onDeferDefectDialogCancel: function (oEvent) {
				this._oDeferDefectDialog.close();
			},

			onDeferDefectDialogOk: function (oEvent) {
				var oContent = oEvent.getSource().getParent().getContent();
				var aItems = oContent[0].getItems();

				var sDeferCode = aItems[2].getSelectedKey();
				var sDeferDescr = aItems[4].getValue();
				var sShop = aItems[6].getSelectedKey();

				var sDefectNo = _this._currentDefectNo;

				if (sDefectNo) {
					if (sDeferCode && sDeferCode.length > 0) {
						if (sShop && sShop.length > 0) {
							var oPayload = {
								"DefectNo": sDefectNo,
								"DeferCode": sDeferCode,
								"DeferDescr": sDeferDescr,
								"Shop": sShop
							};

							LocomotiveDataModel.deferInboundLocomotiveDefect(oPayload, _this._editInboundLocomotiveDefectSuccess, _this._editInboundLocomotiveDefectFailed,
								this);

						} else {
							var msg = this._oI18nModel.getProperty("PLEASE_SELECT_SHOP");
							ErrorManager.handleError("", msg);
						}
					} else {
						var msg = this._oI18nModel.getProperty("PLEASE_SELECT_DEFERAL_CODE");
						ErrorManager.handleError("", msg);
					}
				} else {
					var msg = this._oI18nModel.getProperty("INVALID_DEFECT_NUMBER");
					ErrorManager.handleError("", msg);
				}

			},

			_editInboundLocomotiveDefectSuccess: function (oData) {
				_this._reloadInboundsLocomotiveDefects();

				if (this._oDeferDefectDialog && this._oDeferDefectDialog.isOpen()) {
					this._oDeferDefectDialog.close();
				}
			},

			_editInboundLocomotiveDefectFailed: function (oData) {
				if (this._oDeferDefectDialog && this._oDeferDefectDialog.isOpen()) {
					this._oDeferDefectDialog.close();
				}
			},

			onPressCloseOutCode: function (oEvent) {
				var aData = {};
				aData.sDefectNo = _this._currentDefectNo;
				aData.oController = this;
				aData.oGlobalModel = _this._oGlobalModel;
				aData.oSelectedContext = this._currentDefectContext;
				aData.oSourceViewModel = this.getView().getModel();
				aData.bfromDefectView = true;
				aData.bfromWorkPlanView = false;
				_this._oCloseOutCodeDialog = new CloseOutCode(aData);
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), _this._oCloseOutCodeDialog);
				_this._oCloseOutCodeDialog.getFragment().setContentWidth("60%");
				_this._oCloseOutCodeDialog.getFragment().open();
			},

			onEditDefectLongText: function (oEvent) {
				if (!_this._oLongtextDialog) {
					_this._oLongtextDialog = sap.ui.xmlfragment(
						"com.sap.cp.lm.view.myShop.inbound.defects.DefectLongText",
						_this
					);
				}

				// _this._oLongtextDialog.setBindingContext(_this._currentDefectContext);
				_this._oLongtextDialog.getContent()[0].getItems()[0].setValue(_this.getView().getModel().getObject(_this._currentDefectContext.sPath)
					.DefectLongText);
				_this.getView().addDependent(_this._oCloseOutCodeDialog);
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), _this._oLongtextDialog);
				_this._oLongtextDialog.setContentWidth("40%");
				_this._oLongtextDialog.open();
			},

			onSaveLongText: function (oEvent) {
				var oDefectPayload = this._getselectedDefectPayload(_this._currentDefectContext);
				oDefectPayload.DefectLongText = oEvent.getSource().getParent().getContent()[0].getItems()[0].getValue();
				LocomotiveDataModel.UpdateDefect(_this._updateDefectLongtextSuccess, oDefectPayload, _this);
			},

			onClickEditShortText: function (oEvent) {
				var oShortTextField = oEvent.getSource().getParent().getParent().getItems()[0].getItems()[0];
				if (oShortTextField.getEnabled()) {
					this.onSaveShortText(oEvent.getSource().getBindingContext());
				}
				oShortTextField.setEnabled(!oShortTextField.getEnabled());
			},

			onSaveShortText: function (oContext) {
				var oDefectPayload = this._getselectedDefectPayload(oContext);
				LocomotiveDataModel.UpdateDefect("", oDefectPayload, _this);
			},

			_getselectedDefectPayload: function (oContext) {
				var oDefectPayload = {};
				var aSelDefect = _this.getView().getModel().getObject(oContext.sPath);

				oDefectPayload.EquipNo = aSelDefect.EquipNo;
				oDefectPayload.WorkOrderNo = aSelDefect.WorkOrderNo;
				oDefectPayload.DefectLongText = aSelDefect.DefectLongText;
				oDefectPayload.FunctionalLoc = aSelDefect.FunctionalLoc;
				oDefectPayload.DefectNo = aSelDefect.DefectNo;
				oDefectPayload.DefectType = aSelDefect.DefectType;
				oDefectPayload.DefectDescr = aSelDefect.DefectDescr;
				oDefectPayload.Shop = aSelDefect.Shop;
				oDefectPayload.PlanDefectDur = aSelDefect.PlanDefectDur;
				oDefectPayload.PlanDefectUnit = aSelDefect.PlanDefectUnit;
				oDefectPayload.MandatoryDefect = aSelDefect.MandatoryDefect;
				oDefectPayload.NearingDueDate = aSelDefect.NearingDueDate;
				oDefectPayload.ReqStartTs = aSelDefect.ReqStartTs;
				oDefectPayload.ReqStartTz = aSelDefect.ReqStartTz;
				oDefectPayload.ObjectNo = aSelDefect.ObjectNo;
				oDefectPayload.DefectLongText = aSelDefect.DefectLongText;
				return oDefectPayload;
			},
			//BAJ0018 - START - UPDSTATUS
			onEditStatus: function (oEvent) {
				if (!_this._oEditStatusDialog) {
					_this._oEditStatusDialog = sap.ui.xmlfragment(
						"com.sap.cp.lm.view.myShop.inbound.defects.Status",
						_this
					);
				}
				var aDefectStatus = _this._oGlobalModel.getProperty("/DefectStatus");
				var aSelDefect = _this.getView().getModel().getObject(_this._currentDefectContext.sPath);
				var aDefectStatusFiltered = aDefectStatus.filter(function (status) {
					return status.Key === aSelDefect.DefectType;
				});
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setProperty("/DefectStatus", aDefectStatusFiltered);
				oModel.setProperty("/SelectedKey", aSelDefect.DefectUserStatus);
				_this._oEditStatusDialog.setModel(oModel);
				_this._oEditStatusDialog.open();
			},

			onCancelStatus: function (oEvent) {
				_this._oEditStatusDialog.close();
			},

			onSaveStatus: function (oEvent) {
				var oStatusPayload = {};
				var aSelDefect = _this.getView().getModel().getObject(_this._currentDefectContext.sPath);
				oStatusPayload.DefectNo = aSelDefect.DefectNo;
				var sSelectedKey = _this._oEditStatusDialog.getContent()[0].getItems()[0].getSelectedKey();
				var aDefectStatus = _this._oEditStatusDialog.getModel().getProperty("/DefectStatus");
				var aDefectStatusFiltered = aDefectStatus.filter(function (status) {
					return status.Value === sSelectedKey;
				});
				oStatusPayload.Status = aDefectStatusFiltered[0].StatusCode;
				_this.StatusCode = aDefectStatusFiltered[0].StatusCode;
				LocomotiveDataModel.UpdateDefectStatus(_this._updateDefectStatusSuccess, oStatusPayload, _this);
			},

			_updateDefectStatusSuccess: function () {

				_this.getView().getModel().getObject(_this._currentDefectContext.sPath).DefectUserStatusCode = _this.StatusCode;
				_this.getView().getModel().refresh();
				_this.getView().getModel().updateBindings(true);
				_this._oEditStatusDialog.close();
			},
			//BAJ0018 - START - UPDSTATUS	

			_updateDefectLongtextSuccess: function () {
				_this.getView().getModel().getObject(_this._currentDefectContext.sPath).DefectLongText = _this._oLongtextDialog.getContent()[0].getItems()[
					0].getValue();
				_this._oLongtextDialog.close();
			},

			onCancelLongText: function (oEvent) {
				_this._oLongtextDialog.close();
			},

			onAddToPlan: function (oEvent) {
				var oContext = oEvent.getSource().getParent().getBindingContext();
				var oDefect = oContext.oModel.getProperty(oContext.sPath);

				if (oDefect.WorkOrderNo && oDefect.WorkOrderNo.length > 0) {
					_this.doAddToPlan(oDefect);
				} else {
					_this.openOrderTypeDialog(oDefect);
				}
			},

			doAddToPlan: function (oDefect) {
				var oShop = _this._oGlobalModel.getProperty("/currentShop");

				var oPayload = {
					"DefectNo": oDefect.DefectNo,
					"ShopId": oShop.Id,
					"OrderType": oDefect.OrderType
				};

				LocomotiveDataModel.adoptInboundLocomotiveDefect(oPayload, _this._editInboundLocomotiveDefectSuccess, _this._editInboundLocomotiveDefectFailed,
					_this);
			},

			filterOrderTypes: function (oDefect) {
				var sDefectType = oDefect.DefectType;
				var aFiltered = [];
				var aDefectToOrderTypes = _this._oGlobalModel.getProperty("/DefectToOrderTypes");
				for (var i = 0; i < aDefectToOrderTypes.length; i++) {
					var defectToOrderType = aDefectToOrderTypes[i];
					if (defectToOrderType.Key === sDefectType) {
						aFiltered.push(defectToOrderType);
					}
				}
				return aFiltered;
			},

			openOrderTypeDialog: function (oDefect) {
				var aDefectToOrderTypes = _this.filterOrderTypes(oDefect);

				if (!_this.orderTypeDialog) {
					_this.orderTypeDialog = sap.ui.xmlfragment(
						"com.sap.cp.lm.view.myShop.inbound.defects.AddToPlanDialog",
						_this
					);
				}

				if (_this.orderTypeDialog) {
					var oModel = new sap.ui.model.json.JSONModel();
					oModel.setProperty("/DefectToOrderTypes", aDefectToOrderTypes);
					oModel.setProperty("/Defect", oDefect);
					_this.orderTypeDialog.setModel(oModel);
				}

				_this.getView().addDependent(_this.orderTypeDialog);

				_this.orderTypeDialog.open();
			},

			onOrderTypeDialogCancel: function (oEvent) {
				var oOrderTypeDialogSelect = sap.ui.getCore().byId('orderTypeDialogSelect');
				oOrderTypeDialogSelect.clearSelection();

				_this.orderTypeDialog.close();
			},

			onOrderTypeDialogDone: function (oEvent) {

				var oOrderTypeDialogSelect = sap.ui.getCore().byId('orderTypeDialogSelect');
				var sOrderType = oOrderTypeDialogSelect.getSelectedKey();

				var oDefect = oEvent.getSource().getParent().getModel().getProperty("/Defect");

				oDefect.OrderType = sOrderType;

				_this.doAddToPlan(oDefect);

				oOrderTypeDialogSelect.clearSelection();

				_this.orderTypeDialog.close();
			},

			/***
			 * Open add defect dialog
			 */
			onAddDefect: function (oData) {
				if (!_this.oAddDefectManager) {
					_this.oAddDefectManager = AddDefectManager.init(_this, _this._onAdddefectSuccess);
				}

				_this.oAddDefectManager.onAddAffectDialogOpen("DEFECT");
			},

			_onAdddefectSuccess: function () {
				_this._reloadInboundsLocomotiveDefects();
				if (_this._oGlobalModel.getProperty("/sSelectedView") === Constants.LOCOMOTIVES) {
					var oMasterController = _this._oGlobalModel.getProperty("/locomotiveMasterController");
					oMasterController.onRefreshMasterList();
				}
			},

			/***
			 * Start Arrive process dialog for shopped locomotive
			 */
			onPreShopLocomotivePress: function (oData) {
				var defects = _this.getView().getModel().getProperty("/Defects");

				if (!_this.oArriveManager) {
					_this.oArriveManager = ArriveManager.init("defectsTable", "shopped");
				}

				var oShop = _this._oGlobalModel.getProperty("/currentShop");
				var oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
				_this.oArriveManager.setType("shopped");
				_this.oArriveManager.onArriveProcessDialogOpen(defects, oShop, oLocomotive, _this);
			},

			/***
			 * Start Arrive process dialog for serviced locomotive
			 */
			onPreServiceLocomotivePress: function (oData) {
				if (!_this.oArriveManager) {
					_this.oArriveManager = ArriveManager.init("defectsTable", "service");
				}

				var oShop = _this._oGlobalModel.getProperty("/currentShop");
				var oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
				_this.oArriveManager.setType("service");

				// LMP2-30 KIR0084 Pass in locomotive defects
				var defects = _this.getView().getModel().getProperty("/Defects");
				_this.oArriveManager.onArriveProcessDialogOpen(defects, oShop, oLocomotive, _this);
			},

			/***
			 * handle incident button
			 */
			onClickIncidentNumber: function () {
				if (!_this.oIncidentNumberManager) {
					_this.oIncidentNumberManager = IncidentNumberManager.init(_this);
				}

				var oCurrentDefect = _this.getView().getModel().getObject(_this._currentDefectContext.sPath);

				_this.oIncidentNumberManager.onIncidentNumberDialogOpen(oCurrentDefect);
			},

			/* Start LMP2-28: Confirm Inbound - Add onFleetConfirmInbound Handler and refactor onFleetArrive for code re-use */
			/**
			 * Start confirm inbound locomotive process from anywhere to shop
			 */
			onInboundDetailsConfirmInbound: function (oEvent) {
				_this.oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");

				if (_this.oLocomotive) {
					LocomotiveDataModel.fetchLocomotiveDefects(_this.oLocomotive, _this._onFetchLocomotiveDefectsSuccessForConfirmInbound, undefined,
						_this);
				}
			},

			/**
			 * Instantiate an arrival dialog manager for the type of action passed in as a parameter
			 */
			_onFetchLocomotiveDefectsSuccess: function (oData, type) {
				BusyIndicator.hideBusyIndicator();
				var results = oData.results;

				if (!_this.oArriveManager) {
					_this.oArriveManager = ArriveManager.init("inboundDetails", type);
				}

				var oShop = _this._oGlobalModel.getProperty("/currentShop");
				_this.oArriveManager.setType(type);
				_this.oArriveManager.onArriveProcessDialogOpen(results, oShop, _this.oLocomotive, _this);
			},

			/**
			 * Success callback function for onFleetArrive
			 */
			_onFetchLocomotiveDefectsSuccessForArrive: function (oData) {
				this._onFetchLocomotiveDefectsSuccess(oData, "shopped");
			},

			/**
			 * Success callback function for onFleetConfirmInbound
			 */
			_onFetchLocomotiveDefectsSuccessForConfirmInbound: function (oData) {
				this._onFetchLocomotiveDefectsSuccess(oData, "confirmInbound");
			},
			/* End LMP2-28: Confirm Inbound - Add onFleetConfirmInbound Handler and refactor onFleetArrive for code re-use */

			/* Start LMP2-28: Confirm Inbound - Add onFleetCancelInbound Handler */
			/**
			 * Cancel the inbound action for a plant
			 */
			onInboundDetailsCancelInbound: function (oEvent) {
				_this.oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");

				if (_this.oLocomotive) {
					MessageBox.show("Are you sure you want to cancel the Inbound Confirmation?", {
						icon: MessageBox.Icon.CONFIRM,
						title: "Cancel Inbound Confirmation",
						actions: [MessageBox.Action.CANCEL, MessageBox.Action.OK],
						onClose: function (oEvent) {
							if (oEvent === MessageBox.Action.OK) {
								LocomotiveDataModel.cancelInboundConfirmation({
									LocoId: _this.oLocomotive.LocomotiveId,
									ShopId: _this.oLocomotive.InboundShop
								}, function (oEvent) {
									var oEventBus = sap.ui.getCore().getEventBus();
									oEventBus.publish("InboundDetails", "cancelInboundLocomotiveDone", {
										"origin": _this.origin,
										"locomotive": _this.oLocomotive,
										"success": true
									});
								}, undefined, _this);
							}
						}.bind(this)
					});
				}
			},
			/* End LMP2-28: Confirm Inbound - Add onFleetCancelInbound Handler */

			/* Start LMP2-28: Confirm Inbound - Add refresh Locomotive header function */
			refreshLocomotiveHeader: function (sChannel, oEvent, oData) {
				_this.oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");

				if (_this.oLocomotive && oData && oData.locomotive && _this.oLocomotive.LocomotiveId === oData.locomotive.LocomotiveId) {
					LocomotiveDataModel.fetchLocoHeader(_this._fetchLocoHeaderSuccess, undefined, _this, {
						Equipment: _this.oLocomotive.Equipment || _this.oLocomotive.EquipNbr
					});
				}
			},

			_fetchLocoHeaderSuccess: function (oData) {
					_this._oGlobalModel.setProperty("/currentLocomotive", oData);
				}
				/* End LMP2-28: Confirm Inbound - Add refresh Locomotive header function */

		});
});