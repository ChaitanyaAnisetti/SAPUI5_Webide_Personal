/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.06                                           *
* Project        : Locomotive Maintenance                               *
* Description    : This controller is associated to the Inboud view     *
*                  displayed only when there is no selected locomotive. *
*&----------------------------------------------------------------------*/


sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/BusyIndicator",
	
], function(Controller, Constants, BusyIndicator) {
	"use strict";
	var _this;
	return Controller.extend("com.sap.cp.lm.controller.myShop.inbound.InboundBlankDetails", {

		/**
		 * Function is called when Controller is loaded only for the first time 
		 */
		onInit: function() {
			
		}
	
	});
});