/*&----------------------------------------------------------------------*    
* Author/Changed By   : Sandhya satavalekar                              *
* Date                : 17-May-2019                                      *
* Project             : Locomotive Maintenance Phase 2                   *
* Description         : LMP2-03 : Notification History Tab 	             *
* Search Term         : LMP2-03                                          *
*&-----------------------------------------------------------------------*/ 
/*&----------------------------------------------------------------------*    
* Author/Changed By   : Sandesh Shirode                         		 *
* Date                : 07-August-2019                                   *
* Project             : Locomotive Maintenance Phase 2                   *
* Description         : Notification History Tab 	            		 *
* Search Term         : Defect - 173                                     *
*&-----------------------------------------------------------------------*/ 
/* #DontDelete : Yann */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/controller/map/MapManager",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
	"com/sap/cp/lm/controller/craft/CraftManager",
	"com/sap/cp/lm/controller/locomotives/LocomotiveManager",
	"com/sap/cp/lm/model/craft/CraftDataModel",
	"sap/m/MessageToast"
	//"com/sap/cp/lm/controller/locomotives/WorkOrderManager",
	//"com/sap/cp/lm/controller/locomotives/CommentManager"

], function(Controller, Constants, Formatter, MapManager, BusyIndicator, LocomotiveDataModel, CraftManager, LocomotiveManager,
	CraftDataModel, MessageToast) {
	"use strict";

	var _this;

	return Controller.extend(
		"com.sap.cp.lm.controller.myShop.inbound.InboundContainer", {

			/**
			 * Initializes the controller
			 */
			onInit: function() {
				_this = this;
				_this.getView().setModel(new sap.ui.model.json.JSONModel());
				_this._oI18nModel = _this.getOwnerComponent().getModel("i18n");
				_this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
				_this._oRouter = sap.ui.core.UIComponent.getRouterFor(_this.getView());
				$(window).on('resize', $.proxy(this.handleWindowResize, this));
				_this._oRouter.getTargets().attachDisplay(function(oEvent) {
					if (oEvent.getParameter("name") === "locomotivesInboundHome") {
						_this._oGlobalModel.setProperty("/isShopped", false);
						_this._oGlobalModel.setProperty("/isServiced", false);

						_this.oLocomotive = oEvent.getParameter("data");
						_this.getView().getModel().setProperty("/Locomotive", _this.oLocomotive);
						var sKey = _this.getView().byId("MyShopDetailPageTabBar").getSelectedKey();
						_this._processSelectedTab(sKey);
					}
				});

				BusyIndicator.hideBusyIndicator();
			},

			/**
			 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
			 * This hook is the same one that SAPUI5 controls get after being rendered.
			 */
			onAfterRendering: function() {

			},

			/**
			 * Handles selection of Icon Tab Bar
			 * @params(event) oEvent is returned on
			 * 				  icon tab bar selection changes
			 */
			onIconSelect: function(oEvent) {
				var sKey = oEvent.getParameters().key;
				this._processSelectedTab(sKey);
			},

			addContentIconTabFilter: function(sIdFilter, sView) {

				var oView = this.getOwnerComponent().runAsOwner(function() {
					return sap.ui.view({

						viewName: sView,
						type: sap.ui.core.mvc.ViewType.XML
					});
				});

				oView.setModel(_this._oI18nModel, "i18n");
				
				this.byId(sIdFilter).destroyContent();
				this.byId(sIdFilter).addContent(oView);
				

				return oView.getController();
			},

			_processSelectedTab: function(sKey) {
				BusyIndicator.hideBusyIndicator();
				if (sKey === "history") {
					this._oGlobalModel.setProperty("/readOnlyWorkPlan", true);
					_this._oGlobalModel.setProperty("/readFromWorkPlan", false); //Added by Sandhya LMP2-3
					_this._oGlobalModel.setProperty("/readFromWOHistory", true); //Added by Sandhya LMP2-3
					_this.addContentIconTabFilter("idFilterInboundWOHistory", "com.sap.cp.lm.view.common.workOrderHistory.WorkOrderHistory").fetchWOHistory();

				}
		 //Start : Added by Sandesh : Defect 173
			if (sKey === "notifhistory") {
				// _this._oGlobalModel.setProperty("/workplanFooterIsVisible", false);
				_this._oGlobalModel.setProperty("/readOnlyWorkPlan", true);
				_this._oGlobalModel.setProperty("/readFromWOHistory", true); //Added by Sandhya LMP2-3
				_this._oGlobalModel.setProperty("/readFromWorkPlan", false); //Added by Sandhya LMP2-3
				_this._oGlobalModel.setProperty("/readFromNotifHistory", true); //Added by Sandhya LMP2-3
				_this.addContentIconTabFilter("idFilterNotifHistory", "com.sap.cp.lm.view.common.NotificationHistory.NotificationHistory").fetchNotifHistory();
			}
		//End:Added by Sandesh : Defect 173
		
				if (sKey === "defects") {
					this.byId("InBoundDefects").getController().fetchLocomotiveDefects(_this.oLocomotive);
				}
				if (sKey === "wheelSheetHistory") {
					// this.byId("InboundWheelHistory").getController().fetchLocomotiveWheelSheetHistory();
					_this.addContentIconTabFilter("idFilterInboundWheelHistory", "com.sap.cp.lm.view.myShop.common.wheelSheet.WheelSheetHistory").fetchLocomotiveWheelSheetHistory();
					
				}
				if (sKey === "details") {
					// this.byId("InboundDetails").getController().fetchLocomotiveDetails();
					_this.addContentIconTabFilter("idFilterInboundDetails", "com.sap.cp.lm.view.myShop.common.details.Details").fetchLocomotiveDetails();

				}

			},

			handleWindowResize: function() {}
		});
});