/*&---------------------------------------------------------------------*    
 * Author         : SAP Custom Development                               *
 * Date           : 2017.12.21                                           *
 * Project        : Locomotive Maintenance                               *
 * Description    : Controller for the My Work Centers fragment.         *
 *                  Hook methods of view life cycle can be implemented   *
 *                  for fragment life cycle.                             *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------
/* Author         : Sandesh Shirode                                     *
* Date            : 2018.03.16                                          *
* Incident		  : IM249662                            				*
* Description     : Increase the default model size to 300				*
*&----------------------------------------------------------------------*/
/* Author         : Ibrahim Jadalowen (JAD0007)                         *
 * Date            : 2019.10.31                                          *
 * Incident		  : Project                              				*
 * Description     : Show the Defect Monitor Code on screen.				*
 *                   Restrict drop values using Defect Monitor Codes.    *
 *&----------------------------------------------------------------------*/
/* Author         : Vikram Bajaj                                        *
 * Date            : 2020.08.18                                          *
 * Incident		   : EAM-ASR3415679                        				*
 * Description     : Revised logic for defect codes drop down    		*
 *&----------------------------------------------------------------------*/
 /*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 08-Sep-2021	                                       *
* Project             : Locomotive Maintenance Phase 2                     *
* Description         : Refresh issue with cross navigation		           *
* Search Term         : INC0110700                                         *
/*&------------------------------------------------------------------------*/
// #DontDelete : Daya New controller class , Do not delete any method in this class

sap.ui.define([
		"com/sap/cp/lm/controller/common/FragmentBaseDelegate",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel"
	], function (BaseDelegate, BusyIndicator, LocomotiveDataModel) {
		"use strict";
		var _DefectMonitorCode;
		var _DefectMonitorValue;
		var _gCompGroupDD;
		return BaseDelegate.extend("com.sap.cp.lm.controller.myShop.common.CloseOutCode", {

			_sFragmentName: "com.sap.cp.lm.view.myShop.common.closeOutCodes.COCCodeList",
			_sDefectNo: null,
			_oGlobalModel: null,
			_oI18nModel: null,
			_bfromDefectView: false,
			_bfromWorkPlanview: false,
			_oSourceViewModel: null,
			_oSelectedContext: null,
			/**
			 * Fragment Initialization method
			 * 
			 */
			onInit: function () {
				BusyIndicator.showBusyIndicator();
				this._initParameters();
				LocomotiveDataModel.fetchDefectCloseOutCodes(this._fnsucessCloseoutCodeFetch, "", this, this._sDefectNo);
				// jad0007	start
				_DefectMonitorCode = "";
				_DefectMonitorValue = "";
				_gCompGroupDD = {};
				//jad0007 end
			},

			_initParameters: function () {
				this._sDefectNo = this.oParameters.sDefectNo;
				this._oGlobalModel = this.oParameters.oGlobalModel;
				this._oI18nModel = this.oParameters.oI18nModel;

				this._oSelectedContext = this.oParameters.oSelectedContext;
				this._bfromDefectView = this.oParameters.bfromDefectView;
				this._bfromWorkPlanview = this.oParameters.bfromWorkPlanView;
				this._oSourceViewModel = this.oParameters.oSourceViewModel;

				this.cocController = this.oParameters.oController; //jad0007
			},

			_fnsucessCloseoutCodeFetch: function (oResponse) {
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setProperty("/CloseOutCodesSet", oResponse.CloseOutCodes.results);
				//BAJ0018 - EDIT close out code functionality
				this._oGlobalModel.setProperty("/CloseOutCodesSet1", oResponse.CloseOutCodes.results);
				if (oResponse.CloseOutCodes.results[0]) {
					oModel.setProperty("/CloseOutCodesActionText", 'Edit Close Out Code');
				} else {
					oModel.setProperty("/CloseOutCodesActionText", 'Add Close Out Code');
				}
				//BAJ0018 - EDIT close out code functionality
				//jad0007 start
				var aDefectMonitorCodes = this._oGlobalModel.getProperty("/DefectMonitorCodes");
				oModel.setProperty("/DefectMonitorCodes", aDefectMonitorCodes);
				var oDefectPayload = {};

				oDefectPayload = this._getselectedDefectPayload(this._oSelectedContext);
				_DefectMonitorCode = oDefectPayload.DefectMonitorCode;
				var aDefectMonitorDescr = _DefectMonitorCode;
				if (_DefectMonitorCode) {
					var aLength = aDefectMonitorCodes.length;
					for (var i = 0; i < aLength; i++) {
						if (aDefectMonitorCodes[i].Value === _DefectMonitorCode) {
							aDefectMonitorDescr = _DefectMonitorCode + " " + aDefectMonitorCodes[i].Text;
							break;
						}
					}
				}

				oModel.setProperty("/DefectDescr", oDefectPayload.DefectDescr);
				oModel.setProperty("/DefectMonitorDescr", aDefectMonitorDescr);

				//Make it visible for Z2 defects only.
				if (oDefectPayload.DefectType === 'Z2') {
					oModel.setProperty("/DMCVisible", true);
				} else {
					oModel.setProperty("/DMCVisible", false);
				}
				oModel.setSizeLimit(500);
				//jad0007 end
				oModel.setProperty("/Title", 'Close Out Codes');
				this.getFragment().setModel(oModel);
				BusyIndicator.hideBusyIndicator();
				// Load the Drop down values, and filter by Defect Monitor Code
				if (_DefectMonitorCode > 0) {
					var sQuery = "Usage eq 'COMP_GROUP' and Key eq'" + _DefectMonitorCode + "'";
					LocomotiveDataModel.getDropDown(sQuery, this._onfetchCompGroupSuccess, this);
				}
			},

			_fnsucessCloseoutCodeFetchaftercreate: function (oData) {
				this.getFragment().getModel().setProperty("/CloseOutCodesSet", oData.CloseOutCodes.results);
				//BAJ0018 - EDIT close out code functionality
				if (oData.CloseOutCodes.results[0]) {
					this.getFragment().getModel().setProperty("/CloseOutCodesActionText", 'Edit Close Out Code');
					this._oGlobalModel.setProperty("/CloseOutCodesSet1", oData.CloseOutCodes.results);
				}
				//BAJ0018 - EDIT close out code functionality
				BusyIndicator.hideBusyIndicator();
				this.getFragment().getModel().refresh(true);
			},

			onCloseOutCodeListClose: function (Oevent) {
				this.getFragment().close();
			},
			// jad0007 start
			onChangeDefectMonitorCode2: function (oEvent) {
				var oValidatedComboBox = oEvent.getSource(),
					sSelectedKey = oValidatedComboBox.getSelectedKey(),
					sValue = oValidatedComboBox.getValue();
				_DefectMonitorCode = sSelectedKey;
				_DefectMonitorValue = sValue;

				if (!sSelectedKey && sValue) {
					oValidatedComboBox.setValueState("Error");
					oValidatedComboBox.setValueStateText("Please enter a valid Defect Code!");
				} else {
					oValidatedComboBox.setValueState("None");

					BusyIndicator.resetBusyIndicator();
					BusyIndicator.showBusyIndicator();
					var sQuery = "Usage eq 'COMP_GROUP' and Key eq'" + _DefectMonitorCode + "'";
					LocomotiveDataModel.getDropDown(sQuery, this._onfetchCompGroupSuccess, this);
				}
			},
			// jad0007 end
			onAddCloseOutCode: function (oEvent) {
				var aDefectMonitorDescr;
				var oDefectPayload = this._getselectedDefectPayload(this._oSelectedContext); //jad0007

				if (_DefectMonitorValue !== "") {
					aDefectMonitorDescr = _DefectMonitorValue; //jad0007
				} else if (_DefectMonitorCode !== "") {
					aDefectMonitorDescr = _DefectMonitorCode; //jad0007
				} else {
					aDefectMonitorDescr = oDefectPayload.DefectMonitorCode; //jad0007
				}
				if (_DefectMonitorCode === "") {
					_DefectMonitorCode = oDefectPayload.DefectMonitorCode;
				}
				var aDefectMonitorCodes = this._oGlobalModel.getProperty("/DefectMonitorCodes");

				if (_DefectMonitorCode) {
					var aLength = aDefectMonitorCodes.length;
					for (var i = 0; i < aLength; i++) {
						if (aDefectMonitorCodes[i].Value === _DefectMonitorCode) {
							aDefectMonitorDescr = _DefectMonitorCode + " " + aDefectMonitorCodes[i].Text;
							break;
						}
					}
				}

				var aCompGroupDD;
				aCompGroupDD = this._oGlobalModel.getProperty("/CompGroupDD");
				if (_gCompGroupDD.length > 0) {
					aCompGroupDD = _gCompGroupDD;
				}
				var aCompLocGrpDD = this._oGlobalModel.getProperty("/CompLocGrpDD");

				var aDefectCodeDD = this._oGlobalModel.getProperty("/DefectCodeDD");
				if (!this._AddCOCDialog) {
					this._AddCOCDialog = sap.ui.xmlfragment(
						"com.sap.cp.lm.view.myShop.common.closeOutCodes.COCForm",
						this
					);
				}

				if (this._AddCOCDialog) {
					var oModel = new sap.ui.model.json.JSONModel();
					oModel.setSizeLimit(300); // Incident - IM249662
					oModel.setProperty("/CompGroupDD", aCompGroupDD);
					oModel.setProperty("/CompLocGrpDD", aCompLocGrpDD);
					oModel.setProperty("/DefectCodeDD", aDefectCodeDD);
					oModel.setProperty("/defectMonitorDescr", aDefectMonitorDescr);
					oModel.setProperty("i18n", this._oI18nModel);
					//BAJ0018 - EDIT close out code functionality
					if (this._oGlobalModel.getProperty("/CloseOutCodesSet1")[0]) {
						//oModel.setProperty("/CompGroupDDKey", this._oGlobalModel.getProperty("/CloseOutCodesSet1")[0].CompGrp);
						oModel.setProperty("/DefectCodeDDKey", this._oGlobalModel.getProperty("/CloseOutCodesSet1")[0].CauseCd);
						oModel.setProperty("/Text", this._oGlobalModel.getProperty("/CloseOutCodesSet1")[0].CauseText);
						oModel.setProperty("/CauseText", this._oGlobalModel.getProperty("/CloseOutCodesSet1")[0].ItemShortText);
					}
					//BAJ0018 - EDIT close out code functionality					
					// oModel.setProperty("/Title", sDefectDescr);
					this._AddCOCDialog.setModel(oModel);
				}

				this.getFragment().addDependent(this._AddCOCDialog);
				this._AddCOCDialog.open();

			},

			onCloseOutCodeFormAdd: function (oEvent) {

				var oDefectPayload = {};
				if (this._bfromDefectView) {
					oDefectPayload = this._getselectedDefectPayload(this._oSelectedContext);
				}
				if (this._bfromWorkPlanview) {
					oDefectPayload = this._getselectedDefectPayload(this._oSelectedContext);
				}

				var oCloseOutCode = {};
				var aCloseOutCode = [];

				var oFormConent = oEvent.getSource().getParent().getContent()[0].getItems()[0].getContent();

				oCloseOutCode.CompGrp = oFormConent[3].getSelectedKey();
				oCloseOutCode.CompGrpText = oFormConent[3].getValue();
				oCloseOutCode.CompLocGrp = oFormConent[3].getSelectedKey();
				oCloseOutCode.CompCd = oFormConent[5].getSelectedKey();
				oCloseOutCode.CompCdText = oFormConent[5].getValue();
				oCloseOutCode.CompLocCd = oFormConent[7].getSelectedKey();
				oCloseOutCode.CompLocCdText = oFormConent[7].getValue();
				oCloseOutCode.CauseCd = oFormConent[9].getSelectedKey();
				oCloseOutCode.CauseCdText = oFormConent[9].getValue();
				oCloseOutCode.ItemShortText = oFormConent[11].getValue();
				oCloseOutCode.CauseText = oFormConent[13].getValue();
				//BAJ0018 - EDIT close out code functionality
				if (this._oGlobalModel.getProperty("/CloseOutCodesSet1")[0]) {
					oCloseOutCode.DefectNo = this._oGlobalModel.getProperty("/CloseOutCodesSet1")[0].DefectNo;
					oCloseOutCode.DefectItem = this._oGlobalModel.getProperty("/CloseOutCodesSet1")[0].DefectItem;
				}
				//BAJ0018 - EDIT close out code functionality				
				aCloseOutCode.push(oCloseOutCode);
				oDefectPayload.CloseOutCodes = aCloseOutCode;
				BusyIndicator.showBusyIndicator();
				LocomotiveDataModel.UpdateDefectCloseoutCodes(oDefectPayload, this._updateDefectCloseOutCodeSuccess, this._updateDefectCloseOutCodeError,
					this);
			},

			_updateDefectCloseOutCodeSuccess: function () {
				this._AddCOCDialog.destroy();
				//BAJ0018 - EDIT close out code functionality
				this._AddCOCDialog = '';
				//BAJ0018 - EDIT close out code functionality

				LocomotiveDataModel.fetchDefectCloseOutCodes(this._fnsucessCloseoutCodeFetchaftercreate, "", this, this._sDefectNo);
			},
			_updateDefectCloseOutCodeError: function () {
				this._AddCOCDialog.destroy();
				//BAJ0018 - EDIT close out code functionality
				this._AddCOCDialog = '';
				//BAJ0018 - EDIT close out code functionality
			},
			onCloseOutCodeFormClose: function (oEvent) {
				this._AddCOCDialog.destroy();
				//BAJ0018 - EDIT close out code functionality
				this._AddCOCDialog = '';
				//BAJ0018 - EDIT close out code functionality
			},

			_getselectedDefectPayload: function (oContext) {
				var oDefectPayload = {};

				var aSelDefect = {};
				if (this._bfromDefectView) {
					aSelDefect = this._oSourceViewModel.getObject(oContext.sPath);
					oDefectPayload.EquipNo = aSelDefect.EquipNo;
					oDefectPayload.WorkOrderNo = aSelDefect.WorkOrderNo;
					oDefectPayload.DefectLongText = aSelDefect.DefectLongText;
					oDefectPayload.FunctionalLoc = aSelDefect.FunctionalLoc;
					oDefectPayload.DefectNo = aSelDefect.DefectNo;
					oDefectPayload.DefectType = aSelDefect.DefectType;
					oDefectPayload.DefectDescr = aSelDefect.DefectDescr;
					oDefectPayload.Shop = aSelDefect.Shop;
					oDefectPayload.PlanDefectDur = aSelDefect.PlanDefectDur;
					oDefectPayload.PlanDefectUnit = aSelDefect.PlanDefectUnit;
					oDefectPayload.MandatoryDefect = aSelDefect.MandatoryDefect;
					oDefectPayload.NearingDueDate = aSelDefect.NearingDueDate;
					oDefectPayload.ReqStartTs = aSelDefect.ReqStartTs;
					oDefectPayload.ReqStartTz = aSelDefect.ReqStartTz;
					oDefectPayload.ObjectNo = aSelDefect.ObjectNo;
					oDefectPayload.DefectLongText = aSelDefect.DefectLongText;
					oDefectPayload.DefectMonitorCode = aSelDefect.DefectMonitorCode; //jad0007
					oDefectPayload.WorkOrderDescr = aSelDefect.WorkOrderDescr; //jad0007
				}
				if (this._bfromWorkPlanview) {
					// aSelDefect = this._oSourceViewModel.getObject(oContext.sPath);
					aSelDefect = this._oGlobalModel.getObject(oContext.sPath);// SHE0272 - INC0110700 - Getting the data from global model instead of local
					oDefectPayload.DefectNo = this._sDefectNo;
					oDefectPayload.DefectType = aSelDefect.DefectType; //jad0007
					oDefectPayload.DefectDescr = aSelDefect.Descr; //jad0007
					oDefectPayload.DefectMonitorCode = aSelDefect.DefectMonitorCode; //jad0007
					oDefectPayload.WorkOrderDescr = aSelDefect.WorkOrderDescr; //jad0007
				}

				return oDefectPayload;
			},

			onCompGrpselectionChange: function (oEvent) {
				var sCompGrp = oEvent.getParameter("selectedItem").getKey();
				var oFormFields = oEvent.getSource().getParent().getParent().getParent().getParent().getContent();
				oFormFields[5].setSelectedKey("");
				oFormFields[5].setValue("");
				oFormFields[7].setSelectedKey("");
				oFormFields[7].setValue("");

				BusyIndicator.resetBusyIndicator();
				BusyIndicator.showBusyIndicator();
				var sQuery = "Usage eq 'COMP_CODES' and Key eq'" + sCompGrp + "'";
				LocomotiveDataModel.getDropDown(sQuery, this._onfetchCompCodeSuccess, this);
				BusyIndicator.resetBusyIndicator();
				BusyIndicator.showBusyIndicator();
				sQuery = "Usage eq 'COMP_LOC_CODES' and Key eq'" + sCompGrp + "'";
				LocomotiveDataModel.getDropDown(sQuery, this._onfetchCompCodeGrpSuccess, this);
				// start - baj0018 - component codes
				BusyIndicator.resetBusyIndicator();
				BusyIndicator.showBusyIndicator();
				sQuery = "Usage eq 'DEFECT_CODES' and Key eq'" + sCompGrp + "'";
				LocomotiveDataModel.getDropDown(sQuery, this._onfetchDefectCodeSuccess, this);
				// end - baj0018 - component codes	
			},

			_onfetchCompGroupSuccess: function (oData) {
				var aCompGroupDD = oData.results;
				if (aCompGroupDD.length > 0) {
					_gCompGroupDD = aCompGroupDD;
				} else {
					_gCompGroupDD = {};
				}
			},

			_onfetchCompCodeSuccess: function (oData) {
				var aCompCodeDD = oData.results;
				this._AddCOCDialog.getModel().setProperty("/CompCodeDD", aCompCodeDD);
			},

			_onfetchCompCodeGrpSuccess: function (oData) {
				var aCompLocCodeDD = oData.results;
				this._AddCOCDialog.getModel().setProperty("/CompLocCodeDD", aCompLocCodeDD);
			},
			// end - baj0018 - component codes	
			_onfetchDefectCodeSuccess: function (oData) {
				var aDefectCodeDD = oData.results;
				this._AddCOCDialog.getModel().setProperty("/DefectCodeDD", aDefectCodeDD);
			},
			// end - baj0018 - component codes	
			//Called when Change Defect Monitor Code is clicked.
			//It should setup the fragment for popup, and open it.
			onOpenDefectCodeDialog: function (oData) {
				var oDefectPayload = this._getselectedDefectPayload(this._oSelectedContext);
				_DefectMonitorCode = oDefectPayload.DefectMonitorCode;

				this._DefectMonitorDialog = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.common.defectMonitorCode.DefectMonitorCode",
					this
				);

				if (this._DefectMonitorDialog) {
					var oModel = new sap.ui.model.json.JSONModel();
					oModel.setProperty("i18n", this._oI18nModel);
					var aDefectMonitorCodes = this._oGlobalModel.getProperty("/DefectMonitorCodes");
					oModel.setProperty("/DefectMonitorCodes", aDefectMonitorCodes);
					oModel.setProperty("/comboBoxKey", oDefectPayload.DefectMonitorCode);
					oModel.setProperty("/comboBoxValue", oDefectPayload.DefectMonitorCode);
					oModel.setSizeLimit(500);
					this._DefectMonitorDialog.setModel(oModel);
				}

				this.getFragment().addDependent(this._DefectMonitorDialog);
				this._DefectMonitorDialog.open();
			},

			onSaveDefectMonitorCode: function (oEvent) {
				var oDefectPayload = {};
				oDefectPayload = this._getselectedDefectPayload(this._oSelectedContext);
				var old_DefectMoniCode = oDefectPayload.DefectMonitorCode;
				// var oFormConent = oEvent.getSource().getParent().getContent()[0].getItems()[0];
				var new_DefectMoniCode = oEvent.getSource().getParent().getContent()[0].getItems()[1].getSelectedKey();

				if (old_DefectMoniCode !== new_DefectMoniCode) {
					var fModel = this.getFragment().getModel();
					var aDefectMonitorCodes = this._oGlobalModel.getProperty("/DefectMonitorCodes");
					var aDefectMonitorDescr;
					var aLength = aDefectMonitorCodes.length;
					for (var i = 0; i < aLength; i++) {
						if (aDefectMonitorCodes[i].Value === new_DefectMoniCode) {
							aDefectMonitorDescr = aDefectMonitorCodes[i].Value + " " + aDefectMonitorCodes[i].Text;
							break;
						}
					}
					fModel.setProperty("/DefectMonitorDescr", aDefectMonitorDescr);
					this.getFragment().setModel(fModel);
					oDefectPayload.DefectMonitorCode = new_DefectMoniCode;

					LocomotiveDataModel.UpdateIncidentId(oDefectPayload, this._updateDefectCodeSuccess, this);
				}
				this._DefectMonitorDialog.destroy();
			},

			_updateDefectCodeSuccess: function () {
				var aSelDefect = this._oSourceViewModel.getObject(this._oSelectedContext.sPath);
				// var oDefectPayload = this._getselectedDefectPayload(this._oSelectedContext);
				var new_defectMoniCode = this._DefectMonitorDialog.getModel().getProperty("/comboBoxKey");
				aSelDefect.DefectMonitorCode = new_defectMoniCode;

				this.cocController.SaveDefectBacktoModel(this._oSelectedContext.sPath, aSelDefect);

				this._DefectMonitorDialog.destroy();
			},
			onCancelDefectMonitorCode: function (oEvent) {
				this._DefectMonitorDialog.destroy();
			}
		});
	}

);