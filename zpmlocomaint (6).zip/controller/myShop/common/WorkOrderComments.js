/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.21                                           *
* Project        : Locomotive Maintenance                               *
* Description    : Controller for Managing Comments @Work Order in      *
*                  Work Plan View Hook methods of view life cycle       *
*                  can be implemented for fragment life cycle.          *
*&----------------------------------------------------------------------*/
/**
 * Author         : KIR0084                                              *
 * Date           : 2019.04.01                                           *
 * Incidinet      : LMP2-36 - Create operation long text dialog    	     *
 * Description    : Add callback if first comment was added              *
 * Search Term    : LMP2-36                                              *
*&----------------------------------------------------------------------*/
/**
 * Author         : KIR0084                                              *
 * Date           : 2019.04.01                                           *
 * Incidinet      : LMP2-32 - Add read only option                       *
 * Search Term    : LMP2-32                                              *
*&----------------------------------------------------------------------*/

// #DontDelete : Daya new controller class , dont delete any method inthis file

sap.ui.define([
		"com/sap/cp/lm/controller/common/FragmentBaseDelegate",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
		"com/sap/cp/lm/util/ErrorManager"
	], function(BaseDelegate, BusyIndicator, LocomotiveDataModel, ErrorManager) {
		"use strict";
		var _this;
		return BaseDelegate.extend("com.sap.cp.lm.controller.myShop.common.WorkOrderComments", {

			_sFragmentName: "com.sap.cp.lm.view.myShop.common.WorkOrderComments",
			/**
			 * Fragment Initialization method
			 * 
			 */
			onInit: function() {
				_this = this;
				var oModel = new sap.ui.model.json.JSONModel();
				this.getFragment().setModel(oModel);
				this._initParameters();
			    _this._initWithNoComments = false;
			    _this._commentAdded = false;

			},

			//Initialization

			_initParameters: function() {
				var oModel = this.getFragment().getModel();
				
				this.aDataFromSource = this.oParameters.oWorkOrderHeader;
				this.fnFirstCommentAdded = this.oParameters.fnFirstCommentAdded;
				
				oModel.setProperty("/commentFeedInputVisible", !this.oParameters.readOnly);
				oModel.setProperty("/inputComment", "");
                
                /* KIR0084 LMP2-32 Allow parameters to be passed in to prevent double loading */
                if (this.oParameters.oComments) {
                    oModel.setProperty("/CommentSet", this.oParameters.oComments);
                }
                else {
    				BusyIndicator.showBusyIndicator();
				    LocomotiveDataModel.fetchWOComments(this.onSuccessFetchComments, this.onErrorFetchComments, this, this.aDataFromSource);
                }
                /* KIR0084 LMP2-32 Allow parameters to be passed in to prevent double loading */
			},

			onSuccessFetchComments: function(oData) {

				var oModel = this.getFragment().getModel();
				oModel.setProperty("/CommentSet", oData.results);
				
				// KIR0084 Setup param for holding if first comment was added
				if (oData.results && oData.results.length === 0) {
				    _this._initWithNoComments = true;
				} 

				BusyIndicator.hideBusyIndicator();

			},

			onErrorFetchComments: function(oData) {

				BusyIndicator.hideBusyIndicator();

			},

			//Save Serial number

			onAddComment: function() {

				var oModel = this.getFragment().getModel();
				var oPayload = {};
				oPayload.ObjectNo = this.aDataFromSource.ObjectNo;
				// oPayload.ObjectNo = "OR003000527447";

				oPayload.Comments = oModel.getProperty("/inputComment");

				LocomotiveDataModel.postWOComment(oPayload, _this.fnSuccessSave, "", this);

			},

			//Success call back
			fnSuccessSave: function() {
				// this.getFragment().close();
				this._initParameters();
			    _this._commentAdded = true;
                
			},

			//Close the dialog window

			onCloseComments: function() {
			    // KIR0084 If this was init with no comments call handler
			    if (_this.fnFirstCommentAdded && _this._initWithNoComments && _this._commentAdded) {
			        _this.fnFirstCommentAdded();
			    }
			    
				this.getFragment().close();
			}

		});
	}

);