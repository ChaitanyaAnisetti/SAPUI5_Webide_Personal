/**
 * Author         : KIR0084                                              *
 * Date           : 2019.04.01                                           *
 * Incidinet      : LMP2-36 - Create operation long text dialog    	     *
 * Description    : Create operation long text dialog                    *
 * Search Term    : LMP2-36                                              *
*/

// #DontDelete : Daya new controller class , dont delete any method inthis file

sap.ui.define([
		"com/sap/cp/lm/controller/common/FragmentBaseDelegate",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
		"com/sap/cp/lm/util/ErrorManager"
	], function(BaseDelegate, BusyIndicator, LocomotiveDataModel, ErrorManager) {
		"use strict";
		var _this;
		return BaseDelegate.extend("com.sap.cp.lm.controller.myShop.common.OperationLongTextDialog", {

			_sFragmentName: "com.sap.cp.lm.view.myShop.common.OperationLongTextDialog",
			/**
			 * Fragment Initialization method
			 * 
			 */
			onInit: function() {
				_this = this;
				var oModel = new sap.ui.model.json.JSONModel();
				this.getFragment().setModel(oModel);
				this._initParameters();

			},

			//Initialization

			_initParameters: function() {
				this.aDataFromSource = this.oParameters.oWorkOrderHeader;
				this.fnSuccessCallback = this.oParameters.fnSuccessCallback;
				var oModel = this.getFragment().getModel();
				oModel.setProperty("/LongText", this.aDataFromSource.LongText);
			},

			//Save Serial number

			onAddOperationLongText: function() {

				var oModel = this.getFragment().getModel();
				var oPayload = {};
				oPayload.RoutingNo = this.aDataFromSource.RoutingNo;
				oPayload.OpNode = this.aDataFromSource.OpNode;

				oPayload.LongText = oModel.getProperty("/LongText");

				LocomotiveDataModel.setOperationLongText(oPayload, _this.fnSuccessSave, " ", this);

			},

			//Success call back
			fnSuccessSave: function() {
			    this.fnSuccessCallback();
				this.getFragment().close();
			},

			//Close the dialog window

			onCloseOperationLongText: function() {
				this.getFragment().close();
			}

		});
	}

);