/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.21                                           *
* Project        : Locomotive Maintenance                               *
* Description    : Controller for edit Incident Number for a Defect.    *
*&----------------------------------------------------------------------*/


jQuery.sap.declare("com.sap.cp.lm.controller.myShop.common.IncidentNumberManager");

sap.ui.define([
		"com/sap/cp/lm/util/BusyIndicator",
		"sap/ui/model/json/JSONModel",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel"
	],
	function(BusyIndicator, JSONModel, LocomotiveDataModel) {
		"use strict";
		var _this;
		
		return com.sap.cp.lm.controller.myShop.common.IncidentNumberManager = {
			
			//----------------------------------------------------------------------
			// Initialize controller and dialog
			//----------------------------------------------------------------------
			
			init: function(oContext) {
				_this = this;
				_this._oContext = oContext;

				return _this;
			},
			
			/**
			 * Incident number dialog open
			 */
			onIncidentNumberDialogOpen: function(oCurrentDefect) {
				BusyIndicator.showBusyIndicator();
				
				_this._oCurrentDefect = oCurrentDefect;
				
				if (!_this._oIncidentNumberDialog) {
					_this._oIncidentNumberDialog = sap.ui.xmlfragment(
						"com.sap.cp.lm.view.myShop.common.incidentNumber.IncidentNumber",
						_this
					);
				}
				
				_this._oContext.getView().addDependent(_this._oIncidentNumberDialog);
				
				_this._initDialog();
			},
			
			
			//----------------------------------------------------------------------
			// Private functions
			//----------------------------------------------------------------------
			
			/**
			 * Display dialog
			 */
			_initDialog:  function() {
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setProperty("/IncidentId", _this._oCurrentDefect.IncidentId);
				_this._oIncidentNumberDialog.setModel(oModel);
				
				_this._oIncidentNumberDialog.open();
		        
		        BusyIndicator.hideBusyIndicator();
			},
			
			_updateIncidentIdSuccess: function() {
				_this._oCurrentDefect.IncidentId = _this._oIncidentNumberDialog.getModel().getProperty("/IncidentId");
				_this._oIncidentNumberDialog.close();
			},
			
			//----------------------------------------------------------------------
			// Event handlers
			//----------------------------------------------------------------------
			
			onSaveIncidentNumber: function(oEvent) {
				var oPayload = {};
				oPayload.DefectNo = _this._oCurrentDefect.DefectNo;
				oPayload.IncidentId = _this._oIncidentNumberDialog.getModel().getProperty("/IncidentId");
				
				LocomotiveDataModel.UpdateIncidentId(oPayload, _this._updateIncidentIdSuccess, _this);
			},
			
			onCancelIncidentNumber: function(oEvent) {
				_this._oIncidentNumberDialog.close();
			}
			
		};
	});