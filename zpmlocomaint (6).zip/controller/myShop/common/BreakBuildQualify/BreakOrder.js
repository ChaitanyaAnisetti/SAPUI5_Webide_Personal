 /*&--------------------------------------------------------------------------*    
  * Author/Changed By   : VYA0004	                                             *
  * Date                : 20-Jan-2021                                            *
  * Project             : Break and Build Project (2000011826)                   *
  * Description         : New pop up Dialog for Material Selection for PM04 order*
  * Search Term         :                                                        *
  *&---------------------------------------------------------------------------*/
 jQuery.sap.declare("com.sap.cp.lm.controller.myShop.common.BreakBuildQualify.BreakOrder");

 sap.ui.define([
 		"com/sap/cp/lm/util/Constants",
 		"com/sap/cp/lm/util/BusyIndicator",
 		"com/sap/cp/lm/util/Formatter",
 		"com/sap/cp/lm/util/ErrorManager",
 		"sap/ui/model/json/JSONModel",
 		"sap/ui/model/Filter",
 		"sap/ui/model/FilterOperator",
 		"com/sap/cp/lm/controller/myShop/common/BreakBuildQualify/BnBTasklist",
 		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel"
 	],
 	function (Constants, BusyIndicator, Formatter, ErrorManager, JSONModel, Filter, FilterOperator, BnBTasklist, LocomotiveDataModel) {
 		"use strict";
 		var _this;

 		return com.sap.cp.lm.controller.myShop.common.BreakBuildQualify.BreakOrder = {

 			//----------------------------------------------------------------------
 			// Initialize controller and dialog
 			//----------------------------------------------------------------------

 			init: function (oContext, fReloadOwnerView) {
 				_this = this;
 				_this.oModel = new sap.ui.model.json.JSONModel();

 				_this._oGlobalModel = oContext.getOwnerComponent().getGlobalModel();
 				_this._oI18nModel = oContext.getOwnerComponent().getModel("i18n");

 				_this._oContext = oContext;
 				_this._fReloadOwnerView = fReloadOwnerView;

 				return _this;
 			},

 			// #DontDelete : Q
 			/*
 			 * Add defect dialog open
 			 */
 			onBreakDialogOpen: function (sScenario, oEvent, oContext, fReloadOwnerView) {
 				BusyIndicator.showBusyIndicator();
 				_this._sScenario = sScenario;
 				if (!_this._oBreakDialog) {
 					_this._oBreakDialog = sap.ui.xmlfragment(
 						"com.sap.cp.lm.view.myShop.common.BreakBuildQualify.BreakOrder",
 						_this
 					);
 				}
 				_this._oContext.getView().addDependent(_this._oBreakDialog);
 				_this._oCurrentLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
 				_this._fetchBnBInventory(oContext);
 				_this.initDialog();

 			},
 			// #DontDelete : Q
 			/*
 			 * Populate form data and display dialog when fecthing task lists request to backend succeed
 			 */
 			initDialog: function (oData) {
 				if (_this._oBreakDialog) {
 					var title;
 					if (_this._sScenario === "Break") {
 						title = _this._oI18nModel.getProperty("BREAK_HEADER");
 					}
 					if (_this._sScenario === "Build") {
 						title = _this._oI18nModel.getProperty("BUILD_HEADER");
 					}
 					if (_this._sScenario === "Qualify") {
 						title = _this._oI18nModel.getProperty("QUALIFY_HEADER");
 					}
 					var oModel = new sap.ui.model.json.JSONModel({
 						Scenario: _this._sScenario,
 						Title: title
 					});
 					oModel.setProperty("/currentRole", _this._oGlobalModel.getProperty("/currentUser").CurrentRole);

 					oModel.setSizeLimit(1000);

 					_this._oBreakDialog.setModel(oModel);
 					_this._oBreakDialog.getModel().refresh();
 					_this._oBreakDialog.getModel().updateBindings(true);
 				}
 				_this._oBreakDialog.open();
 				BusyIndicator.hideBusyIndicator();
 			},

 			//----------------------------------------------------------------------
 			// Private functions
 			//----------------------------------------------------------------------
 			//Fetch Materials to be displayed on the screen
 			_fetchBnBInventory: function (oContext) {

 				var aFilters = [];
 				aFilters.push(new Filter("MatType", FilterOperator.EQ, "T"));
 				aFilters.push(new Filter("ShopId", FilterOperator.EQ, _this._oCurrentLocomotive.BnbLocoShop));
 				if (_this._sScenario === "Break") {
 					aFilters.push(new Filter("MaintType", FilterOperator.EQ, "BRK"));
 				} else {
 					if (_this._sScenario === "Build") {
 						aFilters.push(new Filter("MaintType", FilterOperator.EQ, "BUI"));
 					} else {
 						if (_this._sScenario === "Qualify") {
 							aFilters.push(new Filter("MaintType", FilterOperator.EQ, "QUA"));
 						}
 					}
 				}
 				//Get Traction Motor Inventory
 				LocomotiveDataModel.fetchBnbInventory(_this._fnSuccessCallBOBack, _this._fnErrorCallBack, aFilters, _this, oContext);

 				//Get WAG 
 				aFilters = [];
 				aFilters.push(new Filter("MatType", FilterOperator.EQ, "W"));
 				aFilters.push(new Filter("ShopId", FilterOperator.EQ, _this._oCurrentLocomotive.BnbLocoShop));
 				if (_this._sScenario === "Break") {
 					aFilters.push(new Filter("MaintType", FilterOperator.EQ, "BRK"));
 				}
 				if (_this._sScenario === "Build") {
 					aFilters.push(new Filter("MaintType", FilterOperator.EQ, "BUI"));
 				}
 				if (_this._sScenario === "Qualify") {
 					aFilters.push(new Filter("MaintType", FilterOperator.EQ, "QUA"));
 				}
 				//Get Traction Motor Inventory
 				LocomotiveDataModel.fetchBnbInventory(_this._fnSuccessCallBOBack, _this._fnErrorCallBack, aFilters, _this, oContext);
 			},

 			_fnSuccessCallBOBack: function (oData) {
 				var oInventoryModel = new sap.ui.model.json.JSONModel(oData);
             if (oData.results.length > 0){
 				if (oData.results[0].MatType === "T") {
 					sap.ui.getCore().byId("tableTM").setModel(oInventoryModel, "TInventory");
 				}
 				if (oData.results[0].MatType === "W") {
 					sap.ui.getCore().byId("tableWAG").setModel(oInventoryModel, "WInventory");
 				}
             }
 			},

 			_fnErrorCallBack: function (oController, oError) {
 				_this.oSuccess = "False";
 				oController.handleODataError(oError);
 			},
 			//----------------------------------------------------------------------
 			// Event handlers
 			//----------------------------------------------------------------------
 			onResetTMSelection: function (oEvent) {
 				sap.ui.getCore().byId("tableTM").removeSelections();
 			},
 			onResetWAGSelection: function (oEvent) {
 				sap.ui.getCore().byId("tableWAG").removeSelections();
 			},
 			// #DontDelete : Q
 			/*
 			 * Close dialog
 			 */
 			onBreakDialogCancel: function (oEvent) {
 				_this._oBreakDialog.destroy();
 				_this._oBreakDialog = null;
 				_this._sScenario = null;
 				_this.aRefurbOrdData = null;
 				_this.aTaskFilters = null;
 			},
 			//Next button logic
 			onBreakDialogNext: function (oEvent) {
 				var aRefurbOrdData = {};
 				var sError;
 				var aTaskFilters = [];
 				var aRefurbOrdItem = [];
 				var oTableTM = sap.ui.getCore().byId("tableTM");
 				var oModelTM = oTableTM.getModel("TInventory");
 				var sPathTM = oTableTM._aSelectedPaths[0];
 				var oSelectedTM = oModelTM.getProperty(sPathTM);
 				var oTableWAG = sap.ui.getCore().byId("tableWAG");
 				var oModelWAG = oTableWAG.getModel("WInventory");
 				var sPathWAG = oTableWAG._aSelectedPaths[0];
 				var oSelectedWAG = oModelWAG.getProperty(sPathWAG);
 				if (!oSelectedTM && !oSelectedWAG) {
 					ErrorManager.handleError("", "Please select material(s) for order creation");
 					sError = "true";
 				} else {
 					if (_this._sScenario === "Break" || _this._sScenario === "Build") {
 						if (!oSelectedTM || !oSelectedWAG) {
 							ErrorManager.handleError("", "Please select a combo for order creation");
 							//	sap.m.MessageToast.show("Please select a combo for order creation");
 							sError = "true";
 						}
 					}
 				}
 				//Check if Wag- Parent Material = Selected TM material.
 				if (oSelectedTM && oSelectedWAG) {
 					if (oSelectedTM.Matnr !== oSelectedWAG.ParentMaterial) {
 						ErrorManager.handleError("", "Selected Traction Motor and WAG combination is invalid.");
 						sError = "true";
 					} else {
 					//If Break or Qualify	
 						if ((_this._sScenario === "Break") || (_this._sScenario === "Qualify")) {
 							//Storage Location and Valuation Type should be same for TM and WAG selected materials.
 							if ((oSelectedTM.Sloc !== oSelectedWAG.Sloc) || (oSelectedTM.ValType !== oSelectedWAG.ValType)) {
 								ErrorManager.handleError("",
 									"Storage Location and Valuation Types cannot be different between TM/WAG.Please correct your entry.");
 								sError = "true";
 							}
 						}
 					}
 				} 
 				
 					// Check if Selected Materials have stock
 					if ((oSelectedTM && oSelectedTM.Stock === "0.000") || (oSelectedWAG && oSelectedWAG.Stock === "0.000")) {
 						ErrorManager.handleError("", "Selected material(s) do not have sufficient stock.");
 						sError = "true";
 					}
 				
 				if (!sError) {
 					var sMaintType;
 					if (_this._sScenario === "Break") {
 						aTaskFilters.push(new Filter("BreakFlg", FilterOperator.EQ, "X"));
 					}
 					if (_this._sScenario === "Build") {
 						aTaskFilters.push(new Filter("BuildFlg", FilterOperator.EQ, "X"));
 					}
 					if (_this._sScenario === "Qualify") {
 						aTaskFilters.push(new Filter("QualifyFlg", FilterOperator.EQ, "X"));
 					}
 					if (oSelectedTM) {
 						sMaintType = oSelectedTM.MaintType;
 						aRefurbOrdItem.push({
 							Matnr: oSelectedTM.Matnr,
 							Sloc: oSelectedTM.Sloc,
 							Batch: oSelectedTM.ValType,
 							ValType: oSelectedTM.ValType
 						});
 						//Pass this filter for Tasklist selection
 						aTaskFilters.push(new Filter("Matnr", FilterOperator.EQ, oSelectedTM.Matnr));
 					}
 					if (oSelectedWAG) {
 						sMaintType = oSelectedWAG.MaintType;
 						aRefurbOrdItem.push({
 							Matnr: oSelectedWAG.Matnr,
 							Sloc: oSelectedWAG.Sloc,
 							Batch: oSelectedWAG.ValType,
 							ValType: oSelectedWAG.ValType
 						});
 						//Pass this filter for Tasklist selection
 						aTaskFilters.push(new Filter("Matnr", FilterOperator.EQ, oSelectedWAG.Matnr));
 					}
 					var sEquipNo = _this._oCurrentLocomotive.Equipment;
 					aTaskFilters.push(new Filter("Equnr", FilterOperator.EQ, sEquipNo));
 					aRefurbOrdData.MaintType = sMaintType;
 					aRefurbOrdData.ShopId = _this._oCurrentLocomotive.BnbLocoShop;
 					aRefurbOrdData.BnbRefurbOrderItemSet = aRefurbOrdItem;
 					aTaskFilters.push(new Filter("Plnty", FilterOperator.EQ, "A"));
 					_this.aRefurbOrdData = aRefurbOrdData;
 					_this.aTaskFilters = aTaskFilters;
 					_this._oBreakDialog.destroy();
 					_this._oBreakDialog = null;
 					if (!_this.BnBTasklist) {
 						_this.BnBTasklist = BnBTasklist.init(_this._oContext, _this._fReloadOwnerView);
 					}
 					BnBTasklist.onBnBTasklistDialogOpen(oEvent, _this, _this._fReloadOwnerView);
 				}

 			},
 			/**
 			 * dialog navigation logic next step
 			 **/
 			onBreakDialogCreateOrder: function (oEvent) {
 				var aRefurbOrdData = {};
 				var sError;
 				var aRefurbOrdItem = [];
 				var oTableTM = sap.ui.getCore().byId('tableTM');
 				var oModelTM = oTableTM.getModel("TInventory");
 				var sPathTM = oTableTM._aSelectedPaths[0];
 				var oSelectedTM = oModelTM.getProperty(sPathTM);
 				var oTableWAG = sap.ui.getCore().byId('tableWAG');
 				var oModelWAG = oTableWAG.getModel("WInventory");
 				var sPathWAG = oTableWAG._aSelectedPaths[0];
 				var oSelectedWAG = oModelWAG.getProperty(sPathWAG);
 				if (_this._sScenario === "Break" || _this._sScenario === "Build") {
 					if (!oSelectedTM || !oSelectedWAG) {
 						sap.m.MessageToast.show("Please select a combo for order creation");
 						sError = 'true';
 					}
 				}
 				if (!sError) {
 					var sMaintType;
 					if (oSelectedTM) {
 						sMaintType = oSelectedTM.MaintType;
 						aRefurbOrdItem.push({
 							Matnr: oSelectedTM.Matnr,
 							Sloc: oSelectedTM.Sloc,
 							Batch: oSelectedTM.ValType,
 							ValType: oSelectedTM.ValType
 						});
 					}
 					if (oSelectedWAG) {
 						sMaintType = oSelectedTM.MaintType;
 						aRefurbOrdItem.push({
 							Matnr: oSelectedWAG.Matnr,
 							Sloc: oSelectedWAG.Sloc,
 							Batch: oSelectedWAG.ValType,
 							ValType: oSelectedWAG.ValType
 						});
 					}
 					aRefurbOrdData.MaintType = sMaintType;
 					aRefurbOrdData.ShopId = _this._oCurrentLocomotive.BnbLocoShop;
 					aRefurbOrdData.BnbRefurbOrderItemSet = aRefurbOrdItem;

 					LocomotiveDataModel.createRefurbOrder(aRefurbOrdData);
 				}
 			}

 		};

 	});