/*&--------------------------------------------------------------------------*    
 * Author/Changed By   : VYA0004	                                         *
 * Date                : 20-Jan-2021                                         *
 * Project             : Break and Build Project (2000011826)                *
 * Description         : New pop up Dialog to View Inventory of BnB Materials*
 * Search Term         :                                                     *
 *&---------------------------------------------------------------------------*/
jQuery.sap.declare("com.sap.cp.lm.controller.myShop.common.BreakBuildQualify.ViewInventory");

sap.ui.define([
		"com/sap/cp/lm/util/Constants",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/util/Formatter",
		"com/sap/cp/lm/util/ErrorManager",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel"
	],
	function (Constants, BusyIndicator, Formatter, ErrorManager, JSONModel, Filter, FilterOperator, LocomotiveDataModel) {
		"use strict";
		var _this;

		return com.sap.cp.lm.controller.myShop.common.BreakBuildQualify.ViewInventory = {

			//----------------------------------------------------------------------
			// Initialize controller and dialog
			//----------------------------------------------------------------------

			init: function (oContext, fReloadOwnerView) {
				_this = this;
				_this.oModel = new sap.ui.model.json.JSONModel();

				_this._oGlobalModel = oContext.getOwnerComponent().getGlobalModel();
				_this._oI18nModel = oContext.getOwnerComponent().getModel("i18n");

				_this._oContext = oContext;
				_this._fReloadOwnerView = fReloadOwnerView;

				return _this;
			},

			// #DontDelete : Q
			/*
			 * Add defect dialog open
			 */
			onViewInventoryDialogOpen: function (oEvent, oContext, fReloadOwnerView) {
				BusyIndicator.showBusyIndicator();

				if (!_this._oViewInventoryDialog) {
					_this._oViewInventoryDialog = sap.ui.xmlfragment(
						"com.sap.cp.lm.view.myShop.common.BreakBuildQualify.ViewInventory",
						_this
					);
				}

				_this._oCurrentLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
				_this._fetchBnBInventory(oContext);
				//reset Search field
				var oSearchTM = sap.ui.getCore().byId("searchTMVI");
				oSearchTM.mProperties.value = "";
				//reset Search field
				var oSearchWAG = sap.ui.getCore().byId("searchWAGVI");
				oSearchWAG.mProperties.value = "";
				_this.initDialog();
				_this._oContext.getView().addDependent(_this._oViewInventoryDialog);
			},
			// #DontDelete : Q
			/*
			 * Populate form data and display dialog when fecthing task lists request to backend succeed
			 */
			initDialog: function (oData) {
				var title;
				title = _this._oI18nModel.getProperty("VIEW_INVENTORY");
				var oModel = new sap.ui.model.json.JSONModel({
					Title: title
				});
				oModel.setProperty("/currentRole", _this._oGlobalModel.getProperty("/currentUser").CurrentRole);

				oModel.setSizeLimit(1000);

				_this._oViewInventoryDialog.setModel(oModel);
				_this._oViewInventoryDialog.getModel().refresh();
				_this._oViewInventoryDialog.getModel().updateBindings(true);
				_this._oViewInventoryDialog.open();
				BusyIndicator.hideBusyIndicator();
			},
			onSearchWAGVI: function (oEvent) {
				// add filter for search
				var aFilters = [];
				var sQuery = oEvent.getSource().getValue();
				if (sQuery && sQuery.length > 0) {
					var filter = new Filter("Maktx", FilterOperator.Contains, sQuery);
					aFilters.push(filter);
				}
				// update list binding
				sap.ui.getCore().byId("tableWAGVI").getBinding("items").filter(aFilters);
			},
			onSearchTMVI: function (oEvent) {
				// add filter for search
				var aFilters = [];
				var sQuery = oEvent.getSource().getValue();
				if (sQuery && sQuery.length > 0) {
					var filter = new Filter("Maktx", FilterOperator.Contains, sQuery);
					aFilters.push(filter);
				}
				// update list binding
				sap.ui.getCore().byId("tableTMVI").getBinding("items").filter(aFilters);
			},
			//----------------------------------------------------------------------
			// Private functions
			//----------------------------------------------------------------------

			//Fetch Materials to be displayed on the screen
			_fetchBnBInventory: function (oContext) {

				var aFilters = [];
				aFilters.push(new Filter("MatType", FilterOperator.EQ, "T"));
				aFilters.push(new Filter("ShopId", FilterOperator.EQ, _this._oCurrentLocomotive.BnbLocoShop));
				//Get Traction Motor Inventory
				LocomotiveDataModel.fetchBnbInventory(_this._fnSuccessCallBack, _this._fnErrorCallBack, aFilters, _this, oContext);
				//Get WAG 
				aFilters = [];
				aFilters.push(new Filter("MatType", FilterOperator.EQ, "W"));
				aFilters.push(new Filter("ShopId", FilterOperator.EQ, _this._oCurrentLocomotive.BnbLocoShop));
				//Get Traction Motor Inventory
				LocomotiveDataModel.fetchBnbInventory(_this._fnSuccessCallBack, _this._fnErrorCallBack, aFilters, _this, oContext);
			},
			_fnSuccessCallBack: function (oData) {
				var oInventoryModel = new sap.ui.model.json.JSONModel(oData);
              if(oData.results.length > 0){
				if (oData.results[0].MatType === "T") {
					sap.ui.getCore().byId("tableTMVI").setModel(oInventoryModel, "TVInventory");
				}
				if (oData.results[0].MatType === "W") {
					sap.ui.getCore().byId("tableWAGVI").setModel(oInventoryModel, "WVInventory");
				}
              }
			},

			_fnErrorCallBack: function (oController, oError) {
				_this.oSuccess = "False";
				oController.handleODataError(oError);
			},
			_fnSuccessOrder: function () {},
			_fnErrorOrder: function () {},

			//----------------------------------------------------------------------
			// Event handlers
			//----------------------------------------------------------------------
			// #DontDelete : Q
			/*
			 * Close dialog
			 */
			onInventoryDialogCancel: function (oEvent) {

				//sap.ui.getCore().byId("tableTMVI").getBinding("items").filter([]);	
				//sap.ui.getCore().byId("tableWAGVI").getBinding("items").filter([]);
				_this._oViewInventoryDialog.destroy();
				_this._oViewInventoryDialog = null;
				//_this._oViewInventoryDialog.close();
			}
		};

	});