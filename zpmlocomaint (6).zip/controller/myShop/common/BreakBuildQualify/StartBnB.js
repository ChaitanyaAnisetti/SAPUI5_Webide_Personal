 /*&--------------------------------------------------------------------------*    
  * Author/Changed By   : VYA0004			                                     *
  * Date                : 7-Jan-2021                                             *
  * Project             : Break and Build Project (2000011826)                               *
  * Description         : New pop up dialog                                      *
  * Search Term         :                                                        *
  *&---------------------------------------------------------------------------*/
 jQuery.sap.declare("com.sap.cp.lm.controller.myShop.common.BreakBuildQualify.StartBnB");

 sap.ui.define([
 		"com/sap/cp/lm/util/Constants",
 		"com/sap/cp/lm/util/BusyIndicator",
 		"com/sap/cp/lm/util/Formatter",
 		"com/sap/cp/lm/util/ErrorManager",
 		"sap/ui/model/json/JSONModel",
 		"sap/ui/model/Filter",
 		"sap/ui/model/FilterOperator",
 		"com/sap/cp/lm/controller/myShop/common/BreakBuildQualify/BreakOrder",
 		"com/sap/cp/lm/controller/myShop/common/BreakBuildQualify/BnBTasklist",
 		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel"
 	],
 	function (Constants, BusyIndicator, Formatter, ErrorManager, JSONModel, Filter, FilterOperator, BreakOrder, BnBTasklist,
 		LocomotiveDataModel) {
 		"use strict";
 		var _this;

 		return com.sap.cp.lm.controller.myShop.common.BreakBuildQualify.StartBnB = {

 			//----------------------------------------------------------------------
 			// Initialize controller and dialog
 			//----------------------------------------------------------------------

 			init: function (oContext, fReloadOwnerView) {
 				_this = this;
 				_this.oModel = new sap.ui.model.json.JSONModel();

 				_this._oGlobalModel = oContext.getOwnerComponent().getGlobalModel();
 				_this._oI18nModel = oContext.getOwnerComponent().getModel("i18n");

 				_this._oContext = oContext;
 				_this._fReloadOwnerView = fReloadOwnerView;

 				return _this;
 			},

 			// #DontDelete : Q
 			/*
 			 * Add defect dialog open
 			 */
 			onStartBnBDialogOpen: function (oContext, fReloadOwnerView) {
 				BusyIndicator.showBusyIndicator();
 				if (!_this._oStartBnBDialog) {
 					_this._oStartBnBDialog = sap.ui.xmlfragment(
 						"com.sap.cp.lm.view.myShop.common.BreakBuildQualify.StartBnB",
 						_this
 					);
 				}

 				_this._oCurrentLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
 				_this.initDialog();
 				var oRB2 = sap.ui.getCore().byId("RBG2");
 				var oRB1 = sap.ui.getCore().byId("RBG1");
 				//Clear any previous selections
 				oRB1.setSelectedIndex(0);
 				oRB2.setSelectedIndex(1);
 				_this._oContext.getView().addDependent(_this._oStartBnBDialog);
 			},

 			// #DontDelete : Q
 			/*
 			 * Populate form data and display dialog when fecthing task lists request to backend succeed
 			 */
 			initDialog: function (oData) {
 				if (_this._oStartBnBDialog) {

 					var title = _this._oI18nModel.getProperty("START_BNB");

 					var oModel = new sap.ui.model.json.JSONModel({
 						Scenario: _this._sScenario,
 						Title: title
 					});
 					oModel.setProperty("/currentRole", _this._oGlobalModel.getProperty("/currentUser").CurrentRole);

 					oModel.setSizeLimit(1000);

 					_this._oStartBnBDialog.setModel(oModel);
 					_this._oStartBnBDialog.getModel().refresh();
 					_this._oStartBnBDialog.getModel().updateBindings(true);
 				}
 				var model = new sap.ui.model.json.JSONModel();
 				model.setData({
 					modelData: {
 						radioDataText: []
 					}
 				});
 				sap.ui.getCore().setModel(model);
 				var model2 = new sap.ui.model.json.JSONModel();
 				model2.setData({
 					modelData: {
 						radioDataText2: []
 					}
 				});
 				sap.ui.getCore().setModel(model2);
 				_this._oStartBnBDialog.open();

 				BusyIndicator.hideBusyIndicator();
 			},

 			//----------------------------------------------------------------------
 			// Private functions
 			//----------------------------------------------------------------------

 			// /**
 			//  * Select default key depending on parameters
 			//  */
 			// _setDefaultSelectedKey: function (aSelectData, sSelectId, bUseValue) {
 			// 	var i = 0;
 			// 	var bFound = false;
 			// 	while (!bFound && i < aSelectData.length) {
 			// 		var oCurrentData = aSelectData[i];
 			// 		if (aSelectData[i].getBindingContext) {
 			// 			oCurrentData = aSelectData[i].getBindingContext().getObject();
 			// 		}
 			// 		if (oCurrentData.DefaultSelection === true) {
 			// 			bFound = true;
 			// 			var key = oCurrentData.Key;
 			// 			if (bUseValue && bUseValue === true) {
 			// 				key = oCurrentData.Value;
 			// 			}
 			// 			sap.ui.getCore().byId(sSelectId).setSelectedKey(key);
 			// 		}
 			// 		i++;
 			// 	}
 			// },

 			rbg1select: function (oEvent) {
 				var oSelectedIndex = oEvent.getParameter("selectedIndex");
 				var oRadioButtonSrc = oEvent.getSource().getAggregation("buttons");
 				var oSelectedRadioText = oRadioButtonSrc[oSelectedIndex].getText();
 				sap.ui.getCore().getModel().setProperty("/modelData/radioDataText", oSelectedRadioText);
 			},
 			rbg2select: function (oEvent) {
 				var oSelectedIndex = oEvent.getParameter("selectedIndex");
 				var oRadioButtonSrc = oEvent.getSource().getAggregation("buttons");
 				var oSelectedRadioText = oRadioButtonSrc[oSelectedIndex].getText();
 				sap.ui.getCore().getModel().setProperty("/modelData/radioDataText", oSelectedRadioText);
 			},

 			// #DontDelete : Q
 			/*
 			 * Close dialog and launch refresh of context view
 			 */
 			_endSubmitOnSuccess: function (oData) {
 				_this._oAddDefectDialog.close();

 				if (_this._fReloadOwnerView && _this._oContext) {
 					_this._fReloadOwnerView.apply(_this._oContext, null);
 				}
 			},

 			//----------------------------------------------------------------------
 			// Event handlers
 			//----------------------------------------------------------------------

 			// #DontDelete : Q
 			/*
 			 * Close dialog
 			 */
 			onStartBnBDialogCancel: function (oEvent) {
 				_this._oStartBnBDialog.destroy();
 				_this._oStartBnBDialog = null;
 				if (_this._fReloadOwnerView && _this._oContext) {
 					_this._fReloadOwnerView.apply(_this._oContext, null);
 				}
 			},

 			/**
 			 * dialog navigation logic next step
 			 **/
 			onStartBnBDialogNext: function (oEvent) {
 				//dialog flow = Select Task Type(Break/Build/Qualify) and Is WSA(Yes or No) 
 				//If WSA = Yes, Create MS00 Work Order.
 				//If WSA = No, Display Screen for Break/Build or Qualify 
 				// var oDialogContent = _this._oStartBnBDialog.getContent();
 				// var oTabBar = oDialogContent[0];
 				var oRB2 = sap.ui.getCore().byId("RBG2");
 				var sText2 = oRB2.getSelectedButton().getText();
 				var oRB1 = sap.ui.getCore().byId("RBG1");
 				var sText = oRB1.getSelectedButton().getText();
 				if (sText2 === "No") {
 					_this._oStartBnBDialog.destroy();
 					_this._oStartBnBDialog = null;
 					//Create Refurbishment Order
 					if (!_this.BreakOrder) {
 						_this.BreakOrder = BreakOrder.init(_this._oContext, _this._fReloadOwnerView);
 					}
 					BreakOrder.onBreakDialogOpen(sText, oEvent, _this._oContext, _this._fReloadOwnerView);

 				} else {
 					var aTaskFilters = [];
 					var sEquipNo = _this._oCurrentLocomotive.Equipment;
 					aTaskFilters.push(new Filter("Equnr", FilterOperator.EQ, sEquipNo));
 					if (sText === "Break") {
 						aTaskFilters.push(new Filter("BreakFlg", FilterOperator.EQ, "X"));
 					}
 					if (sText === "Build") {
 						aTaskFilters.push(new Filter("BuildFlg", FilterOperator.EQ, "X"));
 					}
 					if (sText === "Qualify") {
 						aTaskFilters.push(new Filter("QualifyFlg", FilterOperator.EQ, "X"));
 					}
 					aTaskFilters.push(new Filter("Plnty", FilterOperator.EQ, "A"));
 					_this.aTaskFilters = aTaskFilters;
 					_this.sScenario = sText;
 					_this._oStartBnBDialog.close();
 					if (!_this.BnBTasklist) {
 						_this.BnBTasklist = BnBTasklist.init(_this._oContext, _this._fReloadOwnerView);
 					}
 					BnBTasklist.onBnBTasklistDialogOpen(oEvent, _this, _this._fReloadOwnerView);

 				}
 			}
 		};

 	});