/*&--------------------------------------------------------------------------*    
 * Author/Changed By   : VYA0004	                                         *
 * Date                : 20-Jan-2021                                         *
 * Project             : Break and Build Project (2000011826)                *
 * Description         : New pop up Dialog to enter Description and Tasklist details*
 * Search Term         :                                                     *
 *&---------------------------------------------------------------------------*/
jQuery.sap.declare("com.sap.cp.lm.controller.myShop.common.BreakBuildQualify.BnBTasklist");

sap.ui.define([
		"com/sap/cp/lm/util/Constants",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/util/Formatter",
		"com/sap/cp/lm/util/ErrorManager",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel"
	],
	function (Constants, BusyIndicator, Formatter, ErrorManager, JSONModel, Filter, FilterOperator, LocomotiveDataModel) {
		"use strict";
		var _this;

		return com.sap.cp.lm.controller.myShop.common.BreakBuildQualify.BreakOrder = {

			//----------------------------------------------------------------------
			// Initialize controller and dialog
			//----------------------------------------------------------------------

			init: function (oContext, fReloadOwnerView) {
				_this = this;
				_this.oModel = new sap.ui.model.json.JSONModel();

				_this._oGlobalModel = oContext.getOwnerComponent().getGlobalModel();
				_this._oI18nModel = oContext.getOwnerComponent().getModel("i18n");

				_this._oContext = oContext;
				_this._fReloadOwnerView = fReloadOwnerView;

				return _this;
			},

			// #DontDelete : Q
			/*
			 * Add defect dialog open
			 */
			onBnBTasklistDialogOpen: function (oEvent, oBreak, fReloadOwnerView) {
				BusyIndicator.showBusyIndicator();
				_this.oBreak = oBreak;
				if (!_this._oBnBTasklistDialog){
					_this._oBnBTasklistDialog = sap.ui.xmlfragment(
						"com.sap.cp.lm.view.myShop.common.BreakBuildQualify.BnBTasklist",
						_this
					);
				}
				_this._oContext.getView().addDependent(_this._oBnBTasklistDialog);
				_this._oCurrentLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
				//Retrieve all the values for Tasklist
				LocomotiveDataModel.fetchBnbTasklist(_this._fnSuccessCallBack, _this._fnErrorCallBack, _this.oBreak.aTaskFilters, _this, _this._oContext);
				_this.initDialog();
				BusyIndicator.hideBusyIndicator();
			},
			// #DontDelete : Q
			/*
			 * Populate form data and display dialog when fecthing task lists request to backend succeed
			 */
			initDialog: function (oData) {
				if (_this._oBnBTasklistDialog) {
					var title;
					sap.ui.getCore().byId("selectBnBTasklist").setValue("");
					var oModel = new sap.ui.model.json.JSONModel({
						Scenario: _this._sScenario,
						Title: title
					});
					oModel.setProperty("/currentRole", _this._oGlobalModel.getProperty("/currentUser").CurrentRole);
					oModel.setSizeLimit(1000);
					_this._oBnBTasklistDialog.setModel(oModel);
					_this._oBnBTasklistDialog.getModel().refresh();
					_this._oBnBTasklistDialog.getModel().updateBindings(true);
				}
				_this._oBnBTasklistDialog.open();
			},

			//----------------------------------------------------------------------
			// Private functions
			//----------------------------------------------------------------------

			_fnSuccessCallBack: function (oData) {
				var oBnBTasklistModel = new sap.ui.model.json.JSONModel(oData);
				sap.ui.getCore().byId("selectBnBTasklist").setModel(oBnBTasklistModel, "BnBTasklist");
			},

			_fnErrorCallBack: function () {
				_this.oSuccess = "False";
			},

			//----------------------------------------------------------------------
			// Event handlers
			//----------------------------------------------------------------------
			// #DontDelete : Q
			/*
			 * Close dialog
			 */
			onBnBTasklistDialogCancel: function (oEvent) {
				_this._oBnBTasklistDialog.destroy();
				_this._oBnBTasklistDialog = null;
				if (_this.oBreak) {
					_this.oBreak = null;
				}
				_this.aTaskFilters = null;
				if (_this._fReloadOwnerView && _this._oContext) {
					_this._fReloadOwnerView.apply(_this._oContext, null);
				}
			},
			_endSubmitOnSuccess: function (oData) {
				_this._oBnBTasklistDialog.destroy();
				_this._oBnBTasklistDialog = null;
				if (_this.aRefurbOrdData) {
					_this.aRefurbOrdData = null;
				}
				if (_this._fReloadOwnerView && _this._oContext) {
					_this._fReloadOwnerView.apply(_this._oContext, null);
				}
			},
			/**
			 * dialog navigation logic next step
			 **/
			onBnBTasklistDialogCreateOrder: function (oEvent) {
				var sPlnnr, sPlnal, sPlnty, sDescription, sIwerk ;
				//Read selected Tasklist and Description
				var sSerialNo = sap.ui.getCore().byId("inputSerialNo").getValue();
				var sUnit = sap.ui.getCore().byId("inputUnit").getValue();
				var sPosition = sap.ui.getCore().byId("inputPosition").getValue();
				sDescription = sSerialNo + " " + sUnit + " " + sPosition;
				if (!sUnit) {
					ErrorManager.handleError("", "Please enter Unit");
				} else {
					if (!sPosition) {
						ErrorManager.handleError("", "Please enter Position");
					} else {
						if (!sSerialNo) {
							ErrorManager.handleError("", "Please enter Serial Number");
						} else {
							var oSelectedTask = sap.ui.getCore().byId("selectBnBTasklist").getSelectedItem();
							if (!oSelectedTask) {
								ErrorManager.handleError("", "Please select a valid Tasklist");
							} else {

								var oTaskKey = oSelectedTask.getKey();
								var aTask = oTaskKey.split("|");
								sPlnnr = aTask[0];
								sPlnty = aTask[1];
								sPlnal = aTask[2];
								sIwerk = aTask[3];

								if (_this.oBreak.aRefurbOrdData) {
									//Create Refurbishment Order
									_this.oBreak.aRefurbOrdData.Description = sDescription;
									_this.oBreak.aRefurbOrdData.TasklistGroupKey = sPlnnr;
									_this.oBreak.aRefurbOrdData.TasklistCounter = sPlnal;
									_this.oBreak.aRefurbOrdData.TasklistType = sPlnty;
									_this.oBreak.aRefurbOrdData.PlanPlant = sIwerk;
									LocomotiveDataModel.createRefurbOrder(_this.oBreak.aRefurbOrdData, _this._endSubmitOnSuccess, _this);
								} else {
									//create MS01
									var aOrderData = {};
									if (_this.oBreak.sScenario === "Break") {
										aOrderData.MaintType = "BRK";
									} else {
										if (_this.oBreak.sScenario === "Build") {
											aOrderData.MaintType = "BUI";
										} else {
											if (_this.oBreak.sScenario === "Qualify") {
												aOrderData.MaintType = "QUA";
											}
										}
									}
									var sEquipNo = _this._oCurrentLocomotive.Equipment;
									if (!sEquipNo) {
										sEquipNo = _this._oCurrentLocomotive.EquipNo;
									}
									aOrderData.Equipment = sEquipNo;
									aOrderData.Description = sDescription;
									aOrderData.ShopId = _this._oCurrentLocomotive.BnbLocoShop;
									aOrderData.TasklistGroupKey = sPlnnr;
									aOrderData.TasklistCounter = sPlnal;
									aOrderData.TasklistType = sPlnty;
									aOrderData.PlanPlant = sIwerk;
									LocomotiveDataModel.createBnBUnscheduledOrder(aOrderData, _this._endSubmitOnSuccess, _this);
								}
							}
						}
					}
				}
			}

		};

	});