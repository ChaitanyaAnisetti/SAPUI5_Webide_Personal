/* #DontDelete : Yann */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel"
], function(Controller, Constants, Formatter, BusyIndicator, LocomotiveDataModel) {
	"use strict";

	var _this;

	return Controller.extend("com.sap.cp.lm.controller.myShop.common.wheelSheet.WheelSheet", {

		/**
		 * Initializes the controller
		 */
		onInit: function() {
			_this = this;
			_this.isEditable = true;
			_this.inputCount = 0;
			_this.codeGroupsSet = {};

		},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 */
		onAfterRendering: function() {},

		/*
		 * handle resize
		 */
		handleWindowResize: function() {},

		/*
		 * get measurement set
		 */
		fetchLocomotiveWheelSheet: function(oLocomotive) {
			_this.oLocomotive = oLocomotive;
			var oPayload = _this.getView().getModel().getProperty("/WSHeader");
			LocomotiveDataModel.fetchLocomotiveWheelSheet(oPayload, _this.fetchLocomotiveWheelSheetSuccess, _this.fetchLocomotiveWheelSheetFailure,
				_this);
		},

		/*
		 * get success
		 */
		fetchLocomotiveWheelSheetSuccess: function(oData) {
			BusyIndicator.hideBusyIndicator();
			_this.refreshWheelSheet(oData);
		},

		/*
		 * get failed
		 */
		fetchLocomotiveWheelSheetFailure: function(oData) {
			BusyIndicator.hideBusyIndicator();
		},

		/*
		 * update measurement set,
		 * prepare payload
		 */
		getSavePayload: function() {
			var oPayload = _this.getView().getModel().getProperty("/WSHeader");

			oPayload["MsetStatus"] = "N";
			oPayload["SubmitFlag"] = "";
			oPayload["MSetReadingSet"] = _this.getReadingSet();

			return oPayload;
		},

		/*
		* input id factory (used to retrieve values on save/submit actions)
		*/
		inputIdForMeasurementPoint: function(oPoint) {
			var sInputId = oPoint.MeasurePtName;
			
			if(oPoint.MeasureColumn !== 0) {
				sInputId = oPoint.MeasurePosition + "_" + oPoint.MeasurePtName;
			}
			
			return sInputId;
		},
		
		/*
		 * update measurement set,
		 * bundle MSetReadingSet in an array
		 * rematch position in the tables with measurement point ids
		 */
		getReadingSet: function() {
			var aReadingSet = [];

			var aMeasurements = _this.getView().getModel().getProperty("/WheelSheet");
			var groups = aMeasurements.MSetGroupSet.results;

			var inputChecksum = 0;

			for (var i = 0; i < groups.length; i++) {
				var group = groups[i];
				var aMeasurementsPoints = group.MeasPointSet.results;

				for (var j = 0; j < aMeasurementsPoints.length; j++) {
					var oPoint = aMeasurementsPoints[j];

					if (oPoint.MeasurePosition !== "" && oPoint.MeasurePtId !== "") {
						var sInputId = _this.inputIdForMeasurementPoint(oPoint);

						var oInput = sap.ui.getCore().byId(this.createId(sInputId));

						if (oInput) {
							var sReading = "";

							if (oPoint.CodeGrp === "") {
								sReading = oInput.getValue().trim();
							} else {
								sReading = oInput.getSelectedKey();
							}

							if (sReading !== "") {
								inputChecksum++;

								var oPayloadPoint = {
									"MeasurePtId": oPoint.MeasurePtId,
									"MeasureDocReading": sReading
								};

								aReadingSet.push(oPayloadPoint);
							}
						}
					}
				}
			}

			_this.WSSubmitBtnId = _this.getView().getModel().getProperty("/WSSubmitBtnId");

			if (inputChecksum === _this.inputCount) {
				sap.ui.getCore().byId(_this.WSSubmitBtnId).setEnabled(true);
			} else {
				sap.ui.getCore().byId(_this.WSSubmitBtnId).setEnabled(false);
			}

			return aReadingSet;
		},

		/*
		 * update measurement set
		 */
		onSaveWheelSheet: function(oEvent) {
			var oPayload = _this.getSavePayload();
			LocomotiveDataModel.updateWheelSheet(oPayload, _this.onSaveWheelSheetSuccess, _this.onSaveWheelSheetFailure, _this);
		},

		/*
		 * update success
		 */
		onSaveWheelSheetSuccess: function(oData) {
			BusyIndicator.hideBusyIndicator();
		},

		/*
		 * update failed
		 */
		onSaveWheelSheetFailure: function() {
			BusyIndicator.hideBusyIndicator();
		},

		/*
		 * submit final measurement set,
		 * prepare payload
		 */
		getSubmitPayload: function() {
			var oWsHeader = _this.getView().getModel().getProperty("/WSHeader");

			oWsHeader["SubmitFlag"] = "X";

			//clean up
			if (oWsHeader.MsetStatus) {
				delete oWsHeader.MsetStatus;
			}

			if (oWsHeader.MSetReadingSet) {
				delete oWsHeader.MSetReadingSet;
			}
			
			if (oWsHeader.MeasPntValue) {
				delete oWsHeader.MeasPntValue;
			}
			
			//build payload
			var oPayload = {};
			oPayload.OperationNbr = oWsHeader.OperationNbr;
			oPayload.OrderNbr = oWsHeader.OrderNbr;
			oPayload.SubOperNbr = oWsHeader.SubOperNbr;
			oPayload.EquipNbr = oWsHeader.EquipNbr;
			oPayload.MsetType = oWsHeader.MsetType;
			oPayload.SubmitFlag = oWsHeader.SubmitFlag;

			return oPayload;
		},

		/*
		 * submit final measurement set,
		 */
		onSubmitWheelSheet: function(oEvent) {
			var oPayload = _this.getSubmitPayload();
			LocomotiveDataModel.submitWheelSheet(oPayload, _this.onSubmitWheelSheetSuccess, _this.onSubmitWheelSheetFailure, _this);
		},

		/*
		 * submit success
		 */
		onSubmitWheelSheetSuccess: function() {
			BusyIndicator.hideBusyIndicator();

			if (_this.oLocomotive) {
				_this.fetchLocomotiveWheelSheet(_this.oLocomotive);
			}
		},

		/*
		 * submit failed
		 */
		onSubmitWheelSheetFailure: function() {
			BusyIndicator.hideBusyIndicator();
		},

		/*
		 * ui utilities
		 */
		refreshWheelSheet: function(oData) {
			_this.inputCount = 0;

			_this.byId("wheelSheetPage").destroyContent();
			_this.getView().getModel().setProperty("/WheelSheet", oData);

			_this.isEditable = (!(oData.SubmitFlag !== "" || oData.MsetStatus === "C"));

			_this.WSSaveBtnId = _this.getView().getModel().getProperty("/WSSaveBtnId");
			_this.WSSubmitBtnId = _this.getView().getModel().getProperty("/WSSubmitBtnId");

			var WSSaveBtn = sap.ui.getCore().byId(_this.WSSaveBtnId);
			var WSSubmitBtn = sap.ui.getCore().byId(_this.WSSubmitBtnId);

			if (WSSaveBtn) {
				WSSaveBtn.setVisible(_this.isEditable);
			}

			if (WSSubmitBtn) {
				WSSubmitBtn.setVisible(_this.isEditable);
			}

			//Code Group Set
			_this.codeGroupsSet = {};

			//Store predefined values to use with dropdown inputs
			var codeGroups = oData.MSetCodeGrpSet.results;
			for (var j = 0; j < codeGroups.length; j++) {
				_this.storeCodeGroups(codeGroups[j]);
			}

			//read measurement sets groups and place them in view
			var groups = oData.MSetGroupSet.results;

			for (var i = 0; i < groups.length; i++) {
				_this.addGroup(groups[i]);
			}

			//check if all inputs are filled to allow submit
			_this.getReadingSet();
		},

		/*
		 * Store predefined values to use with dropdown inputs
		 */
		storeCodeGroups: function(oData) {
			var aValues = oData.MSetCodeValueSet.results;

			if (aValues.length > 0) {
				_this.codeGroupsSet[oData.CodeGrp] = {
					"CatalogType": oData.CatalogType,
					"Values": _this.extractCodeGroupsValues(aValues)
				};
			}
		},

		/*
		 * extract Code Groups Values
		 */
		extractCodeGroupsValues: function(oData) {
			var aResults = [];

			for (var i = 0; i < oData.length; i++) {
				var oEntry = oData[i];

				var oObj = {
					"Code": oEntry.Code,
					"CodeDescription": oEntry.CodeDescription
				};

				aResults.push(oObj);
			}

			return aResults;
		},

		/*
		 * Data driven ui
		 */
		addGroup: function(oData) {
			var sGroupDescription = oData.GroupDescription;

			if (oData.MeasPointSet.results[0].MeasureColumn === 0) {
				//use forms
				_this.displayDataForm(oData.MeasPointSet.results, sGroupDescription);
			} else {
				//use table format
				var aColumnData = _this.extractColumns(oData);
				var aData = _this.extractRows(oData, aColumnData);
				_this.displayDataTable(aColumnData, aData, sGroupDescription);
			}
		},

		/*
		 * Dynamic form
		 */
		displayDataForm: function(aData, sGroupDescription) {
			var oModel = new sap.ui.model.json.JSONModel();

			var oSimpleForm = new sap.ui.layout.form.SimpleForm({
				title: sGroupDescription,
				editable: true,
				layout: "ResponsiveGridLayout",
				labelSpanXL: 4,
				labelSpanL: 3,
				labelSpanM: 4,
				labelSpanS: 12,
				adjustLabelSpan: false,
				emptySpanXL: 0,
				emptySpanL: 4,
				emptySpanM: 0,
				emptySpanS: 0,
				columnsXL: 2,
				columnsL: 1,
				columnsM: 1,
				singleContainerFullSize: false
			});

			oSimpleForm.setModel(oModel);

			for (var i = 0; i < aData.length; i++) {
				var oPoint = aData[i];

				//extract object
				var oObj = _this.objectFromMeasurePoint(oPoint);

				//measurement title
				var oLabel = new sap.m.Label({
					text: oPoint.MeasurePtDescription
				});
				oSimpleForm.addContent(oLabel);

				//measurement input
				var sType = oObj.type;
				var sReading = oObj.value.trim();
				var sInputId = _this.inputIdForMeasurementPoint(oPoint);
				var bEnabled = _this.isEditable;

				var oContent = _this.inputForType(sType, sInputId, sReading, bEnabled);
				oSimpleForm.addContent(oContent);
			}

			_this.byId("wheelSheetPage").addContent(oSimpleForm);
		},

		/*
		 * dynamic table
		 */
		 
		 /*
		 * handle columns
		 */
		 
		extractColumns: function(oData) {
			var aMeasures = oData.MeasPointSet.results;

			var aColumnData = [{
				columnId: "MeasurePosition",
				description: "Position"
			}];

			var index = 1;

			for (var i = 0; i < aMeasures.length; i++) {
				var oMeasurePoint = aMeasures[i];

				if (oMeasurePoint.MeasureColumn === index && oMeasurePoint.MeasureRow === 0) {
					aColumnData.push({
						columnId: oMeasurePoint.MeasurePtName,
						description: oMeasurePoint.MeasurePtDescription
					});
					index++;
				}
			}

			return aColumnData;
		},

		 /*
		 * handle rows
		 */
		extractRows: function(oData, aColumnData) {
			var aMeasures = oData.MeasPointSet.results;

			var oRowsData = {};

			for (var i = 0; i < aMeasures.length; i++) {
				var oMeasurePoint = aMeasures[i];

				if (oMeasurePoint.MeasureRow > 0) {
					var oItem = oRowsData[oMeasurePoint.MeasurePosition];

					if (!oItem) {
						oRowsData[oMeasurePoint.MeasurePosition] = {
							measurePosition: {
								"type": "",
								"value": oMeasurePoint.MeasurePosition
							}
						};

						oItem = oRowsData[oMeasurePoint.MeasurePosition];
					}

					for (var j = 0; j < aColumnData.length; j++) {
						var sColumnId = aColumnData[j].columnId;

						if (oMeasurePoint.MeasurePtName === sColumnId) {

							var oObj = _this.objectFromMeasurePoint(oMeasurePoint);

							oItem[oMeasurePoint.MeasurePtName] = oObj;
							oRowsData[oMeasurePoint.MeasurePosition] = oItem;
						}
					}
				}
			}

			var aData = [];

			for (var key in oRowsData) {
				if (oRowsData.hasOwnProperty(key)) {
					var line = oRowsData[key];
					aData.push(line);
				}
			}

			return aData;
		},

		/*
		 * object type factory
		 */
		objectFromMeasurePoint: function(oMeasurePoint) {
			var sType = "";

			if (oMeasurePoint.CodeGrp !== "") {
				sType = oMeasurePoint.CodeGrp;
			}

			var oObj = {
				"type": sType,
				"value": oMeasurePoint.MeasureDocReading
			};

			return oObj;
		},

		/*
		 *	input factory
		 */
		inputForType: function(sType, sInputId, sReading, bEnabled) {
			_this.inputCount++;

			var oCell;

			if (sType === "") {
				oCell = new sap.m.Input(this.createId(sInputId), {
					showSuggestion: false,
					enabled: bEnabled
				});

				oCell.setValue(sReading);

			} else {

				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(_this.codeGroupsSet[sType]);

				var oItemTemplate = new sap.ui.core.Item({
					key: "{Code}",
					text: "{CodeDescription}"
				});

				oCell = new sap.m.Select({
					id: this.createId(sInputId),
					enabled: bEnabled,
					forceSelection: false,
					items: {
						path: "/Values",
						template: oItemTemplate
					}
				});

				oCell.setModel(oModel);

				oCell.setSelectedKey(sReading);
			}

			return oCell;
		},

		 /*
		 * assemble table
		 */
		displayDataTable: function(aColumnData, aData, sGroupDescription) {
			var oModel = new sap.ui.model.json.JSONModel();

			oModel.setData({
				columns: aColumnData,
				rows: aData
			});

			var oTable = new sap.m.Table({
				inset: true,
				headerText: sGroupDescription
			});

			oTable.setModel(oModel);

			oTable.bindAggregation("columns", "/columns", function(index, context) {
				return new sap.m.Column({
					hlign: "Center",
					vAlign: "Middle",
					header: new sap.m.Label({
						text: context.getObject().description
					})
				});
			});

			oTable.bindItems("/rows", function(index, context) {
				var obj = context.getObject();

				var row = new sap.m.ColumnListItem();

				var i = 0; // skip first obj, it's just the header

				for (var k in obj) {

					var sType = obj[k].type;
					var sReading = obj[k].value.trim();

					var oCell;

					if (i > 0) {
						var sInputId = obj.measurePosition.value + "_" + k;
						var bEnabled = false;
						if (_this.isEditable) {
							bEnabled = true;
						}
						oCell = _this.inputForType(sType, sInputId, sReading, bEnabled);
					} else {
						oCell = new sap.m.Text({
							text: sReading
						});
						i++;
					}

					row.addCell(oCell);
				}

				return row;
			});
			_this.byId("wheelSheetPage").addContent(oTable);
		}
	});
});