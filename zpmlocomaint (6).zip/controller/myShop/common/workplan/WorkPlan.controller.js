/*&---------------------------------------------------------------------*    
 * Author         : SAP Custom Development                               *
 * Date           : 2017.12.21                                           *
 * Project        : Locomotive Maintenance                               *
 * Description    : Controller for Work Orders list fragment. This       *
 *                  fragment is used on views displaying all operations. *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author/Changed By   : Sandhya satavalekar                              *
 * Date                : 02-Feb-2019                                      *
 * Project             : Locomotive Maintenance Phase 2                   *
 * Description         : LMP2-02 : Adding the unTeco Option 	             *
 * Search Term         : LMP2-02                                          *
 *&-----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : KIR0084                                              *
 * Date           : 2019.04.08                                           *
 * Incidinet      : Bug Found - Model undefined		             	     *
 * Description    : Replacing _i18nModel with proper name _oI18nModel	 *
 * Search Term    : _i18nModel undefined								 *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : KIR0084                                              *
 * Date           : 2019.04.01                                           *
 * Incidinet      : LMP2-34 - PM Loco Main phase 2              	     *
 * Description    : Add Number of Crafts					   			 *
 * Search Term    : LMP2-34                                              *
 *&----------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
* Author/Changed By   : Sandesh Shirode(SHI0087)	               		  *
* Date                : 15-April-2019                                     *
* Project             : Locomotive Maintenance Phase 2                    *
* Description         : LMP2-7a : Add attachment functionality to be view *
						from OPeration screen							  *
*&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
 * Author         : KIR0084                                              *
 * Date           : 2019.04.01                                           *
 * Incidinet      : LMP2-36 - Change to edit Comment Button        	     *
 * Description    : Change to edit Comment Button                 		 *
 * Search Term    : LMP2-36                                              *
 *&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
 * Author         : Sandesh Shirode(SHI0087)                             *
 * Date           : 23.Aug.2019                                          *
 * Project        : Locomotive Maintenance Phase 2  			   	     *
 * Description    : LMP2-25 - WheelSheet Measurement Approval            *
 * Search Term    : LMP2-25                                              *
 *&----------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
 * Author         : KIR0084                                              *
 * Date           : 03.Sep.2019                                          *
 * Project        : Locomotive Maintenance Phase 2  			   	     *
 * Description    : LMP2-35 - Work Order Craft popup added               *
 * Search Term    : LMP2-35                                              *
 *&----------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 13.March.2020                                        *
 * Project        : EAM-ASR3414893                   			   	     *
 * Description    : Enhanced release process                             *
 * Search Term    : EAM-ASR3414893                                       *
 *&----------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
 * Author/Changed By   : Vikram BAjaj (BAJ0018)    	               		  *
 * Date                : 25-May-2020                                      *
 * Project             : EAM-ASR3415323					                  *
 * Description         : Revised enhanced released process logic          *	
 *&------------------------------------------------------------------------*/
/*&---------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2020.09.08                                           *
 * Project        : EAM-ASR3415776                                       *
 * Description    : Revised logic for equipment hierarchy  .             *
 *&----------------------------------------------------------------------*/
/*&---------------------------------------------------------------------*    
 * Author         : VYA0004                                              *
 * Date           : Feb 04,2021                                          *
 * Project        : Break and Build Project                              *
 * Description    : Addition of Bnb checks for disabling Release         *
 *                  functionality for BnB loco,Calling Start Bnb and View*
 *                  Inventory screens                                    *
 *Search Term     : VYA0004 2000011826                                   *
 *&----------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : BAJ0018				        		       		   *
* Date                : 19 -Feb -2021                                      *
* Project             : BNB Project                                        *
* Description         : Added BNB Storage locations logic                  *
* Search Term         : BNB                                                *
/*&------------------------------------------------------------------------*/
/*&---------------------------------------------------------------------*    
 * Author         : VYA0004                                              *
 * Date           : April 13,2021                                        *
 * Project        : Break and Build Project                              *
 * Description    : Fixes to Good Return Logic                           *
 *Search Term     : VYA0004 2000012858                                   *
 *&----------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 08-Sep-2021	                                       *
* Project             : Locomotive Maintenance Phase 2                     *
* Description         : Refresh issue with cross navigation		           *
* Search Term         : INC0110700                                         *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 22-Sep-2021	                                       *
* Project             : Locomotive Maintenance Phase 2                     *
* Description         : production issue related to INC0110700	           *
* Search Term         : INC0114906                                         *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : VYA0004				        		       		   *
* Date                : 18-Oct-2021	                                       *
* Project             : LLM3.3                                             *
* Description         : Add button logic for opening pop up for No Material*
*                       Required Reason display                            *
* Search Term         : VYA0004|LLM3.3                                     *
/*&------------------------------------------------------------------------*
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 12-Oct-2021	                                       *
* Project             : LLM3.2 - Revison Number        					   *
* Description         : ERQ Serial Number and SW Revision number		   *
* Search Term         : LLM3.2	                                           *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 25-Nov-2021	                                       *
* Project             : EAM-LLM 1.2 Serialization     					   *
* Description         : Serialization of material and equipment			   *
* Search Term         : LLM1.2	                                           *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : ANI0006				        		       		   *
* Date                : 11-Nov-2021	                                       *
* Project             : EAM Railinc EPA    					               *
* Description         : EPA Information - Fields Masking		           *
* Search Term         : ANI0006 2000014601                                 *
/*&------------------------------------------------------------------------*/

// #DontDelete : Daya ; New controller class , Do not delete any method in this class.

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/BusyIndicator",
	"sap/ui/model/json/JSONModel",
	"com/sap/cp/lm/controller/locomotives/LocomotiveManager",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
	"com/sap/cp/lm/model/main/TrackSpotModel",
	"com/sap/cp/lm/controller/myShop/common/CloseOutCode",
	"com/sap/cp/lm/controller/myShop/common/CraftWorkPlan",
	"com/sap/cp/lm/controller/myShop/common/AddDefectManager",
	"com/sap/cp/lm/controller/myShop/common/BreakBuildQualify/StartBnB",
	"com/sap/cp/lm/controller/myShop/common/BreakBuildQualify/ViewInventory",
	"com/sap/cp/lm/controller/myShop/shopped/addMaterial/AddMaterial",
	"com/sap/cp/lm/util/ErrorManager",
	"com/sap/cp/lm/util/Helper",
	"com/sap/cp/lm/controller/myShop/servicing/serviceGroup/serviceGroupDialog",
	"com/sap/cp/lm/controller/craft/CraftManager",
	"com/sap/cp/lm/controller/common/MeasPointSheet",
	"com/sap/cp/lm/controller/common/SerialNumber",
	"com/sap/cp/lm/controller/myShop/common/OperationLongTextDialog",
	"com/sap/cp/lm/controller/myShop/common/WorkOrderComments",
	"com/sap/cp/lm/controller/myShop/common/workplan/RequestMatDialog",
	"com/sap/cp/lm/controller/myShop/common/IncidentNumberManager",
	"com/sap/cp/lm/controller/common/ArriveManager",
	"com/sap/cp/lm/model/work/WorkDataModel",
	"com/sap/cp/lm/model/material/MaterialModel",
	'sap/m/MessageBox',
	"sap/ui/unified/FileUploaderParameter"
], function (Controller, Constants, BusyIndicator, JSONModel, LocomotiveManager, LocomotiveDataModel, TrackSpotModel, CloseOutCode,
	CraftWorkPlan,
	AddDefectManager, StartBnB, ViewInventory, AddMaterial, ErrorManager, Helper, serviceGroupDialog, CraftManager, MeasPointSheet,
	SerialNumber,
	OperationLongTextDialog, WorkOrderComments,
	RequestMatDialog, IncidentNumberManager, ArriveManager, WorkDataModel, MaterialModel, MessageBox, FileUploaderParameter) {
	"use strict";

	var _this;

	return Controller.extend("com.sap.cp.lm.controller.myShop.common.workplan.WorkPlan", {

		/**
		 * Function is called when Controller is loaded only for the first time 
		 */
		onInit: function () {
			_this = this;

			_this._oView = _this.getView();
			_this._oRouter = sap.ui.core.UIComponent.getRouterFor(_this._oView);

			_this.getView().setModel(new sap.ui.model.json.JSONModel());

			_this._oGlobalLocomotiveModel = _this.getOwnerComponent().getGlobalLocomotiveModel();
			_this._oI18nModel = _this.getOwnerComponent().getModel("i18n");
			_this._oGlobalModel = _this.getOwnerComponent().getGlobalModel();
			//Start: ANI0006 2000014601 - get Engine Manfacture Model
			_this._oEngineManfModel = _this.getOwnerComponent().getEngManfJsonModel();
			//End: ANI0006 2000014601 - get Engine Manfacture Model
			_this._oViewModel = new JSONModel();
			_this._oViewPropertiesModel = new JSONModel();
			_this._initViewPropertiesModel();
			_this._oView.setModel(_this._oViewPropertiesModel, "viewProperties");

			//Buffer the workplan controller which is used in CraftAssignmentManager.js to reload the selected locomotive on assigning the craft
			_this._oGlobalModel.setProperty("/oWorkplanController", _this);

			_this.oExpandedWO = {};
			_this._oPanelExpandModel = new JSONModel();
			_this.getView().setModel(_this._oPanelExpandModel, "PanelExpandModel");

			_this.oModel = _this.getView().getModel();

		},

		//**********************Initialization **************************************

		handleWindowResize: function () {
			if (_this.oDialog) {
				_this.resizeDialog();
			}
		},

		//Initialize the work plan with new set of data

		loadData: function (oParameters) {

			var role = _this._oGlobalModel.getProperty("/role");
			this.oModel.setProperty("/role", role);

			this._oOperationContent = null;
			this._oTaskContent = null;
			if (_this._oGlobalModel.getProperty("/selectedMyShopTab") === Constants.TEXT_SERVICING) {
				this._IsServicing = true;
				// LMP2-35 KIR0084 Add IsShopped to view properties
			} else if (_this._oGlobalModel.getProperty("/selectedMyShopTab") === Constants.TEXT_SHOPPED) {
				this._IsShopped = true;
			} else {
				this._IsServicing = false;
				this._IsShopped = false;
			}
			// LMP2-35 KIR0084 Add IsShopped to view properties
			this._oViewPropertiesModel.setProperty("/isShopped", this._IsShopped);
			if (this._IsServicing) {
				this._IsServicing = true;
				this._oServicing = oParameters.serviceLocoObject;
				this._oViewPropertiesModel.setProperty("/Status/visible", false);
				this._oViewPropertiesModel.setProperty("/isServicing", true);
				this._oViewPropertiesModel.setProperty("/TaskSelectionMode", "MultiSelect");
				this._oViewPropertiesModel.setProperty("/TaskToolBar", true);
				this._oViewPropertiesModel.setProperty("/TaskStatusVisible", true);
			} else {
				// _this.getView().byId("idAssignSelMe").setEnabled(false);
				this._oViewPropertiesModel.setProperty("/isServicing", false);
				this._oViewPropertiesModel.setProperty("/Status/visible", true);
				this._oViewPropertiesModel.setProperty("/TaskSelectionMode", "None");
				this._oViewPropertiesModel.setProperty("/TaskToolBar", false);
				this._oViewPropertiesModel.setProperty("/TaskStatusVisible", false);

				if (oParameters.iconTabBar) {
					this._oIconTabBar = oParameters.iconTabBar;
				}
				this._IsServicing = false;
				this._sEquipmentNo = oParameters.equipmentNo;
			}

			if (oParameters.model && typeof oParameters.model.length === "undefined") {

				var woStatus = [];
				var oWorkOrder = oParameters.model.getProperty(oParameters.bindPath);

				if (oWorkOrder) {
					for (var i = 0; i < oWorkOrder.length; i++) {
						woStatus[oWorkOrder[i].OrderNo] = oWorkOrder[i].Status;
					}
				}
				this._oViewPropertiesModel.setProperty("/WorkOrders", woStatus);
				this._oViewPropertiesModel.setProperty("/LocomotiveNumber", oParameters.locomotiveNumber);

				if (typeof oParameters.model.length === "undefined") { //object
					var oData = oParameters.model.getData();
					// this.oModel.setData(oData);
					_this._oGlobalModel.setProperty("/detailsData", oData.detailsData); // SHE0272 - INC0110700 - Setting the data to global model instead of local
				}
			}

			if (!this._IsServicing) {
				if (this._oPanelExpandModel.getProperty("/LocoNumber") !== oParameters.locomotiveNumber) {
					this.oExpandedWO = {
						"LocoNumber": oParameters.locomotiveNumber
					};

					this._oPanelExpandModel.setData(this.oExpandedWO);
					this._oPanelExpandModel.setProperty(oParameters.locomotiveNumber, {});
				}
			} else {

				if (this._oPanelExpandModel.getProperty("/LocoNumber") !== oParameters.locomotiveNumber) {
					this.oExpandedWO = {
						"LocoNumber": ""
					};

					this._oPanelExpandModel.setData(this.oExpandedWO);
					this._oPanelExpandModel.setProperty(oParameters.locomotiveNumber, {});
				}
			}

			this.initAdditionalWorkPlanProperties();

		},

		/**
		 * Initialize the view properties model
		 */
		_initViewPropertiesModel: function (bValue) {
			var isDesktop = !this._oViewModel.getProperty("/isMapDetailDualPlanScreen");
			this._oViewPropertiesModel.setProperty("/IsDesktop", isDesktop);
			// LMP2-35 KIR0084 Set isShopped.
			this._oViewPropertiesModel.setProperty("/isShopped", false);
			this._oViewPropertiesModel.setProperty("/MyWork", false);
			this._oViewPropertiesModel.setProperty("/LocoWorkPlanTopBar", {
				visible: false
			});
			this._oViewPropertiesModel.setProperty("/MyWorkTopBar", {
				visible: false
			});
			this._oViewPropertiesModel.setProperty("/AllWorkTopBar", {
				visible: false
			});
			this._oViewPropertiesModel.setProperty("/AddRemoveOperation", {
				visible: false,
				width: "10%"
			});
			this._oViewPropertiesModel.setProperty("/ProgressIndicator", {
				visible: true,
				width: "100%"
			});
			this._oViewPropertiesModel.setProperty("/IsWOExpandable", true);
			this._oViewPropertiesModel.setProperty("/WOType", true);
			this._oViewPropertiesModel.setProperty("/AddOperation", {
				visible: true
			});
			this._oViewPropertiesModel.setProperty("/TotalOperation", {
				visible: false
			});
			this._oViewPropertiesModel.setProperty("/AddComments", {
				visible: true,
				width: "100%"
			});
			this._oViewPropertiesModel.setProperty("/AddMaterials", {
				visible: true,
				width: "100%"
			});
			this._oViewPropertiesModel.setProperty("/AddAttachments", {
				visible: false,
				width: "100%"
			});
			this._oViewPropertiesModel.setProperty("/ActionSheetVisibility", {
				visible: true
			});
			this._oViewPropertiesModel.setProperty("/EditWOVisibility", {
				visible: false
			});
			this._oViewPropertiesModel.setProperty("/AddOperationUpdate", true);
			this._oViewPropertiesModel.setProperty("/CheckBox", {
				visible: true,
				width: "5%"
			});
			this._oViewPropertiesModel.setProperty("/Operation", {
				visible: true,
				width: "35%"
			});
			this._oViewPropertiesModel.setProperty("/OperationNumber", {
				visible: false,
				width: "5%"
			});

			this._oViewPropertiesModel.setProperty("/PlannedStart", {
				visible: true,
				width: "6%"
			});
			this._oViewPropertiesModel.setProperty("/Spot", {
				visible: true,
				width: "6%"
			});
			this._oViewPropertiesModel.setProperty("/GE", {
				visible: false,
				width: "5%"
			});
			this._oViewPropertiesModel.setProperty("/Workers", {
				visible: true,
				width: "6%"
			});
			this._oViewPropertiesModel.setProperty("/EstimatedTime", {
				visible: true,
				width: "11%"
			});
			this._oViewPropertiesModel.setProperty("/LeadmanTime", {
				visible: false
			});
			this._oViewPropertiesModel.setProperty("/Materials", {
				visible: true,
				width: "9%"
			});
			this._oViewPropertiesModel.setProperty("/CompletedBy", {
				visible: true,
				width: "8%"
			});
			this._oViewPropertiesModel.setProperty("/ConfirmedBy", {
				visible: true,
				width: "8%"
			});
			this._oViewPropertiesModel.setProperty("/Status", {
				visible: true,
				width: "10%"
			});
			this._oViewPropertiesModel.setProperty("/TaskCount", {
				visible: true,
				width: "7%"
			});
			this._oViewPropertiesModel.setProperty("/StatusMyWork", {
				visible: false,
				width: "13%"
			});
			this._oViewPropertiesModel.setProperty("/AddToMyWork", {
				visible: false,
				width: "15%"
			});
			this._oViewPropertiesModel.setProperty("/ActualTime", {
				visible: false,
				width: "15%"
			});
			this._oViewPropertiesModel.setProperty("/WheelSheetLink", {
				visible: true,
				width: "36%"
			});
			this._oViewPropertiesModel.setProperty("/OperationAction", {
				visible: true,
				width: "15%"
			});
			this._oViewPropertiesModel.setProperty("/TaskDescription", {
				visible: true,
				hboxWidth: "100%",
				width: "45%"
			});
			this._oViewPropertiesModel.setProperty("/TechnicalObject", {
				visible: false,
				width: "25%"
			});
			this._oViewPropertiesModel.setProperty("/LocomotiveName", {
				visible: false,
				width: "0%"
			});
			this._oViewPropertiesModel.setProperty("/TaskName", {
				visible: true,
				width: "15%"
			});
			this._oViewPropertiesModel.setProperty("/TaskConfirm", {
				visible: false,
				width: "15%"
			});
			this._oViewPropertiesModel.setProperty("/TaskGroupConfirm", {
				visible: false,
				width: "13%"
			});
			this._oViewPropertiesModel.setProperty("/WOHBox", {
				visible: true,
				width: "52%"
			});
			this._oViewPropertiesModel.setProperty("/TaskTable", {
				visible: true
			});
			this._oViewPropertiesModel.setProperty("/AssignmentDeletion", {
				visible: false,
				width: "10%"
			});
			this._oViewPropertiesModel.setProperty("/ShiftListVisibility", {
				visible: false,
				width: "100%"
			});
			this._oViewPropertiesModel.setProperty("/WorkPlanHeaderText", {
				visible: true,
				width: "100%"
			});
			this._oViewPropertiesModel.setProperty("/StageCheck", {
				visible: false,
				width: "100%"
			});
		},

		hideCheckboxes: function () {
			this._oViewPropertiesModel.setProperty("/CheckBox", {
				visible: false,
				width: "6%"
			});
		},

		initAdditionalWorkPlanProperties: function () {
			// var aWorkOrders = this.getView().getModel().getObject("/detailsData/results");
			var aWorkOrders = _this._oGlobalModel.getObject("/detailsData/results"); // SHE0272 - INC0110700 - getting the data from global model instead of local

			var openWO = aWorkOrders.length;

			aWorkOrders.forEach(function (oWorkOrder) {
				oWorkOrder.checked = false;

				if (oWorkOrder.Status === Constants.STATUS_COMPLETED || oWorkOrder.Status === Constants.STATUS_DEFERRED) {
					openWO = openWO - 1;
				}

				if (oWorkOrder.OperationSet.results) {
					oWorkOrder.OperationSet.results.forEach(function (oOperation) {
						oOperation.checked = false;
					});
				}
			});

			var canRelease = (openWO === 0);
			//VYA0004 2000011826 Begin
			if (_this._oGlobalModel.getProperty("/currentLocomotive").BnbLocoShop) {
				canRelease = false;
			}
			//VYA0004 2000011826 End
			// this.getView().getModel().setProperty('/CanRelease', canRelease);
			_this._oGlobalModel.setProperty('/CanRelease', canRelease); // SHE0272 - INC0110700 - Setting the data to global model instead of local
		},

		//***************Begin of Event Handlers************************************

		//******************************Event Handlers at Header Level********************************

		/* #DontDelete : Yann */
		/**
		 * change track 
		 */
		onChangeTrack: function (oEvent) {
			var key = oEvent.getSource().getSelectedKey();
			var spotSelect = sap.ui.getCore().byId('releaseDialogSpotSelect');
			var spotSet = _this.filterSpots(key);
			_this.dialogSetProperty("/AvailableSpotSet", spotSet);

			spotSelect.setEnabled(true);
			spotSelect.setSelectedItem(null);
		},
		// Start - BAJ0018 - EAM-ASR3414893
		/**
		 * Supervisor option to re-service a loco after release
		 */
		onReservice: function (oEvent) {
			//START - BAJ0018 - revised enhanced release process
			// release the locomotive if it is not released already
			if (_this._oGlobalModel.getProperty("/currentLocomotive").ShopStatus !== 'R') {
				_this._oGlobalModel.setProperty("/relLocoFirst", true);
			} else {
				_this._oGlobalModel.setProperty("/relLocoFirst", false);
			}

			// if (_this._oGlobalModel.getProperty("/currentLocomotive").ShopStatus !== 'R') {
			// 	// Release shop Dialog
			// 	if (!_this._oReleaseShopDialog) {
			// 		_this._oReleaseShopDialog = sap.ui.xmlfragment(
			// 			"com.sap.cp.lm.view.myShop.common.ReleaseDialog",
			// 			_this);
			// 	}
			// 	_this.shop = " ";
			// 	_this._oReleaseShopDialog.open();
			// } else {
			//END - BAJ0018 - revised enhanced release process
			var oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
			LocomotiveDataModel.fetchLocomotiveDefects(oLocomotive, _this.onFetchLocomotiveDefectsSuccessForService, _this.onFetchLocomotiveDefectsFailure,
				_this);
			// }
		},

		/**
		 * Supervisor option to re-arrive a loco after release
		 */
		onReshop: function (oEvent) {
			//START - BAJ0018 - revised enhanced release process
			if (_this._oGlobalModel.getProperty("/currentLocomotive").ShopStatus !== 'R') {
				_this._oGlobalModel.setProperty("/relLocoFirst", true);
			} else {
				_this._oGlobalModel.setProperty("/relLocoFirst", false);
			}
			// release the locomotive if it is not released already
			// if (_this._oGlobalModel.getProperty("/currentLocomotive").ShopStatus !== 'R') {
			// 	// Release shop Dialog
			// 	if (!_this._oReleaseShopDialog) {
			// 		_this._oReleaseShopDialog = sap.ui.xmlfragment(
			// 			"com.sap.cp.lm.view.myShop.common.ReleaseDialog",
			// 			_this);
			// 	}
			// 	_this.shop = "X";
			// 	_this._oReleaseShopDialog.open();
			// } else {
			// follow existing process
			//END - BAJ0018 - revised enhanced release process
			var oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
			LocomotiveDataModel.fetchLocomotiveDefects(oLocomotive, _this.onFetchLocomotiveDefectsSuccess, _this.onFetchLocomotiveDefectsFailure,
				_this);
			// }
		},
		onRelShopOk: function () {
			var sShopId = this._oGlobalModel.getProperty("/currentShop").Id;
			var oLocomotive = this._oGlobalModel.getProperty("/currentLocomotive");
			var oPayload = {
				"ShopId": sShopId,
				"LocoId": oLocomotive.LocomotiveId
			};
			LocomotiveDataModel.releaseLocomotive(oPayload, _this.onReleaseShopLocomotiveSuccess, _this.onReleaseLocomotiveFailure,
				_this);
		},
		onRelShopClose: function () {
			if (_this._oReleaseShopDialog) {
				_this._oReleaseShopDialog.close();
				_this._oReleaseShopDialog.destroy();
				_this._oReleaseShopDialog = null;
			}
		},
		// END - BAJ0018 - EAM-ASR3414893		

		onReleaseShopLocomotiveSuccess: function (oData) {
			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.publish("ReleaseProcess", "releaseProcessDone", {
				"success": true
			});

			if (_this._oReleaseShopDialog) {
				_this._oReleaseShopDialog.close();
				_this._oReleaseShopDialog.destroy();
				_this._oReleaseShopDialog = null;
			}
			var oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
			sap.m.MessageToast.show(oLocomotive.LocomotiveId + "  is Released", {
				duration: 4000
			});

			if (_this.shop === "X") {
				LocomotiveDataModel.fetchLocomotiveDefects(oLocomotive, _this.onFetchLocomotiveDefectsSuccess, _this.onFetchLocomotiveDefectsFailure,
					_this);
			} else {

				LocomotiveDataModel.fetchLocomotiveDefects(oLocomotive, _this.onFetchLocomotiveDefectsSuccessForService, _this.onFetchLocomotiveDefectsFailure,
					_this);
			}
		},
		/**
		 * Supervisor option to remove loco from map after release
		 */
		onRemoveFromMap: function (oEvent) {
			var sShopId = _this._oGlobalModel.getProperty("/currentShop").Id;
			var oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");

			var oPayload = {
				"ShopId": sShopId,
				"LocoId": oLocomotive.LocomotiveId
			};

			LocomotiveDataModel.departLocomotive(oPayload, _this.onDepartLocomotiveSuccess, null, _this);
		},

		//******************************Event Handlers at WorkOrder Level******************************
		/**
		 * Triggers on Expand/Collapse the WorkOrder, Set the panel model with expanded Workder
		 * @params(oEvent) oEvent parameter on Click
		 */
		onExpandWorkPanel: function (oEvent) {
			var oPanel = oEvent.getSource();

			var oWorkOrder = oPanel.getBindingContext("global").getObject(); // SHE0272 - INC0110700 - Getting the data from global model instead of local
			var sStatus = oWorkOrder.Status;
			var sWorkOrderType = oWorkOrder.OrderType; // LMP2_181
			var oOperationSet = oWorkOrder.OperationSet.results;
			for (var i = 0; i < oOperationSet.length; i++) {
				oOperationSet[i].WorkOrderStatus = sStatus;
				oOperationSet[i].WorkOrderType = sWorkOrderType; // LMP2_181
			}

			oPanel.addStyleClass("lmSelectedPanel");
			this.oExpandedWO.orderType = sWorkOrderType;
			//_this.getView().getModel("PanelExpandModel").setProperty("/orderType", sWorkOrderType);
			this._oPanelExpandModel.setProperty("/orderType", sWorkOrderType);
			var sOrderNumber = {};
			if (oPanel.getContent().length === 0 && oPanel.getExpanded()) {
				this._oOperationContent = !this._oOperationContent ? sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.common.workplan.CustomOperationList", this) : this._oOperationContent;
				oPanel.addContent(this._oOperationContent.clone());
				sOrderNumber = oEvent.getSource().getBindingContext("global").getObject().OrderNo; // SHE0272 - INC0110700 - Getting the data from global model instead of local
			}

			var bExpand = oEvent.getParameters().expand;

			if (bExpand) {
				if (!this.oExpandedWO[sOrderNumber]) {
					this.oExpandedWO[sOrderNumber] = {};
				}
			} else {
				delete this.oExpandedWO[sOrderNumber];
			}

			if (this._IsServicing && _this._oGlobalModel.getProperty("/currentLocomotive") === null) {
				var aLoco = {};
				aLoco.Equipment = oEvent.getSource().getBindingContext("global").getObject().EquipNo; // SHE0272 - INC0110700 - Getting the data from global model instead of local
				aLoco.LocoId = oEvent.getSource().getBindingContext("global").getObject().LocoId; // SHE0272 - INC0110700 - Getting the data from global model instead of local
				_this._oGlobalModel.setProperty("/currentLocomotive", aLoco);
			}
		},

		searchLocomotivesInFleetSuccess: function (oData) {
			if (oData && oData.length > 0) {
				var oLocomotive = oData[0];
				_this._oGlobalModel.setProperty("/currentLocomotive", oLocomotive);
				_this._oGlobalModel.setProperty("/fleetSelectedLocomotive", oLocomotive);
				_this._oGlobalModel.setProperty("/fleetDetailsOrigin", "servicingGroupWorkPlan");
				setTimeout(function () {
					_this._oRouter.getTargets().display("fleetDetails");
				}, 200);
			} else {
				var msg = this._oI18nModel.getProperty("COULD_NOT_RETRIEVE_LOCOMOTIVE");
				ErrorManager.handleError("", msg);
			}
		},

		//In Servicing for Grouped wworkorder Locomotive Details are shown in Dialog
		onLocoDetails: function (oEvent) {
			var locoId = oEvent.getSource().getBindingContext("global").getObject().LocoId; // SHE0272 - INC0114906 - Setting the data to global model instead of local

			LocomotiveDataModel.searchLocomotivesInFleet(locoId, _this.searchLocomotivesInFleetSuccess, null, _this);
		},

		/**
		 * Triggers on click of Tool bar on Work Order
		 * @params(oEvent) oEvent parameter on Click
		 */
		onClickWOToolBarExpand: function (oEvent) {
			var oPanel = oEvent.getSource().getParent();
			oPanel.setExpanded(!oPanel.getExpanded());
		},

		/***
		 * Open add material dialog on button click
		 */
		onClickAddMaterialButtonInWorkPlan: function (oEvent) {
			if (!_this._oAddMaterialDialog) {
				_this._oAddMaterialDialog = AddMaterial.init(_this, _this.fetchAndRefreshView);
			}

			var oSelectedWorkOrder = this.getView().getModel("global").getObject(oEvent.getSource().getBindingContext("global").sPath); // SHE0272 - INC0110700 - Getting the data from global model instead of local
			_this._oAddMaterialDialog.onAddMaterialDialogOpen(oSelectedWorkOrder);
		},

		/** START KIR0084 LMP2-36 Remove Comment on Workplan Button */
		// 		onClickLocoWorkPlanComment: function(oEvent) {

		// 			var oParams = {};
		// 			oParams.oWorkOrderHeader = oEvent.getSource().getBindingContext().getObject();
		// 			var oWorkOrderComments = new WorkOrderComments(oParams);
		// 			if(!_this._oI18nModel && _this.getOwnerComponent()) {
		// 				_this._oI18nModel = _this.getOwnerComponent().getModel("i18n");
		// 			}
		// 			oWorkOrderComments.getFragment().setModel(_this._oI18nModel, "i18n");
		// 			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oWorkOrderComments);
		// 			oWorkOrderComments.getFragment().open();
		// 		},
		/** END KIR0084 LMP2-36 Remove Comment on Workplan Button */

		/**
		 * Open action sheet when drop down list button is clicked in workorder panel
		 * @params(oEvent) oEvent is when drop down list is clicked in workorderpanel
		 */
		openActionSheet: function (oEvent) {

			//$("#" + oEvent.getSource().sId).closest(".sapMCustomListItemPanelStyle").control()[0];
			//this.oSelectedToolBar =oEvent.getSource().getParent().getParent();
			// this.oSelectedPanel = $("#" + oEvent.getSource().sId).closest(".sapMCustomListItemPanelStyle").control()[0];
			this._selectedContext = oEvent.getSource().getBindingContext("global"); // SHE0272 - INC0110700 - Getting the data from global model instead of local

			this.oLocomotiveNumber = oEvent.getSource().getCustomData()[1].getProperty("value");
			this.sOperationNum = oEvent.getSource().getCustomData()[0].getProperty("value");
			LocomotiveManager.openActionSheet(oEvent, this.byId("idWorkOrderList"), this);

		},

		/**
		 * Open dialog fragment when "undo defer work order" is selected in action sheet in drop down list in workorder panel
		 */
		onClickUndoDeferWork: function (oEvent) {
			var oContext = oEvent.getSource().getParent().getBindingContext();
			var oWorkOrder = oContext.oModel.getProperty(oContext.sPath);

			var currentShop = _this._oGlobalModel.getProperty("/currentShop");

			var oPayload = {
				"DefectNo": oWorkOrder.DefectNo,
				"ShopId": currentShop.Id,
				"OrderType": oWorkOrder.OrderType
			};

			LocomotiveDataModel.adoptShoppedLocomotiveDefect(oPayload, _this._editShoppedLocomotiveDefectSuccess, null, _this);
		},

		_editShoppedLocomotiveDefectSuccess: function (oData) {
			_this._reloadShoppedLocomotiveDefects();
		},

		/**
		 * Open Defer Work DIALOG fragment
		 */
		onClickDeferWork: function (oEvent) {
			var aSelWorkOrder = this._selectedContext.getObject();

			var sDefectNo = aSelWorkOrder.DefectNo;
			var sWorkOrderDescr = aSelWorkOrder.Descr;

			if (sDefectNo) {
				_this._currentDefectNo = sDefectNo;

				var deferalCodes = _this._oGlobalModel.getProperty("/DeferalCodes");
				var defaultDeferalCodeValue = _this._oGlobalModel.getProperty("/DefaultDeferalCodeValue");

				var shops = _this._oGlobalModel.getProperty("/Shops");
				var sShopid = this._oGlobalModel.getProperty("/currentShop").Id;

				if (deferalCodes && shops) {
					_this._oDeferDefectDialog = sap.ui.xmlfragment(
						"com.sap.cp.lm.view.myShop.common.DeferDefectDialog",
						_this
					);

					if (_this._oDeferDefectDialog) {
						var oModel = new sap.ui.model.json.JSONModel();
						oModel.setProperty("/DefaultDeferalCodeValue", defaultDeferalCodeValue);
						oModel.setProperty("/DeferalCodes", deferalCodes);
						oModel.setProperty("/Shops", shops);
						oModel.setProperty("/CurrentShopId", sShopid);
						oModel.setProperty("/Title", sWorkOrderDescr);
						_this._oDeferDefectDialog.setModel(oModel);
					}

					_this._oDeferDefectDialog.setBindingContext(_this._currentDefectContext);
					_this.getView().addDependent(_this._oDeferDefectDialog);
					_this._oDeferDefectDialog.open();
				}
			}
		},

		/**
		 * Close Defer Work DIALOG
		 */
		onDeferDefectDialogCancel: function (oEvent) {
			_this._oDeferDefectDialog.close();
			_this._oDeferDefectDialog.destroy();
		},

		/**
		 * Submit Defer Work DIALOG form
		 */
		onDeferDefectDialogOk: function (oEvent) {
			var oContent = oEvent.getSource().getParent().getContent();
			var aItems = oContent[0].getItems();

			var sDeferCode = aItems[2].getSelectedKey();
			var sDeferDescr = aItems[4].getValue();
			var sShop = aItems[6].getSelectedKey();

			var sDefectNo = _this._currentDefectNo;

			if (sDefectNo) {
				if (sDeferCode && sDeferCode.length > 0) {
					if (sShop && sShop.length > 0) {
						var oPayload = {
							"DefectNo": sDefectNo,
							"DeferCode": sDeferCode,
							"DeferDescr": sDeferDescr,
							"Shop": sShop
						};

						LocomotiveDataModel.deferInboundLocomotiveDefect(oPayload, _this._deferDefectSuccess, null, this);
					} else {
						var msg = this._oI18nModel.getProperty("PLEASE_SELECT_SHOP");
						ErrorManager.handleError("", msg);
					}
				} else {
					var msg = this._oI18nModel.getProperty("PLEASE_SELECT_DEFERAL_CODE");
					ErrorManager.handleError("", msg);
				}
			} else {
				var msg = this._oI18nModel.getProperty("INVALID_DEFECT_NUMBER");
				ErrorManager.handleError("", msg);
			}
		},

		/**
		 * open dialog to complete work order
		 */
		onClickCompleteWorkOrder: function (oEvent) {
			var oWorkOrder = this._selectedContext.getObject();

			var sOrderNo = oWorkOrder.OrderNo;
			if (sOrderNo) {
				_this._currentOrderNo = sOrderNo;
			}

			_this._oCompleteWorkDialog = sap.ui.xmlfragment(
				"com.sap.cp.lm.view.myShop.inbound.defects.CompleteWorkDialog",
				_this
			);

			_this.bIsRegulatory = oWorkOrder.RegulatoryInd;

			if (_this._oCompleteWorkDialog) {
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setProperty("/isRegulatory", _this.bIsRegulatory);
				_this._oCompleteWorkDialog.setModel(oModel);
				_this._oCompleteWorkDialog.setModel(oModel);
			}

			_this.getView().addDependent(_this._oCompleteWorkDialog);
			_this._oCompleteWorkDialog.open();
		},

		onCompleteWorkDialogCancel: function (oEvent) {
			_this._currentOrderNo = null;
			_this._oCompleteWorkDialog.close();
			_this._oCompleteWorkDialog.destroy();
		},
		//START - BAJ0018 - BNB
		onPressIsuueTmWag: function (oEvent) {
			var oWorkOrder = this._selectedContext.getObject();
			_this.oWorkOrder = oWorkOrder;
			var oPayload = {
				"MvtType": "1",
				"OrderNumber": oWorkOrder.OrderNo,
				"TmStorageLocation": '',
				"TmValuationType": '',
				"WagStorageLocation": '',
				"WagValuationType": ''
			};
			LocomotiveDataModel.bnbGoodsMvt(oPayload);

		},

		onPressReturnTmWag: function (oEvent) {
			var oWorkOrder = this._selectedContext.getObject();
			var aStorageLocation = _this._oGlobalModel.getProperty("/BnbStorageLocation");
			var sIlart = oWorkOrder.Ilart;
			_this.oWorkOrder = oWorkOrder;
			switch (sIlart) {
			case 'BRK':
				var aTmStorageLocation = aStorageLocation.filter(function (result) {
					return result.Type === "T" && result.Movement === "2" && result.BreakFlg === true;
				});

				var aWagStorageLocation = aStorageLocation.filter(function (result) {
					return result.Type === "W" && result.Movement === "2" && result.BreakFlg === true;
				});
				break;
			case 'BUI':
				aTmStorageLocation = aStorageLocation.filter(function (result) {
					return result.Type === "T" && result.Movement === "2" && result.BuildFlg === true;
				});

				aWagStorageLocation = aStorageLocation.filter(function (result) {
					return result.Type === "W" && result.Movement === "2" && result.BuildFlg === true;
				});
				break;

			case 'QUA':
				aTmStorageLocation = aStorageLocation.filter(function (result) {
					return result.Type === "T" && result.Movement === "2" && result.QualifyFlg === true;
				});

				aWagStorageLocation = aStorageLocation.filter(function (result) {
					return result.Type === "W" && result.Movement === "2" && result.QualifyFlg === true;
				});
				break;
			default:
				// code block
			}
			if (!_this._oReturnTmWagDialog) {
				_this._oReturnTmWagDialog = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.common.workplan.BnbGoodsReturn",
					_this
				);
			}
			if (aTmStorageLocation[0].Bwtar) {
				var sTmValuation = aTmStorageLocation[0].Bwtar;
			}
			if (aWagStorageLocation[0].Bwtar) {
				var sWagValuation = aWagStorageLocation[0].Bwtar;
			}

			if (aTmStorageLocation[0].Lgort) {
				var sTmSloc = aTmStorageLocation[0].Lgort;
			}
			if (aWagStorageLocation[0].Bwtar) {
				var sWagSloc = aWagStorageLocation[0].Lgort;
			}
			// set the data model
			var oData = {
				"tmDesc": oWorkOrder.BnbTmDesc,
				"wagDesc": oWorkOrder.BnbWagDesc,
				"workorder": oWorkOrder.OrderNo,
				"tmStorageLocation": aTmStorageLocation,
				"wagStorageLocation": aWagStorageLocation,
				"tmStorageLoc": sTmSloc,
				"wagStorageLoc": sWagSloc,
				"tmValuation": sTmValuation,
				"wagValuation": sWagValuation,
				"tmStorageLocKey": sTmSloc,
				"wagStorageLocKey": sWagSloc,
				"tmValuationKey": sTmValuation,
				"wagValuationKey": sWagValuation

			};
			var oModel = new sap.ui.model.json.JSONModel(oData);
			_this._oReturnTmWagDialog.setModel(oModel);

			_this.getView().addDependent(_this._oReturnTmWagDialog);
			_this._oReturnTmWagDialog.open();
		},

		onChangeTm: function (oEvent) {
			var key = oEvent.getSource().getSelectedItem().getKey();
			var keys = key.split('|');
			_this._oReturnTmWagDialog.getModel().setProperty("/tmValuation", oEvent.getSource().getSelectedItem().getAdditionalText());
			_this._oReturnTmWagDialog.getModel().setProperty("/tmStorageLoc", oEvent.getSource().getSelectedItem().getText());
			_this._oReturnTmWagDialog.getModel().setProperty("/tmValuationKey", keys[1]);
			_this._oReturnTmWagDialog.getModel().setProperty("/tmStorageLocKey", keys[0]);
		},

		onChangeWag: function (oEvent) {
			var key = oEvent.getSource().getSelectedItem().getKey();
			var keys = key.split('|');
			_this._oReturnTmWagDialog.getModel().setProperty("/wagValuation", oEvent.getSource().getSelectedItem().getAdditionalText());
			_this._oReturnTmWagDialog.getModel().setProperty("/wagStorageLoc", oEvent.getSource().getSelectedItem().getText());
			_this._oReturnTmWagDialog.getModel().setProperty("/wagValuationKey", keys[1]);
			_this._oReturnTmWagDialog.getModel().setProperty("/wagStorageLocKey", keys[0]);
		},
		onBnbGoodsReturnDialogCancel: function () {
			//VYA0004 2000012858 Begin 04/13/2021 BnB Defect
			var oTmReset = sap.ui.getCore().byId("tmSelect").getFirstItem();
			var sTmResetKey = oTmReset.getKey();
			sap.ui.getCore().byId("tmSelect").setSelectedKey(sTmResetKey);
			var oWagReset = sap.ui.getCore().byId("wagSelect").getFirstItem();
			var sWagResetKey = oWagReset.getKey();
			sap.ui.getCore().byId("wagSelect").setSelectedKey(sWagResetKey);
			//VYA0004 2000012858 End BnB Defect
			_this._oReturnTmWagDialog.close();
		},

		onBnbGoodsReturnDialogOk: function () {
			//VYA0004 Added 4/13/2021 BnB Defect
			var oTmSelectedItem = sap.ui.getCore().byId("tmSelect").getSelectedItem();
			var oTmKey = oTmSelectedItem.getKey();
			var aTmSelKey = oTmKey.split("|");
			var sTmSloc = aTmSelKey[0];
			var sTmValtype = aTmSelKey[1];
			var oWagSelectedItem = sap.ui.getCore().byId("wagSelect").getSelectedItem();
			var oWagKey = oWagSelectedItem.getKey();
			var aWagSelKey = oWagKey.split("|");
			var sWagSloc = aWagSelKey[0];
			var sWagValType = aWagSelKey[1];
			// var oPayload = {
			// 	"MvtType": "2",
			// 	"OrderNumber": this._oReturnTmWagDialog.getModel().getProperty("/workorder"),
			// 	"TmStorageLocation": this._oReturnTmWagDialog.getModel().getProperty("/tmStorageLocKey"),
			// 	"TmValuationType": this._oReturnTmWagDialog.getModel().getProperty("/wagValuationKey"),
			// 	"WagStorageLocation": this._oReturnTmWagDialog.getModel().getProperty("/wagStorageLocKey"),
			// 	"WagValuationType": this._oReturnTmWagDialog.getModel().getProperty("/tmValuationKey")
			// };
			var oPayload = {
				"MvtType": "2",
				"OrderNumber": this._oReturnTmWagDialog.getModel().getProperty("/workorder"),
				"TmStorageLocation": sTmSloc,
				"TmValuationType": sTmValtype,
				"WagStorageLocation": sWagSloc,
				"WagValuationType": sWagValType
			};
			//End VYA0004 2000012858 04/13/2021 BnB Defect
			//add validation check for BRK and QUA

			if (_this.oWorkOrder.Ilart === 'BRK') {
				if (oPayload.TmStorageLocation !== oPayload.WagStorageLocation) {
					sap.m.MessageToast.show("TM ang Wag StorageLoc should be same");
					return false;
				}
			}

			if (_this.oWorkOrder.Ilart === 'QUA' && _this.oWorkOrder.BnbTmDesc && _this.oWorkOrder.BnbWagDesc) {
				if (oPayload.TmStorageLocation !== oPayload.WagStorageLocation) {
					sap.m.MessageToast.show("TM ang Wag StorageLoc should be same");
					return false;
				}
			}

			LocomotiveDataModel.bnbGoodsMvt(oPayload);
			//VYA0004 2000012858 Begin 04/13/2021 BnB Defect
			var oTmReset = sap.ui.getCore().byId("tmSelect").getFirstItem();
			var sTmResetKey = oTmReset.getKey();
			sap.ui.getCore().byId("tmSelect").setSelectedKey(sTmResetKey);
			var oWagReset = sap.ui.getCore().byId("wagSelect").getFirstItem();
			var sWagResetKey = oWagReset.getKey();
			sap.ui.getCore().byId("wagSelect").setSelectedKey(sWagResetKey);
			//VYA0004 2000012858 End BnB Defect
			_this._oReturnTmWagDialog.close();
		},

		// END BAJ0018 - BNB
		// Start LMP2-25
		onCompleteWorkDialogOk: function (oEvent) {
			//Begin LLM3.3 call service to retrive 
			//Call the pop up
			//End LLM3.3
			LocomotiveDataModel.fetchWSheetData(_this._currentOrderNo, _this.fetchWSheetSuccess, _this.fetchWSheetFailure, _this);

			_this._oCompleteWorkDialog.close();
			_this._oCompleteWorkDialog.destroy();

		},
		_closeLocoDefect: function (sApprovalFlag) {
			var sAppFlag = sApprovalFlag;
			var aData = [];
			var sOpr, sSubOpr;

			if (sAppFlag !== undefined) {
				aData = _this._oGlobalModel.getData().WSheetdata;
				if (aData.length > 0) {
					sOpr = aData[0].OperationNbr;
					sSubOpr = aData[0].SubOperNbr;
				}
			} else { // Assign space to Undefined variables 
				sOpr = "";
				sSubOpr = "";
				sAppFlag = "";
			}

			if (_this._currentOrderNo) {
				LocomotiveDataModel.closeLocomotiveDefect(_this._currentOrderNo, sOpr, sSubOpr, sAppFlag, _this.closeLocomotiveDefectSuccess,
					_this.closeLocomotiveDefectFailure,
					_this);
			}

			if (_this.bIsRegulatory) {
				//verify FRA checkbox
				var isFRAChecked = sap.ui.getCore().byId('fraCheckbox').getSelected();
				if (isFRAChecked === true) {
					_this.showFRA();
				}
			}
			// _this._oCompleteWorkDialog.close();
			_this._oCompleteWorkDialog.destroy();
			_this._oCompleteWorkDialog = null;

		},
		fetchWSheetSuccess: function (oData) {

			if (oData.results.length < 1) { // it means Wheelsheet is NOT required 

				_this._closeLocoDefect();

			} else {

				if (oData.results[0].ReqNotinFlag === "X") { // It means WheelSheet is required but not entered

					MessageBox.show(
						"WorkOrder cannot be completed because Wheel Sheet has not been entered, please verify and enter wheel sheet reading", {
							icon: MessageBox.Icon.ERROR,
							title: "Error",
							styleClass: "successMessage",
							actions: [MessageBox.Action.OK]
						});
					return false;

				}

				if (!_this._oWheelSheetApproval) {

					_this._oWheelSheetApproval = sap.ui.xmlfragment(
						"com.sap.cp.lm.view.myShop.common.workplan.WheelSheetApproval", this);
					_this.getView().addDependent(_this._oWheelSheetApproval);
				}

				_this._oGlobalModel.setProperty("/WSheetdata", oData.results);

				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setProperty("/WSheetdata", oData.results);
				_this._oWheelSheetApproval.setModel(oModel);

				_this._oWheelSheetApproval.open();
			}

		},
		fetchWSheetFailure: function () {

		},
		onWheelSheetApprovePress: function (oEvent) {
			var sApprovalFlag;

			sApprovalFlag = "Y";
			_this._closeLocoDefect(sApprovalFlag);
			_this.onWheelSheetCancelPress(oEvent);

		},
		onWheelSheetRejectPress: function (oEvent) {
			var sApprovalFlag;

			sApprovalFlag = "N";
			_this._closeLocoDefect(sApprovalFlag);
			_this.onWheelSheetCancelPress(oEvent);

		},
		onWheelSheetCancelPress: function (oEvent) {

			_this._oWheelSheetApproval.close();
			_this._oWheelSheetApproval.destroy();
			_this._oWheelSheetApproval = null;
		},

		// End LMP2-25
		/**
		 * Open WMAT DIALOG fragment when "SET WMAT" is selected in action sheet in drop down list in workorder panel
		 * @params(oEvent) oEvent is event for click on WMAT Work Order
		 */
		onClickWMAT: function (oEvent) {
			LocomotiveManager.onClickWMAT(oEvent, this);
		},

		/*Added by Sandhya : LMP2-02 : Adding the unTeco Option */

		onUnTeco: function () {
			var oWorkOrder = this._selectedContext.getObject();
			var sOrderNo = oWorkOrder.OrderNo;
			var oPayload = {
				"OrderNumber": sOrderNo
			};
			LocomotiveDataModel.unTecoWO(oPayload);
		},
		/*End:Added by Sandhya : LMP2-02 : Adding the unTeco Option */

		/*
		 * Set the Wmat Status on Selection
		 *
		 *
		 */
		onClickCancel: function (oEvent) {
			LocomotiveManager.oWMATWork.close();
		},

		onClickOk: function (oEvent) {
			var oWorkOrder = this.getView().getModel("global").getObject(this._selectedContext.sPath); // SHE0272 - INC0110700 - Getting the data from global model instead of local
			// successCallBack, oContext, oWorkOrderNumber, oWOStatus, oWOUndo
			LocomotiveManager.updateWmat(this.onSucessWmatUpdate, this, oWorkOrder.OrderNo, "WMAT", oWorkOrder.Wmat);
		},

		onPressCloseOutCode: function (oEvent) {

			var aData = {};
			aData.sDefectNo = this.getView().getModel("global").getObject(this._selectedContext.sPath).DefectNo; // SHE0272 - INC0110700 - Getting the data from global model instead of local
			aData.oController = this;
			aData.oGlobalModel = this._oGlobalModel;
			aData.oSelectedContext = this._selectedContext;
			aData.oSourceViewModel = this.getView().getModel();
			aData.bfromDefectView = false;
			aData.bfromWorkPlanView = true;
			this._oCloseOutCodeDialog = new CloseOutCode(aData);
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oCloseOutCodeDialog);
			this._oCloseOutCodeDialog.getFragment().setContentWidth("60%");
			this._oCloseOutCodeDialog.getFragment().open();
		},
		//This will save the changed defect back to this View's Data model
		SaveDefectBacktoModel: function (sPath, oDefect) {
			this.getView().getModel().setProperty(sPath, oDefect);
			this.getView().getModel("global").setProperty(sPath, oDefect); // SHE0272 - INC0114906 - Setting the data to global model instead of local
		},
		onClickIncidentNumber: function (oEvent) {
			if (!_this.oIncidentNumberManager) {
				_this.oIncidentNumberManager = IncidentNumberManager.init(_this);
			}

			var oCurrentWorkOrder = this.getView().getModel("global").getObject(oEvent.getSource().getBindingContext().sPath); // SHE0272 - INC0110700 - Getting the data from global model instead of local

			_this.oIncidentNumberManager.onIncidentNumberDialogOpen(oCurrentWorkOrder);
		},

		//******************************Event Handlers at Operation Level******************************
		onSelallOperation: function (oEvent) {

			var aSelItems = oEvent.getSource().getParent().getParent().getParent().getItems()[1].getItems();
			aSelItems.forEach(function (oItem) {
				if (oItem.getBindingContext("global").getObject().Status !== Constants.STATUS_COMPLETED) { // SHE0272 - INC0114906 - Setting the data to global model instead of local
					oItem.getContent()[0].getHeaderToolbar().getContent()[0].getItems()[0].getItems()[0].setSelected(oEvent.getParameter("selected"));
				}
			});
			// _this.getView().byId("idAssignSelMe").setEnabled(oEvent.getParameter("selected"));
		},

		/**
		 * Triggers on Expand/Collapse the Operation, Set the panel model with expanded Work order
		 * @params(oEvent) oEvent parameter on Click
		 */
		onExpandOperationPanel: function (oEvent) {
			var oPanel = oEvent.getSource();
			var bIsExpended = oPanel.getExpanded();
			// lazy load the panel content on expand
			if (oPanel.getContent().length === 0 && bIsExpended) {
				oPanel.getHeaderToolbar().setBusyIndicatorDelay(0);
				oPanel.getHeaderToolbar().setBusy(true);
				this._oTaskContent = !this._oTaskContent ? sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.common.workplan.CustomTaskList", this) : this._oTaskContent;
				oPanel.addContent(this._oTaskContent.clone());
				// hide the busy indicator on the panel depending on the number of tasks in the operation
				var iItemsLength = 0;
				if (oPanel.getContent()[0].getAggregation("items")) {
					iItemsLength = oPanel.getContent()[0].getAggregation("items").length;
				}
				var iDelay = iItemsLength * 5;
				setTimeout(function () {
					if (oPanel.getHeaderToolbar()) {
						oPanel.getHeaderToolbar().setBusy(false);
					}
				}, iDelay);
			}

			var sOrderNumber = oEvent.getSource().getBindingContext("global").getObject().OrderNo; // SHE0272 - INC0110700 - Getting the data from global model instead of local
			var sOpNumber = oEvent.getSource().getBindingContext("global").getObject().Activity; // SHE0272 - INC0110700 - Getting the data from global model instead of local
			var bExpand = oEvent.getParameters().expand;
			if (this.oExpandedWO[sOrderNumber]) this.oExpandedWO[sOrderNumber][sOpNumber] = bExpand;

			this.getView().getModel("PanelExpandModel").setProperty("/" + sOrderNumber + "|" + sOpNumber, bExpand);
			this._oPanelExpandModel.setProperty("/" + sOrderNumber + "/" + sOpNumber, bExpand);

			//Make Task Button toolbar Visible/invisible based on Selection
			//Make  Table Selection Mode None/Selection
			var oTaskTable = oPanel.getContent()[0].getItems()[0];
			this.enableDisableRowsinTask(oTaskTable);

		},

		onClickOpCheckBox: function (oEvent) {
			// _this.getView().byId("idAssignSelMe").setEnabled(oEvent.getParameter("selected"));
			// this.getView().getModel("PanelExpandModel").refresh(true);
			//oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getParent().getParent().setExpanded(true);
		},

		/***
		 * Open long text dialog on button click
		 */
		onClickLongTextOpen: function (oEvent) {
			var sBindingPath = oEvent.getSource().getBindingContext("global").sPath; // SHE0272 - INC0110700 - Getting the data from global model instead of local

			if (sBindingPath) {
				var oDataObject = this.getView().getModel("global").getObject(sBindingPath); // SHE0272 - INC0110700 - Getting the data from global model instead of local

				Helper.openLongTextDialog(oDataObject);
			}
		},

		/** START KIR0084 LMP2-36 Allow adding of sub-operation long text. */
		onClickCommentOpen: function (oEvent) {
			var oParams = {};
			oParams.oWorkOrderHeader = oEvent.getSource().getBindingContext("global").getObject(); // SHE0272 - INC0110700 - Getting the data from global model instead of local
			oParams.fnFirstCommentAdded = _this.fetchAndRefreshView.bind(_this);

			var oWorkOrderComments = new WorkOrderComments(oParams);
			if (!_this._oI18nModel && _this.getOwnerComponent()) {
				_this._oI18nModel = _this.getOwnerComponent().getModel("i18n");
			}
			oWorkOrderComments.getFragment().setModel(_this._oI18nModel, "i18n");
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oWorkOrderComments);
			oWorkOrderComments.getFragment().open();
		},
		/** END KIR0084 LMP2-36 Allow adding of sub-operation long text. */

		// Added for LMP2-7a	
		onClickAttachmentOpen: function (oEvent) {
			var sBindPath = oEvent.getSource().getBindingContext("global").sPath; // SHE0272 - INC0114906 - Setting the data to global model instead of local
			if (!this._oAttachmentClickPopOver) {

				this._oAttachmentClickPopOver = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.common.workplan.AttachmentClickPopOver", this);
				this.getView().addDependent(this.oAttachmentClickPopOver);
			}
			var oData = this.getView().getModel("global").getObject(sBindPath).AttachSet; // SHE0272 - INC0114906 - Setting the data to global model instead of local
			var oTempModel = new sap.ui.model.json.JSONModel(oData);
			this._oAttachmentClickPopOver.setModel(oTempModel);
			this._oAttachmentClickPopOver.openBy(oEvent.getSource());
		},

		/** START LMP2-35 KIR0084 Display work order worker list */
		/**
		 *
		 * Display the dialog with list of crafts assigned
		 * @params(event) oEvt is the listener for the event
		 * causing the opening of worker list in work plan screen
		 *
		 */
		onClickWorkOrderWorkerList: function (oEvt) {
			var oCurrentPanelId = $("#" + oEvt.getSource().sId).closest(".lmWorkPlanListItem").attr('id');
			var oCurrentPanel = sap.ui.getCore().byId(oCurrentPanelId);
			var oWorkOrder = oCurrentPanel.getBindingContext("global").getObject(); // SHE0272 - INC0110700 - Getting the data from global model instead of local
			var oModel = this.getView().getModel("global"); // SHE0272 - INC0110700 - Getting the data from global model instead of local
			var sLocoDescription = "";
			if (oModel.getData().detailsData && oModel.getData().detailsData.Description) {
				sLocoDescription = oModel.getData().detailsData.Description;
			}

			var sBindingPath = oEvt.getSource().getBindingContext("global").sPath; // SHE0272 - INC0110700 - Getting the data from global model instead of local

			var oOperationWONumer = {
				"WorkOrderNum": oEvt.getSource().getCustomData()[0].getProperty("value"),
				"OperationNumber": oEvt.getSource().getCustomData()[1].getProperty("value"),
				"LocoDescription": sLocoDescription,
				"OperationStatus": oEvt.getSource().getCustomData()[2].getProperty("value"),
				"BindingContext": sBindingPath,
				"ViewType": "WorkPlan",
				"PlanStartTs": oEvt.getSource().getCustomData()[6].getProperty("value"),
				"PlanStartTz": oEvt.getSource().getCustomData()[7].getProperty("value"),
				"WOStatus": oWorkOrder.Status
			};

			LocomotiveManager.onClickWorkOrderWorkerList(oEvt, this.getView(), oModel, oOperationWONumer, sBindingPath);
		},
		/** END KIR0084 Display work order worker list */

		/**
		 *
		 * Display the dialog with list of crafts assigned
		 * @params(event) oEvt is the listener for the event
		 * causing the opening of worker list in work plan screen
		 *
		 */
		onClickWorkerList: function (oEvt) {
			var oCurrentPanelId = $("#" + oEvt.getSource().sId).closest(".lmWorkPlanListItem").attr('id');
			var oCurrentPanel = sap.ui.getCore().byId(oCurrentPanelId);
			var oWorkOrder = oCurrentPanel.getBindingContext("global").getObject(); // SHE0272 - INC0110700 - Getting the data from global model instead of local
			var oModel = this.getView().getModel("global"); // SHE0272 - INC0110700 - Getting the data from global model instead of local
			var sLocoDescription = "";
			if (oModel.getData().detailsData && oModel.getData().detailsData.Description) {
				sLocoDescription = oModel.getData().detailsData.Description;
			}

			var sBindingPath = oEvt.getSource().getBindingContext("global").sPath; // SHE0272 - INC0110700 - Getting the data from global model instead of local

			var oOperationWONumer = {
				"WorkOrderNum": oEvt.getSource().getCustomData()[0].getProperty("value"),
				"OperationNumber": oEvt.getSource().getCustomData()[1].getProperty("value"),
				"LocoDescription": sLocoDescription,
				"OperationStatus": oEvt.getSource().getCustomData()[2].getProperty("value"),
				"BindingContext": sBindingPath,
				"ViewType": "WorkPlan",
				"PlanStartTs": oEvt.getSource().getCustomData()[6].getProperty("value"),
				"PlanStartTz": oEvt.getSource().getCustomData()[7].getProperty("value"),
				"WOStatus": oWorkOrder.Status
			};

			LocomotiveManager.onClickWorkerList(oEvt, this.getView(), oModel, oOperationWONumer, sBindingPath);
		},

		/**
		 *
		 * Opens up the material list in work plan
		 * @params (event) oEvt is the event for the button click for popover
		 *
		 */
		onClickMaterialListPopover: function (oEvt) {
			var sBindingPath = oEvt.getSource().getBindingContext("global").sPath; // SHE0272 - INC0110700 - Getting the data from global model instead of local
			this._selectedContext = oEvt.getSource().getBindingContext("global"); // SHE0272 - INC0110700 - Getting the data from global model instead of local
			var oModel = this.getView().getModel("global"); // SHE0272 - INC0110700 - Getting the data from global model instead of local
			// var sLocoNumber = this._oViewPropertiesModel.getProperty("/LocomotiveNumber");
			// LocomotiveManager.onClickMaterialListPopover(oEvt, this.getView(), sBindingPath, oModel, sLocoNumber);

			if (!this._oMatPopOver) {
				this._oMatPopOver = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.common.workplan.MaterialListPopover", this);
				this.getView().addDependent(this._oMatPopOver);
			}
			this._oMatPopOver.setModel(oModel);
			this._oMatPopOver.bindElement(sBindingPath);
			this._oMatPopOver.openBy(oEvt.getSource());
		},

		onMATRequest: function (oEvent) {
			var oParams = {};
			var oMessage = {};

			var oSelectedOperation = this._selectedContext.getObject();
			var oSelMat = oEvent.getSource().getBindingContext().getObject();
			var oWorkOrder = this.getView().getModel("global").getObject(this._selectedContext.sPath.split("/OperationSet")[0]); // SHE0272 - INC0110700 - Getting the data from global model instead of local

			oMessage.LocoID = this._oGlobalModel.getProperty("/currentLocomotive").LocomotiveId;
			oMessage.OperationNo = oSelectedOperation.Activity;
			oMessage.OperationDescr = oSelectedOperation.Descr;
			oMessage.MaterialDesc = oSelMat.Descr;
			oMessage.MaterialCode = oSelMat.MaterialNo;
			oMessage.Sender = this._oGlobalModel.getProperty("/currentUser").UserId;
			oMessage.ShopNo = this._oGlobalModel.getProperty("/currentShop").Id;
			oMessage.ShopName = this._oGlobalModel.getProperty("/currentShop").Name;
			oMessage.sOrderNo = oWorkOrder.OrderNo;
			oMessage.sOrderDesc = oWorkOrder.Descr;
			oParams.oMessage = oMessage;

			var oRequestMatDialog = new RequestMatDialog(oParams);
			if (!_this._oI18nModel && _this.getOwnerComponent()) {
				_this._oI18nModel = _this.getOwnerComponent().getModel("i18n");
			}
			/* Start change By KIR0084 - _i18nModel undefined so replace with _oI18nModel */
			//oRequestMatDialog.getFragment().setModel(_this._i18nModel, "i18n");
			oRequestMatDialog.getFragment().setModel(_this._oI18nModel, "i18n");
			/* End change By KIR0084 - _i18nModel undefined so replace with _oI18nModel */
			oRequestMatDialog.getFragment().setModel(_this._oGlobalModel, "global");

			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oRequestMatDialog);
			oRequestMatDialog.getFragment().open();
		},
		//****************Servicing group Event Handlers at Operation Level
		//For craft View Begin & End Work
		onBeginWorkforOperation: function (oEvent) {
			var oSelContext = oEvent.getSource().getBindingContext("global"); // SHE0272 - INC0114906 - Setting the data to global model instead of local

			CraftManager.onBeginWorkforOperation(oSelContext, this);

		},
		onEndWorkforOperation: function (oEvent) {
			var oSelContext = oEvent.getSource().getBindingContext("global"); // SHE0272 - INC0114906 - Setting the data to global model instead of local

			CraftManager.onEndWorkforOperation(oSelContext, this);
		},
		//****************End of Servicing group Event Handlers at Operation Level

		onClickAddOperation: function (oEvent) {

			LocomotiveManager.onClickAddOperation(oEvent, this.getView());
		},

		//******************************Event Handlers at Task level***********************************

		onClickCreateWS: function (oEvent) {

			var aSelObject = this.getView().getModel("global").getObject(oEvent.getSource().getBindingContext("global").sPath); // SHE0272 - INC0110700 - Getting the data from global model instead of local
			var sOperationPath = oEvent.getSource().getBindingContext("global").sPath.split("TaskSet")[0]; // SHE0272 - INC0110700 - Getting the data from global model instead of local
			var sOrderPath = sOperationPath.split("/OperationSet")[0];
			var oSelOperation = this.getView().getModel("global").getObject(sOperationPath); // SHE0272 - INC0110700 - Getting the data from global model instead of local
			var oSelOrder = this.getView().getModel("global").getObject(sOrderPath); // SHE0272 - INC0110700 - Getting the data from global model instead of local
			var oWSHeader = {};

			oWSHeader = {
				"OperationNbr": oSelOperation.Activity,
				"OrderNbr": oSelOperation.OrderNo,
				"SubOperNbr": aSelObject.SubOp,
				"EquipNbr": oSelOrder.EquipNo,
				"MsetType": aSelObject.MeasurementSetType,
				"MeasPntValue": aSelObject.MeasPntValue,
				"MeasurementPointName": aSelObject.MeasurementPointName,
				"InstallPosition": aSelObject.InstallPosition,
				"SerialNbr": aSelObject.SerialNbr.trim(), // SHE0272 - LLM3.2 - Trimmed Space from Serial Number
				//START - BAJ0018 - EAM-ASR3415776 	
				"ObjectType": aSelObject.ObjectType,
				"Room": aSelObject.Room,
				//END - BAJ0018 - EAM-ASR3415776,
				// Start - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
				"SoftwareCharacteristic": aSelObject.SoftwareCharacteristic,
				"SoftwareClass": aSelObject.SoftwareClass,
				"MeasurementType": aSelObject.MeasurementType,
				// End - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
				// Start - SHE0272 - LLM1.2 - Serialization
				// "GoodsIssueAndReturn": aSelObject.GoodsmvtIndi,
				// "Plant": this._oGlobalModel.getProperty("/currentShop/Id"),
				// "SerializedMaterial": aSelObject.SerializedMatnr,
				// "UserRole": this._oGlobalModel.getProperty("/role"),
				// End - SHE0272 - SHE0272 - LLM1.2 - Serialization
				// Start - EPA Information_Serial Number mask inputs
				"Measurement": aSelObject.Measurement
					// End - EPA Information_Serial Number mask inputs
			};
			switch (aSelObject.MeasurementType) {
			case Constants.MEASTYPE.WHEEL_SHEET:
				_this.onOpenWheelSheet(oWSHeader);
				break;
			case Constants.MEASTYPE.MS_MEGAWATT_HOUR_A:
				_this.openMeasPoint(oWSHeader);
				break;
			case Constants.MEASTYPE.SERIALNUMBER:
				_this.openSerialNo(oWSHeader);
				break;
				// Start - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
			case Constants.MEASTYPE.SW_VERSION_NUMBER:
				_this.openSerialNo(oWSHeader);
				break;
				// End - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
				// Start - SHE0272 - LLM1.2 - Serialization
				// case Constants.MEASTYPE.SERIALIZATION_NUMBERR:
				// 	_this.openSerialNo(oWSHeader);
				// 	break;
				// End - SHE0272 - LLM1.2 - Serialization
				// Start: ANI0006 2000014601 - EPA Information_Serial Number mask inputs - Case 6
			case Constants.MEASTYPE.EPA_INFORMATION:
				_this.openSerialNo(oWSHeader);
				break;
				// End: ANI0006 2000014601 - EPA Information_Serial Number mask inputs - Case 6
			}
		},

		onSelTaskForCompletion: function (oEvent) {

			oEvent.getSource().getItems().forEach(function (oItem) {
				if (oItem.getBindingContext("global").getObject().Status === "0") { // SHE0272 - INC0114906 - Setting the data to global model instead of local
					oItem.setSelected(true);
				}
			});
			var bItemSelected = false;
			oEvent.getSource().getSelectedItems().forEach(function (oItem) {
				if (oItem.getBindingContext("global").getObject().Status !== "0") { // SHE0272 - INC0114906 - Setting the data to global model instead of local
					bItemSelected = true;
				}
			});
			oEvent.getSource().getParent().getItems()[1].getContent()[1].setEnabled(bItemSelected);
			oEvent.getSource().getParent().getItems()[1].getContent()[2].setEnabled(bItemSelected);

		},
		onCompleteSelected: function (oEvent) {
			var oPayload = {};
			var aConfirmationSet = [];
			var oTable = oEvent.getSource().getParent().getParent().getItems()[0];
			var oParentOperation = oEvent.getSource().getBindingContext("global").getObject(); // SHE0272 - INC0114906 - Setting the data to global model instead of local
			oTable.getSelectedItems().forEach(function (oItem) {
				var oTaskPayload = {};
				var oSelObject = oItem.getBindingContext("global").getObject(); // SHE0272 - INC0114906 - Setting the data to global model instead of local

				if (oSelObject.Status !== 0) {
					oTaskPayload.OrderNumber = oParentOperation.OrderNo;
					oTaskPayload.OperationNumber = oParentOperation.Activity;
					oTaskPayload.SuboperationNumber = oSelObject.SubOp;
					aConfirmationSet.push(oTaskPayload);
				}
			});

			if (aConfirmationSet.length > 0) {
				oPayload.ConfirmationSet = aConfirmationSet;

				WorkDataModel.completeTasks(_this.onSucessWmatUpdate, _this.onCompleteTaskError, _this, oPayload);
			}
		},

		//Start ASR3414325 : Complete the SubOps in the servicing group-->
		onCompleteSelectedServGr: function (oEvent) {
			var oPayload = {};
			var aConfirmationSet = [];
			var oTable = oEvent.getSource().getParent().getParent().getItems()[0];
			var oParentOperation = oEvent.getSource().getBindingContext("global").getObject(); // SHE0272 - INC0114906 - Setting the data to global model instead of local
			oTable.getSelectedItems().forEach(function (oItem) {
				var oTaskPayload = {};
				var oSelObject = oItem.getBindingContext("global").getObject(); // SHE0272 - INC0114906 - Setting the data to global model instead of local

				if (oSelObject.Status !== 0) {
					oTaskPayload.OrderNumber = oParentOperation.OrderNo;
					oTaskPayload.OperationNumber = oParentOperation.Activity;
					oTaskPayload.SuboperationNumber = oSelObject.SubOp;
					oTaskPayload.applytoservgr = 'Z';
					aConfirmationSet.push(oTaskPayload);
				}
			});

			if (aConfirmationSet.length > 0) {
				oPayload.ConfirmationSet = aConfirmationSet;
				WorkDataModel.completeTasks(_this.onSucessWmatUpdate, _this.onCompleteTaskError, _this, oPayload);
			}
		},
		//End ASR3414325 : Complete the SubOps in the servicing group-->		
		//******************************Serivicing Group Specific Event Handlers at Footer Level***********************

		onEditServiceGroup: function (oEvent) {
			var aData = {};
			aData.oSourceViewController = this;
			var oServiceGroupDialog = new serviceGroupDialog(aData);
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oServiceGroupDialog);
			oServiceGroupDialog.getFragment().setContentWidth("40%");
			oServiceGroupDialog.getFragment().open();
		},

		onDeleteServiceGroup: function (oEvent) {
			var oCurrentServiceLoco = this._oGlobalModel.getProperty("/currentServiceLocomotive");
			if (!_this.oDelteteServiceGprDialog) {
				_this.oDelteteServiceGprDialog = sap.ui.xmlfragment("idDialog",
					"com.sap.cp.lm.view.common.DialogtoConfirm", _this);
			}

			_this.oDelteteServiceGprDialog.setTitle(oCurrentServiceLoco.sSrvcGrpDescr);
			var sText = _this._oI18nModel.getProperty("DELTE_CONFIRMATION") + "Service Group " + oCurrentServiceLoco.sSrvcGrpDescr;
			var oDialogContent = sap.ui.core.Fragment.byId("idDialog", "idDCContent");
			oDialogContent.setText(sText);
			_this.getView().addDependent(_this.oDelteteServiceGprDialog);
			_this.oDelteteServiceGprDialog.open();

		},

		onClickServiceCancel: function () {
			_this.oDelteteServiceGprDialog.close();

		},
		onClickDeleteServiceConfirm: function () {
			var sPayload = "/ServiceGroupSet(SrvcGrpId='" + this._oGlobalModel.getProperty("/currentServiceLocomotive").SrvcGrpId + "')";
			LocomotiveDataModel.DeleteServicingGroup(sPayload, this._onSuccessDeleteServiceGroup, this._onErrorDeleteServiceGroup, this);
		},

		/***
		 * Open add work order dialog
		 */
		onAddWorkOrder: function (oEvent) {
			if (!_this.oAddDefectManager) {
				_this.oAddDefectManager = AddDefectManager.init(_this, _this.fetchAndRefreshView);
			}
			_this._bisReloadMasterRequired = true;
			_this.oAddDefectManager.onAddAffectDialogOpen("WORK_ORDER");
			_this.bAddWorkOrder = true;
		},

		/***
		 * Get the selected Operations
		 */
		onAssignSelected: function (oEvent) {
			var aSelOperations = [];
			this.getView().getModel("global").getData().detailsData.results.forEach(function (aWorkOrder) { // SHE0272 - INC0110700 - Getting the data from global model instead of local
				if (aWorkOrder.OperationSet) {
					aWorkOrder.OperationSet.results.forEach(function (aOperation) {
						if (aOperation.checked) {
							aSelOperations.push(aOperation);
						}
					});
				}
			});
			if (aSelOperations.length > 0) {
				var oPayload = this.preparePayloadForAssignment(aSelOperations);

				LocomotiveDataModel.updateCraftAssignmentsSet(oPayload, _this.onBatchAssignmentsUpdateSuccess, _this.onBatchAssignmentsUpdateError,
					_this);
			} else {
				oRequestMatDialog.getFragment().setModel(_this._oI18nModel, "i18n");
				/* Start change By KIR0084 - _i18nModel undefined so replace with _oI18nModel */
				//MessageBox.show(_this._i18nModel.getProperty("SELECT_OPERATIONS"), {
				MessageBox.show(_this._oI18nModel.getProperty("SELECT_OPERATIONS"), {
					icon: MessageBox.Icon.ERROR,
					title: "Error",
					styleClass: "successMessage",
					actions: [MessageBox.Action.OK]
				});
				/* End change By KIR0084 - _i18nModel undefined so replace with _oI18nModel */
			}
		},

		/**
		 * Show a success message dialog
		 */
		onBatchAssignmentsUpdateSuccess: function () {
			// _this.getView().byId("idAssignSelMe").setEnabled(false);
			/* Start change By KIR0084 - _i18nModel undefined so replace with _oI18nModel */
			//MessageBox.show(_this._i18nModel.getProperty("ASSIGNMENT_ME_SUCCESS_MESSAGE"), {
			MessageBox.show(_this._oI18nModel.getProperty("ASSIGNMENT_ME_SUCCESS_MESSAGE"), {
				icon: MessageBox.Icon.SUCCESS,
				title: "Success",
				styleClass: "successMessage",
				actions: [MessageBox.Action.OK]
			});

			_this._oGlobalModel.setProperty("/needDrawMap", true);
			_this._oGlobalModel.setProperty("/needRefreshMapData", true);
			/* End change By KIR0084 - _i18nModel undefined so replace with _oI18nModel */
			_this.fetchAndRefreshView();
		},

		onBatchAssignmentsUpdateError: function () {
			// _this.fetchAndRefreshView();
		},

		preparePayloadForAssignment: function (aOperations) {
			var aPayload = {};
			aPayload.OperationSet = [];
			aPayload.AssignmentSet = [];
			var aSelOp = {};
			aOperations.forEach(function (oItem) {
				aSelOp = {};
				aSelOp.Activity = oItem.Activity;
				aSelOp.RoutingNo = oItem.RoutingNo;
				aSelOp.OpNode = oItem.OpNode;
				aSelOp.PlanWorkDur = oItem.PlanWorkDur;
				aSelOp.PlanWorkUom = oItem.PlanWorkUom;
				aPayload.OperationSet.push(aSelOp);
			});

			var aPersonal = {};
			aPersonal.PersonNo = this._oGlobalModel.getProperty("/currentUser").PersonnelNumber;
			aPayload.ShopId = this._oGlobalModel.getProperty("/currentShop").Id;
			aPayload.AssignmentSet.push(aPersonal);
			return aPayload;

		},

		/*
		 * release process
		 */

		onPreReleaseLocomotivePress: function (oEvent) {
			BusyIndicator.showBusyIndicator();

			//prepare dialog
			if (_this._oReleaseDialog) {
				_this._oReleaseDialog.destroy();
			}

			var directions = _this._oGlobalModel.getProperty("/Directions");

			_this._oReleaseDialog = sap.ui.xmlfragment(
				"com.sap.cp.lm.view.myShop.common.workplan.ReleaseDialog",
				_this
			);

			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setProperty("/Directions", directions);
			_this._oReleaseDialog.setModel(oModel);
			if (!_this._oI18nModel && _this.getOwnerComponent()) {
				_this._oI18nModel = _this.getOwnerComponent().getModel("i18n");
			}

			/* Start change By KIR0084 - _i18nModel undefined so replace with _oI18nModel */
			//_this._oReleaseDialog.setModel(_this._i18nModel, "i18n");
			_this._oReleaseDialog.setModel(_this._oI18nModel, "i18n");
			/* End change By KIR0084 - _i18nModel undefined so replace with _oI18nModel */

			//fetch work orders
			var oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
			var oShop = _this._oGlobalModel.getProperty("/currentShop");

			var sEquipNo = oLocomotive.Equipment;
			if (!sEquipNo) {
				sEquipNo = oLocomotive.EquipNo;
			}
			var oPayload = {
				"ShopId": oShop.Id,
				"EquipNo": parseInt(sEquipNo, 10),
				"OrderCategory": "A"
			};

			LocomotiveDataModel.fetchPreReleaseWO(oPayload, _this.fetchPreReleaseWOSuccess, _this.fetchPreReleaseWOFailed, _this);

		},

		onCancelReleasePress: function (oEvent) {
			_this._oReleaseDialog.close();
			_this._oReleaseDialog.destroy();
		},

		onReleaseLocomotivePress: function (oEvent) {
			var releaseTrackSpotDidPass = this.onValidateReleaseTrackSpot();
			if (releaseTrackSpotDidPass) {
				_this.doReleaseLocomotive();
			}
		},

		onClickEstTimeEdit: function (oEvent) {
			var oSelectedContext = oEvent.getSource().getBindingContext("global").getObject(); // SHE0272 - INC0110700 - Getting the data from global model instead of local

			LocomotiveManager.onClickEstTimeEdit(oEvent, oSelectedContext, this.getView());
		},
		//***************End  of Event Handlers************************************
		//----------------------------------------------------------------------
		// Private functions
		//----------------------------------------------------------------------

		//Initialize the global locomotive incase of Service Group( this is required because Master list binded to different entity)

		//Common Private functions
		resizeDialog: function () {
			var frameHeight = $(window).height();
			var frameWidth = $(window).width();

			var oItem = sap.ui.getCore().byId(_this.wheelSheetDialogId);

			oItem.setContentHeight(frameHeight * 0.75 + "px");
			oItem.setContentWidth(frameWidth * 0.75 + "px");
		},

		//Enable Rows for Selection in the Task Table
		enableDisableRowsinTask: function (oTable) {

			oTable.addDelegate({
				onAfterRendering: function () {
					// var header = this.$().find('thead');
					// var selectAllCb = header.find('.sapMCb');
					// selectAllCb.remove();

					this.getItems().forEach(function (r) {
						var obj = r.getBindingContext("global").getObject(); // SHE0272 - INC0110700 - Getting the data from global model instead of local
						var status = obj.Status;
						var cb = r.$().find('.sapMCb');
						if (cb) {
							var oCb = sap.ui.getCore().byId(cb.attr('id'));
							if (oCb) {
								if (status === "0") {
									oCb.setEnabled(false);
									r.setSelected(true);
								} else {
									oCb.setEnabled(true);
								}
							}
						}
					});

				}
			}, oTable);
		},

		showFRA: function () {
			var oCurrentLocomotive = this._oGlobalModel.getProperty("/currentLocomotive");

			if (oCurrentLocomotive) {
				var sEquipNo = oCurrentLocomotive.Equipment;
				if (!sEquipNo) {
					sEquipNo = oCurrentLocomotive.EquipNo;
				}
				var sEquipment = sEquipNo;
				var oDate = new Date();
				var sYear = oDate.getFullYear();
				var sLink = "/sap/opu/odata/sap/ZPM_FRACARD_SRV/pdfSet(equipment='" + sEquipment + "',year='" + sYear + "')/$value";

				window.open(sLink, '_blank');
			}
		},
		fetchAndRefreshView: function (didRemoveFromMap) {
			// console.log("fetchAndRefreshView");
			if (this._oGlobalModel.getProperty("/sSelectedView") === Constants.LOCOMOTIVES && _this._oGlobalModel.getProperty(
					"/selectedMyShopTab") === Constants.TEXT_SERVICING) {
				_this._IsServicing = true;
			} else {
				_this._IsServicing = false;
			}
			var oCurrentLoco = this._oGlobalModel.getProperty("/currentLocomotive");
			if (_this._IsServicing) {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(_this);
				if (didRemoveFromMap === true) {
					oRouter.getTargets().display("locomotivesServicingBlankDetails");
				} else {
					if (_this._oGlobalModel.getProperty("/currentServiceLocomotive").isServiceGroupSelected) {
						oCurrentLoco = _this._oGlobalModel.getProperty("/currentServiceLocomotive");
					}
					BusyIndicator.showBusyIndicator();
					LocomotiveDataModel.fetchServiceWorkOrders(_this.refreshServiceData, _this.onloadDataError, this, oCurrentLoco);
				}
			} else {
				// BusyIndicator.showBusyIndicator();
				if (this._oGlobalModel.getProperty("/sSelectedView") === Constants.LOCOMOTIVES && _this._oGlobalModel.getProperty(
						"/selectedMyShopTab") === Constants.TEXT_SHOPPED) {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(_this);
					if (didRemoveFromMap === true) {
						oRouter.getTargets().display("locomotivesShoppedBlankDetails");
					} else {
						oRouter.getTargets().display("locomotivesShoppedHome");
					}
				} else if (this._oGlobalModel.getProperty("/sSelectedView") === Constants.FLEET) {
					var oFleetList = this._oGlobalModel.getProperty("/fleetListController");
					if (oFleetList) {
						oFleetList.navtoDetails();
					}
				} else {
					var sEquipNo = oCurrentLoco.Equipment;
					if (!sEquipNo) {
						sEquipNo = oCurrentLoco.EquipNo;
					}
					LocomotiveDataModel.fetchLocomotiveDetails(_this.refreshData, "", _this, oCurrentLoco.LocoId,
						sEquipNo);
				}
			}

			//Start : Added by KIR0084 : Add Number of Crafts : LMP2-34
			// Refresh the map when it is in the current shift
			if (_this._oViewPropertiesModel.getProperty("/IsCurrentShift")) {
				_this._oGlobalModel.setProperty("/needDrawMap", true);
			}
			//End : Added by KIR0084 : Add Number of Crafts : LMP2-34
			if (didRemoveFromMap === true || (_this._oGlobalModel.getProperty("/sSelectedView") === Constants.LOCOMOTIVES && _this.bAddWorkOrder)) {
				//Start : Added by KIR0084 : Add Number of Crafts : LMP2-34
				// Because num crafts on map must be refreshed always, move this outside of if check
				//_this._oGlobalModel.setProperty("/needDrawMap",true);
				//End : Added by KIR0084 : Add Number of Crafts : LMP2-34

				var oMasterController = _this._oGlobalModel.getProperty("/locomotiveMasterController");
				oMasterController.onRefreshMasterList();
				_this.bAddWorkOrder = false;
			}

			this.getView().getModel().refresh();
		},

		refreshViewfromServiceGroup: function () {
			BusyIndicator.showBusyIndicator();
			var oLocomotive = _this._oGlobalModel.getProperty("/currentServiceLocomotive");
			LocomotiveDataModel.fetchServiceWorkOrders(_this.refreshServiceData, _this.onloadDataError, this, oLocomotive);
		},

		refreshServiceData: function (oModel, oContext, oServicingLoco) {
			//ask workplan tab to reload
			// var oParameters = {
			// 	iconTabBar: _this._oIconTabBar,
			// 	bindPath: "/detailsData/results",
			// 	model: oModel,
			// 	parentView: Constants.SERVICING,
			// 	serviceLocoObject: oServicingLoco
			// };
			// this.loadData(oParameters);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(_this);

			oRouter.getTargets().display("locomotivesServicingHome");

			BusyIndicator.hideBusyIndicator();
		},

		/**
		 * Success callback for fetchLocomotiveDetails ,Sets model in View
		 * Loads data for the selected locomotive
		 * @params{object} oModel returned for the new selected Locomotive
		 */
		refreshData: function (oModel, oContext, sLocomotiveID, sEquipNb) {
			var oParameters = {
				iconTabBar: _this._oIconTabBar,
				bindPath: "/detailsData/results",
				model: oModel,
				parentView: Constants.LOCOMOTIVES,
				locomotiveNumber: _this._oViewPropertiesModel.getProperty("/LocomotiveNumber"),
				equipmentNo: _this._sEquipmentNo,
				Description: oModel.getData("global").detailsData.Description, // SHE0272 - INC0110700 - Getting the data from global model instead of local
				shiftlist: true
			};

			if (_this._IsServicing) {
				oParameters.serviceLocoObject = _this._oGlobalModel.getProperty("/currentLocomotive");
			}

			_this.loadData(oParameters);
			BusyIndicator.hideBusyIndicator();

		},

		/*
		CODE COMMENTED AFTER PLANNING HAS BEEN REMOVED
		
		onClickPlanButtonPress: function(oEvent) {
			this._bSingleOperation = false;
			var oDataObject = {};
			oDataObject.PlanStartTs = "";
			oDataObject.PlanWorkDur = "";

			this._oContextCurrOperation = null;

			var oModel = new JSONModel();
			oModel.setProperty("/PlanStartTs", oDataObject.PlanStartTs);
			oModel.setProperty("/PlanWorkDur", oDataObject.PlanWorkDur);
			this.openPlanDialog(oModel);
		},

		onPlanOperation: function(oEvent) {
			var oPlanModel = oEvent.getSource().getModel();
			var dPlanStartTs = oPlanModel.getProperty("/PlanStartTs");
			var iPlanWorkDur = oPlanModel.getProperty("/PlanWorkDur");
			var oDataObject = this.prepareOpPayload(dPlanStartTs, iPlanWorkDur);

			LocomotiveDataModel.updateOperation(this.onOperationUpdateSucesss, this, oDataObject);
			this._oPlanOperationDialog.close();
		},
		
		onCancelPlanOperation: function(oEvent) {
			this._oPlanOperationDialog.close();
		},
		
		onClickPlanLinkPress: function(oEvent) {

			this._bSingleOperation = true;

			var oDataObject = {};
			oDataObject.PlanStartTs = "";
			oDataObject.PlanWorkDur = "";

			this._oContextCurrOperation = oEvent.getSource().getBindingContext();
			if (this._oContextCurrOperation) {
				oDataObject = this.getView().getModel().getObject(this._oContextCurrOperation.sPath);
			}

			var oModel = new JSONModel();
			oModel.setProperty("/PlanStartTs", oDataObject.PlanStartTs);
			oModel.setProperty("/PlanWorkDur", oDataObject.PlanWorkDur);
			this.openPlanDialog(oModel);

		},
		
		openPlanDialog: function(oPlanDialogModel) {

			if (!this._oPlanOperationDialog) {
				this._oPlanOperationDialog = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.common.workplan.PlanOperation",
					this
				);
			}

			this._oPlanOperationDialog.setModel(oPlanDialogModel);
			this.getView().addDependent(this._oPlanOperationDialog);
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oPlanOperationDialog);
			this._oPlanOperationDialog.open();
		},

		prepareOpPayload: function(dStartDateTime, iPlanDur) {
			var sPayload = {};
			var aSelOperations = [];
			var aSelWorkOrders = [];
			var oOrder = {};
			var oOperation = {};
			var bOrderSelected = false;
			var aWorkOrders = this.getView().getModel().getObject("/detailsData/results");
			if (!this._bSingleOperation) {

				aWorkOrders.forEach(function(aWorkOrder) {

					aWorkOrder.OperationSet.results.forEach(function(aOperation) {
						oOperation = {};
						if (aOperation.checked) {
							oOperation.OpNode = aOperation.OpNode;
							oOperation.RoutingNo = aOperation.RoutingNo;
							oOperation.OpOverdueInd = aOperation.OpOverdueInd;
							oOperation.Activity = aOperation.Activity;
							oOperation.RegulatoryInd = aOperation.RegulatoryInd;
							oOperation.Status = aOperation.Status;
							oOperation.OrderNo = aOperation.OrderNo;
							oOperation.PlanWorkDur = aOperation.PlanWorkDur;
							oOperation.PlanWorkUom = aOperation.PlanWorkUom;
							oOperation.Descr = aOperation.Descr;
							oOperation.LongText = aOperation.LongText;
							oOperation.PlanStartTs = dStartDateTime;
							oOperation.PlanWorkDur = iPlanDur;
							bOrderSelected = true;
							aSelOperations.push(oOperation);
						}

					});
					if (bOrderSelected) {
						bOrderSelected = false;
						oOrder.OrderNo = aWorkOrder.OrderNo;
						oOrder.OperationSet = aSelOperations;

					}

				});
			} else {
				this._bSingleOperation = false;
				var aOperation = this.getView().getModel().getObject(this._oContextCurrOperation.sPath);
				oOperation.OpNode = aOperation.OpNode;
				oOperation.RoutingNo = aOperation.RoutingNo;
				oOperation.OpOverdueInd = aOperation.OpOverdueInd;
				oOperation.Activity = aOperation.Activity;
				oOperation.RegulatoryInd = aOperation.RegulatoryInd;
				oOperation.Status = aOperation.Status;
				oOperation.OrderNo = aOperation.OrderNo;
				oOperation.PlanWorkDur = aOperation.PlanWorkDur;
				oOperation.PlanWorkUom = aOperation.PlanWorkUom;
				oOperation.Descr = aOperation.Descr;
				oOperation.LongText = aOperation.LongText;
				oOperation.PlanStartTs = dStartDateTime;
				oOperation.PlanWorkDur = iPlanDur;
				aSelOperations.push(oOperation);
				oOrder.OrderNo = aOperation.OrderNo;
				oOrder.OperationSet = aSelOperations;
			}
			return oOrder;

		},
		
		onOperationUpdateSucesss: function() {

			// BusyIndicator.showBusyIndicator();
			//var oCurrentLoco = this._oGlobalModel.getProperty("/currentLocomotive");
			_this.fetchAndRefreshView();
			// LocomotiveDataModel.fetchLocomotiveDetails(_this.refreshData, "", _this, oCurrentLoco.LocoId, oCurrentLoco.Equipment);
		},
		*/

		onOperationUpdateSucesss: function () {
			/** LMP2-36 Refresh map when crafts change */
			_this._oGlobalModel.setProperty("/needDrawMap", true);
			_this._oGlobalModel.setProperty("/needRefreshMapData", true);
			/** LMP2-36 Refresh map when crafts change */
			_this.fetchAndRefreshView();

		},

		openMeasPoint: function (oWSHeader) {
			var aData = {};
			aData.oTaskHeader = oWSHeader;
			aData.oTaskHeader.oSourceViewController = this;
			aData.oTaskHeader.oSourceViewController.isFromLocomotive = true;
			var oMeasPointDialog = new MeasPointSheet(aData);
			if (!_this._oI18nModel && _this.getOwnerComponent()) {
				_this._oI18nModel = _this.getOwnerComponent().getModel("i18n");
			}
			/* Start change By KIR0084 - _i18nModel undefined so replace with _oI18nModel */
			//oMeasPointDialog.getFragment().setModel(_this._i18nModel, "i18n");
			oMeasPointDialog.getFragment().setModel(_this._oI18nModel, "i18n");
			/* End change By KIR0084 - _i18nModel undefined so replace with _oI18nModel */
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oMeasPointDialog);
			oMeasPointDialog.getFragment().open();
		},
		openSerialNo: function (oWSHeader) {
			var aData = {};
			aData.oTaskHeader = oWSHeader;
			aData.oTaskHeader.oSourceViewController = this;
			var oSerialNoDialog = new SerialNumber(aData);
			if (!_this._oI18nModel && _this.getOwnerComponent()) {
				_this._oI18nModel = _this.getOwnerComponent().getModel("i18n");
			}
			/* Start change By KIR0084 - _i18nModel undefined so replace with _oI18nModel */
			//oSerialNoDialog.getFragment().setModel(_this._i18nModel, "i18n");
			oSerialNoDialog.getFragment().setModel(_this._oI18nModel, "i18n");
			/* End change By KIR0084 - _i18nModel undefined so replace with _oI18nModel */
			//Start: ANI0006 2000014601 - _oEngineManfModel undefined so replace with _oEngineManfModel  
			if (!_this._oEngineManfModel && _this.getOwnerComponent()) {
				_this._oEngineManfModel = _this.getOwnerComponent().getEngManfJsonModel();
			}
			oSerialNoDialog.getFragment().setModel(_this._oEngineManfModel, "GLOBALENGINEMANFMODEL");
			// End: ANI0006 2000014601 - _oEngineManfModel undefined so replace with _oEngineManfModel 

			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oSerialNoDialog);
			oSerialNoDialog.getFragment().open();
		},

		onOpenWheelSheet: function (oWSHeader) {

			if (!_this.WSSaveBtnId) {
				_this.WSSaveBtnId = this.createId("WSSaveBtn");
			}

			if (!_this.WSSubmitBtnId) {
				_this.WSSubmitBtnId = this.createId("WSSubmitBtn");
			}

			if (!_this.oDialog) {
				_this.oDialog = new sap.m.Dialog({
					title: oWSHeader.Descr,
					height: "100%",
					width: "100%",
					content: [],
					buttons: [
						new sap.m.Button({
							text: "{i18n>CLOSE}",
							press: function () {
								_this.oDialog.close();
							}
						}),
						new sap.m.Button(_this.WSSaveBtnId, {
							text: "{i18n>SAVE}",
							press: function () {
								var oController = _this.oDialog.getContent()[0].getController();
								oController.onSaveWheelSheet();
							}
						}),
						new sap.m.Button(_this.WSSubmitBtnId, {
							text: "{i18n>SUBMIT}",
							enabled: false,
							type: "Emphasized",
							press: function () {
								var oController = _this.oDialog.getContent()[0].getController();
								oController.onSubmitWheelSheet();
							}
						})
					],
					afterOpen: _this.resizeDialog
				});

				_this.wheelSheetDialogId = _this.oDialog.sId;

				var oContent = new sap.ui.xmlview({
					viewName: "com.sap.cp.lm.view.myShop.common.wheelSheet.WheelSheet"
				});

				_this.oDialog.addContent(oContent);
			}

			var oCurrentLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");

			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setProperty("/WSHeader", oWSHeader);
			oModel.setProperty("/WSSaveBtnId", _this.WSSaveBtnId);
			oModel.setProperty("/WSSubmitBtnId", _this.WSSubmitBtnId);
			_this.oDialog.setModel(oModel);
			_this.getView().addDependent(this.oDialog);
			_this.oDialog.open();

			var oController = _this.oDialog.getContent()[0].getController();
			oController.fetchLocomotiveWheelSheet(oCurrentLocomotive);
		},

		openReleaseDialog: function (aWorkOrders) {
			_this._oReleaseDialog.getModel().setProperty("/WorkOrders", aWorkOrders);
			_this._oReleaseDialog.getModel()
			_this.getView().addDependent(_this._oReleaseDialog);

			_this._oReleaseDialog.open();
		},

		/**
		 * set dialog property
		 **/
		dialogSetProperty: function (sProperty, oData) {
			var oModel = _this._oReleaseDialog.getModel();
			oModel.setProperty(sProperty, oData);
			_this.oModel.setProperty(sProperty, oData);
		},

		applySelectedTrack: function (sKey) {
			var spotSelect = sap.ui.getCore().byId('releaseDialogSpotSelect');
			var spotSet = _this.filterSpots(sKey);

			var oLoco = _this._oGlobalModel.getProperty("/currentLocomotive");
			if (oLoco.Track === sKey) {
				//re-add spot which is currently occupied by the locomotive on this track
				spotSet.push({
					"Spot": oLoco.Spot
				});
			}

			_this.dialogSetProperty("/AvailableSpotSet", spotSet);

			spotSelect.setEnabled(true);
			spotSelect.setSelectedItem(null);
		},

		/* #DontDelete : Yann */
		/**
		 * filter available Spots
		 */
		filterSpots: function (sKey) {
			var aTrackSet = _this.oModel.getProperty("/AvailableTrackSet");
			for (var i = 0; i < aTrackSet.length; i++) {
				var oTrack = aTrackSet[i];
				if (oTrack.Track === sKey) {
					return oTrack.AvailSpots.results;
				}
			}
			return [];
		},

		/**
		 * Validate choosen release Track/Spot
		 */
		onValidateReleaseTrackSpot: function () {
			var trackSelect = sap.ui.getCore().byId('releaseDialogTrackSelect');
			var track = trackSelect.getSelectedKey();
			_this.newTrack = track;

			var spotSelect = sap.ui.getCore().byId('releaseDialogSpotSelect');
			var spot = spotSelect.getSelectedKey();
			_this.newSpot = spot;

			var directionSelect = sap.ui.getCore().byId('releaseDialogDirectionSegmentedButton');
			var direction = directionSelect.getSelectedKey();
			_this.newDirection = direction;

			if (!track || track.length === 0) {
				ErrorManager.handleError("", "Please select release Track");
				return false;
			}

			if (!spot || spot.length === 0) {
				ErrorManager.handleError("", "Please select release Spot");
				return false;
			}

			if (!direction || direction.length === 0) {
				ErrorManager.handleError("", "Please select release Direction");
				return false;
			}

			return true;
		},

		// //Start LMP2-29 : Releasing the servicing group
		// 		onReleaseServiceGroup : function () {
		// 			var aServGroup = this._oGlobalModel.getProperty("/ServiceGroupList");
		// 			var sShopId = this._oGlobalModel.getProperty("/currentShop").Id;
		// 			var oLocomotive = this._oGlobalModel.getProperty("/currentLocomotive");

		// 			var oPayload = {
		// 				"ShopId": sShopId,
		// 				"LocoId": oLocomotive.LocomotiveId
		// 			};

		// 			LocomotiveDataModel.releaseLocomotive(oPayload, _this.onReleaseLocomotiveSuccess, _this.onReleaseLocomotiveFailure,
		// 				_this);
		// 		},
		// //END LMP2-29 : Releasing the service group		

		/**
		 * complete release
		 */
		doReleaseLocomotive: function () {
			var sShopId = this._oGlobalModel.getProperty("/currentShop").Id;
			var oLocomotive = this._oGlobalModel.getProperty("/currentLocomotive");

			var oPayload = {
				"ShopId": sShopId,
				"LocoId": oLocomotive.LocomotiveId
			};

			LocomotiveDataModel.releaseLocomotive(oPayload, _this.onReleaseLocomotiveSuccess, _this.onReleaseLocomotiveFailure,
				_this);
		},

		//Start LMP2-29 : Release Servicing Group		
		doReleaseServGroup: function () {
			//	var sShopId = this._oGlobalModel.getProperty("/currentShop").Id;
			//	var oLocomotive = this._oGlobalModel.getProperty("/currentLocomotive");
			var aServGroup = this._oGlobalModel.getProperty("/ServiceGroupList");
			var oPayload = {
				"ServGrGUID": aServGroup[0].SrvcGrpId
			};

			LocomotiveDataModel.releaseServGroup(oPayload, _this.onReleaseServGroupSuccess, _this.onReleaseServGroupFailure,
				_this);
		},

		onReleaseServGroupSuccess: function (oData) {
			_this._oGlobalModel.getProperty("/currentServiceLocomotive").oMasterController.onRefreshMasterList();

			_this._oGlobalModel.setProperty("/needDrawMap", true);
			_this._oGlobalModel.setProperty("/needRefreshMapData", true);
		},
		//END LMP2-29 : Release Servicing Group	

		/*
		 * move loco after release
		 */
		getMoveLocomotivePayload: function (oEvent) {
			var oLoco = _this._oGlobalModel.getProperty("/currentLocomotive");
			var oShop = _this._oGlobalModel.getProperty("/currentShop");

			var oPayload = {
				"ShopId": oShop.Id,
				"LocoId": oLoco.LocomotiveId,
				"ToTrack": _this.newTrack,
				"ToSpot": _this.newSpot,
				"ToDirection": _this.newDirection
			};

			return oPayload;
		},

		moveLocoAfterRelease: function (oEvent) {
			var oPayload = _this.getMoveLocomotivePayload();
			LocomotiveDataModel.moveSelectedLocomotive(oPayload, _this.moveLocoAfterReleaseSuccess, _this.moveLocoAfterReleaseFailure,
				_this);
		},

		//Call  Back Functions

		_deferDefectSuccess: function (oData) {
			_this._reloadShoppedLocomotiveDefects();

			if (_this._oDeferDefectDialog && _this._oDeferDefectDialog.isOpen()) {
				_this._oDeferDefectDialog.close();
				_this._oDeferDefectDialog.destroy();
			}
		},

		/**
		 * Reload shopped locomotives from backend
		 */
		_reloadShoppedLocomotiveDefects: function () {
			_this.fetchAndRefreshView();
		},

		closeLocomotiveDefectSuccess: function (oData) {

			_this.fetchAndRefreshView();
		},

		closeLocomotiveDefectFailure: function () {
			_this.fetchAndRefreshView();
		},

		onSucessWmatUpdate: function () {
			if (LocomotiveManager.oWMATWork) {
				LocomotiveManager.oWMATWork.close();
			}

			_this.fetchAndRefreshView();
		},

		_onSuccessDeleteServiceGroup: function () {
			this._oGlobalModel.getProperty("/currentServiceLocomotive").oMasterController.onRefreshMasterList();
		},
		_onErrorDeleteServiceGroup: function () {

		},

		fetchPreReleaseWOSuccess: function (oData) {
			// console.log("fetchPreReleaseWOSuccess");
			// console.log(oData);

			//refresh track/spot
			_this.onRefreshAvailableSpots(function () {

				//pre select track/spot and direction
				var oLoco = _this._oGlobalModel.getProperty("/currentLocomotive");
				var trackSelect = sap.ui.getCore().byId('releaseDialogTrackSelect');
				var spotSelect = sap.ui.getCore().byId('releaseDialogSpotSelect');
				var directionSelect = sap.ui.getCore().byId('releaseDialogDirectionSegmentedButton');

				_this.oldTrack = oLoco.Track;
				_this.oldSpot = oLoco.Spot;
				_this.oldDirection = oLoco.Direction;

				trackSelect.setSelectedKey(oLoco.Track);
				_this.applySelectedTrack(oLoco.Track);
				spotSelect.setSelectedKey(oLoco.Spot);

				directionSelect.setSelectedKey(oLoco.Direction);

				//finally open popover
				_this.openReleaseDialog(oData);
			});
		},

		fetchPreReleaseWOFailed: function () {

		},

		// refresh available spots for locomotive release
		onRefreshAvailableSpots: function (fSuccess) {
			var shop = _this._oGlobalModel.getProperty("/currentShop");

			TrackSpotModel.fetchAvailableTracksSpots(shop.Id,
				function (oData) {
					var aTrackSet = oData.AvailTrackSet.results;
					_this.dialogSetProperty("/AvailableTrackSet", aTrackSet);
					fSuccess();
				},
				null
			);
		},

		onReleaseLocomotiveSuccess: function (oData) {
			if (_this.locoNeedToMove() === true) {
				_this.moveLocoAfterRelease();
			} else {
				_this.completeReleaseProcess();
			}
		},

		locoNeedToMove: function () {
			if (_this.oldTrack === _this.newTrack && _this.oldSpot === _this.newSpot && _this.oldDirection === _this.newDirection) {
				return false;
			}

			return true;
		},

		// Start:  New Functionality of sorting
		showSortingDialog: function () {
			this._showFragmentDialog({
				sVariable: "_oSortSettingDialog",
				sFragmentName: "SortSetting"
			});
		},

		sortReport: function (oEvent) {
			var sSortItem = oEvent.getParameter("sortItem").getKey();
			var bSortDescending = oEvent.getParameter("sortDescending");
			var oListBinding = this.getView().byId("notiftable").getBinding("items");
			oListBinding.sort([new sap.ui.model.Sorter(sSortItem, bSortDescending, false)]);
		},

		_showFragmentDialog: function (oConfig) {
			if (!this[oConfig.sVariable]) {

				this[oConfig.sVariable] = sap.ui.xmlfragment("com.sap.cp.lm.view.myShop.common." + oConfig.sFragmentName, this);
				if (oConfig.bDependentToView) {
					//as dependent
					this.getView().addDependent(this[oConfig.sVariable]);
				} else {
					//define models
					this[oConfig.sVariable].setModel(this.getView().getModel("i18n"), "i18n");
					this[oConfig.sVariable].setModel(oConfig.oDefaultModel ? oConfig.oDefaultModel : this.getView().getModel());
				}
				if (oConfig.fnInit) {
					oConfig.fnInit();
				}
			}

			if (oConfig.fnBeforeOpen) {
				oConfig.fnBeforeOpen();
			}

			if (oConfig.fnOpen) {
				oConfig.fnOpen();
			} else {
				this[oConfig.sVariable].open();
			}

			if (oConfig.fnAfterOpen) {
				oConfig.fnAfterOpen();
			}
		},

		// sorting for WO history scren 
		showSortingDialog1: function () {
			this._showFragmentDialog1({
				sVariable: "_oSortSettingDialog1",
				sFragmentName: "SortSetting1"
			});
		},

		sortReport1: function (oEvent) {
			var sSortItem = oEvent.getParameter("sortItem").getKey();
			var bSortDescending = oEvent.getParameter("sortDescending");
			var oListBinding = this.getView().byId("idWorkOrderList").getBinding("items");
			oListBinding.sort([new sap.ui.model.Sorter(sSortItem, bSortDescending, false)]);
		},

		_showFragmentDialog1: function (oConfig) {
			if (!this[oConfig.sVariable]) {

				this[oConfig.sVariable] = sap.ui.xmlfragment("com.sap.cp.lm.view.myShop.common." + oConfig.sFragmentName, this);
				if (oConfig.bDependentToView) {
					//as dependent
					this.getView().addDependent(this[oConfig.sVariable]);
				} else {
					//define models
					this[oConfig.sVariable].setModel(this.getView().getModel("i18n"), "i18n");
					this[oConfig.sVariable].setModel(oConfig.oDefaultModel ? oConfig.oDefaultModel : this.getView().getModel());
				}
				if (oConfig.fnInit) {
					oConfig.fnInit();
				}
			}

			if (oConfig.fnBeforeOpen) {
				oConfig.fnBeforeOpen();
			}

			if (oConfig.fnOpen) {
				oConfig.fnOpen();
			} else {
				this[oConfig.sVariable].open();
			}

			if (oConfig.fnAfterOpen) {
				oConfig.fnAfterOpen();
			}
		},
		// end:sorting for WO history screen 

		//END:New functionality of Sorting

		onReleaseLocomotiveFailure: function () {
			_this._oReleaseDialog.close();
			_this._oReleaseDialog.destroy();
		},

		moveLocoAfterReleaseSuccess: function (oData) {
			_this.completeReleaseProcess();
		},

		moveLocoAfterReleaseFailure: function () {
			_this._oReleaseDialog.close();
			_this._oReleaseDialog.destroy();
		},

		completeReleaseProcess: function () {
			_this._oReleaseDialog.close();
			_this._oReleaseDialog.destroy();

			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.publish("ReleaseProcess", "releaseProcessDone", {
				"success": true
			});
		},

		/* START KIR0084 LMP2-30 */
		onFetchLocomotiveDefectsSuccessForService: function (oData) {
			if (!_this.oArriveManager) {
				_this.oArriveManager = ArriveManager.init("workPlan", "service");
			}

			var oShop = _this._oGlobalModel.getProperty("/currentShop");
			var oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
			_this.oArriveManager.setType("service");
			_this.oArriveManager.onArriveProcessDialogOpen(oData.results, oShop, oLocomotive, _this);
		},
		/* END KIR0084 LMP2-30 */

		onFetchLocomotiveDefectsSuccess: function (oData) {
			if (!_this.oArriveManager) {
				_this.oArriveManager = ArriveManager.init("workPlan", "shopped");
			}

			var oShop = _this._oGlobalModel.getProperty("/currentShop");
			var oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
			_this.oArriveManager.setType("shopped");
			_this.oArriveManager.onArriveProcessDialogOpen(oData.results, oShop, oLocomotive, _this);
		},
		//START - BAJ0018 - ASR3416358-LM attachment
		onFileUpload: function () {
			var oWorkOrder = this._selectedContext.getObject();
			if (!_this._oFileUpload) {
				_this._oFileUpload = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.common.FileUploader",
					_this
				);

				_this.getView().addDependent(_this._oFileUpload);
				_this.oWorkOrder = oWorkOrder;
			}

			_this._oFileUpload.open();
		},

		onUploadAttachmentClose: function () {
			_this._oFileUpload.close();
			_this._oFileUpload.destroy();
			_this._oFileUpload = null;
		},

		onUploadAttachment: function () {
			var oUploader = sap.ui.getCore().byId("fileUploader");
			oUploader.upload();
			_this._oFileUpload.setBusy(true);
		},

		onUploadAttachmentChange: function (oEvent) {
			var oSource = sap.ui.getCore().byId("fileUploader");
			var oFile = oEvent.getParameters().files[0];
			var sFileName = oFile.name;
			var sType = oFile.type;

			if (!sType) {
				sType = "application/octet-stream";
			}

			var sOrderNumber = _this.oWorkOrder.OrderNo;
			var oModel = _this.getOwnerComponent().getModel();
			var sSlug = '"Key":"' + sOrderNumber + '","FileName":"' + sFileName + '","FileType":"' + sType + '"';

			oSource.destroyHeaderParameters();
			oSource.addHeaderParameter(new FileUploaderParameter({
				name: "X-CSRF-Token",
				value: oModel.getSecurityToken()
			}));
			//file name can not contain :
			oSource.addHeaderParameter(new FileUploaderParameter({
				name: "slug",
				value: sSlug
			}));
			oSource.addHeaderParameter(new FileUploaderParameter({
				name: "Content-Type",
				value: sType
			}));
			oSource.addHeaderParameter(new FileUploaderParameter({
				name: "accept",
				value: "application/json"
			}));
		},

		onUploadAttachmentComplete: function (oEvent) {
			_this._oFileUpload.setBusy(false);
			var iStatus = oEvent.getParameter("status");
			var sResponseRaw = oEvent.getParameter("responseRaw");
			var sMessage = "";

			if (iStatus === 201) {
				oEvent.getSource().clear();
				sap.m.MessageToast.show("File uploaded successfully");
				_this._oFileUpload.setBusy(false);
				_this._oFileUpload.close();
				_this._oFileUpload.destroy();
				_this._oFileUpload = null;
			} else {
				var oResponse = JSON.parse(sResponseRaw);

				if (oResponse.hasOwnProperty("error")) {
					sMessage = oResponse.error.message.value;
				} else {
					sMessage = "File uploaded failed";
				}

				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.show("Upload Response: " + sMessage, {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "File Upload Error!",
					actions: [sap.m.MessageBox.Action.CLOSE],
					onClose: function () {
						_this._oFileUpload.setBusy(false);
						_this._oFileUpload.close();
						_this._oFileUpload.destroy();
						_this._oFileUpload = null;
					}.bind(this)
				});
				return;
			}
		},
		//END - BAJ0018 - ASR3416358-LM attachment

		onDepartLocomotiveSuccess: function (oData) {
			this.fetchAndRefreshView(true);

			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.publish("RemoveProcess", "removeProcessDone", {
				"success": true
			});
		},
		/***
		 * Open BnB dialog VYA0004 2000011826 Begin
		 */
		onStartBnB: function (oEvent) {
			if (!_this.oStartBnB) {
				_this.oStartBnB = StartBnB.init(_this, _this.fetchAndRefreshView);
			}
			_this._bisReloadMasterRequired = true;
			_this.oStartBnB.onStartBnBDialogOpen(_this, _this.fetchAndRefreshView);
		},
		/***
		 * Open View Inventory dialog
		 */
		onViewInventory: function (oEvent) {
			if (!_this.oViewInventory) {
				_this.oViewInventory = ViewInventory.init(_this, _this.fetchAndRefreshView);
			}
			_this._bisReloadMasterRequired = true;
			_this.oViewInventory.onViewInventoryDialogOpen(oEvent, _this, _this.fetchAndRefreshView);
			//_this.bAddWorkOrder = true;
		},
		//VYA0004 2000011826 End
		//Begin VYA0004|LLM3.3
		onClickAcknowledge: function (oEvent) {

			var sOrderNo = _this._currentOrderNo;
			_this._oCompleteWorkDialog = sap.ui.xmlfragment(
				"com.sap.cp.lm.view.myShop.inbound.defects.CompleteWorkDialog",
				_this
			);
			if (_this._oCompleteWorkDialog) {
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setProperty("/isRegulatory", _this.bIsRegulatory);
				_this._oCompleteWorkDialog.setModel(oModel);
				_this._oCompleteWorkDialog.setModel(oModel);
			}
			_this._oNoMatReqDispDialog.destroy();
			_this._oNoMatReqDispDialog = null;
			_this.getView().addDependent(_this._oCompleteWorkDialog);
			_this._oCompleteWorkDialog.open();
		},

		onCompleteWorkNoMatReqOpen: function (oEvent) {
			_this.oNoMatReqDispModel = new sap.ui.model.json.JSONModel();
			var oWorkOrder = this._selectedContext.getObject();
			if (oWorkOrder.MatRestFlag === 'Y') {
				var sOrderNo = oWorkOrder.OrderNo;
				if (sOrderNo) {
					_this._currentOrderNo = sOrderNo;
				}
				_this.bIsRegulatory = oWorkOrder.RegulatoryInd;
				MaterialModel.DisplayNoMaterialRequired(sOrderNo, _this);
				if (!_this._oNoMatReqDispDialog) {
					_this._oNoMatReqDispDialog = sap.ui.xmlfragment(
						"com.sap.cp.lm.view.myShop.shopped.addMaterial.NoMaterialRequiredDisplay",
						_this
					);
				}
				_this._oNoMatReqDispDialog.setModel(_this.oNoMatReqDispModel);
				var i18nModel = new sap.ui.model.resource.ResourceModel({
					bundleName: "com.sap.cp.lm.i18n.i18n"
				});
				MaterialModel.fetchGMPSinfo(sOrderNo, _this);
				_this._oNoMatReqDispDialog.setModel(_this.oModel);
				_this._oNoMatReqDispDialog.setModel(i18nModel, "i18n");
				_this._oNoMatReqDispDialog.open();
				BusyIndicator.hideBusyIndicator();
			} else {
				this.onClickCompleteWorkOrder(oEvent);
			}
		},
		//No Material Required Reason
		onNoMaterialReqDispDialogOpen: function (oEvent) {
			_this.oNoMatReqDispModel = new sap.ui.model.json.JSONModel();
			var sOrderNo = oEvent.getSource().getBindingContext("global").getObject().OrderNo;
			MaterialModel.DisplayNoMaterialRequired(sOrderNo, _this);
			if (!_this._oNoMatReqDispDialog) {
				_this._oNoMatReqDispDialog = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.shopped.addMaterial.NoMaterialRequiredDisplay",
					_this
				);
			}
			_this._oNoMatReqDispDialog.setModel(_this.oNoMatReqDispModel);
			var i18nModel = new sap.ui.model.resource.ResourceModel({
				bundleName: "com.sap.cp.lm.i18n.i18n"
			});
			MaterialModel.fetchGMPSinfo(sOrderNo, _this);
			_this._oNoMatReqDispDialog.setModel(_this.oModel);
			_this._oNoMatReqDispDialog.setModel(i18nModel, "i18n");
			_this._oNoMatReqDispDialog.open();
			BusyIndicator.hideBusyIndicator();
		},
		onNoMatReqDisplayDialogClose: function (oEvent) {
			_this._oNoMatReqDispDialog.destroy();
			_this._oNoMatReqDispDialog = null;
		},
		//End VYA0004|LLM3.3
		onCompleteTaskError: function () {

		}

	});
});