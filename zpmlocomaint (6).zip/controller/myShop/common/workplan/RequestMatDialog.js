/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.21                                           *
* Project        : Locomotive Maintenance                               *
* Description    : Controller for Requesting Materials. Hook methods of *
*                  view life cycle can be implemented for fragment      *
*                  life cycle.                                          *
*&----------------------------------------------------------------------*/

// #DontDelete : Daya new controller class , dont delete any method inthis file

sap.ui.define([
		"com/sap/cp/lm/controller/common/FragmentBaseDelegate",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
		"com/sap/cp/lm/util/ErrorManager",
		"com/sap/cp/lm/model/alert/AlertDataModel"
	], function(BaseDelegate, BusyIndicator, LocomotiveDataModel, ErrorManager, AlertDataModel) {
		"use strict";
		var _this;
		return BaseDelegate.extend("com.sap.cp.lm.controller.myShop.common.workplan.RequestMatDialog", {

			_sFragmentName: "com.sap.cp.lm.view.myShop.common.workplan.RequestMatDialog",
			/**
			 * Fragment Initialization method
			 * 
			 */
			onInit: function() {
				_this = this;
				var oModel = new sap.ui.model.json.JSONModel();
				this.getFragment().setModel(oModel);
				BusyIndicator.showBusyIndicator();
				this._initParameters();

			},

			//Initialization

			_initParameters: function() {
				this.aDataFromSource = this.oParameters.oMessage;
				var oModel = this.getFragment().getModel();
				var sLocoMotive = this.aDataFromSource.LocoID;
				var sOperation = this.aDataFromSource.OperationDescr;
				var sOperationCodeDescr = this.aDataFromSource.OperationDescr + " (" + this.aDataFromSource.OperationNo + ")";
				var sShop = this.aDataFromSource.ShopName + " (" + this.aDataFromSource.ShopNo + ")";
				var sMaterial = this.aDataFromSource.MaterialDesc + " (" + this.aDataFromSource.MaterialCode + ")";
				var sWorkOrder = this.aDataFromSource.sOrderDesc;
				var sWorkOrderNoDescr = this.aDataFromSource.sOrderDesc + " (" + this.aDataFromSource.sOrderNo + ")";

				oModel.setProperty("/Locomotive", sLocoMotive);
				oModel.setProperty("/Operation", sOperation);
				oModel.setProperty("/OperationNo", sOperationCodeDescr);
				oModel.setProperty("/Material", sMaterial);
				oModel.setProperty("/Shop", sShop);
				oModel.setProperty("/Sender", this.aDataFromSource.Sender);
				oModel.setProperty("/WorkOrder", sWorkOrder);
				oModel.setProperty("/WorkOrderNo", sWorkOrderNoDescr);
				BusyIndicator.hideBusyIndicator();

			},

			//Send the Message

			onMATRequest: function() {

				var oModel = this.getFragment().getModel();
				var oPayload = {};
				oPayload.Sender = oModel.getProperty("/Sender");
				oPayload.AlertType = "M";
				oPayload.Shop = this.aDataFromSource.ShopNo;
				oPayload.Text = "Shop: " + oModel.getProperty("/Shop") + "\n" + "Locomotive: " + oModel.getProperty("/Locomotive") + "\n" +
					"Work Order: " + oModel.getProperty("/WorkOrderNo") +
					"\n" + "Operation: " + oModel.getProperty("/OperationNo") +
					"\n" + "Material: " + oModel.getProperty("/Material") + "\n" + oModel.getProperty("/Message");

				var oEntry = AlertDataModel.createPersonalAlertMessage(oPayload.Text, oPayload.Sender, oPayload.Receiver, "M");
				oEntry.Shop = oPayload.Shop;
				AlertDataModel.createAlertsMessage(this.fnSuccessSave, this, oEntry);
			},

			//Success call back
			fnSuccessSave: function() {
				this.getFragment().close();

			},

			//Close the dialog window

			onSendMessageCancel: function() {
				this.getFragment().close();
			}

		});
	}

);