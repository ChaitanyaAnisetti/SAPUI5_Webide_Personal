/* #DontDelete : Yann */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator"
], function(Controller, Constants, Formatter, BusyIndicator) {
	"use strict";

	var _this;

	return Controller.extend("com.sap.cp.lm.controller.myShop.MyShop", {

		/**
		 * Initializes the controller
		 */
		onInit: function() {
			_this = this;

			this._myShopSC = this.getView().byId("MyShopSC");

			// listen to event when the map needs to be rendered in a full screen
			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.subscribe("MyShopSC", "toggleSplitContainerMode", this.toggleSplitContainerMode, this);
			// listen to event when the map is in a full screen to show the master page as a layover on top of the detail page
			oEventBus.subscribe("MyShopSC", "toggleSplitContainerShowMaster", this.toggleSplitContainerShowMaster, this);

		},

		/**
		 * Show/Hide the master page as a layover on top of the detail page within the split controller
		 */
		toggleSplitContainerShowMaster: function(sChannel, sEvent, oData) {
			if (oData.hideMaster) {
				this._myShopSC.hideMaster();
			} else {
				this._myShopSC.showMaster();
			}
		},

		/**
		 * Toggle between full screen and not for the detail page(map view) within the split controller
		 */
		toggleSplitContainerMode: function(sChannel, sEvent, oData) {
			if (oData.hideMaster) {
				this._myShopSC.setMode("HideMode");
			} else {
				this._myShopSC.setMode("ShowHideMode");
			}
		}

	});
});