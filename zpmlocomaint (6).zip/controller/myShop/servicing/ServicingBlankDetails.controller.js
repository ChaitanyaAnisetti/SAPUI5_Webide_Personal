/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.06                                           *
* Project        : Locomotive Maintenance                               *
* Description    : This controller is associated to the Servicing view  *
*                  displayed only when there is no selected locomotive. *
*&----------------------------------------------------------------------*/


sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/BusyIndicator",

], function(Controller, Constants, BusyIndicator) {
	"use strict";
	var _this;
	return Controller.extend("com.sap.cp.lm.controller.myShop.servicing.ServicingBlankDetails", {

		/**
		 * Function is called when Controller is loaded only for the first time 
		 */
		onInit: function() {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());
			BusyIndicator.hideBusyIndicator();
		},

		/**
		 * Navigate back to the map view
		 */
		onMapPress: function() {
			this.getOwnerComponent().getGlobalModel().setProperty("/MyShopMap", true);
			this._oRouter.getTargets().display("locomotivesShoppedMap");
		},

		onShoppedDetailsPress: function() {
			this.getOwnerComponent().getGlobalModel().setProperty("/MyShopMap", false);
			this._oRouter.getTargets().display("locomotivesShoppedHome");
		}
	});
});