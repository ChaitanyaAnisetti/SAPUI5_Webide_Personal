/*&---------------------------------------------------------------------*    
 * Author         : SAP Custom Development                               *
 * Date           : 2017.12.06                                           *
 * Project        : Locomotive Maintenance                               *
 * Description    : This controller is associated to the Servicing tab   *
 *                  on Locomotives page.                                 *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2018.02.15                                           *
 * Incidinet      : Locomotive Maintenance - IM241669-002                *
 * Description    : Logic revised for toolbar buttons in WorkPlan view   *
 *&----------------------------------------------------------------------*/
 /*&-----------------------------------------------------------------------*    
* Author/Changed By   : SAT0008				        		       		  *
* Date                : 8-May-2019                                     *
* Project             : Locomotive Maintenance Phase 2                    *
* Description         : LMP2-03 : Work order History and Notification History *
/*&------------------------------------------------------------------------*/
 /*&-----------------------------------------------------------------------*    
* Author/Changed By   : BAJ0018				        		       		   *
* Date                : 4-October-2021                                     *
* Project             : EAM-INC0117694                                     *
* Description         : Fixed WSA refresh issue                            *
/*&------------------------------------------------------------------------*/
sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/Fragment",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/json/JSONModel",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
	"com/sap/cp/lm/controller/locomotives/LocomotiveManager",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/model/craft/CraftDataModel",
	"com/sap/cp/lm/util/ErrorManager",
	"com/sap/cp/lm/controller/myShop/common/LocomotiveHeaderManager"
], function(jQuery, Fragment, Controller, Filter, JSONModel, Constants, BusyIndicator, LocomotiveDataModel,
	LocomotiveManager, Formatter, CraftDataModel, ErrorManager, LocomotiveHeaderManager) {
	"use strict";
	var _this;
	sap.ui.controller("com.sap.cp.lm.controller.myShop.servicing.ServicingContainer", {

		/**
		 * Function is called when Controller is loaded only for the first time 
		 */
		onInit: function() {
			_this = this;
			$(window).on('resize', $.proxy(_this.handleWindowResize, _this));

			_this._oRouter = sap.ui.core.UIComponent.getRouterFor(_this.getView());
			_this.getView().setModel(new sap.ui.model.json.JSONModel({}));

			_this._oI18nModel = _this.getOwnerComponent().getModel("i18n");
			
			_this._oGlobalModel = _this.getOwnerComponent().getGlobalModel();

			// register to listen to change events of the globalmodel which contain the currentShop
			var binding = new sap.ui.model.Binding(_this._oGlobalModel, "/", _this._oGlobalModel.getContext("/"));
			binding.attachChange(function() {
				_this.onGlobalModelChange();
			});

			this._oRouter.getTargets().attachDisplay(function(oEvent) {
				if (oEvent.getParameter("name") === "locomotivesServicingHome") {
					_this._oGlobalModel.setProperty("/readOnlyWorkPlan", false);
					_this._oGlobalModel.setProperty("/readFromWorkPlan", true); //Added by Sandhya LMP2-3
					_this._oGlobalModel.setProperty("/readFromWOHistory", false); //Added by Sandhya LMP2-3

					_this._oGlobalModel.setProperty("/isShopped", false);
					_this._oGlobalModel.setProperty("/isServiced", true);

					BusyIndicator.showBusyIndicator();
					var oLocomotive = _this._oGlobalModel.getProperty("/currentServiceLocomotive");
					_this.loadLocomotiveDetails(oLocomotive);
					var forcedLocomotive = _this._oGlobalModel.getProperty("/forcedLocomotive");
					if (forcedLocomotive) {
						_this.refreshLocomotivesList();
					}
				}
			});

			_this.initLocomotiveHeader();
		},

		//common
		refreshLocomotivesList: function() {
			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.publish("MyShopMasterPage", "onRefreshMasterList", {});
		},

		/**
		 * Fullscreen/exit full screen button pressed
		 */
		onToggleFullScreenPress: function(oEvent) {
			_this._bHideMaster = !_this._bHideMaster;
			// change the button icon
			if (_this._bHideMaster) {
				oEvent.getSource().setIcon("sap-icon://exit-full-screen");
			} else {
				oEvent.getSource().setIcon("sap-icon://full-screen");
			}

			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.publish("MyShopSC", "toggleSplitContainerShowMaster", {
				"hideMaster": _this._bHideMaster
			});
		},

		/**
		 * when the global model is changed
		 */
		onGlobalModelChange: function() {
			var tempCurrentRole = _this._oGlobalModel.getProperty("/role");
			// check if the currentRole is different and if so reload the map
			if (tempCurrentRole && tempCurrentRole !== _this.sRole) {
				_this.sRole = tempCurrentRole;
				var sRoleModel = new sap.ui.model.json.JSONModel();
				sRoleModel.setProperty("/SelectedRole", _this.sRole);
				_this.getView().setModel(sRoleModel, "Role");

				var oLocomotive = _this._oGlobalModel.getProperty("/currentServiceLocomotive");
				if (oLocomotive) {
					_this.loadLocomotiveDetails(oLocomotive);
				}
			}
		},

		loadLocomotiveDetails: function(oLocomotive) {
			_this.showLocoDetails(oLocomotive);

			_this.sLocomotiveId = oLocomotive.LocomotiveId;
			
			var sEquipNo = oLocomotive.Equipment;
			if(!sEquipNo) {
				sEquipNo = oLocomotive.EquipNo;
			}
			_this.sEquipment = sEquipNo;

			_this.getView().getModel().setProperty("/detailsData/LocomotiveNumber", _this.sLocomotiveId);

			var sKey = _this.getView().byId("serviceIconTabBar").getSelectedKey();
			_this._processSelectedTab(sKey);
		},

		/**
		 * Common close function for all dialogs
		 */
		onClickCancel: function() {
			if (_this.UnplanSelected) {
				_this.UnplanSelected.close();
			}

			if (_this._placeLocomotiveDialog) {
				_this._placeLocomotiveDialog.destroy();
			}
			if (_this.oAddWODialog) {
				_this.onClickWOCancel(_this);
			}
			if (_this.oSelectTaskDialog) {
				_this.oSelectTaskDialog.destroy();
			}
			if (_this.oReleaseFrag) {
				_this.oReleaseFrag.destroy(true);
				_this.oReleaseFrag = null;
			}
			if (_this.oArriveShopService) {
				_this.oArriveShopService.close();
			}
			if (_this.oPredictDialog) {
				_this.oPredictDialog.close();
			}
			if (_this.oAddCraftDiag) {
				var oCraftTable = sap.ui.core.Fragment.byId("idAddCraftFrag", "idCraftTable");
				oCraftTable.removeSelections(true);
				_this.oAddCraftDiag.close();
			}
		},

		/**
		 * Handles selection of Icon Tab Bar
		 * @params(event) oEvent is returned on
		 * 				  icon tab bar selection changes
		 */
		onServiceIconSelect: function(oEvent) {
			var sKey = oEvent.getParameters().key;
			_this._processSelectedTab(sKey);
		},

		addContentIconTabFilter: function(sIdFilter, sView) {
			var oView = this.getOwnerComponent().runAsOwner(function() {
				return sap.ui.view({
					viewName: sView,
					type: sap.ui.core.mvc.ViewType.XML
				});
			});
			oView.setModel(_this._oI18nModel, "i18n");

			this.byId(sIdFilter).destroyContent();
			this.byId(sIdFilter).addContent(oView);

			return oView.getController();
		},

		_processSelectedTab: function(sKey) {
			var oLocomotive = _this._oGlobalModel.getProperty("/currentServiceLocomotive");

			if(!sKey) {
				sKey = "workPlan";
			}
			
			if (sKey === "workPlan") {
// START - BAJ0018 - IM241669-002	
				_this._oGlobalModel.setProperty("/fleetDetailsOrigin", " ");
// End - BAJ0018 - IM241669-002	
				var isGroup = _this._oGlobalModel.getProperty("/isGroup");
				
				if (isGroup && isGroup === true) {
// START - BAJ0018 - IM241669-002					
				//	_this._oGlobalModel.setProperty("/workplanFooterIsVisible", false);
				_this._oGlobalModel.setProperty("/workplanFooterIsVisible", true);
// End - BAJ0018 - IM241669-002					
				} else {
					_this._oGlobalModel.setProperty("/workplanFooterIsVisible", true);
				}

				_this._oGlobalModel.setProperty("/readOnlyWorkPlan", false);
				_this._oGlobalModel.setProperty("/readFromWorkPlan", true); //Added by Sandhya LMP2-3
				_this._oGlobalModel.setProperty("/readFromWOHistory", false); //Added by Sandhya LMP2-3

				LocomotiveDataModel.fetchServiceWorkOrders(_this.loadData, null, _this, oLocomotive);
			}
			if (sKey === "history") {
				_this._oGlobalModel.setProperty("/workplanFooterIsVisible", false);
				_this._oGlobalModel.setProperty("/readOnlyWorkPlan", true);
				_this._oGlobalModel.setProperty("/readFromWorkPlan", false); //Added by Sandhya LMP2-3
				_this._oGlobalModel.setProperty("/readFromWOHistory", true); //Added by Sandhya LMP2-3

				_this.addContentIconTabFilter("serviceWOHistoryTab", "com.sap.cp.lm.view.common.workOrderHistory.WorkOrderHistory").fetchWOHistory();
			}
			if (sKey === "defects") {
				_this.byId("serviceLocoDefects").getController().fetchLocomotiveDefects(oLocomotive);
			}
			if (sKey === "wheelSheet") {
				// _this.byId("serviceLocoWheelSheet").getController().fetchLocomotiveWheelSheetHistory(oLocomotive);
				_this.addContentIconTabFilter("serviceLocoWheelSheetTab", "com.sap.cp.lm.view.myShop.common.wheelSheet.WheelSheetHistory").fetchLocomotiveWheelSheetHistory();
			}
			if (sKey === "details") {
				// _this.byId("serviceLocoDetails").getController().fetchDetails(oLocomotive);
				_this.addContentIconTabFilter("serviceLocoDetailsTab", "com.sap.cp.lm.view.myShop.common.details.Details").fetchLocomotiveDetails();
			}
		},

		showLocoDetails: function(oLocomotive) {
			var visible = !oLocomotive.isServiceGroupSelected;

			_this.getView().byId("serviceLocoDefectsTab").setVisible(visible);
			_this.getView().byId("serviceWOHistoryTab").setVisible(visible);
			_this.getView().byId("serviceLocoWheelSheetTab").setVisible(visible);
			_this.getView().byId("serviceLocoDetailsTab").setVisible(visible);

			_this._oGlobalModel.setProperty("/workplanFooterIsVisible", oLocomotive.isServiceGroupSelected);
		},
		/**
		 * Success callback for fetchLocomotiveDetails ,Sets model in View
		 * Loads data for the selected locomotive
		 * @params{object} oModel returned for the new selected Locomotive
		 */
		loadData: function(oModel, oContext, oServicingLoco) {

			BusyIndicator.hideBusyIndicator();

			//ask workplan tab to reload
			var oParameters = {
				iconTabBar: _this.getView().byId("serviceIconTabBar"),
				bindPath: "/detailsData/results",
				model: oModel,
				parentView: Constants.SERVICING,
				serviceLocoObject: oServicingLoco

			};

			_this.byId("serviceLocoWorkPlan").getController().loadData(oParameters);
			//clear WSA indicator - START - BAJ0018 - EAM-INC0117694
				_this._oGlobalModel.setProperty("/isWSA", "");
			//	END - BAJ0018 - EAM-INC0117694
			BusyIndicator.hideBusyIndicator();
		},

		/**
		 * Function gets fired when the window is resizes
		 */
		handleWindowResize: function() {},

		/**
		 * Init toolbar header fragment and manager
		 */
		initLocomotiveHeader: function() {
			if (_this._oLocomotiveHeaderManager) {
				_this._oLocomotiveHeaderManager.destroy();
			}
			_this._oLocomotiveHeaderManager = new LocomotiveHeaderManager();
			_this._oLocomotiveHeaderManager = _this._oLocomotiveHeaderManager.init(_this);

			if (_this._oLocomotiveHeaderFragment) {
				_this._oLocomotiveHeaderFragment.destroy();
			}
			_this._oLocomotiveHeaderFragment = _this._oLocomotiveHeaderManager.getFragment();
			_this.byId("MyShopToolbar").addContent(_this._oLocomotiveHeaderFragment);
		}

	});
});