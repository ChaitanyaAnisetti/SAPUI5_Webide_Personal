/*&---------------------------------------------------------------------*    
 * Author         : SAP Custom Development                               *
 * Date           : 2017.12.21                                           *
 * Project        : Locomotive Maintenance                               *
 * Description    : Manager for the Locomotive Header fragment.          *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2019.02.03                                           *
 * Incidinet      : EAM-ASR3413183 - PM Loco Main phase 2                *
 * Description    : Logic revised for defult ETR reason                  *
 *&----------------------------------------------------------------------*/
sap.ui.define([
	"com/sap/cp/lm/controller/common/FragmentBaseDelegate",
	"com/sap/cp/lm/model/main/TrackSpotModel",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel"
], function (BaseDelegate, TrackSpotModel, LocomotiveDataModel) {
	"use strict";

	var _oMoveLocomotiveDialog;
	var _oNewETRDialog;

	return BaseDelegate.extend("com.sap.cp.lm.controller.fleet.FleetLocomotiveHeaderManager", {

		//----------------------------------------------------------------------
		// Initialize functions
		//----------------------------------------------------------------------

		_sFragmentName: "com.sap.cp.lm.view.fleet.FleetLocomotiveHeader",

		init: function (oContext, locoPath) {
			this.oContext = oContext;

			return this;
		},

		//----------------------------------------------------------------------
		// Private functions
		//----------------------------------------------------------------------

		/**
		 * Set available spots for track
		 */
		applySelectedTrack: function (sKey) {
			var oContext = this.oContext;
			var spotSelect = sap.ui.getCore().byId('editDialogFinishSpotSelect');
			var spotSet = this.filterSpots(sKey);

			var oLoco = oContext._oGlobalModel.getProperty(this.path);
			if (oLoco.Track === sKey) {
				//re-add spot which is currently occupied by the locomotive on this track
				spotSet.push({
					"Spot": oLoco.Spot
				});
			}

			this.dialogSetProperty("/AvailableSpotSet", spotSet);

			spotSelect.setEnabled(true);
			spotSelect.setSelectedItem(null);
		},

		/**
		 * Filter spots depending on selected track and return results
		 */
		filterSpots: function (sKey) {
			var oContext = this.oContext;
			var aTrackSet = oContext.getView().getModel().getProperty("/AvailableTrackSet");

			for (var i = 0; i < aTrackSet.length; i++) {
				var oTrack = aTrackSet[i];
				if (oTrack.Track === sKey) {
					return oTrack.AvailSpots.results;
				}
			}
			return [];
		},

		/**
		 * Filter spots depending on selected track and return results
		 */
		dialogSetProperty: function (sProperty, oData) {
			var oContext = this.oContext;
			var oModel = _oMoveLocomotiveDialog.getModel();

			oModel.setProperty(sProperty, oData);
			oContext.getView().getModel().setProperty(sProperty, oData);
		},

		/**
		 * Create and return payload needed to request locomotive to move in backend
		 */
		getMoveLocomotivePayload: function (oEvent) {
			var oContext = this.oContext;
			var trackSelect = sap.ui.getCore().byId('editDialogFinishTrackSelect');
			var spotSelect = sap.ui.getCore().byId('editDialogFinishSpotSelect');
			var directionSelect = sap.ui.getCore().byId('editDialogFinishDirectionSegmentedButton');

			var oLoco = oContext._oGlobalModel.getProperty(this.path);
			var oShop = oContext._oGlobalModel.getProperty("/currentShop");

			var sShopId = oShop.Id;
			var sLocoId = oLoco.LocomotiveId;

			var sToTrack = trackSelect.getSelectedKey();
			var sToSpot = spotSelect.getSelectedKey();
			var sToDirection = directionSelect.getSelectedKey();

			var oPayload = {
				"ShopId": sShopId,
				"LocoId": sLocoId,
				"ToTrack": sToTrack,
				"ToSpot": sToSpot,
				"ToDirection": sToDirection
			};

			return oPayload;
		},

		/**
		 * Create and return payload needed to create new ETR in backend
		 */
		getNewETRPayload: function (oEvent) {
			var oContext = this.oContext;

			var newETRReasonSelect = sap.ui.getCore().byId('newETRReasonSelect');
			var ReasonCode = newETRReasonSelect.getSelectedKey();
			/*Added by Vikram*/
			//var ReasonDescr = newETRReasonSelect.getSelectedItem().getText();
			/*Added by Vikram*/
			var oLoco = oContext._oGlobalModel.getProperty(this.path);
			var oShop = oContext._oGlobalModel.getProperty("/currentShop");

			var sEquipNo = oLoco.Equipment;
			if (!sEquipNo) {
				sEquipNo = oLoco.EquipNo;
			}

			var sShopId = oShop.Id;
			var EquipNo = parseInt(sEquipNo, 10);

			var newETRDateTime = sap.ui.getCore().byId('newETRDateTime');
			var newETRTs = newETRDateTime.getValue();

			var newETRTz = oShop.TimeZone;
			/*Added by Vikram*/
			var current_etr = oContext._oGlobalModel.getProperty(this.path + "/EtrTs");
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyy-MM-ddTHH:mm:ss"
			});
			var sFormattedCurDate = oDateFormat.format(current_etr);
			if (sFormattedCurDate > newETRTs) {
				if (ReasonCode) {
					var ReasonDescr = newETRReasonSelect.getSelectedItem().getText();
				} else {
					ReasonCode = "ZZZ"; //default code for early in 
					ReasonDescr = "";
				}
			} else {
			    // KIR0084 Stop null pointer exception when not setting reason description
				// ReasonDescr = newETRReasonSelect.getSelectedItem().getText();
				ReasonDescr = newETRReasonSelect.getSelectedItem()? newETRReasonSelect.getSelectedItem().getText(): "";
			}
			/*Added by Vikram*/
			var oPayload = {
				"Shop": sShopId,
				"EquipNo": EquipNo,
				"ETR_Ts": new Date(newETRTs),
				"ETR_Tz": newETRTz,
				"ReasonCode": ReasonCode,
				"ReasonDescr": ReasonDescr
			};

			return oPayload;
		},

		//----------------------------------------------------------------------
		// Event functions
		//----------------------------------------------------------------------

		/**
		 * Open and init dialog to move locomotive
		 */
		onMoveLocomotive: function (oEvent) {
			var oContext = this.oContext;
			var _this = this;

			if (!_oMoveLocomotiveDialog) {
				_oMoveLocomotiveDialog = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.shopped.MoveLocomotiveDialog",
					this
				);
			}

			if (_oMoveLocomotiveDialog) {
				var shop = oContext._oGlobalModel.getProperty("/currentShop");

				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setProperty("/Shop", shop);
				_oMoveLocomotiveDialog.setModel(oModel);
			}

			oContext.getView().addDependent(_oMoveLocomotiveDialog);

			this.onRefreshAvailableSpots(function () {
				_oMoveLocomotiveDialog.open();

				var oLoco = oContext._oGlobalModel.getProperty(this.path);
				var trackSelect = sap.ui.getCore().byId('editDialogFinishTrackSelect');
				var spotSelect = sap.ui.getCore().byId('editDialogFinishSpotSelect');
				var directionSelect = sap.ui.getCore().byId('editDialogFinishDirectionSegmentedButton');

				trackSelect.setSelectedKey(oLoco.Track);
				_this.applySelectedTrack(oLoco.Track);
				spotSelect.setSelectedKey(oLoco.Spot);
				directionSelect.setSelectedKey(oLoco.Direction);
			});
		},

		/**
		 * Filter spots when track is selected in dropdown from move locomotive dialog
		 */
		onChangeTrack: function (oEvent) {
			var sKey = oEvent.getSource().getSelectedKey();
			this.applySelectedTrack(sKey);
		},

		/**
		 * Refresh available spots for locomotive arrival
		 */
		onRefreshAvailableSpots: function (fSuccess) {
			var oContext = this.oContext;
			var _this = this;
			var shop = oContext._oGlobalModel.getProperty("/currentShop");
			var directions = oContext._oGlobalModel.getProperty("/Directions");

			TrackSpotModel.fetchAvailableTracksSpots(shop.Id,
				function (oData) {
					var aTrackSet = oData.AvailTrackSet.results;
					_this.dialogSetProperty("/AvailableTrackSet", aTrackSet);
					_this.dialogSetProperty("/Directions", directions);
					fSuccess();
				},
				null
			);
		},

		/**
		 * Close dialog on click
		 */
		onDialogCancel: function (oEvent) {
			oEvent.getSource().getParent().close();
		},

		/**
		 * On click of done button in move locomotive dialog, call request
		 */
		onMoveDialogDone: function (oEvent) {
			var oPayload = this.getMoveLocomotivePayload();
			LocomotiveDataModel.moveSelectedLocomotive(oPayload, this.onMoveSelectedLocomotiveSuccess, this.onMoveSelectedLocomotiveFailure,
				this);
		},

		/**
		 * Locomotive has been moved, update locomotives
		 */
		onMoveSelectedLocomotiveSuccess: function (oData) {
			var oContext = this.oContext;

			_oMoveLocomotiveDialog.close();
			oContext.refreshShoppedLocomotives();
		},

		/**
		 * Locomotive has not been moved, close dialog
		 */
		onMoveSelectedLocomotiveFailure: function (oData) {
			_oMoveLocomotiveDialog.close();
		},

		/**
		 * Open and init dialog to create new ETR
		 */
		onNewETR: function (oEvent) {
			var oContext = this.oContext;

			if (!_oNewETRDialog) {
				_oNewETRDialog = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.shopped.NewETRDialog",
					this
				);
			}

			if (_oNewETRDialog) {
				var shop = oContext._oGlobalModel.getProperty("/currentShop");
				var ETRUpdateCodes = oContext.getView().getModel().getProperty("/ETRUpdateCodes");
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setProperty("/Shop", shop);
				oModel.setProperty("/ETRUpdateCodes", ETRUpdateCodes);
				_oNewETRDialog.setModel(oModel);
			}

			oContext.getView().addDependent(_oNewETRDialog);

			_oNewETRDialog.open();

			window.setTimeout(function () {
				var newETRReasonSelect = sap.ui.getCore().byId('newETRReasonSelect');
				newETRReasonSelect.setSelectedItem(null);
				var newETRDateTime = sap.ui.getCore().byId('newETRDateTime');

				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyy-MM-ddTHH:mm:ss"
				});
				var sFormattedCurDate = oDateFormat.format(new Date(oContext._oGlobalModel.getProperty(this.path + "/EtrTs")));
				newETRDateTime.setValue(sFormattedCurDate);
			}.bind(this), 0);
		},

		/**
		 * Set reason dropdown enabled when time is selected
		 */
		onChangeETR: function (oEvent) {
			var newETRReasonSelect = sap.ui.getCore().byId('newETRReasonSelect');
			newETRReasonSelect.setEnabled(true);
		},

		/**
		 * On click of done button in new ETR dialog, call request
		 */
		onNewETRDialogDone: function (oEvent) {
			var oPayload = this.getNewETRPayload();

			LocomotiveDataModel.updateETR(oPayload, this.onNewETRSuccess, this.onNewETRFailure, this);
		},

		/**
		 * ETR has been created, update locomotives
		 */
		onNewETRSuccess: function (oData) {
			var oContext = this.oContext;

			_oNewETRDialog.close();
			
			// KIR0084 Fixing bug where locomotives don't refresh
// 			oContext.refreshShoppedLocomotives();
			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.publish("MyShopMasterPage", "onRefreshMasterList", {});
		},

		/**
		 * ETR has not been created, close dialog
		 */
		onNewETRFailure: function (oData) {
			_oNewETRDialog.close();
		}

	});
});