/*&---------------------------------------------------------------------*    
 * Author         : SAP Custom Development                               *
 * Date           : 2017.12.05                                           *
 * Project        : Locomotive Maintenance                               *
 * Description    : This controller is used by Fleet view. Load          *
 *                  and display locomotives on search.                   *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : KIR0084                                              *
 * Date           : 2019.04.12                                           *
 * Incidinet      : LMP2-28 - Inbound Changes		              	     *
 * Description    : Add new button press handler for confirm inbound     *
 * Search Term    : LMP2-28                                              *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : SHE0272                                              *
 * Date           : 2019.06.04                                           *
 * Incidinet      : LLM2.29 - Road/Yard Repair		              		 *
 * Description    : new button press handler for Road/Yard Repair		 *
 * Search Term    : LLM2.29                                              *
 *&----------------------------------------------------------------------*/

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageBox',
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/controller/common/ArriveManager",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel"
], function (Controller, MessageBox, Constants, Formatter, BusyIndicator, ArriveManager, LocomotiveDataModel) {
	"use strict";

	var _this;

	return Controller.extend("com.sap.cp.lm.controller.fleet.Fleet", {

		//--------------------------------------------------------------------
		// Life cycle functions
		//--------------------------------------------------------------------

		/**
		 * Initializes the controller
		 */
		onInit: function () {
			_this = this;

			$(window).on('resize', $.proxy(this.handleWindowResize, this));

			this._oModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(this._oModel);
			this._oGlobalModel = this.getOwnerComponent().getGlobalModel();

			this._shopId = "";

			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());
			this.oRouter.getTargets().attachDisplay(function (oEvent) {
				if (oEvent.getParameter("name") === "fleet") {
					_this._onFleetRouteMatched();
				}
			});
			this._oGlobalModel.setProperty("/fleetListController", this);

			// register to listen to change events of the globalmodel which contain the currentShop
			var binding = new sap.ui.model.Binding(this._oGlobalModel, "/", this._oGlobalModel.getContext("/"));
			binding.attachChange(function () {
				_this.onGlobalModelChange();
			});

			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.subscribe("ArriveManager", "arriveLocomotiveDone", this.arriveLocomotiveDone, this);
			//Start : Added by KIR0084 : Confirm Inbound: LMP2-28
			oEventBus.subscribe("ArriveManager", "confirmInboundLocomotiveDone", _this.confirmInboundLocomotivesDone, this);
			oEventBus.subscribe("InboundDetails", "cancelInboundLocomotiveDone", _this.confirmInboundLocomotivesDone, this);
			oEventBus.subscribe("FleetDetails", "cancelInboundLocomotiveDone", _this.confirmInboundLocomotivesDone, this);
			//End : Added by KIR0084 : Confirm Inbound: LMP2-28
		},

		//--------------------------------------------------------------------
		// Private functions
		//--------------------------------------------------------------------

		/**
		 * Clean up
		 */
		_resetSearch: function () {
			_this._oModel.setProperty("/Results", null);
			_this.byId("fleetList").setSelectedItem(null);
			_this.byId("fleetSearch").setValue(null);
		},

		/**
		 * Do search vs backend
		 */
		doSearchLocomotivesInFleet: function (sSearchString) {
			if (sSearchString && sSearchString.length > 0) {
				BusyIndicator.showBusyIndicator();
				LocomotiveDataModel.searchLocomotivesInFleet(sSearchString, _this.searchLocomotivesInFleetSuccess, _this.searchLocomotivesInFleetFailure,
					_this);
			} else {
				_this._oModel.setProperty("/Results", null);
				BusyIndicator.hideBusyIndicator();
			}
		},

		searchLocomotivesInFleetSuccess: function (oData) {
			if (oData) {
				_this._oModel.setProperty("/Results", oData);
			}

			this.byId("fleetList").removeSelections();
		},

		searchLocomotivesInFleetFailure: function () {

		},

		/**
		 * Nav to Fleet Work Plan
		 */
		navtoDetails: function () {
			_this._oGlobalModel.setProperty("/fleetDetailsOrigin", "fleet");

			setTimeout(function () {
				_this.oRouter.getTargets().display("fleetDetails");
			}, 200);

			this.byId("fleetList").removeSelections();
		},

		//--------------------------------------------------------------------
		// Event handlers
		//--------------------------------------------------------------------

		_onFleetRouteMatched: function () {},

		/**
		 * Sets height of the shop page
		 */
		handleWindowResize: function () {

		},

		/**
		 * When the global model is changed
		 */
		onGlobalModelChange: function () {

		},

		/**
		 * Handle search input
		 */
		onSearchLocomotivesInFleet: function (oEvent) {
			var sSearchString;

			if (oEvent) {
				if (this._oSearchDelayTimeout) {
					clearTimeout(this._oSearchDelayTimeout);
				}
				sSearchString = oEvent.getParameter("newValue") || oEvent.getParameter("query");
			} else {
				sSearchString = _this.byId("fleetSearch").getValue();
			}

			this._oSearchDelayTimeout = setTimeout(function (oEvt) {
				_this.doSearchLocomotivesInFleet(sSearchString);
			}, 1500);
		},

		/**
		 * Handle locomotive selection
		 */
		onSelectFleetLocomotive: function (oEvent) {
			BusyIndicator.showBusyIndicator();

			var oLocomotive = oEvent.getSource().getSelectedItem().getBindingContext().getObject();
			oLocomotive.isInFleetView = true;

			_this._oGlobalModel.setProperty("/currentLocomotive", oLocomotive);
			_this._oGlobalModel.setProperty("/fleetSelectedLocomotive", oLocomotive);
			_this.navtoDetails();
		},

		/**
		 * Start arrive locomotive process from service
		 */
		onFleetService: function (oEvent) {
			_this.oLocomotive = oEvent.getSource().getParent().getBindingContext().getObject();

			if (_this.oLocomotive) {
				LocomotiveDataModel.fetchLocomotiveDefects(_this.oLocomotive, _this._onFetchLocomotiveDefectsSuccessForService, _this._onFetchLocomotiveDefectsFailed,
					_this);
			}
		},

		/**
		 * Start LLM2.29 - Road/Yard Repair - Called on clicking RYR Button	
		 */
		onFleetRYR: function (oEvent) {
			_this.oLocomotive = oEvent.getSource().getParent().getBindingContext().getObject();
			if (_this.oLocomotive) {
				LocomotiveDataModel.fetchLocomotiveDefects(_this.oLocomotive, _this._onFetchLocomotiveDefectsSuccessForRYR, _this._onFetchLocomotiveDefectsFailed,
					_this, true);
			}
		},

		/* Start LMP2-28: Confirm Inbound - Add onFleetConfirmInbound Handler and refactor onFleetArrive for code re-use */
		/**
		 * Start arrive locomotive process from anywhere to shop
		 */
		onFleetArrive: function (oEvent) {
			_this.oLocomotive = oEvent.getSource().getParent().getBindingContext().getObject();

			if (_this.oLocomotive) {
				LocomotiveDataModel.fetchLocomotiveDefects(_this.oLocomotive, _this._onFetchLocomotiveDefectsSuccessForArrive, _this._onFetchLocomotiveDefectsFailed,
					_this);
			}
		},

		/**
		 * Start confirm inbound locomotive process from anywhere to shop
		 */
		onFleetConfirmInbound: function (oEvent) {
			_this.oLocomotive = oEvent.getSource().getParent().getBindingContext().getObject();

			if (_this.oLocomotive) {
				LocomotiveDataModel.fetchLocomotiveDefects(_this.oLocomotive, _this._onFetchLocomotiveDefectsSuccessForConfirmInbound, _this._onFetchLocomotiveDefectsFailed,
					_this);
			}
		},

		/**
		 * Start change inbound locomotive process from anywhere to shop
		 */
		onFleetChangeInbound: function (oEvent) {
			_this.oLocomotive = oEvent.getSource().getParent().getBindingContext().getObject();

			if (_this.oLocomotive) {
				LocomotiveDataModel.fetchLocomotiveDefects(_this.oLocomotive, _this._onFetchLocomotiveDefectsSuccessForChangeInbound, _this._onFetchLocomotiveDefectsFailed,
					_this);
			}
		},

		/**
		 * Instantiate an arrival dialog manager for the type of action passed in as a parameter
		 */
		_onFetchLocomotiveDefectsSuccess: function (oData, type) {
			BusyIndicator.hideBusyIndicator();
			var results = oData.results;

			if (!_this.oArriveManager) {
				_this.oArriveManager = ArriveManager.init("fleet", type);
			}

			_this.oArriveManager.setType(type);
			_this.oArriveManager.onArriveProcessDialogOpen(results, null, _this.oLocomotive, _this);
		},

		/**
		 * Success callback function for onFleetService
		 */
		_onFetchLocomotiveDefectsSuccessForService: function (oData) {
			this._onFetchLocomotiveDefectsSuccess(oData, "service");
		},

		/**
		 * Success callback function for onFleetRYR
		 */
		_onFetchLocomotiveDefectsSuccessForRYR: function (oData) {
			this._onFetchLocomotiveDefectsSuccess(oData, "roadYardRepair");
		},

		/**
		 * Success callback function for onFleetArrive
		 */
		_onFetchLocomotiveDefectsSuccessForArrive: function (oData) {
			this._onFetchLocomotiveDefectsSuccess(oData, "shopped");
		},

		/**
		 * Success callback function for onFleetConfirmInbound
		 */
		_onFetchLocomotiveDefectsSuccessForConfirmInbound: function (oData) {
			this._onFetchLocomotiveDefectsSuccess(oData, "confirmInbound");
		},

		/**
		 * Success callback function for onFleetChangeInbound
		 */
		_onFetchLocomotiveDefectsSuccessForChangeInbound: function (oData) {
			this._onFetchLocomotiveDefectsSuccess(oData, "changeInbound");
		},
		/* End LMP2-28: Confirm Inbound - Add onFleetConfirmInbound Handler and refactor onFleetArrive for code re-use */

		/* Start LMP2-28: Confirm Inbound - Add onFleetCancelInbound Handler */
		/**
		 * Cancel the inbound action for a plant
		 */
		onFleetCancelInbound: function (oEvent) {
			_this.oLocomotive = oEvent.getSource().getParent().getBindingContext().getObject();

			if (_this.oLocomotive) {
				MessageBox.show("Are you sure you want to cancel the Inbound Confirmation?", {
					icon: MessageBox.Icon.CONFIRM,
					title: "Cancel Inbound Confirmation",
					actions: [MessageBox.Action.CANCEL, MessageBox.Action.OK],
					onClose: function (oEvent) {
						if (oEvent === MessageBox.Action.OK) {
							LocomotiveDataModel.cancelInboundConfirmation({
								LocoId: _this.oLocomotive.LocomotiveId,
								ShopId: _this.oLocomotive.InboundShop
							}, function (oEvent) {
								var oEventBus = sap.ui.getCore().getEventBus();
								oEventBus.publish("Fleet", "cancelInboundLocomotiveDone", {
									"origin": _this.origin,
									"locomotive": _this.oLocomotive,
									"success": true
								});

								_this.confirmInboundLocomotivesDone(oEvent, "cancelInboundLocomotiveDone", {
									locomotive: _this.oLocomotive
								});
							}, _this._onFetchLocomotiveDefectsFailed, _this);
						}
					}.bind(this)
				});
			}
		},
		/* End LMP2-28: Confirm Inbound - Add onFleetCancelInbound Handler */

		_onFetchLocomotiveDefectsFailed: function () {
			BusyIndicator.hideBusyIndicator();

		},

		arriveLocomotiveDone: function (sChannel, oEvent, oData) {
			_this.onSearchLocomotivesInFleet();
		},

		//Start : Added by KIR0084 : Confirm Inbound: LMP2-28
		/**
		 * refresh data after confirm inbound
		 */
		confirmInboundLocomotivesDone: function (sChannel, oEvent, oData) {
			// Check that the locomotive in the event is in the master list
			var fleetListItems = _this._oModel.getProperty("/Results");

			var eventObjectInList = fleetListItems && fleetListItems.filter(function (listLoco) {
				return oData.locomotive.LocomotiveId === listLoco.LocomotiveId;
			}).length > 0;

			if (eventObjectInList) {
				_this.onSearchLocomotivesInFleet();
			}
		},
		//End : Added by KIR0084 : Confirm Inbound: LMP2-28
		
	});

});