/*&---------------------------------------------------------------------*    
 * Author         : SAP Custom Development                               *
 * Date           : 2017.12.06                                           *
 * Project        : Locomotive Maintenance                               *
 * Description    : This is the controller of the view that display      *
 *                  locomotive details when you select a locomotive on   *
 *                  Fleet list.                                          *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : KIR0084                                              *
 * Date           : 2019.04.12                                           *
 * Incidinet      : LMP2-28 - Inbound Changes		              	     *
 * Description    : Add new button press handler for confirm inbound     *
 * Search Term    : LMP2-28                                              *
 *&----------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
* Author/Changed By   : SAT0008				        		       		  *
* Date                : 8-May-2019                                     *
* Project             : Locomotive Maintenance Phase 2                    *
* Description         : LMP2-03 : Work order History and Notification History *
* Search Term		  : LMP2-03                                            *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : KOU0012				        		       		   *
* Date                : 1-June-2020                                        *
* Project             : Locomotive Maintenance Phase 2                     *
* Description         : Added logic to navigate to fleet details if        *
*                       URL parameter is supplied                          *
* Search Term         : MOD001                                             *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 08-Sep-2021	                                       *
* Project             : Locomotive Maintenance Phase 2                     *
* Description         : Refresh issue with cross navigation		           *
* Search Term         : INC0110700                                         *
/*&------------------------------------------------------------------------*/
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageBox',
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
	"com/sap/cp/lm/controller/common/ArriveManager",
	"com/sap/cp/lm/controller/fleet/FleetLocomotiveHeaderManager"
], function (Controller, MessageBox, Constants, Formatter, BusyIndicator, LocomotiveDataModel, ArriveManager, LocomotiveHeaderManager) {
	"use strict";

	var _this;

	return Controller.extend("com.sap.cp.lm.controller.fleet.FleetDetails", {

		//--------------------------------------------------------------------
		// Life cycle functions
		//--------------------------------------------------------------------

		/**
		 * Initializes the controller
		 */
		onInit: function () {
			_this = this;

			$(window).on('resize', $.proxy(this.handleWindowResize, this));

			this._oModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(this._oModel);
			this._oGlobalModel = this.getOwnerComponent().getGlobalModel();

			this._oGlobalModel.setProperty("/fleetDetailsController", this);

			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());
			this.oRouter.getTargets().attachDisplay(function (oEvent) {
				var parameterName = oEvent.getParameter("name");

				if (parameterName === "fleetDetails") {
					_this._onFleetDetailsRouteMatched();
				}
			});

			// register to listen to change events of the globalmodel which contain the currentShop
			var binding = new sap.ui.model.Binding(this._oGlobalModel, "/", this._oGlobalModel.getContext("/"));
			binding.attachChange(function () {
				_this.onGlobalModelChange();
			});

			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.subscribe("ArriveManager", "arriveLocomotiveDone", _this.arriveLocomotiveDone, this);
			//Start : Added by KIR0084 : Confirm Inbound: LMP2-28
			oEventBus.subscribe("ArriveManager", "confirmInboundLocomotiveDone", _this.confirmInboundLocomotivesDone, this);
			//End : Added by KIR0084 : Confirm Inbound: LMP2-28

			this.initLocomotiveHeader();
		},

		//--------------------------------------------------------------------
		// Private functions
		//--------------------------------------------------------------------

		/**
		 * Get the whole data about the current locomotive
		 */
		fetchLocomotiveDetails: function () {
			BusyIndicator.showBusyIndicator(); // SHE0272 - INC0110700 - Adding Busy Indicator on data fetch 
			var oLocomotive = _this._oGlobalModel.getProperty("/fleetSelectedLocomotive");

			if (Formatter.setVisibilityForFleetShoppedFields(oLocomotive.ShopId, oLocomotive.ShopStatus)) {
				_this.getView().byId("fleetIconTabBar").setSelectedKey("workPlan");
			} else {
				_this.getView().byId("fleetIconTabBar").setSelectedKey("defects");
			}

			_this._processSelectedTab(_this.getView().byId("fleetIconTabBar").getSelectedKey());

			_this.sLocomotiveId = oLocomotive.LocomotiveId;

			var sEquipNo = oLocomotive.Equipment;
			if (!sEquipNo) {
				sEquipNo = oLocomotive.EquipNo;
			}

			_this.sEquipment = sEquipNo;

			_this.getView().getModel().setProperty("/detailsData/LocomotiveNumber", _this.sLocomotiveId);

			_this.getView().byId("locoWheelSheet").getController().fetchLocomotiveWheelSheetHistory();
			_this.getView().byId("shoppedLocoDetails").getController().fetchLocomotiveDetails();
			_this.getView().byId("locoDefects").getController().fetchLocomotiveDefects();

			LocomotiveDataModel.fetchLocomotiveDetails(_this.loadData, _this.onloadDataError, this, this.sLocomotiveId, this.sEquipment);
			// begin of MOD001
			// _this.LocoId = _this._oGlobalModel.getProperty("/LocoId");
			// if (_this.LocoId) {
			// BusyIndicator.showBusyIndicator();
			// _this.getView().byId("fleetIconTabBar").setSelectedKey("details");
			// _this._processSelectedTab("details");
			// this._oGlobalModel.setProperty("/LocoId", "");
			// BusyIndicator.hideBusyIndicator();
			// }
			// end of MOD001
		},

		/**
		 * Success callback for fetchLocomotiveDetails ,Sets model in View
		 * Loads data for the selected locomotive
		 * @params{object} oModel returned for the new selected Locomotive
		 */
		loadData: function (oModel, oContext, sLocomotiveId, sEquipment) {

			//ask workplan tab to reload
			var oParameters = {
				iconTabBar: this.getView().byId("fleetIconTabBar"),
				bindPath: "/detailsData/results",
				model: oModel,
				parentView: Constants.LOCOMOTIVES,
				locomotiveNumber: sLocomotiveId,
				equipmentNo: sEquipment,
				Description: oModel.getData().detailsData.Description,
				shiftlist: true
			};

			this.byId("locoWorkPlan").getController().loadData(oParameters);

			_this._oGlobalModel.refresh(true);

			_this.initLocomotiveHeader();

			BusyIndicator.hideBusyIndicator();
		},

		/* Start Added by Sandesh Defect 173 */
		addContentIconTabFilter: function (sIdFilter, sView) {

			var oView = this.getOwnerComponent().runAsOwner(function () {
				return sap.ui.view({
					viewName: sView,
					type: sap.ui.core.mvc.ViewType.XML
				});
			});

			oView.setModel(_this._oI18nModel, "i18n");

			this.byId(sIdFilter).destroyContent();
			this.byId(sIdFilter).addContent(oView);

			return oView.getController();
		},
		/* End Added by Sandesh Defect 173 */
		_processSelectedTab: function (sKey) {
			if (sKey === "workPlan") {
				BusyIndicator.showBusyIndicator();  // SHE0272 - INC0110700 - Adding Busy Indicator on data fetch 
				this._oGlobalModel.setProperty("/workplanFooterIsVisible", true);
				this._oGlobalModel.setProperty("/readOnlyWorkPlan", false);
				this._oGlobalModel.setProperty("/readFromWorkPlan", true); //Added by Sandhya LMP2-3
				this._oGlobalModel.setProperty("/readFromWOHistory", false); //Added by Sandhya LMP2-3
				this._oGlobalModel.setProperty("/detailsData", []);  // SHE0272 - INC0110700 - Setting the data to empty array to refresh the UI
				LocomotiveDataModel.fetchLocomotiveDetails(_this.loadData, _this.onloadDataError, this, this.sLocomotiveId, this.sEquipment);  // SHE0272 - INC0110700 - Added Service Call
			} else if (sKey === "defects") {
				this.byId("locoDefects").getController().fetchLocomotiveDefects();
			} else if (sKey === "wheelSheet") {
				this.byId("locoWheelSheet").getController().fetchLocomotiveWheelSheetHistory();
			} else if (sKey === "history") {
				this._oGlobalModel.setProperty("/workplanFooterIsVisible", false);
				this._oGlobalModel.setProperty("/readOnlyWorkPlan", true);
				this._oGlobalModel.setProperty("/readFromWorkPlan", false); //Added by Sandhya LMP2-3
				this._oGlobalModel.setProperty("/readFromWOHistory", true); //Added by Sandhya LMP2-3
				this._oGlobalModel.setProperty("/detailsData", []);  // SHE0272 - INC0110700 - Setting the data to empty array to refresh the UI
				this.byId("WOHistory").getController().fetchWOHistory();

			} //Start- Added by Sandesh Defect - 173
			else if (sKey === "notifhistory") {
				this._oGlobalModel.setProperty("/workplanFooterIsVisible", false);
				this._oGlobalModel.setProperty("/readOnlyWorkPlan", true);
				this._oGlobalModel.setProperty("/readFromWOHistory", true); //Added by Sandhya LMP2-3
				this._oGlobalModel.setProperty("/readFromWorkPlan", false); //Added by Sandhya LMP2-3
				this._oGlobalModel.setProperty("/readFromNotifHistory", true); //Added by Sandhya LMP2-3
				this.addContentIconTabFilter("idFilterNotifHistory", "com.sap.cp.lm.view.common.NotificationHistory.NotificationHistory").fetchNotifHistory();

				//End- Added by Sandesh Defect - 173
			} else if (sKey === "details") {
				_this.getView().byId("shoppedLocoDetails").getController().fetchLocomotiveDetails();
			}
		},

		/**
		 * Init toolbar header fragment and manager
		 */
		initLocomotiveHeader: function () {
			if (_this._oLocomotiveHeaderManager) {
				_this._oLocomotiveHeaderManager.destroy();
			}
			_this._oLocomotiveHeaderManager = new LocomotiveHeaderManager();
			_this._oLocomotiveHeaderManager = _this._oLocomotiveHeaderManager.init(_this, "/fleetSelectedLocomotive");

			if (_this._oLocomotiveHeaderFragment) {
				_this._oLocomotiveHeaderFragment.destroy();
			}
			_this._oLocomotiveHeaderFragment = _this._oLocomotiveHeaderManager.getFragment();
			_this.byId("MyShopToolbar").addContent(_this._oLocomotiveHeaderFragment);
		},

		//--------------------------------------------------------------------
		// Event handlers
		//--------------------------------------------------------------------

		_onFleetDetailsRouteMatched: function () {
			this._oGlobalModel.setProperty("/workplanFooterIsVisible", null);
			this._oGlobalModel.setProperty("/readOnlyWorkPlan", null);
			this._oGlobalModel.setProperty("/readFromWorkPlan", true); //Added by Sandhya LMP2-3
			this._oGlobalModel.setProperty("/readFromWOHistory", false); //Added by Sandhya LMP2-3
			_this.fetchLocomotiveDetails();
		},

		arriveLocomotiveDone: function (sChannel, oEvent, oData) {
			_this.fetchLocomotiveDetails();
		},

		//Start : Added by KIR0084 : Confirm Inbound: LMP2-28
		/**
		 * refresh data after confirm inbound
		 */
		confirmInboundLocomotivesDone: function (sChannel, oEvent, oData) {
			_this.fetchLocomotiveDetails();
		},
		//End : Added by KIR0084 : Confirm Inbound: LMP2-28

		/**
		 * Sets height of the shop page
		 */
		handleWindowResize: function () {

		},

		/**
		 * When the global model is changed
		 */
		onGlobalModelChange: function () {},

		onloadDataError: function () {
			BusyIndicator.hideBusyIndicator();  // SHE0272 - INC0110700 - Adding Busy Indicator on data fetch
		},

		/**
		 * Handles selection of Icon Tab Bar
		 * @params(event) oEvent is returned on icon tab bar selection changes
		 */
		onFleetIconSelect: function (oEvent) {
			var sKey = oEvent.getParameters().key;
			this._processSelectedTab(sKey);
		},

		/**
		 * Navigation
		 */
		onBack: function (oEvent) {
			var origin = _this._oGlobalModel.getProperty("/fleetDetailsOrigin");

			if (origin === "fleet") {
				_this.oRouter.getTargets().display("fleet");
			} else if (origin === "servicingGroupWorkPlan") {
				_this._oGlobalModel.setProperty("/fleetSelectedLocomotive", null);
				setTimeout(function () {
					_this.oRouter.getTargets().display("locomotivesServicingHome");
				}, 200);
			}
		},

		/**
		 * Start arrive locomotive process from service
		 */
		onFleetDetailsService: function (oEvent) {
			_this.oLocomotive = _this._oGlobalModel.getProperty("/fleetSelectedLocomotive");

			if (_this.oLocomotive) {
				LocomotiveDataModel.fetchLocomotiveDefects(_this.oLocomotive, _this._onFetchLocomotiveDefectsSuccessForService, _this._onFetchLocomotiveDefectsFailed,
					_this);
			}
		},

		/* Start LMP2-28: Confirm Inbound - Add onFleetConfirmInbound Handler and refactor onFleetArrive for code re-use */
		/**
		 * Start arrive locomotive process from anywhere to shop
		 */
		onFleetDetailsArrive: function (oEvent) {
			_this.oLocomotive = _this._oGlobalModel.getProperty("/fleetSelectedLocomotive");

			if (_this.oLocomotive) {
				LocomotiveDataModel.fetchLocomotiveDefects(_this.oLocomotive, _this._onFetchLocomotiveDefectsSuccessForArrive, _this._onFetchLocomotiveDefectsFailed,
					_this);
			}
		},

		/**
		 * Start confirm inbound locomotive process from anywhere to shop
		 */
		onFleetDetailsConfirmInbound: function (oEvent) {
			_this.oLocomotive = _this._oGlobalModel.getProperty("/fleetSelectedLocomotive");

			if (_this.oLocomotive) {
				LocomotiveDataModel.fetchLocomotiveDefects(_this.oLocomotive, _this._onFetchLocomotiveDefectsSuccessForConfirmInbound, _this._onFetchLocomotiveDefectsFailed,
					_this);
			}
		},

		/**
		 * Start confirm inbound locomotive process from anywhere to shop
		 */
		onFleetDetailsChangeInbound: function (oEvent) {
			_this.oLocomotive = _this._oGlobalModel.getProperty("/fleetSelectedLocomotive");

			if (_this.oLocomotive) {
				LocomotiveDataModel.fetchLocomotiveDefects(_this.oLocomotive, _this._onFetchLocomotiveDefectsSuccessForChangeInbound, _this._onFetchLocomotiveDefectsFailed,
					_this);
			}
		},

		/**
		 * Instantiate an arrival dialog manager for the type of action passed in as a parameter
		 */
		_onFetchLocomotiveDefectsSuccess: function (oData, type) {
			BusyIndicator.hideBusyIndicator();
			var results = oData.results;

			if (!_this.oArriveManager) {
				_this.oArriveManager = ArriveManager.init("fleetDetails", type);
			}

			_this.oArriveManager.setType(type);
			_this.oArriveManager.onArriveProcessDialogOpen(results, null, _this.oLocomotive, _this);
		},

		/**
		 * Success callback function for onFleetService
		 */
		_onFetchLocomotiveDefectsSuccessForService: function (oData) {
			this._onFetchLocomotiveDefectsSuccess(oData, "service");
		},

		/**
		 * Success callback function for onFleetArrive
		 */
		_onFetchLocomotiveDefectsSuccessForArrive: function (oData) {
			this._onFetchLocomotiveDefectsSuccess(oData, "shopped");
		},

		/**
		 * Success callback function for onFleetConfirmInbound
		 */
		_onFetchLocomotiveDefectsSuccessForConfirmInbound: function (oData) {
			this._onFetchLocomotiveDefectsSuccess(oData, "confirmInbound");
		},

		/**
		 * Success callback function for onFleetChangeInbound
		 */
		_onFetchLocomotiveDefectsSuccessForChangeInbound: function (oData) {
			this._onFetchLocomotiveDefectsSuccess(oData, "changeInbound");
		},
		/* End LMP2-28: Confirm Inbound - Add onFleetConfirmInbound Handler and refactor onFleetArrive for code re-use */

		/* Start LMP2-28: Confirm Inbound - Add onFleetCancelInbound Handler */
		/**
		 * Cancel the inbound action for a plant
		 */
		onFleetDetailsCancelInbound: function (oEvent) {
			_this.oLocomotive = _this._oGlobalModel.getProperty("/fleetSelectedLocomotive");

			if (_this.oLocomotive) {
				MessageBox.show("Are you sure you want to cancel the Inbound Confirmation?", {
					icon: MessageBox.Icon.CONFIRM,
					title: "Cancel Inbound Confirmation",
					actions: [MessageBox.Action.CANCEL, MessageBox.Action.OK],
					onClose: function (oEvent) {
						if (oEvent === MessageBox.Action.OK) {
							LocomotiveDataModel.cancelInboundConfirmation({
								LocoId: _this.oLocomotive.LocomotiveId,
								ShopId: _this.oLocomotive.InboundShop
							}, function (oEvent) {
								var oEventBus = sap.ui.getCore().getEventBus();
								oEventBus.publish("FleetDetails", "cancelInboundLocomotiveDone", {
									"origin": _this.origin,
									"locomotive": _this.oLocomotive,
									"success": true
								});

								_this.confirmInboundLocomotivesDone(oEvent, "cancelInboundLocomotiveDone", {
									locomotive: _this.oLocomotive
								});
							}, _this._onFetchLocomotiveDefectsFailed, _this);
						}
					}.bind(this)
				});
			}
		},
		/* End LMP2-28: Confirm Inbound - Add onFleetCancelInbound Handler */

		_onFetchLocomotiveDefectsFailed: function () {
			BusyIndicator.hideBusyIndicator();
		}

	});

});