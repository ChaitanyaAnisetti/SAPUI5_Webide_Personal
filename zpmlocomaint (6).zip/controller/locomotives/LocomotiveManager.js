/*&----------------------------------------------------------------------*    
* Author/Changed By   : Sandhya satavalekar                              *
* Date                : 7-July-2019                                      *
* Project             : Locomotive Maintenance Phase 2                   *
* Description         : LMP2-4 : Operation should not be added for craft
*                         with est time more than an hour 	             *
* Search Term         : LMP2-04                                          *
*&-----------------------------------------------------------------------*/ 
/*&----------------------------------------------------------------------*    
* Author/Changed By   : Sandhya satavalekar                              *
* Date                : 01-Sept-2019                                     *
* Project             : Locomotive Maintenance Phase 2                   *
* Description         : LMP2-35 Added Work Order Crafts popup
* Search Term         : LMP2-35                                          *
*&-----------------------------------------------------------------------*/ 
/*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 08-Sep-2021	                                       *
* Project             : Locomotive Maintenance Phase 2                     *
* Description         : Refresh issue with cross navigation		           *
* Search Term         : INC0110700                                         *
/*&------------------------------------------------------------------------*/

jQuery.sap.declare("com.sap.cp.lm.controller.locomotives.LocomotiveManager");
sap.ui.define([
		"com/sap/cp/lm/util/Constants",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
		"com/sap/cp/lm/util/ErrorManager",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/controller/myShop/common/CraftWorkPlan"
	],
	function(Constants, LocomotiveDataModel, ErrorManager, BusyIndicator,
		CraftWorkPlan) {
		"use strict";
		var _this;
		return com.sap.cp.lm.controller.locomotives.LocomotiveManager = {

			//--------------------------------------------------------------------
			// Life cycle functions
			//--------------------------------------------------------------------

			/**
			 * Initialize of LocomotiveManager class
			 */
			init: function(globalModel, globalLocomotiveModel, oMainModel, oWOStatusModel, oI18nModel) {
				_this = this;
				this._oGlobalModel = globalModel;
				this._oGlobalLocomotiveModel = globalLocomotiveModel;
				this._oMainModel = oMainModel;
				this._oWOStatusModel = oWOStatusModel;
				this.isGroup = false;
				this.oEventBus = sap.ui.getCore().getEventBus();
				this._IsMainAssignmentHashMapCreated = false;
				this._oI18nModel = oI18nModel;
			},

			//--------------------------------------------------------------------
			// Private functions
			//--------------------------------------------------------------------

			/**
			 * Open action sheet when drop down list button is clicked in workorder panel
			 * @params(oEvent) oEvent is when drop down list is clicked in workorderpanel
			 * @params(context) oContext is the context of the view
			 * @params(string) oView is from where the call is made
			 */
			openActionSheet: function(oEvent, oView, oContext) {
				var oButton = oEvent.getSource();
				// create action sheet only once
				this._actionSheet = sap.ui.xmlfragment("com.sap.cp.lm.view.myShop.common.workplan.WOActionSheet", oContext);

				this.aOperationList = oButton.getBindingContext("global");// SHE0272 - INC0110700 - changed from local to global model
				this.locoMotiveNum = oButton.getCustomData()[1].getValue();
				var oModel = oView.getModel("global");// SHE0272 - INC0110700 - changed from local to global model
				this._actionSheet.setModel(oModel).setBindingContext(this.aOperationList);
				oContext.getView().addDependent(this._actionSheet);
				if ($("#" + oEvent.getSource().sId).offset().top + 280 < window.innerHeight) {
					this._actionSheet.setPlacement("Bottom");
				} else {
					this._actionSheet.setPlacement("Vertical");
				}
				if (!this._actionSheet.isOpen()) {
					this._actionSheet.openBy(oButton);
				}
			},

			// #DontDelete : Daya 
			updateWmat: function(successCallBack, oContext, oWorkOrderNumber, oWOStatus, oWOUndo) {
				LocomotiveDataModel.updateWOWmatStatus(successCallBack, oContext, oWorkOrderNumber, oWOStatus, oWOUndo);
			},

			// #DontDelete : Daya 
			_afterOperationCreatesucess: function(oEvent) {
				this.oLocoAddOperationDialog.destroy(true);
				this.oLocoAddOperationDialog = null;
				this.oView.getController().fetchAndRefreshView();
			},

			// #DontDelete : Q 
			_afterOperationUpdateSucess: function(oEvent) {
				this.oLocoEditOperationEstTimeDialog.destroy(true);
				
				this.oLocoEditOperationEstTimeDialog = null;
				if (this.oView.getController().fetchAndRefreshView) {
					this.oView.getController().fetchAndRefreshView();
				} else if (this.oView.oCraftManager) {
					this.oView.oCraftManager.reloadWorkOrders();
				}
			},

			//--------------------------------------------------------------------
			// Event handlers
			//--------------------------------------------------------------------

			// #DontDelete : Daya 
			/**
			 * Open WMAT DIALOG fragment when "SET WMAT" is selmected in action sheet in drop down list in workorder panel
			 * @params(oEvent) oEvent is event for click on WMAT Work Order
			 */
			onClickWMAT: function(oEvent, oController) {
				var oContext = this._actionSheet.getParent().getParent().getController();
				var oView = oContext.byId("idWorkOrderList");
				if (!this.oWMATWork) {
					this.oWMATWork = sap.ui.xmlfragment("idWMATDialog",
						"com.sap.cp.lm.view.common.ConfirmationDialog", oController);
				}
				this.sConfirmation = oContext.getOwnerComponent().getText("LHFM_WORK");
				var sWMATStatus = oView.getModel().getProperty(this.aOperationList.sPath + "/Wmat");
				var sLocomotiveDescription = this.locoMotiveNum;
				var sWMATStatusTitle;
				var sWODFMsg;
				if (sWMATStatus) {
					sWMATStatusTitle = oContext.getOwnerComponent().getText("UNDO_WMAT_WORK");
					sWODFMsg = oContext.getOwnerComponent().getText("CONFIRMATION_MESSAGE_UNDO_WMAT_WORK", [sLocomotiveDescription]);
				} else {
					sWMATStatusTitle = oContext.getOwnerComponent().getText("WMAT_WORK");
					sWODFMsg = sLocomotiveDescription + " " + oContext.getOwnerComponent().getText("CONFIRMATION_MESSAGE_WMAT_WORK2");
				}
				this.oWMATWork.setTitle(sWMATStatusTitle);
				this.oWMATWork.setModel(oView.getModel()).setBindingContext(this.aOperationList);
				var sDialogContent = sap.ui.core.Fragment.byId("idWMATDialog", "idCDContent");
				sDialogContent.setText(sWODFMsg);
				oContext.getView().addDependent(this.oWMATWork);
				this.oWMATWork.open();
			},
			
			// #DontDelete : Daya 
			/**
			 * Cancel button handler for Dialogs
			 */
			onClickCancel: function() {
				if (this.oUndoDeferWork) {
					this.oUndoDeferWork.close();
				}
				if (this.oDeferWork) {
					this.oDeferWork.close();
				}
				if (this.oCompleteWork) {
					this.oCompleteWork.close();
				}
				if (this.oRegulatory) {
					this.oRegulatory.close();
				}
				if (this.oWMATWork) {
					this.oWMATWork.close();
				}
				if (this.oUpdateRevisionTypeDialog) {
					this.oUpdateRevisionTypeDialog.close();
				}
				if (this.oUndoArrive) {
					this.oUndoArrive.close();
				}
			},

			// #DontDelete : Daya 
			/**
			 * Creates the dialog for Worker List in Shop list
			 * @params {event} 	oEvt is the listener for the event causing the opening of worker list in shop list screen
			 * @params {view} 	oView is the view for creating a worker list dialog
			 * @params {model} 	oModel is the model of the view to be set
			 * @params {model} 	oOperationWONumer is the Operation Model 
			 * @params {string} sBindingPath is the binding path
			 */
			onClickWorkerList: function(oEvt, oView, oModel, oOperationWONumer, sBindingPath) {
				this._IsMainAssignmentHashMapCreated = false;
				var oOWOModel = new sap.ui.model.json.JSONModel(oOperationWONumer);
				if (this.workerPopover) {
					this.workerPopover.destroy(true);
				}
				this.workerPopover = sap.ui.xmlfragment("com.sap.cp.lm.view.common.WorkerList", this);
				oView.addDependent(this.workerPopover);

				var sRole = this._oGlobalModel.getData().role;
				var sRoleModel = new sap.ui.model.json.JSONModel();
				sRoleModel.setProperty("/SelectedRole", sRole);
				this.workerPopover.setModel(sRoleModel, "Role");
				this.workerPopover.setModel(oOWOModel, "oOperationNoWorkNumberModel");
				var sOrderNo = oEvt.getSource().getCustomData()[0].getProperty("value");
				var sActivity = oEvt.getSource().getCustomData()[1].getProperty("value");
				var sOpNode = oEvt.getSource().getCustomData()[2].getProperty("value");
				var sRoutingNo = oEvt.getSource().getCustomData()[3].getProperty("value");
				var sPlanWorkDur = oEvt.getSource().getCustomData()[4].getProperty("value");
				var sPlanWorkUom = oEvt.getSource().getCustomData()[5].getProperty("value");
				var sPlanStartTs = oEvt.getSource().getCustomData()[6].getProperty("value");
				var sPlanStartTz = oEvt.getSource().getCustomData()[7].getProperty("value");
				var oSelectedOperation = new sap.ui.model.json.JSONModel({
					"OrderNo": sOrderNo,
					"Activity": sActivity,
					"OpNode": sOpNode,
					"RoutingNo": sRoutingNo,
					"PlanWorkDur": sPlanWorkDur,
					"PlanWorkUom": sPlanWorkUom,
					"oSourceViewController": oView,
					"PlanStartTs": sPlanStartTs,
					"PlanStartTz": sPlanStartTz,
					"shopId": this._oGlobalModel.getProperty("/currentShop").Id
				});
				this.workerPopover.setModel(oSelectedOperation, "selectedOperation");

				this.workerPopover.setModel(oModel);
				this.workerPopover.bindElement(sBindingPath);

				this.workerPopover.openBy(oEvt.getSource());
				this.workerPopover.setModel(this._oGlobalModel, "globalModel");
			},

			// START LMP2-35 KIR0084
			/**
			 * Creates the dialog for Worker List in Shop list
			 * @params {event} 	oEvt is the listener for the event causing the opening of worker list in shop list screen
			 * @params {view} 	oView is the view for creating a worker list dialog
			 * @params {model} 	oModel is the model of the view to be set
			 * @params {model} 	oOperationWONumer is the Operation Model 
			 * @params {string} sBindingPath is the binding path
			 */
			onClickWorkOrderWorkerList: function(oEvt, oView, oModel, oOperationWONumer, sBindingPath) {
				this._IsMainAssignmentHashMapCreated = false;
				var oOWOModel = new sap.ui.model.json.JSONModel(oOperationWONumer);
				if (this.workerPopover) {
					this.workerPopover.destroy(true);
				}
				this.workerPopover = sap.ui.xmlfragment("com.sap.cp.lm.view.common.WorkOrderWorkerList", this);
				oView.addDependent(this.workerPopover);

				var sRole = this._oGlobalModel.getData().role;
				var sRoleModel = new sap.ui.model.json.JSONModel();
				sRoleModel.setProperty("/SelectedRole", sRole);
				this.workerPopover.setModel(sRoleModel, "Role");
				this.workerPopover.setModel(oOWOModel, "oOperationNoWorkNumberModel");
				var sOrderNo = oEvt.getSource().getCustomData()[0].getProperty("value");
				var sActivity = oEvt.getSource().getCustomData()[1].getProperty("value");
				var sOpNode = oEvt.getSource().getCustomData()[2].getProperty("value");
				var sRoutingNo = oEvt.getSource().getCustomData()[3].getProperty("value");
				var sPlanWorkDur = oEvt.getSource().getCustomData()[4].getProperty("value");
				var sPlanWorkUom = oEvt.getSource().getCustomData()[5].getProperty("value");
				var sPlanStartTs = oEvt.getSource().getCustomData()[6].getProperty("value");
				var sPlanStartTz = oEvt.getSource().getCustomData()[7].getProperty("value");
				
				var concatAssignmentList = [];
				oView.getModel("global").getProperty(sBindingPath).OperationSet.results.map(function(operation){ // SHE0272 - INC0110700 - changed from local to global model
			        concatAssignmentList = concatAssignmentList.concat(operation.AssignmentSet.results);
			    });
			    var assignmentList = [];
			    
			    // Prevent duplicates Pernrs from being added;
			    var assignmentPernr = [];
			    concatAssignmentList.forEach(function(assignment) {
			        if ($.inArray(assignment.PersonNo, assignmentPernr) === -1) {
			            assignmentPernr.push(assignment.PersonNo);
			            assignmentList.push(assignment);
			        }
			    });
				
				var oSelectedOperation = new sap.ui.model.json.JSONModel({
					"OrderNo": sOrderNo,
					"Activity": sActivity,
					"OpNode": sOpNode,
					"RoutingNo": sRoutingNo,
					"PlanWorkDur": sPlanWorkDur,
					"PlanWorkUom": sPlanWorkUom,
					"oSourceViewController": oView,
					"PlanStartTs": sPlanStartTs,
					"PlanStartTz": sPlanStartTz,
					"AssignmentSet": assignmentList,
					"shopId": this._oGlobalModel.getProperty("/currentShop").Id
				});
				this.workerPopover.setModel(oSelectedOperation, "selectedOperation");

				this.workerPopover.setModel(oModel);
				this.workerPopover.bindElement(sBindingPath);

				this.workerPopover.openBy(oEvt.getSource());
				this.workerPopover.setModel(this._oGlobalModel, "globalModel");
			},
			
			onClickDeleteAssignmentFromWorkOrder : function(oEvent) {
            
				var aData = oEvent.getSource().getBindingContext("selectedOperation").getObject();
				var sPersNumber = oEvent.getSource().getCustomData()[0].getProperty("value");
				var sRecord = "/AssignmentSet(RoutingNo='" + aData.RoutingNo + "',OpNode='" + aData.OpNode + "',PersonNo='" + sPersNumber + "')";
				LocomotiveDataModel.DeleteAssignmentFromOperation(sRecord, oEvent.getSource().getModel("selectedOperation").getData().oSourceViewController.getController().onOperationUpdateSucesss,
					this.onDeleteAssignmentFailed, this);

			},

			// END LMP2-35 KIR0084

			// #DontDelete : Daya 

			/**
			 * Closes the worker list dialog
			 * @params (event) oEvt
			 */
			onWorkerPopoverClosed: function(oEvt) {
				var aData = oEvt.getSource().getModel("selectedOperation").getData();

				this._oWokersPlanDialog = new CraftWorkPlan(aData);
				jQuery.sap.syncStyleClass("sapUiSizeCompact", aData.SourceViewController, this._oWokersPlanDialog);
				this._oWokersPlanDialog.getFragment().setContentWidth("40%");
				this._oWokersPlanDialog.getFragment().open();
				this.workerPopover.close();
			},

			// #DontDelete : Daya 
			/**
			 * Open material list popover fragment when material button is clicked in shop list workorder operations
			 * @params {event} 	oEvt is when materials icon is pressed
			 * @params {object} 	oView is the view to open Material List on
			 * @params {string} sBindingPath is the binding path of to fetch data for
			 * @params {object} oModel is the model of the view
			 */
			onClickMaterialListPopover: function(oEvt, oView, sBindingPath, oModel, sLocomotiveNumber) {
				this._oMaterialParentView = oView;
				this._sBindingPath = sBindingPath;
				this._sLocomotiveNumber = sLocomotiveNumber;
				if (!this._oPopover) {
					this._oPopover = sap.ui.xmlfragment(
						"com.sap.cp.lm.view.myShop.common.workplan.MaterialListPopover", oView.getController());

				}
				oView.addDependent(this._oPopover);

				oModel.setProperty("/Group", false);
				this._oPopover.setModel(oModel);
				this._oPopover.bindElement(sBindingPath);

				var CurrentRole = this._oGlobalModel.getProperty("/role");
				var sRoleModel = new sap.ui.model.json.JSONModel();
				sRoleModel.setProperty("/SelectedRole", CurrentRole);
				this._oPopover.setModel(sRoleModel, "Role");
				this._oPopover.openBy(oEvt.getSource());
			},

			// #DontDelete : Daya 
			onClickAddOperation: function(oEvent, oView) {
				this.oLocoAddOperationDialog = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.common.workplan.AddOperation", this);
				oView.addDependent(this.oLocoAddOperationDialog);
				if (oView.getController().getOwnerComponent().isIPadMode()) {
					this.oLocoAddOperationDialog.setContentWidth("70%");
				} else {
					this.oLocoAddOperationDialog.setContentWidth("40%");
				}

				this.sSelectedWorkOrder = oEvent.getSource().getCustomData()[0].getProperty("value");
				this.oView = oView;

				this.oLocoAddOperationDialog.open();
			},

			// #DontDelete : Daya 
			/**
			 * Closes LocoAddOperation fragment Dialog
			 */
			onClickAddOperationCancel: function() {
				this.oLocoAddOperationDialog.destroy(true);
				this.oLocoAddOperationDialog = null;
			},

			// #DontDelete : Daya 
			onClickAddOperationAdd: function(oEvent) {
				var oPayload = {};
				oPayload.OrderNo = this.sSelectedWorkOrder;
				oPayload.Descr = oEvent.getSource().getParent().getContent()[0].getItems()[0].getItems()[1].getValue();
				oPayload.PlanWorkDur = oEvent.getSource().getParent().getContent()[0].getItems()[1].getItems()[1].getValue();
				oPayload.PlanWorkUom = "H";
				var CurrentRole = this._oGlobalModel.getProperty("/role");
				//Added by Sandhya : LMP2-4 : Operation should not be added for craft with est time more than an hour
				// if (oPayload.PlanWorkDur > 1 && CurrentRole === "CRAFT") {
				// 	ErrorManager.handleError("" , "Estimated Time can not be more than 1 hour");
				if (oPayload.PlanWorkDur > 1) {
					if (CurrentRole === "CRAFT" || CurrentRole === "SUPERVISOR" ) {
					ErrorManager.handleError("" , "Estimated Time can not be more than 1 hour");
				}
				} else {
				LocomotiveDataModel.createOperation(this._afterOperationCreatesucess, this, oPayload);
				}
			},

			// #DontDelete : Q 
			onClickEstTimeEdit: function(oEvent, oSelectedContext, oView) {
				this.oLocoEditOperationEstTimeDialog = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.common.workplan.EditOperationEstTime", this);
				oView.addDependent(this.oLocoEditOperationEstTimeDialog);
				if (oView.getController().getOwnerComponent().isIPadMode()) {
					this.oLocoEditOperationEstTimeDialog.setContentWidth("70%");
				} else {
					this.oLocoEditOperationEstTimeDialog.setContentWidth("40%");
				}

				this.oView = oView;
				this.oSelectedContext = oSelectedContext;

				this.oLocoEditOperationEstTimeDialog.open();
			},

			// #DontDelete : Q 
			/**
			 * Closes Edit Operation Est Time fragment Dialog
			 */
			onClickCloseEditOperationEstTime: function() {
				this.oLocoEditOperationEstTimeDialog.destroy(true);
				this.oLocoEditOperationEstTimeDialog = null;
			},

			// #DontDelete : Q 
			onClickEditOperationEstTimeEdit: function(oEvent) {
				var oPayload = {};
				oPayload.OrderNo = this.oSelectedContext.OrderNo;
				oPayload.Activity = this.oSelectedContext.Activity;
				oPayload.PlanWorkDur = oEvent.getSource().getParent().getContent()[0].getItems()[0].getItems()[1].getValue();
				oPayload.PlanWorkUom = "H";

				var oUrlParameters = {};
				oUrlParameters.OpNode = this.oSelectedContext.OpNode;
				oUrlParameters.RoutingNo = this.oSelectedContext.RoutingNo;

				LocomotiveDataModel.updateOperationEstTime(this._afterOperationUpdateSucess, this, oPayload, oUrlParameters);
			},

			// #DontDelete : Daya 
			onClickDeleteAssignmentFromOperation: function(oEvent) {
    
				var aData = oEvent.getSource().getModel("selectedOperation").getData();
				var sPersNumber = oEvent.getSource().getCustomData()[0].getProperty("value");
				var sRecord = "/AssignmentSet(RoutingNo='" + aData.RoutingNo + "',OpNode='" + aData.OpNode + "',PersonNo='" + sPersNumber + "')";
				LocomotiveDataModel.DeleteAssignmentFromOperation(sRecord, aData.oSourceViewController.getController().onOperationUpdateSucesss,
					this.onDeleteAssignmentFailed, this);

			},
			// #DontDelete : Daya 
			onDeleteAssignmentFailed: function() {

			}

		};
	});