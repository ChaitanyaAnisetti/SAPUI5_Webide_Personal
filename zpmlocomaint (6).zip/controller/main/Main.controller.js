/*&---------------------------------------------------------------------*    
 * Author         : Sandhya satavalekar                                  *
 * Date           : 02-Feb-2019                                          *
 * Project        : Locomotive Maintenance Phase 2                       *
 * Description    : LMP2-05: Change the Loco User Status                 *
 * Search Term    : LMP2-05
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2019.02.03                                           *
 * Incidinet      : EAM-ASR3413183 - PM Loco Main phase 2                *
 * Description    : Logic added for the Unavailability reasons read      *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : ALI0031                                              *
 * Date           : 2019.04.24                                           *
 * Incidinet      : EAM-ASR3413183 - PM Loco Main phase 2                *
 * Description    : added new TOD _showHideHeaderButtons: function ()    *
 *&----------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
* Author/Changed By   : SAT0008				        		       		  *
* Date                : 8-May-2019                                     *
* Project             : Locomotive Maintenance Phase 2                    *
* Description         : LMP2-3 : Work order History and Notification History *
/*&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
* Author/Changed By   : BAJ0018				        		       		  *
* Date                : 6-June-2019                                       *
* Project             : Locomotive Maintenance Phase 2                     *
* Description         : Added logic for system view and productivity       *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : KOU0012				        		       		   *
* Date                : 1-June-2020                                        *
* Project             : Locomotive Maintenance Phase 2                     *
* Description         : Added logic to navigate to fleet details if        *
*                       URL parameter is supplied                          *
* Search Term         : MOD001                                             *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : BAJ0018				        		       		   *
* Date                : 19 -Feb -2021                                      *
* Project             : BNB Project                                        *
* Description         : Added BNB Storage locations logic                  *
* Search Term         : BNB                                                *
/*&------------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : SHE0272                                              *
 * Date           : 25.Jun.2021                                          *
 * Incidinet      : LLM2.29 - Road/Yard Repair			              	 *
 * Description    : Added condition 'R'									 *
 * Search Term    : LLM2.29                                              *
 *&----------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 15-Sep-2021	                                       *
* Project             : Locomotive Maintenance Phase 2                     *
* Description         : Refresh issue with cross navigation		           *
* Search Term         : INC0110700                                         *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : ANI0006				        		       		   *
* Date                : 11-Nov-2021	                                       *
* Project             : EAM Railinc EPA    					               *
* Description         : EPA Information - Fields Masking		           *
* Search Term         : ANI0006 2000014601                                 *
/*&------------------------------------------------------------------------*/
sap.ui.define(["sap/ui/core/mvc/Controller",
		"com/sap/cp/lm/util/Constants",
		"com/sap/cp/lm/util/ErrorManager",
		"com/sap/cp/lm/util/Formatter",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/model/alert/AlertDataModel",
		"com/sap/cp/lm/model/main/TrackSpotModel",
		"sap/ui/unified/Menu",
		"sap/ui/unified/MenuItem",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
		"com/sap/cp/lm/model/craft/CraftDataModel",
		"com/sap/cp/lm/controller/craft/craftAssignment/CraftAssignmentManager"
	],
	function (Controller, Constants, ErrorManager, Formatter, BusyIndicator,
		AlertDataModel, TrackSpotModel, Menu, MenuItem, LocomotiveDataModel, CraftDataModel, CraftAssignmentManager) {

		"use strict";

		var _this;
		var _alertModel;

		return Controller.extend("com.sap.cp.lm.controller.main.Main", {

			/* #DontDelete : Yann */
			/**
			 * Initializes the controller
			 */
			onInit: function () {
				_this = this;
				//The view properties are used for template control
				var isDesktop = !this.getOwnerComponent().isIPadMode();
				this._oViewPropertiesModel = new sap.ui.model.json.JSONModel();
				this._oViewPropertiesModel.setProperty("/isDesktop", isDesktop);
				this._oViewPropertiesModel.setProperty("/isTabletPortraitMode", (window.outerHeight > window.outerWidth));
				var oView = this.getView();
				oView.setModel(this._oViewPropertiesModel, "viewProperties");

				/* counter used to find out if all the backend data is retrieved
				 *  - Map SVG
				 *  - TrackSpotSet
				 *  - LocomotiveSet
				 */
				this._iBusyCounter = 0;
				this._selectedShop = null;
				this._selectedPeople = null;
				this._currentPage = "myShopView";
				this._oModel = this.getOwnerComponent().getMainModel();
				this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
				this._oGlobalLocomotiveModel = this.getOwnerComponent().getGlobalLocomotiveModel();
				this._oGlobalShiftModel = this.getOwnerComponent().getGlobalShiftModel();
				this._oGlobalMyWorkModel = this.getOwnerComponent().getGlobalMyWorkModel();
				//I18n model
				this._oI18nModel = this.getOwnerComponent().getModel("i18n");

				this._oShopModel = new sap.ui.model.json.JSONModel();
				this._oDeferalCodes = new sap.ui.model.json.JSONModel();
				this._oLocoStat = new sap.ui.model.json.JSONModel();

				//Start: ANI0006 2000014601 - Engine manufacturer JSON data 
				this._oEngManfModel = this.getOwnerComponent().getEngManfJsonModel();
				//End: ANI0006 2000014601 - Engine manufacturer JSON data

				this._shopButton = oView.byId("shopB");

				this._oGlobalModel.setProperty("/renderMap", false);

				//simplified direction model for CP, only us Eeast/West
				this._oGlobalModel.setProperty("/Directions", [{
					key: "E",
					text: "East"
				}, {
					key: "W",
					text: "West"
				}]);

				//BusyIndicator.resetBusyIndicator();
				BusyIndicator.showBusyIndicator();
				// read the stations assigned for the user
				this._oModel.read("/ShopSet", {
					urlParameters: {
						"$expand": "TrackSpotSet"
					},
					success: function (oData) {
						_this._oShopModel.setData(oData);
						var shops = oData.results;
						_this._oGlobalModel.setProperty("/Shops", shops);
						// KIR0084 LMP2 Remove to avoid double load
						//_this._setDefaultStation();
						BusyIndicator.hideBusyIndicator();
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

				//BusyIndicator.resetBusyIndicator();
				BusyIndicator.showBusyIndicator();
				this._oModel.read("/DropDownSet", {
					urlParameters: {
						"$filter": "Usage eq 'DEFERRAL_CODES'"
					},
					success: function (oData) {
						_this._oDeferalCodes.setData(oData);
						var deferalCodes = oData.results;
						_this._oGlobalModel.setProperty("/DeferalCodes", deferalCodes);
						var defaultDeferalCodeValue = _this._getDefaultDeferalCodeValue();
						if (defaultDeferalCodeValue) {
							_this._oGlobalModel.setProperty("/DefaultDeferalCodeValue", defaultDeferalCodeValue);
						}
						BusyIndicator.hideBusyIndicator();
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

				//Start: ANI0006 2000014601 - Engine Manufacturer OData  - Fetch EngineManfacturer
				LocomotiveDataModel.fetchEngineManfacturer(_this.onfetchEngineManfacturerSuccess, null,
					this);
				//End: ANI0006 2000014601 - Engine Manufacturer OData  - Fetch EngineManfacturer

				// Fetch DropDownSet requests
				LocomotiveDataModel.fetchDropDownSetRequest(_this.fetchDropDownSetRequestSuccess, null, _this, 'DEFECT_TYPE', "/DefectTypes");
				LocomotiveDataModel.fetchDropDownSetRequest(_this.fetchDropDownSetRequestSuccess, null, _this, 'DEFECT_TYPE_CODE',
					"/DefectTypeCodes");
				LocomotiveDataModel.fetchDropDownSetRequest(_this.fetchDropDownSetRequestSuccess, null, _this, 'DEFECT_MONITOR_CODE',
					"/DefectMonitorCodes");
				LocomotiveDataModel.fetchDropDownSetRequest(_this.fetchDropDownSetRequestSuccess, null, _this, 'DEFECT_STATUS', "/DefectStatus");

				//fetch defect to order types
				LocomotiveDataModel.fetchDefectToOrderTypes(_this.fetchDefectToOrderTypesSuccess, null, _this);
				/*Added by Vikram*/
				//Craft unavailability reasons
				CraftDataModel.fetchUnavailabilityReasons();
				/*Added by Vikram*/
				// Fetch the Dropdown set for Close Out Codes
				//BusyIndicator.resetBusyIndicator();
				BusyIndicator.showBusyIndicator();
				this._oModel.read("/DropDownSet", {
					urlParameters: {
						"$filter": "Usage eq 'COMP_GROUP'"
					},
					success: function (oData) {
						_this._oDeferalCodes.setData(oData);
						var deferalCodes = oData.results;
						_this._oGlobalModel.setProperty("/CompGroupDD", deferalCodes);
						BusyIndicator.hideBusyIndicator();
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

				//Start : Added by Sandhya : Fetch the DropDown set for Locomotive Status : LMP2-05
				// Fetch the Dropdown set for Close Out Codes
				//BusyIndicator.resetBusyIndicator();
				BusyIndicator.showBusyIndicator();
				this._oModel.read("/DropDownSet", {
					urlParameters: {
						"$filter": "Usage eq 'LOCO_STAT'"
					},
					success: function (oData) {
						_this._oLocoStat.setData(oData);
						var LocoStat = oData.results;
						_this._oGlobalModel.setProperty("/LocoStat", LocoStat);
						BusyIndicator.hideBusyIndicator();
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
				//End:Added by Sandhya : Fetch the DropDown set for Locomotive Status

				//BusyIndicator.resetBusyIndicator();
				BusyIndicator.showBusyIndicator();
				this._oModel.read("/DropDownSet", {
					urlParameters: {
						"$filter": "Usage eq 'COMP_LOC_GROUP'"
					},
					success: function (oData) {
						_this._oDeferalCodes.setData(oData);
						var deferalCodes = oData.results;
						_this._oGlobalModel.setProperty("/CompLocGrpDD", deferalCodes);
						BusyIndicator.hideBusyIndicator();
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

				//BusyIndicator.resetBusyIndicator();
				BusyIndicator.showBusyIndicator();
				this._oModel.read("/DropDownSet", {
					urlParameters: {
						"$filter": "Usage eq 'DEFECT_CODES'"
					},
					success: function (oData) {
						_this._oDeferalCodes.setData(oData);
						var deferalCodes = oData.results;
						_this._oGlobalModel.setProperty("/DefectCodeDD", deferalCodes);
						BusyIndicator.hideBusyIndicator();
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
				//START - BAJ0018 - BNB
				//read TM Wag storage locations
				BusyIndicator.showBusyIndicator();
				this._oModel.read("/BnbstoragelocationSet", {
					success: function (oData) {
						var bnbStorageLocation = oData.results;
						_this._oGlobalModel.setProperty("/BnbStorageLocation", bnbStorageLocation);
						BusyIndicator.hideBusyIndicator();
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
				//END -BAJ0018 -BNB
				this._oModel.read("/GlobalParametersSet", {
					urlParameters: {
						"$format": "json"
					},
					success: function (oData) {
						oData.results.forEach(function (oGlobalParameter) {
							_this._oGlobalModel.setProperty(("/" + oGlobalParameter.ParamId), oGlobalParameter.ParamValue);
						});
					},
					error: function (oError) {

					}
				});

				// register to listen to change events of the globalmodel which contain the currentShop
				var binding = new sap.ui.model.Binding(this._oGlobalModel, "/", this._oGlobalModel.getContext("/"));
				binding.attachChange(function () {
					_this.onGlobalModelChange();
				});

				BusyIndicator.showBusyIndicator();
				// read the user information
				this._oModel.read("/UserInfoSet('')", {
					urlParameters: {
						"$expand": "UserRoleSet",
						"$format": "json"
					},

					success: function (oData) {
						// Added BAJ0018
						// Overwrite the default shop if navigating from system view
						if (_this.getOwnerComponent().getComponentData()) {
							var oStartupParams = _this.getOwnerComponent().getComponentData().startupParameters;
						}

						// Sample code can be used for navigation from  system view 
						// oStartupParams = {
						// 		"loco": ["CP8879"],
						// 	"shop": ["1919"]
						// };

						if (oStartupParams && oStartupParams.shop) {
							oData.DefaultShop = oStartupParams.shop[0];
							_this._oGlobalModel.getProperty("/currentShop", oStartupParams.shop[0]);
						}
						// End BAJ0018
						//check that we dont have an empty role set
						if (oData.UserRoleSet.results.length === 0) {
							ErrorManager.handleError("error", "Empty UserRoleSet");
							BusyIndicator.hideBusyIndicator();
							return;
						}

						// check the role sent from backend is valid
						if (Constants.BACKEND_ROLE[oData.DefaultRole]) {
							// user has changed the role validate to see if he has access to this role
							$.each(oData.UserRoleSet.results, function (i, oRole) {
								if (oRole.Role === oData.DefaultRole) {
									oData.CurrentRole = oData.DefaultRole;
									return false;
								}
							});
							if (oData.CurrentRole !== oData.DefaultRole) {
								// error user doesn't have access to this default role
								oData.CurrentRole = oData.UserRoleSet.results[oData.UserRoleSet.results.length - 1].Role;
							}

						} else {
							oData.DefaultRole = Constants.ROLE.SUPERVISOR;
							oData.CurrentRole = oData.DefaultRole;
						}

						// get the default role for the user
						if (!oData.CurrentRole) {
							if (oData.UserRoleSet.results[oData.UserRoleSet.results.length - 1]) {
								oData.CurrentRole = oData.UserRoleSet.results[oData.UserRoleSet.results.length - 1].Role;
							}
						}

						if (oData.CurrentRole === "") {
							// error no maintained roles for the user
							var sMessage = _this._oI18nModel.getProperty("NO_ROLE_MAINTAINED");
							ErrorManager.showErrorMessage(sMessage, _this._onUserRoleError.bind(_this));
							return;
						}

						_this._oGlobalModel.setProperty("/readOnlyWorkPlan", false);
						_this._oGlobalModel.setProperty("/readFromWorkPlan", true); //Added by Sandhya LMP2-3
						_this._oGlobalModel.setProperty("/readFromWOHistory", false); //Added by Sandhya LMP2-3

						_this._oGlobalModel.setProperty("/role", oData.CurrentRole);
						_this._currentUser = oData;
						_this._oGlobalModel.setProperty("/currentUser", oData);
						// System view and Productivity - Added by BAJ0018
						_this._oGlobalModel.setProperty("/systemView", oData.ViewSystemview);
						//_this._oGlobalModel.setProperty("/productivityReports", oData.ViewProductivity);
						// End BAJ0018
						_this._showHideHeaderButtons();
						_this._currentUser = _this._oGlobalModel.getProperty("/currentUser");
						_this._currentUser.ShowTechInfo = oData.ViewTechIds;

						if (oStartupParams && oStartupParams.loco) {
							_this._oGlobalModel.setProperty("/systemViewLocomotive", oStartupParams.loco[0]);
							_this.onLocomotives();
						} else {
							if (oData.CurrentRole === Constants.ROLE.CRAFT) {
								_this.onMyWork();
							}
						}

						BusyIndicator.hideBusyIndicator();
						if (oData.DefaultShop === "") {
							//no default shop - set first in the list
							var aShops = _this._oShopModel.oData.results;
							aShops.sort(function (a, b) {
								if (a.Name < b.Name) return -1;
								if (a.Name > b.Name) return 1;
								return 0;
							});
							_this._setCurrentShop(aShops[0]);
						} else {
							_this._setDefaultStation();
						}

						// Added Vikram - Set the default shop if navigating from system view
						if (oStartupParams && oStartupParams.loco) {
							aShops = _this._oShopModel.oData.results;
							var shop = aShops.find(function (element) {
								return element.Id === oStartupParams.shop[0];
							});
							_this._oGlobalModel.setProperty("/currentShop", shop);
						}
						// End System view navigation
						//Now we have the user information and we can perform the initial call for the user alerts
						_this._readAlertsForUser();
					},
					error: function (oError) {

						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

				/*
				BusyIndicator.showBusyIndicator();
				// read the customizing
				this._oModel.read("/CustomizingSet", {
					success : function(oData) {
						var customizingHashMap = {};
						for (var i = 0, length = oData.results.length; i < length; i++){
							var customizing = oData.results[i];
							if (customizing.Name && customizing.Value){
								customizingHashMap[customizing.Name] = customizing;
							}
						}
						_this._oGlobalModel.setProperty("/customizing",customizingHashMap);
						BusyIndicator.hideBusyIndicator();
					},
					error : function(oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
				*/

				// read the whitelist
				this._oModel.read("/WhitelistSet", {
					success: function (oData) {

						for (var i = 0, length = oData.results.length; i < length; i++) {
							var oWhiteListEntry = oData.results[i];
							//bypass the initial port of 00000
							oWhiteListEntry.Port = (oWhiteListEntry.Port === "000000") ? "" : oWhiteListEntry.Port;
							jQuery.sap.addUrlWhitelist(oWhiteListEntry.Protocol, oWhiteListEntry.Host, oWhiteListEntry.Port, oWhiteListEntry.Path);
						}
					},
					error: function (oError) {
						ErrorManager.handleError(oError);
					}
				});

				/*
				BusyIndicator.showBusyIndicator();
				// read the wheelsheet ddlb values
				this._oModel.read("/CharacteristicSet",{
					urlParameters: {
						"$expand": "DropDownValueSet"
					},
					success : function(oData) {
						var oDDLBCharacteristics = {};
						var oWheelSheetCertificationTypes = [];
						var aDDLBValues = oData.results ? oData.results : [];
						$.each(aDDLBValues, function( index, oCharacteristic ) {						
							if (oCharacteristic.CertificationType === "WHSM"){
								oWheelSheetCertificationTypes = oCharacteristic.DropDownValueSet.results;
							}else{
								oDDLBCharacteristics[oCharacteristic.Name] = oCharacteristic.DropDownValueSet;	
							}
						});
						_this._oGlobalModel.setProperty("/WSDDLBValues",oDDLBCharacteristics);
						_this._oGlobalModel.setProperty("/WSCertificationValues",oWheelSheetCertificationTypes);
						BusyIndicator.hideBusyIndicator();
					},
					error : function(oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
				*/

				/*
				// Read a revision type model
				BusyIndicator.showBusyIndicator();
				this._oModel.read("/RevisionTypeSet", {
					success: function(oData) {
						_this._oGlobalModel.setProperty("/RevisionTypeSet", oData);
						BusyIndicator.hideBusyIndicator();
					},
					error: function(oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
				*/

				/*
				//Read notification types predefined by the backend
				BusyIndicator.showBusyIndicator();			
				this._oModel.read("/NotificationTypeSet", {
					success: function(oData) {
						var aNotificationTypes = oData.results;
						var oTypes = {};
						$.each(aNotificationTypes, function(index, value) {
							oTypes[value.Type] = value.Description;
						});
						_this._oGlobalModel.setProperty("/NotificationTypes", oTypes);
						BusyIndicator.hideBusyIndicator();
					},
					error: function(oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

				*/

				this.getView().setModel(this._oModel);
				this.getView().setModel(this._oGlobalModel, Constants.GLOBAL_MODEL);

				var alertModel = new sap.ui.model.json.JSONModel();
				this.getView().setModel(alertModel, "alert");
				var oButton = oView.byId("idAlertButton");
				oButton.addStyleClass("lmBadge lmBtnDecoration");
				oButton.data("badge", "0", true);

				setInterval(this._readAlertsForUserInBackground, 300000);

				//this.getUserImage(this._oGlobalModel.getProperty("/currentUser").Id);

				var oEventBus = sap.ui.getCore().getEventBus();
				oEventBus.subscribe("MyShopPage", "onLocomotiveDetail", _this.onLocomotiveDetail, _this);
				oEventBus.subscribe("myWorkPage", "onMyWorkDetail", _this.onMyWorkDetail, _this);
				oEventBus.subscribe("craftPage", "onCraftViewDetail", _this.onCraftViewDetail, _this);

			},

			_getDefaultDeferalCodeValue: function () {
				var deferalCodes = _this._oGlobalModel.getProperty("/DeferalCodes");

				for (var i = 0; i < deferalCodes.length; i++) {
					var deferalCode = deferalCodes[i];
					if (deferalCode.DefaultSelection === true) {
						return deferalCode.Value;
					}
				}
			},

			/* #DontDelete : Yann */
			/**
			 * EvenBus subscription, triggered when a locomotive is selected from the map to display its details
			 */
			onLocomotiveDetail: function (sChannel, sEvent, oData) {
				var oLocomotive = oData.oLocomotive;

				this._oGlobalModel.setProperty("/currentLocomotive", oLocomotive);
				if (oLocomotive.ShopReason === "S" || oLocomotive.ShopReasonDet === "R") { // SHE0272: LLM2.29 - Road/Yard Repair - Added condition 'R'
					this._oGlobalModel.setProperty("/currentServiceLocomotive", oLocomotive);
				}

				this._unselectPreviousPage();
				this._oGlobalModel.setProperty("/isMapView", false);
				this._oGlobalModel.setProperty("/sSelectedView", "Locomotives");
				this._currentPage = "locomotivesView";
				this.getView().byId("locomotivesView").addStyleClass("sapButtonSelected");

				var oRouter = sap.ui.core.UIComponent.getRouterFor(_this);
				window.setTimeout(function () {
					if (oData.oLocomotive.ShopReason === "S" || oLocomotive.ShopReasonDet === "R") {
						oRouter.getTargets().display("locomotivesServicingHome");
					} else {
						oRouter.getTargets().display("locomotivesShoppedHome");
					}
				}, 0);

			},

			//TODO: check if this is required?
			/**
			 * EvenBus subscription, 
			 */
			onMyWorkDetail: function (sChannel, sEvent, oData) {

				// this._oGlobalModel.setProperty("/currentLocomotive", oData.oLocomotive);

				this._unselectPreviousPage();
				this._oGlobalModel.setProperty("/isMapView", false);
				this._oGlobalModel.setProperty("/sSelectedView", Constants.MYWORK);
				this._currentPage = "myWorkView";
				this.getView().byId("myWorkView").addStyleClass("sapButtonSelected");

				var oRouter = sap.ui.core.UIComponent.getRouterFor(_this);
				window.setTimeout(function () {
					oRouter.getTargets().display("myWork");
				}, 0);

			},

			//TODO: check if this is required?
			/**
			 * EvenBus subscription, 
			 */
			onCraftViewDetail: function (sChannel, sEvent, oData) {

				// this._oGlobalModel.setProperty("/currentLocomotive", oData.oLocomotive);

				this._unselectPreviousPage();
				this._oGlobalModel.setProperty("/isMapView", false);
				this._oGlobalModel.setProperty("/sSelectedView", Constants.CRAFT);
				this._currentPage = "craftView";
				this.getView().byId("craftView").addStyleClass("sapButtonSelected");

				var oRouter = sap.ui.core.UIComponent.getRouterFor(_this);
				window.setTimeout(function () {
					oRouter.getTargets().display("CraftList");
				}, 0);
			},
			//Added BAJ0018 System View and Productivity
			onSystemView: function () {
				this.goToFioriApp("systemView", "display");
			},

			onProductivityActionMenu: function (oEvent) {
				var oItemText = oEvent.getParameter("item").getText();
				switch (oItemText) {
				case Constants.EMP_PROD:
					this.goToFioriApp("empProd", "display");
					break;
				case Constants.OP_PROD:
					this.goToFioriApp("opProd", "display");
					break;
				case Constants.TASKLIST_PROD:
					this.goToFioriApp("tasklistProd", "display");
					break;
				}
			},
			//End BAJ0018 System View and Productivity
			/* #DontDelete : Yann */
			/**
			 * get dropdown set successful callback (multiple)
			 */
			fetchDropDownSetRequestSuccess: function (oData, sProperty) {
				_this._oGlobalModel.setProperty(sProperty, oData.results);
			},

			/* #DontDelete : Yann */
			/**
			 * get Defect To Order Types successful callback
			 */
			fetchDefectToOrderTypesSuccess: function (oData) {
				_this._oGlobalModel.setProperty("/DefectToOrderTypes", oData.results);
			},

			/**
			 * Logout the user when he doesnt have proper roles assigned to him
			 */
			_onUserRoleError: function () {
				this.onLogout();
			},

			/* #DontDelete : Yann */
			/***
			 * Set the default station for the user
			 */
			_setDefaultStation: function () {
				if (_this._oGlobalModel.getProperty("/currentUser")) {
					//set the default shop of the user
					var defaultShopId = _this._oGlobalModel.getProperty("/currentUser").DefaultShop;
					this._setStation(defaultShopId);
				}
			},

			/* #DontDelete : Yann */
			/***
			 * Set the default station according to shop Id
			 */
			_setStation: function (sShopId) {
				if (_this._oShopModel && _this._oShopModel.oData.results) {
					$.each(_this._oShopModel.oData.results, function (i, shop) {
						if (shop.Id === sShopId) {
							_this._setCurrentShop(shop);
							return false;
						}
					});
				}
			},

			/* #DontDelete : Yann */
			/**
			 * when the global model is changed
			 */
			onGlobalModelChange: function () {
				var tempCurrentRole = this._oGlobalModel.getProperty("/role");
				// check if the currentRole is different and if so reload the app
				if (tempCurrentRole && this._currentUser && tempCurrentRole !== this._currentUser.CurrentRole) {
					this._currentUser.CurrentRole = tempCurrentRole;
					this._showHideHeaderButtons();

					if (this._currentUser.CurrentRole === Constants.ROLE.CRAFT) {
						this.onMyWork();
					} else {
						this.onMyShop();
					}

					jQuery.sap.delayedCall(1000, this, function () {
						BusyIndicator.hideBusyIndicator();
					});
				}
			},

			/* #DontDelete : Yann */
			/**
			 * Show/Hide header navigation button depending on the logged on user role 
			 */
			_showHideHeaderButtons: function () {
				var role = _this._oGlobalModel.getProperty("/role");
				var oCurrentUser = _this._oGlobalModel.getProperty("/currentUser");

				var sysViewVisible = _this._oGlobalModel.getProperty("/systemView");
				//	var prodViewVisible = _this._oGlobalModel.getProperty("/productivityReports");

				var linkUser = this.getView().byId("linkUser");
				linkUser.setProperty("text", oCurrentUser.FullName);

				var linkUserRole = this.getView().byId("linkUserRole");
				var sRole = _this.getOwnerComponent().getText("ROLE_" + Constants.BACKEND_ROLE[role]);
				linkUserRole.setProperty("text", "(" + sRole + " / " + oCurrentUser.SystemId + ")");

				//common to all roles
				this.byId("myShopView").setVisible(true);
				this.byId("locomotivesView").setVisible(true);
				this.byId("myWorkView").setVisible(true);
				this.byId("CraftDialog").setVisible(true);
				this.byId("turnoverDoc").setVisible(true);
				this.byId("productivityReports").setVisible(true);
				//role specific
				switch (role) {
				case Constants.ROLE.SUPERVISOR:
					this.byId("myWorkView").removeStyleClass("lmMyWorkBorder");
					this.byId("craftView").setVisible(true);
					this.byId("fleetView").setVisible(true);
					this.byId("myWorkViewPI").setVisible(false);
					this.byId("myWorkViewPIText").setVisible(false);
					this.byId("idShiftStatusButton").setVisible(true);
					this.byId("idFioriTimeApproveButton").setVisible(true);
					this.byId("shopT").setVisible(false);
					this.byId("shopB").setVisible(true);
					this.byId("CraftDialog").setVisible(true);
					break;
				case Constants.ROLE.CRAFT:
					this.byId("myWorkView").addStyleClass("lmMyWorkBorder");
					this.byId("craftView").setVisible(false);
					this.byId("fleetView").setVisible(false);
					this.byId("myWorkViewPI").setVisible(true);
					this.byId("myWorkViewPIText").setVisible(true);
					this.byId("idShiftStatusButton").setVisible(false);
					this.byId("idFioriTimeApproveButton").setVisible(false);
					this.byId("shopT").setVisible(false); //temporary solution
					this.byId("shopB").setVisible(true); //temporary solution
					this.byId("CraftDialog").setVisible(false);
					// Restrict Craft access for turnover doc and productivity
					this.byId("turnoverDoc").setVisible(false);
					this.byId("productivityReports").setVisible(false);
					break;
				}

				//Acess Specific - BAJ0018
				if (sysViewVisible) {
					this.getView().byId("systemView").setVisible(true);
				}
				// if (prodViewVisible) {
				// 	this.getView().byId("productivityReports").setVisible(true);
				// }
				//end BAJ0018
			},

			/**
			 * Called when the menu button is pressed
			 */
			onMenuPress: function (oEvent) {
				//var oButton = oEvent.getSource();
				var oButton = this.getView().byId("linkUserRole");

				// create menu only once
				if (!this._menu) {
					var oI18Model = this.getOwnerComponent().getModel("i18n");

					//Ideally this should be a fragment 
					//But the menu control doesn't seem to be bindable so we populate the UI
					//programatically for the menu
					this._menu = new sap.ui.unified.Menu();

					var aChangeRoleMenuItems = this._oGlobalModel.getProperty("/currentUser/UserRoleSet/results").map(function (oRole) {
						var oItem = new sap.ui.unified.MenuItem({
							text: Formatter.roleDescriptionFormatter(oRole.Description),
							select: this.onSelectRole.bind(this)
						});
						oItem.data(oRole);
						return oItem;
					}.bind(this));

					var oChangeRoleMenuItems = new sap.ui.unified.MenuItem({
						text: oI18Model.getProperty("CHANGE_ROLE"),
						submenu: new sap.ui.unified.Menu({
							items: aChangeRoleMenuItems
						})
					});

					/*var oLogoutMenuItem = new sap.ui.unified.MenuItem({
						text: oI18Model.getProperty("LOGOUT"),
						select: this.onLogout.bind(this)
					});*/

					this._menu.addItem(oChangeRoleMenuItems);
					//this._menu.addItem(oLogoutMenuItem);
				}

				var eDock = sap.ui.core.Popup.Dock;
				this._menu.open(this._bKeyboard, oButton, eDock.BeginTop, eDock.BeginBottom, oButton);
			},

			/* #DontDelete : Yann */
			/**
			 * Called when the user clicks on the change role to planner button
			 */
			onSelectRole: function (oEvent) {
				var tempCurrentRole = this._oGlobalModel.getProperty("/role");
				var oData = oEvent.getSource().data();
				var sBackendRole = oData.Role;
				if (tempCurrentRole !== sBackendRole) {
					BusyIndicator.showBusyIndicator();
					this._oGlobalModel.setProperty("/role", sBackendRole);
				}
			},

			/**
			 * Called when the user logout
			 */
			onLogout: function () {
				// remove any URL parameters added programmatically
				var newUrl = location.href.split("?")[0];
				history.pushState({}, null, newUrl);
				//The logout requires redirection and could take some time
				//During this process it is not clear that something happens
				BusyIndicator.showBusyIndicator();
				var oAppComponent = this.getOwnerComponent();
				var sAppURL = "";
				var aPathSegments = location.href.split('/');
				for (var i = 3; i < aPathSegments.length; i++) {
					sAppURL += "/" + aPathSegments[i];
				}
				$.ajax({
						type: "GET",
						url: "/sap/public/bc/icf/logoff"
					})
					.always(function (data) {
						// if (!document.execCommand("ClearAuthenticationCache")) { 
						// 	$.ajax({ 
						// 		type: "GET", 
						// 		url: sAppURL,  // url: "/sap/bc/ui5_ui5/sap/zlocomaint",
						// 		username: 'dummy', //dummy credentials: when request fails, will clear the authentication header 
						// 		password: 'dummy', 
						// 		statusCode: { 
						// 			"401": function() { 
						// 				//This empty handler function will prevent authentication pop-up in chrome/firefox
						// 				location.href = location.href.split("?")[0];
						// 				window.location.reload(true);
						// 			},					
						// 			"404": function() {
						// 				//The application URL probably is wrong
						// 				window.location.reload(true);
						// 			},								
						// 			"200": function() {
						// 				window.location.reload(true);
						// 			},							
						// 			error: function() {								
						// 				window.location.reload(true);
						// 			} 
						// 		}
						// 	});
						// };				
					})
					.fail(function () {
						//Filure during logout procedure
						throw new Error(oAppComponent.getText("LOGOUT_FAILURE"));
						//window.location.reload(true);
					});
			},

			/**
			 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
			 * This hook is the same one that SAPUI5 controls get after being rendered.
			 * @memberOf view.Main
			 * Cannot be removed since window needs to be resized
			 */
			onAfterRendering: function () {

				this.getView().byId(this._currentPage).addStyleClass("sapButtonSelected");
				//remove the unused space in left and right
				$(".sapMShellCentralBox").css("width", "100%")
					.css("margin-left", "0")
					.css("left", "0%");
				$(".sapMShellBrandingBar").css("background-color", "transparent");
			},

			/* #DontDelete : Yann */
			/**
			 * Show Settings popover 
			 */
			onShowSettingsPopover: function (oEvent) {
				// set the role model to be used
				var _oRoleModel = new sap.ui.model.json.JSONModel();
				_oRoleModel.setData(this._currentUser.UserRoleSet);

				var settingsPopover = this.byId("DefaultSettingPopover");
				settingsPopover.setModel(_oRoleModel, "RoleModel");
				// set the shop model to be used
				settingsPopover.setModel(this._oShopModel, "ShopModel");

				var oPopoverAnchor = oEvent.getSource();
				settingsPopover.getController().openPopover(oPopoverAnchor);
			},

			/* #DontDelete : Yann */
			/**
			 * Show Personal Links popover 
			 */
			onShowPersonalLinkPopover: function (oEvent) {
				var personalLinkPopover = this.byId("PersonalLinkPopover");
				var oPopoverAnchor = oEvent.getSource();
				personalLinkPopover.getController().openPopover(oPopoverAnchor);
			},

			//Alert Popover Block - BEGIN

			/* #DontDelete : Yann */
			/** 
			 * Event handler for click of the button for Alerts 
			 * @param(event) oEvent The event object.
			 */
			onShowAlertPopover: function (oEvent) {
				this._readAlertsForUser();

				// create alerts popover only once
				if (!this._alertPopover) {
					this._alertPopover = sap.ui.xmlfragment("idAlertPopover", "com.sap.cp.lm.view.main.AlertPopover", this);
					this.getView().addDependent(this._alertPopover);
				}
			},

			/* #DontDelete : Yann */
			/**
			 * Mark all alert as deleted
			 * @param(event) oEvent is the event listener
			 */
			onClearAll: function (oEvent) {
				this._alertPopover.close();
				var aAlerts = this.getView().getModel("alert").getData().results;
				for (var i = 0; i < aAlerts.length; i++) {
					AlertDataModel.deleteAlertMessage(aAlerts[i]);
				}
				AlertDataModel.submitUpdateAlertsBatch(_this);
			},

			/* #DontDelete : Yann */
			/**
			 * Mark one alert as deleted
			 * @param(event) oEvent is the event listener
			 */
			onAlertDelete: function (oEvent) {
				var oItem = oEvent.getSource();
				var bPath = oItem.getBindingContext("alert").getPath();
				var oAlert = this.getView().getModel("alert").getProperty(bPath);

				BusyIndicator.showBusyIndicator();

				AlertDataModel.deleteAlertMessage(oAlert, _this.onUpdateSuccess, _this);
				AlertDataModel.submitUpdateAlertsBatch(_this);
			},

			/* #DontDelete : Yann */
			/**
			 * alert popover post rendering ui setup
			 */
			afterAlertPopoverOpened: function () {
				var oList = sap.ui.core.Fragment.byId("idAlertPopover", "idAlertList");
				oList.attachUpdateFinished(function (oEvent) {
					if (_this._alertPopover) {
						_this.afterAlertPopoverOpened();
					}
				});
				var aItems = oList.getItems();
				$.each(aItems, function (i, item) {
					var id = item.getId();
					var isRead = _this.getView().getModel("alert").getProperty(item.getBindingContext("alert").sPath).ReadFlag;
					var elem = $("#" + id);
					if (isRead === false) {
						elem.addClass("sapMLIBSelected");
					} else {
						elem.removeClass("sapMLIBSelected");
					}
					elem.on("click", _this.onAlertItemClick);
				});
			},

			/* #DontDelete : Yann */
			/**
			 * Mark all alert as read
			 * @param(event) oEvent is the event listener
			 */
			onMarkAllRead: function (oEvent) {
				this._alertPopover.close();
				var aAlerts = this.getView().getModel("alert").getData().results;

				if (aAlerts) {
					for (var i = 0; i < aAlerts.length; i++) {
						if (aAlerts[i].ReadFlag !== true) {
							var oPayload = AlertDataModel.createAlertUpdatePayload(aAlerts[i], true);
							AlertDataModel.onUpdateAlertMessage(oPayload);
						}
					}
					AlertDataModel.submitUpdateAlertsBatch(_this);
				}
			},

			/* #DontDelete : Yann */
			/**
			 * select an alert item in list
			 */
			onSelectAlertItem: function () {
				var oList = sap.ui.core.Fragment.byId("idAlertPopover", "idAlertList");

				var oSelectedItem = oList.getSelectedItem();
				var sSelectedItemPath = oSelectedItem.getBindingContext('alert').getPath();
				var oAlert = this.getView().getModel('alert').getProperty(sSelectedItemPath);

				if (oAlert.ReadFlag !== true) {
					BusyIndicator.showBusyIndicator();

					var oPayload = AlertDataModel.createAlertUpdatePayload(oAlert, true);

					AlertDataModel.onUpdateAlertMessage(oPayload, _this.onUpdateSuccess, _this);

					AlertDataModel.submitUpdateAlertsBatch(_this);
				}
			},

			/* #DontDelete : Yann */
			/**
			 * backend alert update successful callback
			 */
			onUpdateSuccess: function () {
				_this._onSuccessMessageUpdate();
			},

			/* #DontDelete : Yann */
			/**
			 * recuring background call to get alerts for current user
			 */
			_readAlertsForUserInBackground: function () {
				if (_this._oGlobalModel.getProperty("/currentUser")) {
					var userId = _this._oGlobalModel.getProperty("/currentUser").UserId;
					AlertDataModel.readAlertsForUser(userId, _this._onFetchAlertSuccessInBackground);
				}
			},

			/* #DontDelete : Yann */
			/**
			 * initial background call to get alerts for user
			 */
			_readAlertsForUser: function () {
				var currentUser = _this._oGlobalModel.getProperty("/currentUser");
				if (currentUser) {
					var userId = currentUser.UserId;

					BusyIndicator.showBusyIndicator();
					AlertDataModel.readAlertsForUser(userId, _this._onFetchAlertSuccess);
				} else {

				}
			},

			/* #DontDelete : Yann */
			/**
			 * backend fetch alert successful callback
			 */
			_onFetchAlertSuccess: function (oData) {
				_this._updateAlertNotification(oData);

				// KIR0084 Model class already hides busy indicator
				// BusyIndicator.hideBusyIndicator();
				// delay because addDependent will do a asynchronous re-rendering which will close the popover
				if (_this._alertPopover) {
					jQuery.sap.delayedCall(100, this, function () {
						var oPopoverAnchor = _this.getView().byId("idAlertButton");
						_this._alertPopover.openBy(oPopoverAnchor);
					});
				}
			},

			/* #DontDelete : Yann */
			/**
			 * backend fetch alert in background successful callback
			 */
			_onFetchAlertSuccessInBackground: function (oData) {
				_this._updateAlertNotification(oData);
			},

			/* #DontDelete : Yann */
			/**
			 * process retrieved alerts
			 */
			_updateAlertNotification: function (oData) {
				_this.getView().getModel("alert").setData(oData);

				var oButton = _this.getView().byId("idAlertButton");

				if (oData.unread === 0) {
					if (oButton.hasStyleClass("lmBadge")) {
						oButton.removeStyleClass("lmBadge");
					}
					if (oButton.hasStyleClass("lmBtnDecoration")) {
						oButton.removeStyleClass("lmBtnDecoration");
					}
				} else {
					oButton.data("badge", String(oData.unread), true);
					if (!oButton.hasStyleClass("lmBadge")) {
						oButton.addStyleClass("lmBadge");
					}
					if (!oButton.hasStyleClass("lmBtnDecoration")) {
						oButton.addStyleClass("lmBtnDecoration");
					}
					if (oData.unread > 9) {
						oButton.data("badge", "9+", true);
					}
				}
			},

			/* #DontDelete : Yann */
			/**
			 * backend alert update successful callback
			 */
			_onSuccessMessageUpdate: function (oData) {
				_this._readAlertsForUser();
			},

			//Alert Popover Block - END		

			/* #DontDelete : Yann */
			/** 
			 * Send Alert message Block -- Begin
			 */
			onSendMessage: function () {
				var oView = this.getView();
				if (oView.getModel("receiverModel")) {
					this.onSendAlertMessage(false, {});
				} else {
					// fetch craft assigned for this shop 
					CraftDataModel.getShopCraftAssignmentSet(_this._selectedShop.Id, _this.onFetchCraftSuccess, null, _this);
				}
			},

			/* #DontDelete : Yann */
			/** 
			 * Open the send message dialog.
			 * @param(object) oView The current view object.
			 * @param(boolean) bRequestSpot for display or no the locomotive, track and spot number.
			 */
			onSendAlertMessage: function (bRequestSpot, oSpot, sLocomotiveDescription) {
				var oGlobalCraftModel = _this.getOwnerComponent().getGlobalCraftModel();
				var oReceiverModel = new sap.ui.model.json.JSONModel();
				oReceiverModel.oData.results = oGlobalCraftModel.oData.UserInfoSet.results;

				// create send message dialog 
				if (!_this._sendMessageDialog) {
					_this._sendMessageDialog = sap.ui.xmlfragment("sendMessageFragment", "com.sap.cp.lm.view.main.SendMessageDialog", this);
					_this.getView().addDependent(_this._sendMessageDialog);
				}

				oReceiverModel.setSizeLimit(oReceiverModel && oReceiverModel.getData().results ? oReceiverModel.getData().results.length : 0);

				_this._sendMessageDialog.setModel(oReceiverModel, "receiverModel");

				var oReceiverSelectBox = sap.ui.core.Fragment.byId("sendMessageFragment", "receiverSelectBox");
				var oSendButton = sap.ui.core.Fragment.byId("sendMessageFragment", "sendAlertsMessageButton");

				_this._sendMessageDialog.setTitle(_this.getOwnerComponent().getText("SEND_MESSAGE"));
				oReceiverSelectBox.setVisible(true);
				oSendButton.setEnabled(false);

				var oMessageTextA = sap.ui.core.Fragment.byId("sendMessageFragment", "alertsMessage");
				oMessageTextA.setValue("");
				oMessageTextA.setValueState("None");
				oMessageTextA.setValueStateText("");
				_this._sendMessageDialog.open();
			},

			/** 
			 * Called when message dialog is opened
			 * Add event handlers on search field
			 * to listen for virtual keyboard events
			 * @param(oEvent) oEvent The event object.
			 */
			onMessageDialogOpen: function (oEvent) {

				//IPAD
				//Control virtual keyboard influence over send message dialog fields visibility 
				if (_this._oViewPropertiesModel.getProperty("/isDesktop")) {
					return;
				}
				var oSearchInput = $('input[id*="idSearchRecipient"]');
				//Scroll top to see list with recipiens under the input field
				oSearchInput.bind("focus", function () {
					$(window).scrollTop(100);
				});
				//restore window position when input field is left
				oSearchInput.bind("blur", function () {
					$(window).scrollTop(0);
				});
				var oMessageTextArea = $('textarea[id*="alertsMessage-inner"]');
				//restore window position when message area is left
				oMessageTextArea.bind("blur", function () {
					$(window).scrollTop(0);
				});
			},

			/** 
			 * Validate the length of the alert message to send.
			 * @param(event) oEvent The event object.
			 */
			onAlertMessageLiveChange: function (oEvent) {
				var oSendAlertsMessageButton = sap.ui.core.Fragment.byId("sendMessageFragment", "sendAlertsMessageButton");
				var oMessageTextA = sap.ui.core.Fragment.byId("sendMessageFragment", "alertsMessage");
				var sMessageLength = oMessageTextA.getValue().length;

				if (sMessageLength > Constants.ALERT_MESSAGE_LENGTH) {
					oSendAlertsMessageButton.setEnabled(false);
					oMessageTextA.setValueState("Error");
					oMessageTextA.setValueStateText(this._oI18nModel.getProperty("ERROR_ALERT_MESSAGE_LENGTH"));
				} else {
					oSendAlertsMessageButton.setEnabled(true);
					oMessageTextA.setValueState("None");
					oMessageTextA.setValueStateText("");
				}
			},

			/** 
			 * Send the message to the receiver.
			 * @param(event) oEvent The event object.
			 */
			onSend: function (oEvent) {
				var oMessageTextA = sap.ui.core.Fragment.byId("sendMessageFragment", "alertsMessage");
				var sMessage = oMessageTextA.getValue();
				var sSenderNumber = _this._oGlobalModel.getProperty("/currentUser").UserId;
				var sReceiverNumber = this._selectedPeople.UserId;
				var oEntry = AlertDataModel.createPersonalAlertMessage(sMessage, sSenderNumber, sReceiverNumber, "G");
				AlertDataModel.createAlertsMessage(this.onCreateAlertsMessageSuccess, this, oEntry);

				_this._sendMessageDialog.close();
			},

			/** 
			 * Search the people who the message will be sent
			 * @param(event) oEvent is the listener of the event 
			 */
			onSearchPeopleForSendMessage: function (oEvent) {
				// add filter for search
				var aFilters;
				var sQuery = oEvent.getSource().getValue();
				if (sQuery && sQuery.length > 0) {
					var firstNameFilter = new sap.ui.model.Filter("FirstName", sap.ui.model.FilterOperator.Contains, sQuery);
					var lastNameFilter = new sap.ui.model.Filter("LastName", sap.ui.model.FilterOperator.Contains, sQuery);
					aFilters = new sap.ui.model.Filter({
						filters: [firstNameFilter, lastNameFilter],
						and: false
					});
				}
				// update list binding
				var oTable = sap.ui.core.Fragment.byId("sendMessageFragment", "peopleTable");
				var binding = oTable.getBinding("items");
				binding.filter(aFilters);
				var oSendButton = sap.ui.core.Fragment.byId("sendMessageFragment", "sendAlertsMessageButton");
				if (oTable.getItems().length === 1) {
					oTable.setSelectedItem(oTable.getItems()[0]);
					this._selectedPeople = oTable.getSelectedItem().getBindingContext("receiverModel").getObject();
					oSendButton.setEnabled(true);
				} else {
					oTable.removeSelections();
					this._selectedPeople = null;
					oSendButton.setEnabled(false);
				}
			},

			/**
			 * Row selection event of the people table
			 * @param(event) oEvent The event object. 
			 */
			peopleLineItemPress: function (oEvent) {
				this._selectedPeople = oEvent.getParameter("listItem").getBindingContext("receiverModel").getObject();
				var oSendButton = sap.ui.core.Fragment.byId("sendMessageFragment", "sendAlertsMessageButton");
				oSendButton.setEnabled(true);
			},

			/**	
			 *  Success call back function when new alerts message is added
			 */
			onCreateAlertsMessageSuccess: function () {
				this._readAlertsForUser();
			},

			/** 
			 * Close the message dialog.
			 */
			onSendMessageCancel: function () {
				var oTable = sap.ui.core.Fragment.byId("sendMessageFragment", "peopleTable");
				oTable.removeSelections(true);
				var oSendButton = sap.ui.core.Fragment.byId("sendMessageFragment", "sendAlertsMessageButton");
				oSendButton.setEnabled(false);
				_this._sendMessageDialog.close();
			},
			// Send Alert message Block -- End

			/** 
			 * Event handler for click of the user name 
			 * @param(oEvent) oEvent The event object.
			 */
			onUserClick: function (oEvent) {
				var oLink = oEvent.getSource();

				// create action sheet only once
				if (!this._actionSheet) {
					this._actionSheet = sap.ui.xmlfragment("com.sap.cp.lm.view.main.LogoutActionSheet", this);
					this.getView().addDependent(this._actionSheet);
				}

				this._actionSheet.openBy(oLink);
			},

			// /***
			//  * 
			//  */
			// getUserImage: function(sUserId) {
			// 	var sURL = "https://lmwebdv.lm.com/lm.was8/UELdapGateway/api/V1/Users/" + "B032660"; //"B032660"; //B361450 B032660
			// 	var aData = jQuery.ajax({
			// 		type: "GET",
			// 		contentType: "application/json",
			// 		url: sURL,
			// 		dataType: "json",
			// 		async: false,
			// 		success: function(data, textStatus, jqXHR) {
			// 			var oImage = _this.getView().byId("idUserPicture");
			// 			if (data && data.thumbnailPhoto) {
			// 				var sSRC = "data:image/jpeg;base64," + data.thumbnailPhoto;
			// 				oImage.setSrc(sSRC);
			// 			}
			// 		},
			// 		error: function(data, textStatus, jqXHR) {

			// 		}
			// 	});
			// },

			/**
			 * Unselect the previously selected page
			 */
			_unselectPreviousPage: function () {
				if (this._currentPage) {
					this.getView().byId(this._currentPage).removeStyleClass("sapButtonSelected");
				}
			},

			/** 
			 * Event handler for click of the My Shop in the header bar 
			 * @param(event) oEvent The event object.
			 */
			onMyShop: function (oEvent) {
				if (this._currentPage === "myShopView")
					return;
				this._unselectPreviousPage();
				this._oGlobalModel.setProperty("/isMapView", true);
				this._oGlobalModel.setProperty("/sSelectedView", "MyShop");
				this._currentPage = "myShopView";
				this.getView().byId("myShopView").addStyleClass("sapButtonSelected");

				// show the busy indicator during the navigation
				BusyIndicator.showBusyIndicator();
				var oRouter = sap.ui.core.UIComponent.getRouterFor(_this);
				window.setTimeout(function () {
					oRouter.getTargets().display("myShop");
				}, 0);
			},

			/** 
			 * Event handler for click of the Locomotives in the header bar 
			 * @param(event) oEvent The event object.
			 */
			onLocomotives: function (oEvent) {
				if (this._currentPage === "locomotivesView")
					return;
				this._unselectPreviousPage();
				this._oGlobalModel.setProperty("/isMapView", false);
				this._oGlobalModel.setProperty("/sSelectedView", Constants.LOCOMOTIVES);
				this._oGlobalModel.setProperty("/forcedLocomotive", null);

				this._currentPage = "locomotivesView";
				this.getView().byId("locomotivesView").addStyleClass("sapButtonSelected");

				var oRouter = sap.ui.core.UIComponent.getRouterFor(_this);
				window.setTimeout(function () { // SHE0272 - Refresh issue with cross navigatioN - INC0110700                                         
					oRouter.getTargets().display("locomotives");
					sap.ui.controller("com.sap.cp.lm.controller.myShop.Master").onUnselectList();
				}, 0);
			},

			/** Event handler for click of the My Work in the header bar 
			 * @param(event) oEvent The event object.
			 */
			onMyWork: function (oEvent) {
				if (this._currentPage === "myWorkView")
					return;
				this._unselectPreviousPage();
				this._currentPage = "myWorkView";

				this._oGlobalModel.setProperty("/isMapView", false);
				this._oGlobalModel.setProperty("/sSelectedView", Constants.MYWORK);
				this._oGlobalModel.setProperty("/forcedLocomotive", null);

				this.getView().byId("myWorkView").addStyleClass("sapButtonSelected");

				// show the busy indicator during the navigation

				var oRouter = sap.ui.core.UIComponent.getRouterFor(_this);
				window.setTimeout(function () {
					oRouter.getTargets().display("MyWork");
				}, 0);
			},

			/** 
			 * Event handler for click of the Craft in the header bar 
			 * @param(event) oEvent The event object.
			 */
			onCraft: function (oEvent) {
				if (this._currentPage === "craftView")
					return;
				this._unselectPreviousPage();
				this._currentPage = "craftView";

				this._oGlobalModel.setProperty("/sSelectedView", Constants.CRAFT);
				this._oGlobalModel.setProperty("/isMapView", false);
				this._oGlobalModel.setProperty("/forcedLocomotive", null);

				this.getView().byId("craftView").addStyleClass("sapButtonSelected");

				// show the busy indicator during the navigation
				// BusyIndicator.showBusyIndicator();
				var oRouter = sap.ui.core.UIComponent.getRouterFor(_this);
				window.setTimeout(function () {
					oRouter.getTargets().display("CraftList");
				}, 0);
			},

			/** 
			 * Event handler for click of the Fleet in the header bar 
			 * @param(event) oEvent The event object.
			 */
			onFleet: function (oEvent) {

				this._unselectPreviousPage();
				this._currentPage = "fleetView";

				this._oGlobalModel.setProperty("/sSelectedView", Constants.FLEET);
				this._oGlobalModel.setProperty("/isMapView", false);
				this._oGlobalModel.setProperty("/forcedLocomotive", null);

				this.getView().byId("fleetView").addStyleClass("sapButtonSelected");

				// show the busy indicator during the navigation
				// BusyIndicator.showBusyIndicator();
				var oRouter = sap.ui.core.UIComponent.getRouterFor(_this);
				window.setTimeout(function () {
					oRouter.getTargets().display("fleet");
				}, 0);
			},

			/** HALI0031
			 * Event handler for click of the TURNOVER button in the header bar 
			 * @param(event) oEvent The event object.
			 */
			onTurnoverDoc: function (oEvent) {
				if (this._currentPage === "turnoverDoc")
					return;
				this._unselectPreviousPage();
				this._currentPage = "turnoverDoc";

				this._oGlobalModel.setProperty("/sSelectedView", Constants.TURNOVERDOC);
				this._oGlobalModel.setProperty("/isMapView", false);
				this._oGlobalModel.setProperty("/forcedLocomotive", null);

				this.getView().byId("turnoverDoc").addStyleClass("sapButtonSelected");

				// show the busy indicator during the navigation
				// BusyIndicator.showBusyIndicator();
				var oRouter = sap.ui.core.UIComponent.getRouterFor(_this);
				window.setTimeout(function () {
					oRouter.getTargets().display("turnoverDoc");
				}, 0);
			},

			/**
			 * Get the dialog for available station maps 
			 * @return shopDialog The dialog object for stations 
			 */
			_getDialog: function () {
				if (!this._oShopDialog) {
					this._oShopDialog = sap.ui.xmlfragment("com.sap.cp.lm.view.main.SelectShop", this);
					this.getView().addDependent(this._oShopDialog);
				}
				return this._oShopDialog;
			},

			/**
			 * Called when one press on KPI button at the application header
			 * @param {sap.ui.base.Event} [oEvent] the object with the event data
			 * @private
			 */
			onShowKpiPopover: function (oEvent) {
				var kpiPopover = this.byId("KpiPopover");
				var oPopoverAnchor = oEvent.getSource();
				kpiPopover.getController().openPopover(oPopoverAnchor);
			},

			/**
			 *  Event handler for the location press to display the available stations 
			 */
			onLocationPress: function () {
				this._getDialog().setModel(this._oShopModel, "ShopModel");
				this._getDialog().open();
			},

			// #DontDelete
			/**
			 *  Event handler for the craft assignment press
			 */
			onCraftAssignmentPress: function () {
				var oCraftAssignmentManager = CraftAssignmentManager.init(this);

				if (!this._oCraftAssignmentDialog) {
					this._oCraftAssignmentDialog = sap.ui.xmlfragment("com.sap.cp.lm.view.craft.craftAssignment.CraftAssignmentListDialog",
						oCraftAssignmentManager);
					this.getView().addDependent(this._oCraftAssignmentDialog);
				}

				oCraftAssignmentManager.openDialog({
					craft: this._oGlobalModel.getProperty("/currentCraft")
				});
			},

			/** 
			 * Cancel event handler on the station maps dialog 
			 */
			onCancel: function () {
				this._getDialog().close();
			},

			/** 
			 * Go to shop button pressed on the station maps dialog 
			 */
			onGoToShop: function () {
				this._getDialog().close();
				this._setCurrentShop(this._selectedShop);
			},

			/** 
			 * Search the station which is assigned to the user (craft)
			 * @param(event) oEvent is the listener of the event 
			 */
			onSearchStation: function (oEvent) {
				// add filter for search
				var aFilters = [];
				var sQuery = oEvent.getSource().getValue();
				if (sQuery && sQuery.length > 0) {
					var filter = new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, sQuery);
					aFilters.push(filter);
				}
				// update list binding
				var oTable = sap.ui.getCore().byId("shopTable");
				var binding = oTable.getBinding("items");
				binding.filter(aFilters);
			},

			/**
			 * Row selection event of the station table
			 * @param(event) oEvent The event object. 
			 */
			shopLineItemPress: function (oEvent) {
				this._selectedShop = oEvent.getParameter("listItem").getBindingContext("ShopModel").getObject();
			},

			/**
			 * Success callback function for fetching craft data
			 * @param(object) oData is the data returned by call
			 */
			onFetchCraftStatsSuccess: function (oData) {
				var workProgressIndicator = this.byId("myWorkProgressIndicator");
				workProgressIndicator.setPercentValue((oData.CompletedOperations / oData.TotalNbOperations) * 100);
				var workProgressText = this.byId("myWorkViewPIText");
				var opsText = this._oI18nModel.getProperty("OPS");
				workProgressText.setText(oData.CompletedOperations + "/" + oData.TotalNbOperations + " " + opsText);
			},

			/**
			 * Fetch the craft status with respect to completed/assigned operations for a given shift
			 */
			fetchCraftStats: function () {
				//TODO: re activate in due time
				//com.sap.cp.lm.model.craft.CraftDataModel.fetchCraftStats(_this.onFetchCraftStatsSuccess, null, _this);
			},

			/**
			 * Fetching of the Map SVG, TrackSpotSet and LocomotiveSet is done
			 */
			fetchCompleted: function () {
				// set the currentshop
				_this._oGlobalModel.setProperty("/currentShop", _this._selectedShop);
				BusyIndicator.hideBusyIndicator();

				LocomotiveDataModel.fetchShopShifts(_this._selectedShop.Id, _this._initializeShifts, null, _this);
				CraftDataModel.fetchCraftShiftFilters(_this._selectedShop.Id, _this.onFetchCraftShiftFiltersSuccess, null, _this);
				//this._showShop();

				//	begin of MOD001
				// if (_this.getOwnerComponent().getComponentData()) {
				// 	var oStartupParams = _this.getOwnerComponent().getComponentData().startupParameters;

				// 	if (oStartupParams && oStartupParams.fleet) {
				// 		BusyIndicator.showBusyIndicator();
				// 		var LocoId = oStartupParams.fleet[0];
				// 		var fnSuccessCallBack, oContext, fnErrorCallBack;
				// 		var oModel = _this.getOwnerComponent().getModel();
				// 		oModel.read("/GetFleetLocomotives", {
				// 			urlParameters: {
				// 				"LocoId": "'" + LocoId + "'",
				// 				"$format": "json"
				// 			},
				// 			success: function (oData) {
				// 				if (fnSuccessCallBack && oContext) {
				// 					fnSuccessCallBack.apply(oContext, [oData.results, oContext]);
				// 				}
				// 				var oLocomotive = oData.results[0];
				// 				oLocomotive.isInFleetView = true;

				// 				_this._oGlobalModel.setProperty("/currentLocomotive", oLocomotive);
				// 				_this._oGlobalModel.setProperty("/fleetSelectedLocomotive", oLocomotive);
				// 				_this._oGlobalModel.setProperty("/LocoId", LocoId);
				// 				_this._oGlobalModel.setProperty("/fleetDetailsOrigin", "fleet");

				// 				var oRouter = sap.ui.core.UIComponent.getRouterFor(_this);

				// 				window.setTimeout(function () {
				// 					oRouter.getTargets().display("fleetDetails");
				// 				}, 0);

				// 			},
				// 			error: function (oError) {
				// 				BusyIndicator.hideBusyIndicator();
				// 				ErrorManager.handleError(oError);
				// 				if (fnErrorCallBack && oContext) {
				// 					fnErrorCallBack.apply(oContext);
				// 				}
				// 			}
				// 		});
				// 		_this.onFleet();
				// 		//	end of MOD001

				// 	   //	begin of MOD001
				// 	} else {

				// 		BusyIndicator.hideBusyIndicator();
				// 	}
				// } else {
				// 	BusyIndicator.hideBusyIndicator();
				// }
				//                   //	end of MOD001	
			},

			/**
			 * Trigger Inbound locomotive fetch
			 */
			fetchInboundLocomotives: function () {
				_this._iBusyCounter++;
				BusyIndicator.showBusyIndicator();
				LocomotiveDataModel.fetchInboundLocomotives(_this._selectedShop.Id, _this.onFetchInboundLocomotivesSuccess,
					null, _this);
			},

			/**
			 * Fetching Inbound locomotives completed
			 * @param(object) oData is the data returned via the call
			 */
			onFetchInboundLocomotivesSuccess: function (oData) {
				_this._oGlobalLocomotiveModel.setProperty("/Inbound", oData.results);
				_this._iBusyCounter--;
				BusyIndicator.hideBusyIndicator();
				if (_this._iBusyCounter === 0) {
					_this.fetchCompleted();
				}
			},

			fetchServiceLocomotives: function () {
				_this._iBusyCounter++;
				BusyIndicator.showBusyIndicator();
				LocomotiveDataModel.fetchServiceLocomotives(_this._selectedShop.Id, _this.onFetchServiceLocomotivesSuccess,
					null, _this);
			},
			/**
			 * Fetching Service locomotives completed
			 * @param(object) oData is the data returned via the call
			 */
			onFetchServiceLocomotivesSuccess: function (oData) {
				_this._oGlobalLocomotiveModel.setProperty("/Servicing", oData.results);
				_this._iBusyCounter--;
				BusyIndicator.hideBusyIndicator();
				if (_this._iBusyCounter === 0) {
					_this.fetchCompleted();
				}
			},

			/**
			 * Trigger Shopped locomotive fetch
			 */
			fetchShoppedLocomotives: function () {
				_this._iBusyCounter++;
				BusyIndicator.showBusyIndicator();
				LocomotiveDataModel.fetchShoppedLocomotives(_this._selectedShop.Id, _this.onFetchShoppedLocomotivesSuccess,
					null, _this);
			},

			/**
			 * Fetching Shopped locomotives completed
			 * @param(object) oData is the data returned via the call
			 */
			onFetchShoppedLocomotivesSuccess: function (oData) {
				_this._oGlobalLocomotiveModel.setProperty("/Shopped", oData.results);
				_this._iBusyCounter--;
				BusyIndicator.hideBusyIndicator();
				if (_this._iBusyCounter === 0) {
					_this.fetchCompleted();
				}
			},

			fetchCraftsAssigned: function () {
				BusyIndicator.showBusyIndicator();
				LocomotiveDataModel.fetchCraftWorkPlanList(_this.onSuccessCraftList, _this.onErrorCraftList, this,
					_this._selectedShop.Id);
			},

			onSuccessCraftList: function (oData) {
				BusyIndicator.hideBusyIndicator();
				_this._oGlobalLocomotiveModel.setProperty("/CraftList", oData.results);
				if (_this._iBusyCounter === 0) {
					_this.fetchCompleted();
				}
			},

			/**	
			 * Success callback function for craft fetch  
			 * @params(oAssignCraftModel) oAssignCraftModel is the data object returned in success callback
			 */
			onFetchCraftSuccess: function (oAssignCraftModel) {
				var oView = _this.getView();
				oView.setModel(oAssignCraftModel, "receiverModel");
				_this.onSendAlertMessage(false, {});
			},

			/**
			 * fetch list of craft persons for a selected shop id
			 */
			fetchCrafts: function () {
				CraftDataModel.getShopCraftAssignmentSet(_this._selectedShop.Id, _this.onFetchCraftSuccess, null, _this);
			},

			_fetchCraftInBackground: function () {
				CraftDataModel.getShopCraftAssignmentSet(_this._selectedShop.Id, _this.onFetchCraftSuccess, null, _this);
			},

			/**
			 * KIR0084 Adding initialize shifts that does not publish shop change
			 */
			_initializeShifts: function (oData) {
				var currentTimestamp = new Date();
				var currentShift = null;
				$.each(oData.results, function (i, shift) {
					if (shift.ShiftStart < currentTimestamp && shift.ShiftEnd > currentTimestamp) {
						currentShift = shift;
					}
				});
				_this._oGlobalModel.setProperty("/currentShift", currentShift);
				_this._oGlobalShiftModel.setData(oData);

				if (_this._oGlobalModel.getProperty("/role") === Constants.ROLE.CRAFT) {
					// fetch the craft stats
					_this.fetchCraftStats();
				}
			},

			/**
			 * success callback function when list of craft persons is successfully fetched
			 * @param(object) oData is the data returned via the callee function
			 */
			onFetchShiftSuccess: function (oData) {
				// KIR0084 Move to internal function because I need to call just this code elsewhere.
				_this._initializeShifts(oData);

				var oEventBus = sap.ui.getCore().getEventBus();
				oEventBus.publish("ShopChanged", "shopChangedDone");
			},

			/**
			 * success callback function when list of shifts filters is successfully fetched
			 * @param(object) oData is the data returned via the callee function
			 */
			onFetchCraftShiftFiltersSuccess: function (oData) {
				_this._oGlobalModel.setProperty("/currentShiftFilters", oData.results);
				_this._oGlobalModel.refresh(true);
			},

			/**
			 * fetch shifts for a particular shop
			 */
			fetchShifts: function () {
				LocomotiveDataModel.fetchShopShifts(_this._selectedShop.Id, _this.onFetchShiftSuccess, null, _this);
				CraftDataModel.fetchCraftShiftFilters(_this._selectedShop.Id, _this.onFetchCraftShiftFiltersSuccess, null, _this);
			},

			/**
			 * Trigger spot fetch
			 */
			fetchTrackSpot: function (fSuccessCallBack) {

				_this._iBusyCounter++;
				BusyIndicator.showBusyIndicator();

				_this._oModel.read("/ShopSet('" + _this._selectedShop.Id + "')/TrackSpotSet", {
					success: function (oData) {
						//The empty TrackSpotSet is a sign for missing data at the backend
						if (oData.results.length === 0) {
							BusyIndicator.hideBusyIndicator();
							var sWarning = _this._oI18nModel.getProperty("SPOT_INFO_LOAD_FAILURE").replace("{0}", _this._selectedShop.Name);
							ErrorManager.showErrorMessage(sWarning, _this._showShop);
						}

						var trackSet = {};
						var spotSet = {};
						var spotWCIDMap = {};

						for (var i = 0, length = oData.results.length; i < length; i++) {
							var spot = oData.results[i];

							if (spot.Spot && spot.Track && spot.Trackspot) {
								spot.LocomotiveNumber = "";

								trackSet[spot.Track] = spot;
								spotSet[spot.Trackspot] = spot;
								spotWCIDMap[spot.Trackspot] = spot;
							}
						}

						_this._oGlobalModel.setProperty("/TrackSet", trackSet);
						_this._oGlobalModel.setProperty("/SpotSet", spotSet);
						_this._oGlobalModel.setProperty("/SpotWorkCenterSet", spotWCIDMap);

						// in the operation level the workcenterid is passed instead of the workcentercode for performance

						_this._iBusyCounter--;
						BusyIndicator.hideBusyIndicator();
						if (_this._iBusyCounter == 0) {
							_this.fetchCompleted();
						}
						if (fSuccessCallBack) {
							fSuccessCallBack();
						}
					},
					error: function (oError) {
						_this._iBusyCounter--;
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (_this._iBusyCounter == 0) {
							_this.fetchCompleted();
						}
					}
				});
			},

			/**
			 * Trigger Servicing Tasklists fetch
			 */
			fetchServicingTasklists: function (fSuccessCallBack) {

				_this._iBusyCounter++;
				BusyIndicator.showBusyIndicator();

				TrackSpotModel.fetchServicingTasklists(_this._selectedShop.Id,
					function (oData) {
						var servicingTasklists = oData.results;

						_this._oGlobalModel.setProperty("/ServicingTasklists", servicingTasklists);
						_this._iBusyCounter--;
						BusyIndicator.hideBusyIndicator();
						if (_this._iBusyCounter === 0) {
							_this.fetchCompleted();
						}
						if (fSuccessCallBack) {
							fSuccessCallBack();
						}
					},
					function (oError) {
						ErrorManager.handleError(oError);
						_this._iBusyCounter--;
						BusyIndicator.hideBusyIndicator();
						if (_this._iBusyCounter === 0) {
							_this.fetchCompleted();
						}
					});

			},

			/**
			 * Fetch the map SVG associated to the Shop
			 */
			fetchMapSVG: function () {
				_this._oGlobalModel.setProperty("/needDrawMap", true);

				// check if you are trying to run the app within localhost
				var mapURL = "/sap/opu/odata/sap/ZPM_LM_SRV/ShopMapSet('" + _this._selectedShop.Id + "')/$value";

				_this._iBusyCounter++;
				BusyIndicator.showBusyIndicator();
				d3.xml(mapURL, "image/svg+xml", function (error, xml) {
					if (error || !xml) {

						_this._iBusyCounter--;
						BusyIndicator.hideBusyIndicator();
						var message = _this.getOwnerComponent().getText("MAP_LOAD_FAILURE");
						sap.m.MessageBox.show(message, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error",
							actions: [sap.m.MessageBox.Action.OK]
						});
					}

					if (xml) {
						var importedNode = document.importNode(xml.documentElement, true);
						_this._oGlobalModel.setProperty("/shopMapSVG", importedNode);
					}

					BusyIndicator.hideBusyIndicator();
					_this._iBusyCounter--;
					if (_this._iBusyCounter === 0) {
						_this.fetchCompleted();
					}
				});
			},

			//============================================================//
			// Private functions
			//============================================================//		
			/**
			 * Show map even no locomotives are shoped on it
			 * @private
			 */
			_showShop: function () {
				// check if there are no shopped locos

				if (Object.keys(_this._oGlobalLocomotiveModel.getData()).length === 0) {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(_this);
					oRouter.getTargets().display("myShop");
				}

				//read the shift set after currentshop is set	
				this.fetchShifts();
			},

			/**
			 * Set the new station to be used in the application
			 * @param currentShop The station object. 
			 */
			_setCurrentShop: function (currentShop) {
				var activeShop = _this._oGlobalModel.getProperty("/currentShop");
				if (_this._selectedShop === null || activeShop === null || _this._selectedShop.Id !== activeShop.Id) {
					BusyIndicator.showBusyIndicator();
					_this._selectedShop = currentShop;
					//Set the Current Selected shop to another variable  which will be used in other controller for reloading on Selection Change
					_this._oGlobalModel.setProperty("/newShop", _this._selectedShop);
					//reset the currentShop for the time been until everything related to the map is loaded and counter
					_this._oGlobalModel.setProperty("/currentShop", null);

					_this._oGlobalModel.setProperty("/currentLocomotive", null);
					_this._oGlobalModel.setProperty("/currentServiceLocomotive", null);

					this._iBusyCounter = 0;

					//change the button text
					this._shopButton.setText(this._selectedShop.Name);
					this.getView().byId("shopT").setText(this._selectedShop.Name);

					//read the servicing Task lists
					this.fetchServicingTasklists();

					//read the map svg
					this.fetchMapSVG();

					//read the locomotives for station
					// this.fetchInboundLocomotives();

					this.fetchShoppedLocomotives();
					// this.fetchServiceLocomotives();

					//Read the crafts Assigned
					// this.fetchCraftsAssigned();

					//read the track and spot information
					this.fetchTrackSpot();
				}
			},

			/* #DontDelete : Q */
			onPressFioriAppTimeApproveLink: function () {
				this.goToFioriApp("TimeEntry", "zapprove");
			},

			/* #DontDelete : Q */
			onPressFioriAppTimeManageLink: function () {
				this.goToFioriApp("TimeEntry", "manage");
			},

			/* #DontDelete : Q */
			goToFioriApp: function (sSemanticObject, sAction) {
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service

				var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
					target: {
						semanticObject: sSemanticObject,
						action: sAction
					}
				})) || "";

				if (hash.length > 0) {
					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash
						}
					});
				}
			},
			//Start: ANI0006 2000014601 - Engine Manufacturer values set to model _oEngManfModel
			onfetchEngineManfacturerSuccess: function (oData) {
					this._oEngManfModel.setData(oData.results);
				}
			//End: ANI0006 2000014601 - Engine Manufacturer values set to model _oEngManfModel
		});
	});