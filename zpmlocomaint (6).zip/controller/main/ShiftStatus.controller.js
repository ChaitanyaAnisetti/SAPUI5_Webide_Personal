sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/ui/model/json/JSONModel"
	], function (Controller, JSONModel ) {
		"use strict";
		
		/**
		 * @class
		 * provide controller description 
		 */
		return Controller.extend("com.sap.cp.lm.controller.main.ShiftStatus", {
			
			//--------------------------------------------------------------------
			// Life cycle functions
			//--------------------------------------------------------------------
			
			/**
			 * Called when this controller is initialized
			 */
			onInit:function(){
				this._oViewModel = new JSONModel({					
				});
				this.getView().setModel(this._oViewModel, "viewProperties");				
			},	
			
			//--------------------------------------------------------------------
			// Private functions
			//--------------------------------------------------------------------
			
			/**
			 * Callback for successful retrieved shift status data
			 * @private
			 */
			_onFetchShiftStatusDataSuccess: function(oData){
				this._oViewModel.setProperty("/KPISet", oData.getData().results);
				this._oViewModel.setProperty("/busy", false);
			},		
			
			/**
			 * Trigger the fetch of current shift status data
			 * @private
			 */
			_fetchShiftStatusData: function(){
				//	MapDataModel.fetchShiftKPISet(this._onFetchShiftStatusDataSuccess, this);
			},
			
			//--------------------------------------------------------------------
			// Event handlers
			//--------------------------------------------------------------------
			
			/**
			 * Called before ShiftStatusPopover is opened
			 * @param {sap.ui.base.Event} [oEvent] the object with the event data
			 * @private
			 */			
			onBeforeOpen: function(oEvent) {		
				this._oViewModel.setProperty("/busy", true);
				this._fetchShiftStatusData();
			},			

			/**
			 * Called when the update of the list with shift KPIs is finished
			 * @private
			 */		
			onKPIListUpdateFinished: function() {
				this._oViewModel.setProperty("/busy", false);
				this.getView().openBy(this.getCaller());
			}
			
		});
});