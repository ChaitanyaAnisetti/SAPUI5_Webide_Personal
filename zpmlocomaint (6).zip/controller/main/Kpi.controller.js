/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.06                                           *
* Project        : Locomotive Maintenance                               *
* Description    : This controller is used for Key Performance          *
*                  Indicators dialog. Fetch KPI from backend and        *
*                  displays them.                                       *
*&----------------------------------------------------------------------*/

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/ErrorManager",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator",
	"sap/ui/model/json/JSONModel"
], function(Controller, ErrorManager, Constants, Formatter, BusyIndicator, JSONModel) {
	"use strict";
	
	var _this;

	return Controller.extend("com.sap.cp.lm.controller.main.Kpi", {
		
		//--------------------------------------------------------------------
		// Life cycle functions
		//--------------------------------------------------------------------
		
		/**
		 * Called when controller is instantiated
		 */
		onInit: function() {
			_this = this;
			
			//References
			_this._oKpiList = this.byId("kpiList");
			
			//Models
			_this._oDataModel = _this.getOwnerComponent().getModel(Constants.ZPMLM_MODEL);
			_this._oGlobalModel = _this.getOwnerComponent().getGlobalModel();

			//Avoid premature requests
			_this.getView().setModel(new JSONModel());
			_this._oKpiList.setModel(new JSONModel());
		},

		//--------------------------------------------------------------------
		// Controller methods that are used from other view controllers
		//--------------------------------------------------------------------
		
		/**
		 * Fetch and display the Kpi Items
		 */
		openPopover: function(oControl){
			_this._oKpiPopover = _this.byId("kpiPopover");
			
			//Load the dialog data
			_this._fetchKpiItems(_this._bindLinkTable);
			
			_this._oKpiPopover.openBy(oControl);
		},
		
		//--------------------------------------------------------------------
		// Private functions
		//--------------------------------------------------------------------
		
		/**
		 * Trigger Servicing KPI items fetch
		 */
		_fetchKpiItems: function(fSuccessCallBack) {
			var sShopId = _this._oGlobalModel.getProperty("/currentShop").Id;
			
			if(sShopId) {
				_this._oDataModel.read("/GetShopKPIs", {
					urlParameters: {
						"ShopId": "'" + sShopId + "'",
						"$format": "json"
					},
					success: function(oData) {
						if(fSuccessCallBack){
							fSuccessCallBack(oData.results);
						}
					},
					error: function(oError) {
						ErrorManager.handleError(oError);
					}
				});
			}
		},
		
		/**
		 * Bind the list to the odata model.
		 */
		_bindLinkTable: function(oData) {
			_this._oKpiList.setModel(new sap.ui.model.json.JSONModel(
			{
				KpiItems : oData
			}));
		},
		
		/**
		 * Formatter called from view, return color depending on status
		 */
		_graphicColorFormatter: function(sStatus) {
			var sColor = "#0ECC55";
			
			if(sStatus === "2") {
				sColor = "#FABD64";
			} else if(sStatus === "3") {
				sColor = "#BB0000";
			}
			
			return sColor;
		},
		
		/**
		 * Formatter called from view to convert string to float
		 */
		_convertStringToFloatFormatter: function(sValue) {
			var fValue = parseFloat(sValue);
			
			if(fValue <= 0) {
				fValue = 1;
			}
			
			return fValue;
		},
		
		//--------------------------------------------------------------------
		// Event handlers
		//--------------------------------------------------------------------
		
		/**
		 * Close the popover
		 */
		onKpiClose: function(){
			_this._oKpiPopover.close();
		}
		
	});
});