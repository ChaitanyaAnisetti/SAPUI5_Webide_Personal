/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.21                                           *
* Project        : Locomotive Maintenance                               *
* Description    : Controller for the Settings popover displayed        *
*                  when Settings icon is cliked on the navigation bar.  *
*&----------------------------------------------------------------------*/

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/main/DefaultSettingModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel"
], function(Controller, Constants, Formatter, BusyIndicator,
	DefaultSettingModel, Filter, FilterOperator, JSONModel) {
	"use strict";

	var _this;

	return Controller.extend("com.sap.cp.lm.controller.main.DefaultSetting", {
		
		//--------------------------------------------------------------------
		// Life cycle functions
		//--------------------------------------------------------------------
		
		/**
		 * Called when a controller is instantiated
		 */
		onInit: function() {
			_this = this;

			//Models
			this._oDataModel = this.getOwnerComponent().getModel(Constants.ZPMLM_MODEL);
			this._oGlobalModel = this.getOwnerComponent().getGlobalModel();

			//I18n model
			this._oI18nModel = this.getOwnerComponent().getModel("i18n");

			//Initialize the main model
			DefaultSettingModel.init(this.getOwnerComponent());

			//Avoid premature requests
			this.getView().setModel(new JSONModel());

			//the view properties model
			this._oViewPropertiesModel = new JSONModel();
			this._initViewPropertiesModel();
			this.getView().setModel(this._oViewPropertiesModel, "viewProperties");
		},

		//--------------------------------------------------------------------
		// Controller methods that are used from other view controllers
		//--------------------------------------------------------------------

		openPopover: function(oControl) {
			this._oDefaultSettingPopover = this.byId("defaultSettingPopover");

			//Reinitialize the view properties whenever this dialog is open
			this._initViewPropertiesModel();
			this._oDefaultSettingPopover.openBy(oControl);
		},
		
		//--------------------------------------------------------------------
		// Private functions
		//--------------------------------------------------------------------

		/**
		 * Create the view properties model for this view. 
		 */
		_initViewPropertiesModel: function() {
			var _oCurrentUser = this._oGlobalModel.getProperty("/currentUser");
			if (_oCurrentUser) {
				this._oViewPropertiesModel.setProperty("/SelectedDefaultRole", _oCurrentUser.DefaultRole);
				this._oViewPropertiesModel.setProperty("/SelectedDefaultShop", _oCurrentUser.DefaultShop);
				this._oViewPropertiesModel.setProperty("/ShowTechInfo", _oCurrentUser.ShowTechInfo);
			}

			this._oViewPropertiesModel.setProperty("/EnableDefaultShop", true);
		},
		
		//--------------------------------------------------------------------
		// Event handlers
		//--------------------------------------------------------------------

		/**
		 * Update default setting success
		 */
		onSettingModifySuccess: function() {
			// update the current user default settings
			var oCurrentUser = this._oGlobalModel.getProperty("/currentUser");
			oCurrentUser.DefaultRole   = this._oViewPropertiesModel.getProperty("/SelectedDefaultRole");
			oCurrentUser.DefaultShopId = this._oViewPropertiesModel.getProperty("/SelectedDefaultShop");
			oCurrentUser.ShowTechInfo  = this._oViewPropertiesModel.getProperty("/ShowTechInfo");
			this._oDefaultSettingPopover.close();

			//remove any role url parameters and reload the page
			var tempArray = location.href.split("?");
			
			location.href = tempArray[0];
		
		},

		/**
		 * Method called to perform the POST request
		 */
		onDefaultSettingSave: function() {
			var sDefaultRole = this._oViewPropertiesModel.getProperty("/SelectedDefaultRole");
			var sDefaultShop = this._oViewPropertiesModel.getProperty("/SelectedDefaultShop");
			var bViewTechIds = this._oViewPropertiesModel.getProperty("/ShowTechInfo");

			//Payload that will be sent to the oData service
			var oPayload = {
				DefaultRole: sDefaultRole,
				DefaultShop: sDefaultShop,
				ViewTechIds: bViewTechIds
			};

			DefaultSettingModel.updateSettings(oPayload, this.onSettingModifySuccess.bind(this));
		},

		/**
		 * Close the popover
		 */
		onDefaultSettingClose: function() {
			this._oDefaultSettingPopover.close();
		},
		
		onTechInfoSwitchChange: function(oEvent) {
			var bState = oEvent.getSource().getState();
			this._oGlobalModel.setProperty("/currentUser/ShowTechInfo", bState);
			this._oViewPropertiesModel.setProperty("/ShowTechInfo", bState);
		}
	});
});