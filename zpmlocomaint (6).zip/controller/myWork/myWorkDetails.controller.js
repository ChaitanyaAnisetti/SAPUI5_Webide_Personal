// #DontDelete : Daya New controller class , Do not delete any method in this class
/*&-----------------------------------------------------------------------*    
 * Author         : KIR0084                                              *
 * Date           : 2019.04.01                                           *
 * Incidinet      : LMP2-36 - Change to edit Comment Button        	     *
 * Description    : Change to edit Comment Button                 		 *
 * Search Term    : LMP2-36                                              *
 *&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 12-Oct-2021	                                       *
* Project             : LLM3.2 - Revison Number        					   *
* Description         : ERQ Serial Number and SW Revision number		   *
* Search Term         : LLM3.2	                                           *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 01-Dec-2021	                                       *
* Project             : EAM-LLM 1.2 Serialization     					   *
* Description         : Serialization of material and equipment			   *
* Search Term         : LLM1.2	                                           *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : ANI0006				        		       		   *
* Date                : 11-Nov-2021	                                       *
* Project             : EAM Railinc EPA    					               *
* Description         : EPA Information - Fields Masking		           *
* Search Term         : ANI0006 2000014601                                 *
/*&------------------------------------------------------------------------*/
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/util/ErrorManager",
	"com/sap/cp/lm/model/work/WorkDataModel",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
	"com/sap/cp/lm/util/Helper",
	"com/sap/cp/lm/controller/common/MeasPointSheet",
	"com/sap/cp/lm/controller/common/SerialNumber",
	"com/sap/cp/lm/controller/craft/CraftManager",
	"com/sap/cp/lm/controller/myShop/common/WorkOrderComments"
], function (Controller, Constants, Formatter, BusyIndicator, ErrorManager, WorkDataModel, LocomotiveDataModel, Helper, MeasPointSheet,
	SerialNumber, CraftManager, WorkOrderComments) {
	"use strict";

	var _this;

	return Controller.extend("com.sap.cp.lm.controller.myWork.myWorkDetails", {

		//--------------------------------------------------------------------
		// Life cycle functions
		//--------------------------------------------------------------------

		/**
		 * Initializes the controller
		 */
		onInit: function () {
			_this = this;
			this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
			// Added by ANI0006 2000014601 - get Engine Manfacture Model
			_this._oEngineManfModel = _this.getOwnerComponent().getEngManfJsonModel();
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());
			this._oRouter.getTargets().attachDisplay(function (oEvent) {
				if (oEvent.getParameter("name") === "MyWorkDetails") {
					_this.loadData();
				}
			});
		},

		//--------------------------------------------------------------------
		// Private functions
		//--------------------------------------------------------------------

		/**
		 * Get Work data and set model
		 */
		loadData: function () {
			var aData = this.getOwnerComponent().aMyWorkDetailsData;

			aData.checkedAll = false;
			aData.TaskSet.results.forEach(function (aTask) {
				var bChecked = false;

				if (aTask.Status === "0") {
					bChecked = true;
				}

				//add of removal
				//Will be removed after testing
				// aTask.MeasurementType = "2";
				//end of removal
				aTask.checked = bChecked;
			});

			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(aData);
			this.getView().setModel(oModel, "myWorkDetails");

			_this.getView().byId("CompleteTasksButton").setEnabled(false);
		},

		//----------------------------------------------------------------------
		// Private functions
		//----------------------------------------------------------------------

		/**
		 * Check/uncheck Select All Tasks checkbox depending on checked tasks
		 */
		setStateAllTaskCheckbox: function () {
			var bChecked = false;

			if ($('.lmWorkTaskCheckbox[aria-checked="true"]').length >= $('.lmWorkTaskCheckbox').length) {
				bChecked = true;
			}

			var oModel = _this.getView().getModel("myWorkDetails");
			var aMyWorkDetailsData = oModel.oData;

			aMyWorkDetailsData.checkedAll = bChecked;
		},

		/**
		 * Enable/disable Complete Tasks button depending on checked tasks
		 */
		setStateCompleteTasksButton: function () {
			var oModel = _this.getView().getModel("myWorkDetails");
			var aMyWorkDetailsData = oModel.oData;
			var oTasks = aMyWorkDetailsData.TaskSet.results;

			var oTasksFiltered = $.grep(oTasks, function (task) {
				return task.Status !== "0" && task.checked === true;
			});

			var bEnabled = oTasksFiltered.length > 0;

			_this.getView().byId("CompleteTasksButton").setEnabled(bEnabled);
		},

		/**
		 * Submit data to complete task
		 */
		onCompleteSelected: function () {
			var checkedTasks = $('.lmWorkTaskCheckbox[aria-checked="true"]:not(.lmWorkTaskCheckbox[aria-disabled="true"])');

			if (checkedTasks.length > 0) {
				var oPayload = {};
				var aConfirmationSet = [];

				$.each(checkedTasks, function (taskItemKey, taskItem) {
					var oTaskPayload = {};

					if ($(taskItem).data("ordernumber") && $(taskItem).data("operationnumber") && $(taskItem).data("suboperationnumber")) {
						oTaskPayload.OrderNumber = String($(taskItem).data("ordernumber"));
						oTaskPayload.OperationNumber = String($(taskItem).data("operationnumber"));
						oTaskPayload.SuboperationNumber = String($(taskItem).data("suboperationnumber"));

						aConfirmationSet.push(oTaskPayload);
					}
				});

				if (aConfirmationSet.length > 0) {
					var fnCompleteSelected = function (successCallback) {
						var oPayload = {};
						oPayload.ConfirmationSet = aConfirmationSet;
						WorkDataModel.completeTasks(successCallback, _this.onCompleteTaskError, _this, oPayload);
					}.bind(this);
				}

				if (checkedTasks.length === 0) {
					var oSelContext = this.getOwnerComponent().oMyWorkCurrentContext;
					CraftManager.onEndWorkforOperation(oSelContext, this, true, fnCompleteSelected);
				} else {
					fnCompleteSelected(function () {});
				}
			} else {
				ErrorManager.handleError("", "You must select at least one task.");
			}
		},

		_openWheelSheet: function (oWSHeader) {
			if (!_this.WSSaveBtnId) {
				_this.WSSaveBtnId = this.createId("WSSaveBtn");
			}

			if (!_this.WSSubmitBtnId) {
				_this.WSSubmitBtnId = this.createId("WSSubmitBtn");
			}

			if (!this.oDialog) {
				this.oDialog = new sap.m.Dialog({
					title: oWSHeader.Descr,
					height: "100%",
					width: "100%",
					content: [],
					buttons: [
						new sap.m.Button({
							text: "{i18n>CLOSE}",
							press: function () {
								_this.oDialog.close();
							}
						}),
						new sap.m.Button(_this.WSSaveBtnId, {
							text: "{i18n>SAVE}",
							press: function () {
								var oController = _this.oDialog.getContent()[0].getController();
								oController.onSaveWheelSheet();
							}
						}),
						new sap.m.Button(_this.WSSubmitBtnId, {
							text: "{i18n>SUBMIT}",
							enabled: false,
							type: "Emphasized",
							press: function () {
								var oController = _this.oDialog.getContent()[0].getController();
								oController.onSubmitWheelSheet();
							}
						})
					],
					afterOpen: this.resizeDialog
				});

				this.wheelSheetDialogId = this.oDialog.sId;

				var oContent = new sap.ui.xmlview({
					viewName: "com.sap.cp.lm.view.myShop.common.wheelSheet.WheelSheet"
				});

				this.oDialog.addContent(oContent);
			}

			var oCurrentLocomotive = this._oGlobalModel.getProperty("/currentLocomotive");

			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setProperty("/WSHeader", oWSHeader);
			oModel.setProperty("/WSSaveBtnId", _this.WSSaveBtnId);
			oModel.setProperty("/WSSubmitBtnId", _this.WSSubmitBtnId);
			this.oDialog.setModel(oModel);
			this.getView().addDependent(this.oDialog);
			this.oDialog.open();

			var oController = this.oDialog.getContent()[0].getController();
			oController.fetchLocomotiveWheelSheet(oCurrentLocomotive);
		},

		resizeDialog: function () {
			var frameHeight = $(window).height();
			var frameWidth = $(window).width();

			this.setContentHeight(frameHeight * 0.75 + "px");
			this.setContentWidth(frameWidth * 0.75 + "px");
		},

		openMeasPoint: function (oWSHeader) {
			var aData = {};
			aData.oTaskHeader = oWSHeader;
			aData.oTaskHeader.oSourceViewController = this;
			var oMeasPointDialog = new MeasPointSheet(aData);

			var i18nModel = this.getOwnerComponent().getModel("i18n");
			oMeasPointDialog.getFragment().setModel(i18nModel, "i18n");
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oMeasPointDialog);
			oMeasPointDialog.getFragment().open();
		},

		openSerialNo: function (oWSHeader) {
			var aData = {};
			aData.oTaskHeader = oWSHeader;
			aData.oTaskHeader.oSourceViewController = this;
			var oSerialNoDialog = new SerialNumber(aData);
			var i18nModel = this.getOwnerComponent().getModel("i18n");
			oSerialNoDialog.getFragment().setModel(i18nModel, "i18n");

			// Added by  ANI0006 2000014601 - Engine Manufacture model 
			if (!_this._oEngineManfModel && _this.getOwnerComponent()) {
				_this._oEngineManfModel = _this.getOwnerComponent().getEngManfJsonModel();
			}
			/* Start - ANI0006 2000014601 - _oEngineManfModel undefined so replace with _oEngineManfModel */
			oSerialNoDialog.getFragment().setModel(_this._oEngineManfModel, "GLOBALENGINEMANFMODEL");
			/* End - ANI0006 2000014601 - _oEngineManfModel undefined so replace with _oEngineManfModel */

			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oSerialNoDialog);
			oSerialNoDialog.getFragment().open();
		},

		//----------------------------------------------------------------------
		// Event handlers
		//----------------------------------------------------------------------

		/**
		 * Display My Work view
		 */
		onNavBack: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(_this);
			window.setTimeout(function () {
				oRouter.getTargets().display("MyWork");
			}, 0);
		},

		/**
		 * Event fired when a task is selected
		 */
		onTaskCompleteChecked: function (oEvent) {
			_this.setStateCompleteTasksButton();

			_this.setStateAllTaskCheckbox();
		},

		// #DontDelete : Q
		/**
		 * Open long text dialog on button click
		 */
		onClickLongTextOpen: function (oEvent) {
			var sBindingPath = oEvent.getSource().getBindingContext("myWorkDetails").sPath;

			if (sBindingPath) {
				var oDataObject = _this.getView().getModel("myWorkDetails").getObject(sBindingPath);
				Helper.openLongTextDialog(oDataObject);
			}
		},

		/** START KIR0084 LMP2-36 Allow adding of sub-operation long text. */
		onClickCommentOpen: function (oEvent) {
			var oParams = {};
			oParams.oWorkOrderHeader = oEvent.getSource().getBindingContext("myWorkDetails").getObject();
			oParams.fnFirstCommentAdded = _this._fetchAndRefreshView.bind(_this);

			var oWorkOrderComments = new WorkOrderComments(oParams);
			if (!_this._oI18nModel && _this.getOwnerComponent()) {
				_this._oI18nModel = _this.getOwnerComponent().getModel("i18n");
			}
			oWorkOrderComments.getFragment().setModel(_this._oI18nModel, "i18n");
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oWorkOrderComments);
			oWorkOrderComments.getFragment().open();
		},

		/** 
		 * Refresh the data on the current page 
		 */
		_fetchAndRefreshView: function () {
			var oCurrentUser = this._oGlobalModel.getProperty("/currentUser");
			var oCurrentShop = this._oGlobalModel.getProperty("/currentShop");

			LocomotiveDataModel.fetchMyWork(_this.onSuccessCraftWork, "", _this, oCurrentShop.Id, oCurrentUser.PersonnelNumber);
		},

		onSuccessCraftWork: function (oData) {
			// Setup model data and refresh view
			var oModel = new sap.ui.model.json.JSONModel();
			var aData = {};
			aData.WorkList = oData.results;
			aData.operationsListType = "Navigation";

			oModel.setData(aData);
			var oSelContext = this.getOwnerComponent().oMyWorkCurrentContext;
			var aDetails = oModel.getObject(oSelContext.sPath);
			this.getOwnerComponent().aMyWorkDetailsData = aDetails;
			_this.loadData();
		},
		/** END KIR0084 LMP2-36 Allow adding of sub-operation long text. */

		/**
		 * Event fired when Select All Task is checked
		 */
		onSelectAllTaskChecked: function (oEvent) {
			var bChecked = oEvent.getParameter("selected");

			var oModel = _this.getView().getModel("myWorkDetails");
			var aMyWorkDetailsData = oModel.oData;

			aMyWorkDetailsData.TaskSet.results.forEach(function (aTask) {
				if (aTask.Status !== "0") {
					aTask.checked = bChecked;
				}
			});

			_this.setStateCompleteTasksButton();
		},

		/**
		 * Return to My Work view on Complete Tasks request success
		 */
		onCompleteTaskSuccess: function () {
			var oSelContext = this.getOwnerComponent().oMyWorkCurrentContext;
			var oSelObject = oSelContext.getObject();
			var unCheckedTasks = $('.lmWorkTaskCheckbox[aria-checked="false"]:not(.lmWorkTaskCheckbox[aria-disabled="true"])');

			var endWorkFn = function () {
				if (unCheckedTasks.length === 0) {
					CraftManager.onEndWorkforOperation(oSelContext, this, true);
				}
			};

			if (!oSelObject.InProgressInd) {
				var oPayload = CraftManager.prepareBeginOperationPayload(oSelObject);
				LocomotiveDataModel.ConfirmOperation(oPayload, endWorkFn.bind(this), _this.onCompleteTaskError, _this);
			} else {
				endWorkFn.call(this);
			}
		},

		/**
		 * KIR0084 Requires callback function to return to main screen instead of refreshign
		 */
		refreshMyWork: function () {
			_this.onNavBack();
		},

		/**
		 * Display an error if there is a problem with Complete Task request
		 */
		onCompleteTaskError: function (oError) {
			ErrorManager.handleError(oError);
		},

		/**
		 * Open the Wheel Sheet Dialog
		 */
		onClickCreateWS: function (oEvent) {

			var aSelObject = oEvent.getSource().getBindingContext("myWorkDetails").getObject();
			var oSelOperation = oEvent.getSource().getModel("myWorkDetails").getData();
			var oWSHeader = {
				"OperationNbr": oSelOperation.Activity,
				"OrderNbr": oSelOperation.OrderNo,
				"SubOperNbr": aSelObject.SubOp,
				"EquipNbr": oSelOperation.EquipNo,
				"MsetType": aSelObject.MeasurementSetType,
				"MeasPntValue": aSelObject.MeasPntValue,
				"MeasurementPointName": aSelObject.MeasurementPointName,
				"InstallPosition": aSelObject.InstallPosition,
				"SerialNbr": aSelObject.SerialNbr.trim(), // SHE0272 - LLM3.2 - Trimmed Space from Serial Number
				// Start - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
				"ObjectType": aSelObject.ObjectType,
				"Room": aSelObject.Room,
				"SoftwareCharacteristic": aSelObject.SoftwareCharacteristic,
				"SoftwareClass": aSelObject.SoftwareClass,
				"MeasurementType": aSelObject.MeasurementType,
				// End - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
				// Start - SHE0272 - LLM1.2 - Serialization
				// "GoodsIssueAndReturn": aSelObject.GoodsmvtIndi,
				// "Plant": this._oGlobalModel.getProperty("/currentShop/Id"),
				// "SerializedMaterial": aSelObject.SerializedMatnr,
				// "UserRole": this._oGlobalModel.getProperty("/role"),
				// End - SHE0272 - SHE0272 - LLM1.2 - Serialization
				// Start - EPA Information_Serial Number mask inputs
				"Measurement": aSelObject.Measurement
					// End - EPA Information_Serial Number mask inputs
			};

			switch (aSelObject.MeasurementType) {
			case Constants.MEASTYPE.WHEEL_SHEET:
				_this._openWheelSheet(oWSHeader);
				break;
			case Constants.MEASTYPE.MS_MEGAWATT_HOUR_A:
				_this.openMeasPoint(oWSHeader);
				break;
			case Constants.MEASTYPE.SERIALNUMBER:
				_this.openSerialNo(oWSHeader);
				break;
				// Start - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
			case Constants.MEASTYPE.SW_VERSION_NUMBER:
				_this.openSerialNo(oWSHeader);
				break;
				// End - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
				// Start - SHE0272 - LLM1.2 - Serialization
			// case Constants.MEASTYPE.SERIALIZATION_NUMBERR:
			// 	_this.openSerialNo(oWSHeader);
			// 	break;
				// End - SHE0272 - LLM1.2 - Serialization
				// Start - ANI0006 2000014601 - EPA Information_Serial Number mask inputs * Case 6
			case Constants.MEASTYPE.EPA_INFORMATION:
				_this.openSerialNo(oWSHeader);
				break;
				// End - ANI0006 2000014601 - EPA Information_Serial Number mask inputs  * Case 6
			}
		},

		//----------------------------------------------------------------------
		// Formatter functions
		//----------------------------------------------------------------------

		/**
		 * Display/hide Select All Tasks Checkbox if there are checkboxes to check or no
		 */
		formatVisibilitySelectAllCheckbox: function (oTasks) {
			var oTasksFiltered = $.grep(oTasks, function (task) {
				return task.Status !== "0";
			});

			return oTasksFiltered.length > 0;
		},

		formatVisibileSelection: function (oTasks) {
			return true;
		}

	});
});