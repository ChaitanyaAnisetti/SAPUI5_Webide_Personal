/** #Donot Delete Dayakar : New controller all methods are valid**/
/*&-----------------------------------------------------------------------*    
* Author/Changed By   : Sandesh Shirode(SHI0087)	               		  *
* Date                : 15-April-2019                                     *
* Project             : Locomotive Maintenance Phase 2                    *
* Description         : LMP2-7a : Add attachment functionality to be view *
						from OPeration screen							  *
*&------------------------------------------------------------------------*/ 
/*&-----------------------------------------------------------------------*    
 * Author         : KIR0084                                              *
 * Date           : 2019.04.01                                           *
 * Incidinet      : LMP2-36 - Change to edit Comment Button        	     *
 * Description    : Change to edit Comment Button                 		 *
 * Search Term    : LMP2-36                                              *
*&------------------------------------------------------------------------*/ 
/*&-----------------------------------------------------------------------*    
 * Author         : VYA0004                                              *
 * Date           : 4-Oct-2019                                           *
 * Incident      : LLM3.3 - Adding new pop for Materials        	     *
 * Description    : Adding popup to issue/reserve Materials before end of work*
 * Search Term    : VYA0004|LLM3.3                                       *
*&------------------------------------------------------------------------*/ 
sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"com/sap/cp/lm/util/Constants",
		"com/sap/cp/lm/util/Formatter",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
		"com/sap/cp/lm/model/craft/CraftDataModel",
		"com/sap/cp/lm/controller/locomotives/LocomotiveManager",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"sap/ui/model/json/JSONModel",
		"com/sap/cp/lm/util/ErrorManager",
	    "com/sap/cp/lm/controller/myShop/common/WorkOrderComments",
		"com/sap/cp/lm/controller/myShop/shopped/addMaterial/AddMaterial",
		"com/sap/cp/lm/controller/craft/CraftManager",
		"com/sap/cp/lm/util/Helper",
		"com/sap/cp/lm/controller/myShop/common/workplan/RequestMatDialog",
		"com/sap/cp/lm/model/material/MaterialModel",
		"sap/m/MessageBox",
	    "com/sap/cp/lm/controller/myShop/common/OperationLongTextDialog"
	],

	function(Controller, Constants, Formatter, BusyIndicator, LocomotiveDataModel, CraftDataModel, LocomotiveManager, Filter, FilterOperator,
		JSONModel, ErrorManager, WorkOrderComments, AddMaterial, CraftManager, Helper, RequestMatDialog, MaterialModel, MessageBox, OperationLongTextDialog) {
		"use strict";
		var _this;

		return Controller.extend("com.sap.cp.lm.controller.myWork.MyWork", {

			//--------------------------------------------------------------------
			// Life cycle functions
			//--------------------------------------------------------------------

			onInit: function() {
				_this = this;
				this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
				this._oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());
				this._sShopId = null;
				this._bHideComplete = false;
                this._oGlobalModel.setProperty("/oMyWorkController", this);
				// this.getRevisionTypeModel();
				// this.setTimeForDatefield();
				this._oRouter.getTargets().attachDisplay(function(oEvent) {
					if (oEvent.getParameter("name") === "MyWork") {
						 /* KIR0084 LMP2-36 Ensure this read is treated as Work Order list not Work Order History List */
						 _this._oGlobalModel.setProperty("/readFromWOHistory", false);
						 /* KIR0084 LMP2-36 */
						_this.refreshMyWork(true);
						_this.initSelectionMode();
					}
				});

				var binding = new sap.ui.model.Binding(this._oGlobalModel, "/", this._oGlobalModel.getContext("/"));
				binding.attachChange(function() {
					if (_this._oGlobalModel.getProperty("/currentShop")) {
						if (_this._oGlobalModel.getProperty("/sSelectedView") === Constants.MYWORK && _this._oGlobalModel.getProperty("/currentShop").Id !==
							_this._sShopId) {
							_this.refreshMyWork(false);
						}
					}
				});
			},

			//----------------------------------------------------------------------
			// Private functions
			//----------------------------------------------------------------------

			/**
			 * Load the data of operations table depending on shop and user
			 */
			refreshMyWork: function(bForceRefresh) {
				var oCurrentUser = this._oGlobalModel.getProperty("/currentUser");
				var oCurrentShop = this._oGlobalModel.getProperty("/currentShop");
				if (oCurrentShop) {
					if (_this._sShopId !== oCurrentShop.Id || bForceRefresh === true) {
						this._sShopId = oCurrentShop.Id;

						//useful hardcoded test craft 
						//LocomotiveDataModel.fetchMyWork(_this.onSuccessCraftWork, _this.onErrorCraftWork, _this, '1883', '00824129'); //00978304 //510061

						LocomotiveDataModel.fetchMyWork(_this.onSuccessCraftWork, _this.onErrorCraftWork, _this, oCurrentShop.Id, oCurrentUser.PersonnelNumber);
					}
				}
			},
			
			initSelectionMode: function(){
				var oTable = this.getView().byId("myWorkPage").getContent()[0].getContent()[0];
				if(oTable){
					oTable.setMode("None");
				}
			},
			
			refreshCompleteToggle: function() {
				var sFragmentId = this.getView().createId("idMyOperations");

				//update table rows
				var oTable = sap.ui.core.Fragment.byId(sFragmentId, "idCraftOperations");
				var aItems = oTable.getItems();
				var oModel = oTable.getModel("craftOperations");

				for (var i = 0; i < aItems.length; i++) {
					var oItem = aItems[i];
					var oObject = oModel.getProperty("/WorkList/" + i);
					var bHide = false;

					if (oObject.Status === "0" && this._bHideComplete) {
						bHide = true;
					}

					if (bHide === true) {
						oItem.addStyleClass("lmHidden");
					} else {
						oItem.removeStyleClass("lmHidden");
					}
				}

				//update button
				var oButton = sap.ui.core.Fragment.byId(sFragmentId, "ToggleCompleteButton");
				if (!this._bHideComplete) {
					oButton.setText("Hide Complete");
				} else {
					oButton.setText("Show All");
				}
			},

			//----------------------------------------------------------------------
			// Event handlers
			//----------------------------------------------------------------------

			onAfterRendering: function() {
				this.refreshMyWork(false);
			},

			/**
			 * Set the view model with data
			 */
			onSuccessCraftWork: function(oData) {
				BusyIndicator.hideBusyIndicator();
				var oModel = new sap.ui.model.json.JSONModel();
				var aData = {};
				aData.WorkList = oData.results;
				aData.operationsListType = "Navigation";
				
				oModel.setData(aData);
				
				this.getView().setModel(oModel, "craftOperations");
				_this.refreshCompleteToggle();
			},

			onErrorCraftWork: function() {

			},

			onMATRequest: function(oEvent) {
				var oParams = {};
				var oMessage = {};

				var oSelectedOperation = _this._selectedContext.getObject();
				var oSelMat = oEvent.getSource().getBindingContext().getObject();
				 
				oMessage.LocoID = oSelectedOperation.LocoId;
				oMessage.OperationNo = oSelectedOperation.Activity;
				oMessage.OperationDescr = oSelectedOperation.Descr;
				oMessage.MaterialDesc = oSelMat.Descr;
				oMessage.MaterialCode = oSelMat.MaterialNo;
				oMessage.Sender = this._oGlobalModel.getProperty("/currentUser").UserId;
				oMessage.ShopNo = this._oGlobalModel.getProperty("/currentShop").Id;
				oMessage.ShopName = this._oGlobalModel.getProperty("/currentShop").Name;
				oMessage.sOrderNo = oSelectedOperation.OrderNo;
				oMessage.sOrderDesc = oSelectedOperation.OrderDescr;
				oParams.oMessage = oMessage;

				var oRequestMatDialog = new RequestMatDialog(oParams);
				var i18nModel = this.getOwnerComponent().getModel("i18n");
				oRequestMatDialog.getFragment().setModel(i18nModel, "i18n");
				oRequestMatDialog.getFragment().setModel(_this._oGlobalModel, "global");

				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oRequestMatDialog);
				oRequestMatDialog.getFragment().open();
			},

			/**
			 * Fired when an operation is selected
			 */
			onClickMyWorkOperation: function(oEvent) {
				var oSelContext = oEvent.getSource().getBindingContext("craftOperations");
				var aDetails = this.getView().getModel("craftOperations").getObject(oSelContext.sPath);
				this.getOwnerComponent().aMyWorkDetailsData = aDetails;
				this.getOwnerComponent().oMyWorkCurrentContext = oSelContext;
				var oRouter = sap.ui.core.UIComponent.getRouterFor(_this);

				window.setTimeout(function() {
					oRouter.getTargets().display("MyWorkDetails", _this.refreshMyWork);
				}, 0);
			},

			// #DontDelete : Q
			/**
			 * Open long text dialog on button click
			 */
			onClickLongTextOpen: function(oEvent) {
				var sBindingPath = oEvent.getSource().getBindingContext("craftOperations").sPath;

				if (sBindingPath) {
					var oDataObject = _this.getView().getModel("craftOperations").getObject(sBindingPath);
					Helper.openLongTextDialog(oDataObject);
				}
			},
			/* VYA0004|LLM3.3 Begin*/ 
		 onReserveMaterialDialogOpen: function (oEvent) {
			BusyIndicator.showBusyIndicator();
            var oParam = oEvent.getSource().getBindingContext("craftOperations").getObject();
			var sOrderId = oParam.OrderNo;
			var sShopId = oParam.Shop;
			_this.oResMatModel = new sap.ui.model.json.JSONModel();
			MaterialModel.fetchReserveMatDetails(sOrderId, sShopId, this, oParam.Activity);
			if (!_this._oReserveMaterialDialog) {
				_this._oReserveMaterialDialog = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.shopped.addMaterial.MyWorkReserveMaterial",
					_this
				);
			}
			_this._oReserveMaterialDialog.setModel(_this.oResMatModel, "oResMatModel");
			
			var i18nModel = new sap.ui.model.resource.ResourceModel({
				bundleName: "com.sap.cp.lm.i18n.i18n"
			});
            _this.oModel = new sap.ui.model.json.JSONModel();
			_this.oModel.setProperty("/DefaultOperation", oParam.Activity);
			_this.oModel.setProperty("/SelectedOrder", sOrderId); // LMP2-8a
			_this.oModel.setProperty("/SelectedShop", sShopId); // LMP2-8a
			_this.oModel.setProperty("/OpNode", oParam.OpNode);
			_this.oModel.setProperty("/RoutingNo", oParam.RoutingNo);
			_this.oModel.setProperty("/LocoId", oParam.LocoId);
			_this.oModel.setProperty("/FromEndWork", false);
			_this.oModel.setProperty("/FromShoppingCart", true);
			_this.oModel.setProperty("/btnText", "Process Picklist");
			_this._oReserveMaterialDialog.setModel(_this.oModel);
			MaterialModel.FetchBNBMaterial(_this); // SHE0272 - LLMBNB3.0
            
			// Reset dialog content
			sap.ui.getCore().byId("mwaddMaterialSearchBar").setValue("");
            
			_this._oReserveMaterialDialog.setModel(i18nModel, "i18n");
			sap.ui.getCore().byId("mwIconTabResMat").setSelectedKey("mwpicklist");
			
			
			_this._oReserveMaterialDialog.open();
			BusyIndicator.hideBusyIndicator();
		},
		onSearchMaterial: function (oEvent) {
			var sQuery = oEvent.getSource().getValue();

			var sShopId = _this._oGlobalModel.getProperty("/currentShop").Id;
			// Start - SHE0272 - LLMBNB3.0 - Added a new bnbFilter to pass in the service call
			var bnbFilter = "";
			if (!_this._oGlobalModel.getProperty("/currentLocomotive/BnbLoco")) {
				bnbFilter = _this.oModel.getProperty("/BNBMaterial");
			}
			// End - SHE0272 - LLMBNB3.0 - Added a new bnbFilter to pass in the service call
			MaterialModel.fetchCpPartNumber(sQuery, sShopId, _this._initializeTable, null, _this, bnbFilter);

		},

		/*
		 * Initialize table and model
		 */
		_initializeTable: function (oCpPartNumberData) {
			_this.oModel.setProperty("/CpPartNumbers", oCpPartNumberData.results);
			_this._oReserveMaterialDialog.setModel(_this.oModel);
		},

		onSelectResMat:function (oEvent) {
            var sSelectKey = oEvent.getParameter("key");
			if(sSelectKey === "mwaddmaterial"){
			// if user is on Add Materials tab	
			_this.oModel.setProperty("/btnText", "Process Material");
			}else{
				if(sSelectKey === "mwpicklist"){
			// if user is on Picklist tab	
			_this.oModel.setProperty("/btnText", "Process Picklist");
				}
			}
		},
		
		onMyWorkResMatDialogClose:function (oEvent) {
			     sap.ui.getCore().byId("mwIconTabResMat").setSelectedKey("mwpicklist");
			     _this._oReserveMaterialDialog.close();
 				_this._oReserveMaterialDialog.destroy();
 				_this._oReserveMaterialDialog = null;
 			},  
 			onMyWorkResMatDialogProcess:function (oEvent) {
 			var sProcessKey = sap.ui.getCore().byId("mwIconTabResMat").getSelectedKey();
 			if (sProcessKey === "mwpicklist"){
 			//Picklist Process Begin	
 			var aReserveMatItems = _this.oResMatModel.getProperty("/ReserveMat");
			var aPayloads = [];
			var oLoad = {};
			var isValid = "true";
			var aReserveMatTable = sap.ui.getCore().byId("mwIssueResTbl").getItems();
		  if (aReserveMatTable.length > 0) {
				var iRowIndex = 0,
					iRowCounter = 0;
				while (iRowIndex < aReserveMatTable.length) {
					//LLM3.3 Updated Cell number from 6 to 7 and 8 to 9 to adjust for Charged Qty field.
					oLoad.WithdrawnQty = aReserveMatTable[iRowIndex].getCells()[8].getValue(); // Issue
					oLoad.SerialNum = aReserveMatTable[iRowIndex].getCells()[9].getValue();
					oLoad.Bwart = aReserveMatItems[iRowIndex].Bwart;
					oLoad.By = aReserveMatItems[iRowIndex].By; // Using this field to let Backend know that to put this value into BATCH field of BAPI
					oLoad.ConfirmedQty = aReserveMatItems[iRowIndex].ConfirmedQty; // Available
					oLoad.StorageLoc   = aReserveMatItems[iRowIndex].StorageLoc;   // ij1
					oLoad.Descr = aReserveMatItems[iRowIndex].Descr;
					oLoad.Dmbtr = aReserveMatItems[iRowIndex].Dmbtr;
					oLoad.ItemNo = aReserveMatItems[iRowIndex].ItemNo;
					oLoad.MaterialNo = aReserveMatItems[iRowIndex].MaterialNo;
					oLoad.OpNode = aReserveMatItems[iRowIndex].OpNode;
					oLoad.QtyUom = aReserveMatItems[iRowIndex].QtyUom;
					oLoad.RequiredQty = aReserveMatItems[iRowIndex].RequiredQty; //  Reserve Qty
					oLoad.RoutingNo = aReserveMatItems[iRowIndex].RoutingNo;

					// Validate if issue qty is GREATER than Available Qty  	
					if (parseInt(oLoad.WithdrawnQty, 10) > parseInt(oLoad.ConfirmedQty, 10)) { // SHE0272 - Chnaged from string compare to integer check - INC0110700   

						ErrorManager.handleError("", "Material(s) Cannot be issued greater than available Quantity");
						isValid = "false";
					}

					// This condition is to avoid additional check at backend and reduce additional traffic on batch request
					if (oLoad.WithdrawnQty > 0) {
						aPayloads[iRowCounter] = oLoad;
						iRowCounter++;
					}
					oLoad = {}; // clear the workarea
					iRowIndex++;
				}
			}
			if (isValid === "true" && aPayloads.length > 0 ) {
				MaterialModel.AddReserveMaterial(aPayloads, _this, _this.fnSuccessMWAddMat);
			}else{
				ErrorManager.handleError("", "No material selected to issue.Please enter quantity to process picklist.");
			}

 			}
 			//Picklist Process End.
 				else{
 			//Begin Add Material		
 			var oFormData = _this._validateForm();
			if (oFormData.isValid) {
				// Start LMP2-8a Check the Confirmation if user is ready to submit the Add material ( Issue/Reserve request )
				MessageBox.show(oFormData.oPayload.WithdrawnQty + " Material(s) will be issued and " +
				oFormData.oPayload.RequiredQty + " Material(s) will be reserve. Continue ?", {
				icon: MessageBox.Icon.CONFIRM,
				title: "Do you want to Continue?",
				actions: [MessageBox.Action.CANCEL, MessageBox.Action.OK],
				onClose: function (oEvent1) {
					if (oEvent1 === MessageBox.Action.OK) {
					_this._submitData(oFormData.oPayload);
			      }
				}
					});
					
			}
			}//End Add Material Process
 			},
 			fnSuccessMWAddMat: function(oContext, oData){
 			var sFromSC = _this.oModel.getProperty("/FromShoppingCart");
			var sFromEW = _this.oModel.getProperty("/FromEndWork");	
 			_this.oModel.setProperty("/FromShoppingCart", false);
		   	_this.oModel.setProperty("/FromEndWork", false);
	        if(sFromSC === false && sFromEW === true && _this.oSelContext){
			  //Call time entry
				CraftManager.onEndWorkforOperation(_this.oSelContext, this);
			     }	
 			},
 		/*
		 * Close dialog and launch refresh of context view
		 */
		_endSubmitOnSuccess: function (oResponse) {
			_this._oReserveMaterialDialog.close();
			if (_this._fReloadOwnerView && _this._oContext) {
				_this._fReloadOwnerView.apply(_this._oContext, null);
			}
            sap.m.MessageBox.success("Record(s) processed successfully!");
            var sFromSC = _this.oModel.getProperty("/FromShoppingCart");
			var sFromEW = _this.oModel.getProperty("/FromEndWork");
			//Reset following values
			_this.oModel.setProperty("/FromShoppingCart", false);
			_this.oModel.setProperty("/FromEndWork", false);
			_this._oReserveMaterialDialog.close();
			if(sFromSC === false && sFromEW === true && _this.oSelContext){
			    //Call time entry
				CraftManager.onEndWorkforOperation(_this.oSelContext, this);
			}
		},
		
 			_validateForm: function () {
 			var isValid = true;
			var oPayload = {};
			var oReturn = {};

			var sOperation = _this.oModel.getProperty("/DefaultOperation");
            
			oPayload.RoutingNo = _this.oModel.getProperty("/RoutingNo");
			oPayload.OpNode = _this.oModel.getProperty("/OpNode");
					var iRowIndex = 0;
					var iCountSelectedRow = 0;
					var oMaterialsTable = sap.ui.getCore().byId('mwmaterialsTable'),
						aMaterialItems = oMaterialsTable.getItems();
					var aMatList = _this.oModel.getProperty("/CpPartNumbers"); // Get all the records of material

					if (aMaterialItems.length > 0) {
						while (iRowIndex < aMaterialItems.length) {
							var oCurrentMat = aMatList[iRowIndex];
							var oMaterialItem = aMaterialItems[iRowIndex];
							var oMaterialItemContext = oMaterialItem.getBindingContext();
							var oMaterialItemObj = oMaterialItemContext.getObject();
							var oMaterialItemAggregations = oMaterialItem.mAggregations;

							if (oMaterialItemAggregations) {
								var oMaterialItemQuantityCell = oMaterialItemAggregations.cells[8];
								var oMaterialSerialNumCell = oMaterialItemAggregations.cells[9];
								if (oMaterialItemQuantityCell) {
									var iMaterialItemQuantity = oMaterialItemQuantityCell._lastValue;

									if (iMaterialItemQuantity > 0) {
										iCountSelectedRow++;
										var iAvailableQty = oMaterialItemObj.Available;
										var iIssueQty = iMaterialItemQuantity - iAvailableQty;
										if (iIssueQty > 0) {
											oPayload.WithdrawnQty = iAvailableQty; // Qty to be issued
											oPayload.RequiredQty = iIssueQty.toString(); // Reserve Qty
										} else {
											oPayload.WithdrawnQty = iMaterialItemQuantity;
											oPayload.RequiredQty = "0";
										}
										var sSerialNumTxt = oMaterialSerialNumCell._lastValue;
										if (sSerialNumTxt.length > 0) {
											oPayload.SerialNum = sSerialNumTxt;
										}
										oPayload.MaterialNo = oMaterialItemObj.MaterialNo;
										if (oCurrentMat.ValType.length > 0) {
											oPayload.By = oCurrentMat.ValType; // For backend to determine valution type from this field
										}

										oPayload.QtyUom = oMaterialItemObj.UOM;
										oPayload.Descr = oMaterialItemObj.Description;
										oPayload.StorageLoc = oMaterialItemObj.Sloc;					//ASR3414893
									}
								}
							}

							iRowIndex++;
						}

						if (iCountSelectedRow > 1) {
							isValid = false;
							ErrorManager.handleError("", "Fill quantity only for one material row.");
						} else if (iCountSelectedRow !== 1) {
							isValid = false;
							ErrorManager.handleError("", "Fill quantity for choosed material.");
						}
					} else {
						isValid = false;
						ErrorManager.handleError("", "No material to add. Search material with OEM Part Number/Material Number/Material Description.");
					}
			if (isValid) {
				$.each(oPayload, function (index, value) {
					if (isValid) {
						if (!value || value.length === 0) {
							isValid = false;
							ErrorManager.handleError("", "Please fill in all fields.");
						}
					}
				});
			}

			oReturn.isValid = isValid;
			oReturn.oPayload = oPayload;

			return oReturn;
 			},
 			//No Material Required Reason
 			onMyWorkNoMatRequired: function(oEvent){
 			_this._oReserveMaterialDialog.close();	
 			_this.oNoMatReqModel = new sap.ui.model.json.JSONModel();
			if (!_this._oNoMatReqDialog) {
				_this._oNoMatReqDialog = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.shopped.addMaterial.NoMaterialRequired",
					_this
				);
			}
			_this._oNoMatReqDialog.setModel(_this.oResMatModel);
			var i18nModel = new sap.ui.model.resource.ResourceModel({
				bundleName: "com.sap.cp.lm.i18n.i18n"
			});
			_this._oNoMatReqDialog.setModel(i18nModel, "i18n");
			_this._oNoMatReqDialog.open();
			BusyIndicator.hideBusyIndicator();
 			},
 			onMWNoMatReqDialogClose:function (oEvent){
 				_this.oModel.setProperty("/FromShoppingCart", false);
				_this.oModel.setProperty("/FromEndWork", false);
 				_this._oNoMatReqDialog.close();
 			},
 			onMWNoMatReqReasonSave:function (oEvent){
			var oPayload = {};
			oPayload.Reason = sap.ui.getCore().byId("inputmyWorkNoMatReason").getProperty("value");
			if(oPayload.Reason.length > 0){
			oPayload.LocoId = _this.oModel.getProperty("/LocoId");
			oPayload.Workorder = _this.oModel.getProperty("/SelectedOrder");
			oPayload.Operation = _this.oModel.getProperty("/DefaultOperation");
			//Call method to save the reason in custom table
			MaterialModel.SaveNoMaterialReqReason(oPayload, _this, _this.fnSuccessMWAddMat);
			var sFromSC = _this.oModel.getProperty("/FromShoppingCart");
			var sFromEW = _this.oModel.getProperty("/FromEndWork");
			if(sFromSC === false && sFromEW === true){
				//Call End work screen
				_this._oNoMatReqDialog.close();
			}else{
				_this.oModel.setProperty("/FromShoppingCart", false);
				_this.oModel.setProperty("/FromEndWork", false);
			}
 			}else{
 				//User clicked Save without entering and reason, give error
 					ErrorManager.handleError("", "Please fill in all fields.");
 			}
 			
 			},
 			/*
		 * Add material on submit
		 */
		_submitData: function (oPayload) {
			MaterialModel.addMaterialToOperation(oPayload, _this._endSubmitOnSuccess, null, _this);
		},

		/*VYA0004|LLM3.3 End*/
	        /** START KIR0084 LMP2-36 Allow adding of sub-operation long text. */
        	onClickCommentOpen: function(oEvent) {
        		var oParams = {};
        		oParams.oWorkOrderHeader = oEvent.getSource().getBindingContext("craftOperations").getObject();
        		oParams.fnFirstCommentAdded = _this.refreshMyWork.bind(_this, true);
        		
        		var oWorkOrderComments = new WorkOrderComments(oParams);
        		if(!_this._oI18nModel && _this.getOwnerComponent()) {
        			_this._oI18nModel = _this.getOwnerComponent().getModel("i18n");
        		}
        		oWorkOrderComments.getFragment().setModel(_this._oI18nModel, "i18n");
        		jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oWorkOrderComments);
        		oWorkOrderComments.getFragment().open();
        	},
		    /** END KIR0084 LMP2-36 Allow adding of sub-operation long text. */
			
    		// Added for LMP2-7a	
    		onClickAttachmentOpen: function(oEvent) {
    			
    			var sBindPath = oEvent.getSource().getBindingContext("craftOperations").sPath;
    			
    				if (!this._oAttachmentClickPopOver){
    					
    					this._oAttachmentClickPopOver = sap.ui.xmlfragment(
    						"com.sap.cp.lm.view.myShop.common.workplan.AttachmentClickPopOver",this);
    						this.getView().addDependent(this.oAttachmentClickPopOver);
    				}
    			var oData = this.getView().getModel("craftOperations").getObject(sBindPath).AttachSet;
    				var oTempModel = new sap.ui.model.json.JSONModel(oData);
    				this._oAttachmentClickPopOver.setModel(oTempModel);
    				this._oAttachmentClickPopOver.openBy(oEvent.getSource());
    		
    		},

			/**
			 * Fired when an operation is selected
			 */
			onClickMaterialListPopover: function(oEvt) {
				var sBindingPath = oEvt.getSource().getBindingContext("craftOperations").sPath;
				_this._selectedContext = oEvt.getSource().getBindingContext("craftOperations");
				var oModel = this.getView().getModel("craftOperations");
				var sLocoNumber = oModel.getObject(sBindingPath);

				LocomotiveManager.onClickMaterialListPopover(oEvt, this.getView(), sBindingPath, oModel, sLocoNumber);
			},

			onRefreshList: function(oEvent) {
				this.refreshMyWork(true);
			},

			onToggleComplete: function(oEvent) {
				_this._bHideComplete = !_this._bHideComplete;

				_this.refreshCompleteToggle();
			},
			
			/**
			 * For craft View Begin & End Work
			 */
			onBeginWorkforOperation: function(oEvent) {
				var oSelContext = oEvent.getSource().getBindingContext("craftOperations");
				CraftManager.onBeginWorkforOperation(oSelContext, this);
			},
			
			onEndWorkforOperation: function(oEvent) {
				var oSelContext = oEvent.getSource().getBindingContext("craftOperations");
				/*VYA0004|LLM3.3 Begin*/
				var oParam = oSelContext.getObject();
			    var sOrderId = oParam.OrderNo;
			    var sActivity = oParam.Activity;
				//Check all materials have been issued for this Operation
				MaterialModel.CheckGoodsIssueComplete(sOrderId, sActivity, this, this.fOpenpopup, oSelContext);
				//if Yes, proceed as usual
				//No, Pop up MyWorkReserveMaterial screen
				// CraftManager.onEndWorkforOperation(oSelContext, this);
				/* VYA0004|LLM3.3 End*/
			},

			fOpenpopup: function(oData, oSelContext){
			_this.oSelContext = oSelContext;	
			if (oData.OpenPopUp === "Y"){
			//Call MyWorkReserveMaterial Screen	
		    var oParam = oSelContext.getObject();
			var sOrderId = oParam.OrderNo;
			var sShopId = oParam.Shop;
			_this.oResMatModel = new sap.ui.model.json.JSONModel();
			MaterialModel.fetchReserveMatDetails(sOrderId, sShopId, this, oParam.Activity);
			if (!_this._oReserveMaterialDialog) {
				_this._oReserveMaterialDialog = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.shopped.addMaterial.MyWorkReserveMaterial",
					_this
				);
			}
			_this._oReserveMaterialDialog.setModel(_this.oResMatModel, "oResMatModel");
			
			var i18nModel = new sap.ui.model.resource.ResourceModel({
				bundleName: "com.sap.cp.lm.i18n.i18n"
			});
            _this.oModel = new sap.ui.model.json.JSONModel();
			_this.oModel.setProperty("/DefaultOperation", oParam.Activity);
			_this.oModel.setProperty("/SelectedOrder", sOrderId); // LMP2-8a
			_this.oModel.setProperty("/SelectedShop", sShopId); // LMP2-8a
			_this.oModel.setProperty("/OpNode", oParam.OpNode);
			_this.oModel.setProperty("/RoutingNo", oParam.RoutingNo);
			_this.oModel.setProperty("/LocoId", oParam.LocoId);
			_this.oModel.setProperty("/FromShoppingCart", false);
			_this.oModel.setProperty("/FromEndWork", true);
			_this.oModel.setProperty("/btnText", "Process Picklist");
			_this._oReserveMaterialDialog.setModel(_this.oModel);
			MaterialModel.FetchBNBMaterial(_this); // SHE0272 - LLMBNB3.0
            
			// Reset dialog content
			sap.ui.getCore().byId("mwaddMaterialSearchBar").setValue("");
            sap.ui.getCore().byId("mwIconTabResMat").setSelectedKey("mwpicklist");
			_this._oReserveMaterialDialog.setModel(i18nModel, "i18n");
			_this._oReserveMaterialDialog.open();
			BusyIndicator.hideBusyIndicator();
			}
			else{
				//Call time entry
				CraftManager.onEndWorkforOperation(oSelContext, this);
			}
			}

		});
	});