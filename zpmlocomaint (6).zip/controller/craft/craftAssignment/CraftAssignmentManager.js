/*&---------------------------------------------------------------------*    
 * Author         : SAP Custom Development                               *
 * Date           : 2017.12.05                                           *
 * Project        : Locomotive Maintenance                               *
 * Description    : This manager is used for the Craft Assignment pop up *
 *                  in navigation bar. It manages the list of workers,   *
 *                  locomotives and assignment.                          *
 *&----------------------------------------------------------------------*/
 /*&---------------------------------------------------------------------*    
 * Author         : KIR0084                                              *
 * Date           : 2019.07.25                                           *
 * Project        : Locomotive Maintenance                               *
 * Description    : Add ability to preset craft and loco                 *
 *&----------------------------------------------------------------------*/
 /*&---------------------------------------------------------------------*    
* Author         : KIR0084                                              *
* Date           : 2019.10.10                                           *
* Project        : LMP2 change request                                  *
* Description    : Remove final verification step in craft assignment   *
*&----------------------------------------------------------------------*/

jQuery.sap.declare("com.sap.cp.lm.controller.craft.craftAssignment.craftAssignmentManager");

sap.ui.define([
		"com/sap/cp/lm/util/Constants",
		"com/sap/cp/lm/controller/craft/CraftSearchManager",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
		"com/sap/cp/lm/util/ErrorManager",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/controller/locomotives/LocomotiveManager",
		"com/sap/cp/lm/util/Helper",
		"sap/ui/model/FilterOperator",
		'sap/m/MessageBox',
		"sap/ui/model/json/JSONModel"
	],
	function(Constants, CraftSearchManager, LocomotiveDataModel, ErrorManager, BusyIndicator, LocomotiveManager, Helper, FilterOperator,
		MessageBox, JSONModel) {
		"use strict";
		var _this;

		return com.sap.cp.lm.controller.craft.craftAssignment.craftAssignmentManager = {

			//--------------------------------------------------------------------
			// Life cycle functions
			//--------------------------------------------------------------------

			// #DontDelete : Q
			/**
			 * Initialize private functions and get context from main view
			 */
			init: function(oContext) {
				_this = this;
				_this._oContext = oContext;
				_this._oView = _this._oContext.getView();
				this._oGlobalModel = _this._oContext.getView().getModel(Constants.GLOBAL_MODEL);
				_this._aSelectedWorkers = [];
				_this._dialogIsOpen = false;
				var oModel = new sap.ui.model.json.JSONModel();
				_this._oView.setModel(oModel);
				_this.bOpenfromMain = true;
				return _this;
			},

			//----------------------------------------------------------------------
			// Private functions : Craft List
			//----------------------------------------------------------------------

			/**
			 * This function is called after initialization, it opens the dialog view
			 */
			openDialog: function(oParams) {
        
                
				if (!_this._oCraftAssignmentWorkDialog) {
					_this._oCraftAssignmentWorkDialog = sap.ui.xmlfragment("com.sap.cp.lm.view.craft.craftAssignment.CraftAssignmentWorkDialog", _this);
					_this._oView.addDependent(_this._oCraftAssignmentWorkDialog);
				}

				_this.initializeCraftAssignmentWorkDialog(oParams);

			},

			openCraftDialog: function() {
				if (_this.bOpenfromMain) {
					_this.bOpenfromMain = false;
					_this._oCraftAssignmentListDialog = sap.ui.getCore().byId("craftAssignmentListDialog");
					_this._oWorkersTable = sap.ui.getCore().byId("craftAssignmentListWorkersTable");

					_this.loadCraftSearchFragment();
					_this.refreshWorkersList();
				} else {
					_this._oCraftAssignmentListDialog.open();
				}

			},

			// #DontDelete : Q
			/**
			 * Load Craft Search Manager and display fragment
			 */
			loadCraftSearchFragment: function() {
				if (_this._oCraftAssignmentSearchManager) {
					_this._oCraftAssignmentSearchManager.destroy();
				}
				_this._oCraftAssignmentSearchManager = new CraftSearchManager();
				_this._oCraftAssignmentSearchManager = _this._oCraftAssignmentSearchManager.init(_this, _this.refreshWorkersList, _this._oWorkersTable);

				if (_this._oCraftSearchFragment) {
					_this._oCraftSearchFragment.destroy();
				}
				_this._oCraftSearchFragment = _this._oCraftAssignmentSearchManager.getFragment();
				sap.ui.getCore().byId("craftAssignmentListSearchToolbar").addContent(_this._oCraftSearchFragment);
				
				//LMP2-37 Do not show remove assignment button on craft assignment list screen
				_this._oCraftSearchFragment.getItems()[1].setVisible(false);
			},

			// #DontDelete : Q
			/**
			 * Load Workers from service to backend
			 */
			refreshWorkersList: function() {
				var sCurrentShopId = _this._oContext._oGlobalModel.getProperty("/currentShop").Id;

				LocomotiveDataModel.fetchCraftWorkPlanList(_this.onSuccessCraftList, null, this, sCurrentShopId);
			},

			//----------------------------------------------------------------------
			// Event handlers : Craft List
			//----------------------------------------------------------------------

			// #DontDelete : Q
			/**
			 * Edit model property boolean value when a craft worker is selected
			 */
			onWorkerSelect: function() {
				var oTableContexts = _this._oWorkersTable.getSelectedContexts();
				var bWorkersAreSelected = false;

				if (oTableContexts.length > 0) {
					bWorkersAreSelected = true;
				}

				_this._oView.getModel().setProperty("/WorkersAreSelected", bWorkersAreSelected);
			},

			// #DontDelete : Q
			/**
			 * Validate workers has been selected and store them to a private function
			 */
			onAssignSelectedPress: function() {
			    
			    /* KIR0084 Check if operations vaildation successful before moving to next screen */
			    var selectedSuccess = _this.onAddSelectedOperations();
			    
			    if (selectedSuccess) {
    				_this.openCraftDialog();
    				_this._oCraftAssignmentWorkDialog.close();
			    }
			},

			// #DontDelete : Q
			/**
			 * Close the dialog view
			 */
			onCraftListCancelPress: function() {
				this.closeDialog();
			},
			closeDialog: function() {
				_this._oCraftAssignmentListDialog.close();
				if (_this._oCraftAssignmentSearchManager) {
					_this._oCraftAssignmentSearchManager.destroy();
					_this._oCraftAssignmentSearchManager = null;
				}
				if (_this._oCraftSearchFragment) {
					_this._oCraftSearchFragment.destroy();
					_this._oCraftSearchFragment = null;
				}
			},

			// #DontDelete : Q
			/**
			 * Store the workers in model when fetch is successful
			 */

			_sortCraftList: function(aRawCrafts) {
		 
				var aAvailables = [];
				var aUnavaillables = [];
				aRawCrafts.forEach(function(oCraft) {
					if (oCraft.RemainingAvailableHrs && parseFloat(oCraft.RemainingAvailableHrs) > 0) {
						aAvailables.push(oCraft);
					} else {
						aUnavaillables.push(oCraft);
					}
				});

				aAvailables.sort(function(a, b) {
					return a.Name - b.Name;
				});
				aUnavaillables.forEach(function(oCraft){
					aAvailables.push(oCraft);
				});
				return aAvailables;
			},

			onSuccessCraftList: function(oData) {
				var aSorted = _this._sortCraftList(oData.results);

				var oModel = _this._oView.getModel();
				oModel.setProperty("/CraftList", aSorted);
				_this._oCraftAssignmentSearchManager._filterItems();
				
				// KIR0084 LMP2 if craft preselected, default this popup
				if (_this._oPreSelectedCraft) {
				    _this._oCraftAssignmentListDialog.attachAfterOpen(function() {
    				    var selectedCraftItem = _this._oWorkersTable.getItems().filter(function(itemCraft) {
    				        return itemCraft.getBindingContext().getObject().PersonNo === _this._oPreSelectedCraft.PersonNo;
    				    })[0];
    				    
    				    if (selectedCraftItem) {
    				        selectedCraftItem.setSelected(true);
         				    _this._oWorkersTable.fireSelectionChange({
         				        listItem: selectedCraftItem, 
         				        selected: true
         				    });
        				    selectedCraftItem.focus();
    				    }
    				    delete _this._oPreSelectedCraft;
				    });
				} else {
				    _this._oCraftAssignmentListDialog.attachAfterOpen(function() {});
				}           

				if (!_this._dialogIsOpen) {
					_this._oCraftAssignmentListDialog.open();
					_this._oView.getModel().setProperty("/WorkersAreSelected", false);
					_this._oView.getModel().refresh();
				}
				
			},

			//----------------------------------------------------------------------
			// Private functions : Craft Work
			//----------------------------------------------------------------------

			// #DontDelete : Q
			/**
			 * Close the craft assignment list dialog and display the craft assignment work dialog with locomotives
			 */
			initializeCraftAssignmentWorkDialog: function(oParams) {
				// _this._oCraftAssignmentListDialog.close();

				var sCraftAssignmentWorkDialogTitle = "Select the Operations to Assign";

				_this._oCraftAssignmentWorkDialog.setTitle(sCraftAssignmentWorkDialogTitle);
				_this._oPreSelectedCraft = oParams.craft;

				var aShoppedLocomotives = _this._oContext._oGlobalLocomotiveModel.getProperty("/Shopped");
				var aShoppedLocomotivesWithWorkOrders = aShoppedLocomotives.filter(function(shoppedLocomotive) {
					return parseInt(shoppedLocomotive.NbrWorkOrdersOpen) > 0;
				});

				_this._oView.getModel().setProperty("/ShoppedData", aShoppedLocomotivesWithWorkOrders);
				
				// KIR0084 LMP2 Loading from craft screen map should have craft and locomotive preset because the user clicked a loco inside the craft
				// Skip the loco assigment screen but we need to busy screen after it is loaded
				if (oParams && oParams.locomotive) {
				    _this._oView.getModel().setProperty("/assignmentStatusIsLocomotiveSelection", true);
    				BusyIndicator.hideBusyIndicator();
				}
				_this._oView.getModel().setProperty("/WorkAssigned", {});
				_this._oView.getModel().setProperty("/ReadyToSaveWorkAssigned", false);

				_this._oCraftAssignmentWorkDialog.open();
				
				// KIR0084 LMP2 See above comment, load locomotives after dialog opened
				if (oParams && oParams.locomotive) {
				    _this._skipLocoSelectionScreen(oParams.locomotive);
				} 
			},
			
			// START KIR0084 LMP2 Add ability to skip locomoitive selection
		    _skipLocoSelectionScreen: function(locomotive) {
				this.oExpandedWO = {};
				this._oPanelExpandModel = new JSONModel();
				this._oPanelExpandModel.setData(this.oExpandedWO);
				_this._oView.getModel().setProperty("/assignmentStatusIsLocomotiveSelection", false);

				_this._oView.setModel(this._oPanelExpandModel, "CraftPanelExpandModel");

				_this._oView.getModel().setProperty("/SelectedLocomotive", locomotive);
				
				var sEquipNo = locomotive.Equipment;
				if(!sEquipNo) {
					sEquipNo = locomotive.EquipNo;
				}
			
				_this.loadLocomotiveWorkOrders(locomotive.LocomotiveId, sEquipNo);  
		    },
			// END KIR0084 LMP2 Add ability to skip locomoitive selection

			// #DontDelete : Q
			/**
			 * Reset the work orders and fetch new ones for the selected locomotive
			 */
			loadLocomotiveWorkOrders: function(sLocomotiveNumber, sEquipNo) {
				BusyIndicator.showBusyIndicator();

				_this._oView.getModel().setProperty("/WorkOrdersSet", []);

				LocomotiveDataModel.fetchLocomotiveDetails(_this.onLoadLocomotiveWorkOrdersSuccess, "", this, sLocomotiveNumber, sEquipNo);
			},

			// #DontDelete : Q
			/**
			 * Filter the list based on the searchString
			 */
			_filterLocomotivesList: function(sSearchString) {
				var oFinalFilter;
				var oOrFilter = new sap.ui.model.Filter(_this.prepareFilter(sSearchString), false);
				oFinalFilter = new sap.ui.model.Filter(oOrFilter, true);
				sap.ui.getCore().byId("craftAssignmentWorkLocomotivesTable").getBinding("items").filter(oFinalFilter);
			},

			// #DontDelete : Q
			/**
			 * Prepare filters
			 */
			prepareFilter: function(sSearchString) {
				sSearchString = sSearchString ? sSearchString : "";
				var aOrFilters = [];
				aOrFilters = [
					new sap.ui.model.Filter("LocomotiveId", FilterOperator.Contains, sSearchString)
				];
				return aOrFilters;
			},

			//----------------------------------------------------------------------
			// Event handlers : Craft Work
			//----------------------------------------------------------------------

			// #DontDelete : Q
			/**
			 * Event handle when the search text changes in the search bar for Locomotives list.
			 */
			onSearchTextChanged: function(oEvent) {
				var sSearchString = oEvent.getParameter("newValue") || oEvent.getParameter("query");
				_this._filterLocomotivesList(sSearchString);
			},

			// #DontDelete : Q
			/**
			 * Store the works orders for locomotive and filter them to get only not completed ones
			 * Filter their operations to get only the not completed ones too
			 */
			onLoadLocomotiveWorkOrdersSuccess: function(oModel, oParameters, sLocomotiveNo, sEquipNo) {
				var aWorkOrdersSet = [];

				if (oModel.getData().detailsData) {
					var aWorkOrdersSetAll = oModel.getData().detailsData.results;
					aWorkOrdersSet = aWorkOrdersSetAll.filter(function(oWorkOrder) {
						return oWorkOrder.Status !== "0";
					});

					$.each(aWorkOrdersSet, function(i, oWorkOrder) {
						var aOperationSetAll = oWorkOrder.OperationSet.results;
						var aOperationSet = aOperationSetAll.filter(function(oOperation) {
							return oOperation.Status !== "0";
						});

						oWorkOrder.OperationSet.results = aOperationSet;
					});
				}

				var oTableSelectedLocomotiveData = _this._oView.getModel().getProperty("/SelectedLocomotive");
				oTableSelectedLocomotiveData.WorkOrdersSet = aWorkOrdersSet;

				_this._oView.getModel().setProperty("/WorkOrdersSet", aWorkOrdersSet);
				
				/* LMP2 KIR0084 Fix bug where updating time doesn't reflect if object is already selected */
				var locoId = oTableSelectedLocomotiveData.LocomotiveId;
				var workAssigned = _this._oView.getModel().getProperty("/WorkAssigned");
				if (workAssigned && workAssigned[locoId]) {
				    var workOrdersAssigned = workAssigned[locoId]["WAWorkOrdersSet"];
    				// Merged changed data back into WorkAssigned so hours is updated
    				aWorkOrdersSet.forEach(function(oWorkOrder) {
    				    if (workOrdersAssigned[oWorkOrder.OrderNo]) {
    				        // Get operations for work Order
    				        var operationsAssigned = workOrdersAssigned[oWorkOrder.OrderNo]["WAOperationsSet"];
    				        oWorkOrder.OperationSet.results.forEach(function(oOperation) {
    				            if (operationsAssigned[oOperation.OpNode]) {
    				                // Loop over properties in operations assigned
    				                Object.keys(operationsAssigned[oOperation.OpNode]).forEach(function(key) {
    				                    // Replace value in selected operations with value in result set
    				                    operationsAssigned[oOperation.OpNode][key] = oOperation[key];  
    				                });
    				            } 
    				        });
    				        workOrdersAssigned[oWorkOrder.OrderNo]["WAOperationsSet"] = operationsAssigned;
    				    } 
    				});
    				workAssigned[locoId]["WAWorkOrdersSet"] = workOrdersAssigned;
				}
				_this._oView.getModel().setProperty("/WorkAssigned", workAssigned);
				/* LMP2 KIR0084 Fix bug where updating time doesn't reflect if object is already selected */
				
				
				if (_this.bEstimateUpdated) {
					_this.bEstimateUpdated = false;
					this._oPanelExpandModel.refresh(true);
					// this.oOperationPanel.setExpanded(true);
				}

				BusyIndicator.hideBusyIndicator();
			},

			// #DontDelete : Q
			/**
			 * Store the selected locomotive in the model and call function to display the work orders view
			 */
			onLocomotiveSelect: function() {
				this.oExpandedWO = {};
				this._oPanelExpandModel = new JSONModel();
				this._oPanelExpandModel.setData(this.oExpandedWO);
				_this._oView.getModel().setProperty("/assignmentStatusIsLocomotiveSelection", false);

				var oTableLocomotives = sap.ui.getCore().byId("craftAssignmentWorkLocomotivesTable");
				_this._oView.setModel(this._oPanelExpandModel, "CraftPanelExpandModel");
				var oTableSelectedLocomotive = oTableLocomotives.getSelectedItem();
				var oTableSelectedLocomotiveContextPath = oTableSelectedLocomotive.getBindingContext().sPath;
				var oTableSelectedLocomotiveData = oTableLocomotives.getModel().getProperty(oTableSelectedLocomotiveContextPath);

				_this._oView.getModel().setProperty("/SelectedLocomotive", oTableSelectedLocomotiveData);
				
				var sEquipNo = oTableSelectedLocomotiveData.Equipment;
				if(!sEquipNo) {
					sEquipNo = oTableSelectedLocomotiveData.EquipNo;
				}
			
				_this.loadLocomotiveWorkOrders(oTableSelectedLocomotiveData.LocomotiveId, sEquipNo);
			},
			/**
			 * Open the dialog to change the time
			 */
			onClickEstTimeEdit: function(oEvent) {
				var oSelectedContext = oEvent.getSource().getBindingContext().getObject();
				_this._oView.oCraftManager = this;
				LocomotiveManager.onClickEstTimeEdit(oEvent, oSelectedContext, _this._oView);
			},

			onExpandOperationPanel: function(oEvent) {
				this.oOperationPanel = oEvent.getSource();
				var bExpand = oEvent.getParameters().expand;
				var sOrderNumber = oEvent.getSource().getBindingContext().getObject().OrderNo;

				if (bExpand) {
					if (!this.oExpandedWO[sOrderNumber]) {
						this.oExpandedWO[sOrderNumber] = {};
					}
				} else {
					delete this.oExpandedWO[sOrderNumber];
				}
			},

			reloadWorkOrders: function() {
				//Set the flag to expand the current operation on successfull update.
				_this.bEstimateUpdated = true;
				var oTableSelectedLocomotiveData = _this._oView.getModel().getProperty("/SelectedLocomotive");

				var sEquipNo = oTableSelectedLocomotiveData.Equipment;
				if(!sEquipNo) {
					sEquipNo = oTableSelectedLocomotiveData.EquipNo;
				}
				
				_this.loadLocomotiveWorkOrders(oTableSelectedLocomotiveData.LocomotiveId, sEquipNo);
			},

			// #DontDelete : Q
			/**
			 * Hide the work orders view and display the locomotives table
			 */
			onBackToLocomotivesPress: function() {
				_this._oView.getModel().setProperty("/assignmentStatusIsLocomotiveSelection", true);
			},

			// #DontDelete : Q
			/**
			 * Display the Material list popover on click
			 */
			onClickMaterialListPopover: function(oEvent) {
				var sBindingPath = oEvent.getSource().getBindingContext().sPath;
				var oModel = _this._oView.getModel();
				var oLocomotive = oModel.getProperty("/SelectedLocomotive");
				var sLocomotiveId = oLocomotive.LocomotiveId;

				LocomotiveManager.onClickMaterialListPopover(oEvent, _this._oView, sBindingPath, oModel, sLocomotiveId);
			},

			// #DontDelete : Q
			/**
			 * Open long text dialog on button click
			 */
			onClickLongTextOpen: function(oEvent) {
				var sBindingPath = oEvent.getSource().getBindingContext().sPath;

				if (sBindingPath) {
					var oDataObject = _this._oView.getModel().getObject(sBindingPath);
					Helper.openLongTextDialog(oDataObject);
				}
			},

			// #DontDelete : Q
			/**
			 * Create or modify the model containing the Work Assigned selection with the newly selected ones
			 */
			onAddSelectedOperations: function() {
				var countSelectedOperations = 0;
				var oWorkOrdersList = sap.ui.getCore().byId('lmCraftAssignmentWorkOrdersList');

				// var aWorkAssigned = _this._oView.getModel().getProperty("/WorkAssigned");
				// LMP2 KIR0084 Fix bug where removing operations wasnt removing them from being selected
				var aWorkAssigned;
				if (!aWorkAssigned) {
					aWorkAssigned = {};
				}

				var oLocomotive = _this._oView.getModel().getProperty("/SelectedLocomotive");
				var sLocomotiveId = oLocomotive.LocomotiveId;
				var oWorkAssignedLocomotive = {};
				oWorkAssignedLocomotive.LocomotiveId = sLocomotiveId;

				if (aWorkAssigned[sLocomotiveId]) {
					oWorkAssignedLocomotive = aWorkAssigned[sLocomotiveId];
				}

				if (!oWorkAssignedLocomotive.WAWorkOrdersSet) {
					oWorkAssignedLocomotive.WAWorkOrdersSet = {};
				}

				oWorkOrdersList.getItems().forEach(function(oWorkOrderItem) {
					var sBindingPath = oWorkOrderItem.getBindingContext().sPath;
					var oWorkOrder = _this._oView.getModel().getObject(sBindingPath);

					if (oWorkOrderItem.$().find('table')) {
						if (oWorkOrderItem.$().find('table')[0]) {
							var oWorkOrderItemTable = $(oWorkOrderItem.$().find('table')[0]).control()[0];

							if (oWorkOrderItemTable) {
								var oTableContexts = oWorkOrderItemTable.getSelectedContexts();
								var aSelectedOperations = oTableContexts.map(function(w) {
									return w.getObject();
								});

								if (aSelectedOperations.length > 0) {
									if (!oWorkAssignedLocomotive.WAWorkOrdersSet[oWorkOrder.OrderNo]) {
										oWorkAssignedLocomotive.WAWorkOrdersSet[oWorkOrder.OrderNo] = {
											Descr: oWorkOrder.Descr,
											DefectNo: oWorkOrder.DefectNo,
											EquipNo: oWorkOrder.EquipNo,
											OrderNo: oWorkOrder.OrderNo
										};
									}

									if (!oWorkAssignedLocomotive.WAWorkOrdersSet[oWorkOrder.OrderNo].WAOperationsSet) {
										oWorkAssignedLocomotive.WAWorkOrdersSet[oWorkOrder.OrderNo].WAOperationsSet = {};
									}

									aSelectedOperations.forEach(function(oSelectedOperationItem) {
										if (!oWorkAssignedLocomotive.WAWorkOrdersSet[oWorkOrder.OrderNo].WAOperationsSet[oSelectedOperationItem.OpNode]) {
											var oOperationToAdd = {};
											oOperationToAdd.OpNode = oSelectedOperationItem.OpNode;
											oOperationToAdd.Activity = oSelectedOperationItem.Activity;
											oOperationToAdd.OrderNo = oSelectedOperationItem.OrderNo;
											oOperationToAdd.PlanWorkDur = oSelectedOperationItem.PlanWorkDur;
											oOperationToAdd.PlanWorkUom = oSelectedOperationItem.PlanWorkUom;
											oOperationToAdd.RoutingNo = oSelectedOperationItem.RoutingNo;
											oOperationToAdd.Descr = oSelectedOperationItem.Descr;

											oWorkAssignedLocomotive.WAWorkOrdersSet[oWorkOrder.OrderNo].WAOperationsSet[oSelectedOperationItem.OpNode] =
												oOperationToAdd;

											countSelectedOperations++;
										}
									});
								}
							}
						}
					}
				});

				if (countSelectedOperations > 0) {
					if (!aWorkAssigned[sLocomotiveId]) {
						aWorkAssigned[sLocomotiveId] = oWorkAssignedLocomotive;
					}

					_this._oView.getModel().setProperty("/WorkAssigned", aWorkAssigned);
				} else {
					ErrorManager.handleError("", _this._oContext._oI18nModel.getProperty("ERROR_WORK_ASSIGNED_SELECT_OPERATIONS"));
				}

				var bReadyToSaveWorkAssigned = false;
				if (Object.keys(aWorkAssigned).length > 0) {
					bReadyToSaveWorkAssigned = true;
				}
				_this._oView.getModel().setProperty("/ReadyToSaveWorkAssigned", bReadyToSaveWorkAssigned);
				return bReadyToSaveWorkAssigned;
			},

			// #DontDelete : Q
			/**
			 * Modify the model containing the Work Assigned selection to remove the selected ones
			 */
			onRemoveWorkAssignedOperations: function() {
				var oWorkAssignedLocomotivesList = sap.ui.getCore().byId('lmWorkAssignedList');
				var countSelectedOperations = 0;

				oWorkAssignedLocomotivesList.getItems().forEach(function(oWorkAssignedLocomotivesItem) {
					var sLocomotivesItemBindingPath = oWorkAssignedLocomotivesItem.getBindingContext().sPath;
					var oLocomotive = _this._oView.getModel().getObject(sLocomotivesItemBindingPath);

					if (oWorkAssignedLocomotivesItem.$().find('.sapMList')) {
						if (oWorkAssignedLocomotivesItem.$().find('.sapMList')[0]) {
							var oWorkAssignedWOList = $(oWorkAssignedLocomotivesItem.$().find('.sapMList')[0]).control()[0];

							oWorkAssignedWOList.getItems().forEach(function(oWorkAssignedWOItem) {
								var sWOItemBindingPath = oWorkAssignedWOItem.getBindingContext().sPath;
								var oWO = _this._oView.getModel().getObject(sWOItemBindingPath);

								if (oWorkAssignedWOItem.$().find('table')) {
									if (oWorkAssignedWOItem.$().find('table')[0]) {
										var oWorkAssignedWOItemTable = $(oWorkAssignedWOItem.$().find('table')[0]).control()[0];

										if (oWorkAssignedWOItemTable) {
											var oWOItemTableContexts = oWorkAssignedWOItemTable.getSelectedContexts();
											oWOItemTableContexts.forEach(function(w) {
												countSelectedOperations++;
												delete oWO.WAOperationsSet[w.getObject().OpNode];
											});
										}
									}
								}

								if (Object.keys(oWO.WAOperationsSet).length <= 0) {
									delete oLocomotive.WAWorkOrdersSet[oWO.OrderNo];
								}
							});
						}
					}

					if (Object.keys(oLocomotive.WAWorkOrdersSet).length <= 0) {
						var aWorkAssigned = _this._oView.getModel().getProperty("/WorkAssigned");

						delete aWorkAssigned[oLocomotive.LocomotiveId];

						if (Object.keys(aWorkAssigned).length <= 0) {
							_this._oView.getModel().setProperty("/ReadyToSaveWorkAssigned", false);
						}
					}
				});

				if (countSelectedOperations <= 0) {
					ErrorManager.handleError("", _this._oContext._oI18nModel.getProperty("ERROR_WORK_ASSIGNED_SELECT_OPERATIONS"));
				}

				_this._oView.getModel().refresh();
			},

			// #DontDelete : Q
			/**
			 * Create the payload to call service for assign work
			 */
			onSavePress: function() {
				var oTableContexts = _this._oWorkersTable.getSelectedContexts();
				var aSelectedWorkers = oTableContexts.map(function(w) {
					return w.getObject();
				});

				if (aSelectedWorkers.length > 0) {
					_this._aSelectedWorkers = aSelectedWorkers;
				}
				var aWorkAssigned = _this._oView.getModel().getProperty("/WorkAssigned");
				var oPayload = {};

				oPayload.ShopId = _this._oContext._oGlobalModel.getProperty("/currentShop").Id;
				oPayload.OperationSet = [];

				$.each(aWorkAssigned, function(keyL, oLocomotive) {
					$.each(oLocomotive.WAWorkOrdersSet, function(keyW, oWorkOrder) {
						$.each(oWorkOrder.WAOperationsSet, function(keyO, oOperation) {
							var aOperationSetHeader = {};
							aOperationSetHeader.OrderNo = oOperation.OrderNo;
							aOperationSetHeader.Activity = oOperation.Activity;
							aOperationSetHeader.RoutingNo = oOperation.RoutingNo;
							aOperationSetHeader.OpNode = oOperation.OpNode;
							aOperationSetHeader.PlanWorkDur = oOperation.PlanWorkDur;
							aOperationSetHeader.PlanWorkUom = oOperation.PlanWorkUom;

							oPayload.OperationSet.push(aOperationSetHeader);
						});
					});
				});

				oPayload.AssignmentSet = [];

				_this._aSelectedWorkers.forEach(function(oSelectedWorker) {
					var oAssignment = {};
					oAssignment.PersonNo = oSelectedWorker.PersonNo;

					oPayload.AssignmentSet.push(oAssignment);
				});

				LocomotiveDataModel.updateCraftAssignmentsSet(oPayload, _this.onBatchAssignmentsUpdateSuccess, _this.onBatchAssignmentsUpdateError,
					_this);
			},

			// #DontDelete : Q
			/**
			 * Show a success message dialog
			 */
			onBatchAssignmentsUpdateSuccess: function() {
				this.closeDialog();
    		    /** LMP2-36 Refresh map when crafts change */
				var oEventBus = sap.ui.getCore().getEventBus();
				
                if (this._oGlobalModel.getProperty("/isMapView") && this._oGlobalModel.getProperty("/sSelectedView") === Constants.MYSHOP) {
				    oEventBus.publish("ShopChanged", "shopChangedDone", this);
                }
                else if (this._oGlobalModel.getProperty("/isCraftMapView") && this._oGlobalModel.getProperty("/sSelectedView") === Constants.CRAFT) {
				    oEventBus.publish("ShopChanged", "shopCraftChangedDone", this);
				    this._oGlobalModel.getProperty("/CraftMasterController").onRefreshMasterList(true);
                }
                else {
                    this._oGlobalModel.setProperty("/needDrawMap", true);
                    this._oGlobalModel.setProperty("/needRefreshMapData", true);
                }

				MessageBox.show(_this._oContext._oI18nModel.getProperty("CRAFT_ASSIGNMENT_SUCCESS_MESSAGE"), {
					icon: MessageBox.Icon.SUCCESS,
					title: "Success",
					styleClass: "successMessage",
					actions: [MessageBox.Action.OK]
				});
			    return;
    
			    _this.reloadWorkplan();
                /** LMP2-36 Refresh map when crafts change */
			},

			onBatchAssignmentsUpdateError: function() {
				_this.reloadWorkplan();
			},

			//Reaload the work Plan in selected tab : Locomotives, Mywork, Fleet,Craft views
			reloadWorkplan: function() {
				var oGlobalModel = _this._oContext._oGlobalModel;
				_this._oGlobalModel = oGlobalModel;

				if (this._oGlobalModel.getProperty("/sSelectedView") === Constants.LOCOMOTIVES) {
					this.reloadShoppedLocoWorkPlan();
				}

				if (this._oGlobalModel.getProperty("/sSelectedView") === Constants.MYWORK) {
					_this.reloadMyWork();
				}
				if (this._oGlobalModel.getProperty("/sSelectedView") === Constants.CRAFT) {
					_this.reloadCraftWork();
				}

				if (this._oGlobalModel.getProperty("/sSelectedView") === Constants.FLEET) {
					_this.reloadFleetWorkPlan();
				}
			},

			//Check the selected Lcomotives(for selected  Operations) are available in the workplan displayed. 
			//then Reload the work plan
			reloadShoppedLocoWorkPlan: function() {
				var oWorkPlanController = _this._oGlobalModel.getProperty("/oWorkplanController");
				var oMasterController = _this._oGlobalModel.getProperty("/locomotiveMasterController");
				var bReloadWorkplan = false;
				var sLocoId;
				if (oWorkPlanController) {

					if (_this._oGlobalModel.getProperty("/selectedMyShopTab") === Constants.TEXT_SERVICING || _this._oGlobalModel.getProperty(
							"/selectedMyShopTab") ===
						Constants.TEXT_SHOPPED) {
						//Validate if reload required
						if (oMasterController._shoppedList.getSelectedItem()) {
							sLocoId = oMasterController._shoppedList.getSelectedItem().getBindingContext().getObject().LocomotiveId;
							bReloadWorkplan = _this.checkCurrentSelectedWorkPlanLoco(sLocoId);
						}
						if (oMasterController._oServiceUngroupedList.getSelectedItem()) {
							sLocoId = oMasterController._oServiceUngroupedList.getSelectedItem().getBindingContext().getObject().LocomotiveId;
							bReloadWorkplan = _this.checkCurrentSelectedWorkPlanLoco(sLocoId);
						}
						if (oMasterController._oServicegroupedList.getSelectedItem()) {
							var oGroupLoco = oMasterController._oServicegroupedList.getSelectedItem().getBindingContext().getObject().ServiceGroupItemSet.results;
							oGroupLoco.forEach(function(oItem) {
								sLocoId = oItem.LocomotiveId;
								bReloadWorkplan = _this.checkCurrentSelectedWorkPlanLoco(sLocoId);
							});
						}

						if (bReloadWorkplan) {

							oWorkPlanController.fetchAndRefreshView();
						}

					}
				}
			},

			//Check the selected Crafts is the craft logged in 
			//then Reload the my work plan

			reloadMyWork: function() {
				var bReloadMyWork = _this.checkAssignedPernr(_this._oGlobalModel.getProperty("/currentUser").PersonnelNumber);

				if (bReloadMyWork) {
					this._oGlobalModel.getProperty("/oMyWorkController").refreshMyWork(true);
				}
			},

			//Check the seleceted craft is available in crafts seleceted for assignment
			//then Reload the work plan

			reloadCraftWork: function() {
				var oCraftMaster = this._oGlobalModel.getProperty("/CraftMasterController");
				var oSelItem;
				if (oCraftMaster) {
					oSelItem = oCraftMaster.getView().byId("craftList").getSelectedItem();
					if (oSelItem) {
						var sPath = oSelItem.getBindingContext().getPath();
						var bChecked = _this.checkAssignedPernr(oSelItem.getBindingContext().getObject().PersonNo);
						if (bChecked) {
							oCraftMaster.loadWorkPlan(sPath);
						}
					}
				}
			},

			//Check the selected Lcomotive(for selected  Operations) are available in the workplan displayed. 
			//then Reload the work plan

			reloadFleetWorkPlan: function() {

				var sLocoId = _this._oGlobalModel.getProperty("/currentLocomotive").LocomotiveId;
				var bReloadWorkplan = _this.checkCurrentSelectedWorkPlanLoco(sLocoId);
				var oFleetController = this._oGlobalModel.getProperty("/fleetDetailsController");
				if (bReloadWorkplan) {
					oFleetController.fetchLocomotiveDetails();
				}

			},
			//Find the personal number of craft logged in the seleceted Crafts
			checkAssignedPernr: function(sPersNo) {
				var bPersonFound = false;
				_this._aSelectedWorkers.forEach(function(oSelectedWorker) {
					if (oSelectedWorker.PersonNo === sPersNo) {
						bPersonFound = true;
					}

				});
				return bPersonFound;
			},
			//Find the current selected locomitive is available in selected locomotives(for selected operations)
			checkCurrentSelectedWorkPlanLoco: function(sLocoId) {
				var bLocoFound = false;
				var aWorkAssigned = _this._oView.getModel().getProperty("/WorkAssigned");
				$.each(aWorkAssigned, function(keyL, oLocomotive) {
					if (keyL === sLocoId) {
						bLocoFound = true;
					}
				});
				return bLocoFound;
			},

			// #DontDelete : Q
			/**
			 * Close the selection of work dialog to display the selection of workers dialog
			 */
			onCraftAssignmentWorkCancelPress: function() {
				_this._oCraftAssignmentWorkDialog.open();
				_this._oCraftAssignmentListDialog.close();
			},

			// #DontDelete : Q
			/**
			 * Close the dialog view
			 */
			onCraftWorkCancelPress: function() {
				_this._oCraftAssignmentWorkDialog.close();
				if (_this._oCraftAssignmentSearchManager) {
					_this._oCraftAssignmentSearchManager.destroy();
					_this._oCraftAssignmentSearchManager = null;
				}
				if (_this._oCraftSearchFragment) {
					_this._oCraftSearchFragment.destroy();
					_this._oCraftSearchFragment = null;
				}
			}

		};
	});