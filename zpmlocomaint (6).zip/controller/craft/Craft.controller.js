// #DontDelete : Daya
//Chsnges by Ibrahim
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator"
], function(Controller, Constants, Formatter, BusyIndicator) {
	"use strict";

	var _this;

	return Controller.extend("com.sap.cp.lm.controller.craft.Craft", {
		
		//--------------------------------------------------------------------
		// Life cycle functions
		//--------------------------------------------------------------------
		
		/**
		 * Initializes the controller
		 */
		onInit: function() {
			_this = this;

			this._CraftSC = this.getView().byId("CraftSC");

			// listen to event when the map needs to be rendered in a full screen
			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.subscribe("CraftSC", "toggleSplitContainerMode", this.toggleSplitContainerMode, this);
			// listen to event when the map is in a full screen to show the master page as a layover on top of the detail page
			oEventBus.subscribe("CraftSC", "toggleSplitContainerShowMaster", this.toggleSplitContainerShowMaster, this);
		},
		
		//--------------------------------------------------------------------
		// Private functions
		//--------------------------------------------------------------------

		/**
		 * Show/Hide the master page as a layover on top of the detail page within the split controller
		 */
		toggleSplitContainerShowMaster: function(sChannel, sEvent, oData) {
			if (oData.hideMaster) {
				this._CraftSC.hideMaster();
			} else {
				this._CraftSC.showMaster();
			}
		},

		/**
		 * Toggle between full screen and not for the detail page(map view) within the split controller
		 */
		toggleSplitContainerMode: function(sChannel, sEvent, oData) {
			if (oData.hideMaster) {
				this._CraftSC.setMode("HideMode");
			} else {
				this._CraftSC.setMode("ShowHideMode");
			}
		}

	});
});