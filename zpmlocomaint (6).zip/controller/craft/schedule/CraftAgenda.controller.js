/* #DontDelete : Yann */
/*&----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2018.06.04                                           *
 * Incidinet      : Locomotive Maintenance - ASR3411887                  *
 * Description    : Added logic for for unavailability reason            *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2019.02.03                                           *
 * Incidinet      : EAM-ASR3413183 - PM Loco Main phase 2                *
 * Description    : Start/End time made mandatory for unavailable reason *
 *&----------------------------------------------------------------------*/
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
	"com/sap/cp/lm/model/craft/CraftDataModel",
	"com/sap/cp/lm/util/Helper",
	"sap/ui/unified/CalendarLegendItem",
	"sap/ui/unified/DateTypeRange"

], function (Controller, Constants, Formatter, BusyIndicator, LocomotiveDataModel, CraftDataModel, Helper, CalendarLegendItem,
	DateTypeRange) {
	"use strict";

	var _this;

	return Controller.extend(
		"com.sap.cp.lm.controller.craft.schedule.CraftAgenda", {

			//--------------------------------------------------------------------
			// Life cycle functions
			//--------------------------------------------------------------------

			/**
			 * Initializes the controller
			 */
			onInit: function () {
				_this = this;
				this.getView().setModel(new sap.ui.model.json.JSONModel());
				this._oModel = this.getView().getModel();
				this._oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());
				$(window).on('resize', $.proxy(this.handleWindowResize, this));

				_this._oGlobalModel = this.getOwnerComponent().getGlobalModel();

				// register to listen to change events of the globalmodel which contain the currentShop
				var binding = new sap.ui.model.Binding(this._oGlobalModel, "/", this._oGlobalModel.getContext("/"));
				binding.attachChange(function () {
					_this.onGlobalModelChange();
				});

				var oAvailability = [{
					"Text": "Available",
					"Value": "A"
				}, {
					"Text": "Unavailable",
					"Value": "U"
				}];

				this.getView().getModel().setProperty("/Availability", oAvailability);
				/*Added by Vikram	*/
				//Unavailability Reason
				// var oUnavailabilityReason = [{
				// 	"Text": "Servicing",
				// 	"Value": "SV"
				// }, {
				// 	"Text": "Shop Maintenance",
				// 	"Value": "SM"
				// }, {
				// 	"Text": "Health and Safety",
				// 	"Value": "HS"
				// }, {
				// 	"Text": "Fuel Truck",
				// 	"Value": "FT"
				// }, {
				// 	"Text": "Road Call",
				// 	"Value": "RC"
				// }, {
				// 	"Text": "Off",
				// 	"Value": "OF"
				// }];

				// this.getView().getModel().setProperty("/UnavailabilityReason", _this._oGlobalModel.getProperty("/unavailReasons"));
				/*Added by Vikram	*/
				this._setCalendarLegend();

				this._sShopId = _this._oGlobalModel.getProperty("/currentShop").Id;
				this._sPersonNo = _this._oGlobalModel.getProperty("/currentCraft").PersonNo;

				this.fetchAvailabilityForShopAndCraft();
			},

			/**
			 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
			 * This hook is the same one that SAPUI5 controls get after being rendered.
			 */
			onAfterRendering: function () {

			},

			//--------------------------------------------------------------------
			// Private functions
			//--------------------------------------------------------------------

			/**
			 * Display legend
			 */
			_setCalendarLegend: function () {
				var oLegend = this.getView().byId("craftCalendarLegend");

				oLegend.addItem(new CalendarLegendItem({
					text: "Available"
				}));

				oLegend.addItem(new CalendarLegendItem({
					text: "Unavailable"
				}));

				oLegend.addItem(new CalendarLegendItem({
					text: "Overtime"
				}));
			},

			fetchAvailabilityForShopAndCraft: function () {
				var sShopId = _this._oGlobalModel.getProperty("/currentShop").Id;
				var sPersonNo = _this._oGlobalModel.getProperty("/currentCraft").PersonNo;

				this._sShopId = sShopId;
				this._sPersonNo = sPersonNo;

				var date = new Date();
				var dFirstDay = new Date(date.getFullYear(), date.getMonth(), 1);
				var dLastDay = new Date(date.getFullYear(), date.getMonth() + 3, 0);

				var sFirstDay = Formatter.toDatetimeFormat(dFirstDay);
				var sLastDay = Formatter.toDatetimeFormat(dLastDay);

				var oPayload = {
					"Shop": this._sShopId,
					"PersonNo": this._sPersonNo,
					"FromDate": sFirstDay,
					"ToDate": sLastDay
				};

				CraftDataModel.fetchAvailabilityForShopAndCraft(oPayload, _this.fetchAvailabilityForShopAndCraftSuccess, _this.fetchAvailabilityForShopAndCraftFailure,
					_this);
			},

			fetchAvailabilityForShopAndCraftSuccess: function (oData) {
				_this.onDeselectAll();

				if (oData.results) {
					_this.aDays = oData.results;

				} else {
					_this.aDays = null;
				}
				_this.onRefreshCalendar();
			},

			fetchAvailabilityForShopAndCraftFailure: function () {

			},

			dayForDate: function (sSelectedDate) {
				var aDays = _this.aDays;
				var oSelectedDay;
				if (aDays && aDays.length > 0) {
					for (var i = 0; i < aDays.length; i++) {
						var aDay = aDays[i];

						//handle timezone
						var dDate = aDay.AvailDate;
						var dLocaleDate = _this.handleTimezone(dDate);

						var sDay = Formatter.changeDateFormatDayMMDDYY(dLocaleDate);

						if (sDay === sSelectedDate) {
							oSelectedDay = aDay;
							break;
						}
					}
				}

				return oSelectedDay;
			},

			displayDetailsForDay: function (oSelectedDay) {

				var oAvailabilityStatusSelect = this.getView().byId("craftCalendarAvailabilityStatus");
				oAvailabilityStatusSelect.setSelectedKey(oSelectedDay.AvailStatus);
				// Unavailability Reason start
				var oUnavailabilityReasonSelect = this.getView().byId("craftCalendarUnavailabilityReason");
				oUnavailabilityReasonSelect.setSelectedKey(oSelectedDay.UnavailReason);

				if (oSelectedDay.AvailStatus === "U") {
					oUnavailabilityReasonSelect.setVisible(true);
					/*Added by Vikram	*/
					this.getView().byId("startTime").setRequired(false);
					this.getView().byId("endTime").setRequired(false);
					/*Added by Vikram	*/
				} else {
					oUnavailabilityReasonSelect.setVisible(false);
					/*Added by Vikram	*/
					this.getView().byId("startTime").setRequired(true);
					this.getView().byId("endTime").setRequired(true);
					/*Added by Vikram	*/
				}
				// Unavailability Reason end
				var oAvailabilityStartTime = this.getView().byId("craftCalendarAvailabilityStartTime");
				var sAvailStart = Formatter.changeTimeFormatforSchedule(oSelectedDay.AvailStart);
				oAvailabilityStartTime.setValue(sAvailStart);

				var oAvailabilityEndTime = this.getView().byId("craftCalendarAvailabilityEndTime");
				var sAvailEnd = Formatter.changeTimeFormatforSchedule(oSelectedDay.AvailEnd);
				oAvailabilityEndTime.setValue(sAvailEnd);

				var oOvertimeStartTime = this.getView().byId("craftCalendarOvertimeStartTime");
				var sOtStart = Formatter.changeTimeFormatforSchedule(oSelectedDay.OtStart);
				oOvertimeStartTime.setValue(sOtStart);

				var oOvertimeEndTime = this.getView().byId("craftCalendarOvertimeEndTime");
				var sOtEnd = Formatter.changeTimeFormatforSchedule(oSelectedDay.OtEnd);
				oOvertimeEndTime.setValue(sOtEnd);

				_this.updateOT();
			},

			resetDay: function () {
				_this.resetDayBypass(false);
			},

			resetDayBypass: function (bBypass) {
				if (bBypass === false) {
					var oAvailabilityStatusSelect = this.getView().byId("craftCalendarAvailabilityStatus");
					oAvailabilityStatusSelect.setSelectedKey("A");
				}

				var oAvailabilityStartTime = this.getView().byId("craftCalendarAvailabilityStartTime");
				oAvailabilityStartTime.setValue("");

				var oAvailabilityEndTime = this.getView().byId("craftCalendarAvailabilityEndTime");
				oAvailabilityEndTime.setValue("");

				var oOvertimeStartTime = this.getView().byId("craftCalendarOvertimeStartTime");
				oOvertimeStartTime.setValue("");

				var oOvertimeEndTime = this.getView().byId("craftCalendarOvertimeEndTime");
				oOvertimeEndTime.setValue("");
			},

			/**
			 * Prepare batch payloads
			 */
			mergeDaysAndPayload: function (aDays) {
				var aPayloads = [];

				for (var i = 0; i < aDays.length; i++) {
					var oDay = aDays[i];
					var oPayload = _this.getAvailabilityPayload();
					oPayload["AvailDate"] = oDay;
					aPayloads.push(oPayload);
				}

				return aPayloads;
			},

			/**
			 * Get selected days to update
			 */
			getTheSelectedDays: function () {
				var aAvailDates = [];
				var aDays = _this._oModel.getProperty("/SelectedDays");
				if (aDays.length <= 0) {
					return;
				}

				for (var i = 0; i < aDays.length; i++) {
					var oDay = aDays[i];
					var dAvailDate = oDay.AvailDate;
					var dTmpDate = dAvailDate.getTime() + (dAvailDate.getTimezoneOffset() * 60000);
					var dLocalDate = new Date(dTmpDate);
					var sAvailDate = Formatter.toDatetimeFormat(dLocalDate);
					aAvailDates.push(sAvailDate);
				}

				return aAvailDates;
			},

			/**
			 * Get base payload
			 */
			getAvailabilityPayload: function () {
				var sShopId = _this._oGlobalModel.getProperty("/currentShop").Id;
				var sPersonNo = _this._oGlobalModel.getProperty("/currentCraft").PersonNo;

				var sAvailStatus = _this.getView().byId("craftCalendarAvailabilityStatus").getSelectedItem().getKey();

				var sUnavailReason = _this.getView().byId("craftCalendarUnavailabilityReason").getSelectedItem().getKey();

				var sAvailStart = _this.getView().byId("craftCalendarAvailabilityStartTime").getValue();
				sAvailStart = Formatter.availabilityTimeFormat(sAvailStart);

				var sAvailEnd = _this.getView().byId("craftCalendarAvailabilityEndTime").getValue();
				sAvailEnd = Formatter.availabilityTimeFormat(sAvailEnd);

				var sOtStart = _this.getView().byId("craftCalendarOvertimeStartTime").getValue();
				sOtStart = Formatter.availabilityTimeFormat(sOtStart);

				var sOtEnd = _this.getView().byId("craftCalendarOvertimeEndTime").getValue();
				sOtEnd = Formatter.availabilityTimeFormat(sOtEnd);

				var oPayload = {
					"ShopId": sShopId,
					"PersonNo": sPersonNo,
					"AvailStatus": sAvailStatus,
					"UnavailReason": sUnavailReason,
					"AvailStart": sAvailStart,
					"AvailEnd": sAvailEnd
				};

				if (sOtStart && sOtEnd) {
					oPayload["OtStart"] = sOtStart;
					oPayload["OtEnd"] = sOtEnd;
				}

				return oPayload;
			},

			updateOT: function () {
				var oAvailabilityStatusSelect = this.getView().byId("craftCalendarAvailabilityStatus");

				var oAvailStartTime = this.getView().byId("craftCalendarAvailabilityStartTime");
				var oAvailEndTime = this.getView().byId("craftCalendarAvailabilityEndTime");
				var oOvertimeStartTime = this.getView().byId("craftCalendarOvertimeStartTime");
				var oOvertimeEndTime = this.getView().byId("craftCalendarOvertimeEndTime");

				if (oAvailabilityStatusSelect.getSelectedItem().getText() === "Unavailable") {
					oOvertimeStartTime.setEnabled(false);
					oOvertimeEndTime.setEnabled(false);
					oAvailStartTime.setEnabled(false);
					oAvailEndTime.setEnabled(false);
				} else {
					oOvertimeStartTime.setEnabled(true);
					oOvertimeEndTime.setEnabled(true);
					oAvailStartTime.setEnabled(true);
					oAvailEndTime.setEnabled(true);
				}
			},

			//--------------------------------------------------------------------
			// Event handlers
			//--------------------------------------------------------------------

			/**
			 * When the global model is changed
			 */
			onGlobalModelChange: function () {
				var oShop = _this._oGlobalModel.getProperty("/currentShop");

				if (oShop) {
					var sShopId = oShop.Id;
					var sPersonNo = _this._oGlobalModel.getProperty("/currentCraft").PersonNo;

					if (sShopId !== this._sShopId || sPersonNo !== this._sPersonNo) {
						_this.fetchAvailabilityForShopAndCraft();
					}
				}
			},

			/**
			 * Sets height of the shop page
			 */
			handleWindowResize: function () {

			},

			/**
			 * Handle timezone
			 */
			handleTimezone: function (dDate) {
				var dTmpDate = dDate.getTime() + (dDate.getTimezoneOffset() * 60000);
				return new Date(dTmpDate);
			},

			/** 
			 * Handle calendar input
			 */
			onHandleCalendarSelect: function (oEvent) {
				var aSelectedDays = [];
				var aSelectedDates = oEvent.getSource().getSelectedDates();
				var oLastSelection;

				for (var i = 0; i < aSelectedDates.length; i++) {
					var oDate = aSelectedDates[i];
					var dDate = oDate.getStartDate();
					var dLocaleDate = _this.handleTimezone(dDate);
					var sSelectedDate = Formatter.changeDateFormatDayMMDDYY(dLocaleDate);

					var oSelectedDay = _this.dayForDate(sSelectedDate);
					if (!oSelectedDay) {
						oSelectedDay = {
							"AvailDate": dLocaleDate
						};
					}
					oLastSelection = oSelectedDay;
					aSelectedDays.push(oSelectedDay);
				}

				_this._oModel.setProperty("/SelectedDays", aSelectedDays);

				if (oLastSelection) {
					_this.displayDetailsForDay(oSelectedDay);
				} else {
					_this.resetDay();
				}
			},

			/**
			 * Calendar utility
			 */
			onRefreshCalendar: function () {
				var oCalendar = this.getView().byId("craftCalendar");
				oCalendar.removeAllSpecialDates();
				oCalendar.removeAllSelectedDates();

				var aDays = _this.aDays;

				if (aDays && aDays.length > 0) {
					for (var i = 0; i < aDays.length; i++) {
						var aDay = aDays[i];
						var dDate = new Date(aDay.AvailDate);

						//handle timezone
						var dLocaleDate = _this.handleTimezone(dDate);

						var sType = "Type01";
						var sLegend = "Available";
						if (aDay.AvailStatus === "U") {
							sType = "Type02";
							sLegend = "Unavailable";
						}
						if (aDay.OtStart.ms !== 0 && aDay.OtEnd.ms !== 0) {
							sType = "Type03";
							sLegend = "Overtime";
						}
						_this.onAddDayType(dLocaleDate, sType, sLegend);
					}
				}
			},

			onAddDayType: function (oDate, sType, sLegend) {
				var oCalendar = this.getView().byId("craftCalendar");

				oCalendar.addSpecialDate(new DateTypeRange({
					startDate: oDate,
					type: sType,
					tooltip: sLegend
				}));
			},

			/**
			 * Handle availability input
			 */
			onSave: function (oEvent) {
				/*Added by Vikram	*/
				if (this.getView().byId("craftCalendarAvailabilityStatus").getSelectedKey() === "A") {
					var startTime = this.getView().byId("craftCalendarAvailabilityStartTime").getValue();
					var endTime = this.getView().byId("craftCalendarAvailabilityEndTime").getValue();
					if (!startTime || !endTime) {
						sap.ui.require(["sap/m/MessageToast"], function (MessageToast) {
							MessageToast.show("Enter Start Time and End Time");
						});
						return;
					}
				}
				/*Added by Vikram	*/
				var aDays = _this.getTheSelectedDays();
				if (aDays && aDays.length > 0) {
					var aPayloads = _this.mergeDaysAndPayload(aDays);

					if (aPayloads && aPayloads.length > 0) {
						CraftDataModel.setBatchAvailabilityForShopAndCraft(aPayloads, _this.setAvailabilityForShopAndCraftSuccess, _this.setAvailabilityForShopAndCraftFailure,
							_this);
					}
				}
			},

			setAvailabilityForShopAndCraftSuccess: function (oData) {
				_this.fetchAvailabilityForShopAndCraft();
			},

			setAvailabilityForShopAndCraftFailure: function () {

			},

			onChangeAvailability: function (oEvent) {

				var selectedKey = this.getView().byId("craftCalendarAvailabilityStatus").getSelectedKey();
				var oReasonInput = this.getView().byId("craftCalendarUnavailabilityReason");
				if (selectedKey === "U") {
					oReasonInput.setVisible(true);
					/*Added by Vikram	*/
					this.getView().byId("startTime").setRequired(false);
					this.getView().byId("endTime").setRequired(false);
					/*Added by Vikram	*/
				} else {
					oReasonInput.setVisible(false);
					/*Added by Vikram	*/
					this.getView().byId("startTime").setRequired(true);
					this.getView().byId("endTime").setRequired(true);
					/*Added by Vikram	*/
				}
				_this.resetDayBypass(true);

				_this.updateOT();

			},

			/**
			 * Deselect all days
			 */
			onDeselectAll: function (oEvent) {
				var oCalendar = this.getView().byId("craftCalendar");
				oCalendar.removeAllSelectedDates();
				_this._oModel.setProperty("/SelectedDays", []);
				_this.resetDay();
			}

		});
});