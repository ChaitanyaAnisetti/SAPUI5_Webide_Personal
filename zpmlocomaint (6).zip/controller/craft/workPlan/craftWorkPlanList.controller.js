// #DontDelete : Daya New controller class, dont delete any method in this class
/*&-----------------------------------------------------------------------*    
 * Author         : KIR0084                                              *
 * Date           : 2019.04.01                                           *
 * Incidinet      : LMP2-36 - Change to edit Comment Button        	     *
 * Description    : Change to edit Comment Button                 		 *
 * Search Term    : LMP2-36                                              *
 *&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 01-Dec-2021	                                       *
* Project             : EAM-LLM 1.2 Serialization     					   *
* Description         : Serialization of material and equipment			   *
* Search Term         : LLM1.2	                                           *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : ANI0006				        		       		   *
* Date                : 11-Nov-2021	                                       *
* Project             : EAM Railinc EPA    					               *
* Description         : EPA Information - Fields Masking		           *
* Search Term         : ANI0006 2000014601                                 *
/*&------------------------------------------------------------------------*/
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
	"com/sap/cp/lm/util/Helper",
	"com/sap/cp/lm/controller/common/MeasPointSheet",
	"com/sap/cp/lm/controller/common/SerialNumber",
	"com/sap/cp/lm/controller/myShop/common/OperationLongTextDialog",
	"com/sap/cp/lm/controller/myShop/common/WorkOrderComments"

], function (Controller, Constants, Formatter, BusyIndicator, LocomotiveDataModel, Helper, MeasPointSheet, SerialNumber,
	OperationLongTextDialog, WorkOrderComments) {
	"use strict";

	var _this;

	return Controller.extend(
		"com.sap.cp.lm.controller.craft.workPlan.craftWorkPlanList", {

			//--------------------------------------------------------------------
			// Life cycle functions
			//--------------------------------------------------------------------

			/**
			 * Initializes the controller
			 */
			onInit: function () {
				_this = this;
				this.getView().setModel(new sap.ui.model.json.JSONModel());

				this._bHideComplete = false;

				this._oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());
				$(window).on('resize', $.proxy(this.handleWindowResize, this));

				this._oGlobalLocomotiveModel = this.getOwnerComponent().getGlobalLocomotiveModel();
				this._oI18nModel = this.getOwnerComponent().getModel("i18n");
				this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
				// Added by ANI0006 2000014601 - get Engine Manfacture Model
				_this._oEngineManfModel = _this.getOwnerComponent().getEngManfJsonModel();
				this.onGlobalModelChange();

				// register to listen to change events of the globalmodel which contain the currentShop
				var binding = new sap.ui.model.Binding(this._oGlobalModel, "/", this._oGlobalModel.getContext("/"));
				binding.attachChange(function () {
					_this.onGlobalModelChange();
				});

				this._oRouter.getTargets().attachDisplay(function (oEvent) {
					if (oEvent.getParameter("name") === "CraftDetails") {
						_this.oCraft = oEvent.getParameter("data");
						_this._reloadCraftDetails();
					}
				});
			},

			/**
			 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
			 * This hook is the same one that SAPUI5 controls get after being rendered.
			 */
			onAfterRendering: function () {
				_this.handleWindowResize();
			},

			//--------------------------------------------------------------------
			// Private functions
			//--------------------------------------------------------------------

			/**
			 * Reload inbounds locomotives from backend
			 */
			_reloadCraftDetails: function () {
				var sShopId = _this._oGlobalModel.getProperty("/currentShop").Id;
				LocomotiveDataModel.fetchMyWork(_this._onSuccessCraftDetails, _this._onErrorCraftDetails, _this, sShopId, _this.oCraft.PersonNo);
			},

			/* KIR0084 LMP2-36 Add function for reloading task list */
			_reloadCraftDetailsTaskList: function (context) {
				var sShopId = _this._oGlobalModel.getProperty("/currentShop").Id;

				var fnSuccess = function (oData) {
					_this._onSuccessCraftTaskListDetails.call(_this, oData, context);
				};

				LocomotiveDataModel.fetchMyWork(fnSuccess, _this._onErrorCraftDetails, _this, sShopId, _this.oCraft.PersonNo);
			},
			/* KIR0084 LMP2-36 Add function for reloading task list */

			refreshCompleteToggle: function () {
				var sFragmentId = this.getView().createId("idMyOperations");

				//update table rows
				var oTable = sap.ui.core.Fragment.byId(sFragmentId, "idCraftOperations");
				var aItems = oTable.getItems();
				var oModel = oTable.getModel("craftOperations");

				for (var i = 0; i < aItems.length; i++) {
					var oItem = aItems[i];
					var oObject = oModel.getProperty("/WorkList/" + i);
					var bHide = false;

					if (oObject.Status === "0" && this._bHideComplete) {
						bHide = true;
					}

					if (bHide === true) {
						oItem.addStyleClass("lmHidden");
					} else {
						oItem.removeStyleClass("lmHidden");
					}
				}

				//update button
				var oButton = sap.ui.core.Fragment.byId(sFragmentId, "ToggleCompleteButton");
				if (!this._bHideComplete) {
					oButton.setText("Hide Complete");
				} else {
					oButton.setText("Show All");
				}
			},

			/**
			 * Open wheel Sheet for the selected task
			 */
			_openWheelSheet: function (oWSHeader) {

				if (!_this.WSSaveBtnId) {
					_this.WSSaveBtnId = this.createId("WSSaveBtn");
				}

				if (!_this.WSSubmitBtnId) {
					_this.WSSubmitBtnId = this.createId("WSSubmitBtn");
				}

				if (!this.oDialog) {
					this.oDialog = new sap.m.Dialog({
						title: oWSHeader.Descr,
						height: "100%",
						width: "100%",
						content: [],
						buttons: [
							new sap.m.Button({
								text: "{i18n>CLOSE}",
								press: function () {
									_this.oDialog.close();
								}
							}),
							new sap.m.Button(_this.WSSaveBtnId, {
								text: "{i18n>SAVE}",
								press: function () {
									var oController = _this.oDialog.getContent()[0].getController();
									oController.onSaveWheelSheet();
								}
							}),
							new sap.m.Button(_this.WSSubmitBtnId, {
								text: "{i18n>SUBMIT}",
								enabled: false,
								type: "Emphasized",
								press: function () {
									var oController = _this.oDialog.getContent()[0].getController();
									oController.onSubmitWheelSheet();
								}
							})
						],
						afterOpen: this.resizeDialog
					});

					this.wheelSheetDialogId = this.oDialog.sId;

					var oContent = new sap.ui.xmlview({
						viewName: "com.sap.cp.lm.view.myShop.common.wheelSheet.WheelSheet"
					});

					this.oDialog.addContent(oContent);
				}

				var oCurrentLocomotive = this._oGlobalModel.getProperty("/currentLocomotive");

				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setProperty("/WSHeader", oWSHeader);
				oModel.setProperty("/WSSaveBtnId", _this.WSSaveBtnId);
				oModel.setProperty("/WSSubmitBtnId", _this.WSSubmitBtnId);
				this.oDialog.setModel(oModel);
				this.getView().addDependent(this.oDialog);
				this.oDialog.open();

				var oController = this.oDialog.getContent()[0].getController();
				oController.fetchLocomotiveWheelSheet(oCurrentLocomotive);

			},

			resizeDialog: function () {
				var frameHeight = $(window).height();
				var frameWidth = $(window).width();

				this.setContentHeight(frameHeight * 0.75 + "px");
				this.setContentWidth(frameWidth * 0.75 + "px");
			},

			/**
			 * Open Measurement point for Selected Task
			 */
			openMeasPoint: function (oWSHeader) {
				var aData = {};
				aData.oTaskHeader = oWSHeader;
				aData.oTaskHeader.oSourceViewController = this;
				var oMeasPointDialog = new MeasPointSheet(aData);

				var i18nModel = this.getOwnerComponent().getModel("i18n");
				oMeasPointDialog.getFragment().setModel(i18nModel, "i18n");
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oMeasPointDialog);
				oMeasPointDialog.getFragment().open();
			},

			/**
			 * Open Serial no for Selected Task
			 */
			openSerialNo: function (oWSHeader) {
				var aData = {};
				aData.oTaskHeader = oWSHeader;
				aData.oTaskHeader.oSourceViewController = this;
				var oSerialNoDialog = new SerialNumber(aData);
				var i18nModel = this.getOwnerComponent().getModel("i18n");
				oSerialNoDialog.getFragment().setModel(i18nModel, "i18n");

				// Added by  ANI0006 2000014601 - Engine Manufacture model 
				if (!_this._oEngineManfModel && _this.getOwnerComponent()) {
					_this._oEngineManfModel = _this.getOwnerComponent().getEngManfJsonModel();
				}
				/* Start - ANI0006 2000014601 - _oEngineManfModel undefined so replace with _oEngineManfModel */
				oSerialNoDialog.getFragment().setModel(_this._oEngineManfModel, "GLOBALENGINEMANFMODEL");
				/* End - ANI0006 2000014601 - _oEngineManfModel undefined so replace with _oEngineManfModel */

				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oSerialNoDialog);
				oSerialNoDialog.getFragment().open();
			},

			//--------------------------------------------------------------------
			// Event handlers
			//--------------------------------------------------------------------

			/* KIR0084 LMP2-36 Add refresh craft task list */
			_onSuccessCraftTaskListDetails: function (oData, sPath) {
				var oModel = new sap.ui.model.json.JSONModel();
				var aData = {};
				aData.WorkList = oData.results;
				aData.operationsListType = null;

				oModel.setData(aData);
				this.getView().setModel(oModel, "craftOperations");

				if (_this.oTaskListPath) {
					var aDetails = this.getView().getModel("craftOperations").getObject(_this.oTaskListPath);
					this.getView().getModel("myWorkDetails").setData(aDetails);
				}
			},
			/* KIR0084 LMP2-36 Add refresh craft task list */

			/**
			 * Success callback function for readInboundLocomotive
			 */
			_onSuccessCraftDetails: function (oData) {
				var oModel = new sap.ui.model.json.JSONModel();
				var aData = {};
				aData.WorkList = oData.results;
				aData.operationsListType = null;

				oModel.setData(aData);
				this.getView().setModel(oModel, "craftOperations");

				this.refreshCompleteToggle();

				BusyIndicator.hideBusyIndicator();

				var oTaskModel = new sap.ui.model.json.JSONModel();
				this.getView().setModel(oTaskModel, "myWorkDetails");
				this.getView().byId("idCraftTaskBox").setVisible(false);
				this.getView().byId("idCraftOpBox").setVisible(true);
			},

			/**
			 * Open long text dialog on button click
			 */
			onClickLongTextOpen: function (oEvent) {
				/** START KIR0084 LMP2-36 This control is getting called from myWorkDetailsTask because of how craftOperation.fragment is made. 
				                          Check the models so we are using the real ones*/
				var context = oEvent.getSource().getBindingContext("craftOperations") || oEvent.getSource().getBindingContext("myWorkDetails");
				var oModel = context.getModel();
				/** End KIR0084 LMP2-36 . */

				var sBindingPath = context.sPath;

				if (sBindingPath) {
					var oDataObject = oModel.getObject(sBindingPath);

					Helper.openLongTextDialog(oDataObject);
				}
			},

			/** START KIR0084 LMP2-36 Allow adding of sub-operation long text. */
			/**
			 * Open Task List Long Text
			 */
			onClickCommentOpen: function (oEvent) {
				var context = oEvent.getSource().getBindingContext("craftOperations");
				var oParams = {};
				oParams.fnFirstCommentAdded = _this._reloadCraftDetails.bind(_this);

				if (context === undefined) {
					context = oEvent.getSource().getBindingContext("myWorkDetails");
					oParams.fnFirstCommentAdded = _this._reloadCraftDetailsTaskList.bind(_this, context);
				}
				oParams.oWorkOrderHeader = context.getObject();

				var oWorkOrderComments = new WorkOrderComments(oParams);
				if (!_this._oI18nModel && _this.getOwnerComponent()) {
					_this._oI18nModel = _this.getOwnerComponent().getModel("i18n");
				}
				oWorkOrderComments.getFragment().setModel(_this._oI18nModel, "i18n");
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oWorkOrderComments);
				oWorkOrderComments.getFragment().open();
			},
			/** END KIR0084 LMP2-36 Allow adding of sub-operation long text. */

			/**
			 * Failed callback function for readInboundLocomotive
			 */
			_onErrorCraftDetails: function (oData) {
				BusyIndicator.hideBusyIndicator();
			},

			/**
			 * when the global model is changed
			 */
			onGlobalModelChange: function () {
				_this._currentShop = this._oGlobalModel.getProperty("/currentShop");
			},

			/**
			 * sets height of the shop page
			 */
			handleWindowResize: function () {

			},

			onRefreshList: function () {
				_this._reloadCraftDetails();
			},

			onToggleComplete: function (oEvent) {
				_this._bHideComplete = !_this._bHideComplete;

				_this.refreshCompleteToggle();
			},

			/**
			 * Fired when an operation is selected
			 */
			onClickMyWorkOperation: function (oEvent) {
				var oSelContext = oEvent.getSource().getBindingContext("craftOperations");
				var aDetails = this.getView().getModel("craftOperations").getObject(oSelContext.sPath);
				_this.oTaskListPath = oSelContext.sPath;

				this.getView().getModel("myWorkDetails").setData(aDetails);
				this.getView().byId("idCraftTaskBox").setVisible(true);
				this.getView().byId("idCraftOpBox").setVisible(false);
				this.byId(sap.ui.core.Fragment.createId("idMyTasks", "idTaskHeaderToolBar")).setVisible(true);

			},

			formatVisibilitySelectAllCheckbox: function (oTasks) {
				return false;
			},

			formatVisibileSelection: function (oTasks) {
				return false;
			},

			/**
			 * Display My Work view
			 */
			onNavBack: function () {
				this.getView().byId("idCraftTaskBox").setVisible(false);
				this.getView().byId("idCraftOpBox").setVisible(true);
				this.getView().byId("craftPage").setShowNavButton(false);
			},

			/**
			 * Open the Wheel Sheet Dialog
			 */
			onClickCreateWS: function (oEvent) {
				var aSelObject = oEvent.getSource().getBindingContext("myWorkDetails").getObject();
				var oSelOperation = oEvent.getSource().getModel("myWorkDetails").getData();
				var oWSHeader = {
					"OperationNbr": oSelOperation.Activity,
					"OrderNbr": oSelOperation.OrderNo,
					"SubOperNbr": aSelObject.SubOp,
					"EquipNbr": oSelOperation.EquipNo,
					"MsetType": aSelObject.MeasurementSetType,
					"MeasPntValue": aSelObject.MeasPntValue,
					"MeasurementPointName": aSelObject.MeasurementPointName,
					"InstallPosition": aSelObject.InstallPosition,
					"SerialNbr": aSelObject.SerialNbr, // SHE0272 - LLM3.2 - Trimmed Space from Serial Number
					// Start - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
					"ObjectType": aSelObject.ObjectType,
					"Room": aSelObject.Room,
					"SoftwareCharacteristic": aSelObject.SoftwareCharacteristic,
					"SoftwareClass": aSelObject.SoftwareClass,
					"MeasurementType": aSelObject.MeasurementType,
					// End - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
					// Start - SHE0272 - LLM1.2 - Serialization
					// "GoodsIssueAndReturn": aSelObject.GoodsmvtIndi,
					// "Plant": this._oGlobalModel.getProperty("/currentShop/Id"),
					// "SerializedMaterial": aSelObject.SerializedMatnr,
					// "UserRole": this._oGlobalModel.getProperty("/role"),
					// End - SHE0272 - SHE0272 - LLM1.2 - Serialization
					// Start - EPA Information_Serial Number mask inputs
					"Measurement": aSelObject.Measurement
						// End - EPA Information_Serial Number mask inputs
				};

				switch (aSelObject.MeasurementType) {
				case Constants.MEASTYPE.WHEEL_SHEET:
					_this._openWheelSheet(oWSHeader);
					break;
				case Constants.MEASTYPE.MS_MEGAWATT_HOUR_A:
					_this.openMeasPoint(oWSHeader);
					break;
				case Constants.MEASTYPE.SERIALNUMBER:
					_this.openSerialNo(oWSHeader);
					break;
					// Start - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
				case Constants.MEASTYPE.SW_VERSION_NUMBER:
					_this.openSerialNo(oWSHeader);
					break;
					// End - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
					// Start - SHE0272 - LLM1.2 - Serialization
				// case Constants.MEASTYPE.SERIALIZATION_NUMBERR:
				// 	_this.openSerialNo(oWSHeader);
				// 	break;
					// End - SHE0272 - LLM1.2 - Serialization
					// Start - ANI0006 2000014601 - EPA Information_Serial Number mask inputs * Case 6
				case Constants.MEASTYPE.EPA_INFORMATION:
					_this.openSerialNo(oWSHeader);
					break;
					// End - ANI0006 2000014601 - EPA Information_Serial Number mask inputs  * Case 6
				}
			},

			// onUnassign: function(oEvent) {
			// 		var oSelectedItems = this.getView().byId("idCraftOpBox").getContent()[0].getContent()[0].getSelectedItems();
			// 		var sPersNumber = _this.oCraft.PersonNo;
			// 		oSelectedItems.forEach(function(oItem) {
			// 			var oOperation = oItem.getBindingContext("craftOperations").getObject();
			// 			var sRecord = "/AssignmentSet(RoutingNo='" + oOperation.RoutingNo + "',OpNode='" + oOperation.OpNode + "',PersonNo='" +
			// 				sPersNumber + "')";
			// 			LocomotiveDataModel.DeleteAssignmentFromOperation(sRecord, _this.onDeleteSuccess,
			// 				"", this);

			// 		});
			// 		// _this.onRefreshList();

			// 	},
			// 	onDeleteSuccess: function(){

			// 	}

			// onDeleteAssignmentFailed: function(){

			// }
			onDeleteOperation: function (oEvent) {
				var oItem = oEvent.getParameter("listItem");
				var sPersNumber = _this.oCraft.PersonNo;
				if (oItem) {
					var oOperation = oItem.getBindingContext("craftOperations").getObject();
					var sRecord = "/AssignmentSet(RoutingNo='" + oOperation.RoutingNo + "',OpNode='" + oOperation.OpNode + "',PersonNo='" +
						sPersNumber + "')";
					LocomotiveDataModel.DeleteAssignmentFromOperation(sRecord, _this.onRefreshList,
						"", this);
				}
			}

		});
});