/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.05                                           *
* Project        : Locomotive Maintenance                               *
* Description    : This is the manager for the view Craft History.      *
*&----------------------------------------------------------------------*/

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
	"com/sap/cp/lm/util/Helper",
	"com/sap/cp/lm/util/ErrorManager"

], function(Controller, Constants, Formatter, BusyIndicator, LocomotiveDataModel, Helper, ErrorManager) {
	"use strict";

	var _this;

	return Controller.extend(
	"com.sap.cp.lm.controller.craft.history.CraftHistory", {
		
		//--------------------------------------------------------------------
		// Life cycle functions
		//--------------------------------------------------------------------
		
		// #DontDelete : Q
		/**
		 * Initializes the controller
		 */
		onInit: function() {
			_this = this;
			_this.getView().setModel(new sap.ui.model.json.JSONModel());
			_this._oModel = this.getView().getModel();
			_this._oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());
			
			_this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
			_this._oI18nModel = this.getOwnerComponent().getModel("i18n");
			
			_this._resetModelProperty();
			
			this._oRouter.getTargets().attachDisplay(function(oEvent) {
				if (oEvent.getParameter("name") === "CraftDetails") {
					_this.oCraft = oEvent.getParameter("data");
					_this._reloadCraftHistoryDetails();
				}
			});
		},
		
		//----------------------------------------------------------------------
		// Private functions
		//----------------------------------------------------------------------
		
		// #DontDelete : Q
		/**
		 * Reset the dates from and to for initial values
		 */
		_resetModelProperty: function() {
			var iCraftHistDays = _this._oGlobalModel.getProperty(Constants.ZPM_LM_CRAFT_HIST_DAYS);
			if(!iCraftHistDays) {
				iCraftHistDays = 2;
			}
			
			var dToday = new Date();
			var dHistoryDay = new Date();
			dHistoryDay.setDate(dHistoryDay.getDate() - iCraftHistDays);
			
			_this.getView().getModel().setProperty("/DateFrom", dHistoryDay);
			_this.getView().getModel().setProperty("/DateTo", dToday);
			_this.getView().getModel().setProperty("/DateRangeValid", true);
		},
		
		// #DontDelete : Q
		/**
		 * Reload craft worker history from backend
		 */
		_reloadCraftHistoryDetails: function() {
			var bValid = _this.getView().getModel().getProperty("/DateRangeValid");
			var dFromDate = _this.getView().getModel().getProperty("/DateFrom");
			var dToDate = _this.getView().getModel().getProperty("/DateTo");
			
			if(bValid && dFromDate && dToDate) {
				var sShopId = _this._oGlobalModel.getProperty("/currentShop").Id;
				var sPersonNo = _this._oGlobalModel.getProperty("/currentCraft").PersonNo;
				var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern : "yyyy-MM-ddTHH:mm:ss" });
				var sFromDate = dateFormat.format(dFromDate);
				var sToDate = dateFormat.format(dToDate);
				    
				LocomotiveDataModel.fetchCraftWorkerHistory(_this._onSuccessCraftHistoryDetails, _this._onErrorCraftHistoryDetails, _this, 
				sShopId, sPersonNo, sFromDate, sToDate);
			} else {
				ErrorManager.handleError("", _this._oI18nModel.getProperty("ERROR_DATE_RANGE_SELECTON"));
			}
		},
		
		//----------------------------------------------------------------------
		// Event handlers
		//----------------------------------------------------------------------
		
		// #DontDelete : Q
		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 */
		onAfterRendering: function() {
			_this._resetModelProperty();
			_this._reloadCraftHistoryDetails();
		},
		
		// #DontDelete : Q
		/**
		 * Success callback function for fetchCraftWorkerHistory
		 */
		_onSuccessCraftHistoryDetails: function(oData) {
			_this.getView().getModel().setProperty("/CraftHistoryOperations", oData.results);

			BusyIndicator.hideBusyIndicator();
		},
		
		// #DontDelete : Q
		/**
		 * Failed callback function for readInboundLocomotive
		 */
		_onErrorCraftHistoryDetails: function(oData) {
			BusyIndicator.hideBusyIndicator();
		},
		
		// #DontDelete : Q
		/**
		 * Open long text dialog on button click
		 */
		onClickLongTextOpen: function(oEvent) {
			var sBindingPath = oEvent.getSource().getBindingContext("craftOperations").sPath;

			if (sBindingPath) {
				var oDataObject = this.getView().getModel("craftOperations").getObject(sBindingPath);

				Helper.openLongTextDialog(oDataObject);
			}
		},
		
		// #DontDelete : Q
		/**
		 * Fired when date range is set. Call method to fetch list from backend.
		 */
		onDateRangeChange: function (oEvent) {
			var bValid = oEvent.getParameter("valid");
			_this.getView().getModel().setProperty("/DateRangeValid", bValid);
			
			_this._reloadCraftHistoryDetails();
		},
		
		// #DontDelete : Q
		/**
		 * Fired when date range is set. Call method to fetch list from backend.
		 */
		onRefreshList: function() {
			_this._reloadCraftHistoryDetails();
		}
	});
});