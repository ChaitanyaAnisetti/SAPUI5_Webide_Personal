/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.21                                           *
* Project        : Locomotive Maintenance                               *
* Description    : Controller for the Craft Container fragment used     *
*                  on Craft page.                                       *
*&----------------------------------------------------------------------*/

sap.ui.define([
	"sap/ui/core/mvc/Controller",

	"com/sap/cp/lm/util/BusyIndicator"

], function(Controller, BusyIndicator) {
	"use strict";

	var _this;

	return Controller.extend(
		"com.sap.cp.lm.controller.craft.CraftContainer", {
			
			//--------------------------------------------------------------------
			// Life cycle functions
			//--------------------------------------------------------------------
			
			/**
			 * Initializes the controller
			 */
			onInit: function() {
				_this = this;

				_this.getView().setModel(new sap.ui.model.json.JSONModel());
				_this._oRouter = sap.ui.core.UIComponent.getRouterFor(_this.getView());
				$(window).on('resize', $.proxy(this.handleWindowResize, this));

				this._oRouter.getTargets().attachDisplay(function(oEvent) {
					if (oEvent.getParameter("name") === "CraftDetails") {
						_this.oCraft = oEvent.getParameter("data");
                        
						var oLabel = _this.getView().byId("idSelectedCraftLabel");
						if (oLabel) {
							oLabel.setText(_this.oCraft.Name);
						}
					}
				});

				BusyIndicator.hideBusyIndicator();
			},

			/**
			 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
			 * This hook is the same one that SAPUI5 controls get after being rendered.
			 */
			onAfterRendering: function() {},

			handleWindowResize: function() {},
		
			//--------------------------------------------------------------------
			// Event handlers
			//--------------------------------------------------------------------
			
			/**
			 * Handles selection of Icon Tab Bar
			 * @params(event) oEvent is returned on
			 * 				  icon tab bar selection changes
			 */
			onCraftIconSelect: function(oEvent) {
				var sKey = oEvent.getParameters().key;
				if (sKey === "CraftTimeSheet") {
					//_this.crossApplicationNavigation();
				}
				if (sKey === "CraftAssignment") {
    				this.getOwnerComponent().getGlobalModel().setProperty("/isCraftMapView", true);
				} else {
    				this.getOwnerComponent().getGlobalModel().setProperty("/isCraftMapView", false);
				}  
			}

		});
});