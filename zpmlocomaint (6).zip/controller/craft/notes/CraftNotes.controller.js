/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.21                                           *
* Project        : Locomotive Maintenance                               *
* Description    : Controller for the Notes fragment on the Craft       *
*                  page for a worker.                                   *
*&----------------------------------------------------------------------*/

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel"
], function(Controller, Constants, Formatter, BusyIndicator, LocomotiveDataModel) {
	"use strict";

	var _this;

	return Controller.extend("com.sap.cp.lm.controller.craft.notes.CraftNotes", {
		
		//--------------------------------------------------------------------
		// Life cycle functions
		//--------------------------------------------------------------------
		
		/**
		 * Initializes the controller
		 */
		onInit: function() {
			_this = this;
			if (this.getOwnerComponent()) {
				this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
			}
			var oModel = new sap.ui.model.json.JSONModel();
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());
			oModel.setProperty("/CraftNoteSet", "");
			oModel.setProperty("/Note", "");
			this.getView().setModel(oModel);
			_this.sPrevCraftID = "";

			this._oRouter.getTargets().attachDisplay(function(oEvent) {
				if (oEvent.getParameter("name") === "CraftDetails") {
					_this.sPrevCraftID = oEvent.getParameter("data").PersonNo;
					_this.fetchcraftNotes(_this.sPrevCraftID);
				}
			});
		},
		
		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 */
		onAfterRendering: function() {
			// if (_this.sPrevCraftID !== _this._oGlobalModel.getProperty("/currentCraft").PersonNo) {
			// 	_this.sPrevCraftID = _this._oGlobalModel.getProperty("/currentCraft").PersonNo;
			// 	_this.fetchcraftNotes(_this.sPrevCraftID);
			// }
		},
		
		//--------------------------------------------------------------------
		// Private functions
		//--------------------------------------------------------------------
		
		/**
		 * Fetch Craft Notes
		 */
		fetchcraftNotes: function(sCraftPersonnelNo) {
			LocomotiveDataModel.fetchCraftNotes(_this.loadData, _this.onloadDataError, this, _this.sPrevCraftID);
		},
		
		/**
		 * Initialize the List
		 */
		loadData: function(oData) {
			var oModel = this.getView().getModel();
			oModel.setProperty("/CraftNoteSet", oData.results);
			oModel.setProperty("/Note", "");
		},
		
		//--------------------------------------------------------------------
		// Event handlers
		//--------------------------------------------------------------------
		
		/**
		 * Save the Craft Notes
		 */
		onSaveNotes: function(oEvent) {
			var oPayload = {};
			oPayload.CraftPersonnelNo = _this.sPrevCraftID;
			oPayload.Note = this.getView().getModel().getProperty("/Note");

			LocomotiveDataModel.postCraftNotes(oPayload, _this.onSuccessNotesPost, _this.onErrorNotesPost, _this);
		},
		
		/**
		 * Delete the Notes
		 */
		onDeleteNotes: function(oEvent) {
			var oItem = oEvent.getParameter("listItem"),
				oPayload = oItem.getBindingContext().getObject();
			oPayload.Deleted = true;
			LocomotiveDataModel.deleteNotes(oPayload, _this.onSuccessNotesPost, _this.onErrorNotesPost, _this);
		},
		
		onSuccessNotesPost: function() {
			_this.fetchcraftNotes(_this.sPrevCraftID);
		},
		
		onErrorNotesPost: function() {

		}

	});
});