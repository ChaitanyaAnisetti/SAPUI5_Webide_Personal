/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.29                                           *
* Project        : Locomotive Maintenance                               *
* Description    : Controller for the Measurement Point Sheet.          *
*                  Hook methods of view life cycle can be implemented   *
*                  for fragment life cycle.                             *
*&----------------------------------------------------------------------*/

// #DontDelete : Daya New control class donot delete any method in this file

sap.ui.define([
		"com/sap/cp/lm/controller/common/FragmentBaseDelegate",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
		"com/sap/cp/lm/util/ErrorManager"
	], function(BaseDelegate, BusyIndicator, LocomotiveDataModel, ErrorManager) {
		"use strict";
		var _this;
		return BaseDelegate.extend("com.sap.cp.lm.controller.common.MeasPointSheet", {

			_sFragmentName: "com.sap.cp.lm.view.common.TaskSheet.MeasPointSheet",
			
			//--------------------------------------------------------------------
			// Life cycle functions
			//--------------------------------------------------------------------
			
			/**
			 * Fragment Initialization method
			 */
			onInit: function() {
				_this = this;
				var oModel = new sap.ui.model.json.JSONModel();
				this.getFragment().setModel(oModel);
				BusyIndicator.showBusyIndicator();
				this._initParameters();

			},
			
			//--------------------------------------------------------------------
			// Private functions
			//--------------------------------------------------------------------
			
			//initialize the dialong window
			_initParameters: function() {
				//Recieving the parameters from source of trigger
				this.aDataFromSource = this.oParameters.oTaskHeader;
				//Fetch the measurement code group to enable the drop down in dialong
				LocomotiveDataModel.fetchMesCodeGroup(_this._fnSuccessMeasPtCodeVal, "", this, this.aDataFromSource);
			},

			//Success call back
			_fnSuccessMeasPtCodeVal: function(oData) {

				if (oData.MeasPtCodeValSet.results.length > 0) {
					//enable the drop down in dialong window
					_this._initDialog(true, oData);
				} else {
					//enable the input field in dialong window
					_this._initDialog(false, oData);
				}
			},

			//Initizalize the dialog window with data
			_initDialog: function(bSelection, oData) {
				this._oMeasHeader = oData;
				var oModel = this.getFragment().getModel();
				oModel.setProperty("/isSelection", bSelection);
				oModel.setProperty("/MeasPtCodeValSet", oData.MeasPtCodeValSet.results);
				oModel.setProperty("/MeasurePtDesc", oData.MeasurePtDesc);
				oModel.setProperty("/Measurement", this.aDataFromSource.MeasPntValue);
				BusyIndicator.hideBusyIndicator();

			},
			
			//--------------------------------------------------------------------
			// Event handlers
			//--------------------------------------------------------------------
			
			//Save measurement point
			onSave: function() {

				var oModel = this.getFragment().getModel();
				var oPayload = {};
				oPayload.OrderNbr = this.aDataFromSource.OrderNbr;
				oPayload.OperationNbr = this.aDataFromSource.OperationNbr;
				oPayload.SubOperNbr = this.aDataFromSource.SubOperNbr;
				oPayload.MeasurePtId = this._oMeasHeader.MeasurePtId;
				oPayload.CatalogType = this._oMeasHeader.CatalogType;
				oPayload.CodeGrp = this._oMeasHeader.CodeGrp;

				if (oModel.getProperty("/isSelection")) {
					oPayload.MeasureDocReading = this.getFragment().getContent()[0].getItems()[2].getSelectedKey();
				} else {
					oPayload.MeasureDocReading = oModel.getProperty("/Measurement");
				}

				LocomotiveDataModel.updateMeasPoint(oPayload, _this.fnSuccessSave, " ", this);

			},
			
			//after updaing the measurement point
			fnSuccessSave: function() {

				this.getFragment().close();
				if (this.aDataFromSource.oSourceViewController.isFromLocomotive) {
					//From Locomotive view...Reload the workplan
					this.aDataFromSource.oSourceViewController.fetchAndRefreshView();
				}else if(this.aDataFromSource.oSourceViewController.onCompleteTaskSuccess){
					//From my Work
					this.aDataFromSource.oSourceViewController.onCompleteTaskSuccess();
				}
			},
			
			//Close the dialog window
			onClose: function() {
				this.getFragment().close();
			}
		});
	}

);