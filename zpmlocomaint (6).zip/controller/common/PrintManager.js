/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.05                                           *
* Project        : Locomotive Maintenance                               *
* Description    : This manager is used to create a html document and   *
*                  opens it in a new window for print.                  *
*&----------------------------------------------------------------------*/
/*&---------------------------------------------------------------------*    
* Author         : KIR0084                                              *
* Date           : 2019.06..12                                          *
* Project        : LMP2-Phase2                                          *
* Description    : Fix bug where if popups are blocked, app crashes and doesnt unbusy
                                                                        *
*&----------------------------------------------------------------------*/

jQuery.sap.declare("com.sap.cp.lm.controller.common.PrintManager");

sap.ui.define([
		
	],
	function() {
		"use strict";
		
		var _this;
		
		return com.sap.cp.lm.controller.common.PrintManager = {
			
			//----------------------------------------------------------------------
			// Initialize functions
			//----------------------------------------------------------------------
			
			onInit: function() {
				_this = this;
			},
			
			//----------------------------------------------------------------------
			// Private functions
			//----------------------------------------------------------------------
			
			/**
			 * Print html from parameter
			 */
			createPrintPage: function(sTitle, sHtmlContent, iPrintDelay) {
				this._printWindow = window.open('', sTitle);
				
				if (!this._printWindow) {
				    return;
				}
				
				var html = '<html>';
				html += '<head>';
				html += '<title>'+sTitle+'</title>';
				
				for (var i= 0; i<document.styleSheets.length; i++) {
				    var sheet= document.styleSheets[i];
			    	if(sheet.href){
				    	var sheetHref = sheet.href;
				    	html += '<link rel="stylesheet" type="text/css" href="'+sheetHref+'">';
				    }
				}
				
				html += '<link rel="stylesheet" type="text/css" href="fonts/fonts.css">';
				html += '<link rel="stylesheet" type="text/css" href="css/print.css">';
				html += '</head>';
				html += '<body>';
				html += sHtmlContent;
				html += '</body>';
				html += '</html>';
				
				this._printWindow.document.write(html);
				
				// delay the triggering of the print so the DOM is rendered and the broswer print preview contains the map
				if(!sap.ui.Device.browser.msie){
					setTimeout(this._print.bind(this), iPrintDelay);
				}
			},
			
			/**
			 * Trigger the print of the browser
			 */
			_print: function() {
				this._printWindow.document.close();
                this._printWindow.focus();
                this._printWindow.print();
			}
			
		};
});