/*&---------------------------------------------------------------------*    
 * Author         : SAP Custom Development                               *
 * Date           : 2017.12.05                                           *
 * Project        : Locomotive Maintenance                               *
 * Description    : Constants used throughout the app.                   *
 *&----------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 12-Oct-2021	                                       *
* Project             : LLM3.2 - Revison Number        					   *
* Description         : ERQ Serial Number and SW Revision number		   *
* Search Term         : LLM3.2	                                           *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 25-Nov-2021	                                       *
* Project             : EAM-LLM 1.2 Serialization     					   *
* Description         : Serialization of material and equipment			   *
* Search Term         : LLM1.2	                                           *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : ANI0006				        		       		   *
* Date                : 11-Nov-2021	                                       *
* Project             : EAM Railinc EPA    					               *
* Description         : EPA Information - Fields Masking		           *
* Search Term         : ANI0006 2000014601                                 *
/*&------------------------------------------------------------------------*/

jQuery.sap.declare("app.util.Constants");
$.sap.declare("com.sap.cp.lm.util.Constants");

com.sap.cp.lm.util.Constants = {
	// OData models
	LOCOMOTIVE_MODEL: "main",
	LOCOMOTIVE_SERVICE: "SERVICE",
	LOCOMOTIVE_WO_STATUS: "WorkOrderStatusChange",
	ZPMLM_MODEL: "zpmlm",
	GLOBAL_MODEL: "global",
	GLOBAL_LOCOMOTIVE_MODEL: "locomotive",
	GLOBAL_SHIFT_MODEL: "shift",
	GLOBAL_CRAFT_MODEL: "craft",
	STATUS_MODEL: "predictCancel",
	WO_EDIT: "Edit Work Order",
	WO_ADD: "Add Work Order",
	WHEELSHEET_RAIL_CLEARANCE: "Locomotive Rail Clearance",
	WHEELSHEET_LEFT: "Left Side",
	WHEELSHEET_RIGHT: "Right Side",
	WHEELSHEET_REAR: "REAR",
	WHEELSHEET_FRNT: "FRONT",
	GLOBAL_MY_WORK: "globalMyWork",
	ARRIVE_SERVICING: "SV",
	ARRIVE_MAINTENANCE: "MN",
	ARRIVE_OUTBOUND: "OB",
	ARRIVE_REMOVE_FROM_MAP: "RFM",
	SEARCH: "Search",
	L5: "L5",
	// Version path key in version model
	VERSION_MODEL: "version",
	LM_VERSION_PATH: "LM_VERSION_PATH",

	//Start: ANI0006 2000014601 Engine Manufacturer Models
	ENGINEMANF_MODEL: "Engine_Manifacture_model",
	GLOBAL_ENGINEMANF_MODEL: "GLOBALENGINEMANFMODEL",
	//End: ANI0006 2000014601 Engine Manufacturer Models

	// global parameters
	ZPM_LM_WO_HISTORY_DAYS: "/ZPM_LM_WO_HISTORY_DAYS",
	ZPM_LM_CRAFT_HIST_DAYS: "/ZPM_LM_CRAFT_HIST_DAYS",

	// roles
	ROLE: {
		PLANNER: "PLANNER",
		SUPERVISOR: "SUPERVISOR",
		CRAFT: "CRAFT",
		LEADMAN: "LLEADMAN"
	},

	BACKEND_ROLE: {
		"PLANNER": "PLANNER",
		"SUPERVISOR": "SUPERVISOR",
		"CRAFT": "CRAFT",
		"LLEADMAN": "LEADMAN"
	},

	// named models assigned to the app component
	I18N_MODEL: "i18n",
	APP_MODEL: "AppModel",

	// Routing
	//Constant for MyPlan
	MYPLAN: "MyPlan",
	MYSHOP: "MyShop",
	MYSHOP2: "MyShop2",
	PLAN_SHIFT_DURATION: 4,
	EDIT_DEFECT: "Edit Defect",
	MYWORK: "MyWork",
	ALLWORK: "allWork",
	LOCOMOTIVES: "Locomotives",
	ASSIGNWORK: "AssignWork",
	SERVICING: "Servicing",
	CRAFT: "craft",
	TURNOVERDOC: "turnoverDoc", // added by ALI0031 HAMED ALI 2019.04.24
	//Constant for LocomotiveList
	PREVENTATIVE_MAINTENANCE: "PREV",
	CORRECTIVE_MAINTENANCE: "CORR",
	ACTIVITY_REQUEST: "ACT",
	MOD_PROJECT_WRECK: "M/P/W",
	SERVICE_NOTIFICATION: "SERV",
	OUT_OF_SERVICE: "OOS",

	BEGIN: "begin",
	REGULATORY_TRUE: true,
	WO_UNDO_FALSE: "false",
	WO_UNDO_TRUE: "true",
	STATUS_COMPLETED: "0",
	STATUS_IN_PROGRESS: "1",
	STATUS_NOT_PLANNED: "2",
	STATUS_DEFERRED: "3",
	STATUS_NOT_STARTED: "4",
	STATUS_INBOUND: "INBO",
	TEXT: "Text",
	LINK: "Link",
	STATUS_SHOPPED: "SHOP",
	STATUS_STAGED: "STAG",
	STATUS_LOCO_YARD: "1",
	YARD: "Yard",
	LOCAL: "Local",
	THROUGH_TRAIN: "Through Train",
	STATUS_GROUPED: "GROUP",
	STATUS_PTA: "PTA",
	STATUS_DEFECT_PRIORITY_HIGH: "1",
	STATUS_DEFECT_PRIORITY_LOW: "3",
	STATUS_DEFECT_PRIORITY_MEDIUM: "2",
	WO_STATUS_IN_PROGRESS: "9",
	STATUS_MATERIAL_AVAILABLE: "0",
	STATUS_MATERIAL_REQUESTED: "1",
	STATUS_MATERIAL_NOT_AVAILABLE: "2",
	STATUS_TECO_LIT: "TECO",
	TIME_AM: " AM",
	TIME_PM: " PM",
	TEXT_COMPLETE: "COMPLETE",
	TEXT_SCOMPLETE: "Complete",
	TEXT_NOTSTARTED: "Not Started",
	TEXT_INPROGRESS: "In Progress",
	TEXT_SCOMPLETED: "Completed",
	TEXT_DEFERED: "Deferred",
	TEXT_NOTPLANNED: "Not Planned",
	TEXT_NOT_STARTED: "Not Started",
	TEXT_ASSIGNMENT: "Craft",
	REGULATORY: "Regulatory",
	WORKPLAN: "workPlan",
	DEFECTS: "defects",
	TEXT_INBOUND: "Inbound",
	TEXT_SHOPPED: "Shopped",
	TEXT_SERVICING: "Servicing",
	TEXT_GROUPED: "Grouped",
	DURATION_8_HOURS: "8 Hours",
	STAGED_FALSE: false,
	STAGED_TRUE: true,

	ICON: {
		ALERT: "alert",
		ACCEPT: "accept",
		NOTIFICATION: "notification"
	},
	COLOR: {
		RED: "#CB1717",
		GREEN: "#037834",
		YELLOW: "#EBC62E"
	},

	NEWLINE: "\n",
	GROUP_SEPERATOR: "|",
	COMMENTS_SEPARATOR: "\n__________________________________________________\n",
	BLUECARD_URL: "BLUECARD_BASE_URL",
	LINQ_URL: "INQUIRY_URL",
	WO_OBJCET_TASKLIST: "2",
	WO_OBJCET_MATERIAL: "",
	WO_OBJCET_OBJECT: "B",
	WO_OBJECT_SYMPTOM: "D",
	MMDDYYYY: "MM/dd/yyyy",
	MMDDYY: "MM/dd/yy",

	ALERT_MESSAGE_LENGTH: "160",
	CREATE_MEASUREMENT_DOCUMENT: "Create Measurement",
	DISPLAY_MEASUREMENT_DOCUMENT: "Display Measurement",

	ML01: "PREV",
	ML02: "CORR",
	ML03: "ACT",
	ML04: "REPR",
	ML05: "",
	ML06: "M/P/W",

	// Notifications
	L2: "L2",

	VE_CANVAS_WIDTH: "800",
	VE_CANVAS_HEIGHT: "600",

	MEASTYPE: {
		WHEEL_SHEET: "1",
		MS_MEGAWATT_HOUR_A: "2",
		SERIALNUMBER: "3",
		SW_VERSION_NUMBER: "4", // SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
		SERIALIZATION_NUMBERR: "5", // SHE0272 - LLM1.2 - Serialization
		//Start: ANI0006 2000014601 EPA Information Field masking - Case 6
		EPA_INFORMATION: "6"
		//End: ANI0006 2000014601 EPA Information Field masking - Case 6
	},

	EMP_PROD: "Employee Productivity",
	OP_PROD: "Shop Productivity",
	TASKLIST_PROD: "Tasklists Productivity"
};