/*&---------------------------------------------------------------------*    
 * Author         : SAP Custom Development                               *
 * Date           : 2017.12.06                                           *
 * Project        : Locomotive Maintenance                               *
 * Description    : Multiple methods used by the xml files as            *
 *                  formatters (visibility, enable/disable,              *
 *                  value format).                                       *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2018.02.15                                           *
 * Incidinet      : Locomotive Maintenance - IM241669-002                *
 * Description    : Logic revised for toolbar buttons in WorkPlan view   *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2018.03.09                                           *
 * Incidinet      : Locomotive Maintenance - ASR3411740                  *
 * Description    : Change made to inbound color status                  *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2018.06.04                                           *
 * Incidinet      : Locomotive Maintenance - ASR3411887                  *
 * Description    : Added formatter for unavailability status            *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2019.02.03                                           *
 * Incidinet      : EAM-ASR3413183 - PM Loco Main phase 2                *
 * Description    : Fixed issues and added new formatters                *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : SAT0008                                              *
 * Date           : 27-Feb-2019                                          *
 * Incidinet      : EAM-ASR3413183 - PM Loco Main phase 2                *
 * Description    : LMP2-4 :Add_Operation link should be disabled        *
 * for certain criteria
 *&----------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
* Author/Changed By   : Sandesh Shirode(SHI0087)	               		  *
* Date                : 15-April-2019                                     *
* Project             : Locomotive Maintenance Phase 2                    *
* Description         : LMP2-7a : Add attachment functionality to be view *
						from OPeration screen							  *
*&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
* Author/Changed By   : SAT0008				        		       		  *
* Date                : 17-April-2019                                     *
* Project             : Locomotive Maintenance Phase 2                    *
* Description         : LMP2-26 : Progress Bar is considered including    *
*                       the tasks                                         *
/*&-----------------------------------------------------------------------*    
* Author/Changed By   : SAT0008				        		       		  *
* Date                : 8-May-2019                                     *
* Project             : Locomotive Maintenance Phase 2                    *
* Description         : LMP2-3 : Work order History and Notification History                                    *
*&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
* Author/Changed By   : Sandesh Shirode(SHI0087)	               		   *
* Date                : 06-May-2019                                        *
* Project             : Locomotive Maintenance Phase 2                     *
* Description         : LMP2-8a : Highlight the Add Material Button        *
						only for GMPS status							   *
*&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*
 * Author/Changed By   : KIR0084				        		       		  *
 * Date                : 10-May-2019                                        *
 * Project             : Locomotive Maintenance Phase 2                    *
 * Description         : LMP2-28 : Add new formatter for shop selection text *
 * Search Term         : LMP2-28                                           *
 *&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------*
* Author/Changed By   : SAT0008				        		       	       *
* Date                : 15-May-2019                                        *
* Project             : Locomotive Maintenance Phase 2                     *
* Description         : LMP2-12 : Long text display on the Inboud screen   *
/*&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*
 * Author/Changed By   : KIR0084				        		       		  *
 * Date                : 31-May-2019                                       *
 * Project             : Locomotive Maintenance Phase 2                    *
 * Description         : LMP2-32 : Update formatter to handle TaskSet better *
 * Search Term         : LMP2-32                                           *
 *&------------------------------------------------------------------------*/

/*&-----------------------------------------------------------------------*
 * Author/Changed By   : KIR0084				        		       		  *
 * Date                : 01-Augst-2019                                     *
 * Project             : Locomotive Maintenance Phase 2                    *
 * Description         : LMP2-35 : Add Crafts Assigned Formatter           *
 *&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*
 * Author/Changed By   : BAJ0018     		            		     	  *
 * Date                : 02-September-2020                                 *
 * Project             : EAM-ASR3415765                                    *
 * Description         : revised logic for loco defer Z4/Z6/Z7              *
 *&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*
 * Author/Changed By   : BAJ0018     		            		     	  *
 * Date                : 30-September-2020                                 *
 * Project             : EAM-ASR3415776                                    *
 * Description         : revised logic for setting WMAT status             *
 *&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*
 * Author/Changed By   : BAJ0018     		                		     	  *
 * Date                : 23-November-2020                                  *
 * Project             : EAM-ASR3416050                                    *
 * Description         : UI comment box opened for history tabs            *
 *&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*
 * Author/Changed By   : BAJ0018     		                		  	  *
 * Date                : 18-Jan-2020                                      *
 * Project             : EAM-ASR3416229                                    *
 * Description         : revised logic for Add operation                   *
 *&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*
 * Author/Changed By   : VYA0004     		                		      *
 * Date                : 1-January-2021                                   *
 * Project             : Break and Build                                  *
 * Description         : Check for BNB Loco and hide/display buttons      *
 * Search Term         : VYA0004 MOD0017                                  *
 *&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*
 * Author/Changed By   : SHE0272											*
 * Date                : 07 -Jun -2021									*
 * Project             : LLM2.29 - Road/Yard Repair						*
 * Description         : Formater for the mandatory field visibility		*
 * Search Term         : LLM2.29											*
 *&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*
 * Author/Changed By   : SHE0272											*
 * Date                : 07 -Jun -2021									*
 * Project             : LLM2.3 - Add Orders in Service Tab				*
 * Description         : Formater for visibility of the button			*
 * Search Term         : LLM2.3											*
 *&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*
 * Author/Changed By   : SHE0272											*
 * Date                : 13 -Jul -2021									*
 * Project             : LLM2.23 - Primary Defect						*
 * Description         : Formater for visibility of the primary indicator*
 * Search Term         : LLM2.23											*
 *&------------------------------------------------------------------------*/
 /*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 08-Sep-2021	                                       *
* Project             : Locomotive Maintenance Phase 2                     *
* Description         : Refresh issue with cross navigation		           *
* Search Term         : INC0110700                                         *
/*&------------------------------------------------------------------------*/
 /*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 12-Oct-2021	                                       *
* Project             : LLM3.2 - Revison Number        					   *
* Description         : ERQ Serial Number and SW Revision number		   *
* Search Term         : LLM3.2	                                           *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : VYA0004				        		       		   *
* Date                : 21-Oct-2021	                                       *
* Project             : LLM3.3                      					   *
* Description         : Function to check if 'No Material Required Reason' *
*                       to be displayed on screen or not.                  *
* Search Term         : VYA0004|LLM3.3                                     *
/*&------------------------------------------------------------------------*/
  /*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 09-Dec-2021	                                       *
* Project             : EAM-LLM 1.2 Serialization     					   *
* Description         : Serialization of material and equipment			   *
* Search Term         : LLM1.2	                                           *
/*&------------------------------------------------------------------------*/

jQuery.sap.require("sap.ui.core.format.DateFormat");
jQuery.sap.require("sap.ui.core.format.NumberFormat");
jQuery.sap.declare("com.sap.cp.lm.util.Formatter");
sap.ui.define(
	["com/sap/cp/lm/util/Formatter", "com/sap/cp/lm/util/Constants"],
	function (Formatter, Constants) {
		"use strict";
		return com.sap.cp.lm.util.Formatter = {

			/**
			 * Version model
			 */
			_oVersionModel: null,
			_oComponent: null,

			translateAvailabilityStatus: function (sStatus) {
				var sRaw = "";
				if (sStatus === "U") {
					sRaw = "UNAVAILABLE";
				}
				if (sStatus === "A") {
					sRaw = "AVAILABLE";
				}

				var i18n = com.sap.cp.lm.util.Formatter._oComponent.getModel("i18n");
				return i18n.getProperty(sRaw);
			},
			translateUnavailabilityReason: function (sStatus) {
				var sRaw = "";
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				var unavailabilityReasons = oGlobalModel.getProperty("/unavailReasons");
				if (unavailabilityReasons) {
					for (var i = 0; i < unavailabilityReasons.length; i++) {
						if (unavailabilityReasons[i].code === sStatus) {
							sRaw = unavailabilityReasons[i].description;
						}
					}
				}
				return sRaw;
				// if (sStatus === "SV") {
				// 	sRaw = "SERVICING";
				// }
				// if (sStatus === "SM") {
				// 	sRaw = "SHOPMAINTENANCE";
				// }
				// if (sStatus === "HS") {
				// 	sRaw = "HEALTHANDSAFETY";
				// }
				// if (sStatus === "FT") {
				// 	sRaw = "FUELTRUCK";
				// }
				// if (sStatus === "RC") {
				// 	sRaw = "ROADCALL";
				// }
				// if (sStatus === "OF") {
				// 	sRaw = "OFF";
				// }

				// var i18n = com.sap.cp.lm.util.Formatter._oComponent.getModel("i18n");
				// return i18n.getProperty(sRaw);
			},

			shoppedColorStatus: function (sStatus) {
				var target = this;
				if (sStatus === "DLA") {
					target.addStyleClass("lmBackgroundOrange");
					target.addStyleClass("lmBoldWhite");
				} else {
					target.removeStyleClass("lmBackgroundOrange");
					target.removeStyleClass("lmBoldWhite");
				}
				return sStatus;
			},

			inboundColorStatus: function (sStatus) {
				var target = this;
				if (sStatus === "DEAD" || sStatus === "PART" || sStatus === "ISOL" || sStatus === "OKCD") {
					target.addStyleClass("lmBackgroundOrange");
					target.addStyleClass("lmBoldWhite");
				} else {
					target.removeStyleClass("lmBackgroundOrange");
					target.removeStyleClass("lmBoldWhite");
				}
				return sStatus;
			},

			translateWOStatus: function (sStatus) {
				var sRaw = "STATUS_UNKNOWN";
				if (sStatus === "0") {
					sRaw = "COMPLETED";
				}
				if (sStatus === "3") {
					sRaw = "DEFERRED";
				}
				if (sStatus === "9") {
					sRaw = "OTHER";
				}

				var i18n = com.sap.cp.lm.util.Formatter._oComponent.getModel("i18n");
				return i18n.getProperty(sRaw);
			},

			/** KIR0084 START Post-Prod Fix for KPI formatting **/
			parseStringToFloat: function (string) {
				return parseFloat(string);
			},
			/** KIR0084 END Post-Prod Fix for KPI formatting **/

			/* Start LMP2-8 */

			changeDateFormatGMPS: function (oDate) { // Change MDT to UTC so that it shows same date by which Material is posted

				var utcEpoch = oDate.getTime() + (oDate.getTimezoneOffset() * 60000);
				var sFormattedDate = "";
				var utcDate = new Date(utcEpoch);
				if (utcDate) {
					$.sap.require("sap.ui.core.format.DateFormat");
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "MM-dd-yyyy"
					});
					sFormattedDate = oDateFormat.format(utcDate);
				}
				return sFormattedDate;
			},

			setBkGrndColorForGMPS: function (sStatus, bGMPSStatus) {
				var sStr = "";
				if (bGMPSStatus === true) {
					this.addStyleClass("lmGMPSButton");
				} else {
					this.removeStyleClass("lmGMPSButton");
				}
				return sStr;
			},

			setStatusOfGMPSRecord: function (sMovType) {
				if (sMovType === "961") {
					return true;
				} else {
					return false;
				}
			},
			setToolTipOfGMPSRecord: function (sMovType) {
				if (sMovType === "961") {
					return "Issued";
				} else {
					return "Reversed";
				}
			},
			setBkGrndColorForUnavailableMaterial: function (sFld, sStock) {
				if (sStock > 0) {
					if (sFld === 'R' || sFld === 'N') // For highlighting Repairability
					{
						this.addStyleClass("lmColorRed");
						return sFld;
					}
					this.removeStyleClass("lmColorRed");
					return sFld;
				} else {
					this.addStyleClass("lmColorRed");
					return sFld;
				}
			},
			setMaterialValueType: function (sFld, sStock) {
				var sPartialStr;
				if (sStock > 0) {
					this.removeStyleClass("lmColorRed");
					sPartialStr = sFld.substr(0, 3);
					return sPartialStr;
				} else {
					this.addStyleClass("lmColorRed");
					sPartialStr = sFld.substr(0, 3);
					return sPartialStr;
				}

			},

			/* End LMP2-8 */
			translateShopStatus: function (sStatus) {
				var sRaw = "STATUS_UNKNOWN";
				if (sStatus === "R") {
					sRaw = "STATUS_RELEASED";
				}
				if (sStatus === "D") {
					sRaw = "STATUS_DEPARTED";
				}
				if (sStatus === "S") {
					sRaw = "STATUS_SHOPPED";
				}

				var i18n = com.sap.cp.lm.util.Formatter._oComponent.getModel("i18n");
				return i18n.getProperty(sRaw);
			},

			changeToInt: function (sInt) {
				return parseInt(sInt, 10);
			},

			availabilityTimeFormat: function (sTime) {
				if (!sTime) {
					return;
				}

				//PT07H00M00S
				var sTmp = sTime.replace(":", "H");
				var sFinal = "PT" + sTmp + "M00S";

				return sFinal;
			},

			localDateAtCurrentShop: function (oDate) {

				if (!oDate) {
					return;
				}

				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				var oShop = oGlobalModel.getProperty("/currentShop");

				if (!oShop) {
					return;
				}

				var shopOffset = this.shopTimezoneOffset(oShop);

				// convert to msec
				// add local time zone offset
				// get UTC time in msec
				var utc = oDate.getTime() + (oDate.getTimezoneOffset() * 60000);

				// create new Date object for different city
				// using supplied offset
				var finalDate = new Date(utc + shopOffset);

				return finalDate;
			},

			shopTimezoneOffset: function (oShop) {
				var offset = oShop.Utcdiff.ms;
				if (oShop.Utcsign === "-") {
					offset = -offset;
				}
				return offset;
			},

			/**
			 * Set visibility for GE Task.
			 * @param(String) sIsEServiceRelevant to check whether it is a GE Task or not
			 *           
			 */
			setVisibilityForGECustomTask: function (sIsEServiceRelevant, sParentViewName, _this) {
				if (!_this) {
					_this = this;
				}
				if (_this.getBindingContext().getModel().getProperty(_this.getBindingContext().getPath().split("TaskSet/")[0]).IsEServiceRelevant !==
					"") {
					return true;
				}
				return false;
			},

			/**
			 * Set Input as enable for GE Task in MyWork.
			 * @param(String) sIsEServiceRelevant to check whether it is a GE Task or not
			 *           
			 */
			setEnableGECustomTaskForMyWork: function (sIsEServiceRelevant, sParentViewName) {

				if (sParentViewName === Constants.MYWORK) {

					return com.sap.cp.lm.util.Formatter.setVisibilityForGECustomTask(sIsEServiceRelevant, sParentViewName, this);

				}
				return false;
			},

			/**
			 * Set visibility & width for Task Description.
			 * @param(Boolean) sVisible to check whether to show Description or not
			 * @param(String) sTaskWidth is the width for Task Description
			 * @param(String) sIsEServiceRelevant to check whether it is a GE Task or not
			 *           
			 */
			setVisibleAndWidthForGECustomTaskDescription: function (sVisible, sTaskWidth, sIsEServiceRelevant) {

				if (sVisible) {
					if (sIsEServiceRelevant !== "") {

						this.setWidth(parseInt(sTaskWidth) * 0.8 + "%");
					} else {
						this.setWidth(sTaskWidth);
					}
				}
				return sVisible;
			},
			/**
			 * Set visibility for GE Task Column.
			 * @param(String) sTaskWidth is the width for Task Description
			 * @param(String) sIsEServiceRelevant to check whether it is a GE Task or not          
			 */
			setVisibilityForGECustomTaskColumn: function (sTaskWidth, sIsEServiceRelevant, sParentViewName) {
				if (sIsEServiceRelevant !== "") {

					this.setWidth(parseInt(sTaskWidth) * 0.2 + "%");
					return true;

				}
				return false;

			},

			//LMP2-04: Est Time can not be changed for Shop Move and Defect operations
			enableEstTime: function (sWODesc) {
				if (sWODesc) {
					if (sWODesc === 'SHOP MOVES' || sWODesc === 'DEFECTS') {
						return false;
					} else {
						return true;
					}
				} else {
					return true;
				}
			},
			/**
			 * Helper function to set visibility for task status & checkboxes for group * normal operation
			 */
			setVisibilityHelperforGEandNormalTask: function (sTaskStatus, IsServicing, sTaskCheckBox, sTaskGroupCheckBox, sIsEServiceRelevant,
				oContext) {
				var oOperation = oContext.getModel().getProperty(oContext.getBindingContext().getPath().split("/TaskSet")[0]);
				var bOperationStatus = com.sap.cp.lm.util.Formatter.setVisibilityForOprationInProgress(oOperation.Status, oOperation.GroupedOperations);
				var oViewPropertiesModel = oContext.getModel("viewProperties");

				if (bOperationStatus && oViewPropertiesModel.getProperty("/GEVisibility") && oOperation.GroupedOperations && oOperation.GroupedOperations
					.length > 0) {
					//	console.log(oViewPropertiesModel.getProperty("/GEVisibility")); //Commented as a part of the Veracode scan recommendation
					//	if (oViewPropertiesModel.getProperty("/harshit")) { "//Commented as a part of the Veracode scan recommendation"
					//	console.log("yes"); //Commented as a part of the Veracode scan recommendation
					//	} //Veracode comment
				}

				// logic for task status , task select checkbox , task group select checkbox for my work tab for normal wo , servicing, group wo .. 
				if (bOperationStatus && (IsServicing || (oViewPropertiesModel.getProperty("/parentView") === "MyWork" && oViewPropertiesModel.getProperty(
						"/GEVisibility") === "myWork"))) {
					if (sTaskStatus && !sTaskCheckBox && !sTaskGroupCheckBox) {
						return false;
					}
					if (oOperation.TaskSet.results.length === 0) {
						return false;
					}
					if (sTaskStatus && sTaskCheckBox && !sTaskGroupCheckBox) {
						return true;
					}

					if (sTaskStatus && sTaskCheckBox && sTaskGroupCheckBox) {
						if (oOperation.GroupedOperations && oOperation.GroupedOperations.length > 0) {
							return true
						} else {
							return false;
						}
					}

				} else {
					if (sTaskStatus && !sTaskCheckBox && !sTaskGroupCheckBox) {
						return true;
					} else {
						return false;
					}
				}

			},
			/**
			 * Function sets visibility for the control if Status is
			 * in progress of task
			 */
			setVisibilityForTaskInProgress: function (sTaskStatus, IsServicing, sTaskCheckBox, sTaskGroupCheckBox, sIsEServiceRelevant,
				bWheelSheet) {
				// check if this is a WheelSheet Operation in this case dont show the checkbox
				if (this.getBindingContext().getObject().WheelSheetRequired) {
					return false;
				}
				if (this.getBindingContext().getPath().includes("TaskSet")) {
					sIsEServiceRelevant = this.getBindingContext().getModel().getProperty(this.getBindingContext().getPath().split("TaskSet/")[0]).IsEServiceRelevant;
				}

				if (sTaskCheckBox && sIsEServiceRelevant !== "") return false;
				// don not dare to touch this formatter
				return com.sap.cp.lm.util.Formatter.setVisibilityHelperforGEandNormalTask(sTaskStatus, IsServicing, sTaskCheckBox,
					sTaskGroupCheckBox, sIsEServiceRelevant, this);
			},

			/**
			 * Sets the version model.
			 * 
			 * @param _oVersionModel
			 *            The version model.
			 * @discussion This method must be called before calling getText() or any other methods that use the version model.
			 */
			setVersionModel: function (oVersionModel) {
				// set the instance variable
				this._oVersionModel = oVersionModel;
			},

			/**
			 * Returns the version path based on the POM.xml app version
			 * 
			 * @result The version path of the app
			 */
			getVersionPath: function () {
				var sVersionPath = null;

				if (this._oVersionModel) {
					sVersionPath = this._oVersionModel.getResourceBundle().getText(Constants.LM_VERSION_PATH);
				}

				return sVersionPath;
			},

			/**
			 * Set the reference to the Component
			 */
			setComponent: function (_oComponent) {
				this._oComponent = _oComponent;
			},

			/**
			 * Get the reference to the Component
			 */
			getComponent: function () {
				return this._oComponent;
			},

			/**
			 * Convert the JSON object /Date(1293034567877)/ values to Javascript Date objects
			 */
			dateReviver: function (key, value) {
				var a;
				if (typeof value === 'string') {
					a = /\/Date\((\d*)\)\//.exec(value);
					if (a) {
						return new Date(+a[1]);
					}
				}
				return value;
			},

			setVisibilityForWOgrpInAssignWork: function (sStatus, aWOData, sParentView) {
				if (sParentView === Constants.ASSIGNWORK) {

					if (aWOData.OperationSet) {
						var aOperationsData = aWOData.OperationSet.results;

						if (aOperationsData) {
							var iNoOfOPerations = aOperationsData.length;
							for (var i = 0; i < iNoOfOPerations; i++) {
								if (aOperationsData[i].Status === Constants.STATUS_IN_PROGRESS || aOperationsData[i].Status === Constants.STATUS_NOT_STARTED) {
									return true;
								}
							}
						}
					}

					return false;
				}
				return true;
			},

			setExpandForPanel: function (PanelPrevState, WorkOrderNum, OperationNumber) {
				if (PanelPrevState.hasOwnProperty(WorkOrderNum)) {
					if (OperationNumber) {
						return PanelPrevState[WorkOrderNum][OperationNumber] ? true : false;
					} else {
						return true;
					}
				}
				return false;
			},

			setVisibilityForWOAndOpInAssignWork: function (sLocoStatus, sParentView, bAssignedToMe, bMyWork) {
				if (sParentView === Constants.ASSIGNWORK) {
					if (sLocoStatus !== Constants.STATUS_COMPLETED) {
						return true;
					}
					return false;
				} else if (sParentView === Constants.MYWORK) {
					return bMyWork ? bAssignedToMe : true;
				}
				return true;
			},

			/**
			 * set visibilty for work order in assign work
			 * @params{sLocoStatus} sLocoStatus is the status of the work order
			 * @params{aWOData} aWOData is the data of the work order
			 */
			setVisibilityForWOInAssignWork: function (sLocoStatus, aWOData, sParentView, bAssignedToMe, bMyWork) {

				if (sParentView === Constants.ASSIGNWORK) {

					if (sLocoStatus) {
						if (aWOData.GroupId) {
							return false;
						}
						if (sLocoStatus === Constants.WO_STATUS_IN_PROGRESS) {
							if (aWOData.OperationSet) {
								var aOperationsData = aWOData.OperationSet.results;

								if (aOperationsData) {
									var iNoOfOPerations = aOperationsData.length;
									for (var i = 0; i < iNoOfOPerations; i++) {
										if (aOperationsData[i].Status !== Constants.STATUS_COMPLETED) {
											return true;
										}
									}
								}
							}

						}
						return false;
					} else {

						if (aWOData.OperationSet) {
							var aOperationsData = aWOData.OperationSet.results;

							if (aOperationsData) {
								var iNoOfOPerations = aOperationsData.length;
								for (var i = 0; i < iNoOfOPerations; i++) {
									if (aOperationsData[i].Status !== Constants.STATUS_COMPLETED) {
										return true;
									}
								}
							}
						}

						return false;
					}

				} else if (sParentView === Constants.MYWORK) {
					return bMyWork ? bAssignedToMe : true;
				}
				return true;
			},

			/**
			 * set visibility for group work order in right hand side in assign work
			 * @param(object) aWOData is the group work order data
			 */
			setVisibilityForGroupWOInAssignWork: function (aWOData) {
				if (aWOData.OperationSet) {
					var aOperationsData = aWOData.OperationSet.results;
					if (aOperationsData) {
						var iNoOfOPerations = aOperationsData.length;
						for (var i = 0; i < iNoOfOPerations; i++) {
							if (aOperationsData[i].Status !== Constants.STATUS_COMPLETED) {
								return true;
							}
						}
					}
				}
				return false;
			},
			/**
			 * set visibilty for locomotive in assing work
			 * @params{aLocoData} aLocoData is the data of the locomotive
			 */
			setVisibilityForLocoInAssignWork: function (aLocoData) {
				if (aLocoData.WorkOrderSet) {
					var aWorkOrdersData = aLocoData.WorkOrderSet.results;
					var iNoOfWOs = aWorkOrdersData.length;
					for (var i = 0; i < iNoOfWOs; i++) {
						if (aWorkOrdersData[i].Status === Constants.WO_STATUS_IN_PROGRESS && aWorkOrdersData[i].GroupId === "") {
							var aOperationsData = aWorkOrdersData[i].OperationSet.results;
							var iNoOfOPerations = aOperationsData.length;
							for (var j = 0; j < iNoOfOPerations; j++) {
								if (aOperationsData[j].Status !== Constants.STATUS_COMPLETED) {
									return true;
								}
							}
						}
					}
				}
				if (aLocoData.GroupSet) {

					var aGroupData = aLocoData.GroupSet.results;
					if (aGroupData) {
						if (aGroupData.length > 0) {
							for (var i = 0; i < aGroupData.length; i++) {
								var aOperationsData = aGroupData[i].OperationSet.results;

								var iNoOfOPerations = aOperationsData.length;
								for (var j = 0; j < iNoOfOPerations; j++) {
									if (aOperationsData[j].Status !== Constants.STATUS_COMPLETED) {
										return true;
									}
								}
							}
						}
					}
				}

				return false;

			},

			/**
			 * Function Sets Visibility for + at operation level in assign work dialog 
			 * of craft tab
			 * @params(string) sPer is the personnel number of the worker
			 * @params(array) aAssignSet is the assignment set
			 */
			setVisibilityForPlusInOPAssignWork: function (aPer, sLocoNum, sWONum, sOPNum, aHashMap, sGroupId, aGroupedOperations) {
				if (typeof sGroupId === "undefined") { //group id not present
					if (typeof sLocoNum !== "undefined") {
						for (var j = 0; j < aPer.length; ++j) {
							if (aHashMap[sLocoNum.replace(/^0+/, '') + "|" + sWONum.replace(/^0+/, '') + "|" + sOPNum.replace(/^0+/, '') + "|" + aPer[j].PersonnelNumber
									.replace(/^0+/, '')] === undefined) {
								return true;
							}
						}
						return false;
					}
				} else { //grp id is present
					var k = 0;
					for (var j = 0; j < aPer.length; ++j) {
						if (aGroupedOperations && aGroupedOperations.length) {
							for (k = 0; k < aGroupedOperations.length; ++k) {
								if (typeof aHashMap[sGroupId.replace(/^0+/, '') + "|" + aGroupedOperations[k].WorkOrderNum.replace(/^0+/, '') + "|" +
										aGroupedOperations[k].OperationNumber.replace(/^0+/, '') + "|" + aPer[j].PersonnelNumber.replace(/^0+/, '')] === "undefined") {
									return true;
								}
							}
						}
					}
					return false;
				}
			},

			/**
			 * Function Sets Visibility for - at Work Order level in assign work dialog 
			 * of craft tab
			 * @params(string) sPer is the personnel number of the worker
			 * @params(object) oOperationSet is the Operation set
			 */
			setVisibilityForMinusInWOAssignWork: function (aPer, sLocoNum, aOperationSet, aHashMap) { //{sPer, oOperationSet){

				for (var j = 0; j < aPer.length; ++j) {
					if (aOperationSet) {
						for (var i = 0; i < aOperationSet.length; ++i) {
							if (aOperationSet[i].Status === Constants.STATUS_IN_PROGRESS || aOperationSet[i].Status === Constants.STATUS_NOT_STARTED) {
								if (aHashMap[sLocoNum.replace(/^0+/, '') + "|" + aOperationSet[i].WorkOrderNum.replace(/^0+/, '') + "|" + aOperationSet[i].OperationNumber
										.replace(/^0+/, '') + "|" + aPer[j].PersonnelNumber.replace(/^0+/, '')] === undefined) {
									return false;
								}
							}

						}
					}
				}
				return true;

			},

			/**
			 * Function Sets Visibility for - at operation level in assign work dialog 
			 * of craft tab
			 * @params(string) sPer is the personnel number of the worker
			 * @params(array) aAssignSet is the assignment set
			 */
			setVisibilityForMinusInOPAssignWork: function (aPer, sLocoNum, sWONum, sOPNum, aHashMap, sGroupId, aGroupedOperations) { //{sPer, oOperationSet){
				if (typeof sGroupId === "undefined") { //group id not present
					if (typeof sLocoNum !== "undefined") {
						for (var j = 0; j < aPer.length; ++j) {
							if (aHashMap[sLocoNum.replace(/^0+/, '') + "|" + sWONum.replace(/^0+/, '') + "|" + sOPNum.replace(/^0+/, '') + "|" + aPer[j].PersonnelNumber
									.replace(/^0+/, '')] === undefined) {
								return false;
							}
						}
						return true;
					}
				} else { //grp id present
					var k = 0;
					for (var j = 0; j < aPer.length; ++j) {
						if (aGroupedOperations && aGroupedOperations.length) {
							for (k = 0; k < aGroupedOperations.length; ++k) {
								if (typeof aHashMap[sGroupId.replace(/^0+/, '') + "|" + aGroupedOperations[k].WorkOrderNum.replace(/^0+/, '') + "|" +
										aGroupedOperations[k].OperationNumber.replace(/^0+/, '') + "|" + aPer[j].PersonnelNumber.replace(/^0+/, '')] === "undefined") {
									return false;
								}
							}
						}
					}
					return true;
				}
			},

			/**
			 * Function Sets Visibility for + at Work Order level in assign work dialog 
			 * of craft tab
			 * @params(string) sPer is the personnel number of the worker
			 * @params(object) oOperationSet is the Operation set
			 */
			setVisibilityForPlusInWOAssignWork: function (aPer, sLocoNum, aOperationSet, aHashMap) { //{sPer, oOperationSet){

				for (var j = 0; j < aPer.length; ++j) {
					if (aOperationSet) {
						for (var i = 0; i < aOperationSet.length; ++i) {
							if (aOperationSet[i].Status === Constants.STATUS_IN_PROGRESS || aOperationSet[i].Status === Constants.STATUS_NOT_STARTED) {
								if (aHashMap[sLocoNum.replace(/^0+/, '') + "|" + aOperationSet[i].WorkOrderNum.replace(/^0+/, '') + "|" + aOperationSet[i].OperationNumber
										.replace(/^0+/, '') + "|" + aPer[j].PersonnelNumber.replace(/^0+/, '')] === undefined) {
									return true;
								}
							}

						}
					}
				}
				return false;
			},

			/* Function Sets Visibility for Defect Tab */
			setVisibilityForShopDefects: function (sType, sOrderNumber, sNotificationType) {
				if (sType === Constants.STATUS_SHOPPED && !(sOrderNumber === "")) {
					return false;
				}
				if (!sNotificationType) {
					return true;
				}

				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				var oVisibleNotificationTypes = oGlobalModel.getProperty("/NotificationTypes");
				if (oVisibleNotificationTypes[sNotificationType]) {
					return true;
				}
				return false;
			},
			/*
			 * Function Sets Visibility for Move button in
			 * My Shop 
			 */
			setVisibilityForMove: function (sRole) {
				if (sRole === Constants.ROLE.SUPERVISOR || sRole === Constants.ROLE.PLANNER) {
					return true;
				} else {
					return false;
				}
			},

			/*
			 * Function Sets Visibility for Supervisor
			 * My Shop 
			 */
			setVisibilityForSupervisorOnly: function (sRole) {
				if (sRole === Constants.ROLE.SUPERVISOR) {
					return true;
				} else {
					return false;
				}
			},

			/*
			 * Function Sets Visibility for Remove plan button in
			 * Defects Tab
			 */
			setVisibilityForDefectRemovePlan: function (sLocoStatus, sOrderNumber, sRole) {
				// if (!(sLocoStatus === Constants.STATUS_INBOUND)
				// && !(sOrderNumber === "")) {
				// return true;
				// } else
				if (sRole === Constants.ROLE.CRAFT || this.getModel("viewProperties").getProperty("/IsMyWork")) {
					return false;
				}
				if ((sLocoStatus === Constants.STATUS_PTA || sLocoStatus === Constants.STATUS_INBOUND) && !(sOrderNumber === "")) {
					return true;
				} else {
					return false;
				}
			},
			/*
			 * Function Sets Visibility for Assigning Operation by Craft
			 * Defects Tab
			 */
			setVisibilityForAssigningOperationByCraft: function (aAssignment) {
				var flag = 1;
				if (this.getModel("viewProperties").getProperty("/GEVisibility") === Constants.ALLWORK) {
					var i, j;

					var sCurrentUserPN = this.getModel("globalModel").getProperty("/currentUser/PersonnelNumber");
					var sWorkOrderPath = this.getBindingContext().sPath.split("OperationSet")[0];
					var sWorkOrderStatus = this.getBindingContext().getModel().getProperty(sWorkOrderPath).Status;
					if (sWorkOrderStatus !== Constants.STATUS_DEFERRED && sWorkOrderStatus !== Constants.STATUS_COMPLETED) {
						if (this.getBindingContext().getPath().includes("GroupSet")) {
							var iFinFlag = 0;
							flag = 1;
							var flag2 = 0;
							if (this.getBindingContext().getObject().Status !== Constants.STATUS_COMPLETED) {
								flag2 = 1;

							}
							for (i = 0; i < aAssignment.length; ++i) {
								if (sCurrentUserPN === aAssignment[i].PersonnelNumber) {
									flag = 0;
								}
							}
							if (flag) {
								iFinFlag = 1;
							}
							if (this.getBindingContext().getObject().GroupedOperations) {

								var aGroupedOperations = this.getBindingContext().getObject().GroupedOperations;
								for (j = 0; j < aGroupedOperations.length; ++j) {
									if (aGroupedOperations[j].Status !== Constants.STATUS_COMPLETED) {
										flag2 = 1;
									}
									aAssignment = aGroupedOperations[j].AssignmentSet.results;
									flag = 1;
									if (aAssignment) {
										for (i = 0; i < aAssignment.length; ++i) {
											if (sCurrentUserPN === aAssignment[i].PersonnelNumber) {
												flag = 0;
											}
										}
									}
									if (flag) {
										iFinFlag = 1;
									}
								}

							}
							if (iFinFlag && flag2) return true;
						} else {

							//	this.getBindingContext().getModel().getProperty(this.getBindingContext().sPath).Status
							if (this.getBindingContext().getObject().Status !== Constants.STATUS_COMPLETED) {
								for (i = 0; i < aAssignment.length; ++i) {
									if (sCurrentUserPN === aAssignment[i].PersonnelNumber) {
										flag = 0;
									}
								}
								if (flag) return true;
							}

						}
					}

				}
				return false;

			},

			/*
			 * Function Sets Visibility for Edit Defect Option in
			 * Defects Tab
			 */
			setVisibilityForEditDefect: function (sLocoStatus, sOrderNumber, sRole) {

				if (sLocoStatus === Constants.STATUS_SHOPPED && sOrderNumber === "" && !this.getModel("viewProperties").getProperty("/IsMyWork")) {
					return true;
				} else {
					return false;
				}
			},
			/*
			 * Function Sets Visibility for Add to plan button in
			 * Defects Tab
			 */
			setVisibiltyForDefectAddToPlan: function (sLocoStatus, sOrderNumber, sRole) {
				if (sRole === Constants.ROLE.CRAFT || this.getModel("viewProperties").getProperty("/IsMyWork")) {
					return false;
				}
				if (sLocoStatus === Constants.STATUS_SHOPPED && sOrderNumber === "") {
					return true;
				}
				// else if (sLocoStatus === Constants.STATUS_INBOUND
				// && sPredictCancel === true
				// && sOrderNumber === "") {
				// return true;
				// }
				else if ((sLocoStatus === Constants.STATUS_PTA || sLocoStatus === Constants.STATUS_INBOUND) && sOrderNumber === "") {
					return true;
				} else {
					return false;
				}
			},
			/*
			 * Function Sets Visibility for Predict to arrive label
			 * in Locomotive detail
			 */
			setVisibilityForPredictToArrive: function (sLocoStatus, sRole) {
				if (sRole === Constants.ROLE.CRAFT) {
					return false;
				}
				if (sLocoStatus === Constants.STATUS_PTA) {
					return true;
				} else {
					return false;
				}
			},
			/*
			 * Function Sets Visibility for Predict to arrive Button
			 * in Locomotive detail
			 */
			setVisibilityForPredictToArriveButton: function (sLocoStatus, sRole) {
				if (sRole === Constants.ROLE.SUPERVISOR || sRole === Constants.ROLE.LEADMAN || sRole === Constants.ROLE.PLANNER) {
					if (sLocoStatus === Constants.STATUS_PTA) {
						return true;
					}
				}

				return false;

			},
			/*
			 * Function Sets Visibility for Inbound text on
			 * Locomotive detail
			 */
			setVisibilityForInbound: function (sLocoStatus, sRole) {
				if (sRole === Constants.ROLE.CRAFT) {
					return false;
				}
				if (sLocoStatus === Constants.STATUS_INBOUND) {
					return true;
				} else {
					return false;
				}
			},
			/*
			 * Function Sets Visibility for Inbound Button on
			 * Locomotive detail
			 */
			setVisibilityForInboundButton: function (sLocoStatus, sRole) {
				if (sRole === Constants.ROLE.SUPERVISOR || sRole === Constants.ROLE.LEADMAN || sRole === Constants.ROLE.PLANNER) {
					if (sLocoStatus === Constants.STATUS_INBOUND) {
						return true;
					}
				}

				return false;

			},

			/**
			 * Function to show Warning with craft's name in CraftList Dialog View
			 * Functionality needs DISCUSSION
			 */
			onLocoListPeopleAlert: function (sWarning) {
				if (sWarning !== "") {
					return true;
				}
				return false;
			},
			/* Function formats the Time in HH : mm AM/PM format */
			changeTimeFormat: function (sDate) {
				var sDates = new Date(sDate);
				var sHours = sDates.getHours();
				var sMinutes = sDates.getMinutes();
				var sAMPM = "";
				if (parseInt(sHours) > 12 || (parseInt(sHours) === 12 && parseInt(sMinutes) > 0)) {
					sHours = parseInt(sHours) - 12;
					sAMPM = Constants.TIME_PM;
				} else {
					sAMPM = Constants.TIME_AM;
				}
				return sHours + ":" + sMinutes + sAMPM;
			},

			/* Function formats the Time in '## Hrs.' format */
			formatTimeInHoursHrs: function (iSeconds) {
				var fHours = iSeconds / 3600;
				return com.sap.cp.lm.util.Formatter.roundedToFixed(fHours, 0) + " Hrs.";
			},

			calculateHoursByDateTime: function (startDate, startTime, endDate, endTime) {
				if (!startDate || !endDate) {
					return "00 H 00 M";
				}
				startDate.setHours(0, 0, 0, 0);
				var compiledStartTime = startDate.getTime() + startTime.ms;
				endDate.setHours(0, 0, 0, 0);
				var compiledEndTime = endDate.getTime() + endTime.ms;
				var timeDuration = compiledEndTime - compiledStartTime;
				var time = com.sap.cp.lm.util.Formatter.msToTime(timeDuration);
				var aTime = time.split(":");
				aTime[0] = aTime[0] < 10 ? "0" + aTime[0] : aTime[0];
				aTime[1] = aTime[1] < 10 ? "0" + aTime[1] : aTime[1];

				var result = aTime[0] + " H " + aTime[1] + " M";
				return result;
			},

			msToTime: function (s) {
				var ms = s % 1000;
				s = (s - ms) / 1000;
				var secs = s % 60;
				s = (s - secs) / 60;
				var mins = s % 60;
				var hrs = (s - mins) / 60;
				return hrs + ':' + mins;
			},

			changeTimeFormatByUnit: function (sTime, sUnit) {
				if (!sUnit || sUnit === "") {
					sUnit = "H";
				}
				if (sUnit === "H") {
					return com.sap.cp.lm.util.Formatter.getHoursFormated(sTime);
				}
				if (sUnit === "MIN") {
					return com.sap.cp.lm.util.Formatter.getMinsFormated(sTime);
				}
			},

			getMinsFormated: function (sTime) {
				if (!sTime) {
					return "NaN";
				}
				sTime = sTime.toString();
				sTime = parseInt(sTime);
				var iHours = parseInt(sTime / 60);
				var iMins = sTime % 60;
				iHours = iHours < 10 ? "0" + iHours : iHours;
				iMins = iMins < 10 ? "0" + iMins : iMins;
				return iHours + " H " + iMins + " M";
			},

			getHoursFormated: function (sTime) {
				if (!sTime) {
					return "NaN";
				}
				sTime = sTime.toString(); //it will not display any trailing zeros in mins
				var aTime = sTime.split(".");
				var hour = parseInt(aTime[0]); //remove extra 0's in begining

				hour = hour < 10 ? "0" + hour : hour;

				var iNoOfDigitsInMins;

				var min = aTime[1];
				if (!min) {
					min = "0";
					iNoOfDigitsInMins = 0;
				} else {
					iNoOfDigitsInMins = min.length;
				}

				min = ((min * 60) / (Math.pow(10, iNoOfDigitsInMins)));
				min = Math.round(min);
				if (min === 60) {
					min = 0;
					hour += 1;
				}
				hour = hour.toString();
				min = min.toString();
				min = min < 10 ? "0" + min : min;

				//min = min < 10 ? "0" + min : min;
				return hour + " H " + min + " M";
			},

			//			/*
			//			 * function gets the Icon for operation and workorder
			//			 * level .it calculates the each material status and
			//			 * gives calculated status and icon for operation or
			//			 * workorder.
			//			 */
			//			getIconFlag: function (aMaterials) {
			//				var sIconPrefix = "sap-icon://";
			//				var sIcon = sIconPrefix + Constants.ICON.ACCEPT;
			//				for(var i = 0; i < aMaterials.length; i++) {
			//					if(aMaterials[i].Status === Constants.STATUS_MATERIAL_NOT_AVAILABLE) {
			//						sIcon = sIconPrefix + Constants.ICON.ALERT;
			//						break;
			//					} else if(aMaterials[i].Status === Constants.STATUS_MATERIAL_REQUESTED) {
			//						sIcon = sIconPrefix + Constants.ICON.NOTIFICATION;
			//					}
			//				}
			//				return sIcon;
			//			},
			//			/*
			//			 * function gets the Icon color for operation and
			//			 * workorder level .it calculates the each material
			//			 * status and gives calculated status and icon color for
			//			 * operation or workorder.
			//			 */
			//			getIconColor: function (aMaterials) {
			//				var sColor = Constants.COLOR.GREEN;
			//				for(var i = 0; i < aMaterials.length; i++) {
			//					if(aMaterials[i].Status === Constants.STATUS_MATERIAL_NOT_AVAILABLE) {
			//						sColor = Constants.COLOR.RED;
			//						break;
			//					} else if(aMaterials[i].Status === Constants.STATUS_MATERIAL_REQUESTED) {
			//						sColor = Constants.COLOR.YELLOW;
			//					}
			//				}
			//				return sColor;
			//			},
			/* Function sets the icon for Each material */
			getIconsForMaterial: function (sType) {

				var sIconPrefix = "sap-icon://";
				var sIcon = sIconPrefix + Constants.ICON.ALERT;
				if (sType === Constants.STATUS_MATERIAL_AVAILABLE) {
					this.setColor(Constants.COLOR.GREEN);
					sIcon = sIconPrefix + Constants.ICON.ACCEPT;
				} else if (sType === Constants.STATUS_MATERIAL_REQUESTED) {
					this.setColor(Constants.COLOR.YELLOW);
					sIcon = sIconPrefix + Constants.ICON.NOTIFICATION;
				} else if (sType === Constants.STATUS_MATERIAL_NOT_AVAILABLE) {
					this.setColor(Constants.COLOR.RED);
					sIcon = sIconPrefix + Constants.ICON.ALERT;
				}
				return sIcon;

			},
			//			/*
			//			 * Function sets the icon color based on status for Each
			//			 * material
			//			 */
			//			getIconColorForMaterial: function (sType) {
			//				var sColor = Constants.COLOR.RED;
			//				if(sType === Constants.STATUS_MATERIAL_AVAILABLE) {
			//					sColor = Constants.COLOR.GREEN;
			//				} else if(sType === Constants.STATUS_MATERIAL_REQUESTED) {
			//					sColor = Constants.COLOR.YELLOW;
			//				} else if(sType === Constants.STATUS_MATERIAL_NOT_AVAILABLE) {
			//					sColor = Constants.COLOR.RED;
			//				}
			//				return sColor;
			//			},
			/*
			 * Function sets the Completed Progress status of a
			 * progress bar based on work status
			 */
			setProgressBarCompleteStatus: function (sCompletedWork, sPlannedWork) {
				var iCompletedWork = parseInt(sCompletedWork);
				var iPlannedWork = parseInt(sPlannedWork);
				if (iPlannedWork === 0) {
					return 100;
				} else {
					return ((iCompletedWork / iPlannedWork) * 100);
				}
			},
			/*
			 * function gets the status of checkbox and selects
			 * panel checkbox is all element are selected
			 */
			getCheckBoxStatus: function (sType) {
				if (!sType || !sType.length || sType.length === 0) {
					return false;
				}
				for (var i = 0; i < sType.length; i++) {
					if (!sType[i].Checked) {
						return false;
					}
				}
				return true;
			},
			/*
			 * Function expands panel if all the child elements are
			 * selected
			 */
			expandPanel: function (sType) {
				if (!sType || !sType.length) {
					return false;
				}
				for (var i = 0; i < sType.length; i++) {
					if (sType[i].selected) {
						return true;
					}
				}
				return false;
			},
			/** START KIR0084 LMP2-28 Add new formatter for shop selection text */
			/**
			 * Setup the shop select dropdown text for the arrival dialog
			 */
			setShopSelectionTextInArriveDialog: function (type) {
				var i18n = com.sap.cp.lm.util.Formatter._oComponent.getModel("i18n");
				var retVal = i18n.getProperty("ARRIVE_TO_SHOP");

				if (type === "confirmInbound") {
					retVal = i18n.getProperty("CONFIRM_INBOUND_TO_SHOP");
				}

				if (type === "changeInbound") {
					retVal = i18n.getProperty("CHANGE_INBOUND_SHOP");
				}

				return retVal;
			},
			/** START SHE0272 LLM2.29 - Outside Point process */
			/**
			 * Visibility of mandatory field in arrive screen for road/repair yard
			 */
			setMandatoryNoteVisibilityInArriveDialog: function (oValue) {
				if (oValue && oValue === "roadYardRepair") {
					return true;
				} else {
					return false;
				}
			},
			/**
			 * Add CSS style for Operation Long Text Dialog
			 */
			setStyleForOperationComment: function (readFromWOHistory, commentCount) {
				this.addStyleClass("lmOpComment");
				if (commentCount > 0) {
					this.addStyleClass("lmOpCommentRed");
				} else {
					this.removeStyleClass("lmOpCommentRed");
				}
				//START - BAJ0018 EAM-ASR3416050-UI comment box
				//return (!readFromWOHistory);
				return true;
				//END - BAJ0018 EAM-ASR3416050-UI comment box
			},

			/**
			 * Add CSS style for Operation Long Text Dialog
			 */
			setReadOnlyStyleForOperationComment: function (readFromWOHistory, commentCount) {
				this.addStyleClass("lmOpComment");
				if (commentCount > 0) {
					this.removeStyleClass("lmOpCommentHidden");
					this.addStyleClass("lmOpCommentRed");
				} else {
					this.removeStyleClass("lmOpCommentRed");
					this.addStyleClass("lmOpCommentHidden");
				}
				return (!readFromWOHistory);
			},
			/** END KIR0084 LMP2-28 Add new formatter for shop selection text */

			/* Function formats date in the format MM/dd HH:MM */
			changeDateFormat: function (dDate) {
				var sFormattedDate = "";
				if (dDate) {
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "MM/dd HH:mm"
					});
					sFormattedDate = oDateFormat.format(dDate);
				}
				return sFormattedDate;
			},

			changeDateFormatETR: function (dDate) {
				var sFormattedDate = "";
				if (dDate) {
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "yyyy-MM-ddTHH:mm:ss"
					});
					sFormattedDate = oDateFormat.format(dDate);
				}
				return sFormattedDate;
			},

			changeDateFormatHHMMAtCurrentShop: function (dDate) {
				var oDate = com.sap.cp.lm.util.Formatter.localDateAtCurrentShop(dDate);
				return com.sap.cp.lm.util.Formatter.changeDateFormatHHMM(oDate);
			},

			/* Function formats date in the format HH:MM */
			changeDateFormatHHMM: function (dDate) {
				var sFormattedDate = "";
				if (dDate) {
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "HH:mm"
					});
					sFormattedDate = oDateFormat.format(dDate);
				}
				return sFormattedDate;
			},

			getCurrentDate: function () {
				var sDate = new Date();
				var sCurrentdate = com.sap.cp.lm.util.Formatter.changeDateFormat(sDate);
				return sCurrentdate;
			},
			/*
			 * Function sets visibility for Inbound fields on
			 * locomotive details view
			 */
			setVisibilityForInboundFields: function (status) { // check
				// with
				// function
				// setVisibilityForInboundText
				// and
				// ststua
				// PTA
				if (status === Constants.STATUS_INBOUND || status === Constants.STATUS_PTA) {
					return true;
				} else {
					return false;
				}
			},
			/*
			 * function Sets visibility of Add Work Order button on
			 * Details view according to the role of user
			 */
			setVisibilityForAddWork: function (sLocoStatus, sRole) {

				if (sRole === Constants.ROLE.PLANNER || sRole === Constants.ROLE.SUPERVISOR || sRole === Constants.ROLE.LEADMAN) {
					return true;
				}

				return false;
			},
			/*
			 * function Sets the visibility according to role
			 * Time field according to the role of user
			 */

			setVisibilityForNotLeadman: function (sLocoStatus, sRole) {
				if (sRole === Constants.ROLE.LEADMAN) {

					return false;

				}
				return true;

			},
			/*
			 * function Sets the visibility according to role
			 * Time field according to the role of user
			 */

			setVisibilityForLeadman: function (sLocoStatus, sRole) {
				if (sRole === Constants.ROLE.LEADMAN) {

					return true;

				}
				return false;

			},
			/*
			 * function Sets the visibility of Move button on
			 * Details view according to the role of user
			 */

			setVisibilityForMoveLoco: function (sLocoStatus, staged, sRole) {
				if (sRole === Constants.ROLE.LEADMAN) {
					if (sLocoStatus === Constants.STATUS_SHOPPED) {
						return true;
					}
				}
				return false;

			},
			/*
			 * function Sets visibility of Group Work button on
			 * Details view according to the role of user
			 */
			setVisibilityForGroupWork: function (sLocoStatus, staged, sRole) {

				if (sRole === Constants.ROLE.SUPERVISOR && sLocoStatus === Constants.STATUS_SHOPPED) {

					return true;

				}

				return false;
			},

			/*
			 * function Sets the visibility of Release button on
			 * Details view according to the role of user
			 */
			setVisibilityForRelease: function (sLocoStatus, staged, sRole) {
				if (sRole === Constants.ROLE.SUPERVISOR || sRole === Constants.ROLE.LEADMAN) {
					if (sLocoStatus === Constants.STATUS_SHOPPED) {

						return true;

					}
				}
				return false;
			},
			/*
			 * function Sets the visibility of Shopped field on
			 * Details view according to the loco status
			 */
			setVisibilityForShoppedFields: function (status) {
				if (status === Constants.STATUS_SHOPPED || status === Constants.STATUS_STAGED) {
					return true;
				} else {
					return false;
				}
			},

			setVisibilityForShoppedWheelSheet: function (status) {

				if (status === Constants.STATUS_SHOPPED) {
					return true;
				}

				return false

			},
			/*
			 * function Sets the visibility of Shopped field on
			 * Workplan view  according to the loco status and Staged status
			 */
			setVisibilityForShoppedWorkPlanFields: function (status, staged) {
				if (status === Constants.STATUS_SHOPPED) {

					return true;

				}

				return false;
			},

			/**
			 * Formatter function for the visibility Defects tab
			 */
			setVisibilityForShoppedDefects: function (sStatus) {
				if (sStatus === Constants.STATUS_STAGED) {
					return false;
				}
				return true;
			},
			/* Function formats time in hours from seconds */
			formatTimeInHours: function (iSeconds) {
				var fHours = iSeconds / 3600;
				return com.sap.cp.lm.util.Formatter.roundedToFixed(fHours, 0) + "h";
			},
			getTimeInHoursFromSeconds: function (iSeconds) {
				var fHours = iSeconds / 3600;
				return com.sap.cp.lm.util.Formatter.roundedToFixed(fHours, 0) + "h";
			},
			roundedToFixed: function (fHours, iNoOfDecimals) {
				var iRounder = Math.pow(10, iNoOfDecimals);
				return (Math.round(fHours * iRounder) / iRounder).toFixed(iNoOfDecimals);
			},
			/* formatTimeInHours ends here */
			/* Function sets Uppercase letter is status is complete */
			formatStatusInUppercase: function (sType) {
				if (sType === Constants.STATUS_COMPLETED) {
					return sType.toUpperCase();
				} else {
					return sType;
				}
			},
			/*
			 * Function sets visibility for Status Text for a work
			 * order in loco detail view
			 */
			setVisibilityForWorkOrderStatus: function (sType) {
				if (sType === Constants.STATUS_COMPLETED) {
					return true;
				}
				if (sType === Constants.STATUS_NOT_STARTED) {
					return false;
				}
				if (sType === Constants.STATUS_IN_PROGRESS) {
					return true;
				}
			},
			/*
			 * Function sets visibility for Status Progressbar for a
			 * work oreder in loco detail view
			 */
			setVisibilityForProgressIndicator: function (sType) {
				if (sType === Constants.STATUS_COMPLETED) {
					return false;
				}
				if (sType === Constants.STATUS_NOT_STARTED) {
					return true;
				}
				if (sType === Constants.STATUS_IN_PROGRESS) {
					return false;
				}
			},
			/*
			 * Function counts the assignments in operation set for
			 * a locomotive
			 */
			getAssignmentCount: function (aAssignmentSet, aGroupedOperation) {
				if (aGroupedOperation && aGroupedOperation.length > 0) {

					if (!aAssignmentSet) {
						return 0;
					}
					var iAssignedCount = aAssignmentSet.length;
					var aAssignedCount = [];
					for (var i; i < aGroupedOperation.length; i++) {
						aAssignedCount.push(aGroupedOperation[i].AssignmentSet.results.length);
					}
					aAssignedCount.push(iAssignedCount);
					aAssignedCount.sort();

					return aAssignedCount[0];
				} else {

					if (!aAssignmentSet) {
						return 0;
					}
					var iAssignedCount = aAssignmentSet.length;
					return iAssignedCount;
				}

			},
			/*
			 * Function sets visibility for the control if Status is
			 * in progress of operation
			 */
			setVisibilityForOprationInProgress: function (sOPStatus, aGroupedOperation) {
				// don not dare to touch this formatter

				if (aGroupedOperation && aGroupedOperation.length > 0) {

					var aGroupOpStatus = [];
					var iGroupOpCompleteCount = 0;
					aGroupedOperation = JSON.stringify(aGroupedOperation);
					aGroupedOperation = JSON.parse(aGroupedOperation);

					aGroupedOperation.push(jQuery.extend(true, {}, {
						Status: sOPStatus
					}));
					for (var i = 0; i < aGroupedOperation.length; i++) {
						if (aGroupedOperation[i].Status === Constants.STATUS_COMPLETED || aGroupedOperation[i].Status === Constants.STATUS_IN_PROGRESS) {
							aGroupOpStatus.push(jQuery.extend(true, {}, {
								Status: aGroupedOperation[i].Status
							}));
							if (aGroupedOperation[i].Status === Constants.STATUS_COMPLETED) {
								iGroupOpCompleteCount = iGroupOpCompleteCount + 1;
							}
						}

					}
					if (iGroupOpCompleteCount === aGroupedOperation.length) {
						return false;
					}
					if (aGroupOpStatus.length === aGroupedOperation.length) {
						return true;
					}

					return false;
				} else {

					if (sOPStatus === Constants.STATUS_IN_PROGRESS) {
						return true;
					}
					return false;
				}
			},
			/** 
			 * Function to Enable the selection on operation based on Status.
			 * */
			enableOperationSelection: function (bOperationStaus) {
				if (bOperationStaus === Constants.STATUS_COMPLETED) {
					return false;
				} else {
					return true;
				}
			},
			/** 
			 * Function to Enable the select all operation in Workplan.
			 * */
			enableAllOperationSelection: function (aOperations) {
				var bSelection = true;
				aOperations.forEach(function (oItem) {
					if (oItem.Status === Constants.STATUS_COMPLETED) {
						bSelection = false;
					}
				});
				return bSelection;

			},

			/*
			 * Function sets visibility for the control if Status is
			 * Planned of operation
			 */
			setVisibilityForOprationNotStarted: function (sOPStatus, aGroupedOperation, isServicing) {

				if (isServicing) {
					if (sOPStatus === Constants.STATUS_NOT_STARTED || sOPStatus === Constants.STATUS_NOT_PLANNED) {
						return true;
					}
				}
				if (aGroupedOperation && aGroupedOperation.length > 0) {

					var aGroupOpStatus = [];

					for (var i = 0; i < aGroupedOperation.length; i++) {
						if (aGroupedOperation[i].Status === Constants.STATUS_COMPLETED || aGroupedOperation[i].Status === Constants.STATUS_IN_PROGRESS ||
							aGroupedOperation[i].Status === Constants.STATUS_NOT_STARTED) {
							aGroupOpStatus.push(aGroupedOperation[i].Status);

						}

					}
					if (sOPStatus === Constants.STATUS_COMPLETED || sOPStatus === Constants.STATUS_IN_PROGRESS || sOPStatus === Constants.STATUS_NOT_STARTED) {
						aGroupOpStatus.push(sOPStatus);

					}

					if (aGroupOpStatus.length === aGroupedOperation.length + 1) {
						return true;
					}

					return false;
				} else {

					if (sOPStatus === Constants.STATUS_NOT_STARTED) {
						return true;
					}
					return false;
				}
			},
			/*
			 * Function sets text as Not Started according to status
			 * comming for operation
			 */
			setOperationStatusNotStarted: function (sLocoStatus) {
				if (sLocoStatus === Constants.STATUS_NOT_STARTED) {
					return Constants.TEXT_NOTSTARTED;
				}
			},
			/*
			 * Function sets text as COMPLETE according to status
			 * comming for operation
			 */
			setOperationStatusCompleted: function (sLocoStatus) {
				if (sLocoStatus === Constants.STATUS_COMPLETED) {
					return Constants.TEXT_COMPLETE;
				}
			},

			/*
			 * Function sets text as In progress according to status
			 * comming for operation
			 */
			setOperationStatusInProgress: function (sLocoStatus) {
				if (sLocoStatus === Constants.STATUS_IN_PROGRESS) {
					return Constants.TEXT_INPROGRESS;
				}
			},
			/**
			 *set the status of task in checkbox
			 */
			setCheckBoxForTask: function (sLocoStatus) {

				if (sLocoStatus === Constants.STATUS_COMPLETED) {
					return true;
				}

				return false;
			},
			/**
			 *set the status of  group task in checkbox
			 */
			setCheckBoxForGroupTask: function (sTaskListNode) {
				var sTaskPath = this.getBindingContext().sPath;
				var aOPPath = sTaskPath.split("TaskSet");
				var TaskSet = this.getModel().getProperty(aOPPath[0]).TaskSet.results;
				var aTaskGroupNode = [];
				var aTaskGroupComplete = [];
				if (TaskSet.length > 0) {
					for (var i = 0; i < TaskSet.length; i++) {

						if (TaskSet[i].Status === Constants.STATUS_NOT_PLANNED && TaskSet[i].TasklistNodeNumber === sTaskListNode) {
							return false

						}

					}
				}

				return true;
			},

			/**
			 *enabled disable the task checkboc on status
			 */
			enableCheckBoxForTask: function (sLocoStatus) {

				var sTaskPath = this.getBindingContext().sPath;
				var aOPPath = sTaskPath.split("TaskSet");
				var sOPStatus = this.getModel().getProperty(aOPPath[0]).Status;
				if (sOPStatus === Constants.STATUS_COMPLETED) {
					return false;
				}
				if (sOPStatus === Constants.STATUS_NOT_STARTED) {
					return false;
				}
				if (sOPStatus === Constants.STATUS_NOT_PLANNED) {
					return false;
				}

				if (sLocoStatus === Constants.STATUS_COMPLETED) {
					return false;
				}

				return true;
			},
			/**
			 *enabled disable the task checkboc on group status
			 */
			enableCheckBoxForGroupTask: function (sLocoStatus, sTaskListNode) {

				var sTaskPath = this.getBindingContext().sPath;
				var aOPPath = sTaskPath.split("TaskSet");
				var sOPStatus = this.getModel().getProperty(aOPPath[0]).Status;
				if (sOPStatus === Constants.STATUS_COMPLETED) {
					return false;
				}
				if (sOPStatus === Constants.STATUS_NOT_STARTED) {
					return false;
				}
				if (sOPStatus === Constants.STATUS_NOT_PLANNED) {
					return false;
				}

				if (sLocoStatus === Constants.STATUS_COMPLETED) {
					return false;
				}

				var TaskSet = this.getModel().getProperty(aOPPath[0]).TaskSet.results;
				var aTaskGroupNode = [];
				var aTaskGroupComplete = [];
				if (TaskSet.length > 0) {
					for (var i = 0; i < TaskSet.length; i++) {
						if (TaskSet[i].TasklistNodeNumber === sTaskListNode) {
							aTaskGroupNode.push(TaskSet[i]);

						}
						if (TaskSet[i].Status === Constants.STATUS_COMPLETED && TaskSet[i].TasklistNodeNumber === sTaskListNode) {
							aTaskGroupComplete.push(TaskSet[i]);

						}

					}

					if (aTaskGroupNode === aTaskGroupComplete) {
						return false;
					}

				}

				return true;
			},

			/* Function formats time in HH:mm for my work view */
			formatTimeInHrAndMin: function (oStartTime, oEndTime) {
				if (oStartTime === null || oEndTime === null) {
					return "0:00";
				} else {
					var iDuration = oEndTime.ms - oStartTime.ms;
					/*	var oDate = new Date;
						oDate.setTime(iDuration);
						var oHours = oDate.getUTCHours();
						var oMinutes = oDate.getUTCMinutes();
						var oSec = oDate.getUTCSeconds();*/
					var oMinutes = iDuration / 60000;
					var oHours = oMinutes / 60;
					oHours = parseInt(oHours);
					oMinutes = oMinutes - (oHours * 60);
					oMinutes = parseInt(oMinutes);

					/*if(oMinutes === 0 ) {
						oMinutes = 1;
					}*/
					return oHours + ":" + (oMinutes < 10 ? "0" + oMinutes : oMinutes);
				}
			},
			/*
			 * Function sets visibility for Status complete of
			 * operation
			 */
			setVisibilityForStatusComplete: function (sOPStatus, aGroupedOperation) {
				if (aGroupedOperation && aGroupedOperation.length > 0) {

					var aGroupOpStatus = [];
					aGroupedOperation = JSON.stringify(aGroupedOperation);
					aGroupedOperation = JSON.parse(aGroupedOperation);

					aGroupedOperation.push(jQuery.extend(true, {}, {
						Status: sOPStatus
					}));
					for (var i = 0; i < aGroupedOperation.length; i++) {
						if (aGroupedOperation[i].Status === Constants.STATUS_COMPLETED) {
							aGroupOpStatus.push(jQuery.extend(true, {}, {
								Status: aGroupedOperation[i].Status
							}));

						}

					}

					if (aGroupOpStatus.length === aGroupedOperation.length) {
						return true;
					} else {
						return false;
					}
				} else {
					if (sOPStatus === Constants.STATUS_COMPLETED) {
						return true;
					}
					return false;
				}

			},
			/*
			 * Function sets visibility for Status complete of
			 * operation
			 */
			getEnabledForNotInProgress: function (sOPStatus) {

				if (sOPStatus === Constants.STATUS_IN_PROGRESS) {
					return false;
				}
				return true;

			},

			/**
			 * Function sets visibility for Status not complete or deferred of operation
			 */
			setVisibilityForStatusNotCompleteAndNotDeferred: function (sOPStatus, oGroups, sGroupId, isDesktop) {
				if (sOPStatus === Constants.STATUS_DEFERRED) {
					return false;
				}

				return com.sap.cp.lm.util.Formatter.setVisibilityForStatusNotComplete(sOPStatus, oGroups, sGroupId, isDesktop);
			},

			/*
			 * Function sets visibility for REG Status
			 * operation
			 */
			setVisibilityForREG: function (sOPStatus) {
				if (sOPStatus === true) {
					return true;
				}
				return false;
			},

			/*
			 * Function sets visibility for long text
			 */
			setVisibilityForLongText: function (sLongText, aLinks) {
				var visible = false;

				if (sLongText) {
					if (sLongText.length > 0) {
						visible = true;
					}
				}

				if (aLinks && !visible) {
					if (aLinks.length > 0) {
						visible = true;
					}
				}

				return visible;
			},
			/* 
			 * Added for LPM 7-2a	Function set visibility for attachment
			 */
			setVisibilityForAttachment: function (aUrl) {
				var visible = false;

				if (aUrl) {
					if (aUrl.length > 0) {
						visible = true;
					}
				}
				return visible;
			},
			/*
			 * Function sets visibility for Checkbox at Workorder level
			 * based on its status
			 */
			/*
			setVisibilityForWOCheckBox: function(sStatus) {
				if (sStatus === Constants.STATUS_COMPLETED || sStatus === Constants.STATUS_DEFERRED) {
					return false;
				}
				return true;
			},*/

			/*
			 * Function sets visibility for Checkbox at Operation level
			 * based on its status
			 */
			setVisibilityForOperationCheckBox: function (sStatus, aGroupedOperation) {
				// check if the WO is completed or deferred if so hide the checkbox
				var oWO = this.getBindingContext().getModel().getProperty(this.getBindingContext().sPath.split("OperationSet")[0]);
				if (oWO.Status === Constants.STATUS_COMPLETED || oWO.Status === Constants.STATUS_DEFERRED) {
					return false;
				}

				if (sStatus === Constants.STATUS_COMPLETED) {
					return false;
				} else {
					if (aGroupedOperation && aGroupedOperation.length) {
						var i = 0;
						for (i = 0; i < aGroupedOperation.length; ++i) {
							if (aGroupedOperation[i].Status === Constants.STATUS_COMPLETED) {
								return false;
							}
						}
					}
				}
				return true;
			},

			/*
			 * Function sets selected for Checkbox at WO level
			 * based on its operations
			 */
			setSelectedWOCheckBox: function (aOperation) {

				var i = 0,
					j = 0;

				for (i = 0; i < aOperation.length; ++i) {
					if (!aOperation[i].Checked) {
						return false;
					} else {
						if (aOperation[i].GroupedOperations && aOperation[i].GroupedOperations.length) {
							for (j = 0; j < aOperation[i].GroupedOperations.length; ++j) {
								if (!aOperation[i].GroupedOperations[j].Checked) {
									return false;
								}
							}
						}
					}
				}
				return true;
			},
			/*
			 * Function sets visibility of text according to task
			 * status is planned
			 */
			setVisibilityForStatusPlanned: function (sLocoStatus, aGroupOpeartions) {

				if (aGroupOpeartions) {
					if (sLocoStatus === Constants.STATUS_NOT_PLANNED) {
						return false;
					} else {
						for (var i = 0; i < aGroupOpeartions.length; i++) {
							if (aGroupOpeartions[i].Status === Constants.STATUS_NOT_PLANNED) {
								return false;
							}

						}

					}
				} else {
					if (sLocoStatus === Constants.STATUS_NOT_PLANNED) {
						return false;
					}
				}

				return true;
			},
			/*
			 * Function sets visibility of WorkerList popover according to Operation
			 * status 
			 */

			setDiableWorkerListForCompletedOperations: function (sLocoStatus, aWorkOrders, sWorkOrderNum) {

				if (sLocoStatus === Constants.STATUS_COMPLETED) {
					return false;
				} else if (aWorkOrders && (aWorkOrders[sWorkOrderNum] === Constants.STATUS_COMPLETED || aWorkOrders[sWorkOrderNum] === Constants.STATUS_DEFERRED)) {
					return false;

				}

				return true;
			},

			/*
			 * Function sets visibility of text according to task
			 * status is not planned
			 */
			setVisibilityForStatusNotPlanned: function (sLocoStatus, aGroupOpeartions) {
				if (aGroupOpeartions) {

					if (sLocoStatus === Constants.STATUS_NOT_PLANNED) {
						return true;
					} else {
						for (var i = 0; i < aGroupOpeartions.length; i++) {
							if (aGroupOpeartions[i].Status === Constants.STATUS_NOT_PLANNED) {
								return true;
							}

						}

					}
					return false;

				} else {
					if (sLocoStatus === Constants.STATUS_NOT_PLANNED) {
						return true;
					}
					return false;
				}
			},
			/*
			 * Function sets visibility of text according to task
			 * status is -In Progress
			 */
			setVisibilityForStatusInProgress: function (sLocoStatus) {
				if (sLocoStatus === Constants.STATUS_IN_PROGRESS) {
					return true;
				}
				return false;
			},

			/**
			 * Set the WO Status Text and Color
			 */
			//start:Commented by Sandhya : LMP2-26: Progress Bar			 
			// setWOStatusTextAndColor: function (sLocoStatus, aOperations) {
			// 	var iCompletedOperations = 0;
			// 	if (sLocoStatus) {
			// 		if (sLocoStatus === Constants.STATUS_COMPLETED) {
			// 			this.addStyleClass("WOStatusCompleted");
			// 			return Constants.TEXT_SCOMPLETED;
			// 		} else if (sLocoStatus === Constants.STATUS_DEFERRED) {
			// 			this.addStyleClass("lmWOStatusDeferred");
			// 			return Constants.TEXT_DEFERED;
			// 		} else {
			// 			if (!aOperations) {
			// 				aOperations = [];
			// 			}

			// 			for (var k = 0; k < aOperations.length; k++) {
			// 				if (aOperations[k].Status === Constants.STATUS_COMPLETED) {
			// 					iCompletedOperations = iCompletedOperations + 1;
			// 				}
			// 			}
			// 			return iCompletedOperations + "/" + aOperations.length + " " + Constants.TEXT_SCOMPLETE;
			// 		}
			// 	}
			// 	return "";
			// },
			//End:Commented by Sandhya : LMP2-26: Progress Bar

			//Start : Added by Sandhya : LMP2-26 : Progress Bar
			setWOStatusTextAndColor: function (sLocoStatus, aOperations) {
				var iCompletedOperations = 0;
				var iTotalLen = 0;
				this.removeStyleClass("WOStatusCompleted");
				this.removeStyleClass("lmTagCompleted");
				this.removeStyleClass("lmWOStatusDeferred");
				if (sLocoStatus) {
					if (sLocoStatus === Constants.STATUS_COMPLETED) {
						this.addStyleClass("WOStatusCompleted");
						this.addStyleClass("lmTagCompleted");
						return Constants.TEXT_SCOMPLETED;
					} else if (sLocoStatus === Constants.STATUS_DEFERRED) {
						this.addStyleClass("lmWOStatusDeferred");
						return Constants.TEXT_DEFERED;
					} else {
						if (!aOperations) {
							aOperations = [];
						}
						for (var k = 0; k < aOperations.length; k++) {
							var TaskSet = aOperations[k].TaskSet ? aOperations[k].TaskSet.results : [];
							if (TaskSet.length === 0) {
								iTotalLen = iTotalLen + 1;
								if (aOperations[k].Status === Constants.STATUS_COMPLETED) {
									iCompletedOperations = iCompletedOperations + 1;
								}
							} else {
								for (var j = 0; j < TaskSet.length; j++) {
									iTotalLen = iTotalLen + 1;
									if (TaskSet[j].Status === Constants.STATUS_COMPLETED) {
										iCompletedOperations = iCompletedOperations + 1;
									}
								}
							}
						}
						return iCompletedOperations + "/" + iTotalLen + " " + Constants.TEXT_SCOMPLETE;
					}
				}
				return "";
			},
			//End:Added by Sandhya : LMP2-26 : Progress Bar

			//Start : Added by KIR0084 : LMP2-32 : Progress Bar on Work Order

			setOperationStatusTextAndColor: function (aWorkOrderStatus, aOperationSet) {
				if (aOperationSet) {
					var iCompletedOperations = aOperationSet.filter(function (operation) {
						return operation.Status === Constants.STATUS_COMPLETED;
					}).length;
					var iTotalLen = aOperationSet.length;

					return iCompletedOperations + "/" + iTotalLen + " " + Constants.TEXT_SCOMPLETE;
				} else {
					return "";
				}
			},

			parseStringToFloat: function (string) {
				if (!string) {
					return "";
				}
				return parseFloat(string);
			},

			formatHours: function (sHrs) {
				if (!sHrs) {
					return "";
				}
				var fHrs = parseFloat(sHrs);
				if (fHrs < 0) {
					return "0.00";
				} else {
					return fHrs.toFixed(2);
				}
			},

			formatPercentage: function (string) {
				if (string) {
					return parseFloat(string) + "%";
				}
				return "";
			},

			formatShiftText: function (startTime, endTime) {
				return com.sap.cp.lm.util.Formatter.changeDateFormatHHMM(startTime) + " - " + com.sap.cp.lm.util.Formatter.changeDateFormatHHMM(
					endTime);
			},

			formatShiftSecondaryText: function (startTime, endTime) {
				return com.sap.cp.lm.util.Formatter.changeDateFormatDayMMDDYY(startTime);
			},

			formatProductivity: function (hours, percentage) {
				if (hours || percentage) {
					return parseFloat(hours) + "h / " + parseFloat(percentage) + "%";
				}
				return "";
			},

			setWOStatusText: function (sLocoStatus, aOperations) {
				var iCompletedOperations = 0;
				var iTotalLen = 0;
				if (sLocoStatus) {
					if (sLocoStatus === Constants.STATUS_COMPLETED) {
						return Constants.TEXT_SCOMPLETED;
					} else if (sLocoStatus === Constants.STATUS_DEFERRED) {
						return Constants.TEXT_DEFERED;
					} else {
						if (!aOperations) {
							aOperations = [];
						}
						for (var k = 0; k < aOperations.length; k++) {
							var TaskSet = aOperations[k].TaskSet ? aOperations[k].TaskSet.results : [];
							if (TaskSet.length === 0) {
								iTotalLen = iTotalLen + 1;
								if (aOperations[k].Status === Constants.STATUS_COMPLETED) {
									iCompletedOperations = iCompletedOperations + 1;
								}
							} else {
								for (var j = 0; j < TaskSet.length; j++) {
									iTotalLen = iTotalLen + 1;
									if (TaskSet[j].Status === Constants.STATUS_COMPLETED) {
										iCompletedOperations = iCompletedOperations + 1;
									}
								}
							}
						}
						return iCompletedOperations + "/" + iTotalLen + " " + Constants.TEXT_SCOMPLETE;
					}
				}
				return "";
			},
			//End:Added by KIR0084 : LMP2-32 : Progress Bar on Work Order

			//Start : Added by KIR0084 : LMP2-32 : Operation Assignment Text
			setOperationAssignment: function (aAssignmentSet) {
				var assignmentText = "";
				if (aAssignmentSet && aAssignmentSet.length > 0) {
					assignmentText += Constants.TEXT_ASSIGNMENT + ": ";

					aAssignmentSet.forEach(function (assignment) {
						assignmentText += assignment.Name + ", ";
					});

					assignmentText = assignmentText.substring(0, assignmentText.length - 2);
				}
				return assignmentText;
			},

			setOperationAssignmentForPrint: function (aAssignmentSet) {
				var assignmentText = "";
				if (aAssignmentSet && aAssignmentSet.length > 0) {
					aAssignmentSet.forEach(function (assignment) {
						assignmentText += assignment.Name + ", ";
					});

					assignmentText = assignmentText.substring(0, assignmentText.length - 2);
				}
				return assignmentText;
			},
			//End:Added by KIR0084 : LMP2-32 : Operation Assignment Text

			/*
			 * Function sets visibility of text according to task
			 * status if not Complete and defer
			 */
			setVisibilityForStatusNotCompleteAndDefer: function (sLocoStatus, oGroups) {
				// Setting visibility for a simple workorder
				if (sLocoStatus) {
					return (sLocoStatus !== Constants.STATUS_COMPLETED && sLocoStatus !== Constants.STATUS_DEFERRED)
				}
				// Setting visibility for a group
				else if (oGroups) {
					var aGroupItemSet = oGroups.results;
					var bIsVisible = true;
					if (aGroupItemSet) {
						for (var i = 0; i < aGroupItemSet.length; i++) {
							var oCurrentGroup = aGroupItemSet[i];
							if (!oCurrentGroup.WorkOrder || oCurrentGroup.WorkOrder.ObjectStatuses.indexOf(Constants.STATUS_TECO_LIT) != -1) {
								bIsVisible = false;
								break;
							}
						}
					}
					return bIsVisible;
				}

				return true;
			},

			/*
			 * Function sets visibility of text according to regulatory  & WO
			 * status if not Complete and defer
			 */
			setVisibilityForAddOperation: function (bWheelSheet) {
				// Setting visibility for a simple workorder
				if (!bWheelSheet) {
					return true;
				}
				return false;

			},
			/*
			 * Function sets visibility of text according to regulatory  & WO
			 * status if not Complete and defer
			 */
			setVisibilityForRegulatoryAndStatusNotCompleteOrDefer: function (sStatus, sReg, oGroups, parentView) {
				// Setting visibility for a simple workorder

				var aAssignmentSet = this.getModel().getProperty("/detailsData/WorkPlan/AssignmentSet/results");

				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();

				var sCurrentRole = oGlobalModel.getProperty("/role");

				if (parentView === Constants.LOCOMOTIVES) {
					if (sCurrentRole === Constants.ROLE.CRAFT) {
						var oCurrentUser = this._oGlobalModel.getProperty("/currentUser");
						var sPersNum = oCurrentUser.PersonnelNumber;
						var i = 0;
						var flag = 1;
						if (aAssignmentSet) {
							for (i = 0; i < aAssignmentSet.length; ++i) {
								if (aAssignmentSet[i].PersonnelNumber === sPersNum) {
									flag = 0;
									break;
								}
							}
						}
						if (flag) {
							if (!sReg) {
								return com.sap.cp.lm.util.Formatter.setVisibilityForStatusNotCompleteAndDefer(sStatus, oGroups);
							}
							return false;
						}
					}
				}
				return com.sap.cp.lm.util.Formatter.setVisibilityForStatusNotCompleteAndDefer(sStatus, oGroups);

			},

			//Added by Sandhya : LMP2-4 :Not able to add operation
			setVisibilityForRegulatoryAndStatusNotCompleteOrDefer1: function (sStatus, sReg, sDef, sTasklistDescr, sOrderType) {
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				var sRole = oGlobalModel.getProperty("/role");

				if (sOrderType === 'MS01' || sOrderType === 'MS06') {
					return true;
				} else {
					return false;
				}
				// START - BAJ0018 - EAM-ASR3416229
				// if (sTasklistDescr.includes("SHOP MOVES") || sTasklistDescr.includes("DEFECTS")) {
				// 	//don't do anything
				// } else {
				// 	return false;

				// }
				// END - BAJ0018 - EAM-ASR3416229
				if (sStatus === '0') {
					return false;
				}
				if (sStatus != '0') {
					if (sRole === 'SUPERVISOR') {
						return true;
					} else {
						if (sDef === '0') {
							return true;
						} else {
							return false;
						}
					}
				}
			},
			//End:Added by Sandhya : LMP2-4 :Not able to add operation
			//Added by Sandhya : LMP2-02 : unTeco Option
			setVisibleunTeco: function (sStatus) {
				if (sStatus === '0') {
					return true;
				} else {
					return false;
				}
			},
			//End:Added by Sandhya : LMP2-4 :Not able to add operation

			//Added by Sandhya : LMP2-12 : Notif Long text on the inbound screen
			setVisibleLongText: function (sLongText) {
				if (sLongText.length > 0) {
					return true;
				} else {
					return false;
				}
			},
			//End:Added by Sandhya : LMP2-12 : Notif Long text on the inbound screen
			setVisibilityForStatusLHFM: function (sLocoStatus) {
				if (sLocoStatus === Constants.STATUS_DEFERRED) {
					return true;
				}
				return false;
			},
			/*
			 * Function sets complete work enable in action sheet
			 *  according to Operations complete status.
			 * 
			 */
			setVisibilityForOperationStatusComplete: function (aOperations, sGroupStatus) {
				var iCompletedOP = 0;

				if (!aOperations) {
					aOperations = [];
				}

				if (aOperations !== null) {
					if (sGroupStatus !== Constants.STATUS_DEFERRED) {
						for (var i = 0; i < aOperations.length; i++) {
							if (aOperations[i].Status === Constants.STATUS_COMPLETED) {
								iCompletedOP = iCompletedOP + 1;
							}
						}
						if (iCompletedOP === aOperations.length) {
							return true;
						}
					} else {
						//return false when group status is defered
						return false;
					}
				}
				return false;
			},

			/*
			 * Function sets task status according to no of
			 * completed task
			 */
			setOperationStatus: function (sOPStatus, aTask) {
				var j = 0;

				if (!aTask) {
					aTask = [];
				}

				for (var i = 0; i < aTask.length; i++) {
					if (aTask[i].Status === Constants.STATUS_COMPLETED) {
						j = j + 1;
					}
				}
				return j + "/" + aTask.length + " " + "Tasks" + " " + Constants.TEXT_SCOMPLETE;

			},
			/*
			 * Function sets the value of progress bar according to
			 * the completed task percentage
			 */
			//			progressIndicatorPercents: function (nPlanned, nCompleted) {
			//				if(nPlanned > 0) {
			//					var result = (nCompleted / nPlanned) * 100;
			//					return Math.round(result);
			//				} else {
			//					return 100;
			//				}
			//				return 0;
			//			},
			/*
			 * Function sets the value of progress bar according to
			 * the completed task percentage
			 */
			//Start: Commented by Sandhya : LMP2-26 : Progress Bar
			// setProgressIndicator: function (sWOStatus, aOperations) {
			// 	var iCompletedOperations = 0;
			// 	var fPercentValue = 0;
			// 	if (sWOStatus === Constants.STATUS_COMPLETED) {
			// 		fPercentValue = 100;
			// 	} else {
			// 		if (!aOperations) {
			// 			aOperations = [];
			// 		}

			// 		for (var k = 0; k < aOperations.length; k++) {
			// 			if (aOperations[k].Status === Constants.STATUS_COMPLETED) {
			// 				iCompletedOperations = iCompletedOperations + 1;
			// 			}
			// 		}
			// 		fPercentValue = (iCompletedOperations / aOperations.length) * 100;
			// 	}
			// 	return fPercentValue;
			// },
			//End: Commented by Sandhya : LMP2-26 : Progress Bar

			//Start : Added by Sandhya : LMP2-26: Progress bar
			setProgressIndicator: function (sWOStatus, aOperations) {
				var iCompletedOperations = 0;
				var fPercentValue = 0;
				var iTotalLen = 0;
				if (sWOStatus === Constants.STATUS_COMPLETED) {
					fPercentValue = 100;
				} else {
					if (!aOperations) {
						aOperations = [];
					}
					for (var k = 0; k < aOperations.length; k++) {
						/** LMP2-32 Return task set if results is empty */
						var TaskSet = aOperations[k].TaskSet ? aOperations[k].TaskSet.results || aOperations[k].TaskSet : [];
						/** LMP2-32 Return task set if results is empty */
						if (TaskSet.length === 0) {
							iTotalLen = iTotalLen + 1;
							if (aOperations[k].Status === Constants.STATUS_COMPLETED) {
								iCompletedOperations = iCompletedOperations + 1;
							}
						} else {
							for (var j = 0; j < TaskSet.length; j++) {
								iTotalLen = iTotalLen + 1;
								if (TaskSet[j].Status === Constants.STATUS_COMPLETED) {
									iCompletedOperations = iCompletedOperations + 1;
								}
							}
						}
					}
					if (iTotalLen === 0) {
						fPercentValue = 0;
					} else {
						fPercentValue = (iCompletedOperations / iTotalLen) * 100;
					}
				}
				return fPercentValue;
			},
			//End : Added by Sandhya : LMP2-26: Progress bar

			// Start: KIR0084 LMP2-32 - Add Locomotive Progress Indicator
			setLocomotiveProgressIndicator: function (aWorkOrders, shopStatus) {
				if (shopStatus === "R") {
					return 0;
				} else if (!aWorkOrders || aWorkOrders.length === 0) {
					return 0;
				} else {
					var iCompletedOperations = 0;
					var iTotalOperations = 0;
					aWorkOrders.forEach(function (workOrder) {
						workOrder.OperationSet.forEach(function (operation) {

							/** LMP2-32 Return task set if results is empty */
							var TaskSet = operation.TaskSet ? operation.TaskSet.results || operation.TaskSet : [];
							/** LMP2-32 Return task set if results is empty */
							if (TaskSet.length === 0) {
								iTotalOperations++;
								if (operation.Status === Constants.STATUS_COMPLETED) {
									iCompletedOperations = iCompletedOperations + 1;
								}
							} else {
								for (var j = 0; j < TaskSet.length; j++) {
									iTotalOperations++;
									if (TaskSet[j].Status === Constants.STATUS_COMPLETED) {
										iCompletedOperations = iCompletedOperations + 1;
									}
								}
							}
						});
					});
					return iCompletedOperations / iTotalOperations * 100;
				}
			},

			setLocomotiveStatusText: function (aWorkOrders, shopStatus) {
				var iCompletedOperations = 0;
				var iTotalOperations = 0;
				if (shopStatus === "R") {
					return "";
				} else if (aWorkOrders) {
					aWorkOrders.forEach(function (workOrder) {
						workOrder.OperationSet.forEach(function (operation) {

							/** LMP2-32 Return task set if results is empty */
							var TaskSet = operation.TaskSet ? operation.TaskSet.results || operation.TaskSet : [];
							/** LMP2-32 Return task set if results is empty */
							if (TaskSet.length === 0) {
								iTotalOperations++;
								if (operation.Status === Constants.STATUS_COMPLETED) {
									iCompletedOperations = iCompletedOperations + 1;
								}
							} else {
								for (var j = 0; j < TaskSet.length; j++) {
									iTotalOperations++;
									if (TaskSet[j].Status === Constants.STATUS_COMPLETED) {
										iCompletedOperations = iCompletedOperations + 1;
									}
								}
							}
						});
					});
				}
				return iCompletedOperations + "/" + iTotalOperations + " " + Constants.TEXT_SCOMPLETE;
			},
			// End: KIR0084 LMP2-32 - Add Locomotive Progress Indicator

			/*
			 * Function sets work order status according to no of
			 * completed WO
			 */
			setWorkOrderCompleteStatus: function (sWOStatus, aOperations) {
				var iCompletedOperations = 0;
				if (sWOStatus === Constants.STATUS_COMPLETED) {
					return Constants.TEXT_SCOMPLETED;
				} else {
					if (!aOperations) {
						aOperations = [];
					}

					for (var k = 0; k < aOperations.length; k++) {
						if (aOperations[k].Status === Constants.STATUS_COMPLETED) {
							iCompletedOperations = iCompletedOperations + 1;
						}
					}
					return iCompletedOperations + "/" + aOperations.length + " " + Constants.TEXT_SCOMPLETE;
				}
			},

			/* Function changes date format to MM/DD */
			changeDateFormatMMDDHHmm: function (oDate, aGroupOpeartions) {
				var sFormattedDate = "<NA>";
				if (oDate) {
					var getWorstConditionForGroup = function (oDate, aGroupOpeartions) {
						var aGroupPlanStartDate = [];
						for (var i = 0; i < aGroupOpeartions.length; i++) {
							aGroupPlanStartDate.push(aGroupOpeartions[i]);

						}
						var temp = {
							ScheduledStart: oDate
						};
						aGroupPlanStartDate.push(temp);
						var datesort_asc = function (date1, date2) {

							if (date1.ScheduledStart > date2.ScheduledStart) return 1;
							if (date1.ScheduledStart < date2.ScheduledStart) return -1;
							return 0;
						};
						aGroupPlanStartDate.sort(datesort_asc);
						return aGroupPlanStartDate[0];

					}
					if (aGroupOpeartions && aGroupOpeartions.length > 0) {

						var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
							pattern: "MM/dd HH:mm"
						});
						if (getWorstConditionForGroup(oDate, aGroupOpeartions) && getWorstConditionForGroup(oDate, aGroupOpeartions).ScheduledStart) {
							sFormattedDate = oDateFormat.format(getWorstConditionForGroup(oDate, aGroupOpeartions).ScheduledStart);
						}

					} else {
						var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
							pattern: "MM/dd HH:mm"
						});

						sFormattedDate = oDateFormat.format(oDate);

					}
				}
				return sFormattedDate;
			},

			/* Function changes date format to MM/DD */
			changeDateFormatMMDD: function (oDate, aGroupOpeartions) {
				var sFormattedDate = "<NA>";
				if (oDate) {
					var getWorstConditionForGroup = function (oDate, aGroupOpeartions) {
						var aGroupPlanStartDate = [];
						for (var i = 0; i < aGroupOpeartions.length; i++) {
							aGroupPlanStartDate.push(aGroupOpeartions[i]);

						}
						var temp = {
							ScheduledStart: oDate
						};
						aGroupPlanStartDate.push(temp);
						var datesort_asc = function (date1, date2) {

							if (date1.ScheduledStart > date2.ScheduledStart) return 1;
							if (date1.ScheduledStart < date2.ScheduledStart) return -1;
							return 0;
						};
						aGroupPlanStartDate.sort(datesort_asc);
						return aGroupPlanStartDate[0];

					}
					if (aGroupOpeartions && aGroupOpeartions.length > 0) {

						var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
							pattern: "MM/dd"
						});
						if (getWorstConditionForGroup(oDate, aGroupOpeartions) && getWorstConditionForGroup(oDate, aGroupOpeartions).ScheduledStart) {
							sFormattedDate = oDateFormat.format(getWorstConditionForGroup(oDate, aGroupOpeartions).ScheduledStart);
						}

					} else {
						var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
							pattern: "MM/dd"
						});

						sFormattedDate = oDateFormat.format(oDate);

					}
				}
				return sFormattedDate;
			},
			getTrackSpotForOperation: function (oDate, aGroupOpeartions, TrackNumber, TrackSpot) {
				var getWorstConditionForGroup = function (oDate, aGroupOpeartions) {
					var aGroupPlanStartDate = [];
					for (var i = 0; i < aGroupOpeartions.length; i++) {
						aGroupPlanStartDate.push(aGroupOpeartions[i]);
					}
					var temp = {
						ScheduledStart: oDate
					};
					aGroupPlanStartDate.push(temp);
					var datesort_asc = function (date1, date2) {
						if (date1.ScheduledStart > date2.ScheduledStart) return 1;
						if (date1.ScheduledStart < date2.ScheduledStart) return -1;
						return 0;
					};
					aGroupPlanStartDate.sort(datesort_asc);
					return aGroupPlanStartDate[0];
				}
				if (aGroupOpeartions && aGroupOpeartions.length > 0) {
					var groupOP = getWorstConditionForGroup(oDate, aGroupOpeartions);
					if (groupOP.ScheduledStart === oDate) {
						return TrackNumber + "-" + TrackSpot;
					} else return groupOPTrack + "-" + groupOP.TrackSpot;
				} else {

					return TrackNumber + "-" + TrackSpot;
				}
			},

			/* Function changes date format to Day MM DD yy */

			changeDateFormatDayMMDDUTC: function (oDate, bComments) {
				var utcEpoch = oDate.getTime() + (oDate.getTimezoneOffset() * 60000);
				var utcDate = new Date(utcEpoch);
				return com.sap.cp.lm.util.Formatter.changeDateFormatDayMMDDYYfull(utcDate, bComments, false);
			},

			changeDateFormatDayMMDDYYAtCurrentShop: function (dDate) {
				var oDate = com.sap.cp.lm.util.Formatter.localDateAtCurrentShop(dDate);
				return com.sap.cp.lm.util.Formatter.changeDateFormatDayMMDDYY(oDate);
			},

			changeDateFormatDayMMDDAtCurrentShop: function (dDate) {
				var oDate = com.sap.cp.lm.util.Formatter.localDateAtCurrentShop(dDate);
				return com.sap.cp.lm.util.Formatter.changeDateFormatDayMMDD(oDate);
			},

			changeDateFormatDayMMDD: function (oDate, bComments) {
				return com.sap.cp.lm.util.Formatter.changeDateFormatDayMMDDYYfull(oDate, bComments, false);
			},

			changeDateFormatDayMMDDYY: function (oDate, bComments) {
				return com.sap.cp.lm.util.Formatter.changeDateFormatDayMMDDYYfull(oDate, bComments, true);
			},

			changeDateFormatDayMMDDYYfull: function (oDate, bComments, bUseYear) {
				if (oDate) {
					var oDays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
					var oMonths = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November",
						"December"
					];
					var currentDay = oDate.getDay();
					var currentMonth = oDate.getMonth();
					var currentDate = oDate.getDate();
					var currentYear = "";

					if (bUseYear === true) {
						currentYear = " " + oDate.getFullYear() + " ";
					}

					if (bComments) {
						return (oMonths[currentMonth] + " " + currentDate + currentYear + (oDate.getHours() > 9 ? oDate.getHours() : "0" +
							oDate.getHours()) + ":" + (oDate.getMinutes() > 9 ? oDate.getMinutes() : "0" + oDate.getMinutes()));
					} else {
						return (oDays[currentDay] + " " + oMonths[currentMonth] + " " + currentDate + currentYear);
					}
				}
				return "";
			},
			/* Function changes date format to Day DDMMyy */
			changeDateFormatMMDDYY: function (oDate) {
				var sFormattedDate = "<NA>";
				if (oDate) {
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: Constants.MMDDYY
					});
					sFormattedDate = oDateFormat.format(oDate);
				}
				return sFormattedDate;
			},

			changeDateFormatDateTime: function (oDate) {
				var sFormattedDate = "<NA>";
				if (oDate) {
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "MM-dd-yyyyTHH:mm:ss"
					});
					sFormattedDate = oDateFormat.format(oDate);
				}
				return sFormattedDate;
			},

			toDatetimeFormat: function (oDate) {
				var sFormattedDate = "<NA>";
				if (oDate) {
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "yyyy-MM-ddTHH:mm:ss"
					});
					sFormattedDate = oDateFormat.format(oDate);
				}
				return sFormattedDate;
			},

			/*
			 * handle timestamps and timezones
			 */
			changeToUTCTimestamp: function (oDate) {
				var sFormattedDate = "";

				var utcEpoch = oDate.getTime() + (oDate.getTimezoneOffset() * 60000);
				var utcDate = new Date(utcEpoch);
				if (utcDate) {
					$.sap.require("sap.ui.core.format.DateFormat");
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "yyyyMMddHHmmss"
					});
					sFormattedDate = oDateFormat.format(utcDate);
				}

				return sFormattedDate;
			},

			changeTimestampToDayHour: function (sTimestamp, sTimezone) {
				var sFormattedDate = "";
				if (sTimestamp) {
					var oDate = new Date(sTimestamp);
					if (oDate) {
						$.sap.require("sap.ui.core.format.DateFormat");
						var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
							pattern: "MM/dd HH:mm"
						});
						sFormattedDate = oDateFormat.format(oDate);
					}
				}
				return sFormattedDate;
			},
			changeTimestampToDayHourWithColor: function (sTimestamp, sTimezone) {
				var sFormattedDate = "";
				if (sTimestamp) {
					var oDate = new Date(sTimestamp);
					if (oDate) {
						$.sap.require("sap.ui.core.format.DateFormat");
						var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
							pattern: "MM/dd HH:mm"
						});
						sFormattedDate = oDateFormat.format(oDate);
					}
				}
				if (sTimestamp >= new Date()) {
					this.addStyleClass("lmBackgroundGreen");
					this.addStyleClass("lmBoldWhite");
				} else {
					this.addStyleClass("lmBackgroundRed");
					this.addStyleClass("lmBoldWhite");
				}
				return sFormattedDate;
			},
			changeTimestampToDay: function (sTimestamp, sTimezone) {
				var sFormattedDate = "";
				if (sTimestamp) {
					var oDate = new Date(sTimestamp);
					if (oDate) {
						$.sap.require("sap.ui.core.format.DateFormat");
						var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
							pattern: "MM/dd"
						});
						sFormattedDate = oDateFormat.format(oDate);
					}
				}
				return sFormattedDate;
			},
			/*
			 * Function changes date format to Day MM DD yy
			 * Completed
			 */
			changeDateFormatMMDDYYCompleted: function (oDate) {
				var sFormattedDate = "";
				if (oDate) {
					$.sap.require("sap.ui.core.format.DateFormat");
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: Constants.MMDDYY
					});
					sFormattedDate = oDateFormat.format(oDate);
				}
				var sCompletedString = "Completed: ";
				return sCompletedString + sFormattedDate;
			},

			changeDateFormatDayHour: function (oDate) {
				var sFormattedDate = "<NA>";
				var todayDate = new Date();
				if (oDate) {
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "MMMM d  'at'  HH:mm",
						relative: true,
						relativeRange: [0]
					});

					oDateFormat.bSupportRelative = true;

					sFormattedDate = oDateFormat.format(oDate);

				}
				return sFormattedDate;
			},

			getAlertMessageHeader: function (sName, sFamily) {
				return sName + " " + sFamily;
			},

			getReadClassForAlert: function (sReadFlag) {
				var sReadClass = "unreaded";

				if (sReadFlag === true) {
					sReadClass = "readed";
				}

				return sReadClass;
			},

			/* Needs to check this function need to test this function for craft and Work when the data is comming:Neha Kannaujia*/
			getOperationRoleBasedStaus: function (sRole) {

				return "Not Planned";
			},
			/*
			 * Function sets the status of task - such as defered
			 * ,completed ,not planned and in progress
			 */
			setTaskStaus: function (sLocoStatus) {
				if (sLocoStatus === Constants.STATUS_NOT_PLANNED) {
					return Constants.TEXT_NOTPLANNED;
				}
				if (sLocoStatus === Constants.STATUS_COMPLETED) {
					return Constants.TEXT_SCOMPLETED;
				}
				if (sLocoStatus === Constants.STATUS_IN_PROGRESS) {
					return Constants.TEXT_INPROGRESS;
				}
				if (sLocoStatus === Constants.STATUS_DEFERRED) {
					return Constants.TEXT_DEFERED;
				}
			},
			/*
			 * Function sets Visibility for planner link if role is
			 * supervisor/planner and status is not planned
			 */
			setVisibilityForPlanLink: function (sStatus, sRole, aGroupOpeartions) {

				if (sRole === Constants.ROLE.CRAFT) {
					return false;
				}
				if (sRole === Constants.ROLE.PLANNER || sRole === Constants.ROLE.SUPERVISOR) {
					if (aGroupOpeartions) {
						if (sStatus === Constants.STATUS_NOT_PLANNED) {
							return true;
						} else {
							for (var i = 0; i < aGroupOpeartions.length; i++) {
								if (aGroupOpeartions[i].Status === Constants.STATUS_NOT_PLANNED) {
									return true;
								}
							}
						}
					} else {
						// check if the WO is deferred if so hide the plan button
						var oWO = this.getBindingContext().getModel().getProperty(this.getBindingContext().sPath.split("OperationSet")[0]);
						if (oWO.Status !== Constants.STATUS_DEFERRED && sStatus === Constants.STATUS_NOT_PLANNED) {
							return true;
						}
					}
				}
				return false;
			},

			/*
			 * Function sets Visibility for planner Date link if role is
			 * supervisor/Planner and status is not planned
			 */
			setVisibilityForPlanTextLink: function (sRole, sStatus, aGroupOpeartions) {

				if (sRole === Constants.ROLE.CRAFT) {
					return false;
				}
				if (sRole === Constants.ROLE.PLANNER || sRole === Constants.ROLE.SUPERVISOR) {
					if (aGroupOpeartions) {
						var iNotPlanCount = 0;
						if (sStatus === Constants.STATUS_NOT_PLANNED) {
							iNotPlanCount = iNotPlanCount + 1;
						}

						for (var i = 0; i < aGroupOpeartions.length; i++) {
							if (aGroupOpeartions[i].Status === Constants.STATUS_NOT_PLANNED) {
								iNotPlanCount = iNotPlanCount + 1;
							}
						}
						if (iNotPlanCount > 0) {
							return false;
						} else {
							return true;
						}

					} else {
						// check if the WO is deferred if so hide the plan button
						var oWO = this.getBindingContext().getModel().getProperty(this.getBindingContext().sPath.split("OperationSet")[0]);
						if (oWO.Status !== Constants.STATUS_DEFERRED && sStatus === Constants.STATUS_NOT_STARTED) {
							return true;
						} else {
							return false;
						}
					}
				}
			},

			/*
			 * Function sets visibility of text when status is planned
			 */
			setVisibilityForPlanText: function (sRole, sStatus, aGroupOpeartions) {
				if (sRole !== Constants.ROLE.PLANNER && sRole !== Constants.ROLE.SUPERVISOR) {

					if (aGroupOpeartions) {
						if (sStatus === Constants.STATUS_NOT_PLANNED) {
							return false;
						} else {
							for (var i = 0; i < aGroupOpeartions.length; i++) {
								if (aGroupOpeartions[i].Status === Constants.STATUS_NOT_PLANNED) {
									return false;
								}

							}

						}
					} else {
						if (sStatus === Constants.STATUS_NOT_PLANNED) {
							return false;
						}
					}

					return true;
				} else if (sStatus === Constants.STATUS_COMPLETED) {
					/// NEEDS CONFIRMATION 
					return true;
				}
				return false;
			},

			/*
			 * Function Sets the visibility status of the Material
			 * according to the availability
			 */
			setVisibilityForMaterialAvailable: function (sLocoStatus, sCannibalLoco) {

				var bVisibility = false;
				if (!sCannibalLoco) {
					if (sLocoStatus === Constants.STATUS_MATERIAL_AVAILABLE) {
						bVisibility = true;
					}
				}
				return bVisibility;
			},
			/*
			 * Function Sets the visibility status of the Material
			 * if it is requested
			 */
			setVisibilityForMaterialRequested: function (sLocoStatus, sCannibalLoco) {
				var bVisibility = false;
				if (!sCannibalLoco) {
					if (sLocoStatus === Constants.STATUS_MATERIAL_REQUESTED) {
						bVisibility = true;
					}
				}
				return bVisibility;
			},
			/*
			 * Function Sets the visibility status of the Material
			 * if it is not available
			 */
			setVisibilityForMaterialNA: function (sLocoStatus, sCannibalLoco) {
				var bVisibility = false;
				if (!sCannibalLoco) {
					if (sLocoStatus === Constants.STATUS_MATERIAL_NOT_AVAILABLE) {
						bVisibility = true;
					}
				}
				return bVisibility;
			},
			setVisibilityForMaterialCan: function (sLocoStatus, Group, sCannibalLocoNumber, sRole) {
				if (sRole === Constants.ROLE.CRAFT) {
					return false;
				}
				if (Group) {
					return false
				} else {
					if (sLocoStatus === Constants.STATUS_MATERIAL_NOT_AVAILABLE && sCannibalLocoNumber === "") {
						return true;
					}
					return false;
				}

			},

			setVisibilityForMaterialCanText: function (sCannibalLocoNumber) {

				if (sCannibalLocoNumber === "") {
					return false;
				}
				return true;

			},
			/*
			 * Function Sets the visibility for assign and reassign
			 * button based on rule
			 */
			setVisibilityForAssign: function (sRole, sWorkOrderStatus) {
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				if (oGlobalModel.getProperty("/readOnlyWorkPlan") === true) {
					return false;
				}

				if (sWorkOrderStatus === Constants.STATUS_DEFERRED || sWorkOrderStatus === Constants.STATUS_COMPLETED) {
					return false;
				}

				// This needs to be testes when data is there Neha Kannaujia	
				if (sRole === Constants.ROLE.SUPERVISOR || sRole === Constants.ROLE.LEADMAN || sRole === Constants.ROLE.PLANNER) {
					return true;
				}
				return false;
			},
			setVisibilityForDeleteOperationButton: function (sRole, sOpStatus, sWO) {
				if (sWO) {
					if ((sRole === Constants.ROLE.SUPERVISOR || sRole === Constants.ROLE.LEADMAN || sRole === Constants.ROLE.PLANNER) && sOpStatus !==
						Constants.STATUS_COMPLETED) {
						return true;
					}

				} else {
					var i = 0;
					for (i = 0; i < sOpStatus.length; ++i) {
						if ((sRole === Constants.ROLE.SUPERVISOR || sRole === Constants.ROLE.LEADMAN || sRole === Constants.ROLE.PLANNER) && sOpStatus[i] !==
							Constants.STATUS_COMPLETED) {
							return true;
						}
					}
				}
				return false;
			},

			setVisibilityForDeleteOperationInCraft: function (sOpStatus, aGroupedOperation) {

				if (sOpStatus !== Constants.STATUS_COMPLETED) {
					return true;
				} else {
					var i = 0;
					if (aGroupedOperation && aGroupedOperation.length) {
						for (i = 0; i < aGroupedOperation.length; ++i) {
							if (aGroupedOperation[i].Status !== Constants.STATUS_COMPLETED) {
								return true;
							}
						}
					}
				}
				return false;
			},
			/*
			 * Function sets the Image square color according to
			 * priority
			 */
			setBulletColor: function (sType) {
				if (sType === Constants.STATUS_DEFECT_PRIORITY_HIGH) {
					return "#C4002A";
				} else if (sType === Constants.STATUS_DEFECT_PRIORITY_MEDIUM) {
					return "#1E93DA";
				} else if (sType === Constants.STATUS_DEFECT_PRIORITY_LOW) {
					return "#FB9300";
				}
			},
			/**
			 * Function sets the material icon
			 */
			setVisibilityForMaterialIcon: function (aMaterials) {
				if (!aMaterials || aMaterials.length === 0) {
					// Not Applicable
					if (this.setEnabled) {
						this.setEnabled(false);
					}
					return com.sap.cp.lm.util.Formatter.getVersionPath() + "mimes/NA_Icon.png";
				}
				var j = 0;
				var k = 0;
				for (var i = 0; i < aMaterials.length; i++) {
					if (aMaterials[i].Status === Constants.STATUS_MATERIAL_NOT_AVAILABLE) {
						this.addStyleClass("lmIconColorAlert");
						return "sap-icon://alert";
					} else if (aMaterials[i].Status === Constants.STATUS_MATERIAL_AVAILABLE) {
						j = j + 1;
					} else if (aMaterials[i].Status === Constants.STATUS_MATERIAL_REQUESTED) {
						k = k + 1;
					}
				}
				if (k > 0) {
					this.addStyleClass("lmIconColorNotification");
					return "sap-icon://notification";
				}
				if (j === aMaterials.length) {
					this.addStyleClass("lmIconColorAccept");
					return "sap-icon://accept";
				}
			},

			/**
			 * Get the Material Icon URL
			 */
			_getMaterialIconURL: function (aOperations, oIcon) {
				var sVersionPath = com.sap.cp.lm.util.Formatter.getVersionPath();
				var sIcon = sVersionPath + "mimes/NA_Icon.png";

				if (!aOperations) {
					aOperations = [];
				}
				var k = 0;
				var bMaterials = false;
				for (var i = 0; i < aOperations.length; i++) {
					for (var j = 0; j < aOperations[i].MaterialSet.results.length; j++) {
						bMaterials = true;
						if (aOperations[i].MaterialSet.results[j].Status === Constants.STATUS_MATERIAL_NOT_AVAILABLE) {
							oIcon.addStyleClass("lmIconColorAlert");
							sIcon = sVersionPath + "mimes/Alert_Icon.png";
							return sIcon;
						} else if (aOperations[i].MaterialSet.results[j].Status === Constants.STATUS_MATERIAL_REQUESTED) {
							k = k + 1;
						}
					}
				}
				if (k > 0) {
					oIcon.addStyleClass("lmIconColorNotification");
					sIcon = sVersionPath + "mimes/Notification_Icon.png";
				} else if (bMaterials) {
					oIcon.addStyleClass("lmIconColorAccept");
					sIcon = sVersionPath + "mimes/Accept_Icon.png";
				}

				return sIcon;
			},

			showMaterialNA: function (aOperations) {
				var sIcon = com.sap.cp.lm.util.Formatter._getMaterialIconURL(aOperations, this);
				if (sIcon === null) {
					return true;
				}
				return false;
			},

			/*
			 * Function sets the Icon for Material according to the
			 * status of material
			 */
			setMaterialIcon: function (aOperations) {
				var sIcon = com.sap.cp.lm.util.Formatter._getMaterialIconURL(aOperations, this);
				if (sIcon === null) {
					this.setVisible(false);
				}
				return sIcon;

			},

			/*
			 * Function sets the Icon for Material for a single Operation according to the
			 * status of material
			 */
			setMaterialIconSingleOperation: function (aMaterials) {
				var aOperations = [{
					MaterialSet: aMaterials
				}];
				var sIcon = com.sap.cp.lm.util.Formatter._getMaterialIconURL(aOperations, this);
				if (sIcon === null) {
					this.setVisible(false);
				}
				return sIcon;
			},

			/*
			 * Function sets the Icon Color for Material according
			 * to the status of material
			 */
			setMaterialIconColor: function (aOperations) {
				var sColor = Constants.COLOR.GREEN;

				if (!aOperations) {
					aOperations = [];
				}

				for (var i = 0; i < aOperations.length; i++) {
					for (var j = 0; j < aOperations[i].MaterialSet.results.length; j++) {
						if (aOperations[i].MaterialSet.results[j].Status === Constants.STATUS_MATERIAL_NOT_AVAILABLE) {
							sColor = Constants.COLOR.RED;
							break;
						} else if (aOperations[i].MaterialSet.results[j].Status === Constants.STATUS_MATERIAL_REQUESTED) {
							sColor = Constants.COLOR.YELLOW;
						}
					}
				}
				return sColor;
			},
			// To be updated later when odata service will be ready
			ProgressIndicatorChange: function () {
				var startTime = 1275632110000;
				var shiftTime = 1375632110000;
				var finishedTime = 1459174237921;
				var perChange = (((shiftTime - startTime) / (finishedTime - startTime)) * 100); // main
				// percentValue
				// for
				// progress
				// bar
				return perChange;
			},
			// To be updated later when odata service will be ready
			ProgressIndicatorChangeCurrent: function () {
				var startTime = 1275632110000;
				var currentTime = 1375632110000;
				var shiftTime = 1459174237921;
				var perChange = (((currentTime - startTime) / (shiftTime - startTime)) * 100); // change
				// within
				// a
				// progress
				// bar
				return perChange;
			},

			// To be updated later when odata service will be ready
			ProgressIndicatorChangeLoco: function (EstimatedArrivalTime, EstimatedReleaseTime) {
				if (EstimatedArrivalTime !== undefined && EstimatedArrivalTime !== undefined) {
					var sArrivedTime = EstimatedArrivalTime.getTime();
					var sPlannedRelease = EstimatedReleaseTime.getTime();

					//var arrivedTime = 964505710000;
					var startedTime = 1458000200000;
					//var plannedRelease = 1392185710000;

					var sTimeDiffBtwReleasedAndArrived = Math.abs(sPlannedRelease - sArrivedTime);
					var sDaysDiffBtwReleasedAndArrived = (Math.ceil(sTimeDiffBtwReleasedAndArrived / (1000 * 3600 * 24)));
					var stimeDiffBtwArrivedAndStarted = Math.abs(startedTime - sArrivedTime);
					var sDaysDiffBtwArrivedAndStarted = (Math.ceil(stimeDiffBtwArrivedAndStarted / (1000 * 3600 * 24)));
					var sDiff = ((sDaysDiffBtwArrivedAndStarted / sDaysDiffBtwReleasedAndArrived) * 20);
					if (sDiff > 0) {
						return 4; //sDiff;Needs to be updated when data is proper
					} else {
						return 0;
					}

				} else {
					return 0;
				}
				// //gives result in rem for padding
				//return 4;
			},

			/**
			 * Calculate total input time for a workorder in craft work plan
			 * @params(oWorkOrders) oWorkOrders is the workorder object that contains all operations for that wo 
			 * $params(ActualDurationUnit) ActualDurationUnit is the unit for ActualDuration time
			 */
			craftWPTotalInputTime: function (oWorkOrders) {
				if (oWorkOrders) {
					var iTotalTimeInput = 0;
					var iNoOfOps = oWorkOrders.length;
					var iHours = 0;
					var iMins = 0;

					for (var i = 0; i < iNoOfOps; i++) {

						var sActualStartDate = oWorkOrders[i].ActualStartDate;
						var sActualStartTime = oWorkOrders[i].ActualStartTime;
						var sActualEndDate = oWorkOrders[i].ActualEndDate;
						var sActualEndTime = oWorkOrders[i].ActualEndTime;

						var sTimeInHrsAndMin = com.sap.cp.lm.util.Formatter.calculateHoursByDateTime(sActualStartDate, sActualStartTime, sActualEndDate,
							sActualEndTime);

						var aHourAndMinsDuration = sTimeInHrsAndMin.split(" ");
						iHours += parseInt(aHourAndMinsDuration[0]);
						var sNewMin = parseInt(aHourAndMinsDuration[2]);
						var iTotalMins = sNewMin + iMins;
						if (iTotalMins > 60 || iTotalMins === 60) {
							var iHoursToAdd = iTotalMins / 60;
							iTotalMins = iTotalMins % 60;
							iHours += parseInt(iHoursToAdd);
						}
						iMins = iTotalMins;
					}
					iHours = iHours < 10 ? "0" + iHours : iHours;
					iMins = iMins < 10 ? "0" + iMins : iMins;
					return iHours + " H " + iMins + " M";
				}
				return "";
			},

			/**
			 * Calculate total required time for a workorder in craft work plan
			 * @params(oWorkOrders) oWorkOrders is the workorder object that contains all operations for that wo 
			 * $params(PlanDurationUnit) PlanDurationUnit is the unit for PlanDurationUnit time
			 */
			craftWPTotalRequiredTime: function (oWorkOrders) {

				if (oWorkOrders) {
					var iTotalTimeRequired = 0;
					var iNoOfOps = oWorkOrders.length;
					var iHours = 0;
					var iMins = 0;
					for (var i = 0; i < iNoOfOps; i++) {
						var sActualDuration = oWorkOrders[i].PlanDuration;
						var sActualDurationUnit = oWorkOrders[i].PlanDurationUnit;
						var sTimeInHrsAndMin = com.sap.cp.lm.util.Formatter.changeTimeFormatByUnit(sActualDuration, sActualDurationUnit);
						var aHourAndMinsDuration = "";
						if (sTimeInHrsAndMin) {
							aHourAndMinsDuration = sTimeInHrsAndMin.split(" ");
						}
						iHours += parseInt(aHourAndMinsDuration[0]);
						var sNewMin = parseInt(aHourAndMinsDuration[2]);
						var iTotalMins = sNewMin + iMins;
						if (iTotalMins > 60 || iTotalMins === 60) {
							var iHoursToAdd = iTotalMins / 60;
							iTotalMins = iTotalMins % 60;
							iHours += parseInt(iHoursToAdd);
						}
						iMins = iTotalMins;
					}
					iHours = iHours < 10 ? "0" + iHours : iHours;
					iMins = iMins < 10 ? "0" + iMins : iMins;
					return iHours + " H " + iMins + " M";
				}
				return "";
			},

			/**
			 * Used by DateRangeSelection to setup the default selection period: 30 days back in the time
			 * @returns model which contains the defauls date selection periods
			 */
			getDatePickerRange: function () {
				var dateFrom = new Date();
				var DateTo = new Date();
				var sfromDate = dateFrom.getDate();
				var sfromMonth = dateFrom.getMonth();
				var sfromYear = dateFrom.getFullYear();

				dateFrom.setUTCDate(dateFrom.getDate() - 30);
				dateFrom.setUTCMonth(dateFrom.getMonth());
				dateFrom.setUTCFullYear(dateFrom.getFullYear());

				DateTo.setUTCDate(sfromDate);
				DateTo.setUTCMonth(sfromMonth);
				DateTo.setUTCFullYear(sfromYear);
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData({
					"delimiterdateRangeHistory": "@",
					"dateValuedateRangeHistory": dateFrom,
					"secondDateValuedateRangeHistory": DateTo,
					"dateFormatdateRangeHistory": Constants.MMDDYYYY

				});
				return oModel;
				//this.getView().setModel(oModel ,"dateRange");
			},

			/**
			 * set color black for totaltime for a workorder in craft work plan if TotalRequiredTime is greater than TotalInputTime
			 * @params(oWorkOrders) oWorkOrders is the workorder object that contains all operations for that WO
			 */
			setTotalTimeColorBlackInCraftWorkPlan: function (oWorkOrders) {
				{
					var sTotalRequiredTime = com.sap.cp.lm.util.Formatter.craftWPTotalRequiredTime(oWorkOrders);
					var sTotalInputTime = com.sap.cp.lm.util.Formatter.craftWPTotalInputTime(oWorkOrders);

					var aHourAndMinInTotalRequiredTime = sTotalRequiredTime.split(" ");
					var iHoursTotalRequiredTime = parseInt(aHourAndMinInTotalRequiredTime[0]);
					var iMinsTotalRequiredTime = parseInt(aHourAndMinInTotalRequiredTime[2]);
					var fTotalRequiredTimeInHours = iHoursTotalRequiredTime + (iMinsTotalRequiredTime / 60);

					var aHourAndMinInTotalInputTime = sTotalInputTime.split(" ");
					var iHoursTotalInputTime = parseInt(aHourAndMinInTotalInputTime[0]);
					var iMinsTotalInputTime = parseInt(aHourAndMinInTotalInputTime[2]);
					var fTotalInputTimeInHours = iHoursTotalInputTime + (iMinsTotalInputTime / 60);

					if (fTotalRequiredTimeInHours < fTotalInputTimeInHours) {
						return false;
					} else {
						return true;
					}
				}
			},
			/**
			 * set color red for totaltime for a workorder in craft work plan if TotalRequiredTime is less than TotalInputTime
			 * @params(oWorkOrders) oWorkOrders is the workorder object that contains all operations for that wo
			 */
			setTotalTimeColorRedInCraftWorkPlan: function (oWorkOrders) {

				var sTotalRequiredTime = com.sap.cp.lm.util.Formatter.craftWPTotalRequiredTime(oWorkOrders);
				var sTotalInputTime = com.sap.cp.lm.util.Formatter.craftWPTotalInputTime(oWorkOrders);

				var aHourAndMinInTotalRequiredTime = sTotalRequiredTime.split(" ");
				var iHoursTotalRequiredTime = parseInt(aHourAndMinInTotalRequiredTime[0]);
				var iMinsTotalRequiredTime = parseInt(aHourAndMinInTotalRequiredTime[2]);
				var fTotalRequiredTimeInHours = iHoursTotalRequiredTime + (iMinsTotalRequiredTime / 60);

				var aHourAndMinInTotalInputTime = sTotalInputTime.split(" ");
				var iHoursTotalInputTime = parseInt(aHourAndMinInTotalInputTime[0]);
				var iMinsTotalInputTime = parseInt(aHourAndMinInTotalInputTime[2]);
				var fTotalInputTimeInHours = iHoursTotalInputTime + (iMinsTotalInputTime / 60);

				if (fTotalRequiredTimeInHours < fTotalInputTimeInHours) {
					return true;
				} else {
					return false;
				}

			},

			/**
			 * Return an array of comments objects split by new line (\n)
			 * 
			 * @return aComments is an array of Comments
			 */
			getComments: function (sComment) {
				var aComments = [];
				sComment = sComment;
				var comments = sComment ? sComment.split(Constants.COMMENTS_SEPARATOR) : "";
				$.each(comments, function (i, comment) {
					var author = "";
					var concatComments = "";
					var date = "";
					var aNewLines = comment.split(Constants.NEWLINE);
					$.each(aNewLines, function (i, newLine) {
						if (i === 0) {
							author = newLine;
						} else if (i === aNewLines.length - 1) {
							date = newLine;
						} else {
							concatComments = concatComments + Constants.NEWLINE + newLine;
						}

					});
					if (author !== "") {
						var oComment = {
							Author: author,
							Comment: concatComments,
							Date: date
						}
						aComments.push(oComment);
					}
				});
				return aComments;
			},

			/**
			 * Show the Locomotive Description in either green or gray depending on the status 
			 */
			setLocomotiveDescription: function (sDescription, sStatus) {
				if (sStatus === Constants.STATUS_SHOPPED) {
					this.addStyleClass("lmLocoListColorGray");
				} else if (sStatus === Constants.STATUS_STAGED) {
					this.addStyleClass("lmLocoListColorGreen");
				}
				return sDescription;
			},

			setVisibilityForMyWorkShop: function (sLocoStatus) {
				if (sLocoStatus === Constants.STATUS_SHOPPED) {
					return true;
				}

			},
			setVisibilityForMyWorkGroup: function (sLocoStatus) {
				if (sLocoStatus !== Constants.STATUS_SHOPPED) {
					return true;
				}

			},
			setVisibilityForOperationStatus: function (sOPStatus, aGroupedOperation, IsServicing) {

			},
			/*
			 * Function sets visibility of operation according to 
			 * status if it is planned
			 */
			setVisibilityForOperationStatusPlanned: function (sOPStatus, aGroupedOperation, IsServicing) {

				if (aGroupedOperation && aGroupedOperation.length > 0) {

					aGroupedOperation = JSON.stringify(aGroupedOperation);
					aGroupedOperation = JSON.parse(aGroupedOperation);

					var aGroupOpStatus = [];
					var aNormalGroupOpStatus = [];
					aGroupedOperation.push(jQuery.extend(true, {}, {
						Status: sOPStatus
					}));
					for (var i = 0; i < aGroupedOperation.length; i++) {
						if (IsServicing) {
							if (aGroupedOperation[i].Status === Constants.STATUS_NOT_STARTED || aGroupedOperation[i].Status === Constants.STATUS_NOT_PLANNED) {
								aGroupOpStatus.push(jQuery.extend(true, {}, {
									Status: aGroupedOperation[i].Status
								}));

							}

						} else {
							if (aGroupedOperation[i].Status === Constants.STATUS_NOT_PLANNED) {
								return false;

							}
							if (aGroupedOperation[i].Status === Constants.STATUS_NOT_STARTED) {
								aNormalGroupOpStatus.push(jQuery.extend(true, {}, {
									Status: aGroupedOperation[i].Status
								}));

							}

						}
					}
					if (aGroupOpStatus.length > 0) {
						return true;
					}
					if (aNormalGroupOpStatus.length > 0) {
						return true;
					}

					return false;
				} else {
					if (IsServicing) {
						if (sOPStatus === Constants.STATUS_NOT_STARTED || sOPStatus === Constants.STATUS_NOT_PLANNED)
							return true;
					}

					if (sOPStatus === Constants.STATUS_NOT_STARTED) {
						return true;
					}
					return false;
				}
			},

			setTextForOperationStatusPlanned: function (sLocoStatus) {

				return "Planned";

			},
			/**
			 * Sets the visibility for Combo Box in Wheel Sheet
			 * @params (string) sCodeGroup is the criteria for toggling visibility
			 */
			setVisibilityForWSCombo: function (aDDLBValues) {
				if (aDDLBValues && aDDLBValues.length > 0) {
					return true;
				}
				return false;
			},
			/**
			 * Sets the visibility for Text Area in Wheel Sheet
			 * @params (string) sCodeGroup is the criteria for toggling visibility
			 */
			setVisibilityForWSText: function (aDDLBValues) {
				if (aDDLBValues && aDDLBValues.length > 0) {
					return false;
				}
				return true;
			},

			/**
			 * Show/Hide the Blue card button for a Locomotive
			 */
			setVisibilityForBlueCard: function (sLocoStatus, bForeignLocomotive) {
				if ((sLocoStatus === Constants.STATUS_SHOPPED || sLocoStatus === Constants.STATUS_STAGED) && !bForeignLocomotive) {
					return true;
				}
				return false;
			},

			/**
			 * Show/Hide the Linq button for a Locomotive
			 */
			setVisibilityForLinq: function (sLocoStatus, bForeignLocomotive) {
				if ((sLocoStatus === Constants.STATUS_SHOPPED || sLocoStatus === Constants.STATUS_STAGED) && !bForeignLocomotive) {
					return true;
				}
				return false;
			},

			/***
			 * Sets the row selected/unselected depending if there is no WorkCenterId set for the operation
			 * during the planning
			 */
			setWOOperationSelected: function (sWorkCenterId, sCurrentWorkCenterId) {
				if (sWorkCenterId === sCurrentWorkCenterId) {
					return true;
				}
				return false;
			},
			/*sets the visibility of Wo table symptons based on the catalog status comming from oData*/
			setVisibilityForForWoSymptom: function (sCatalog, sTaskListCode) {
				if (sTaskListCode === "") {
					if (sCatalog === Constants.WO_OBJECT_SYMPTOM) {
						return true;
					}
				}
				return false;
			},
			/*sets the visibility of Wo table objects based on the catalog status comming from oData*/
			setVisibilityForForWoObject: function (sCatalog, sTaskListCode) {
				if (sTaskListCode === "") {
					if (sCatalog === Constants.WO_OBJCET_OBJECT) {
						return true;
					}
				}
				return false;
			},
			/*sets the visibility of Wo table Material based on the catalog status comming from oData*/
			setVisibilityForWoMaterial: function (sCatalog, sTaskListCode) {
				if (sTaskListCode === "") {
					if (sCatalog === Constants.WO_OBJCET_MATERIAL) {
						return true;
					}
				}
				return false;
			},

			/*sets the visibility of Wo table Task List based on the catalog status comming from oData*/
			setVisibilityForTaskList: function (sTaskListCode) {
				if (sTaskListCode !== "") {
					return true;
				}
				return false;
			},
			/*sets the visibility of Icon Tab Bar in Loco Tabs based on the status*/
			setIconTabBar: function (sLocoStatus) {
				if (sLocoStatus === Constants.STATUS_SHOPPED) {
					return Constants.WORKPLAN;
				}
				if (sLocoStatus === Constants.STATUS_INBOUND) {
					return Constants.DEFECTS;
				}
			},

			/**
			 * format availabe hrs of a craft person in assign work dialog
			 */
			formatAvailableHrsOfWorkerInAssignWork: function (sAvailHrs) {
				var fAvailHrs = parseFloat(sAvailHrs);
				if (fAvailHrs < 0) {
					return "0.00";
				} else {
					return fAvailHrs.toFixed(2);
				}
			},
			/**
			 * format visibility of availabe hrs of a craft person in assign work dialog
			 */
			formatVisibilityForAvailableHrsOfWorkerInAssignWork: function (aSelectedCraftPersonsData) {
				if (aSelectedCraftPersonsData.length === 1) { //only one craft person selected
					return true;
				} else {
					return false;
				}
			},

			/**
			 * Set title for Assign Reassign Scenario
			 */
			formatNameForSelectedWorkersInAssignWork: function (aSelectedCraftPersonsData) {
				var iNoOfSelectedCraftPersons = aSelectedCraftPersonsData.length;
				var sAssignWorkHeaderString = "";

				for (var i = 0; i < iNoOfSelectedCraftPersons - 1; i++) {
					sAssignWorkHeaderString += aSelectedCraftPersonsData[i].FirstName + " " + aSelectedCraftPersonsData[i].LastName + ", ";
				}

				if (iNoOfSelectedCraftPersons > 1) {

					sAssignWorkHeaderString = sAssignWorkHeaderString.substr(0, sAssignWorkHeaderString.length - 2);
					sAssignWorkHeaderString += " & " + aSelectedCraftPersonsData[iNoOfSelectedCraftPersons - 1].FirstName + " " +
						aSelectedCraftPersonsData[iNoOfSelectedCraftPersons - 1].LastName;

				} else if (iNoOfSelectedCraftPersons === 1) {

					sAssignWorkHeaderString += aSelectedCraftPersonsData[0].FirstName + " " + aSelectedCraftPersonsData[0].LastName;

				}
				return sAssignWorkHeaderString;
			},
			setDisableOfWS: function (sDocNum) {
				if (sDocNum) {
					return false;
				} else {
					return true;
				}
			},
			setWSTextValue: function (bStatus, sValue) {
				if (!bStatus) {
					if (sValue) {
						return Number(sValue);
					} else {
						return "";
					}
				} else {
					return "";
				}
			},
			setJornalDate: function (oDate) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: Constants.MMDDYYYY
				});
				return oDateFormat.format(oDate);
			},
			showMeasureCreation: function (bWSRequiered, sMeasurePoint) {
				if (bWSRequiered) {
					return false;
				} else {
					if (sMeasurePoint) {
						return true;
					} else {
						return false;
					}
				}
			},
			/**
			 * Set text for notification type in notification(locomotive defects) and arrive dialog
			 * @param{String} sNotificationType is the type of the notification
			 */
			setTextForNotificationTypeInDefectTab: function (sNotificationType) {
				switch (sNotificationType) {
				case "L1":
					return Constants.PREVENTATIVE_MAINTENANCE;

				case "L2":
					return Constants.CORRECTIVE_MAINTENANCE;

				case "L3":
					return Constants.ACTIVITY_REQUEST;

				case "L4":
					return Constants.MOD_PROJECT_WRECK;

				case "L5":
					return Constants.SERVICE_NOTIFICATION;

				case "L6":
					return Constants.OUT_OF_SERVICE;

				default:
					return "";
				}
			},

			/**
			 * Returns if the notification is visible in UI
			 * @param{String} sNotificationType is the type of the notification
			 * @return{boolean} true if notification have to be visible; false otherwise
			 */
			isNotificationTypeVisible: function (sNotificationType) {
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				var oVisibleNotificationTypes = oGlobalModel.getProperty("/NotificationTypes");
				if (oVisibleNotificationTypes[sNotificationType]) {
					return true;
				}
				return false;
			},

			setMPointButtonIcon: function (sLocoStatus, sMeasurementDocument, sDescription) {
				if (sLocoStatus === Constants.STATUS_COMPLETED || sMeasurementDocument) {
					return "sap-icon://show-edit";
				} else {
					return "sap-icon://create";
				}
			},

			setMPointLinkText: function (sLocoStatus, sMeasurementDocument, sDescription) {
				if (sLocoStatus === Constants.STATUS_COMPLETED || sMeasurementDocument) {
					return Constants.DISPLAY_MEASUREMENT_DOCUMENT;
				} else {
					return Constants.CREATE_MEASUREMENT_DOCUMENT;
				}
			},

			/**
			 * Formatter for the WO Type Text
			 */
			workOrderTypeFormatter: function (sWOTypeKey, aOperationSet) {
				// change the background color of the WOType
				this.addStyleClass("lmWOType" + sWOTypeKey);
				return Constants[sWOTypeKey];
			},

			/**
			 * Formatter for the Total Time color
			 * @params(oWorkOrders) oWorkOrders is the workorder object that contains all operations for that wo
			 */
			totalTimeColorFormatter: function (oWorkOrders) {
				var sTotalRequiredTime = com.sap.cp.lm.util.Formatter.craftWPTotalRequiredTime(oWorkOrders);
				var sTotalInputTime = com.sap.cp.lm.util.Formatter.craftWPTotalInputTime(oWorkOrders);

				var aHourAndMinInTotalRequiredTime = sTotalRequiredTime.split(" ");
				var iHoursTotalRequiredTime = parseInt(aHourAndMinInTotalRequiredTime[0]);
				var iMinsTotalRequiredTime = parseInt(aHourAndMinInTotalRequiredTime[2]);
				var fTotalRequiredTimeInHours = iHoursTotalRequiredTime + (iMinsTotalRequiredTime / 60);

				var aHourAndMinInTotalInputTime = sTotalInputTime.split(" ");
				var iHoursTotalInputTime = parseInt(aHourAndMinInTotalInputTime[0]);
				var iMinsTotalInputTime = parseInt(aHourAndMinInTotalInputTime[2]);
				var fTotalInputTimeInHours = iHoursTotalInputTime + (iMinsTotalInputTime / 60);

				//used in custom data to change the color of the text
				if (fTotalRequiredTimeInHours < fTotalInputTimeInHours) {
					return "red";
				} else {
					return "black";
				}
			},

			/**
			 * Formatter for the Add Operation button At Work Order Level  for left Side WorkOrders
			 */
			AddOperationAtWorkOrderLevelLeftSideFormatter: function (sLocoNumber, aOperationSet, aPer, aHashMap, sGroupId) {
				if (typeof sGroupId === "undefined") { //group id not present
					if (typeof sLocoNumber !== "undefined") {
						for (var j = 0; j < aPer.length; ++j) {
							if (aOperationSet) {
								for (var i = 0; i < aOperationSet.OperationSet.results.length; ++i) {
									if (aOperationSet.OperationSet.results[i].Status !== Constants.STATUS_COMPLETED) {
										if (aHashMap[sLocoNumber.replace(/^0+/, '') + "|" + aOperationSet.OperationSet.results[i].WorkOrderNum.replace(/^0+/, '') +
												"|" + aOperationSet.OperationSet.results[i].OperationNumber.replace(/^0+/, '') + "|" + aPer[j].PersonnelNumber.replace(
													/^0+/,
													'')] === undefined) {
											return true;
										}
									}

								}
							}
						}
						return false;
					}

				} else { //group id present
					var k = 0;
					aHashMap = this.getModel("oHashMap").getProperty("/results");
					for (var j = 0; j < aPer.length; ++j) {
						if (aOperationSet && aOperationSet.OperationSet && aOperationSet.OperationSet.results) {
							for (var i = 0; i < aOperationSet.OperationSet.results.length; ++i) {
								if (aOperationSet.OperationSet.results[i].Status !== Constants.STATUS_COMPLETED) {
									var aGroupedOperations = aOperationSet.OperationSet.results[i].GroupedOperations;
									if (aGroupedOperations && aGroupedOperations.length) {
										for (k = 0; k < aGroupedOperations.length; ++k) {

											if (aGroupedOperations[k].Id && typeof aHashMap[aGroupedOperations[k].Id.replace(/^0+/, '') + "|" + aGroupedOperations[k].WorkOrderNum
													.replace(/^0+/, '') + "|" + aGroupedOperations[k].OperationNumber.replace(/^0+/, '') + "|" + aPer[j].PersonnelNumber.replace(
														/^0+/, '')] === "undefined") {
												return true;
											}
										}
									}
								}

							}
						}
					}
					return false;
				}

			},

			/**
			 *  Formatter for the Remove Operation button At Work Order Level  for left Side WorkOrders
			 */
			RemoveOperationAtWorkOrderLevelLeftSideFormatter: function (sLocoNumber, aOperationSet, aPer, aHashMap, sGroupId) {
				if (typeof sGroupId === "undefined") { //group id not present
					if (typeof sLocoNumber !== "undefined") {

						for (var j = 0; j < aPer.length; ++j) {
							if (aOperationSet) {
								for (var i = 0; i < aOperationSet.OperationSet.results.length; ++i) {
									if (aOperationSet.OperationSet.results[i].Status !== Constants.STATUS_COMPLETED) {
										if (aHashMap[sLocoNumber.replace(/^0+/, '') + "|" + aOperationSet.OperationSet.results[i].WorkOrderNum.replace(/^0+/, '') +
												"|" + aOperationSet.OperationSet.results[i].OperationNumber.replace(/^0+/, '') + "|" + aPer[j].PersonnelNumber.replace(
													/^0+/,
													'')] === undefined) {
											return false;
										}
									}

								}
							}
						}
						return true;
					}
				} else { //group id present

					var k = 0;
					aHashMap = this.getModel("oHashMap").getProperty("/results");
					for (var j = 0; j < aPer.length; ++j) {
						if (aOperationSet && aOperationSet.OperationSet && aOperationSet.OperationSet.results) {
							for (var i = 0; i < aOperationSet.OperationSet.results.length; ++i) {
								if (aOperationSet.OperationSet.results[i].Status !== Constants.STATUS_COMPLETED) {
									var aGroupedOperations = aOperationSet.OperationSet.results[i].GroupedOperations;
									if (aGroupedOperations && aGroupedOperations.length) {
										for (k = 0; k < aGroupedOperations.length; ++k) {

											if (aGroupedOperations[k].Id && typeof aHashMap[aGroupedOperations[k].Id.replace(/^0+/, '') + "|" + aGroupedOperations[k].WorkOrderNum
													.replace(/^0+/, '') + "|" + aGroupedOperations[k].OperationNumber.replace(/^0+/, '') + "|" + aPer[j].PersonnelNumber.replace(
														/^0+/, '')] === "undefined") {
												return false;
											}
										}
									}
								}

							}
						}
					}
					return true;

				}
			},

			/**
			 * Formatter for loclization of the Role Description
			 */
			roleDescriptionFormatter: function (sDescription) {
				var i18n = com.sap.cp.lm.util.Formatter._oComponent.getModel("i18n");
				return i18n.getProperty(sDescription);
			},

			/**
			 * Formatter for the Group notification count which will display Count of Grouped Wo
			 * @iCount : Checks if group id is present sets visibility to true
			 */
			setVisibilityForCount: function (iCount) {
				if (iCount) {
					return true;
				}
				return false;
			},

			/**
			 * Formatter for the Group notification count how many Grouped Wo exists
			 * @iCount : Checks if groupItemSet/results has more than 2 grouped work orders
			 */
			setGroupedItems: function (groupItemSet) {
				if (groupItemSet) {
					if (groupItemSet.length) {
						var groupedItems = groupItemSet.length
						return groupedItems;
					}
				}
				return 0;
			},

			/**
			 * set visibility for servicing group workorder
			 * @param(oServicingData) oServicingData is the data for the servicing work order
			 */
			setVisibilityForServicingWO: function (oServicingData) {
				if (oServicingData.OperationSet) {
					if (oServicingData.OperationSet.results) {
						if (oServicingData.OperationSet.results.length > 0) {
							return true;
						}
					}
				}
				return false;
			},

			/**
			 * Formatter for the revision type to the revision description
			 */
			revisionTypeFormatter: function (sRevisionType, oRevisionTypeModel) {
				if (oRevisionTypeModel) {
					var revisionTypeList = oRevisionTypeModel.results;
					for (var i = 0; i < revisionTypeList.length; i++) {
						if (sRevisionType === revisionTypeList[i].Type) {
							var descriptionFormatted = revisionTypeList[i].Description.substr(7, revisionTypeList[i].Description.length);
							return descriptionFormatted;
						}
					}
				}
			},

			/**
			 * Formatter for the locomotive type to the type description
			 */
			locomotiveTypeFormatter: function (sLocomotiveType, oLocomotiveTypeModel) {
				if (oLocomotiveTypeModel) {
					var locomotiveTypeList = oLocomotiveTypeModel.getData().results;
					for (var i = 0; i < locomotiveTypeList.length; i++) {
						if (sLocomotiveType === locomotiveTypeList[i].Type) {
							return locomotiveTypeList[i].Description;
						}
					}
				}
			},

			// TODO: remove everything about VE

			/**
			 * show single eye to represent 1 VE document
			 */
			showSingleVEEye: function (aVEDocumentHeader) {
				if (aVEDocumentHeader && aVEDocumentHeader.results && aVEDocumentHeader.results.length == 1) {
					this.data("oVEDocumentHeader", aVEDocumentHeader.results[0]);
					return true;
				}
				return false;
			},

			/**
			 * show multiple eyes to represent many VE documents
			 */
			showMultipleVEEye: function (aVEDocumentHeader) {
				if (aVEDocumentHeader && aVEDocumentHeader.results && aVEDocumentHeader.results.length > 1) {
					this.data("aVEDocumentHeader", aVEDocumentHeader.results);
					return true;
				}
				return false;
			},
			/**
			 * show eyes to represent single VE document for Structure
			 */
			showSingleVEEyeStruct: function (stId) {
				if (stId != null) {
					if (stId.charAt(stId.length - 1) == "A") {
						return true;
					}
				}
				return false;
			},
			/**
			 * show eye to represent multiple VE document for Structure
			 */
			showMultipleVEEyeStruct: function (stId) {
				if (stId != null) {
					if (stId.charAt(stId.length - 1) == "X") {
						return true;
					}
				}
				return false;
			},
			/*
			 * Function Sets Visibility for Spot link within the dialog of
			 * the map view when we click on locomotive.
			 */
			setVisibilityForSpotLink: function (sMode, sRole) {
				if (sMode && sMode === Constants.MYPLAN) {
					return false;
				} else if (sRole && ((sRole === Constants.ROLE.CRAFT) || (sRole === Constants.ROLE.LEADMAN))) {
					return false;
				} else {
					return true;
				}
			},

			/*
			 * Function Sets Visibility for Spot text within the dialog of
			 * the map view when we click on locomotive.
			 */
			setVisibilityForSpotText: function (sMode, sRole) {
				if (sMode && sMode === Constants.MYPLAN) {
					return true;
				} else if (sRole && ((sRole === Constants.ROLE.CRAFT) || (sRole === Constants.ROLE.LEADMAN))) {
					return true;
				} else {
					return false;
				}
			},

			/*
			 * Function Sets Visibility for Revision Type link
			 */
			setVisibilityForRevisionTypeLink: function (sValue, sRole) {
				if (sRole === Constants.ROLE.CRAFT) {
					return false;
				} else if (sValue && sValue != Constants.STATUS_SHOPPED) {
					return false;
				} else {
					return true;
				}
			},

			/*
			 * Function Sets Visibility for  Revision Type text
			 */
			setVisibilityForRevisionTypeText: function (sValue, sRole) {
				if (sRole === Constants.ROLE.CRAFT) {
					return true;
				} else if (sValue && sValue != Constants.STATUS_SHOPPED) {
					return true;
				} else {
					return false;
				}
			},
			/*
			 * Function Sets button enable for  carft role
			 */
			setEnabledForCraft: function (sRole) {
				if (sRole === Constants.ROLE.CRAFT) {
					return false;
				} else {
					return true;
				}
			},
			/*
			 * Function Sets button visibility for  arrive button
			 */
			setVisibilityForArrive: function (sLocoStatus, staged, sRole) {
				if (sRole != Constants.ROLE.CRAFT) {
					if (sLocoStatus === Constants.STATUS_INBOUND || sLocoStatus === Constants.STATUS_PTA) {
						return true;
					} else {
						return false;
					}
				}
				return false;
			},
			/*
			 * Function Sets button visibility for  LHFM label
			 */
			setVisibilityForLHFM: function (LHFMStatus) {
				if (LHFMStatus === "LH") {
					return true;
				} else {
					return true;
				}

			},
			/*
			 * Function Sets button visibility for  servicng group button
			 */
			setVisibilityForServicingGroup: function (selectedTab, sRole) {
				if (sRole === Constants.ROLE.CRAFT) {
					return false;
				}
				if (selectedTab === Constants.SERVICING) {
					return true;
				} else {
					return false;
				}
			},
			/*
			 * Function Sets button visibility for set lhfm group button
			 */
			setVisibilityForLhfmGroup: function (aGroup) {
				for (var i in aGroup) {
					if (!aGroup[i].WorkOrder.Lhfm) {
						return true;
					}
				}
				return false;

			},
			/*
			 * Function Sets button visibility for set undo group button
			 */
			setVisibilityForNotLhfmGroup: function (aGroup) {
				for (var i in aGroup) {
					if (!aGroup[i].WorkOrder.Lhfm) {
						return false;
					}
				}
				return true;

			},

			setMaxWidthOperationText: function (bReg, bOverDue) {
				if (bReg & bOverDue) {
					this.addStyleClass("operationTextWithRegAndOverDue");
				} else if (bReg) {
					this.addStyleClass("operationTextWithReg");
				} else if (bOverDue) {
					this.addStyleClass("operationTextWithOverDue");
				} else {
					this.addStyleClass("operationText");
				}
				return 100;
			},

			setMaxWidthTaskText: function (bReg) {
				if (bReg) {
					this.addStyleClass("operationTextWithReg");
				}
				return 100;
			},

			/*
			 * Function Sets  visibility for hasOverDueOps at Work Order level
			 */
			setVisibilityForHasOverdueWO: function (hasOverdueOps, GroupItemSet, sParentViewName) {
				if (!GroupItemSet) {
					return hasOverdueOps;
				} else {
					for (var i in GroupItemSet) {
						if (!GroupItemSet[i].WorkOrder.hasOverdueOps) {
							return false;
						}
					}
				}
				return true;
			},

			/*
			 * Function Sets  visibility  for  lhfm at wo level
			 */
			setVisibilityForlhfmGroupWO: function (Lhfm, GroupItemSet, LHFMTemp) {

				if (!GroupItemSet) {
					return Lhfm;
				} else {
					for (var i in GroupItemSet) {
						if (!GroupItemSet[i].WorkOrder.Lhfm) {
							return false;
						}
					}
				}

				return true;

			},
			/*
			 * Function returns the month date text
			 */
			setShiftMonthDayText: function (StartDateTime, Currentshift) {
				var monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
				if (StartDateTime) {
					StartDateTime = new Date(StartDateTime);
					var monthindex = StartDateTime.getMonth();
					var month = monthNames[monthindex];
					var date = StartDateTime.getDate();
					if (Currentshift && Currentshift !== null) {
						if (Currentshift.StartDateTime.getMonth() === StartDateTime.getMonth() && Currentshift.StartDateTime.getDate() === StartDateTime
							.getDate() &&
							Currentshift.StartDateTime.getYear() === StartDateTime.getYear() && Currentshift.StartDateTime.getHours() === StartDateTime.getHours()
						) {
							this.addStyleClass("currentShiftColor");
							return "Current Shift"
						} else {
							return month + " " + date;
						}
					} else {
						return month + " " + date;
					}
				} else {
					return false;
				}

			},

			/*
			 * Function to set visibilty for trackspot link or text in workplan
			 */
			setVisibiltyForTrackSpotTextOrLinkInWorkPlan: function (StartDateTime, Currentshift, sControlType) {
				if (sControlType === Constants.TEXT) {
					if (StartDateTime >= Currentshift.StartDateTime) {
						return false;
					}
					return true;
				} else {
					if (StartDateTime >= Currentshift.StartDateTime) {
						return true;
					}
					return false;
				}
			},

			/*
			 * Disable trackspot link if out of the period
			 */
			checkSecondSpotLinkValidity: function (StartDateTime, ReleaseDateTime) {
				var dDateTime = new Date(StartDateTime);
				dDateTime.setTime(dDateTime.getTime() + (4 * 60 * 60 * 1000));
				if (ReleaseDateTime <= dDateTime) {
					//this.setEnabled(false);
					return false;
				}
				//this.setEnabled(true);
				return true;
			},

			/*
			 * Function returns the shift time
			 */
			setShiftTime: function (StartDateTime, EndDateTime) {
				if (StartDateTime && EndDateTime) {
					StartDateTime = new Date(StartDateTime);
					EndDateTime = new Date(EndDateTime);
					var startShiftHour = ('0' + StartDateTime.getHours()).substr(-2);
					var startShiftMin = ('0' + StartDateTime.getMinutes()).substr(-2);
					var endShiftHour = ('0' + EndDateTime.getHours()).substr(-2);
					var endShiftMin = ('0' + EndDateTime.getMinutes()).substr(-2);

					return startShiftHour + ":" + startShiftMin + " - " + endShiftHour + ":" + endShiftMin;
				} else {
					return "";
				}
			},

			/*
			 * Helper Function to return the shift time 
			 */
			_getShiftTrackSpot: function (oLink, sSpotCode, oShiftStartDate, oShiftEndDate, iIndex, sLocomotiveNumber) {
				var oComponent = com.sap.cp.lm.util.Formatter.getComponent();
				var oGlobalModel = oComponent.getGlobalModel();
				var oSpotSet = oGlobalModel.getProperty("/SpotWorkCenterSet");
				var oCurrentShift = oGlobalModel.getProperty("/currentShift");
				if (sSpotCode) {
					var oSpot;
					if (oCurrentShift.StartDateTime >= oShiftStartDate && oCurrentShift.EndDateTime <= oShiftEndDate) {
						// current shift get the spot information from the locomotive model
						var oGlobalLocmotiveModel = oComponent.getGlobalLocomotiveModel();
						var oLocomotive = oGlobalLocmotiveModel.getData()[sLocomotiveNumber];
						var sTrackspot = oLocomotive ? oLocomotive.WorkCenterId : null;
						oSpot = sTrackspot ? oSpotSet[sTrackspot] : null
					} else {
						oSpot = oSpotSet[sSpotCode.split(Constants.GROUP_SEPERATOR)[iIndex]];
					}
					if (oSpot) {
						return oSpotTrack + "-" + oSpot.Spot;
					}
				}
				return "";
			},

			/*
			 * Check if the ShiftStart and ShiftEnd datetime relies within the current shift
			 */
			isShiftCurrentShift: function (oShiftStartDate, oShiftEndDate) {
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				var oCurrentShift = oGlobalModel.getProperty("/currentShift");
				if (oShiftStartDate >= oCurrentShift.StartDateTime && oCurrentShift.EndDateTime.getTime() == oShiftEndDate.getTime()) {
					//first shift is current shift
					return true;
				} else if (oCurrentShift.StartDateTime.getTime() == oShiftStartDate.getTime() && oShiftEndDate <= oCurrentShift.EndDateTime) {
					//last shift is current shift
					return true;
				} else if (oCurrentShift.StartDateTime >= oShiftStartDate && oCurrentShift.EndDateTime <= oShiftEndDate) {
					return true;
				}
				return false;
			},

			/*
			 * Function to return the first shift time 
			 */
			getShiftTrackSpot1: function (sSpotCode, oShiftStartDate, oShiftEndDate, sLocomotiveNumber) {
				oShiftStartDate = new Date(oShiftStartDate);
				oShiftEndDate = new Date(oShiftEndDate);
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				var oSpotSet = oGlobalModel.getProperty("/SpotWorkCenterSet");
				var oCurrentShift = oGlobalModel.getProperty("/currentShift");
				var oCurrentRole = oGlobalModel.getProperty("/role");

				if (com.sap.cp.lm.util.Formatter.isShiftCurrentShift(oShiftStartDate, oShiftEndDate)) {
					this.setVisible(true);
					if (this.setEnabled && oCurrentRole === Constants.ROLE.CRAFT) {
						this.setEnabled(false);
					}
				} else if (this.setEnabled && oCurrentRole != Constants.ROLE.PLANNER) {
					this.setEnabled(false);
				}
				return com.sap.cp.lm.util.Formatter._getShiftTrackSpot(this, sSpotCode, oShiftStartDate, oShiftEndDate, 0, sLocomotiveNumber);
			},

			/*
			 * Function to return the last shift time 
			 */
			getShiftTrackSpot2: function (sSpotCode, oShiftStartDate, oShiftEndDate) {
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				var oSpotSet = oGlobalModel.getProperty("/SpotWorkCenterSet");
				var oCurrentShift = oGlobalModel.getProperty("/currentShift");
				oShiftStartDate = new Date(oShiftStartDate);
				oShiftEndDate = new Date(oShiftEndDate);
				var oCurrentRole = oGlobalModel.getProperty("/role");

				if (com.sap.cp.lm.util.Formatter.isShiftCurrentShift(oShiftStartDate, oShiftEndDate)) {
					this.setVisible(false);
					if (this.setEnabled && oCurrentRole === Constants.ROLE.CRAFT) {
						this.setEnabled(false);
					}
				} else if (this.setEnabled && oCurrentRole != Constants.ROLE.PLANNER) {
					this.setEnabled(false);
				}

				if (sSpotCode) {
					var aTrackSpots = sSpotCode.split("|");
					return com.sap.cp.lm.util.Formatter._getShiftTrackSpot(this, sSpotCode, oShiftStartDate, oShiftEndDate, aTrackSpots.length - 1);
				}
				return "";
			},

			/**
			 * Sets the visibility for EditButton in Link PopOver
			 * @params (string) oDeletable is the criteria for toggling visibility
			 */
			setVisibilityForEditDeleteButton: function (oDeletable) {
				if (!oDeletable) {
					return false;
				}
				return true;
			},

			//LMP2-29 : Setting the visibility of the Apply_To_Servgr check boxIt should be visible only from
			// the servicing group
			setVisibilityForApplyToServgGr: function () {
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				if (oGlobalModel.getProperty("/sSelectedView") === Constants.MYWORK) {
					return false;
				}
				//logic to display the Apply to ServGr checkbox for the servicing group only and not for 
				//the individual locos on the servicing tab
				var aServGroup = oGlobalModel.getProperty("/ServiceGroupList");
				if (!aServGroup) {
					return false;
				}

				return true;
			},
			/**
			 * Set the drop down shift Track and Spot information
			 */
			_shiftTrackSpot: function (sTrackSpots, bCurrentShift) {
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				var oSpotSet = oGlobalModel.getProperty("/SpotWorkCenterSet");
				var aSpots = sTrackSpots.split(Constants.GROUP_SEPERATOR);
				var sSpot = "";
				$.each(aSpots, function (i, spot) {
					if (i != 0) {
						sSpot = sSpot + ",";
					} else {
						sSpot = sSpot + "(";
					}
					var oSpot = oSpotSet[spot];
					sSpot = oSpot ? sSpot + oSpotTrack + "-" + oSpot.Spot : sSpot;
					if (bCurrentShift) {
						return false;
					}
				});
				return sSpot + ")";
			},

			/**
			 * Sets the dropdown shift data  for replan dialog
			 * @params (StartDateTime) is the start time of the shift
			 * @params (EndDateTime) is the end time of the shift
			 * @params (TrackSpot) is the spot of the shift
			 */
			setShiftTimeTrackForPlan: function (StartDateTime, EndDateTime, TrackSpot, Currentshift) {
				var monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
				if (StartDateTime && EndDateTime) {
					StartDateTime = new Date(StartDateTime);
					EndDateTime = new Date(EndDateTime);
					var startShiftHour = ('0' + StartDateTime.getHours()).substr(-2);
					var startShiftMin = ('0' + StartDateTime.getMinutes()).substr(-2);
					var endShiftHour = ('0' + EndDateTime.getHours()).substr(-2);
					var endShiftMin = ('0' + EndDateTime.getMinutes()).substr(-2);
					var startDateMonth = StartDateTime.getMonth();
					var startDate = StartDateTime.getDate();
					var sSpot;
					if (Currentshift && Currentshift !== null) {
						var dCurrentStartDateTime = Currentshift.StartDateTime;
						if (typeof Currentshift.StartDateTime === "string") {
							dCurrentStartDateTime = new Date(Currentshift.StartDateTime);
						}
						if (dCurrentStartDateTime.getMonth() === StartDateTime.getMonth() && dCurrentStartDateTime.getDate() === StartDateTime.getDate() &&
							dCurrentStartDateTime.getYear() === StartDateTime.getYear() && dCurrentStartDateTime.getHours() === StartDateTime.getHours()) {
							sSpot = com.sap.cp.lm.util.Formatter._shiftTrackSpot(TrackSpot, true);
							//						this.addStyleClass("lmCurrentShiftColor");
							return "Current Shift " + startShiftHour + ":" + startShiftMin + " - " + endShiftHour + ":" + endShiftMin + "   " + sSpot;
						} else {
							sSpot = com.sap.cp.lm.util.Formatter._shiftTrackSpot(TrackSpot, false);
							return monthNames[startDateMonth] + " " + startDate + " " + startShiftHour + ":" + startShiftMin + " - " + endShiftHour + ":" +
								endShiftMin + "   " + sSpot;
						}
					}
				} else {
					return "";
				}
			},
			/**
			 * Sets the count of task
			 * @params (sRole) is the Current role
			 */
			setTaskValue: function (TaskSet) {
				// return TaskSet.length;
				var ilength = TaskSet.length.toString();
				var iCounter = 0;
				TaskSet.forEach(function (oItem) {
					if (oItem.Status === "0") {
						iCounter++;
					}
				});
				return iCounter + "/" + ilength;
			},

			/**
			 * Sets the visibility for plan button according to role
			 * @params (sRole) is the Current role
			 */
			setVisibilityForReplanUnplan: function (sLocoStatus, sRole) {
				if (sRole !== Constants.ROLE.CRAFT && sLocoStatus === Constants.STATUS_SHOPPED) {
					return true;
				} else {
					return false;
				}
			},
			/**
			 * Sets the Span for layout according to role
			 * @params (sRole) is the Current role
			 */
			setSpanForText: function (sRole) {
				if (sRole === Constants.ROLE.SUPERVISOR || sRole === Constants.ROLE.LEADMAN) {
					return "L5 M5 S5";
				}
				return "L6 M6 S6";
			},
			/**
			 * Sets the Span for layout according to role
			 * @params (sRole) is the Current role
			 */
			setSpanForHBox: function (sRole) {
				if (sRole === Constants.ROLE.SUPERVISOR || sRole === Constants.ROLE.LEADMAN) {
					return "L7 M7 S7";
				}
				return "L6 M6 S6";
			},
			/**
			 * Set visibility for Undo Arrive button
			 */
			setVisibilityForUndo: function (sLocoStatus, staged, sRole) {
				if (sRole === Constants.ROLE.PLANNER || sRole === Constants.ROLE.SUPERVISOR || sRole === Constants.ROLE.LEADMAN) {
					if (sLocoStatus === Constants.STATUS_SHOPPED) {
						return true;
					}
				}
				return false;
			},

			/**
			 * Check if the operation is assigned to the user provided
			 */
			isOperationAssignedToMe: function (aAssignmentSet, sPersonnelNumber) {
				for (var i = 0; i < aAssignmentSet.length; i++) {
					var oAssignment = aAssignmentSet[i];
					if (oAssignment.PersonnelNumber === sPersonnelNumber) {
						return true
					}
				}
				return false;
			},
			/**
			 * Check if the WS is in current mode in Wheelsheet History
			 */
			setCurrentDateinWS: function (oDate, sCertifiedBy, isWSCreated) {
				var i18n = com.sap.cp.lm.util.Formatter._oComponent.getModel("i18n");
				if (sCertifiedBy === "") {
					this.addStyleClass("WSCurrent");
					return i18n.getProperty("ACTIVE");
				} else if (oDate && jQuery.type(oDate) === "date") {
					var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
						pattern: "MM/dd/yyyy HH:mm "
					});
					return oDateFormat.format(oDate);
				}
			},
			/**
			 * set the action and its name
			 */
			setActioninWSHistory: function (oDate, isWSCreated) {
				var i18n = com.sap.cp.lm.util.Formatter._oComponent.getModel("i18n");
				if (!oDate) {
					return i18n.getProperty("EDIT");
				} else {
					return i18n.getProperty("VIEW");
				}
			},

			/**
			 * set the visibility of WS import button 
			 * @params (WSScenario) is the WS Scenario
			 * @paras (WSActive)  is either Final or Initial
			 */
			setVisibilityForWSImport: function (WSScenario, WSActive, bEnabled) {
				if (WSScenario === "IE") {
					return bEnabled;
				}
				return false;
			},
			/**
			 * set the visibility of WS import to wheelsheet button 
			 * @params (WSScenario) is the WS Scenario
			 * @paras (WSActive)  is either Final or Initial
			 */
			setVisibilityForWSImportToWheelSheet: function (WSScenario, WSActive) {
				if (WSScenario === "EWG") {
					return true;
				}
				return false;
			},
			/**
			 * set the visibility of save and submit button in ws
			 * @params (WSScenario) is the WS Scenario
			 * @paras (WSActive)  is either Final or Initial
			 */
			setVisibilityForWSSaveAndSubmit: function (WSScenario, WSActive, bEnabled) {
				if (WSScenario === "IE") {
					return bEnabled;
				}
				if (WSScenario === "FE") {
					if (WSActive === "Initial") {
						return false;
					} else {
						return true;
					}

				}

				return false;

			},
			/**
			 * set the visibility of initial or final switch in ws
			 * @params (WSScenario) is the WS Scenario
			 */
			setVisibilityForWSInitialOrFinalSwitch: function (WSScenario) {
				if (WSScenario === "FE" || WSScenario === "H") {
					return true;
				}
				return false;
			},

			/**
			 * set the text of WS dialog Header
			 * @params (WSScenario) is the WS Scenario
			 * @paras (WSActive)  is either Final or Initial
			 */
			setWSHeaderText: function (WSScenario, WSActive) {
				var i18n = com.sap.cp.lm.util.Formatter._oComponent.getModel("i18n");
				if (WSScenario === "EWG") {
					return i18n.getProperty("MEASUREMENT_PREVIEW");
				}
				if (WSActive === "Final") {
					return i18n.getProperty("FINAL_WHEELSHEET");
				} else {
					return i18n.getProperty("INITIAL_WHEELSHEET");
				}

			},
			setVisibilityForGE: function (sRole, View, URL) {
				if (URL != "") {
					return true;
				}
				return false;
			},
			showTaskDesc: function () {

				var aGroupedOperations = "";
				if (this.getBindingContext().sPath && this.getBindingContext().sPath.split("/TaskSet")[0] && this.getModel().getProperty(this.getBindingContext()
						.sPath.split("/TaskSet")[0])) {
					aGroupedOperations = JSON.stringify(this.getModel().getProperty(this.getBindingContext().sPath.split("/TaskSet")[0]).GroupedOperations);
				}

				if (aGroupedOperations && aGroupedOperations.length > 0) {
					aGroupedOperations = JSON.parse(aGroupedOperations);
					if ((this.getBindingContext().sPath.split("/TaskSet/results/")[1] % (aGroupedOperations.length + 1)) === 0) {
						return true;
					} else {
						this.getParent().getParent().addStyleClass("lmTopBorder");
						this.getParent().addStyleClass("lmTopBorder");
						return false;
					}
				} else {
					return true;
				}

			},
			
			// Start- SHE0272 - INC0110700 - Custom method to get the data based on the global model
			customShowTaskDesc: function () {

				var aGroupedOperations = "";
				if (this.getBindingContext("global").sPath && this.getBindingContext("global").sPath.split("/TaskSet")[0] && this.getModel("global").getProperty(this.getBindingContext("global")
						.sPath.split("/TaskSet")[0])) {
					aGroupedOperations = JSON.stringify(this.getModel("global").getProperty(this.getBindingContext("global").sPath.split("/TaskSet")[0]).GroupedOperations);
				}

				if (aGroupedOperations && aGroupedOperations.length > 0) {
					aGroupedOperations = JSON.parse(aGroupedOperations);
					if ((this.getBindingContext("global").sPath.split("/TaskSet/results/")[1] % (aGroupedOperations.length + 1)) === 0) {
						return true;
					} else {
						this.getParent().getParent().addStyleClass("lmTopBorder");
						this.getParent().addStyleClass("lmTopBorder");
						return false;
					}
				} else {
					return true;
				}

			},
			// End - SHE0272 - INC0110700 - Custom method to get the data based on the global model

			/**
			 * Set values for Operation  Number & Task Number
			 */
			setValueForOpAndTaskNumber: function (sWOorOporTaskNumber) {

				return com.sap.cp.lm.util.Formatter.removeLeadingZeroes(sWOorOporTaskNumber);

			},

			/**
			 * Return setValueForOpAndTaskNumber() as a String
			 */
			setValueForOpAndTaskNumberAsString: function (sWOorOporTaskNumber) {
				return String(com.sap.cp.lm.util.Formatter.setValueForOpAndTaskNumber(sWOorOporTaskNumber));
			},

			/**
			 * function to remove leading zeroes
			 */
			removeLeadingZeroes: function (sWOorTaskNumber) {
				if (sWOorTaskNumber)
					return sWOorTaskNumber.replace(/^0+/, '');
			},

			/**
			 * Setting Visibility for Operation Number or Task Number
			 */
			setVisibleAndWidthForOpAndTaskNumber: function (bShowTechInfo, sParentViewName) {
				//var oGlobalModel = com.sap.mdc.bnsf.locomotivemaintenance.util.Formatter.getComponent().getGlobalModel();
				if (bShowTechInfo) {

					/*this.getModel("viewProperties").setProperty("/OperationNumber/visible", true);
					this.getModel("viewProperties").setProperty("/OperationNumber/width", "8.5%");
					this.getModel("viewProperties").setProperty("/Operation/width", "31.5%");
					this.getModel("viewProperties").setProperty("/TaskDescription/width", "36.5%");*/

					return true;
				}
				return false;
			},

			/**
			 * function to set Status Visibility for an Operation
			 */
			setVisibilityForStatusInMyShop: function (sOperationStatus) {
				if (sOperationStatus === Constants.STATUS_IN_PROGRESS || sOperationStatus === Constants.STATUS_COMPLETED || sOperationStatus ===
					Constants.STATUS_NOT_PLANNED || sOperationStatus === Constants.STATUS_NOT_STARTED) {
					return true;
				}
			},

			/**
			 * function to set Status Text for an Operation
			 */
			setOperationStatusInMyShop: function (sStatus, aTaskSet, aGroupedOperation) {
				/* KIR0084 LMP2-35 */
				var statusText = com.sap.cp.lm.util.Formatter._getOperationStatusText(sStatus, this);

				if (this.addStyleClass) {
					if (statusText === Constants.TEXT_COMPLETE) {
						this.addStyleClass("lmTagCompleted");
					} else {
						this.removeStyleClass("lmTagCompleted");
					}
				}

				return statusText;
				/* KIR0084 LMP2-35 */
			},

			_getOperationStatusText: function (sStatus, oControl) {
				if (sStatus === Constants.STATUS_COMPLETED) {
					return Constants.TEXT_COMPLETE;
				} else if (sStatus === Constants.STATUS_IN_PROGRESS) {
					return Constants.TEXT_INPROGRESS;
				} else if (sStatus === Constants.STATUS_NOT_PLANNED) {
					return Constants.TEXT_NOTPLANNED;
				} else if (sStatus === Constants.STATUS_NOT_STARTED) {
					return Constants.TEXT_NOT_STARTED;
				}
				return "";
			},

			setVisibleAddToWork: function (sShopGroup, oLocomotive) {
				// SHE0272 - Start - LLM2.3 - Add Orders in Service Tab -  Commented shop reason
				// if (sShopGroup && sShopGroup === 3 && oLocomotive.ShopStatus === "S" && oLocomotive.ShopReason === "M") {
				// 	return true;
				// }
				if (sShopGroup && sShopGroup === 3 && oLocomotive && oLocomotive.ShopStatus === "S") {
					return true;
				}
				// SHE0272 - End - LLM2.3 - Add Orders in Service Tab -  Commented shop reason
				return false;
			},

			setVisibleAddPlan: function (sShopGroup) {
				if (sShopGroup && sShopGroup === 2) {
					return true;
				}
				return false;
			},

			setVisibleIncidentNumber: function (sDefectType) {
				if (sDefectType === "Z2") {
					return true;
				}
				return false;
			},

			setVisibleDeferDefect: function (sShopGroup) {
				if (sShopGroup && sShopGroup === 1) {
					return true;
				}
				return false;
			},

			trackSpot: function (oLocomotive) {
				if (oLocomotive) {
					var dir = "North";
					if (oLocomotive.Direction === "S") {
						dir = "South";
					}
					if (oLocomotive.Direction === "E") {
						dir = "East";
					}
					if (oLocomotive.Direction === "W") {
						dir = "West";
					}

					return oLocomotive.Track + " - " + oLocomotive.Spot + " [" + dir + "]";
				}

				return "* - *";
			},

			/*
			 * Function sets Text attribute of the Plan Link object
			 */
			setPlanLinkText: function (sOperationStatus, oDate, aGroupOpeartions) {
				var oOperation = this.getBindingContext().getObject();
				sOperationStatus = com.sap.cp.lm.util.Formatter._getUpdatedOperationStatus(oOperation.CompletedTasks,
					oOperation.TotalTasks, sOperationStatus);
				if (sOperationStatus === Constants.STATUS_NOT_PLANNED) {
					var i18n = com.sap.cp.lm.util.Formatter._oComponent.getModel("i18n");
					return i18n.getProperty("PLAN");
				} else {
					return com.sap.cp.lm.util.Formatter.changeDateFormatMMDDHHmm(oDate, aGroupOpeartions);
				}

			},

			/**
			* Get the Updated Operation Status according to the Tasks visible in the UI
			*   If TotalTasks = 0, then you can rely on the backend status field of the operation.
			•   If TotalTasks > 0 and CompletedTasks = 0, then you can rely on backend status field of operation
			•   If TotalTasks > 0 and 0 < CompletedTasks < TotalTasks, then the status is In Progress
			•   If TotalTasks > 0 and CompletedTasks = TotalTasks, then the status is Completed.
			*/
			_getUpdatedOperationStatus: function (iCompletedTasks, iTotalTasks, sOperationStatus) {
				var sUICalculatedOperationStatus = sOperationStatus;
				if (iTotalTasks > 0 && 0 < iCompletedTasks && iCompletedTasks < iTotalTasks) {
					// TotalTasks > 0 and 0 < CompletedTasks < TotalTasks Status In Progress
					sUICalculatedOperationStatus = Constants.STATUS_IN_PROGRESS;
				} else if (iTotalTasks > 0 && iCompletedTasks === iTotalTasks) {
					// TotalTasks > 0 and CompletedTasks = TotalTasks Status Completed
					sUICalculatedOperationStatus = Constants.STATUS_COMPLETED;
				}
				return sUICalculatedOperationStatus;
			},

			formatTime: function (oTime) {
				if (oTime) {
					var oMilliSeconds = oTime.valueOf("ms").ms;

					return com.sap.cp.lm.util.Formatter.changeTimeFormat(oMilliSeconds);
				}

			},

			returnDateObject: function (oDate) {
				return new Date(oDate);
			},

			setVisibleVisitDetails: function (sShopStatus) {

				if (sShopStatus === "S" || sShopStatus === "R") {
					return true;
				}

				return false;
			},

			setVisibilityServiceGroupLocoId: function (oDetailsdata) {

				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();

				if (Constants.LOCOMOTIVES === oGlobalModel.getProperty("/sSelectedView") && oGlobalModel.getProperty("/currentServiceLocomotive")) {
					if (oGlobalModel.getProperty("/currentServiceLocomotive").isServiceGroupSelected) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
			},

			setVisibilityServiceGroupButton: function (oDetailsdata) {
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();

				var org = oGlobalModel.getProperty("/fleetDetailsOrigin");

				if (org && org === "servicingGroupWorkPlan") {
					return false;
				}

				if (Constants.LOCOMOTIVES === oGlobalModel.getProperty("/sSelectedView") && oGlobalModel.getProperty("/currentServiceLocomotive")) {
					if (oGlobalModel.getProperty("/currentServiceLocomotive").isServiceGroupSelected) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
			},

			setVisibilityEndWorkButton: function (isServicing) {
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				if (isServicing) {
					return true;
				}
				if (oGlobalModel.getProperty("/sSelectedView") === Constants.MYWORK) {
					return true;
				} else {
					return false;
				}
			},

			setOperationsListType: function () {
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				if (oGlobalModel.getProperty("/sSelectedView") === Constants.MYWORK) {
					return "Navigation";
				}
			},
			setVisibilitynonServiceGroup: function () {
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				if (oGlobalModel.getProperty("/readOnlyWorkPlan") === true) {
					return false;
				}

				if (Constants.LOCOMOTIVES === oGlobalModel.getProperty("/sSelectedView") && oGlobalModel.getProperty("/currentServiceLocomotive")) {
					return false;
				} else {
					return true;
				}
			},
			isReadOnlyWorkPlan: function () {
				var bResult = true;
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				if (oGlobalModel.getProperty("/readOnlyWorkPlan") === true) {
					bResult = false;
				}
				return bResult;
			},

			// Start : Added by Sandhya : LMP2-3 : Work order History and Notification History
			isReadFromWOHistory: function () {
				var bResult = false;
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				if (oGlobalModel.getProperty("/readFromWOHistory") === true) {
					bResult = true;
				}
				return bResult;
			},

			isReadFromWorkPlan: function () {
				var bResult = false;
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				if (oGlobalModel.getProperty("/readFromWorkPlan") === true) {
					bResult = true;
				}
				return bResult;
			},
			// End : Added by Sandhya : LMP2-3 : Work order History and Notification History
			//Added by SAndhya : 3D
			is3dlocodet: function (sABC) {
				var bResult = false;
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				if (oGlobalModel.getProperty("/3dlocodet") === true) {
					bResult = true;
				}
				return bResult;
			},

			is3dlocochar: function (sABC) {
				var bResult = false;
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				if (oGlobalModel.getProperty("/3dlocochar") === true) {
					bResult = true;
				}
				return bResult;
			},
			//End:Added by SAndhya : 3D
			/*hideWorkPlanHeader: function(odetailsdata) {
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				if (Constants.LOCOMOTIVES === oGlobalModel.getProperty("/sSelectedView") && oGlobalModel.getProperty("/currentServiceLocomotive")) {
					if (oGlobalModel.getProperty("/currentServiceLocomotive").isServiceGroupSelected) {
						return false;
					} else {
						return true;
					}
				}
			},*/

			formatCraftWorkerHoursPlanned: function (sAssignedWorkHrs, sAvailableWork) {
				var fAssignedWorkHrs = (sAssignedWorkHrs * 1);
				var fAvailableWork = (sAvailableWork * 1);

				var i18n = com.sap.cp.lm.util.Formatter._oComponent.getModel("i18n");

				var sFormatted = fAssignedWorkHrs.toString() + " / " + fAvailableWork.toString() + " " + i18n.getProperty("HOURS_PLANNED");

				if (fAssignedWorkHrs >= fAvailableWork) {
					this.removeStyleClass("lmColorLightBlue");
					this.addStyleClass("lmColorRed");
				} else {
					this.removeStyleClass("lmColorRed");
					this.addStyleClass("lmColorLightBlue");
				}

				return sFormatted;
			},

			formatCraftAvailabilityStatus: function (sAvailabilityStatus) {
				var sAvailability = "";
				var i18n = com.sap.cp.lm.util.Formatter._oComponent.getModel("i18n");

				if (sAvailabilityStatus === "U") {
					this.removeStyleClass("lmColorLightBlue");
					this.addStyleClass("lmColorRed");
					sAvailability = i18n.getProperty("UNAVAILABLE");
				} else if (sAvailabilityStatus === "A") {
					this.removeStyleClass("lmColorRed");
					this.addStyleClass("lmColorLightBlue");
					sAvailability = i18n.getProperty("AVAILABLE");
				}

				return sAvailability;
			},

			formatCraftAllocatedHours: function (sAllocatedHrs) {
				var sFormatted = "/ ";
				var i18n = com.sap.cp.lm.util.Formatter._oComponent.getModel("i18n");
				sAllocatedHrs = (sAllocatedHrs * 1).toString();

				sFormatted += sAllocatedHrs;
				sFormatted += " ";
				sFormatted += i18n.getProperty("LOGGED_ON_ALLOCATED_HOURS");

				return sFormatted;
			},

			getPercentFromFraction: function (sNumerator, sDenominator) {
				var fNumerator = parseInt(sNumerator);
				var fDenominator = parseInt(sDenominator);
				//set the default percentage to zero instead of 100
				var fPercent = 0;

				if (fDenominator !== 0) {
					fPercent = ((fNumerator * 100) / fDenominator);
				}
				if (fNumerator === 0 && fDenominator === 0) {
					fPercent = 100;
				}
				return fPercent;
			},
			/*Added By Vikram*/
			getStateColorFromFraction: function (sNumerator, sDenominator) {
				var fNumerator = parseInt(sNumerator);
				var fDenominator = parseInt(sDenominator);
				// default state
				var state = "Success";

				if (fNumerator === 0 && fDenominator === 0) {
					state = "Error";
				}
				return state;
			},
			/*Added By Vikram*/
			getOperationsCount: function (sNumerator, sDenominator) {
				var i18n = com.sap.cp.lm.util.Formatter._oComponent.getModel("i18n");
				var count = sNumerator + "/" + sDenominator + " " + i18n.getProperty("OPERATIONS");
				return count;
			},

			getPercentFromFractionAsString: function (sNumerator, sDenominator) {
				var fPercent = com.sap.cp.lm.util.Formatter.getPercentFromFraction(sNumerator, sDenominator);
				var sPercent = String(fPercent);

				if (Math.round(fPercent) !== fPercent) {
					sPercent = fPercent.toFixed(2);
				}

				return sPercent;
			},

			getPercentEfficiency: function (sNumerator, sDenominator) {
				var fNumerator = parseFloat(sNumerator);
				var fDenominator = parseFloat(sDenominator);
				var i18n = com.sap.cp.lm.util.Formatter._oComponent.getModel("i18n");
				var sEfficiency = i18n.getProperty("NO_LOGGED_HOURS");

				if (fDenominator !== 0) {
					var fPercent = ((fNumerator * 100) / fDenominator);
					var sPercent = String(Math.round(fPercent));

					sEfficiency = sPercent + "% " + i18n.getProperty("PRODUCTIVITY");
				}

				return sEfficiency;
			},

			setAlertColorForNumeratorOverflow: function (sNumerator, sDenominator) {
				var fNumerator = (sNumerator * 1);
				var sFormatted = fNumerator.toString();

				if (parseInt(sNumerator) > parseInt(sDenominator)) {
					this.addStyleClass("lmColorRed");
					this.addStyleClass("lmFontBold");
				}

				return sFormatted;
			},

			//SetVisibility for task sheet
			setVisibilityforTaskSheet: function (sMeasurementType) {

				switch (sMeasurementType) {
				case Constants.MEASTYPE.WHEEL_SHEET:
					return true;

				case Constants.MEASTYPE.MS_MEGAWATT_HOUR_A:
					return true;

				case Constants.MEASTYPE.SERIALNUMBER:
					return true;
				// Start - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
				case Constants.MEASTYPE.SW_VERSION_NUMBER:
					return true;
				// End - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
				default:
					return false;
				}
			},

			/* Function formats the cats time into hours & Minues */
			changeTimeFormatforTask: function (sDate) {
				if (sDate) {
					var oMilliSeconds = sDate.valueOf("ms").ms;

					// 1- Convert to seconds:
					var seconds = oMilliSeconds / 1000;
					// 2- Extract hours:
					var sHours = parseInt(seconds / 3600); // 3,600 seconds in 1 hour
					seconds = seconds % 3600; // seconds remaining after extracting hours
					// 3- Extract minutes:
					var sMinutes = parseInt(seconds / 60); // 60 seconds in 1 minute
					return sHours + " H " + sMinutes + " M";
				} else {
					return sDate;
				}
			},

			pad: function (n, width, z) {
				z = z || '0';
				n = n + '';
				return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
			},

			/* Function formats the cats time into hours : Minutes */
			changeTimeFormatforSchedule: function (sDate) {
				if (sDate) {
					var oMilliSeconds = sDate.valueOf("ms").ms;
					if (oMilliSeconds === 0) {
						return "";
					}
					var dDate = new Date(oMilliSeconds);
					var dTmpDate = dDate.getTime() + (dDate.getTimezoneOffset() * 60000);
					var dLocaleDate = new Date(dTmpDate);
					var sHours = dLocaleDate.getHours();
					var sMinutes = com.sap.cp.lm.util.Formatter.pad(dLocaleDate.getMinutes(), 2);
					var sResult = sHours + ":" + sMinutes;

					return sResult;
				} else {
					return sDate;
				}
			},

			setExpandablePanelVisibility: function (aTableSet, bIsTableVisible) {
				var bIsVisible = bIsTableVisible;

				if (bIsTableVisible !== false) {
					if (aTableSet.length <= 0) {
						//bIsVisible = false;
						this.addStyleClass("lmPanelNotVisible");
					} else {
						this.removeStyleClass("lmPanelNotVisible");
					}
				}

				return bIsVisible;
			},

			setExpandablePanelCustomData: function (aTableSet, bIsTableVisible) {
				var bIsVisible = bIsTableVisible;

				if (bIsTableVisible !== false) {
					if (aTableSet.length <= 0) {
						bIsVisible = false;
					}
				}

				return String(bIsVisible);
			},
			//Begin VYA0004 MOD0017
			setVisibilityBNBLoco: function (oLocomotive, bReadOnlyWorkPlan) {

				var bIsVisible = false;

				if (oLocomotive && !bReadOnlyWorkPlan) {
					if (oLocomotive.ShopStatus !== "R") { //not released
						if (oLocomotive.ShopReason === "M") { //shopped for maintenance
							if (oLocomotive.BnbLoco) {
								bIsVisible = true;
							}
						}
					}
				}

				return bIsVisible;
			},
			setVisibilityLocoNotReleasedUpdated: function (oLocomotive, bReadOnlyWorkPlan) {

				var bIsVisible = false;

				if (oLocomotive && !bReadOnlyWorkPlan) {
					// SHE0272 - Start - LLM2.3 - Add Orders in Service Tab -  Commented shop reason check
					// if (oLocomotive.ShopStatus !== "R" && oLocomotive.ShopReason === "M" && !oLocomotive.BnbLoco) {
					// 	bIsVisible = true;
					// }
					if (oLocomotive.ShopStatus !== "R" && !oLocomotive.BnbLoco) {
						bIsVisible = true;
					}
					// SHE0272 - End - LLM2.3 - Add Orders in Service Tab
				}
				return bIsVisible;
			},
			//End VYA0004 MOD0017
			setVisibilityLocoNotReleased: function (oLocomotive, bReadOnlyWorkPlan) {

				var bIsVisible = false;

				if (oLocomotive && !bReadOnlyWorkPlan) {
					if (oLocomotive.ShopStatus !== "R") { //not released
						// Start - LLM2.3 - Add Orders in Service Tab - Commented shop reason check
						// if (oLocomotive.ShopReason === "M") { //shopped for maintenance
						bIsVisible = true;
						// }
						// End - LLM2.3 - Add Orders in Service Tab
					}
				}

				return bIsVisible;
			},

			setVisibilityNotReleased: function (sShopStatus, bReadOnlyWorkPlan) {

				var bIsVisible = false;

				if (!bReadOnlyWorkPlan) {
					// START - BAJ0018 - IM241669-002					
					//		if (sShopStatus !== "R") {

					if (sShopStatus && sShopStatus !== "R") {
						// START - BAJ0018 - IM241669-002						
						bIsVisible = true;
						//bIsVisible = com.sap.cp.lm.util.Formatter.setVisibilitynonServiceGroup();
					}
				}

				return bIsVisible;
			},

			setVisibilityNotReleasedAndNotCraft: function (sShopStatus, sRole, sBnbLoco) {

				if (sBnbLoco) {
					return false;
				}

				if (com.sap.cp.lm.util.Formatter.isCraft(sRole)) {
					return false;
				}

				if (sShopStatus !== "") {
					return com.sap.cp.lm.util.Formatter.setVisibilityNotReleased(sShopStatus, false);
				}

				return false;
			},

			setVisibilityOnlyReleased: function (sShopStatus, sRole) {
				var bIsVisible = false;

				if (com.sap.cp.lm.util.Formatter.isCraft(sRole)) {
					return bIsVisible;
				}

				if (sShopStatus === "R") {
					bIsVisible = true;
					//bIsVisible = com.sap.cp.lm.util.Formatter.setVisibilitynonServiceGroup();
				}

				return bIsVisible;
			},

			isCraft: function (sRole) {
				var bIsCraft = false;

				if (sRole === Constants.ROLE.CRAFT) {
					bIsCraft = true;
				}

				return bIsCraft;
			},

			isNotCraft: function (sRole) {
				return !com.sap.cp.lm.util.Formatter.isCraft(sRole);
			},

			/**
			 * Formatter called from KpiView to remove decimals when they are nil (eg. 30.00 become 30)
			 * Set color class depending on status
			 */
			numericHandleDecimalsFormatter: function (sValue, sStatus) {
				var fValue = parseFloat(sValue);
				var sClass = "lmColorPositive";

				if (sStatus === "2") {
					sClass = "lmColorCritical";
				} else if (sStatus === "3") {
					sClass = "lmColorNegative";
				}

				this.addStyleClass(sClass);

				return fValue;
			},

			/**
			 * Return true if locmotive status is deferred
			 */
			isStatusDefer: function (sLocoStatus) {
				var bIsDeferred = false;

				if (sLocoStatus === Constants.STATUS_DEFERRED) {
					bIsDeferred = true;
				}

				return bIsDeferred;
			},

			/**
			 * Function sets visibility for Status not complete of operation
			 */
			isStatusNotCompleteOrGroupVisible: function (sOPStatus, oGroups, sGroupId) {
				if ((sOPStatus === Constants.STATUS_COMPLETED) && (sGroupId === "" || sGroupId === undefined)) {
					return false;
				} else if (oGroups) {
					var aGroupItemSet = oGroups.results;
					var bIsVisible = true;
					if (aGroupItemSet) {
						for (var i = 0; i < aGroupItemSet.length; i++) {
							var oCurrentGroup = aGroupItemSet[i];
							if (oCurrentGroup.WorkOrder && oCurrentGroup.WorkOrder.Status === Constants.STATUS_COMPLETED && oCurrentGroup.WorkOrder.NotificationType) {
								bIsVisible = false;
							} else {
								bIsVisible = true;
								break;
							}
						}
					}
					return bIsVisible;
				} else if (sOPStatus === Constants.STATUS_COMPLETED) {
					return false;
				}
				return true;
			},

			/**
			 * Function sets visibility to complete work button in Workorder Actionsheet of WO
			 */
			setVisibilityBtnCompleteWork: function (sOPStatus, oGroups, sGroupId, sRole, sFullLoad, sActType, bBnbGoodsIssue, bBnbGoodsReturn,
				sOrderType) {
				if (sActType && sOrderType === 'PM04') {
					if (!bBnbGoodsIssue || !bBnbGoodsReturn)
						return false;
				}

				if (com.sap.cp.lm.util.Formatter.isStatusDefer(sOPStatus)) {
					return false;
				}

				if (com.sap.cp.lm.util.Formatter.isCraft(sRole)) {
					return false;
				}

				return com.sap.cp.lm.util.Formatter.isStatusNotCompleteOrGroupVisible(sOPStatus, oGroups, sGroupId);
			},

			setVisibilityBtnDeferWork: function (sOPStatus, oGroups, sGroupId, sRole, sOrderType, sDefectType) {
				// any one can defer work based on new requirements
				return true;

				if (sOrderType === "MS06") {
					return false;
				}
				if (sDefectType === "Z4" || sDefectType === "Z6" || sDefectType === "Z7") {
					return false;
				}
				if (com.sap.cp.lm.util.Formatter.isCraft(sRole)) {
					return false;
				}

				if (!com.sap.cp.lm.util.Formatter.isStatusDefer(sOPStatus)) {
					return com.sap.cp.lm.util.Formatter.isStatusNotCompleteOrGroupVisible(sOPStatus, oGroups, sGroupId);
				}

				return false;
			},

			setVisibilityBtnUndoDeferWork: function (sOPStatus, oGroups, sGroupId) {
				var bIsVisible = false;

				if (com.sap.cp.lm.util.Formatter.isStatusDefer(sOPStatus)) {
					bIsVisible = com.sap.cp.lm.util.Formatter.isStatusNotCompleteOrGroupVisible(sOPStatus, oGroups, sGroupId);
				}

				return bIsVisible;
			},

			setVisibilityBtnWmat: function (isWmat, sRole) {
				var bIsVisible = false;

				if (isWmat && !com.sap.cp.lm.util.Formatter.isCraft(sRole)) {
					bIsVisible = true;
				}

				return bIsVisible;
			},
			setVisibilityBtnWmatset: function (isWmat, isReserved, sRole) {
				var bIsVisible = false;

				if (!isWmat && !com.sap.cp.lm.util.Formatter.isCraft(sRole)) {
					bIsVisible = true;
				}
				//start - BAJ0018 - EAM-ASR3415776
				if (!isReserved) {
					bIsVisible = false;
				}
				//end - BAJ0018 - EAM-ASR3415776
				return bIsVisible;
			},

			setListTypeForCraftOperations: function (TaskSet) {
				var sType = "Inactive";

				if (TaskSet && TaskSet.length > 0) {
					sType = "Navigation";
				}

				return sType;
			},

			setCraftOperationsColumnWidth: function (bShowTechInfo) {
				var sWidth = "17%";

				if (!bShowTechInfo) {
					sWidth = "26%";
				}

				return sWidth;
			},

			setTooltipMeasurementType: function (sMeasurementType) {
				var i18n = com.sap.cp.lm.util.Formatter._oComponent.getModel("i18n");
				var iMeasurementType = parseInt(sMeasurementType);
				var sTitle = "";

				if (iMeasurementType === 1) {
					sTitle = i18n.getProperty("MEASUREMENT_SET");
				} else if (iMeasurementType === 2) {
					sTitle = i18n.getProperty("MEASUREMENT_POINT");
				} else if (iMeasurementType === 3) {
					sTitle = i18n.getProperty("SERIAL_NUMBER");
				} 
				// Start - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
				else if (iMeasurementType === 4) {
					sTitle = i18n.getProperty("SW_VERSION_NUMBER");
				}
				// End - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
				return sTitle;
			},

			setVisibilityForNotFleetShoppedFields: function (sShopId, sShopStatus) {
				var bIsVisible = false;

				if (sShopId !== "" && sShopStatus !== "s") {
					bIsVisible = true;
				}

				return !bIsVisible;
			},

			setVisibilityForFleetShoppedFields: function (sShopId, sShopStatus) {
				var bIsVisible = false;

				if (sShopId !== "" && sShopStatus !== "s") {
					bIsVisible = true;
				}

				return bIsVisible;
			},

			setVisibilityForFleetNotShoppedFields: function (sShopId, sShopStatus) {
				return !com.sap.cp.lm.util.Formatter.setVisibilityForFleetShoppedFields(sShopId, sShopStatus);
			},

			isNotCraftAndIsNotFleet: function (sRole, bIsFleet) {
				return (!com.sap.cp.lm.util.Formatter.isCraft(sRole) && !bIsFleet);
			},

			shopIdToShopName: function (sShopId) {
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				var aShops = oGlobalModel.getProperty("/Shops");
				var sShopName = "";
				var bShopFound = false;
				var i = 0;

				while (!bShopFound && i < aShops.length) {
					if (aShops[i].Id === sShopId) {
						sShopName = aShops[i].Name;
						bShopFound = true;
					}

					i++;
				}

				return sShopName;
			},

			returnEarlierDate: function (dNextDefectDate, dNextMaintDate, sTimezone) {
				var dEarlier = dNextDefectDate;

				if (dNextMaintDate < dEarlier) {
					dEarlier = dNextMaintDate;
				}

				return com.sap.cp.lm.util.Formatter.changeTimestampToDay(dEarlier, sTimezone);
			},

			editEstTimeIsEnabled: function (sLocoStatus, sPlanWorkDur, sOrderType, sOprStatus) {
				var bIsEnabled = false;
				// Start LMP2_181 ( Defect#226 Dt.25/Nov/19 - Business requested to take this enhancement out , hence below code is commented)
				// var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				// var sCurrentRole = oGlobalModel.getProperty("/role");

				// if (sOrderType === 'MS01' && sCurrentRole === Constants.ROLE.SUPERVISOR && sOprStatus !== "0") {
				// 	bIsEnabled = true;
				// }
				// End LMP2_181
				if (sLocoStatus !== Constants.STATUS_COMPLETED && sPlanWorkDur === '0.0') {
					bIsEnabled = true;
				}

				return bIsEnabled;
			},

			editEstTimeIsDisabled: function (sLocoStatus, sPlanWorkDur, sOrderType, sOprStatus) {
				return !com.sap.cp.lm.util.Formatter.editEstTimeIsEnabled(sLocoStatus, sPlanWorkDur, sOrderType, sOprStatus);
			},

			setDefaultSelectedWorkOrderType: function (oItems) {
				var i = 0;
				var bFound = false;
				var sSelectedKey = false;

				if (oItems) {
					while (!bFound && i < oItems.length) {
						var oCurrentData = oItems[i];
						if (oCurrentData.DefaultSelection === true) {
							bFound = true;
							sSelectedKey = oCurrentData.Value;
						}
						i++;
					}
				}

				return sSelectedKey;
			},

			/* START KIR0084 LMP2-35 Crafts Assigned for Work Order formatter */
			formatCraftsAssignedToWorkOrders: function (workOrderList) {
				if (workOrderList) {
					var workOrderItems = workOrderList.results || workOrderList;
					if (workOrderItems.length < 1) {
						return "";
					}

					var craftAssignString = "";
					var aPernrAssigned = [];

					workOrderItems.forEach(function (workOrder) {
						return workOrder.OperationSet.results.forEach(function (operation) {
							return operation.AssignmentSet.results.forEach(function (assignment) {
								if (!aPernrAssigned.includes(assignment.Name)) {
									craftAssignString += assignment.Name + ", ";
									aPernrAssigned.push(assignment.Name);
								}
							});
						});
					});
					if (craftAssignString.length > 2) {
						return craftAssignString.substring(0, craftAssignString.length - 2);
					} else {
						return craftAssignString;
					}
				} else {
					return "";
				}
			},

			formatCraftButtonForOperation: function (operationSet) {
				var addedCraftsList = [];

				if (operationSet && operationSet.results) {

					operationSet.results.forEach(function (operation) {
						operation.AssignmentSet.results.forEach(function (assignment) {
							if ($.inArray(assignment.PersonNo, addedCraftsList) === -1) {
								addedCraftsList.push(assignment.PersonNo);
							}
						});
					});
				}

				return "Crafts(" + addedCraftsList.length + ")";
			},

			formatCraftButtonActiveForOperation: function (operationSet) {
				if (operationSet && operationSet.results) {
					var craftAssignCount = 0;

					operationSet.results.forEach(function (operation) {
						craftAssignCount += operation.AssignmentSet.results.length;
					});
					return craftAssignCount > 0;
				} else {
					return false;
				}
			},
			/* END KIR0084 LMP2-35 Crafts Assigned for Work Order formatter */
			/* START KIR0084 Format shop name */
			formatGetShopName: function (shopId) {
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();

				var odataShops = oGlobalModel.getProperty("/Shops");

				if (!odataShops) {
					return "";
				}

				var shops = odataShops.filter(function (shop) {
					return shop.Id === shopId;
				});

				if (shops.length > 0) {
					return shops[0].Name;
				}
			},
			/* END KIR0084 Format shop name */
			
            //Begin VYA0004|LLM3.3
            isWOHistoryReasonVisible: function (sCount, sMatRestFlag) {
				var bResult = false;
				var oGlobalModel = com.sap.cp.lm.util.Formatter.getComponent().getGlobalModel();
				if (oGlobalModel.getProperty("/readFromWOHistory") === true
				    && sCount !== 0 && sMatRestFlag === 'Y') {
					bResult = true;
				}
				return bResult;
			},
			isMaterialChargeVisible: function (sMatRestFlag) {
				var bResult = false;
				if (sMatRestFlag === 'Y') {
					bResult = true;
				}
				return bResult;
			},
            //End VYA0004|LLM3.3
			// SHE0272 - LLM2.23 - Primary Defect - Formater for visibility of the primary indicator
			setPrimaryReasonIndicator: function (primaryReason) {
				if (primaryReason && (primaryReason === 'X')) {
					return 'M';
				} else {
					return '';
				}
			},
			
			// SHE0272 - LLM2.23 - Primary Defect - Formater for visibility of the primary indicator
			setPrimaryReasonInTurnOverReport: function (primaryReason) {
				this.removeStyleClass("lmWorkPlanListItemDescription");
				this.removeStyleClass("lmMainReasonStyleClass");
				var primaryReasonValue = "";
				if (primaryReason) {
					this.addStyleClass("lmWorkPlanListItemDescription");
					this.addStyleClass("lmMainReasonStyleClass");
					primaryReasonValue = "M";
				}
				return primaryReasonValue;
			},
			
			// SHE0272 - EAM-LLM 1.2 Serialization
			fnAddSerializationPopUpStyleClass: function (measurementType) {
				this.removeStyleClass("llmSerialzeBoxStyleClass");
				if (measurementType && measurementType === '5') {
					this.addStyleClass("llmSerialzeBoxStyleClass");
				}
				return "30%";
			},
			
			// SHE0272 - EAM-LLM 1.2 Serialization
			fnAddCustomDisableStyleClass: function (disableIndicator) {
				this.removeStyleClass("llmCustomReadOnlyInputStyleClass");
				if (disableIndicator && disableIndicator === 'X') {
					this.addStyleClass("llmCustomReadOnlyInputStyleClass");
					return false;
				} else {
					return true;
				}
			},
			
			// SHE0272 - EAM-LLM 1.2 Serialization
			fnAddCustomXDisableStyleClass: function (disableIndicator) {
				this.removeStyleClass("llmCustomReadOnlyInputStyleClass");
				if (!disableIndicator) {
					this.addStyleClass("llmCustomReadOnlyInputStyleClass");
				}
				return disableIndicator;
			}
		};
	});