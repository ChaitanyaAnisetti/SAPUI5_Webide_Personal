(function() {
    "use strict";

    $.sap.declare("com.sap.cp.lm.framework.BaseDelegate");

    /**
     * Constructor for a new BaseDelegate.
     *
     * @param {object}
     *            mParameters a map with parameters
     * @param {string}
     *            mParameters.fragmentName the name of the fragment.
     * @param mParameters.owner the owner of the fragment.
     *
     * @name delta.swaps.view.BaseDelegate
     * @extends sap.ui.base.EventProvider
     */
    sap.ui.base.EventProvider.extend("com.sap.cp.lm.framework.BaseDelegate",
        {
            _oFragment: null,
            _oOwner: null,
            _sFragmentId: null,
            _sFragmentName: null,

            constructor: function (mParameters) {
                sap.ui.base.EventProvider.prototype.constructor.apply(this, arguments);

                if (!mParameters || !mParameters.fragmentName) {
                    $.sap.log.fatal("Fragment name has to be provided", "BaseDelegate", "cp.lm");
                }

                if (!mParameters || !mParameters.owner) {
                    $.sap.log.fatal("Owner has to be provided", "BaseDelegate", "cp.lm");
                }

                this._sFragmentName = mParameters.fragmentName;
                this._oOwner = mParameters.owner;
            },

            /**
             * Destroys the objects and releases all object references.
             */
            destroy: function () {
                // Destroy objects
                if (this._oFragment) {
                    this._oFragment.destroy();
                }

                // Reset properties
                this._oFragment = null;
                this._oOwner = null;

                sap.ui.base.EventProvider.prototype.destroy.apply(this, arguments);
            },

            /**
             * Returns the owner of the delegate.
             *
             * @returns  the owner of the view (controller or delegate).
             */
            _getOwner: function () {
                return this._oOwner;
            },

            /**
             * Returns the component for the delegate.
             *
             * @returns the component
             */
            getComponent: function () {
                return this._getOwner().getComponent();
            },

            /**
             * Creates the fragment from the fragment name provided to the controller and assigned a random id.
             *
             * @returns {sap.ui.core.Element|sap.ui.core.Element[]} the root element of the fragment or an array of elements.
             */
            _createFragment: function () {
                $.sap.assert(this._sFragmentName, "Trying to instantiate fragment but fragmentName is not given.");
                this._sFragmentId = $.sap.uid();
                var vFragment = sap.ui.xmlfragment(this._sFragmentId, this._sFragmentName, this);

                return vFragment;
            },

            /**
             * Internal utility function for accessing an element inside the fragment by its id.
             *
             * @param {string}
             *            sId the id of the element inside the fragment.
             * @returns {sap.ui.core.Element} the element matching the id.
             */
            byId: function (sId) {
                return sap.ui.core.Fragment.byId(this._sFragmentId, sId);
            },

            /**
             * Internal utility function for creating an id for an element inside the fragment.
             *
             * @param {string}
             *            sId the id of the element inside the fragment.
             * @returns {string} the id.
             */
            createId: function (sId) {
                return sap.ui.core.Fragment.createId(this._sFragmentId, sId);
            },

            /**
             * Returns the fragment.
             *
             * @returns {sap.ui.core.Element} the root element of the fragment.
             */
            getFragment: function () {
                if (!this._oFragment) {
                    this._oFragment = this._createFragment();
                }
                return this._oFragment;
            },

            /**
             * Checks whether the fragment has already been created.
             *
             * @returns {boolean} true of fragment has been created, false otherwise.
             */
            isFragmentCreated: function () {
                return !!this._oFragment;
            }
        }
    );
    }
());