/*///////////////////////// Change Log /////////////////////////////////  
Author/Changed By   : Sandesh Shirode(SHI0087)	               		
Date                : 06-May-2019                                      
Project             : Locomotive Maintenance Phase                     
Description         : 1) LMP2-8a: Fuzzy Search help based on OEM part no 
						Material Number / Material Description			  
						2) Issue reserve Material in batch				  
*************************************************************************  
Author/Changed By   : Sandesh Shirode(SHI0087)	               		   
Date                : 06-Sep-2019                                       
Project             : Locomotive Maintenance Phase 2 (Sprint3)           
Description         : Fetch Applicable Assets for respective materials  
						Material Number / Material Description			   
*************************************************************************
Changed By       : Steve Palme(PAL0121)
Change Code      : ASR3414893
Business Analyst : Soon Hong Cheah
Trans. Req.      : YD1K904915
Charm Request ID : 2000008938
Date             : 3/3/20
Purpose          : Add storage loc ST1A for loco materials
Details          : Add storage loc ST1A for loco materials, also add 
				   storage loc as input when adding material
*************************************************************************
Changed By       : BAJ0018
Change Code      : BNB
Business Analyst : Alex Capicio
Date             : 13/4/21
Purpose          : Add storage loc ASSM for BNB		
*************************************************************************  
Author/Changed By   : SHE0272	               		 
Date                : 19-Aug-2021                                     
Project             : Display Permissable storage location                  
Description         : LLMBNB3.0: Fetch only ASSM location material
*************************************************************************
Changed By       : VYA0004
Change Code      : LLM3.3
Business Analyst : Ken Zheng
Date             : 8 Oct 2021
Purpose          : Adding a method to check if all the materials have been
                   issued for a given Order-Operation.
Search Term      : VYA0004|LLM3.3                   
*************************************************************************  
*/ //////////////////////////////////////////////////////////////////////    
//#Dont Delete Daya
jQuery.sap.declare("com.sap.cp.lm.model.material.MaterialModel");

sap.ui.define([
		"com/sap/cp/lm/util/Constants",
		"com/sap/cp/lm/util/BusyIndicator",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"com/sap/cp/lm/util/ErrorManager"
	],
	function (Constants, BusyIndicator, Filter, FilterOperator, ErrorManager) {
		"use strict";

		var _this;

		return com.sap.cp.lm.model.material.MaterialModel = {

			/**
			 * Initialize of material datamodel
			 */
			init: function (oMainModel, oGlobalModel) {
				_this = this;
				this._oModel = oMainModel;
				this._oGlobalModel = oGlobalModel;
			},

			/**
			 * Fetch the material with OEM Number / MAterial Number / Material Description
			 */
			fetchCpPartNumber: function (sSearchTerm, sShopId, fnSuccessCallBack, fnErrorCallBack, oContext, bnbFilter) { // SHE0272 - LLMBNB3.0 - Added a new bnbFilter to pass in the service call
				BusyIndicator.showBusyIndicator();
				// Start - LMP2-8A - Obtain the list of materials	
				var sStoLoco = "ST1A"; //ASR3414893					
				var sModifiedSearchTerm = "*" + sSearchTerm + "*";

				var sEntityPath = "/ZPM_LM_C_GET_MATERIAL(p_shop_id%3D'" + sShopId + "',p_sto_loc%3D'" + sStoLoco + "')/Set"; // LMP2-8a
				this._oModel.read(sEntityPath, {
					urlParameters: {
						search: sModifiedSearchTerm,
						$filter: bnbFilter,
						$top: 50
					},
					success: function (oData) {
						//BNB	storage location - START
						sStoLoco = "ASSM"; //BNB	storage location			
						sModifiedSearchTerm = "*" + sSearchTerm + "*";
						sEntityPath = "/ZPM_LM_C_GET_MATERIAL(p_shop_id%3D'" + sShopId + "',p_sto_loc%3D'" + sStoLoco + "')/Set"; // LMP2-8a
						this._oModel.read(sEntityPath, {
							urlParameters: {
								search: sModifiedSearchTerm,
								$top: 50
							},
							success: function (oAssmData) {
								BusyIndicator.hideBusyIndicator();
								oData.results = oData.results.concat(oAssmData.results);

								function compareAssm(a, b) {
									if (a.MaterialNo < b.MaterialNo) {
										return -1;
									}
									if (a.MaterialNo > b.MaterialNo) {
										return 1;
									}
									return 0;
								}
								oData.results.sort(compareAssm);
								/////////////////////Begin of Changes for ASR3414893 by PAL0121/////////////////////
								if (sShopId === "1025" || sShopId === "1065" || sShopId === "1883" || sShopId === "3035") {
									sStoLoco = "LOCO";
									sEntityPath = "/ZPM_LM_C_GET_MATERIAL(p_shop_id%3D'" + sShopId + "',p_sto_loc%3D'" + sStoLoco + "')/Set"; // LMP2-8a
									this._oModel.read(sEntityPath, {
										urlParameters: {
											search: sModifiedSearchTerm,
											$filter: bnbFilter,
											$top: 50
										},
										success: function (oLocoData) {
											BusyIndicator.hideBusyIndicator();

											oData.results = oData.results.concat(oLocoData.results);

											function compare(a, b) {
												if (a.MaterialNo < b.MaterialNo) {
													return -1;
												}
												if (a.MaterialNo > b.MaterialNo) {
													return 1;
												}
												return 0;
											}

											oData.results.sort(compare);
											if (fnSuccessCallBack && oContext) {
												fnSuccessCallBack.apply(oContext, [oData]);
											}
										},
										error: function (oError) {
											BusyIndicator.hideBusyIndicator();
											ErrorManager.handleError(oError);
										}
									});
								} else {
									BusyIndicator.hideBusyIndicator();

									if (fnSuccessCallBack && oContext) {
										fnSuccessCallBack.apply(oContext, [oData]);
									}
								}
								//////////////////////End of Changes for ASR3414893 by PAL0121////////////////////// 	
							}.bind(this),
							error: function (oError) {
								BusyIndicator.hideBusyIndicator();
								ErrorManager.handleError(oError);
							}
						});
						//BNB	storage location - END
					}.bind(this),
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
			},
			// Start LMP2-8A - Fetch GMPS data			
			fetchGMPSinfo: function (sOrderNum, oContext) {
				BusyIndicator.showBusyIndicator();
				this._oModel.callFunction("/GetGMPSInfo", {
					urlParameters: {
						"OrderNo": sOrderNum,
						"$format": "json"
					},
					success: function (oData) {
						oContext.oModel.setProperty("/GMPSinfo", oData.results);
						BusyIndicator.hideBusyIndicator();

					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}

				});
			},
			/*VYA0004|LLM3.3 Adding sOperation*/
			fetchReserveMatDetails: function (sOrderNum, sPlant, oContext, sOperation) {
				BusyIndicator.showBusyIndicator();
				//VYA0004|LLM3.3 Begin
				if (sOperation){
				this._oModel.callFunction("/GetReserveMatDetails", {
					urlParameters: {
						"OrderNo": sOrderNum,
						"Plant": sPlant,
						"OprNum": sOperation,
						"$format": "json"
					},
					success: function (oData) {
						oContext.oResMatModel.setProperty("/ReserveMat", oData.results);
						BusyIndicator.hideBusyIndicator();

					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}

				});
				}else{
				//VYA0004|LLM3.3 End	
					this._oModel.callFunction("/GetReserveMatDetails", {
					urlParameters: {
						"OrderNo": sOrderNum,
						"Plant": sPlant,
						"$format": "json"
					},
					success: function (oData) {
						oContext.oResMatModel.setProperty("/ReserveMat", oData.results);
						BusyIndicator.hideBusyIndicator();

					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}

				});
				}
			},
			// Process the Issue Reserve material data in batch 
			AddReserveMaterial: function (aPayloads, oContext, fnSuccessCallBack) {

				BusyIndicator.showBusyIndicator();

				this._oModel.setUseBatch(true);

				//Define group ID
				this._oModel.setDeferredGroups(["reserveMatGroup"]);

				for (var i = 0; i < aPayloads.length; i++) {
					var oPayload = aPayloads[i];

					this._oModel.update("/MaterialSet(OpNode='" + oPayload.OpNode + "',RoutingNo='" + oPayload.RoutingNo + "')",
						oPayload, {
							groupId: "reserveMatGroup"
						});
				}
				this._oModel.submitChanges({
					groupId: "reserveMatGroup",
					success: function (oData, oResponse) {
						BusyIndicator.hideBusyIndicator();
						$.each(oData.__batchResponses, function (j, obj) {
							if (obj && obj.message) {
								sap.m.MessageBox.error("Error in Processing record(s)!!");
								oContext._oReserveMaterialDialog.close();
							} else {
								sap.m.MessageBox.success("Record(s) process successfully!");
								oContext._oReserveMaterialDialog.close();
								//Begin VYA0004|LLM3.3
								if (fnSuccessCallBack && oContext) {
							      fnSuccessCallBack.apply(oContext, [oData]);
						          }//End VYA0004|LLM3.3
							}
						});
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						sap.m.MessageBox.error("Error in Processing record(s)!!");
					}

				});
			},
			// End - LMP2-8A  

			/* 
			 * Call service to add material
			 */
			addMaterialToOperation: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/MaterialSet",
					oPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							}
						}
					}
				);
			},

			/**
			 * Fetch the Applicable Asset LMP2_168_169  (sMaterialNo,sPlant,sStoLoc,_this);
			 */
			fetchAppAssetsInfo: function (sMaterialNo, sShopId, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				var sStoLoco = "ST1A"; //ASR3414893

				var sEntityPath = "/ZPM_LM_C_GET_APP_ASSETS(p_mat_no%3D'" + sMaterialNo + "',p_shop_id%3D'" + sShopId + "',p_sto_loc%3D'" + sStoLoco +
					"')/Set";
				this._oModel.read(sEntityPath, {
					success: function (oData) {
						/////////////////////Begin of Changes for ASR3414893 by PAL0121/////////////////////
						if (sShopId === "1025" || sShopId === "1065" || sShopId === "1883" || sShopId === "3035") {
							sStoLoco = "LOCO";
							sEntityPath = "/ZPM_LM_C_GET_APP_ASSETS(p_mat_no%3D'" + sMaterialNo + "',p_shop_id%3D'" + sShopId + "',p_sto_loc%3D'" +
								sStoLoco + "')/Set";
							this._oModel.read(sEntityPath, {
								success: function (oLocoData) {
									BusyIndicator.hideBusyIndicator();
									oData.results = oData.results.concat(oLocoData.results);

									function compare(a, b) {
										if (a.MaterialNo < b.MaterialNo) {
											return -1;
										}
										if (a.MaterialNo > b.MaterialNo) {
											return 1;
										}
										return 0;
									}

									oData.results.sort(compare);
									if (fnSuccessCallBack && oContext) {
										fnSuccessCallBack.apply(oContext, [oData]);
									}
								},
								error: function (oError) {
									BusyIndicator.hideBusyIndicator();
									ErrorManager.handleError(oError);
								}
							});
						} else {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							}
							// oContext.oAppAssetModel.setProperty("/ApplicableAssets", oData.results);
						}
						//////////////////////End of Changes for ASR3414893 by PAL0121//////////////////////  							
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
			},
            //Start VYA0004|LLM3.3
            CheckGoodsIssueComplete: function (sOrderNo, sActivity, oContext, fOpenpopup, oSelContext) {
            //Check if all materials assigned to this operation were issued or not.	
            BusyIndicator.showBusyIndicator();
            	// var sQuery = "(OrderNo eq '" + sOrderNo + "' " + "and " + "Activity eq '" + sActivity + "')";
            var sKey = this._oModel.createKey("/ValidateIssueMatSet", {
            	OrderNo: sOrderNo,
                Activity: sActivity});
                this._oModel.read( sKey, {
                	 
                   success: function (oData) {
						fOpenpopup.apply(oContext, [oData,oSelContext]);
						BusyIndicator.hideBusyIndicator();
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}

				});
            	
            },
            DisplayNoMaterialRequired:function(sOrderNo, oContext){
            //Retrieve No Material Required reason(s) for this work order
            BusyIndicator.showBusyIndicator();
            var aFilters = [];
				aFilters.push(new Filter("Workorder", FilterOperator.EQ, sOrderNo));
            this._oModel.read("/WONoMatReasonSet", {
					filters: aFilters,
					success: function (oData) {
						var oNoMatReqDispModel = new sap.ui.model.json.JSONModel(oData);
						sap.ui.getCore().byId("tNoMatReqDisp").setModel(oNoMatReqDispModel, "NoMatReqDisp");
						BusyIndicator.hideBusyIndicator();
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}

				});
				
            },
            SaveNoMaterialReqReason:function(oPayload, oContext, fnSuccess){
            BusyIndicator.showBusyIndicator();

				this._oModel.create("/UpdateMatReasonSet", oPayload, {
					async: false,
					success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							oContext._oNoMatReqDialog.close();
						if (fnSuccess && oContext) {
							      fnSuccess.apply(oContext, [oData]);
						  }
							
					}.bind(this),
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						sap.m.MessageBox.error("Error occurred while saving.Please try again.");
					}
				});
					
            },
            //End VYA0004|LLM3.3
			// Start SHE0272 - LLMBNB3.0 - Fetch BNP Materail			
			FetchBNBMaterial: function (oContext) {
					BusyIndicator.showBusyIndicator();
					this._oModel.read("/BnBMaterialSet", {
						success: function (oData) {
							var bnbMaterialBnb = "";
							var bnbMatList = oData.results;
							if (bnbMatList && bnbMatList.length > 0) {
								for (var i = 0; i < bnbMatList.length; i++) {
									if (bnbMatList[i].Matnr) {
										if (bnbMaterialBnb) {
											bnbMaterialBnb = bnbMaterialBnb + " and ";
										}
										bnbMaterialBnb = bnbMaterialBnb + "MaterialNo ne '" + bnbMatList[i].Matnr + "'";
									}
								}
							}
							oContext.oModel.setProperty("/BNBMaterial", bnbMaterialBnb);
							BusyIndicator.hideBusyIndicator();

						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
						}

					});
				}
				// End SHE0272 - LLMBNB3.0 - Fetch BNP Materail
		};

	});