/*&----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2019.02.03                                           *
 * Incidinet      : EAM-ASR3413183 - PM Loco Main phase 2                *
 * Description    : Added unavailability reasons read                    *
 *&----------------------------------------------------------------------*/
/* #DontDelete : Yann */
jQuery.sap.declare("com.sap.cp.lm.model.craft.CraftDataModel");

sap.ui.define(["com/sap/cp/lm/util/Constants",
		"com/sap/cp/lm/util/Formatter",
		"com/sap/cp/lm/util/ErrorManager",
		"com/sap/cp/lm/util/BusyIndicator"
	],
	function (Constants, Formatter, ErrorManager, BusyIndicator) {
		"use strict";
		var _this;
		return com.sap.cp.lm.model.craft.CraftDataModel = {

			/* #DontDelete : Yann */
			/**
			 * Initialize of craft data model
			 * @param(object) oMainModel is the main model
			 * @param(object) oGlobalCraftModel is the global craft model
			 * @param(object) oGlobalModel is the global model
			 */
			init: function (oMainModel, oGlobalCraftModel, oGlobalModel) {
				_this = this;
				this._oModel = oMainModel;
				this.oGlobalCraftModel = oGlobalCraftModel;
				this.oGlobalModel = oGlobalModel;
			},

			/* #DontDelete : Yann */
			/**
			 * Returns the history of WorkOrders of locomotive for a given timeframe for a shop
			 * @param {function} fnSuccessCallBack is the callback function that would be executed on OData success callback
			 * @param {function} fnErrorCallBack is the callback function that would be executed on OData error callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * @param {string} sOrderNumber is the workOrder number
			 * 
			 */
			fetchAvailabilityForShopAndCraft: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {

				// GetCraftAvailability?Shop='1883'&PersonNo='12345678'&FromDate=datetime'2017-10-01T00:00:00'&ToDate=datetime'2017-10-31T00:00:00'&$format=json

				this._oModel.read("/GetCraftAvailability", {
					urlParameters: {
						"Shop": "'" + oPayload.Shop + "'",
						"PersonNo": "'" + oPayload.PersonNo + "'",
						"FromDate": "datetime'" + oPayload.FromDate + "'",
						"ToDate": "datetime'" + oPayload.ToDate + "'",
						"$format": "json"
					},
					success: function (oData) {
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						ErrorManager.handleError(oError);
						BusyIndicator.hideBusyIndicator();
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						} else {
							BusyIndicator.hideBusyIndicator();
						}
					}
				});

			},

			/* #DontDelete : Yann */
			/** 
			 * submit Create or update the availability for a Craft
			 * @param {object}   oPayload 
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			setAvailabilityForShopAndCraft: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				/*
				
				/sap/opu/odata/sap/ZPM_LM_SRV/CraftAvailSet
 
				{
				  "d" : {
				    "ShopId" : "1883",
				    "PersonNo" : "12345678",                        (Craft ID, Personnel Number)
				    "AvailDate" : "2017-10-24T00:00:00",    (Date of availability start.  Note: Availability end time may be on the next day)
				    "AvailStatus" : "A",                                     (“A” = Available; “U” = Unavailable)         
				    "AvailStart" : "PT07H00M00S",
				    "AvailEnd" : "PT15H00M00S",
				    "OtStart" : "PT15H00M00S",                    (optional)
				    "OtEnd" : "PT19H00M00S"                       (optional)
				  }
				}
				
				
				*/

				BusyIndicator.showBusyIndicator();

				this._oModel.create("/CraftAvailSet",
					oPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							}
						}
					});
			},

			/* #DontDelete : Yann */
			/**
			 * submit batch Create or update the availability for a Craft
			 * @param {object}   aPayloads array of payloads to send
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 */

			setBatchAvailabilityForShopAndCraft: function (aPayloads, fnSuccessCallBack, fnErrorCallBack, oContext) {

				BusyIndicator.showBusyIndicator();

				this._oModel.setUseBatch(true);

				var mParameters = {
					groupId: "_setCraftAvailability",
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				};

				this._oModel.setDeferredBatchGroups(["_setCraftAvailability"]);

				for (var i = 0; i < aPayloads.length; i++) {
					var oPayload = aPayloads[i];
					_this._oModel.create("/CraftAvailSet",
						oPayload, {
							groupId: "_setCraftAvailability",
							changeSetId: Math.random()
						}
					);
				}

				this._oModel.submitChanges(mParameters);

			},

			/*** legacy code below - TODO : check clean remove */

			/** 
			 * Read the craft assignment list
			 * @param(string) shopId is the current shop id
			 * @param(function) successCallBack is the callback function for success
			 * @param(function) errorCallBack is the callback function for error
			 * @param(oContext) oContext is the current view context
			//  */
			// getShopCraftAssignList: function(shopId, successCallBack, errorCallBack, oContext) {
			// 	var oGlobalModel = this.oGlobalModel;
			// 	//shopId = !shopId ? oGlobalModel.getProperty("/currentShop").Id : shopId;
			// 	if (!shopId) {
			// 		if (oGlobalModel.getProperty("/currentShop")) {
			// 			shopId = oGlobalModel.getProperty("/currentShop").Id;
			// 		} else {
			// 			shopId = oGlobalModel.getProperty("/currentUser").DefaultShopId
			// 		}
			// 	}
			// 	var currentShift = oGlobalModel.getProperty("/currentShift");
			// 	var dStart = new Date(0);
			// 	var dEnd = new Date();
			// 	if (currentShift) {
			// 		dStart = currentShift.StartDateTime;
			// 		dEnd = currentShift.EndDateTime;
			// 	}
			// 	BusyIndicator.showBusyIndicator();

			// 	var oAssignCraftModel = new sap.ui.model.json.JSONModel();
			// 	this._oModel.callFunction("/GetAssignmentsByShift", {
			// 		urlParameters: {
			// 			"Shop": shopId,
			// 			"PeriodStart": dStart,
			// 			"PeriodEnd": dEnd
			// 		},
			// 		success: function(oData) {
			// 			oAssignCraftModel.setData(oData);
			// 			_this.oGlobalCraftModel.setData(oData);
			// 			BusyIndicator.hideBusyIndicator();
			// 			if (successCallBack && oContext) {
			// 				successCallBack.apply(oContext, [oAssignCraftModel]);
			// 			};
			// 		},
			// 		error: function(oError) {
			// 			BusyIndicator.hideBusyIndicator();
			// 			successCallBack.apply(oContext, [oAssignCraftModel]);
			// 			//ErrorManager.handleError(oError);
			// 		}
			// 	});
			// },

			// /** 
			//  * Read the craft's Group set
			//  * @param(string) shopId is the current shop id
			//  * @param(function) successCallBack is the callback function for success
			//  * @param(function) errorCallBack is the callback function for error
			//  * @param(oContext) oContext is the current view context
			//  */
			// getUserGroupSet: function(sShopId, successCallBack, errorCallBack, oContext) {
			// 	BusyIndicator.showBusyIndicator();
			// 	this._oModel.read("/UserGroupSet", {
			// 		urlParameters: {
			// 			"$filter": "ShopId eq '" + sShopId + "' "
			// 		},
			// 		success: function(oData) {
			// 			BusyIndicator.hideBusyIndicator();
			// 			if (successCallBack && oContext) {
			// 				successCallBack.apply(oContext, [oData]);
			// 			};
			// 		},
			// 		error: function(oError) {
			// 			BusyIndicator.hideBusyIndicator();
			// 			ErrorManager.handleError(oError);
			// 		}
			// 	});

			// // },

			/* #DontDelete : Q */
			/** 
			 * Read the craft assignment set regardless of shift
			 * @param(string) shopId is the current shop id
			 * @param(function) successCallBack is the callback function for success
			 * @param(function) errorCallBack is the callback function for error
			 * @param(oContext) oContext is the current view context
			 */
			getShopCraftAssignmentSet: function (shopId, successCallBack, errorCallBack, oContext) {
				var oGlobalModel = _this.oGlobalModel;
				shopId = !shopId ? oGlobalModel.getProperty("/currentShop").Id : shopId; //TODO? - see getShopCraftAssignList
				BusyIndicator.showBusyIndicator();
				var oAssignCraftModel = new sap.ui.model.json.JSONModel();

				this._oModel.read("/ShopSet('" + shopId + "')", {
					urlParameters: {
						"$expand": "UserInfoSet",
						"$format": "json"
					},
					success: function (oData) {
						oAssignCraftModel.setData(oData);
						_this.oGlobalCraftModel.setData(oData);
						BusyIndicator.hideBusyIndicator();
						if (successCallBack && oContext) {
							successCallBack.apply(oContext, [oAssignCraftModel]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
			},

			/* #DontDelete : Yann */
			/**
			 * Returns the shifts description for the given shop id
			 * @param {string}	 sShopId id of the shop to retrieve info on
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			fetchCraftShiftFilters: function (sShopId, fnSuccessCallBack, fnErrorCallBack, oContext) {
				// /sap/opu/odata/sap/ZPM_LM_SRV/GetCraftListShiftFilters?ShopId='1883'&$format=json
				BusyIndicator.showBusyIndicator();
				this._oModel.read("/GetCraftListShiftFilters", {
					urlParameters: {
						"ShopId": "'" + sShopId + "'",
						"$format": "json"
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},
			/*Added by Vikram*/
			fetchUnavailabilityReasons: function () {
					var oGlobalModel = this.oGlobalModel;
					this._oModel.read("/ZPM_LM_VH_UNAVAIL_REASON", {
						success: function (oData) {
							oGlobalModel.setProperty("/unavailReasons", oData.results);
						},
						error: function (oError) {
							ErrorManager.handleError(oError);
						}
					});
				}
				/*Added by Vikram*/
				// /**
				//  * Assign Selected Craft to current shift
				//  * @param(object) oCreateCraftPayload is the payload data
				//  * @param(function) successCallBack is the callback function for success
				//  * @param(function) errorCallBack is the callback function for error
				//  * @param(oContext) oContext is the current view context
				//  */
				// AddCraftToCurrentShift: function(oCreateCraftPayload, successCallBack, errorCallback, oContext) {
				// 	BusyIndicator.showBusyIndicator();
				// 	this._oModel.create("/ShiftSet",
				// 		oCreateCraftPayload, {
				// 			success: function(oData) {
				// 				BusyIndicator.hideBusyIndicator();
				// 				if (successCallBack && oContext) {
				// 					successCallBack.apply(oContext);
				// 				}

			// 			},
			// 			error: function(oError) {
			// 				BusyIndicator.hideBusyIndicator();
			// 				ErrorManager.handleError(oError);
			// 				if (errorCallback && oContext) {
			// 					errorCallback.apply(oContext, [oOperationWONumer, BusyIndicator]);
			// 				}
			// 			},

			// 		});

			// },
			// /***
			//  * create operations for assign craft 
			//  * @param(object) oCreateAssignmentPayload is the payload data
			//  * @param(function) successCallBack is the callback function for success
			//  * @param(function) errorCallBack is the callback function for error
			//  * @param(oContext) oContext is the current view context
			//  * @param(string) oOperationWONumer is the operation number
			//  * @param(string) batchGroupId is the id for the batch call
			//  */
			// onCreateOperationAssignemt: function(oCreateAssignmentPayload, successCallBack, errorCallback, oContext, oOperationWONumer,
			// 	batchGroupId) {
			// 	this._oModel.create("/AssignmentSet",
			// 		oCreateAssignmentPayload, {
			// 			batchGroupId: batchGroupId,
			// 			changeSetId: Math.random()
			// 		});
			// },
			// /***
			//  * delete operations for assign craft
			//  * @param(string) oOperationWONumer is the operation number
			//  * @param(function) successCallBack is the callback function for success
			//  * @param(function) errorCallBack is the callback function for error
			//  * @param(oContext) oContext is the current view context
			//  * @param(string) batchGroupId is the id for the batch call
			//  *  
			//  */
			// onDeleteOperationAssignemt: function(oOperationWONumer, successCallBack, errorCallback, oContext, batchGroupId) {
			// 	var str = "/AssignmentSet(WorkOrderNum=\'" + oOperationWONumer.WorkOrderNum + "\',OperationNumber=\'" + oOperationWONumer.OperationNumber +
			// 		"\',PersonnelNumber=\'" + oOperationWONumer.PersonnelNumber + "\')";
			// 	this._oModel.remove(str, {
			// 		batchGroupId: batchGroupId,
			// 		changeSetId: Math.random()
			// 	});
			// },

			// /** 
			//  * Read the work plan for a person for a period/shift
			//  * @param(string) sPersonnelNumber is the personnel number of the craft person
			//  * @param(function) successCallBack is the callback function for success
			//  * @param(function) errorCallBack is the callback function for error
			//  * @param(oContext) oContext is the current view context
			//  * @param(object) oController is the controller object
			//  */
			// fetchCraftWorkPlanDataForCraft: function(sPersonnelNumber, successCallBack, errorCallBack, oContext, oController, sLocoNumber,
			// 	oStartDate) {

			// 	var sShopId = this.oGlobalModel.getProperty("/currentShop").Id;

			// 	var urlParams = {
			// 		"PersonnelNumber": sPersonnelNumber,
			// 		"ShopId": sShopId,
			// 		"LocomotiveNumber": sLocoNumber,
			// 		"$expand": "WorkPlanSet/GroupSet/OperationSet/TaskSet,GroupSet/OperationSet,GroupSet/OperationSet/TaskSet,GroupSet/OperationSet/MaterialSet,WorkPlanSet/WorkOrderSet/OperationSet,WorkPlanSet/WorkOrderSet/OperationSet/TaskSet,WorkPlanSet/WorkOrderSet/OperationSet/MaterialSet"
			// 	};

			// 	var currentShift = this.oGlobalModel.getProperty("/currentShift");
			// 	urlParams.PeriodStart = oStartDate ? oStartDate : currentShift.StartDateTime;
			// 	urlParams.PeriodEnd = currentShift.EndDateTime;

			// 	this._oModel.callFunction("/GetAssignmentsByPersonnel", {
			// 		urlParameters: urlParams,
			// 		success: function(oData) {
			// 			BusyIndicator.hideBusyIndicator();
			// 			if (successCallBack && oContext) {
			// 				successCallBack.apply(oContext, [oData, oController, sLocoNumber]);
			// 			};
			// 		},
			// 		error: function(oError) {
			// 			BusyIndicator.hideBusyIndicator();
			// 			ErrorManager.handleError(oError);
			// 			if (errorCallBack && oContext) {
			// 				errorCallBack.apply(oContext, [oData]);
			// 			};
			// 		}
			// 	});
			// },

			// /**
			//  * Fetch the craft status of completed/assigned operations for the current shift
			//  * @param(function) successCallBack is the callback function for success
			//  * @param(function) errorCallBack is the callback function for error
			//  * @param(oContext) oContext is the current view context
			//  */
			// fetchCraftStats: function(successCallBack, errorCallBack, oContext) {
			// 	var currentShift = this.oGlobalModel.getProperty("/currentShift");
			// 	var currentUser = this.oGlobalModel.getProperty("/currentUser");
			// 	this._oModel.callFunction("/GetCraftStats", {
			// 		urlParameters: {
			// 			"PersonnelNumber": currentUser.PersonnelNumber,
			// 			"StartDateTime": currentShift.StartDateTime,
			// 			"EndDateTime": currentShift.EndDateTime
			// 		},
			// 		success: function(oData) {
			// 			if (successCallBack && oContext) {
			// 				successCallBack.apply(oContext, [oData]);
			// 			};
			// 		},
			// 		error: function(oError) {
			// 			if (errorCallBack && oContext) {
			// 				errorCallBack.apply(oContext, [oError]);
			// 			};
			// 		}
			// 	});
			// },

			// /**
			//  * Fetch the craft status of completed/assigned operations for the current shift
			//  * @param(string) sPersonnelNumber is the personnel number of the craft person
			//  * @param(string) dateEnd is the ending date
			//  * @param(function) successCallBack is the callback function for success
			//  * @param(function) errorCallBack is the callback function for error
			//  * @param(oContext) oContext is the current view context
			//  */
			// fetchEmployeeHistory: function(sPersonnelNumber, dateStart, dateEnd, successCallBack, errorCallBack, oContext) {
			// 	this._oModel.callFunction("/GetEmployeeHistory", {
			// 		urlParameters: {
			// 			"PersonnelNumber": sPersonnelNumber,
			// 			"StartDate": dateStart,
			// 			"EndDate": dateEnd,
			// 			"$expand": "OperationSet/ConfirmationSet,OperationSet/TaskSet"
			// 		},
			// 		success: function(oData) {
			// 			BusyIndicator.hideBusyIndicator();
			// 			if (successCallBack && oContext) {
			// 				successCallBack.apply(oContext, [oData]);
			// 			};
			// 		},
			// 		error: function(oError) {
			// 			BusyIndicator.hideBusyIndicator();
			// 			ErrorManager.handleError(oError);
			// 			if (errorCallBack && oContext) {
			// 				errorCallBack.apply(oContext, [oError]);
			// 			};
			// 		}
			// 	});
			// },

			// /**
			//  * assign and reassign users in batch
			//  */
			// submitBatchAssignWorkers: function(batchChanges, fnSuccessCallBack, oContext, BusyIndicator) {
			// 	this._oModel.submitChanges({
			// 		batchGroupId: batchChanges,
			// 		success: function(oData) {
			// 			if (fnSuccessCallBack && oContext) {
			// 				fnSuccessCallBack.apply(oContext, [oData, BusyIndicator]);
			// 			}
			// 		},
			// 		error: function(oError) {
			// 			BusyIndicator.hideBusyIndicator();
			// 		}
			// 	});
			// },

			// /**
			//  * function to fetch groupset
			//  */
			// fetchGroupSet: function(sGroupID, successCallBack, oContext) {
			// 	BusyIndicator.showBusyIndicator();
			// 	this._oModel.read("/GroupSet('" + sGroupID + "')", {
			// 		urlParameters: {
			// 			"$expand": "OperationSet/TaskSet"
			// 		},
			// 		success: function(oData) {
			// 			BusyIndicator.hideBusyIndicator();
			// 			if (successCallBack && oContext) {
			// 				successCallBack.apply(oContext, [oData]);
			// 			};
			// 		},
			// 		error: function(oError) {
			// 			BusyIndicator.hideBusyIndicator();
			// 			ErrorManager.handleError(oError);
			// 		}
			// 	});
			// },

			// /**
			//  * Fetch Assignments by Groups
			//  * @param(string) sGroups is the concatenated groups's name string
			//  * @param(function) successCallBack is the callback function for success
			//  * @param(oContext) oContext is the current view context
			//  * @param(string) sFilterGroup is the concatenated groups's name string
			//  */
			// fetchAssignmentsByGroups: function(aGroups, successCallBack, oContext, sFilterGroup, aAvailHrsFilter, oEvt) {

			// 	BusyIndicator.showBusyIndicator();
			// 	var oGlobalModel = _this.oGlobalModel;
			// 	//shopId = !shopId ? oGlobalModel.getProperty("/currentShop").Id : shopId;
			// 	var sShopId = "";
			// 	if (oGlobalModel.getProperty("/currentShop")) {
			// 		sShopId = oGlobalModel.getProperty("/currentShop").Id;
			// 	}

			// 	this._oModel.read("/GetAssignmentsByGroups", {
			// 		urlParameters: {
			// 			"Shop": "'" + sShopId + "'",
			// 			"Groups": "'" + aGroups.join(Constants.GROUP_SEPERATOR) + "'"
			// 		},
			// 		success: function(oData) {
			// 			BusyIndicator.hideBusyIndicator();
			// 			if (successCallBack && oContext) {
			// 				successCallBack.apply(oContext, [oData, sFilterGroup, aAvailHrsFilter, oEvt]);
			// 			};
			// 		},
			// 		error: function(oError) {
			// 			BusyIndicator.hideBusyIndicator();
			// 			ErrorManager.handleError(oError);
			// 		}
			// 	});
			// },
			// /** 
			//  * Read the craft assignment list
			//  * @param(string) shopId is the current shop id
			//  * @param(function) successCallBack is the callback function for success
			//  * @param(function) errorCallBack is the callback function for error
			//  * @param(oContext) oContext is the current view context
			//  */
			// getShopCraftAssignReplanList: function(shopId, successCallBack, errorCallBack, oContext, oShift) {
			// 	var oGlobalModel = this.oGlobalModel;
			// 	if (!shopId) {
			// 		if (oGlobalModel.getProperty("/currentShop")) {
			// 			shopId = oGlobalModel.getProperty("/currentShop").Id;
			// 		} else {
			// 			shopId = oGlobalModel.getProperty("/currentUser").DefaultShopId
			// 		}
			// 	}
			// 	var currentShift = oGlobalModel.getProperty("/currentShift");
			// 	var dStart = new Date(0);
			// 	var dEnd = new Date();
			// 	if (oShift) {
			// 		dStart = oShift.StartDateTime;
			// 		dEnd = oShift.EndDateTime;
			// 	} else {
			// 		dStart = currentShift.StartDateTime;
			// 		dEnd = currentShift.EndDateTime;
			// 	}
			// 	BusyIndicator.showBusyIndicator();

			// 	var oAssignCraftModel = new sap.ui.model.json.JSONModel();
			// 	this._oModel.callFunction("/GetShiftPlanningSummary", {
			// 		urlParameters: {
			// 			"Shop": shopId,
			// 			"PeriodStart": dStart,
			// 			"PeriodEnd": dEnd
			// 		},
			// 		success: function(oData) {
			// 			oAssignCraftModel.setData(oData);
			// 			//_this.oGlobalCraftModel.setData(oData);
			// 			BusyIndicator.hideBusyIndicator();
			// 			if (successCallBack && oContext) {
			// 				successCallBack.apply(oContext, [oAssignCraftModel]);
			// 			};
			// 		},
			// 		error: function(oError) {
			// 			BusyIndicator.hideBusyIndicator();
			// 			successCallBack.apply(oContext, [oAssignCraftModel]);
			// 			//ErrorManager.handleError(oError);
			// 		}
			// 	});
			// }

		};
	});