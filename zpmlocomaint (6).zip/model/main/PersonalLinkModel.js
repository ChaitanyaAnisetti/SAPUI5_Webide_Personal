/* #DontDelete : Yann */
sap.ui.define([
               "com/sap/cp/lm/util/Constants",
               "com/sap/cp/lm/util/BusyIndicator",
               "com/sap/cp/lm/util/ErrorManager",
               ], function(Constants,BusyIndicator,ErrorManager) {
	"use strict";

	jQuery.sap.declare("com.sap.cp.lm.model.main.PersonalLinkModel");

	return com.sap.cp.lm.model.main.PersonalLinkModel = {
			/**
			 * Initializes this manager
			 * @param {sap.ui.core.Component} is the ui5 component
			 */
			init : function(oComponent) {
				this._oModel = oComponent.getModel(Constants.ZPMLM_MODEL);
			},

			/**
			 * Create a link, this function garantees that the service will be called with the 
			 * payload in the object oData and call the successCallback when successful. When the function
			 * fails it will display an error to the user
			 */
			createLink: function(oData, successCallback) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/LinkSet",oData, {
					success: function(oResult) {
						BusyIndicator.hideBusyIndicator();
						successCallback(oResult);
					},
					error: function(oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}.bind(this)
				});				
			},

			/**
			 * Update a link, this function garantees that the service will be called with the 
			 * payload in the object oData and call the successCallback when successful. When the function
			 * fails it will display an error to the user
			 */
			updateLink: function(oData, successCallback) {
				BusyIndicator.showBusyIndicator();
				this._oModel.update("/LinkSet('"+oData.Guid+"')",
						oData,
						{
					merge: false,
					success: function(oResult) {
						BusyIndicator.hideBusyIndicator();
						successCallback(oResult);
					},
					error: function(oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}.bind(this)
						});				
			},
			
			/**
			 * Delete a link, this function garantees that the service will be called with the 
			 * payload in the object oData and call the successCallback when successful. When the function
			 * fails it will display an error to the user
			 */
			deleteLink: function(sGuid, successCallback) {
				BusyIndicator.showBusyIndicator();
				this._oModel.remove("/LinkSet('"+sGuid+"')",
						{
					success: function(oResult) {
						BusyIndicator.hideBusyIndicator();
						successCallback(oResult);
					},
					error: function(oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}.bind(this)
						});				
			}
	};
});