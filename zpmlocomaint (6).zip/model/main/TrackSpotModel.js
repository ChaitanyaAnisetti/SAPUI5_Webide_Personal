/* #DontDelete : Yann */
/*&----------------------------------------------------------------------*    
 * Author         : SHE0272                                              *
 * Date           : 14.Jun.2021                                          *
 * Incidinet      : LLM2.29 - Road/Yard Repair			              	 *
 * Description    : new method to get track and spot dropdown values	 *
					for Road/Yard Repair								 *
 * Search Term    : LLM2.29                                              *
 *&----------------------------------------------------------------------*/

sap.ui.define([
               "com/sap/cp/lm/util/Constants",
               "com/sap/cp/lm/util/BusyIndicator",
               "com/sap/cp/lm/util/ErrorManager",
               ], function(Constants,BusyIndicator,ErrorManager) {
	"use strict";

	jQuery.sap.declare("com.sap.cp.lm.model.main.TrackSpotModel");

	return com.sap.cp.lm.model.main.TrackSpotModel = {
			/**
			 * Initializes this manager
			 * @param {sap.ui.core.Component} is the ui5 component
			 */
			init : function(oComponent) {
				this._oModel = oComponent.getModel(Constants.ZPMLM_MODEL);
			},
			
			/**
			 * fetch available tracks and spots
			 */
			 
			fetchAvailableTracksSpots: function(sShopId,fSuccessCallback,fFailureCallback) {

				BusyIndicator.showBusyIndicator();
				this._oModel.read("/ShopSet('" + sShopId + "')", {
					urlParameters: {
						"$expand": "AvailTrackSet/AvailSpots",
						"$format": "json"
					},
					success: function(oResult) {
						BusyIndicator.hideBusyIndicator();
						if (fSuccessCallback) {
							fSuccessCallback(oResult);
						}						
					},
					error: function(oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fFailureCallback) {
							fFailureCallback(oError);
						}
					}
				});				
			},
			
			// Start - SHE0272: LLM2.29 - Road/Yard Repair - New method to get the dropdown values based on the process type
			/**
			 * fetch available tracks and spots for specific process
			 */
			 
			fetchAvailableProcessSpecificTracksSpots: function(url,urlParameters,fSuccessCallback,fFailureCallback) {

				BusyIndicator.showBusyIndicator();
				this._oModel.read(url, {
					urlParameters: urlParameters,
					success: function(oResult) {
						BusyIndicator.hideBusyIndicator();
						if (fSuccessCallback) {
							fSuccessCallback(oResult);
						}						
					},
					error: function(oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fFailureCallback) {
							fFailureCallback(oError);
						}
					}
				});				
			},
			
			// End - SHE0272: LLM2.29 - Road/Yard Repair - New method to get the dropdown values based on the process type
			
			/**
			 * fetch shop task list
			 */
			fetchServicingTasklists: function(sShopId,fSuccessCallback,fFailureCallback) {

				BusyIndicator.showBusyIndicator();
				this._oModel.read("/GetServicingTasklists", {
					urlParameters: {
						"ShopId": "'" + sShopId + "'",
						"$format": "json"
					},
					success: function(oResult) {
						BusyIndicator.hideBusyIndicator();
						if (fSuccessCallback) {
							fSuccessCallback(oResult);
						}						
					},
					error: function(oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fFailureCallback) {
							fFailureCallback(oError);
						}
					}
				});
				
			},
			
			/**
			 * fetch shop task list
			 */
			fetchServicingTasklistNotifications: function(sShopId,sEquipmentNumber,sTasklistGroupKey,fSuccessCallback,fFailureCallback) {

				BusyIndicator.showBusyIndicator();
				this._oModel.read("/GetServicingTasklistNotificationsForLoco", {
					urlParameters: {
						"ShopId": "'" + sShopId + "'",
						"Equipment": "'" + sEquipmentNumber + "'",
						"TasklistGroupKey": "'" + sTasklistGroupKey + "'",
						"$format": "json"
					},
					success: function(oResult) {
						BusyIndicator.hideBusyIndicator();
						if (fSuccessCallback) {
							fSuccessCallback(oResult);
						}						
					},
					error: function(oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fFailureCallback) {
							fFailureCallback(oError);
						}
					}
				});
				
			}
	};
});