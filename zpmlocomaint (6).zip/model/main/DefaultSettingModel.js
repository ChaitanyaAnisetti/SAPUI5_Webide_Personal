/* #DontDelete : Yann */
sap.ui.define([
               "com/sap/cp/lm/util/Constants",
               "com/sap/cp/lm/util/BusyIndicator",
               "com/sap/cp/lm/util/ErrorManager",
               ], function(Constants,BusyIndicator,ErrorManager) {
	"use strict";

	jQuery.sap.declare("com.sap.cp.lm.model.main.DefaultSettingModel");

	return com.sap.cp.lm.model.main.DefaultSettingModel = {
			/**
			 * Initializes this manager
			 * @param {sap.ui.core.Component} is the ui5 component
			 */
			init : function(oComponent) {
				this._oModel = oComponent.getModel(Constants.ZPMLM_MODEL);
			},

			/**
			 * Update Default Settings for the user, this function garantees that the service will be called with the 
			 * payload in the object oData and call the successCallback when successful. When the function
			 * fails it will display an error to the user
			 */
			updateSettings: function(oData, successCallback) {
				BusyIndicator.showBusyIndicator();
				this._oModel.update("/UserInfoSet('')",
						oData,
						{
					merge: false,
					success: function(oResult) {
						BusyIndicator.hideBusyIndicator();
						if (successCallback) {
							successCallback(oResult);
						}						
					},
					error: function(oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});				
			}	
	};
});