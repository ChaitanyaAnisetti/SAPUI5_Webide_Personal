/*&--------------------------------------------------------------------------*    
 * Author/Changed By   : Sandhya satavalekar                                  *
 * Date  			  : 10-Feb-2019                                          *
 * Project             : Locomotive Maintenance Phase 2                       *
 * Description         : LMP2-16: Get the Loco Charactsristics                *
 * Search Term         : LMP2-16                                              *
 *&---------------------------------------------------------------------------*/
/*&--------------------------------------------------------------------------*    
 * Author/Changed By   : Sandhya satavalekar                                  *
 * Date                : 02-Feb-2019                                          *
 * Project             : Locomotive Maintenance Phase 2                       *
 * Description         : LMP2-05: Change the Loco User Status                 *
 * Search Term         : LMP2-05                                              *
 *&---------------------------------------------------------------------------*/
/*&--------------------------------------------------------------------------*    
 * Author/Changed By   : Sandhya satavalekar                                  *
 * Date                : 02-Feb-2019                                          *
 * Project             : Locomotive Maintenance Phase 2                       *
 * Description         : LMP2-02 : Adding the unTeco Option 	                 *
 * Search Term         : LMP2-02                                              *
 *&---------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
* Author/Changed By   : Sandesh Shirode(SHI0087)	               		  *
* Date                : 15-April-2019                                     *
* Project             : Locomotive Maintenance Phase 2                    *
* Description         : LMP2-7a : Add attachment functionality to be view  *
						from OPeration screen							  *
*&------------------------------------------------------------------------*/
/*&--------------------------------------------------------------------------*    
 * Author/Changed By   : KIR0084			                                     *
 * Date                : 16-Apr-2019                                          *
 * Project             : Locomotive Maintenance Phase 2                       *
 * Description         : LMP2-28 : Add cancel inbound action	                 *
 * D                     LMP2-28 : Add filter inbound action	                 *
 * Search Term         : LMP2-28                                              *
 *&---------------------------------------------------------------------------*/
/*&--------------------------------------------------------------------------*    
 * Author/Changed By   : KIR0084			                                     *
 * Date                : 12-May-2019                                          *
 * Project             : Locomotive Maintenance Phase 2                       *
 * Description         : LMP2-36 : Add handler for SetOperationLongText action *
 * Search Term         : LMP2-36                                              *
 *&---------------------------------------------------------------------------*/
/*&--------------------------------------------------------------------------*    
 * Author/Changed By   : SAT0008			                                     *
 * Date                : 29-May-2019                                          *
 * Project             : Locomotive Maintenance Phase 2                       *
 * Description         : LMP2-40 : Add NOCO to notification screen            *
 * Search Term         : LMP2-40                                              *
 *&---------------------------------------------------------------------------*/
/*&--------------------------------------------------------------------------*    
 * Author/Changed By   : KIR0084			                                     *
 * Date                : 31-May-2019                                          *
 * Project             : Locomotive Maintenance Phase 2                       *
 * Description         : LMP2-32 : Add function for turnover doc report       *
 * Search Term         : LMP2-32                                              *
 *&---------------------------------------------------------------------------*/
/*&--------------------------------------------------------------------------*    
 * Author/Changed By   : VYA0004			                                     *
 * Date                : 31-July-2019                                         *
 * Project             : Locomotive Hierarchy Project                         *
 * Description         : LMP2-HIE-002 : Update TaskList logic                 *
 * Search Term         : VYA0004 LMP2-HIE-002                                 *
 *&---------------------------------------------------------------------------*/
/*&--------------------------------------------------------------------------*    
 * Author         : Sandesh Shirode(SHI0087)                            	 *
 * Date           : 23.Aug.2019                                         	 *
 * Project        : Locomotive Maintenance Phase 2  			   			 *
 * Description    : LMP2-25 - WheelSheet Measurement Approval           	 *
 * Search Term    : LMP2-25                                             	 *
 *&-------------------------------------------------------------------------*/
/*&--------------------------------------------------------------------------*    
 * Author/Changed By   : KIR0084			                                     *
 * Date                : 27-Aug-2019                                          *
 * Project             : Locomotive Maintenance Phase 2                       *
 * Description         : LMP2-33 : Handle RemoveCraftsForShiftEnd action      *
 * Search Term         : LMP2-33                                              *
 *&---------------------------------------------------------------------------*/
/*&--------------------------------------------------------------------------*    
 * Author/Changed By   : BAJ0018	                                         *
 * Date                : 13-Oct-2020                                         *
 * Project             : EAM-INC0027575-LM Wheel Sheet                       *
 * Description         : Bug fixed related to  wheel sheet payload           *
 * Search Term         : EAM-INC0027575                                      *
 *&---------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : BAJ0018				        		       		   *
* Date                : 19 -Feb -2021                                      *
* Project             : BNB Project                                        *
* Description         : Added BNB Storage locations logic                  *
* Search Term         : BNB                                                *
/*&------------------------------------------------------------------------*/
/*&--------------------------------------------------------------------------*    
 * Author/Changed By   : VYA0004	                                         *
 * Date                : 20-Jan-2021                                         *
 * Project             : Break and Build Project                             *
 * Description         : Adding calls for BnB Inventory retrieval, Refurb Ord Creation*
 * Search Term         : BnB VYA0004 MOD0013 2000011826                                 *
 *&---------------------------------------------------------------------------*/
/* #DontDelete : Yann */
/*&----------------------------------------------------------------------*    
 * Author         : SHE0272                                              *
 * Date           : 08.Jun.2021                                          *
 * Incidinet      : LLM2.29 - Road/Yard Repair			              	 *
 * Description    : new button press handler for road/yard repair		 *
 * Search Term    : LLM2.29                                              *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2021.07.26                                           *
 * Description    : LMP-2.28 Update USER STATUS                          *                   
 * Search Term    : UPDSTATUS                                            *
 *&----------------------------------------------------------------------*/
/*&--------------------------------------------------------------------------*    
 * Author/Changed By   : BAJ0018	                                         *
 * Date                : 17-Nov-2021                                         *
 * Project             : EAM-INC0127935-LM Wheel Sheet                       *
 * Description         : Bug fixed related to  wheel sheet payload           *
 * Search Term         : EAM-INC0127935                                      *
 *&---------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 01-Dec-2021	                                       *
* Project             : EAM-LLM 1.2 Serialization     					   *
* Description         : Serialization of material and equipment			   *
* Search Term         : LLM1.2	                                           *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : ANI0006				        		       		   *
* Date                : 11-Nov-2021	                                       *
* Project             : EAM Railinc EPA    					               *
* Description         : EPA Information - Fields Masking		           *
* Search Term         : ANI0006 2000014601                                 *
/*&------------------------------------------------------------------------*/
jQuery.sap.declare("com.sap.cp.lm.model.locomotives.LocomotiveDataModel");

sap.ui.define([
		"com/sap/cp/lm/util/Constants",
		"com/sap/cp/lm/util/Formatter",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/util/ErrorManager",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		'sap/m/MessageBox'
	],
	function (Constants, Formatter, BusyIndicator, ErrorManager, Filter, FilterOperator, MessageBox) {
		"use strict";
		var _this;
		return com.sap.cp.lm.model.locomotives.LocomotiveDataModel = {

			/* #DontDelete : Yann */
			/**
			 * Initialize of locomotive datamodel
			 * @param(object) oMainModel is the main model
			 * @param(object) oGlobalCraftModel is the global craft model
			 * @param(object) oGlobalModel is the global model
			 * @param(object) oEngManfModel is the Engine Manufacturer  model
			 */
			init: function (oMainModel, oGlobalLocomotiveModel, oGlobalModel, oEngManfModel) {
				_this = this;
				this._oGlobalLocomotiveModel = oGlobalLocomotiveModel;
				this._oModel = oMainModel;
				this._oGlobalModel = oGlobalModel;
				//Start: ANI0006 2000014601 Initialize of Engine Manufacturer OData Model
				this._oEngManfModel = oEngManfModel;
				//End: ANI0006 2000014601 Initialize of Engine Manufacturer OData Model
			},

			/* #DontDelete : Yann */
			/**
			 * Returns the list of planned locomotives for a shop
			 * @param {string} sShopId is the search string entered
			 * @param {string} sShiftStartTs is the timestamps of the shift to retrieve
			 * @param {function} fnSuccessCallBack is the callback function that would be executed on OData success callback
			 * @param {function} fnErrorCallBack is the callback function that would be executed on OData error callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 */
			fetchPlannedLocomotives: function (sShopId, sShiftStartTs, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();
				this._oModel.read("/GetShoppedLocomotives", {
					urlParameters: {
						"plant": "'" + sShopId + "'",
						"ShiftStartTs": "'" + sShiftStartTs + "'",
						"IncludeDetails": true
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

			},

			/* #DontDelete : Yann */
			/**
			 * Returns the list of shopped locomotives for a shop
			 * @param {string} sShopId is the search string entered
			 * @param {function} fnSuccessCallBack is the callback function that would be executed on OData success callback
			 * @param {function} fnErrorCallBack is the callback function that would be executed on OData error callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * 
			 */
			fetchShoppedLocomotives: function (sShopId, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();
				this._oModel.read("/GetShoppedLocomotives", {
					urlParameters: {
						"plant": "'" + sShopId + "'",
						"ShiftStartTs": "'00000000000000'",
						"IncludeDetails": true
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

			},

			/**
			 * Returns the MSWheelSheet LMP2-25
			 * @param {function} fnSuccessCallBack is the callback function that would be executed on OData success callback
			 * @param {function} fnErrorCallBack is the callback function that would be executed on OData error callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * 
			 */
			fetchWSheetData: function (sOrderNbr, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				var aFilters = [];
				aFilters.push(new Filter("OrderNbr", FilterOperator.EQ, sOrderNbr));

				this._oModel.read("/MWSheetSet", {
					filters: aFilters,
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

			},

			/* #DontDelete : Yann */
			/**
			 * Returns the list of inbound locomotives for a shop
			 * @param {string} sShopId is the search string entered
			 * @param {function} fnSuccessCallBack is the callback function that would be executed on OData success callback
			 * @param {function} fnErrorCallBack is the callback function that would be executed on OData error callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * 
			 */
			fetchInboundLocomotives: function (sParamData, fnSuccessCallBack, fnErrorCallBack, oContext) {
				// KIR0084 LMP2-28 Filter Inbound Locomotives
				var urlParameters = {
					"IncludeDetails": true
				};

				// sParam data will either be a plant string or an object containing plant
				if (sParamData && sParamData.plant) {
					$.extend(urlParameters, sParamData);
				} else {
					urlParameters.plant = sParamData;
				}
				// KIR0084 LMP2-28 Filter Inbound Locomotives

				BusyIndicator.showBusyIndicator();
				this._oModel.callFunction("/GetInboundLocomotives", {
					urlParameters: urlParameters,
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});

			},

			/* #DontDelete : Yann */
			/***
			 * Read a single inbound locomotive
			 * @param(object)	oLocomotive is the inbound locomotive object
			 * @param(function) fnSuccessCallBack is the success callback function
			 * @param(function) fnErrorCallBack is the error callback function
			 * @param(object)	oContext is the controller object that implements the error and success call backs
			 * 
			 */

			fetchLocomotiveDefects: function (oLocomotive, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				var sEquip;
				if (oLocomotive) {
					if (oLocomotive.Equipment) {
						sEquip = oLocomotive.Equipment;
					} else {
						sEquip = oLocomotive.EquipNo;
					}
				}
				// Start - SHE0272: LLM2.29 - Added condition to get Defect type 'Z2' for RYR
				var filter = "EquipNo eq '" + sEquip + "' ";
				// if ((fnSuccessCallBack.name && fnSuccessCallBack.name === "_onFetchLocomotiveDefectsSuccessForRYR") || (oLocomotive.ShopReasonDet &&
				// 		oLocomotive.ShopReasonDet === "R")) {
				// 	filter = "EquipNo eq '" + sEquip + "' and DefectType eq 'Z2' ";
				// }
				// End - SHE0272: LLM2.29 - Added condition to get Defect type 'Z2' for RYR

				this._oModel.read("/DefectSet", {
					urlParameters: {
						"$filter": filter
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext, oLocomotive]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},

			// Start - SHE0272: LLM2.29 - To fetch the mandatory note for Road/Yard Repair process
			fetchMandatoryNote: function (suggestionValue, fnSuccessCallBack, fnErrorCallBack, oContext) {
				// BusyIndicator.showBusyIndicator();
				this._oModel.read("/MandtNoteFuzzySearch", {
					urlParameters: {
						"$filter": "StationName eq '" + suggestionValue + "'"
					},
					success: function (oData) {
						// BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						// BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},

			/* #DontDelete : Yann */
			/** 
			 * Defer an inbound locomotive defect to another shop
			 * @param {object}   oPayload is the payload generated to defer the defect, contains DefectNo,DeferCode,DeferDescr and ShopId
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			deferInboundLocomotiveDefect: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.callFunction("/DeferLocoDefect", {
					method: "POST",
					urlParameters: oPayload,
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},

			/* #DontDelete : Yann */
			/** 
			 * close a defect
			 * @param {string}   sOrderNumber is the defect order number
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */

			closeLocomotiveDefect: function (sOrderNumber, sOpr, sSubOpr, sApprovalFlag, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				//The URI is /sap/opu/odata/sap/ZPM_LM_SRV/SetWorkOrderTeco?OrderNumber='300099999'&$format=json . 

				this._oModel.callFunction("/SetWorkOrderTeco", {
					method: "POST",
					urlParameters: {
						"OrderNumber": sOrderNumber,
						"OprNum": sOpr,
						"SubOprNum": sSubOpr,
						"ApprovalFlag": sApprovalFlag,
						"$format": "json"
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},

			/* #DontDelete : Yann */
			/** 
			 * Add an inbound locomotive defect to current shop
			 * @param {object}   oPayload is the payload generated to defer the defect, contains DefectNo, ShopId and OrderType
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			adoptInboundLocomotiveDefect: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.callFunction("/AddDefectToPlan", {
					method: "POST",
					urlParameters: oPayload,
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},

			/* #DontDelete : Yann */
			/** 
			 * Add an shopped locomotive defect to current shop
			 * @param {object}   oPayload is the payload generated to defer the defect, contains DefectNo, ShopId and OrderType
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			adoptShoppedLocomotiveDefect: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.callFunction("/AddDefectToWorkPlan", {
					method: "POST",
					urlParameters: oPayload,
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},

			/* #DontDelete : Yann */
			/** 
			 * Depart locomotive from  current shop (remove it from the map)
			 * @param {object}   oPayload contains ShopId - LocoId
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			departLocomotive: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.callFunction("/DepartFromShop", {
					method: "POST",
					urlParameters: oPayload,
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},

			/* #DontDelete : Yann */
			/** 
			 * Release locomotive from  current shop
			 * @param {object}   oPayload contains ShopId - LocoId
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			//Start : LMP2-29 : Releasing Servicing Group			 
			releaseServGroup: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.callFunction("/ReleaseServGroup", {
					method: "POST",
					urlParameters: oPayload,
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						// if (fnSuccessCallBack && oContext) {
						// 	fnSuccessCallBack.apply(oContext, [oData, oContext]);
						// }
						MessageBox.show("Servicing Group released successfully", {
							icon: MessageBox.Icon.SUCCESS,
							title: "Success",
							styleClass: "successMessage",
							actions: [MessageBox.Action.OK]
						});
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},
			//End : LMP2-29 : Releasing Servicing Group			

			releaseLocomotive: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.callFunction("/ReleaseFromShop", {
					method: "POST",
					urlParameters: oPayload,
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},

			/*Added by Sandhya : LMP2-02 : Adding the unTeco Option */
			unTecoWO: function (oPayload) {
				BusyIndicator.showBusyIndicator();

				this._oModel.callFunction("/UnTecoWO", {
					method: "POST",
					urlParameters: oPayload,
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						MessageBox.show("Cancelling the work order completion successful", {
							icon: MessageBox.Icon.SUCCESS,
							title: "Success",
							styleClass: "successMessage",
							actions: [MessageBox.Action.OK]
						});
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						MessageBox.show("Cancelling the work order completion failed", {
							icon: MessageBox.Icon.ERROR,
							title: "Error",
							styleClass: "successMessage",
							actions: [MessageBox.Action.OK]
						});
					}
				});
			},
			/*End:Added by Sandhya : LMP2-02 : Adding the unTeco Option */
			// START - BAJ0018 - BNB
			bnbGoodsMvt: function (oPayload) {
				BusyIndicator.showBusyIndicator();
				this._oModel.callFunction("/BnbGoodsMvt", {
					method: "POST",
					urlParameters: oPayload,
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						MessageBox.show("Goods movement successfull", {
							icon: MessageBox.Icon.SUCCESS,
							title: "Success",
							styleClass: "successMessage",
							actions: [MessageBox.Action.OK]
						});
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						// MessageBox.show("Error occured during the goods movement", {
						// 	icon: MessageBox.Icon.ERROR,
						// 	title: "Error",
						// 	styleClass: "successMessage",
						// 	actions: [MessageBox.Action.OK]
						// });
					}
				});

			},
			// END - BAJ0018 - BNB
			/*Added by Sandhya : LMP2-40 : Add NOCO to notification screen */
			CompleteNotif: function (oPayload, fnSuccessCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.callFunction("/CompleteNotif", {
					method: "POST",
					urlParameters: oPayload,
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						MessageBox.show("Notification Completed successfully", {
							icon: MessageBox.Icon.SUCCESS,
							title: "Success",
							styleClass: "successMessage",
							actions: [MessageBox.Action.OK]
						});
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						MessageBox.show("Please TECO the work order or Enter closeout codes", {
							icon: MessageBox.Icon.ERROR,
							title: "Error",
							styleClass: "errorMessage",
							actions: [MessageBox.Action.OK]
						});
					}
				});
			},

			/*End:Added by Sandhya : LMP2-40 : Add NOCO to notification screen */
			/* #DontDelete : Yann */
			/** 
			 * Arrive an inbound locomotive to the current shop
			 * @param {object}   oPayload contains ShopId - LocoId - EquipNbr - ShoppedTimestamp - ShoppedTimezone - Track - Spot
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			arriveInboundLocomotive: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/ShoppedLocoSet",
					oPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);

							//BAPI error temporary managment
							if (oError.responseText && oError.responseText.includes("BAPI") === true) {
								if (fnSuccessCallBack && oContext) {
									fnSuccessCallBack.apply(oContext, [null, oContext]);
								}
							} else {
								if (fnErrorCallBack && oContext) {
									fnErrorCallBack.apply(oContext);
								}
							}
						}
					});
			},

			/*Added by KIR0084 : LMP2-33 : RemoveCraftsForShiftEnd action */
			removeCraftsForShiftEnd: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.callFunction("/RemoveCraftsForShiftEnd", {
					method: "POST",
					urlParameters: oPayload,
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);

						//BAPI error temporary managment
						if (oError.responseText && oError.responseText.includes("BAPI") === true) {
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [null, oContext]);
							}
						} else {
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							}
						}
					}
				});
			},
			/*End:Added by KIR0084 : LMP2-33 : RemoveCraftsForShiftEnd action */

			/*Added by KIR0084 : LMP2-28 : Add cancel inbound action */
			cancelInboundConfirmation: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.callFunction("/CancelInboundConfirmationForLocomotive", {
					method: "POST",
					urlParameters: oPayload,
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);

						//BAPI error temporary managment
						if (oError.responseText && oError.responseText.includes("BAPI") === true) {
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [null, oContext]);
							}
						} else {
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							}
						}
					}
				});
			},
			/*End:Added by KIR0084 : LMP2-28 : Add cancel inbound action */

			/*Added by KIR0084 : LMP2-36 : Set Operation Long Text action */
			setOperationLongText: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.callFunction("/SetOperationLongText", {
					method: "POST",
					urlParameters: oPayload,
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);

						//BAPI error temporary managment
						if (oError.responseText && oError.responseText.includes("BAPI") === true) {
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [null, oContext]);
							}
						} else {
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							}
						}
					}
				});
			},
			/*End:Added by KIR0084 : LMP2-36 : Set Operation Long Text action */

			/* #DontDelete : Yann */
			/***
			 * Read a single wheel sheet for an inbound locomotive
			 * @param(object)	oPayload contains Order Nbr, Operation Nbr, Equipment Nbr
			 * @param(function) fnSuccessCallBack is the success callback function
			 * @param(function) fnErrorCallBack is the error callback function
			 * @param(object)	oContext is the controller object that implements the error and success call backs
			 * 
			 */

			fetchLocomotiveWheelSheet: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.read("/MeasurementSetSet(OrderNbr='" + oPayload['OrderNbr'] + "',OperationNbr='" + oPayload['OperationNbr'] +
					"',SubOperNbr='" + oPayload['SubOperNbr'] + "',EquipNbr='" + oPayload['EquipNbr'] + "',MsetType='" + oPayload['MsetType'] + "')", {
						urlParameters: {
							"$expand": "MSetGroupSet/MeasPointSet,MSetCodeGrpSet/MSetCodeValueSet",
							"$format": "json"
						},
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							}
						}
					});
			},

			/* #DontDelete : Yann */
			/***
			 * Read a list of past Wheel Sheets for an inbound locomotive
			 * @param(object)	oLocomotive contains current locomotive data
			 * @param(function) fnSuccessCallBack is the success callback function
			 * @param(function) fnErrorCallBack is the error callback function
			 * @param(object)	oContext is the controller object that implements the error and success call backs
			 * 
			 */

			fetchLocomotiveWheelSheetHistory: function (oLocomotive, fnSuccessCallBack, fnErrorCallBack, oContext) {

				BusyIndicator.showBusyIndicator();

				var sEquip;
				if (oLocomotive) {
					if (oLocomotive.Equipment) {
						sEquip = oLocomotive.Equipment;
					} else {
						sEquip = oLocomotive.EquipNo;
					}
				}

				this._oModel.read("/MeasurementSetSet", {
					urlParameters: {
						"$filter": "EquipNbr eq '" + sEquip + "' and MsetType eq 'WHEEL_SHEET'",
						"$format": "json"
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},

			/* #DontDelete : Yann */
			/** 
			 * update Wheel Sheet data for a locomotive
			 * @param {object}   oPayload 
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			updateWheelSheet: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				//sanitize payload
				if (oPayload["Measurement"] === "") {
					delete oPayload["Measurement"];
				}

				if (oPayload["MeasPntValue"] === "") {
					delete oPayload["MeasPntValue"];
				}

				if (oPayload["SerialNbr"] === "") {
					delete oPayload["SerialNbr"];
				}

				if (oPayload["MeasurementPointName"] === "") {
					delete oPayload["MeasurementPointName"];
				}

				if (oPayload["InstallPosition"] === "") {
					delete oPayload["InstallPosition"];
				}
				// START - BAJ0018 - EAM-INC0027575				
				if (oPayload["ObjectType"] === "") {
					delete oPayload["ObjectType"];
				}
				if (oPayload["Room"] === "") {
					delete oPayload["Room"];
				}
				//END - BAJ0018 - EAM-INC0027575

				// START - SHE0272 - EAM-INC0127935	
				if (oPayload["SoftwareCharacteristic"] === "") {
					delete oPayload["SoftwareCharacteristic"];
				}
				if (oPayload["SoftwareClass"] === "") {
					delete oPayload["SoftwareClass"];
				}
				delete oPayload["MeasurementType"];
				//END - SHE0272 - EAM-INC0127935

				// START - SHE0272 - EAM-LLM 1.2 Serialization	
				// if (oPayload["GoodsIssueAndReturn"] === "") {
				// 	delete oPayload["GoodsIssueAndReturn"];
				// }
				// if (oPayload["Plant"] === "") {
				// 	delete oPayload["Plant"];
				// }
				// if (oPayload["SerializedMaterial"] === "") {
				// 	delete oPayload["SerializedMaterial"];
				// }
				// if (oPayload["UserRole"] === "") {
				// 	delete oPayload["UserRole"];
				// }
				//END - SHE0272 - EAM-LLM 1.2 Serialization

				this._oModel.create("/MeasurementSetSet",
					oPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							}
						}
					});
			},

			/* #DontDelete : Yann */
			/** 
			 * submit Wheel Sheet data for a locomotive
			 * @param {object}   oPayload 
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			submitWheelSheet: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();
				// Defect#202 Corrected the URI by adding - MeasurementSetSet(Sub
				this._oModel.update("/MeasurementSetSet(SubOperNbr='" + oPayload["SubOperNbr"] + "',OrderNbr='" + oPayload["OrderNbr"] +
					"',OperationNbr='" + oPayload["OperationNbr"] +
					"',EquipNbr='" + oPayload["EquipNbr"] + "',MsetType='" + oPayload["MsetType"] + "')",
					oPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							}
						}
					});
			},

			/* #DontDelete : Yann */
			/** 
			 * Get DropDownSet request results
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 * @param {string}	 sFilter is the string parameter for $filter in request parameters
			 * @param {string}	 sProperty is the property to add results to in global model
			 */
			fetchDropDownSetRequest: function (fnSuccessCallBack, fnErrorCallBack, oContext, sFilter, sProperty) {
				BusyIndicator.showBusyIndicator();
				this._oModel.read("/DropDownSet", {
					urlParameters: {
						"$filter": "Usage eq '" + sFilter + "' ",
						"$format": "json"
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, sProperty, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},

			/* #DontDelete : Yann */
			/** 
			 * Get the defect to order types
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			fetchDefectToOrderTypes: function (fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();
				this._oModel.read("/DropDownSet", {
					urlParameters: {
						"$filter": "Usage eq 'DEFECT_TO_ORDER_TYPE' ",
						"$format": "json"
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},

			/* #DontDelete : Yann */
			/** 
			 * Get the task lists
			 * @param {object} oLocomotive is the inbound locomotive object
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object} oContext is the controller object that implements the error and success call backs
			 */
			fetchTaskLists: function (oLocomotive, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				var sEquip;
				if (oLocomotive) {
					if (oLocomotive.Equipment) {
						sEquip = oLocomotive.Equipment;
					} else {
						sEquip = oLocomotive.EquipNo;
					}
				}

				this._oModel.read("/GetLocoTaskLists", {
					urlParameters: {
						"EquipNo": "'" + sEquip + "'",
						"$format": "json"
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},
			/* #DontDelete : Yann */

			/** Begin change VYA0004 LMP2-HIE-002
			 * Get the task lists
			 * @param {object} oLocomotive is the inbound locomotive object
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object} oContext is the controller object that implements the error and success call backs
			 */
			fetchTaskListsNew: function (oLocomotive, oDefectMoniCode, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				var sEquip;
				if (oLocomotive) {
					if (oLocomotive.Equipment) {
						sEquip = oLocomotive.Equipment;
					} else {
						sEquip = oLocomotive.EquipNo;
					}
				}
				this._oModel.read("/GetLocoTaskLists", {
					urlParameters: {
						"DefectCode": "'" + oDefectMoniCode + "'",
						"EquipNo": "'" + sEquip + "'",
						"$format": "json"
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},
			// End change VYA0004 LMP2-HIE-002
			/** 
			 * Create a new Defect or WorkOrder
			 * @param {object} oPayload 
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object} oContext is the controller object that implements the error and success call backs
			 */
			createDefectSet: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/NewDefectSet",
					oPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							}
						}
					});
			},

			/* #DontDelete : Yann */
			/** 
			 * Get the codes validating an update of the ETR
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			fetchETRUpdateCodes: function (fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();
				this._oModel.read("/DropDownSet", {
					urlParameters: {
						"$filter": "Usage eq 'ETR_CODES' ",
						"$format": "json"
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},

			/* #DontDelete : Yann */
			/** 
			 * Update ETR for a locomotive
			 * @param {object}   oPayload contains Shop,EquipNo,ETR_Ts,ETR_Tz,ReasonCode and ReasonDescr 
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			updateETR: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				//    /sap/opu/odata/sap/ZPM_LM_SRV/SetLocoETR?Shop='1035'&EquipNo='50075072'&ETR_Ts=datetime'2018-08-30T10:30:00'&ETR_Tz='MST'&ReasonCode='MWAT'&ReasonDescr=' '

				this._oModel.callFunction("/SetLocoETR", {
					method: "POST",
					urlParameters: oPayload,
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},

			/* #DontDelete : Yann */
			/** 
			 * move locomotive to another track / spot
			 * @param {object}   oPayload 
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			moveSelectedLocomotive: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/MoveLocoSet",
					oPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							}
						}
					});
			},

			/* #DontDelete : Yann */
			/**
			 * Returns the details of locomotive
			 * @param {function} fnSuccessCallBack is the callback function that would be executed on OData success callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * @param {string} sLocoNumber is the locomotive number
			 */
			fetchLocomotiveDetails: function (fnSuccessCallBack, fnErrorCallBack, oContext, sLocomotiveID, sEquipNo) {
				/*
				This is commented because back end don't need the ShopId anymore as it uses the
				locomotive shop id instead of the current shop id, wich is better for views like Fleet.
				var sShopId = this._oGlobalModel.getProperty("/currentShop").Id;
				var sQuery = "ShopId eq " + "'" + sShopId + "'" + " and EquipNo eq '" + sEquipNo + "'";
				*/

				var sQuery = "EquipNo eq '" + sEquipNo + "'";
				this._oModel.read("/OrderSet", {
					urlParameters: {
						"$filter": sQuery,
						"$expand": "OperationSet/TaskSet,OperationSet/MaterialSet,OperationSet/AssignmentSet,OperationSet/AttachSet" //LMP2-7a

					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						var oLocoDetailModel = new sap.ui.model.json.JSONModel({
							detailsData: oData
						});

						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oLocoDetailModel, oContext, sLocomotiveID, sEquipNo]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext, []);
						}
					}
				});
			},

			/* #DontDelete : Yann */
			/**
			 * Returns the shifts for the given shop id
			 * @param {string}	 sShopId id of the shop to retrieve info on
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			fetchShopShifts: function (sShopId, fnSuccessCallBack, fnErrorCallBack, oContext) {
				// /sap/opu/odata/sap/ZPM_LM_SRV/GetShopShifts?ShopId='1883'&$format=json
				BusyIndicator.showBusyIndicator();
				this._oModel.read("/GetShopShifts", {
					urlParameters: {
						"ShopId": "'" + sShopId + "'",
						"$format": "json"
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},

			/* START KIR0084 LMP2-32 Create query for turnover doc */
			fetchTurnoverDocReport: function (aFilterList, aSorterList, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				_this._oModel.read("/LocomotiveSet", {
					filters: aFilterList,
					sorters: aSorterList,
					urlParameters: {
						// 	"$expand": "OrderSet,OrderSet/OperationSet,OrderSet/OperationSet/CommentSet,OrderSet/OperationSet/AssignmentSet,OrderSet/OperationSet/TaskSet"
						"$expand": "OrderSet,OrderSet/OperationSet,OrderSet/OperationSet/AssignmentSet,OrderSet/OperationSet/TaskSet"
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});

			},

			/**
			 * Load all shop KPIs
			 */
			fetchShopKPIs: function (shopId, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				_this._oModel.callFunction("/GetShopKPIs", {
					method: "GET",
					urlParameters: {
						"ShopId": shopId
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
			},

			/**
			 * Load all shop KPIs
			 */
			fetchSystemViewKPIs: function (shopId, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				_this._oModel.callFunction("/GetSystemViewKPIs", {
					method: "GET",
					urlParameters: {
						"ShopId": shopId
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
			},

			/* END KIR0084 LMP2-32 Create query for turnover doc */

			/* #DontDelete : Yann */
			/**
			 * Returns all informations on all identified locomotives, to print a report
			 * @param {array} aLocomotives locomotives to retrieve
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 */
			fetchTurnoutReport: function (aLocomotives, fnSuccessCallBack, fnErrorCallBack, oContext) {
				var oLocoHash = {};

				BusyIndicator.showBusyIndicator();

				this._oModel.setUseBatch(true);

				var mParameters = {
					groupId: "_fetchTurnoutReport",
					success: function (oData) {

						$.each(oData.__batchResponses, function (i, obj) {
							var aWO = obj.data.results;
							if (aWO.length > 0) {
								oLocoHash[aWO[0].EquipNo].WorkOrders = aWO;
							}
						});

						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oLocoHash, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				};

				this._oModel.setDeferredBatchGroups(["_fetchTurnoutReport"]);

				// var sShopId = this._oGlobalModel.getProperty("/currentShop").Id;

				$.each(aLocomotives, function (i, oLocomotive) {
					/*
					This is commented because back end don't need the ShopId anymore as it uses the
					locomotive shop id instead of the current shop id, wich is better for views like Fleet.
					var sQuery = "ShopId eq " + "'" + sShopId + "'" + " and EquipNo eq '" + oLocomotive.Equipment + "'";
					*/

					var sEquip;
					if (oLocomotive) {
						if (oLocomotive.Equipment) {
							sEquip = oLocomotive.Equipment;
						} else {
							sEquip = oLocomotive.EquipNo;
						}
					}

					var sQuery = "EquipNo eq '" + sEquip + "'";

					var eqNb = Formatter.removeLeadingZeroes(sEquip);
					oLocoHash[eqNb] = oLocomotive;

					_this._oModel.read("/OrderSet", {
						urlParameters: {
							"$filter": sQuery,
							"$expand": "OperationSet/TaskSet,OperationSet/MaterialSet,OperationSet/AssignmentSet,OperationSet/AttachSet" //LMP2-7a
						},
						groupId: "_fetchTurnoutReport"

					});
				});

				this._oModel.submitChanges(mParameters);

			},

			/* #DontDelete : Yann */
			/**
			 * Returns searched locomotives in the fleet
			 * @param {string} sSearchString string to search in fleet
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 
			 */
			searchLocomotivesInFleet: function (sSearchString, fnSuccessCallBack, fnErrorCallBack, oContext) {
				///sap/opu/odata/sap/ZPM_LM_srv/GetFleetLocomotives?LocoId='cp82'&$format=json

				this._oModel.read("/GetFleetLocomotives", {
					urlParameters: {
						"LocoId": "'" + sSearchString + "'",
						"$format": "json"
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData.results, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},

			/* #DontDelete : Yann */
			/**
			 * Returns work order history for a locomotive
			 * @param {object}   oPayload  contains EquipNo and OrderCategory, optionally StartDate and EndDate
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 
			 */
			fetchWOHistory: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {

				///sap/opu/odata/sap/ZPM_LM_SRV/OrderSet?$filter=EquipNo eq '50075072' and OrderCategory eq 'H' and FromDate eq datetime'2017-08-01T00:00:00' and ToDate eq datetime'2017-10-25T00:00:00'&$format=json

				var sFilter = "EquipNo eq '" + oPayload["EquipNo"] + "' and OrderCategory eq '" + oPayload["OrderCategory"] + "'";

				//time range selection
				var dStartDate = oPayload["StartDate"];
				var dEndDate = oPayload["EndDate"];

				if (dStartDate && dEndDate) {
					var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "yyyy-MM-ddTHH:mm:ss"
					});
					var sStartDate = dateFormat.format(dStartDate);
					var sEndDate = dateFormat.format(dEndDate);
					sFilter += " and FromDate eq datetime'" + sStartDate + "' and ToDate eq datetime'" + sEndDate + "'";
				}

				this._oModel.read("/OrderSet", {
					urlParameters: {
						"$filter": sFilter,
						"$expand": "OperationSet/TaskSet,OperationSet/MaterialSet,OperationSet/AssignmentSet,OperationSet/AttachSet", //LMP2-7a
						"$format": "json"
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData.results, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext, []);
						}
					}
				});
			},

			/* #DontDelete : Yann */
			/**
			 * Returns work orders before a locomotive release
			 * @param {object}   oPayload  contains ShopId, EquipNo and OrderCategory
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 
			 */
			fetchPreReleaseWO: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				///sap/opu/odata/sap/ZPM_LM_SRV/OrderSet?$filter=ShopId eq '1035' and EquipNo eq '50075072' and OrderCategory eq 'A'&$format=json

				/*
				This is commented because back end don't need the ShopId anymore as it uses the
				locomotive shop id instead of the current shop id, wich is better for views like Fleet.
				var sFilter = "ShopId eq '" + oPayload["ShopId"] + "' and EquipNo eq '" + oPayload["EquipNo"] + "' and OrderCategory eq '" +
					oPayload["OrderCategory"] + "'";
				*/

				var sFilter = "EquipNo eq '" + oPayload["EquipNo"] + "' and OrderCategory eq '" + oPayload["OrderCategory"] + "'";

				this._oModel.read("/OrderSet", {
					urlParameters: {
						"$filter": sFilter,
						"$format": "json"
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData.results, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext, []);
						}
					}
				});
			},

			/**
			 * Updates the Lcomotive Details 
			 * update locomotive data
			 * @param {function}  successCallBack is the callback function that would be executed on OData success callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * @param {object} oPayload is the payload data
			 * @param {string} sLocomotiveNumber is the locomotive number
			 */
			updateLocomotive: function (successCallBack, oContext, oPayload, sLocomotiveNumber) {
				this._oModel.update("/LocomotiveSet('" + sLocomotiveNumber + "')",
					oPayload, {
						merge: false,
						success: function (oData) {
							if (successCallBack && oContext) {
								successCallBack.apply(oContext);
							}
						},
						error: function (oError) {
							ErrorManager.handleError(oError);
							BusyIndicator.hideBusyIndicator();
						}
					});
			},
			/**
			 * Call to submit Foreign Work authorization request
			 * @param {function}  successCallBack is the callback function that would be executed on OData success callback
			 * @param {object} oContext is the controller object that implements the error and success call backs
			 * @param {object} oPayload is the payload data
			 * @param {string} sLocomotiveNumber is the locomotive number
			 */
			updateFWALocomotive: function (successCallBack, oContext, oPayload, sLocomotiveNumber) {
				this._oModel.update("/LocomotiveSet('" + sLocomotiveNumber + "')",
					oPayload,

					{
						merge: false,
						success: function (oData) {
							if (successCallBack && oContext) {
								successCallBack.apply(oContext, [oPayload]);
							}
						},
						error: function (oError) {
							ErrorManager.handleError(oError);
							BusyIndicator.hideBusyIndicator();
						}
					});
			},
			// #DontDelete : Daya  
			/**
			 * Function to set Work Order status
			 * @function successCallBack is the callback function that would be executed on OData success callback
			 * @param {object} oContext is the controller object that implements the error and success call backs
			 * @param {string} oWorkOrderNumber is the Work Order to fetch status for
			 * @param {string} oWOStatus is the Work Order status
			 * @param {string} oWOUndo is the Undo status of Work Order
			 * @param {string} sFrom is from where the call is made
			 */
			updateWOWmatStatus: function (successCallBack, oContext, oWorkOrderNumber, oWOStatus, oWOUndo) {

				this._oModel.callFunction(
					"/SetWorkOrderUserStatus", {
						method: "POST",
						urlParameters: {
							"WorkOrderNumber": +oWorkOrderNumber,
							"UserStatus": oWOStatus,
							"Undo": oWOUndo
						},
						success: function (oData) {

							if (successCallBack && oContext) {
								successCallBack.apply(oContext, [oData, oContext]);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
						}
					});
			},

			// #DontDelete : Daya  

			/**
			 * Fetch The Dropdown Down list
			 * @function successCallBack is the callback function that would be executed on OData success callback	
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * @param {string} sLocomotiveNumber is the Locomotive Number
			 */
			fetchDropDownList: function (successCallBack, sKey, sUsage, oContext) {
				var sQuery = "LocomotiveNumber eq '" + sUsage + "' ";
				if (sKey) {
					sQuery = sQuery + " and " + "Key eq '" + sKey + "'";
				}
				this._oModel.read("/DropDownSet", {
					urlParameters: {
						"$filter": sQuery
					},
					success: function (oData) {
						if (successCallBack && oContext) {
							successCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						ErrorManager.handleError(oError);
						BusyIndicator.hideBusyIndicator();
					}
				});
			},

			// #DontDelete : Daya  
			/**
			 * Fetch The Dropdown Down list
			 * @function successCallBack is the callback function that would be executed on OData success callback	
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * @param {string} sLocomotiveNumber is the Locomotive Number
			 */
			fetchDefectCloseOutCodes: function (fnSuccessCallBack, fnErrorCallBack, oContext, sDefect) {

				this._oModel.read("/DefectSet('" + sDefect + "')", {
					urlParameters: {
						"$expand": "CloseOutCodes"
					},
					success: function (oData) {
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext, []);
						}
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
			},
			// #DontDelete : Daya  

			/***
			 * Update the  defect set for a given locomotive
			 * @function successCallBack is the callback function that would be executed on OData success callback
			 * @function errorCallBack is the callback function that would be executed on OData error callback
			 * @param {object} oContext is the controller object that implements the error and success call backs
			 * @param {object} oDefectPayload is the Payload for the call
			 * @param {object} oDefectPayload is the defect payload with close out code
			 * @param {function} successCallBack is the callback function that would be executed on OData success callback
			 * @param {function} errorCallBack is the callback function that would be executed on OData error callback
			 * @param {object} oContext is the controller object that implements the error and success call backs
			 */
			UpdateDefectCloseoutCodes: function (oDefectPayload, successCallBack, errorCallback, oContext) {

				this._oModel.create("/DefectSet",
					oDefectPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (successCallBack && oContext) {
								successCallBack.apply(oContext);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (errorCallback && oContext) {
								errorCallback.apply(oContext);
							}
						}
					});
			},

			// #DontDelete : Daya  
			/**
			 * Updates Defect Long Text
			 * @param {function} fnSuccessCallBack is the callback function that would be executed on OData success callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * @param {object}   oCommentsPayLoad is the pay load generated for adding comments for a WorkOrder
			 */
			UpdateDefect: function (fnSuccessCallBack, oDefectPayLoad, oContext) {
				BusyIndicator.showBusyIndicator();
				var sOrderNumber = oDefectPayLoad.DefectNo;
				this._oModel.update("/DefectSet('" + sOrderNumber + "')",
					oDefectPayLoad, {
						async: false,
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
						}
					});

			},
			//BAJ0018 - START - UPDSTATUS
			UpdateDefectStatus: function (fnSuccessCallBack, oStatusPayLoad, oContext) {
				BusyIndicator.showBusyIndicator();
				this._oModel.callFunction("/SetDefectUserStatus", {
					method: "POST",
					urlParameters: {
						"DefectNo": oStatusPayLoad.DefectNo,
						"StatusExt": oStatusPayLoad.Status,
						"SetInactive": ""
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

			},
			//BAJ0018 - END - UPDSTATUS
			// #DontDelete : Q  
			/**
			 * Updates Defect or Work Order Incident number
			 * @param {object}   oPayLoad is the pay load generated for editing incident number
			 * @param {function} fnSuccessCallBack is the callback function that would be executed on OData success callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 */
			UpdateIncidentId: function (oPayLoad, fnSuccessCallBack, oContext) {
				BusyIndicator.showBusyIndicator();
				var oIncidentId = oPayLoad.IncidentId;
				var oDefectMonitorCd = oPayLoad.DefectMonitorCode;

				if ((!oPayLoad.IncidentId) || oPayLoad.IncidentId === "") {
					oIncidentId = "DUMMY";
				}
				if ((!oPayLoad.DefectMonitorCode) || oPayLoad.DefectMonitorCode === "") {
					oDefectMonitorCd = "DUMMY";
				}
				this._oModel.callFunction("/UpdateIncidentID", {
					method: "POST",
					urlParameters: {
						"DefectNo": oPayLoad.DefectNo,
						"IncidentId": oIncidentId,
						"DefectMonitorCode": oDefectMonitorCd
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
			},

			// #DontDelete : Daya  
			/**
			 * Get DropDown
			 * @param {function} fnSuccessCallBack is the callback function that would be executed on OData success callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * @param {object}   oCommentsPayLoad is the pay load generated for adding comments for a WorkOrder
			 */
			getDropDown: function (sQuery, fnSuccessCallBack, oContext) {
				this._oModel.read("/DropDownSet", {
					urlParameters: {
						"$filter": sQuery
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
						// var deferalCodes = oData.results;
						// _this._oGlobalModel.setProperty("/CompCodeDD", deferalCodes);
						// BusyIndicator.hideBusyIndicator();
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

			},
			// #DontDelete : Daya  
			/** 
			 * Update the locomotive comments data
			 * @param {function} successCallBack is the callback function that would be executed on OData success callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * @param {object}   oCommentsPayLoad is the pay load generated to update comments for a locomotive
			 */
			updateOperation: function (successCallBack, oContext, oOpreationPayLoad) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/OrderSet",
					oOpreationPayLoad, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (successCallBack && oContext) {
								successCallBack.apply(oContext, [oOpreationPayLoad]);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
						}
					});
			},
			// #DontDelete : Daya  
			/** 
			 * Create New Operation
			 * @param {function} successCallBack is the callback function that would be executed on OData success callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * @param {object}   oCommentsPayLoad is the pay load generated to update comments for a locomotive
			 */
			createOperation: function (successCallBack, oContext, oOpreationPayLoad) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/OperationSet",
					oOpreationPayLoad, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (successCallBack && oContext) {
								successCallBack.apply(oContext, [oOpreationPayLoad]);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
						}
					});
			},

			// #DontDelete : Q  
			/** 
			 * Update an Operation
			 */
			updateOperationEstTime: function (fnSuccessCallBack, oContext, oPayload, oUrlParameters) {
				BusyIndicator.showBusyIndicator();
				this._oModel.update("/OperationSet(OpNode='" + oUrlParameters.OpNode + "',RoutingNo='" + oUrlParameters.RoutingNo + "')",
					oPayload, {
						merge: false,
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
						}
					});
			},

			// #DontDelete : Daya  
			/**
			 * Returns the list of shopped locomotives for a shop
			 * @param {string} sShopId is the search string entered
			 * @param {function} fnSuccessCallBack is the callback function that would be executed on OData success callback
			 * @param {function} fnErrorCallBack is the callback function that would be executed on OData error callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * 
			 */
			fetchLocoMegaWattHours: function (fnSuccessCallBack, fnErrorCallBack, oContext, sEuipno) {
				BusyIndicator.showBusyIndicator();
				this._oModel.callFunction("/GetLocomotiveMegaWattHrs", {
					urlParameters: {
						"EquipNo": sEuipno
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

			},
			// #DontDelete : Daya  
			fetchCraftWorkPlanList: function (fnSuccessCallBack, fnErrorCallBack, oContext, sShopID) {
				BusyIndicator.showBusyIndicator();
				this._oModel.callFunction("/GetEmpWorkSched", {
					urlParameters: {
						"Shop": sShopID
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
			},

			/* #DontDelete : Q */
			/** 
			 * update Craft Assignments for Operation
			 * @param {object}   oPayload 
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			upDateCraftAssignments: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/OperationSet",
					oPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							}
						}
					});
			},

			/* #DontDelete : Q */
			/** 
			 * update Craft Assignments for Operations Set
			 * @param {object}   oPayload 
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			updateCraftAssignmentsSet: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/WorkSet",
					oPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							}
						}
					});
			},

			// #DontDelete : Daya  

			/** 
			 * Remove Assignment from Operation
			 * @param {object}   oPayload 
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			DeleteAssignmentFromOperation: function (sEntity, fnSuccessCallBack, fnErrorCallBack, oContext) {
				// BusyIndicator.showBusyIndicator();

				this._oModel.remove(sEntity, {
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						} else {
							BusyIndicator.hideBusyIndicator();
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						} else {
							BusyIndicator.hideBusyIndicator();
						}
					}
				});
			},

			// #DontDelete : Q
			fetchCraftWorkerHistory: function (fnSuccessCallBack, fnErrorCallBack, oContext, sShopID, sPersNo, sFromDate, sToDate) {
				BusyIndicator.showBusyIndicator();

				var sQuery = "Shop eq '" + sShopID + "' and PersonnelNo eq '" + sPersNo + "' and Fromdate eq datetime'" + sFromDate +
					"' and Todate eq datetime'" + sToDate + "'";

				this._oModel.read("/CraftHistorySet", {
					urlParameters: {
						"$filter": sQuery,
						"$format": "json"
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
			},

			// #DontDelete : Daya 
			fetchMyWork: function (fnSuccessCallBack, fnErrorCallBack, oContext, sShopID, sPersNo) {
				BusyIndicator.showBusyIndicator();

				var sQuery = "Shop eq " + "'" + sShopID + "'" + " and PersonNo eq '" + sPersNo + "'";
				this._oModel.read("/OperationSet", {
					urlParameters: {
						"$filter": sQuery,
						"$expand": "MaterialSet,TaskSet,AttachSet" //LMP2-7a
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
			},

			// #DontDelete : Daya  
			/**
			 * Returns the list of Servicing locomotives for a shop
			 * @param {string} sShopId is the search string entered
			 * @param {function} fnSuccessCallBack is the callback function that would be executed on OData success callback
			 * @param {function} fnErrorCallBack is the callback function that would be executed on OData error callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * 
			 */
			fetchServiceLocomotives: function (sShopId, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();
				var sQuery = "Shop eq '" + sShopId + "'";

				this._oModel.read("/ServiceGroupSet", {
					urlParameters: {
						"$filter": sQuery,
						"$expand": "ServiceGroupItemSet"
					},
					success: function (oData) {

						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

			},
			// #DontDelete : Daya  

			/**
			 * Returns the details of Service locomotive
			 * @param {function} fnSuccessCallBack is the callback function that would be executed on OData success callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * @param {string} sLocoNumber is the locomotive number
			 */
			fetchServiceWorkOrders: function (fnSuccessCallBack, fnErrorCallBack, oContext, oServiceLocomotive) {

				var sEntitySet;
				var sFilter = "";
				var sExpand = "";
				if (oServiceLocomotive.isServiceGroupSelected) {
					//if service group selected fetch workorders by group ID
					//sShopId = "1035";
					sEntitySet = "/ServiceGroupSet(SrvcGrpId='" + oServiceLocomotive.SrvcGrpId + "')";
					sFilter = "";
					sExpand =
						"OrderSet/OperationSet,OrderSet/OperationSet/TaskSet,OrderSet/OperationSet/MaterialSet,OrderSet/OperationSet/AssignmentSet,OrderSet/OperationSet/AttachSet"; //LMP2-7a
					this._oModel.read(sEntitySet, {
						urlParameters: {
							"$expand": sExpand
						},
						success: function (oData) {

							var oLocoDetailModel = new sap.ui.model.json.JSONModel({
								detailsData: oData.OrderSet
							});

							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oLocoDetailModel, oContext, oServiceLocomotive]);
							}
						},
						error: function (oError) {
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext, []);
							}
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
						}
					});

					//ServiceGroupSet(SrvcGrpId=guid'005056bc-21bb-1ed7-a9f5-912c7e9345c2')?$expand=OrderSet/OperationSet
				} else {
					//if Ungrouped locomotive selected , fetch workorders by Locomotive
					//OrderSet?$filter=ShopId eq '1035' and EquipNo eq '50075072' and SrvcOrderInd eq true&$expand=OperationSet
					// sShopId = "1035";
					sEntitySet = "/OrderSet";
					var sEquip = " ";
					if (oServiceLocomotive.EquipNo) {
						sEquip = oServiceLocomotive.EquipNo;
					} else {
						sEquip = oServiceLocomotive.Equipment;
					}
					/*
					This is commented because back end don't need the ShopId anymore as it uses the
					locomotive shop id instead of the current shop id, wich is better for views like Fleet.
					sFilter = "ShopId eq '" + sShopId + "' and EquipNo eq '" + sEquip + "' and OrderCategory eq 'S'";
					*/
					// Start - SHE0272: LLM2.29 - Order Category will be 'R' for RYR process
					var orderCategory = "S";
					if (oServiceLocomotive.ShopReasonDet && oServiceLocomotive.ShopReasonDet === "R") {
						orderCategory = "R";
					}
					sFilter = "EquipNo eq '" + sEquip + "' and OrderCategory eq '" + orderCategory + "'";
					// End - SHE0272: LLM2.29 - Order Category will be 'R' for RYR process
					sExpand = "OperationSet,OperationSet/TaskSet,OperationSet/MaterialSet,OperationSet/AssignmentSet,OperationSet/AttachSet"; //LMP2-7a
					this._oModel.read(sEntitySet, {
						urlParameters: {
							"$filter": sFilter,
							"$expand": sExpand
						},
						success: function (oData) {

							var oLocoDetailModel = new sap.ui.model.json.JSONModel({
								detailsData: oData
							});

							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oLocoDetailModel, oContext, oServiceLocomotive]);
							}
						},
						error: function (oError) {
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext, []);
							}
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
						}
					});

				}

			},
			// #DontDelete : Daya  

			/**
			 * Returns the list of Ungrouped for a shop
			 * @param {string} sShopId is the search string entered
			 * @param {function} fnSuccessCallBack is the callback function that would be executed on OData success callback
			 * @param {function} fnErrorCallBack is the callback function that would be executed on OData error callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * 
			 */
			fetchUngroupedLocomotives: function (fnSuccessCallBack, fnErrorCallBack, oContext) {

				var sShopId = this._oGlobalModel.getProperty("/currentShop").Id;
				BusyIndicator.showBusyIndicator();
				this._oModel.callFunction("/GetUngroupedServiceLocos", {
					urlParameters: {
						"Shop": sShopId
					},
					success: function (oData) {
						// BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

			},
			// #DontDelete : Daya  

			/** 
			 * Create Service Group
			 * @param {object}   oPayload 
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			createServiceGroup: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/ServiceGroupSet",
					oPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							} else {
								BusyIndicator.hideBusyIndicator();
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							} else {
								BusyIndicator.hideBusyIndicator();
							}
						}
					});
			},
			// #DontDelete : Daya  
			/** 
			 * Remove Assignment from Operation
			 * @param {object}   oPayload 
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			DeleteServicingGroup: function (sEntity, fnSuccessCallBack, fnErrorCallBack, oContext) {
				// BusyIndicator.showBusyIndicator();
				this._oModel.remove(sEntity, {
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						} else {
							BusyIndicator.hideBusyIndicator();
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						} else {
							BusyIndicator.hideBusyIndicator();
						}
					}
				});
			},
			// #DontDelete : Daya  
			/** 
			 * Final Confirmation on Operations Set
			 * @param {object}   oPayload contains ShopId - LocoId - EquipNbr - ShoppedTimestamp - ShoppedTimezone - Track - Spot
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			ConfirmOperation: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/OrderSet",
					oPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							} else {
								BusyIndicator.hideBusyIndicator();
							}
						},
						// groupId: "idGroup1",
						changeSetId: "idOperationChanges",
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							} else {
								BusyIndicator.hideBusyIndicator();
							}
						}
					});
			},
			// #DontDelete : Daya  
			/** 
			 * Adjust Materials for My Work Operation
			 * @param {object}   oPayload contains adjusted materials
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			AdjustMaterials: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/OperationSet ",
					oPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							} else {
								BusyIndicator.hideBusyIndicator();
							}
						},

						//groupId: "idGroup1",
						changeSetId: "idMatChanges",
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							} else {
								BusyIndicator.hideBusyIndicator();
							}
						}
					});
			},
			// #DontDelete : Daya  
			fetchMesCodeGroup: function (fnSuccessCallBack, fnErrorCallBack, oContext, oTaskHeader) {
				BusyIndicator.showBusyIndicator();
				// MeasurementPointSet(EquipNbr='50388149',MeasurePtName= MS_MEGAWATT_HOUR_A)
				var sQuery = "/MeasurementPointSet(EquipNbr='" + oTaskHeader.EquipNbr + "',MeasurePtName='" + oTaskHeader.MeasurementPointName +
					"')";
				this._oModel.read(sQuery, {
					urlParameters: {
						"$expand": "MeasPtCodeValSet"
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

			},
			// #DontDelete : Daya  
			/** 
			 * Update measurement point
			 * @param {object}   oPayload contains adjusted materials
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			updateMeasPoint: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/MeasurementPointSet ",
					oPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							} else {
								BusyIndicator.hideBusyIndicator();
							}
						},

						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							} else {
								BusyIndicator.hideBusyIndicator();
							}
						}
					});
			},
			// #DontDelete : Daya  

			/** 
			 * Update Serial Number
			 * @param {object}   oPayload contains task Entity for updating serial number
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			updateSerialNo: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/SerialNumberSet ",
					oPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							} else {
								BusyIndicator.hideBusyIndicator();
							}
						},

						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							} else {
								BusyIndicator.hideBusyIndicator();
							}
						}
					});
			},
			// #DontDelete : Daya  

			fetchLocoHeader: function (fnSuccessCallBack, fnErrorCallBack, oContext, oParam) {
				BusyIndicator.showBusyIndicator();

				var sQuery = "/LocomotiveSet(Equipment='" + oParam.Equipment + "')";
				this._oModel.read(sQuery, {
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

			},
			// #DontDelete : Daya  
			//Added by Sandhya : LMP2-16:Get the Loco Characteristics
			fetchLocoChar: function (fnSuccessCallBack, fnErrorCallBack, oContext, oParam) {
				BusyIndicator.showBusyIndicator();
				var sQuery = "/LocoCharacteristicsSet(Equipment='" + oParam.Equipment + "')";
				this._oModel.read("/LocoCharacteristicsSet", {
					urlParameters: {
						"$filter": "Equipment eq '" + oParam.Equipment + "' "
					},
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});

			},
			//End:Added by Sandhya : LMP2-16:Get the Loco Characteristics

			fetchWOComments: function (fnSuccessCallBack, fnErrorCallBack, oContext, oParam) {
				BusyIndicator.showBusyIndicator();

				this._oModel.read("/CommentSet", {
					urlParameters: {
						"$filter": "ObjectNo eq '" + oParam.ObjectNo + "' "
							// "$filter": "ObjectNo eq '" + "OR003000527447" + "' "
					},

					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

			},

			// #DontDelete : Daya  

			//Added by Sandhya  :LMP2-05
			saveLocoStat: function (oData1, fnSuccessCallBack, fnErrorCallBack, oContext) {
				this._oModel.update("/LocomotiveSet('')",
					oData1, {
						merge: false,
						success: function (oResult) {
							BusyIndicator.hideBusyIndicator();
							MessageBox.show("Unit Status for the Locomotive saved successfully", {
								icon: MessageBox.Icon.SUCCESS,
								title: "Success",
								styleClass: "successMessage",
								actions: [MessageBox.Action.OK]
							});
							// if (fnSuccessCallBack && oContext) {
							// 		fnSuccessCallBack.apply(oContext, [oData, oContext]);
							// 	} else {
							// 		BusyIndicator.hideBusyIndicator();
							// 	}	
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							} else {
								BusyIndicator.hideBusyIndicator();
							}
						}
					});
			},
			//End:Added by Sandhya : LMP2-05	

			/** 
			 * Post Workorder Comment
			 * @param {object}   oPayload contains comments payload
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			postWOComment: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/CommentSet ",
					oPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							} else {
								BusyIndicator.hideBusyIndicator();
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							} else {
								BusyIndicator.hideBusyIndicator();
							}
						}
					});
			},
			// #DontDelete : Daya  

			fetchCraftNotes: function (fnSuccessCallBack, fnErrorCallBack, oContext, sPersonNo) {
				BusyIndicator.showBusyIndicator();

				this._oModel.read("/CraftNoteSet", {
					urlParameters: {
						"$filter": "CraftPersonnelNo  eq '" + sPersonNo + "' "
							// "$filter": "ObjectNo eq '" + "OR003000527447" + "' "
					},

					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

			},

			// #DontDelete : Daya  

			/** 
			 * Post Craft Notes
			 * @param {object}   oPayload contains comments payload
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			postCraftNotes: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/CraftNoteSet ",
					oPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							} else {
								BusyIndicator.hideBusyIndicator();
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							} else {
								BusyIndicator.hideBusyIndicator();
							}
						}
					});
			},
			/** 
			 * Mark the notes for Deletion
			 * @param {object}   oPayload 
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			deleteNotes: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				var sEntity = "/CraftNoteSet('" + oPayload.Guid + "')";
				this._oModel.remove(sEntity, {
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData, oContext]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},
			// #DontDelete : Daya  

			/** 
			 * Request for Materials
			 * @param {object}   oPayload contains comments payload
			 * @param {function} fnSuccessCallBack is the success callback function
			 * @param {function} fnErrorCallBack is the error callback function
			 * @param {object}	 oContext is the controller object that implements the error and success call backs
			 */
			requestMatMessage: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/AlertSet",
					oPayload, {

						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData, oContext]);
							} else {
								BusyIndicator.hideBusyIndicator();
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext);
							} else {
								BusyIndicator.hideBusyIndicator();
							}
						}
					});
			},
			//BnB VYA0004 MOD0013 2000011826 Begin
			fetchBnbInventory: function (fnSuccessCallBack, fnErrorCallBack, aFilters, oController, oContext) {
				BusyIndicator.showBusyIndicator();
				this._oModel.read("/BnbInventorySet", {
					async: false,
					filters: aFilters,
					success: function (oData) {
						var oInventoryModel = new sap.ui.model.json.JSONModel(oData);
						if (fnSuccessCallBack && oContext) {
							BusyIndicator.hideBusyIndicator();
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oController, oError);
						}
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
			},
			fetchBnbTasklist: function (fnSuccessCallBack, fnErrorCallBack, aFilters, oController, oContext) {

				this._oModel.read("/BnBTasklistSet", {
					async: false,
					filters: aFilters,
					success: function (oData) {
						var oBnbTasklistModel = new sap.ui.model.json.JSONModel(oData);
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext, []);
						}
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
			},

			createBnBUnscheduledOrder: function (aOrderData, fnSuccessCallBack, oContext) {
				BusyIndicator.showBusyIndicator();
				this._oModel.create("/BnBUnscheduledWOSet", aOrderData, {
					async: false,
					success: function (oData) {
						if (fnSuccessCallBack && oContext) {
							BusyIndicator.hideBusyIndicator();
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					}.bind(this),
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

			},

			createRefurbOrder: function (aRefurbOrdData, fnSuccessCallBack, oContext) {
				BusyIndicator.showBusyIndicator();
				this._oModel.create("/BnbRefurbOrderSet", aRefurbOrdData, {
					async: false,
					success: function (oData) {
						if (fnSuccessCallBack && oContext) {
							BusyIndicator.hideBusyIndicator();
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					}.bind(this),
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});

			},
			//BnB VYA0004 Mod0013 2000011826 End

			// Fetch crafts based on shift
			fetchCraftWorkPlanListWithShift: function (fnSuccessCallBack, fnErrorCallBack, oContext, oParams) {
				BusyIndicator.showBusyIndicator();
				this._oModel.callFunction("/GetEmpWorkSched", {
					urlParameters: {
						"Shop": oParams.Shop
					},
					// urlParameters: {
					// 	"Shop": oParams.Shop,
					// 	"PersonNo": oParams.PersonNo,
					// 	"FromDate": oParams.FromDate,
					// 	"ToDate": oParams.ToDate
					// },
					success: function (oData) {
						BusyIndicator.hideBusyIndicator();
						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oData]);
						}
					},
					error: function (oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
			},

			// // Start - SHE0272: EAM-LLM1.2 Serialization of material and equipment
			// GetSerializationNumbers: function (suggestionValue, methodType, fnSuccessCallBack, fnErrorCallBack, oContext) {
			// 	// BusyIndicator.showBusyIndicator();
			// 	this._oModel.read("/FuzzSerialMatSet", {
			// 		urlParameters: {
			// 			"$filter": "(Werks eq '" + suggestionValue + "' and Process eq '" + methodType + "' )"
			// 		},
			// 		success: function (oData) {
			// 			// BusyIndicator.hideBusyIndicator();
			// 			if (fnSuccessCallBack && oContext) {
			// 				fnSuccessCallBack.apply(oContext, [oData, oContext]);
			// 			}
			// 		},
			// 		error: function (oError) {
			// 			// BusyIndicator.hideBusyIndicator();
			// 			ErrorManager.handleError(oError);
			// 			if (fnErrorCallBack && oContext) {
			// 				fnErrorCallBack.apply(oContext);
			// 			}
			// 		}
			// 	});
			// },

			// // Start - SHE0272: EAM-LLM1.2 Serialization of material and equipment
			// GetMaterialList: function (suggestionValue, fnSuccessCallBack, fnErrorCallBack, oContext) {
			// 	// BusyIndicator.showBusyIndicator();
			// 	this._oModel.read("/SerializedMatSet", {
			// 		success: function (oData) {
			// 			// BusyIndicator.hideBusyIndicator();
			// 			if (fnSuccessCallBack && oContext) {
			// 				fnSuccessCallBack.apply(oContext, [oData, oContext]);
			// 			}
			// 		},
			// 		error: function (oError) {
			// 			// BusyIndicator.hideBusyIndicator();
			// 			ErrorManager.handleError(oError);
			// 			if (fnErrorCallBack && oContext) {
			// 				fnErrorCallBack.apply(oContext);
			// 			}
			// 		}
			// 	});
			// },

			// // Start - SHE0272: EAM-LLM1.2 Serialization of material and equipment
			// fnGetStorageLocationDetails: function (filterParameter, fnSuccessCallBack, fnErrorCallBack, oContext) {
			// 	// BusyIndicator.showBusyIndicator();
			// 	this._oModel.read("/StoLocBatchSet", {
			// 		urlParameters: {
			// 			"$filter": filterParameter
			// 		},
			// 		success: function (oData) {
			// 			// BusyIndicator.hideBusyIndicator();
			// 			if (fnSuccessCallBack && oContext) {
			// 				fnSuccessCallBack.apply(oContext, [oData, oContext]);
			// 			}
			// 		},
			// 		error: function (oError) {
			// 			// BusyIndicator.hideBusyIndicator();
			// 			ErrorManager.handleError(oError);
			// 			if (fnErrorCallBack && oContext) {
			// 				fnErrorCallBack.apply(oContext);
			// 			}
			// 		}
			// 	});
			// },

			// // Start - SHE0272: EAM-LLM1.2 Serialization of material and equipment
			// fnGoodIssue: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
			// 	BusyIndicator.showBusyIndicator();
			// 	this._oModel.create("/GoodsIssueSet", oPayload, {
			// 		async: false,
			// 		success: function (oData) {
			// 			if (fnSuccessCallBack && oContext) {
			// 				BusyIndicator.hideBusyIndicator();
			// 				fnSuccessCallBack.apply(oContext, [oData]);
			// 			}
			// 		}.bind(this),
			// 		error: function (oError) {
			// 			BusyIndicator.hideBusyIndicator();
			// 			ErrorManager.handleError(oError);
			// 		}
			// 	});
			// },

			// // Start - SHE0272: EAM-LLM1.2 Serialization of material and equipment
			// fnGoodsReturn: function (oPayload, fnSuccessCallBack, fnErrorCallBack, oContext) {
			// 	BusyIndicator.showBusyIndicator();
			// 	this._oModel.create("/GoodsReturnSet", oPayload, {
			// 		async: false,
			// 		success: function (oData) {
			// 			if (fnSuccessCallBack && oContext) {
			// 				BusyIndicator.hideBusyIndicator();
			// 				fnSuccessCallBack.apply(oContext, [oData]);
			// 			}
			// 		}.bind(this),
			// 		error: function (oError) {
			// 			BusyIndicator.hideBusyIndicator();
			// 			ErrorManager.handleError(oError);
			// 		}
			// 	});
			// },
			
			//Start: ANI0006 2000014601 - Engine Manufacturer dropdown read operation
			fetchEngineManfacturer: function (fnSuccessCallBack, fnErrorCallBack, oContext) {
					BusyIndicator.showBusyIndicator();
					this._oEngManfModel.read("/equip_manfSet", {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData]);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager.handleError(oError);
						}
					});
				}
			// End: ANI0006 2000014601 - Engine Manufacturer dropdown read operation 

		};

	});