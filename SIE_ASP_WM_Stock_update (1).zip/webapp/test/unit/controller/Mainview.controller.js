/*global QUnit*/

sap.ui.define([
	"SIE_ASP_WM_Stock_update/SIE_ASP_WM_Stock_update/controller/Mainview.controller"
], function (Controller) {
	"use strict";

	QUnit.module("Mainview Controller");

	QUnit.test("I should test the Mainview controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});