/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"SIE_ASP_WM_Stock_update/SIE_ASP_WM_Stock_update/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});