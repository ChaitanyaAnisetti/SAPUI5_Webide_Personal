jQuery.sap.require("sap.ui.core.format.NumberFormat");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageBox',
	'sap/m/MessagePopover',
	'sap/m/MessageItem',
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function (Controller, MessageBox, MessagePopover, MessageItem, JSONModel, MessageToast) {
	"use strict";

	return Controller.extend("SIE_ASP_WM_Stock_update.SIE_ASP_WM_Stock_update.controller.ChangestockcatDisplay", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf SIE_ASP_WM_Stock_update.SIE_ASP_WM_Stock_update.view.ChangestockcatDisplay
		 */
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("ChangestockcatDisplay").attachPatternMatched(this._onObjectMatched, this);
			this.oBusyDialog = new sap.m.BusyDialog();
		},
		_onObjectMatched: function (oEvent) {
			
			if (oEvent.getParameter("arguments").WarehouseNo && oEvent.getParameter("arguments").Plant) {
				this.WarehouseNo = oEvent.getParameter("arguments").WarehouseNo || "";
				this.Plant = oEvent.getParameter("arguments").Plant || "";
				this.StorageBin = oEvent.getParameter("arguments").StorageBin || "";
				this.Material = oEvent.getParameter("arguments").Material || "";
				this.Sloc = oEvent.getParameter("arguments").Sloc || "";
				this.Batchno = oEvent.getParameter("arguments").Batchno || "";
				this.SpecialStock = oEvent.getParameter("arguments").SpecialStoc || "";
				var Stockcat = oEvent.getParameter("arguments").Stockcat || "";
				var SpecialStockIndicator = "";
				this.SpecialStockNo = "";
				if (this.SpecialStock != "" && this.SpecialStock != "undefined") {
					SpecialStockIndicator = this.SpecialStock.split(" ")[0];
					this.SpecialStockNo = this.SpecialStock.split(" ")[1];
				}
				this.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", null);
				var Indicator = oEvent.getParameter("arguments").Indicator || "";
				this.getOwnerComponent().getModel("localModel").setProperty("/Indicator", Indicator);
				var SelectedCategoryBtn = oEvent.getParameter("arguments").SelectedCategoryBtn;
				if (SelectedCategoryBtn === "Change Stock Category") {
					if (SelectedCategoryBtn === "Change Stock Category" && Stockcat === "Q") {
						this.getView().byId("oBtnQitour").setVisible(true);
						this.getView().byId("oBtnQItoBlock").setVisible(true);
						this.getView().byId("oBtnURtoQI").setVisible(false);
						this.getView().byId("oBtnURtoBlock").setVisible(false);
						this.getView().byId("oBtnBlocktoUR").setVisible(false);
						this.getView().byId("oBtnBlocktoQI").setVisible(false);
					} else if (SelectedCategoryBtn === "Change Stock Category" && Stockcat === "") {
						this.getView().byId("oBtnQitour").setVisible(false);
						this.getView().byId("oBtnQItoBlock").setVisible(false);
						this.getView().byId("oBtnURtoQI").setVisible(true);
						this.getView().byId("oBtnURtoBlock").setVisible(true);
						this.getView().byId("oBtnBlocktoUR").setVisible(false);
						this.getView().byId("oBtnBlocktoQI").setVisible(false);
					} else if (SelectedCategoryBtn === "Change Stock Category" && Stockcat === "S") {
						this.getView().byId("oBtnQitour").setVisible(false);
						this.getView().byId("oBtnQItoBlock").setVisible(false);
						this.getView().byId("oBtnURtoQI").setVisible(false);
						this.getView().byId("oBtnURtoBlock").setVisible(false);
						this.getView().byId("oBtnBlocktoUR").setVisible(true);
						this.getView().byId("oBtnBlocktoQI").setVisible(true);
					}
				} else {
					this.getView().byId("oBtnQitour").setVisible(false);
					this.getView().byId("oBtnQItoBlock").setVisible(false);
					this.getView().byId("oBtnURtoQI").setVisible(false);
					this.getView().byId("oBtnURtoBlock").setVisible(false);
					this.getView().byId("oBtnBlocktoUR").setVisible(false);
					this.getView().byId("oBtnBlocktoQI").setVisible(false);
				}
				this.getOwnerComponent().getModel("localModel").setProperty("/SelectedCategoryBtn", SelectedCategoryBtn);
				this.getOwnerComponent().getModel("localModel").setProperty("/SpecialStockIndicator", SpecialStockIndicator);
				this.getOwnerComponent().getModel("localModel").setProperty("/SpecialStockNo", this.SpecialStockNo);
				//	this.Batchno = "";
				var that = this;
				if (SelectedCategoryBtn === "Change Stock Category") {
					this.oBusyDialog.open();
					var Tr = "Stockcat eq '" + Stockcat + "'";
					var oBindingInfo = {
						filters: null,
						urlParameters: {
							"$filter": Tr
						},
						success: function (oData, oResponse) {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", oData);
						},
						error: function (oError) {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
						}
					};

					this.getOwnerComponent().getModel("STOCK_INFO_SRV").read("/ItemDetailSet(WarehouseNo='" + this.WarehouseNo +
						"',StorageBin='" + this.StorageBin + "',Material='" + this.Material + "',Plant='" + this.Plant +
						"',Sloc='" + this.Sloc + "',SpecialStockNo='" + this.SpecialStock + "',Batchno='" + this.Batchno +
						"')/?$expand=ITEM_SERIAL_NAV", oBindingInfo);
				} else if (SelectedCategoryBtn === "Change Batch Number") {

					this.oBusyDialog.open();
					var oBindingInfo = {

						success: function (oData, oResponse) {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", oData);
						},
						error: function (oError) {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
						}
					};

					//	this.getOwnerComponent().getModel("STOCK_INFO_SRV").read("/ItemDetailSet(WarehouseNo='A03',StorageBin='65A',Material='100000063',Plant='9DB3',Sloc='0001',SpecialStockNo='',Batchno='0000000651')/?$expand=ITEM_SERIAL_NAV,ITEMTOBATCH_NAV",oBindingInfo);

					this.getOwnerComponent().getModel("STOCK_INFO_SRV").read("/ItemDetailSet(WarehouseNo='" + this.WarehouseNo +
						"',StorageBin='" + this.StorageBin + "',Material='" + this.Material + "',Plant='" + this.Plant +
						"',Sloc='" + this.Sloc + "',SpecialStockNo='" + this.SpecialStock + "',Batchno='" + this.Batchno +
						"')/?$expand=ITEM_SERIAL_NAV", oBindingInfo);
				} else if (SelectedCategoryBtn === "Change Special Stock") {

					this.oBusyDialog.open();
					var oBindingInfo = {

						success: function (oData, oResponse) {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", oData);
						},
						error: function (oError) {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
						}
					};

					/*	this.getOwnerComponent().getModel("STOCK_INFO_SRV").read("/ItemDetailSet(WarehouseNo='" + this.WarehouseNo +
							"',StorageBin='" + this.StorageBin + "',Material='" + this.Material + "',Plant='" + this.Plant +
							"',Sloc='" + this.Sloc + "',SpecialStockNo='" + this.SpecialStockNo + "',Batchno='" + this.Batchno +
							"')/?$expand=ITEM_SERIAL_NAV", oBindingInfo);*/

					this.getOwnerComponent().getModel("STOCK_INFO_SRV").read("/ItemDetailSet(WarehouseNo='" + this.WarehouseNo +
						"',StorageBin='" + this.StorageBin + "',Material='" + this.Material + "',Plant='" + this.Plant +
						"',Sloc='" + this.Sloc + "',SpecialStockNo='" + this.SpecialStock + "',Batchno='" + this.Batchno +
						"')/?$expand=ITEM_SERIAL_NAV", oBindingInfo);

				}

			}
		},
		onQitour: function () {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("U");
			} else {
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					//	"SpecialStockNo": "",
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					//	"Stockcat": "",
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": "U",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": [],
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": {}

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.Msgtype === "S") {

							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.success(oData.Msgdesc, {

								actions: ["Change Stock Category", "Go Back to Main Menu"],
								title: "Change Stock Category",
								onClose: function (oAction) {

									if (oAction == "Change Stock Category") {

										that.ChangeStockcategory();

									} else {
										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.show(
								oData.Msgdesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
					}
				});
			}

		},
		onURtoQI: function () {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("U");
			} else {
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					//	"Stockcat": "",
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": "U",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": [],
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": {}

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.Msgtype === "S") {

							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.success(oData.Msgdesc, {

								actions: ["Change Stock Category", "Go Back to Main Menu"],
								title: "Change Stock Category",
								onClose: function (oAction) {

									if (oAction == "Change Stock Category") {

										that.ChangeStockcategory();

									} else {
										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.show(
								oData.Msgdesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
						that.oBusyDialog.close();
						that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
					}
				});
			}

		},
		onURtoBlock: function () {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("Q");
			} else {
				var oPayload = {

					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					//	"Stockcat": "",
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": "Q",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": [],
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": {}

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.Msgtype === "S") {
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							that.oBusyDialog.close();
							sap.m.MessageBox.success(oData.Msgdesc, {

								actions: ["Change Stock Category", "Go Back to Main Menu"],
								title: "Change Stock Category",
								onClose: function (oAction) {

									if (oAction == "Change Stock Category") {

										that.ChangeStockcategory();

									} else {
										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.show(
								oData.Msgdesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
						that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
					}
				});
			}

		},
		onBlocktoUR: function () {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("U");
			} else {
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					//	"Stockcat": "",
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": "U",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": [],
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": {}

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.Msgtype === "S") {
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							that.oBusyDialog.close();
							sap.m.MessageBox.success(oData.Msgdesc, {

								actions: ["Change Stock Category", "Go Back to Main Menu"],
								title: "Change Stock Category",
								onClose: function (oAction) {

									if (oAction == "Change Stock Category") {

										that.ChangeStockcategory();

									} else {
										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.show(
								oData.Msgdesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
						that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
					}
				});
			}
		},
		onBlocktoQI: function () {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("Q");
			} else {
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					//	"Stockcat": "",
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": "Q",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": [],
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": {}

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.Msgtype === "S") {
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							that.oBusyDialog.close();
							sap.m.MessageBox.success(oData.Msgdesc, {

								actions: ["Change Stock Category", "Go Back to Main Menu"],
								title: "Change Stock Category",
								onClose: function (oAction) {

									if (oAction == "Change Stock Category") {

										that.ChangeStockcategory();

									} else {
										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.show(
								oData.Msgdesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
						that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
					}
				});
			}
		},

		onSerialnoSave: function () {

		},
		onMaterialChangeStockSave: function () {
			var oTable = sap.ui.getCore().byId("oRelaseStrtTable").getModel().getData().filter(function (x) {
				return x.Serialno === "";
			});
			if (!oTable.length) {
				var MaintainedSrnoData = sap.ui.getCore().byId("oRelaseStrtTable").getModel().getData();
				this.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", MaintainedSrnoData);
				//	this.oMaintianSerialNoBtnPost();
				this._Dialog1.destroy(true);
				this._Dialog1 = undefined;
			} else {
				sap.m.MessageBox.show(
					"Please enter valid Serial No.s", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.CLOSE],
						onClose: function (oAction) {}

					}
				);
			}

		},
		onMaterialChangeStockBack: function () {
			this._Dialog1.destroy(true);
			this._Dialog1 = undefined;
		},

		onQItoBlock: function () {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("Q");
			} else {
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					//	"Stockcat": "",
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": "Q",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": [],
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": {}
				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.Msgtype === "S") {
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							that.oBusyDialog.close();
							sap.m.MessageBox.success(oData.Msgdesc, {

								actions: ["Change Stock Category", "Go Back to Main Menu"],
								title: "Change Stock Category",
								onClose: function (oAction) {

									if (oAction == "Change Stock Category") {

										that.ChangeStockcategory();

									} else {

										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.show(
								oData.Msgdesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}

					},
					error: function (oError) {
						that.oBusyDialog.close();
						that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
					}
				});
			}

		},

		ChangeStockcategory: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ChangeStockcategory", {

			});

		},
		onBack: function () {

			/*	this._Dialog.destroy(true);
				this._Dialog = undefined;*/

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ChangeStockInfo", {

			});

		},
		onStockQunatitychange: function (oEvt) {

			var sValue1 = oEvt.getParameter("value");
			var sValue = Number(sValue1).toFixed(3);
			this.getView().byId("oStockQty").setText(sValue);
			oEvt.getSource().setValue(sValue);
		},
		onMaintainserialno: function () {

			var oVal = this.getView().byId("oStockQtychange").getValue();
			var bindVal = "";
			if (oVal) {
				oVal = Number(Number(oVal).toFixed(0));
				if (oVal <= 1) {
					var loopoVal = 1;
					//	bindVal = oVal;
				} else {
					var loopoVal = oVal;
				}
			} else {
				loopoVal = 0;
			}
			if (!this._Dialog1) {
				this._Dialog1 = sap.ui.xmlfragment(
					"SIE_ASP_WM_Stock_update.SIE_ASP_WM_Stock_update.Fragment.MultipleQuantitieRows",
					this
				);
				this.getView().addDependent(this._Dialog1);
			}
			this._Dialog1.open();
			var oTable = sap.ui.getCore().byId("oRelaseStrtTable");
			var oColumn = new sap.m.Column({
				header: new sap.m.Label({
					text: "Serial No.s",
					required: true
				})
			});
			oTable.addColumn(oColumn);
			var oCell = [];
			var Data = [];
			var cell1 = new sap.m.Input({
				value: "{Serialno}"
			});
			oCell.push(cell1);

			for (var i = 0; i < loopoVal; i++) {
				var obj = {
					"Serialno": bindVal
				};
				Data.push(obj);
			}
			var Model = new sap.ui.model.json.JSONModel(Data);
			oTable.setModel(Model);
			var aColList = new sap.m.ColumnListItem("", {
				cells: oCell
			});
			oTable.bindItems("/", aColList);

		},
		onPressback: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ChangeStockcategory", {

			});

		},
		onMaterialChangeStockClear: function () {
			var oVal = this.getView().byId("oStockQtychange").getValue();
			if (oVal) {
				oVal = Number(Number(oVal).toFixed(0));
			} else {
				oVal = 0;
			}

			var oTable = sap.ui.getCore().byId("oRelaseStrtTable");
			oTable.destroyItems();
			oTable.unbindItems();
			oTable.removeAllColumns();
			var oColumn = new sap.m.Column({
				header: new sap.m.Label({
					text: "Serial No.s",
					required: true
				})
			});
			oTable.addColumn(oColumn);
			var oCell = [];
			var Data = [];
			var cell1 = new sap.m.Input({
				value: "{Serialno}"
			});
			oCell.push(cell1);
			for (var i = 0; i < oVal; i++) {
				var obj = {
					"Serialno": ""
				};
				Data.push(obj);
			}
			var Model = new sap.ui.model.json.JSONModel(Data);
			oTable.setModel(Model);
			var aColList = new sap.m.ColumnListItem("", {
				cells: oCell
			});
			oTable.bindItems("/", aColList);
		},
		onChangebatchno: function (oEvent) {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else {
				if (!this._DialogCB) {
					this._DialogCB = sap.ui.xmlfragment(
						"SIE_ASP_WM_Stock_update.SIE_ASP_WM_Stock_update.Fragment.ChangebatchNo_ChngBtchNo",
						this
					);
					this.getView().addDependent(this._DialogCB);
				}
				this._DialogCB.open();
			}

		},
		onChangespeicalstock: function (oEvent) {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else {
				if (!this._DialogSSI) {
					this._DialogSSI = sap.ui.xmlfragment(
						"SIE_ASP_WM_Stock_update.SIE_ASP_WM_Stock_update.Fragment.Specialstockindicator",
						this
					);
					this.getView().addDependent(this._DialogSSI);
				}
				this._DialogSSI.open();
			}
		},
		onChangebatchnSave: function () {

			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");
			if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("B");
				this._DialogCB.close();
				this._DialogCB.destroy();
				this._DialogCB = undefined;
			} else {
				var ChngBatchNum = {
					"BatchNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ChgBatchNo": sap.ui.getCore().byId("oNewbatchno1").getValue()
				};
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					//"Stockcat": "",
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": "B",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": [],
					"ITEMTOBATCH_NAV": ChngBatchNum,
					"ITEMTOSPECIALSTOCK_NAV": {}

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.Msgtype === "S") {

							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.success(oData.Msgdesc, {

								actions: ["Change batch and Special stock", "Go Back to Main Menu"],
								title: "Change batch and Special stock",
								onClose: function (oAction) {
									that._DialogCB.close();
									that._DialogCB.destroy();
									that._DialogCB = undefined;
									if (oAction == "Change batch and Special stock") {
										that.ChangeStockcategory();

									} else {
										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.show(
								oData.Msgdesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						sap.m.MessageBox.error("Error");
						that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
						that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
					}
				});
			}

		},
		onChangebatchnClear: function () {
			sap.ui.getCore().byId("oNewbatchno1").setValue("");
		},
		onchangebatchnBack: function () {
			var that = this;
			that._DialogCB.close();
			that._DialogCB.destroy();
			that._DialogCB = undefined;
		},
		onSpecialStockindSave: function () {

			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");
			if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("S");
				this._DialogSSI.close();
				this._DialogSSI.destroy();
				this._DialogSSI = undefined;
			} else {
				var ChngSpecialstockdetails = {
					
					
/*	"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
	"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
	"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
	"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
		"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
			"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),*/
	
	
					"SpecialStockInd": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),

					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),

					"SpecialStockIndChg": sap.ui.getCore().byId("oNewSpecialstockind1").getValue(),
					"SpecialStockNoChg": sap.ui.getCore().byId("oNewSpecialstocknoval").getValue()
				};
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					//	"Stockcat": "",
					
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": "S",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": [],
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": ChngSpecialstockdetails

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.Msgtype === "S") {
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							that.oBusyDialog.close();
							sap.m.MessageBox.success(oData.Msgdesc, {

								actions: ["Change batch and Special stock", "Go Back to Main Menu"],
								title: "Change batch and Special stock",
								onClose: function (oAction) {
									that._DialogSSI.close();
									that._DialogSSI.destroy();
									that._DialogSSI = undefined;
									if (oAction == "Change batch and Special stock") {
										that.ChangeStockcategory();

									} else {
										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.show(
								oData.Msgdesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						sap.m.MessageBox.error("Error");
						that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
						that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
					}
				});
			}

		},
		onSpecialStockindClear: function () {
			sap.ui.getCore().byId("oNewSpecialstockind1").setValue("");
			sap.ui.getCore().byId("oNewSpecialstocknoval").setValue("");
		},
		onBack1: function () {
			var that = this;
			that._DialogSSI.close();
			that._DialogSSI.destroy();
			that._DialogSSI = undefined;

		},
		//Serial number post operation
		oMaintianSerialNoBtnPost: function (Action) {
			//	var Action = this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Action");
			if (Action === "Q" || Action === "U") {
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),

					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": Action,
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData"),
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": {}

				};
			} else if (Action === "B") {
				var ChngBatchNum = {
					"BatchNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ChgBatchNo": sap.ui.getCore().byId("oNewbatchno1").getValue()
				};
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),

					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": Action,
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData"),
					"ITEMTOBATCH_NAV": ChngBatchNum,
					"ITEMTOSPECIALSTOCK_NAV": {}

				};
			} else if (Action === "S") {

				var ChngSpecialstockdetails = {
					"SpecialStockInd": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),

					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockIndChg": sap.ui.getCore().byId("oNewSpecialstockind1").getValue(),
					"SpecialStockNoChg": sap.ui.getCore().byId("oNewSpecialstocknoval").getValue()
				};
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": Action,
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData"),
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": ChngSpecialstockdetails

				};

			}
			this.oBusyDialog.open();
			var that = this;
			this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
				success: function (oData, oResponse) {
					if (oData.Msgtype === "S") {

						that.oBusyDialog.close();
						that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", null);
						sap.m.MessageBox.show(oData.Msgdesc, {

							actions: ["Change Stock Category", "Go Back to Main Menu"],
							title: "Change Stock Category",
							onClose: function (oAction) {

								if (oAction == "Change Stock Category") {

									that.ChangeStockcategory();

								} else {
									that.onBack();
								}

							}

						});
					} else {
						that.oBusyDialog.close();
						sap.m.MessageBox.show(
							oData.Msgdesc, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Error",
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);
					}
				},
				error: function (oError) {
					that.oBusyDialog.close();
					that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
				}
			});

		}

	});

});