jQuery.sap.require("sap.ndc.BarcodeScanner");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"
], function (Controller, History, JSONModel,MessageBox) {
	"use strict";

	return Controller.extend("SIE_ASP_WM_Stock_update.SIE_ASP_WM_Stock_update.controller.ChangeStockcategory", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf SIE_ASP_WM_Stock_update.SIE_ASP_WM_Stock_update.view.ChangeStockcategory
		 */
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		this.oFioriClient = this.getOwnerComponent().getFioriClient();
			oRouter.getRoute("ChangeStockcategory").attachPatternMatched(this._onObjectMatched, this);
			this.oBusyDialog = new sap.m.BusyDialog();
		},
		_onObjectMatched: function (oEvent) {
			
			if (oEvent.getParameter("arguments").WarehouseNo && oEvent.getParameter("arguments").Plant) {
				this.WarehouseNo = oEvent.getParameter("arguments").WarehouseNo;
				this.Plant = oEvent.getParameter("arguments").Plant;
				this.SelectedCategoryBtn = oEvent.getParameter("arguments").SelectedCategoryBtn;

				var sTr = "WarehouseNo eq '" + this.WarehouseNo + "'";
				this.oBusyDialog.open();
				/*	var oParam = {
						"$filter": "WarehouseNo eq '" + WarehouseNo + "'"
					};*/

				var oBindingInfo = {
					filters: null,
					urlParameters: {
						"$filter": sTr
					},
					success: function (oData, oResponse) {
						this.oBusyDialog.close();
						var oStogeBinModel = new JSONModel(oData.results);
						this.getView().setModel(oStogeBinModel, "oStogeBinModel");
					}.bind(this),
					error: function (oError) {
						this.oBusyDialog.close();
						var oStogeBinModel = new JSONModel([]);
						this.getView().setModel(oStogeBinModel, "oStogeBinModel");
					}.bind(this)
				};

				this.getOwnerComponent().getModel("STOCK_INFO_SRV").read("/StoragebinlistSet", oBindingInfo);
			}
		},

		handleValueHelpStoragebin: function (oEvent) {

			if (!this._Dialog) {
				this._Dialog = sap.ui.xmlfragment(
					"SIE_ASP_WM_Stock_update.SIE_ASP_WM_Stock_update.Fragment.Storagebinlist",
					this
				);
				this.getView().addDependent(this._Dialog);
			}
			this._Dialog.open();

		},

		handleStoragbinfSearch_Press: function (oEvent) {
			var aFilters = [];
			var sQuery = oEvent.getParameter("value");
			var list = sap.ui.getCore().byId("oStrbin");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("StoragebinType", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("StorageBin", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		onStoragebinConfirm: function (oEvent) {
			var oSelectedItemStoragebin = oEvent.getParameter('selectedItem').getProperty("title");
			this.oselectedStoragebinType = oEvent.getParameter('selectedItem').getProperty("description");
			if (oSelectedItemStoragebin) {
				var oStorageInputval = this.getView().byId("filterStorageBin");
				oStorageInputval.setValue(oSelectedItemStoragebin);
			}
			else{
			 this.getView().byId("filterStorageBin").setValue("");
			}
			oEvent.getSource().getBinding("items").filter([]);
		//	this._CheckStoragebin(oSelectedItemStoragebin);
			this._Dialog.destroy(true);
			this._Dialog = undefined;

		},
		onStoragbinCancel: function () {
			this._Dialog.destroy(true);
			this._Dialog = undefined;
		},
		handleStoragebinSearch:function(oEvt){
			var StoragebinVal=oEvt.getSource().getValue();
		if(StoragebinVal){
				this._CheckStoragebin(StoragebinVal);	
			}
			else{
				var oMateriallistModel = new JSONModel([]);
					this.getView().setModel(oMateriallistModel, "oMateriallistModel");	
			}
		},

		_CheckStoragebin: function (oSelectedItemStoragebin) {
			

			this.oBusyDialog.open();
			var oBindingInfo = {
				success: function (oData, oResponse) {
					this.oBusyDialog.close();
					if (oData.MsgType === "S") {
						var oStorageBinSuccess = oData.StorageBin;
						
						this.oBusyDialog.close();
						this.MaterialListSet(oStorageBinSuccess);

					} else {
						this.oBusyDialog.close();
							var oMateriallistModel = new JSONModel([]);
					this.getView().setModel(oMateriallistModel, "oMateriallistModel");
						sap.m.MessageBox.show(
							oData.MsgDesc, {
								icon: sap.m.MessageBox.Icon.ERROR,
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);
					}
				}.bind(this),
				error: function (oError) {
					this.oBusyDialog.close();
						var oMateriallistModel = new JSONModel([]);
					this.getView().setModel(oMateriallistModel, "oMateriallistModel");
					var oCheckStogeBinModel = new JSONModel([]);
					this.getView().setModel(oCheckStogeBinModel, "oCheckStogeBinModel");
				}.bind(this)
			};

			this.getOwnerComponent().getModel("STOCK_INFO_SRV").read("/ChkStorageBinSet(WarehouseNo='" + this.WarehouseNo + "',StorageBin='" +
				oSelectedItemStoragebin + "')", oBindingInfo);

		},
		MaterialListSet: function (oStorageBinSuccess) {
			

			/*	this.WarehouseNo 
				this.Plant */
			var sTr = "WarehouseNo eq '" + this.WarehouseNo + "'and StorageBin eq '" + oStorageBinSuccess + "'and Plant eq '" + this.Plant +
				"'";
			this.oBusyDialog.open();
			var oBindingInfotable = {
				filters: null,
				urlParameters: {
					"$filter": sTr
				},
				success: function (oData, oResponse) {
					this.oBusyDialog.close();
					var oMateriallistModel = new JSONModel(oData.results);
					this.getView().setModel(oMateriallistModel, "oMateriallistModel");
				}.bind(this),
				error: function (oError) {
					this.oBusyDialog.close();
					var oMateriallistModel = new JSONModel([]);
					this.getView().setModel(oMateriallistModel, "oMateriallistModel");
				}.bind(this)
			};
			this.getOwnerComponent().getModel("STOCK_INFO_SRV").read("/MaterialListSet", oBindingInfotable);
		},

		onNavBack: function () {

			
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ChangeStockInfo", {

			});

		},
		//barcode scanner functionalities....
			onBarCodeScan: function() {
				
		/*	if (this.oFioriClient.isAvailable()) {
				window.cordova.plugins.barcodeScanner.scan(
					this.onSuccess.bind(this),
					this.onError.bind(this)
				);
			}
			else{*/
				sap.ndc.BarcodeScanner.scan(
					this.onSuccess.bind(this),
					this.onError.bind(this)
			);
	//		}
			},
			// onSuccess Callback 
			onSuccess: function(result) {
					var bCancelled = result.cancelled;
					this.getView().byId("filterStorageBin").setValue("");
					this.getView().byId("filterStorageBin").setValue(result.text);
					if(result.text&&bCancelled==false){
					this._CheckStoragebin(result.text);
					}
				else if (bCancelled) {
						sap.m.MessageToast.show("Scan Cancelled");
					}
					
			},
				
			// onError Callback
			onError: function(error) {
					sap.m.MessageToast.show(error, "Error");
			},
		
		ovalidationLookupForStoragBin:function(storageBinNo){
			
			var oWareHouseNo = this.getOwnerComponent().getModel("localModel").getProperty("/LoginUserInfo/WarehouseNo");
			//oWareHouseNo = "K01"; // for testing..
			var sPath = this.getOwnerComponent().getModel("STOCK_INFO_SRV").createKey("CHkStoraebinSet", {
					StorageBin :  storageBinNo,
					WarehouseNo:  oWareHouseNo
				});
				
			var oBusyDialog = new sap.m.BusyDialog();
				var 
				oBindingInfo = "";
				
				oBindingInfo = {
				filters : null,
				urlParameters:null,
				success:function(oData,oResponse)
					{
						
							//console.log(oData);
							oBusyDialog.close();
							if(oData.MsgType === "S"){
								this.MaterialListSet(storageBinNo);
							}else if(oData.MsgType === "E"){
								sap.m.MessageBox.error(oData.MsgDesc);
							}
							
						
					}.bind(this),
					error:function(oError){
						oBusyDialog.close();
						sap.m.MessageToast.show("odata Error occoured");
					}.bind(this)
				};
				
			
					 this.getOwnerComponent().getModel("STOCK_INFO_SRV").read("/"+ sPath,oBindingInfo);
			
		},
		onProcess: function (oEvent) {
				
				var oTable = this.getView().byId("table");
				var oSelectedObject = oEvent.getSource().getParent().getBindingContext("oMateriallistModel").getObject();

				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("ChangestockcatDisplay", {
					Sloc: oSelectedObject.Sloc,
					Material: oSelectedObject.Material,
					WarehouseNo: oSelectedObject.WarehouseNo,
					StorageBin: oSelectedObject.StorageBin,
					Plant: oSelectedObject.Plant,
                	SelectedCategoryBtn: this.SelectedCategoryBtn,
                	SpecialStoc:oSelectedObject.SpecialStoc,
                		Indicator: oSelectedObject.Indicator,
                			Batchno:oSelectedObject.Batchno,
                			Stockcat :oSelectedObject.Stockcat 
				});

			}
			/*	getRouter : function () {
					return sap.ui.core.UIComponent.getRouterFor(this);
				}*/

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf SIE_ASP_WM_Stock_update.SIE_ASP_WM_Stock_update.view.ChangeStockcategory
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf SIE_ASP_WM_Stock_update.SIE_ASP_WM_Stock_update.view.ChangeStockcategory
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf SIE_ASP_WM_Stock_update.SIE_ASP_WM_Stock_update.view.ChangeStockcategory
		 */
		//	onExit: function() {
		//
		//	}

	});

});