sap.ui.define([
	"mytime/ZMOB_MY_TIME_Redesign/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"mytime/ZMOB_MY_TIME_Redesign/js/Utilities",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"mytime/ZMOB_MY_TIME_Redesign/js/formatter"
], function (Controller, JSONModel, Utilities, MessageBox, MessageToast, formatter) {
	"use strict";

	return Controller.extend("mytime.ZMOB_MY_TIME_Redesign.controller.CrewEmpList", {
		formatter: formatter,
		onInit: function () {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oComponent = this.getOwnerComponent();
			this.sCrew = {};

			this._handleRouting();

		},
		_handleRouting: function () {
			this.getRouter().attachRouteMatched(function (oEvent) {
				var sNavigationName = oEvent.getParameter("name");
				this.applicationId = this._getApplicationId();
				if (sNavigationName === "CrewEmpList" || (sNavigationName === "CrewTime" && (this.sCrew.CrewId === undefined || this.sCrew.CrewId ===
						""))) {
					this.sCrew.JobCode = oEvent.getParameter("arguments").JobCode;
					this.sCrew.CrewId = oEvent.getParameter("arguments").CrewId;
					this.sCrew.EffectiveDate = oEvent.getParameter("arguments").EffectiveDate;

					this.byId("idDate").setValue(this.sCrew.EffectiveDate);

					this.getView().bindElement({
						path: "/CrewListSet(JobCode='" + this.sCrew.JobCode + "',CrewId='" + encodeURIComponent(this.sCrew.CrewId) +
							"',EffectiveDate='" + this.sCrew.EffectiveDate +
							"',ApplicationId='" + this.applicationId + "')",
						events: {

							change: function (e) {
								var oContextBinding = e.getSource();
								oContextBinding.refresh(false); 
							},
							dataRequested: function () {},
							dataReceived: function () {}
						}
					});

					this._initializeCrewTimeDataServiceModels(this.sCrew);

				}
			}, this);

		},
		_getApplicationId: function () {

			var appId = "E";
			try {
				var approverFlag = this.getOwnerComponent().getComponentData().startupParameters['TA'][0];
				if (approverFlag === 'X') {
					appId = "A";
				}
			} catch (err) {};
			return appId;
		},
		_initializeCrewTimeDataServiceModels: function (oCrew) {
			this.getView().setModel(new JSONModel(), "crewEmpList");
			this._initializeCrewEmployeeData(oCrew);
		},
		_initializeCrewEmployeeData: function (oCrew) {
			this.showBusyIndicator(4000, 1);
			this.oComponent.getDataProvider().loadCrewEmployees(this, oCrew);
		},
		onDateChange: function (oEvent) {
			/*			this.showBusyIndicator(4000, 1);
						var oDate = oEvent.getParameter("value");
						this.sCrew.EffectiveDate = oDate;
						this.getView().byId("idTable").removeSelections();
						this.oComponent.getDataProvider().loadCrewEmployeesByDate(this, this.sCrew, oDate);
						this.oComponent.getDataProvider().loadCrew(this, oDate, this.sCrew);*/
		},
		onCrewEmpLoad: function (aCrewEmplist) {
			var aItem = [];

			if (aCrewEmplist !== undefined && aCrewEmplist.length > 0) {
				aItem.push({
					Ename: "All Crew Members",
					Pernr: "00000000",
					EmpBecref: "00000000",
					CrewEffectiveDate: aCrewEmplist[0].CrewEffectiveDate,
					JobCode: aCrewEmplist[0].JobCode,
					CrewId: aCrewEmplist[0].CrewId,
					Description: aCrewEmplist[0].Description,
					EffectiveDate: aCrewEmplist[0].EffectiveDate,
					Shift: aCrewEmplist[0].Shift,
					ShiftDescription: aCrewEmplist[0].ShiftDescription,
					EmpPersk: aCrewEmplist[0].EmpPersk,
					EmpPersg: aCrewEmplist[0].EmpPersg,
					EmpZztrfgr: aCrewEmplist[0].EmpZztrfgr,
					EmpEffectiveDate: aCrewEmplist[0].EmpEffectiveDate,
					DeleteFlag: " ",
					TotalHours: aCrewEmplist[0].TotalHours,
					EmpZztrfgrTx: aCrewEmplist[0].EmpZztrfgrTx,
					//	CraftDescription: aCrewEmplist[0].CraftDescription
				});
			}
			for (var i = 0; i < aCrewEmplist.length; i++) {
				aItem.push({
					Ename: aCrewEmplist[i].Ename,
					ParentId: aCrewEmplist[i].ParentId,
					CrewEffectiveDate: aCrewEmplist[i].CrewEffectiveDate,
					JobCode: aCrewEmplist[i].JobCode,
					CrewId: aCrewEmplist[i].CrewId,
					Pernr: aCrewEmplist[i].Pernr,
					Description: aCrewEmplist[i].Description,
					EffectiveDate: aCrewEmplist[i].EffectiveDate,
					Shift: aCrewEmplist[i].Shift,
					ShiftDescription: aCrewEmplist[i].ShiftDescription,
					EmpPersk: aCrewEmplist[i].EmpPersk,
					EmpPersg: aCrewEmplist[i].EmpPersg,
					EmpZztrfgr: aCrewEmplist[i].EmpZztrfgr,
					EmpBecref: aCrewEmplist[i].EmpBecref,
					EmpEffectiveDate: aCrewEmplist[i].EmpEffectiveDate,
					DeleteFlag: " ",
					TotalHours: aCrewEmplist[i].TotalHours,
					EmpZztrfgrTx: aCrewEmplist[i].EmpZztrfgrTx,
					CraftDescription: aCrewEmplist[i].CraftDescription
				});
			}
			this.getModel("crewEmpList").setSizeLimit(aItem.length);
			this.setProperty("crewEmpList", "/CrewListSet", aItem);
			this.hideBusyIndicator();

		},
		onCrewEmpError: function (oError) {
			var errorDetails = this.parseError(oError.responseText);
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.error(errorDetails, {
				styleClass: bCompact ? "sapUiSizeCompact" : ""
			});
		},
		onTimesheet: function (oEvent) {
			var bReplace = "";
			var oItem = oEvent.getParameter("listItem");
			var oCtx = oItem.getBindingContextPath();
			var aId = this.getProperty("crewEmpList", oCtx);

			this.getRouter().navTo("CrewTime", {
				"JobCode": aId.JobCode,
				"CrewId": aId.CrewId,
				"EffectiveDate": aId.EffectiveDate,
				"EmpBecref": aId.EmpBecref
			});
		},

		hideBusyIndicator: function () {
			sap.ui.core.BusyIndicator.hide();
		},
		showBusyIndicator: function (iDuration, iDelay) {
			sap.ui.core.BusyIndicator.show(iDelay);
			if (iDuration && iDuration > 0) {
				if (this._sTimeoutId) {
					jQuery.sap.clearDelayedCall(this._sTimeoutId);
					this._sTimeoutId = null;
				}
				this._sTimeoutId = jQuery.sap.delayedCall(iDuration, this, function () {
					this.hideBusyIndicator();
				});
			}
		},
		/*		onCrewLoad: function (aCrew) {

					//			this.byId("idStatus").setText(aCrew.StatusTx);
					//			this.byId("idStatus").setState(formatter.Status(aCrew.StatusTx));
					this.sCrew.JobCode = aCrew.JobCode;
					this.sCrew.CrewId = aCrew.CrewId;
					this.sCrew.Description = aCrew.Description;
					this.sCrew.ShiftDescription = aCrew.ShiftDescription;
					this.sCrew.EffectiveDate = aCrew.EffectiveDate;
					this.sCrew.JobCode = aCrew.JobCode;
					this.sCrew.FmName = aCrew.FmName;
					this.sCrew.StatusTx = aCrew.StatusTx;
					this.sCrew.FmWerks = aCrew.FmWerks;
					this.sCrew.CrewEffectiveDate = aCrew.CrewEffectiveDate;
				},
				onCrewListError: function (oError) {
					var errorDetails = this.parseError(oError.responseText);
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.error(errorDetails, {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					});
				},*/
		parseError: function (oError) {
			var messageText;
			try {
				// Try to parse as a JSON string
				messageText = JSON.parse(oError);
				messageText = messageText.error.code + ": " + messageText.error.message.value; // + "\n" + "Please contact Administrator.";	SAP-8326						
			} catch (err) {
				try {
					switch (typeof oError) {
					case "string": // XML or simple text
						if (oError.indexOf("<?xml") === 0) {
							var oXML = jQuery.parseXML(oError);
							var oXMLMsg = oXML.querySelector("message");
							if (oXMLMsg) {
								messageText = oXMLMsg.textContent;
							}
						} else {
							messageText = oError;
						}
						break;
					case "object": // Exception
						messageText = oError.toString();
						break;
					}
				} catch (err) {
					messageText = "An unknown error occurred!! Please contact Administrator !!";
				}
			}
			return messageText.replace("/IWBEP/CM_MGW_RT/022: ", "");
		},

		// flexible layout buttons

		onCloseDetailPress: function () {
			var oModel = this.getView().getModel("app");
			oModel.setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
			this.getOwnerComponent().getRouter().navTo("CrewList", {}, true);
		},

		toggleFullScreen: function () {
			var oModel = this.getView().getModel("app");
			var bFullScreen = oModel.getProperty("/actionButtonsInfo/midColumn/fullScreen");
			oModel.setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
			if (!bFullScreen) {
				// store current layout and go full screen
				oModel.setProperty("/previousLayout", oModel.getProperty("/layout"));
				oModel.setProperty("/layout", "MidColumnFullScreen");
			} else {
				// reset to previous layout
				oModel.setProperty("/layout", oModel.getProperty("/previousLayout"));
			}
		},

	});

});