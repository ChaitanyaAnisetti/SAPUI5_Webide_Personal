sap.ui.define([
	"mytime/ZMOB_MY_TIME_Redesign/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment",
	"sap/m/MessageToast",
	"sap/ui/core/syncStyleClass",
	"mytime/ZMOB_MY_TIME_Redesign/js/formatter",
	"mytime/ZMOB_MY_TIME_Redesign/js/Utilities",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/library",
	"sap/m/List",
	"sap/m/StandardListItem",
	"sap/m/Text",
	"sap/m/Label",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Filter"

], function (BaseController, JSONModel, MessageBox, Fragment, MessageToast, syncStyleClass, formatter, Utilities,
	Dialog, Button, mobileLibrary, List, StandardListItem, Text, Label, FilterOperator, Filter) {
	"use strict";
	var that;
	var sLastItemPath;
	var selDate;
	return BaseController.extend("mytime.ZMOB_MY_TIME_Redesign.controller.CrewTime", {
		formatter: formatter,
		onInit: function () {
			that = this;
			this.isReadOnly = true;
			//		var aUser = sap.ushell.Container.getService("UserInfo").getId(); 
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oComponent = this.getOwnerComponent();
			this.applicationId = this._getApplicationId();
			this._handleRouting();
			this.sCrew = {};
			this.timeTypeCategory = [];
			this.timeTypeDescription = [];
			this.deletedRows = [];
			this.oEmployees = [];
			this.countryCode = 13;
			this.hoursRule = '0000';

		},

		_handleRouting: function () {
			var a = this;
			this.getRouter().attachRouteMatched(function (oEvent) {
				var sNavigationName = oEvent.getParameter("name");
				this.applicationId = this._getApplicationId();
				if (sNavigationName === "CrewTime") {
					this.sCrew.JobCode = oEvent.getParameter("arguments").JobCode;
					this.sCrew.CrewId = oEvent.getParameter("arguments").CrewId;
					this.sCrew.EffectiveDate = oEvent.getParameter("arguments").EffectiveDate;
					this.sCrew.EmpBecref = oEvent.getParameter("arguments").EmpBecref;

					this.byId("idDate").setValue(this.sCrew.EffectiveDate);

					this.getView().bindElement({
						path: "/CrewListSet(JobCode='" + this.sCrew.JobCode + "',CrewId='" + encodeURIComponent(this.sCrew.CrewId) +
							"',EffectiveDate='" + this.sCrew.EffectiveDate +
							"',ApplicationId='" + this.applicationId + "')",
						events: {
							change: function (e) {
								var temp = that.sCrew.EmpBecref;
								that.sCrew = e.getSource().getBoundContext().getObject();
								that.sCrew.EmpBecref = temp;
								that._initializeCrewTimeDataServiceModels(that.sCrew);
								that._updatePageSetting();
								that._updateCrewTimeAdminRole();
							},
							dataRequested: function () {

								var a = 1;
							},
							dataReceived: function (e) {
								var temp = that.sCrew.EmpBecref;
								that.sCrew = e.getSource().getBoundContext().getObject();
								that.sCrew.EmpBecref = temp;
								that._updatePageSetting();
								that._updateCrewTimeAdminRole();
							}
						}
					});
					try {
						// no reason to put it here. will remove later. taking care in change event above
						var temp = that.sCrew.EmpBecref;
						this.sCrew = this.getView().getElementBinding().getBoundContext().getObject();
						that.sCrew.EmpBecref = temp;
						this._initializeCrewTimeDataServiceModels(this.sCrew);
						this._updatePageSetting();
						this._updateCrewTimeAdminRole();
					} catch (err) {}

				}
			}, this);
		},
		_updatePageSetting: function () {

			var oModel = this.getView().getModel("app");
			if (this.sCrew.EmpBecref === '00000000') {
				if (this.applicationId === 'A') {
					this.isReadOnly = true;

					oModel.setProperty("/timePageReadOnly", true);
					if (this.sCrew.Status === '20') {

						oModel.setProperty("/approvalReady", true);
					} else {
						oModel.setProperty("/approvalReady", false);
					}

				} else {
					if (this.sCrew.IsEditable === false) {
						this.isReadOnly = true;
						oModel.setProperty("/timePageReadOnly", true);
						oModel.setProperty("/approvalReady", false);

					} else {
						this.isReadOnly = false;
						oModel.setProperty("/timePageReadOnly", false);
						oModel.setProperty("/approvalReady", false);

					}
				}
			} else {

				this.isReadOnly = true;
				oModel.setProperty("/timePageReadOnly", true);
				oModel.setProperty("/approvalReady", false);
			}
		},
		_updateCrewTimeAdminRole: function () {
			try {
				var timeadminFlag = this.getOwnerComponent().getComponentData().startupParameters['AD'][0];
				var oModel = this.getView().getModel("app");
				if (timeadminFlag === 'Y' && this.sCrew.isTimeAdmin === 'X') {
					oModel.setProperty("/isUserCrewTimeAdmin", true);
				}
				
			} catch (err) {};
		},
		_getApplicationId: function () {
			/*			var appId = this.getOwnerComponent().getModel("appId").getProperty("/applicationId");

						if (appId === undefined || appId === "" || appId !== "A") {
							return "E";
						} else {
							return appId;
						}*/
			var appId = "E";
			try {
				var approverFlag = this.getOwnerComponent().getComponentData().startupParameters['TA'][0];
				if (approverFlag === 'X') {
					appId = "A";
				}
			} catch (err) {};
			return appId;
		},
		_initializeCrewTimeDataServiceModels: function (oCrew) {

			this.getView().setModel(new JSONModel(), "Employees");
			this.getView().setModel(new JSONModel(), "crewTimeRedesign");
			this.getView().setModel(new JSONModel(), "timeTypes");
			this.getView().setModel(new JSONModel(), "searchHelpTimeType");
			this._initializeSearchHelpTimeType(oCrew);

			this.getView().setModel(new JSONModel(), "crewTime");
			this._initializeCrewTimeData(oCrew);
			this.getView().setModel(new JSONModel(), "searchHelpClass");
			this._initializeSearchHelpClass(oCrew);
			//this.getView().setModel(new JSONModel(), "searchHelpCostCode");
			this._initializeSearchHelpCostCode(oCrew);
			this._initializeSearchHelpUnassignedCostCode(oCrew);

			this.getView().setModel(new JSONModel(), "searchHelpActivity");
			this._initializeSearchHelpActivity(oCrew);

			//	this.oComponent.getDataProvider().loadCrew(this, this.sCrew.EffectiveDate, this.sCrew);

		},

		_initializeCrewTimeData: function (oCrew) {
			this.showBusyIndicator(4000, 1);
			this.oComponent.getDataProvider().loadCrewTime(this, oCrew);
		},

		_initializeSearchHelpClass: function (oCrew) {
			this.setData("searchHelpClass", {
				selection: {
					Werks: "",
					Persg: "",
					Persk: "",
					Trfgr: "",
					Trfst: "",
					ClassDesc: ""
				},
				SearchHelpClass: []
			});
			this.oComponent.getDataProvider().loadSearchHelpClass(this, oCrew.FmWerks);
		},
		_initializeSearchHelpCostCode: function (oCrew) {
			/*			this.setData("searchHelpCostCode", {
							selection: {
								CostcodeTx: " ",
								CrewId: " ",
								Entity: " ",
								JobCode: " ",
								Costcode: " ",
								Zzptjcd: " ",
								Zzcst: " ",
								Zzssc: " ",
								ClassEditable: " ",
								ZzactEditable: " ",
							},
							SearchHelpCostCode: []
						});*/
			this.oComponent.getDataProvider().loadSearchHelpCostCode(this, oCrew);
		},
		_initializeSearchHelpUnassignedCostCode: function (oCrew) {

			this.oComponent.getDataProvider().loadSearchHelpUnassignedCostCode(this, oCrew);
		},
		_initializeSearchHelpActivity: function (oCrew) {
			this.setData("searchHelpActivity", {
				selection: {
					JobCode: " ",
					Zzact: " ",
					EffectiveDate: " ",
					WorkpkgId: " ",
					WorkpkgDesc: " "

				},
				SearchHelpActivity: []
			});
			this.oComponent.getDataProvider().loadSearchHelpActivity(this, oCrew.EffectiveDate, oCrew.JobCode);
		},

		_initializeSearchHelpTimeType: function (oCrew) {
			this.setData("searchHelpTimeType", {
				selection: {
					JobCode: " ",
					CrewId: " ",
					EffectiveDate: " ",
					TimeType: " ",
					TimeTypeTx: " "

				},
				SearchHelpActivity: []
			});
			this.oComponent.getDataProvider().loadSearchHelpTimeType(this, oCrew);
		},
		onDateChange: function (oEvent) {
			var oDate = oEvent.getParameter("value");
			selDate = oEvent.getParameter("value");
			this.showBusyIndicator(4000, 1);
			this.oComponent.getDataProvider().loadCrewTimebyDate(this, oDate, this.sCrew);
			this.oComponent.getDataProvider().loadCrew(this, oDate, this.sCrew);
			this.oComponent.getDataProvider().loadSearchHelpActivity(this, oDate, this.sCrew.JobCode);
		},
		onCrewTimeLoad: function (aCrewTime) {

			//	this.PopulatData();
			var oEntry = {};
			var ItemData = [];
			var HeadData = [];
			this.deletedRows = [];
			this.oEmployees = [];

			var oEntryRedesign = {};
			var oColumnResdeisgn = [];
			for (var i = 0; i < aCrewTime.length; i++) {
				HeadData.push({
					ClockIn: aCrewTime[i].ClockIn,
					ClockOut: aCrewTime[i].ClockOut,
					CraftDescription: aCrewTime[i].CraftDescription,
					CrewEffectiveDate: aCrewTime[i].CrewEffectiveDate,
					CrewId: aCrewTime[i].CrewId,
					Description: aCrewTime[i].Description,
					EffectiveDate: aCrewTime[i].EffectiveDate,
					EmpBecref: aCrewTime[i].EmpBecref,
					EmpEffectiveDate: aCrewTime[i].EmpEffectiveDate,
					EmpPersg: aCrewTime[i].EmpPersg,
					EmpPersk: aCrewTime[i].EmpPersk,
					EmpWerks: aCrewTime[i].EmpWerks,
					EmpZztrfgr: aCrewTime[i].EmpZztrfgr,
					EmpZztrfgrTx: aCrewTime[i].EmpZztrfgrTx,
					Ename: aCrewTime[i].Ename,
					JobCode: aCrewTime[i].JobCode,
					ParentId: aCrewTime[i].ParentId,
					Pernr: aCrewTime[i].Pernr,
					PlannedHours: aCrewTime[i].PlannedHours,
					Shift: aCrewTime[i].Shift,
					ShiftDescription: aCrewTime[i].ShiftDescription,
					TotalHours: aCrewTime[i].TotalHours,
					EmpCountryCode: aCrewTime[i].EmpCountryCode,
					HoursRule: aCrewTime[i].HoursRule
				});
				this.oEmployees[i] = HeadData[i];
				var a = aCrewTime[i].ToEmpTime.results.length;
				if (a > 0) {

					for (var j = 0; j < aCrewTime[i].ToEmpTime.results.length; j++) {
						ItemData.push({
							Class: aCrewTime[i].ToEmpTime.results[j].Class,
							ClassEditable: aCrewTime[i].ToEmpTime.results[j].ClassEditable,
							ClassTx: aCrewTime[i].ToEmpTime.results[j].ClassTx,
							Costcode: aCrewTime[i].ToEmpTime.results[j].Costcode,
							CostcodeTx: aCrewTime[i].ToEmpTime.results[j].CostcodeTx,
							Counter: aCrewTime[i].ToEmpTime.results[j].Counter,
							CrewId: aCrewTime[i].ToEmpTime.results[j].CrewId,
							Hours: aCrewTime[i].ToEmpTime.results[j].Hours,
							IsEditable: aCrewTime[i].ToEmpTime.results[j].IsEditable,
							IsNewRecord: aCrewTime[i].ToEmpTime.results[j].IsNewRecord,
							JobCode: aCrewTime[i].ToEmpTime.results[j].JobCode,
							LongText: aCrewTime[i].ToEmpTime.results[j].LongText,
							LongText_Data: aCrewTime[i].ToEmpTime.results[j].LongText_Data,
							ParentId: aCrewTime[i].ToEmpTime.results[j].ParentId,
							Pernr: aCrewTime[i].ToEmpTime.results[j].Pernr,
							Prakn: aCrewTime[i].ToEmpTime.results[j].Prakn,
							Prakz: aCrewTime[i].ToEmpTime.results[j].Prakz,
							Qnty: aCrewTime[i].ToEmpTime.results[j].Qnty,
							RefCounter: aCrewTime[i].ToEmpTime.results[j].RefCounter,
							TimeType: aCrewTime[i].ToEmpTime.results[j].TimeType,
							Trfst: aCrewTime[i].ToEmpTime.results[j].Trfst,
							Workdate: aCrewTime[i].ToEmpTime.results[j].Workdate,
							Zzact: aCrewTime[i].ToEmpTime.results[j].Zzact,
							ZzactEditable: aCrewTime[i].ToEmpTime.results[j].ZzactEditable,
							Zzcst: aCrewTime[i].ToEmpTime.results[j].Zzcst,
							Zzptjcd: aCrewTime[i].ToEmpTime.results[j].Zzptjcd,
							Zzssc: aCrewTime[i].ToEmpTime.results[j].Zzssc,
							DeleteFlag: ""
						});
					}
					oEntry.CrewTime = HeadData;
					oEntry.CrewTime[i].Time = ItemData;

					ItemData = [];
				} else {
					oEntry.CrewTime = HeadData;
				}

			}
			// var oModel = this.getView().getModel("crewTime");
			// oModel.setProperty("/CrewTime", oEntry, null, true);

			// ***************************************

			this.getView().getModel("Employees").setProperty("/Employees", this.oEmployees, null, true);
			oEntryRedesign = this._buildRows(this.oEmployees, oEntry.CrewTime);
			var oModelRedesign = this.getView().getModel("crewTimeRedesign");
			oModelRedesign.setProperty("/CrewTime", oEntryRedesign, null, true);
			this._buildTable(this.oEmployees);
			// ***************************************
			this.hideBusyIndicator();

		},
		_buildRows: function (oEmployees, oCrewTime) {

			var rowStruct;
			var tableRows = [];
			var rowExistsIndex = -2;
			this.TotalTimesheetHours = 0.00;

			if (oCrewTime !== undefined && oCrewTime.length !== undefined) {
				for (var i = 0; i < oCrewTime.length; i++) {
					if ((oCrewTime[i].Time !== undefined)) {
						var a = oCrewTime[i].Time.length;
						if (a > 0) {
							for (var j = 0; j < oCrewTime[i].Time.length; j++) {
								const Hours = 'Hours' + i;
								const HoursEditable = 'HoursEditable' + i;
								const Qnty = 'Qnty' + i;
								const DeleteFlag = 'DeleteFlag' + i;
								const LongText = 'LongText' + i;
								const LongTextData = 'LongText_Data' + i;

								const HoursCounter = 'HoursCounter' + i;
								const HoursRefcount = 'HoursRefcount' + i;
								const ParentId = 'ParentId' + i;
								const classcol = 'Class' + i;
								const trfstcol = 'Trfst' + i;
								rowStruct = {
									EmployeeColumnNo: i,
									Zzcst: oCrewTime[i].Time[j].Zzcst,
									Zzptjcd: oCrewTime[i].Time[j].Zzptjcd,
									Zzssc: oCrewTime[i].Time[j].Zzssc,
									Zzact: oCrewTime[i].Time[j].Zzact,
									Prakn: oCrewTime[i].Time[j].Prakn,
									Prakz: oCrewTime[i].Time[j].Prakz,
									TimeType: oCrewTime[i].Time[j].TimeType,
									Costcode: oCrewTime[i].Time[j].Costcode,
									CostcodeTx: oCrewTime[i].Time[j].CostcodeTx,
									TimeType: oCrewTime[i].Time[j].TimeType,
									IsDeletedRow: false,
									isNewRow: false,
									[Hours]: oCrewTime[i].Time[j].Hours,
									[Qnty]: oCrewTime[i].Time[j].Qnty,
									[LongText]: oCrewTime[i].Time[j].LongText,
									[LongTextData]: oCrewTime[i].Time[j].LongText_Data,
									[HoursCounter]: oCrewTime[i].Time[j].Counter,
									[HoursRefcount]: oCrewTime[i].Time[j].RefCounter,
									[ParentId]: oCrewTime[i].Time[j].ParentId,
									[classcol]: oCrewTime[i].Time[j].Class,
									[trfstcol]: oCrewTime[i].Time[j].Trfst,
									CostCodeTotalHours: '0.00'
								};
								rowExistsIndex = -2;
								var isEmptyFound = false;
								while (isEmptyFound === false) {
									rowExistsIndex = this._findRowInColumnStructTable(rowStruct, tableRows, rowExistsIndex);
									const HoursCounter = 'HoursCounter' + i;
									if (rowExistsIndex === -1 || tableRows[rowExistsIndex][HoursCounter] === undefined) {
										isEmptyFound = true;
									}
								}
								if (rowExistsIndex > -1) {
									tableRows = this._mergeTableRows(rowStruct, tableRows, rowExistsIndex);
								} else {
									if (this.timeTypeCategory[oCrewTime[i].Time[j].TimeType] !== 'PD') {
										rowStruct.CostCodeTotalHours = oCrewTime[i].Time[j].Hours;
										this.TotalTimesheetHours = parseFloat(this.TotalTimesheetHours) + parseFloat(rowStruct.CostCodeTotalHours);
									}
									tableRows.push(rowStruct);
								}
							}
						}
					}

				}
			}

			// sort by Costcode
			tableRows.sort(function (a, b) {
				const CostcodeA = a.Costcode.toUpperCase(); // ignore upper and lowercase
				const CostcodeB = b.Costcode.toUpperCase(); // ignore upper and lowercase
				if (CostcodeA < CostcodeB) {
					return -1;
				}
				if (CostcodeA > CostcodeB) {
					return 1;
				}

				return 0;
			});
			return tableRows;
		},
		_findRowInColumnStructTable: function (oRow, oTableRows, startIndex) {
			let index = oTableRows.findIndex(
				(row, index) => row.Zzcst === oRow.Zzcst &&
				row.Zzptjcd === oRow.Zzptjcd &&
				row.Zzssc === oRow.Zzssc &&
				row.Zzact === oRow.Zzact &&
				row.TimeType === oRow.TimeType && index > startIndex

			);
			return index;
		},

		_mergeTableRows: function (orowStruct, ocolumnStructTable, orowLocationToMerge) {
			var i = orowStruct.EmployeeColumnNo;
			const Hours = 'Hours' + i;
			const HoursEditable = 'HoursEditable' + i;
			const Qnty = 'Qnty' + i;
			const DeleteFlag = 'DeleteFlag' + i;
			const LongText = 'LongText' + i;
			const LongTextData = 'LongText_Data' + i;
			const HoursCounter = 'HoursCounter' + i;
			const HoursRefcount = 'HoursRefcount' + i;
			const classcol = 'Class' + i;
			const trfstcol = 'Trfst' + i;
			const ParentId = 'ParentId' + i;

			if (this.timeTypeCategory[orowStruct.TimeType] !== 'PD') {
				ocolumnStructTable[orowLocationToMerge].CostCodeTotalHours = parseFloat(ocolumnStructTable[orowLocationToMerge].CostCodeTotalHours) +
					parseFloat(orowStruct[Hours]);
				this.TotalTimesheetHours = parseFloat(this.TotalTimesheetHours) + parseFloat(orowStruct[Hours]);
			}

			ocolumnStructTable[orowLocationToMerge][Hours] = orowStruct[Hours];
			ocolumnStructTable[orowLocationToMerge][HoursEditable] = orowStruct[HoursEditable];
			ocolumnStructTable[orowLocationToMerge][Qnty] = orowStruct[Qnty];
			ocolumnStructTable[orowLocationToMerge][DeleteFlag] = orowStruct[DeleteFlag];
			ocolumnStructTable[orowLocationToMerge][LongText] = orowStruct[LongText];
			ocolumnStructTable[orowLocationToMerge][LongTextData] = orowStruct[LongTextData];

			ocolumnStructTable[orowLocationToMerge][HoursCounter] = orowStruct[HoursCounter];
			ocolumnStructTable[orowLocationToMerge][HoursRefcount] = orowStruct[HoursRefcount];
			ocolumnStructTable[orowLocationToMerge][classcol] = orowStruct[classcol];
			ocolumnStructTable[orowLocationToMerge][trfstcol] = orowStruct[trfstcol];
			ocolumnStructTable[orowLocationToMerge][ParentId] = orowStruct[ParentId];
			return ocolumnStructTable;
		},

		_buildTable: function (oEmployees) {
			var oTable = this.getView().byId("idEmpTable");
			var oView = this.getView();
			oTable.destroyColumns();
			oTable.destroyRowSettingsTemplate();
			oTable.addColumn(new sap.ui.table.Column({
				multiLabels: [
					new sap.m.Label({
						visible: false
					}),

					new sap.m.Label({
						text: "{i18n>CT.CC}",
						wrapping: true
					}),
					new sap.m.Label({
						visible: false
					})
				],
				width: "9rem",
				template: new sap.m.Link({
					text: "{Costcode}",
					wrapping: true,
					press: this.onCostCodeQuickView.bind(this)

				})

				/*				new sap.m.Text({
									text: "{Costcode}",
									wrapping: true
								})*/
			}));

			oTable.addColumn(new sap.ui.table.Column({
				multiLabels: [
					new sap.m.Label({
						visible: false
					}),

					new sap.m.Label({
						text: "Activity",
						wrapping: true
					}),
					new sap.m.Label({
						visible: false
					}),
				],
				visible: true,
				width: "9rem",
				template:
				/* new sap.m.Text({
					text: "{Zzact}",
					type: "Text"
				})*/

					new sap.m.Input({
					type: "Text",
					value: "{Zzact}",
					placeholder: "Select Activity ...",
					showValueHelp: true,
					valueHelpOnly: true,
					valueHelpRequest: this.handleValueHelpActivity.bind(this),
					visible: true,
					editable: {
						path: 'app>/timePageReadOnly',
						formatter: function (a) {
							return !a;
						}
					},
				})
			}));

			oTable.addColumn(new sap.ui.table.Column({
				multiLabels: [
					new sap.m.Label({
						visible: false
					}),

					new sap.m.Label({
						text: "Time Type",
						wrapping: true
					}),
					new sap.m.Label({
						visible: false
					}),
				],
				width: "6rem",
				template: new sap.m.Input({
					type: "Text",
					value: "{TimeType}",
					placeholder: "Enter Time Type ...",
					showValueHelp: true,
					valueHelpOnly: true,
					valueHelpRequest: this.handleValueHelpTimeType.bind(this),
					visible: true,
					editable: {
						path: 'app>/timePageReadOnly',
						formatter: function (a) {
							return !a;
						}
					},
				})

				/*				template: new sap.m.Select({
									showSecondaryValues: true,
									items: [path: '/results'],
									<core:ListItem text="{TimeType}" additionalText="{TimeTypeTx}"/>
									visible: true
								})*/

			}));
			oTable.addColumn(new sap.ui.table.Column({
				multiLabels: [
					new sap.m.Label({
						visible: false
					}),

					new sap.m.Label({
						text: "Total",
						wrapping: true
					}),
					new sap.m.Text({
						text: '',
						width: "100%",
						textAlign: "Center"
					}).addStyleClass("zSmallFontGreenColumnHeader"),
					new sap.m.Text({
						text: this.formatter.decimal(this.TotalTimesheetHours) + ' Hours',
						width: "100%",
						textAlign: "Center"
					}).addStyleClass("zSmallFontGreenColumnHeader")

				],
				width: "5rem",

				template: new sap.m.ObjectNumber({
					number: {
						path: 'CostCodeTotalHours',
						formatter: this.formatter.decimal.bind(this)

					},
					textAlign: "End"
				})
			}));

			var sUrl;
			for (var i = 0; i < oEmployees.length; i++) {
				var columnID = 'Hours' + i;
				var longtextcol = 'LongText' + i;
				var parentID = 'ParentId' + i;
				var HoursEditable = 'HoursEditable' + i;
				var timetypecol = 'TimeType';
				var qntycol = 'Qnty' + i;
				var classcol = 'Class' + i;
				var trfstcol = 'Trfst' + i;
				var BooleanType = this.formatter.getBooleanStringType();
				var path = "/EmployeePictureSet(JobCode='" + oEmployees[i].JobCode + "',CrewId='" + oEmployees[i].CrewId + "',EmployeeId='" +
					oEmployees[i].Pernr + "')/$value";
				var sEmpZztrfgr = "Employees>/Employees/" + i + "/EmpZztrfgr";
				var sEmpPersk = "Employees>/Employees/" + i + "/EmpPersk";

				if (oEmployees[i].EmpCountryCode !== undefined && oEmployees[i].EmpCountryCode !== null && oEmployees[i].EmpCountryCode !== "" &&
					this.countryCode !== oEmployees[i].EmpCountryCode) {
					this.countryCode = oEmployees[i].EmpCountryCode;
				}
				if (oEmployees[i].HoursRule !== undefined && oEmployees[i].HoursRule !== null && oEmployees[i].HoursRule !== "" &&
					this.hoursRule !== oEmployees[i].HoursRule) {
					this.hoursRule = oEmployees[i].HoursRule;
				}				
				sUrl = this.oComponent.oModels.TIME7011.sServiceUrl + path;
				if (this.oComponent.oModels.TIME7011.aUrlParams !== undefined && this.oComponent.oModels.TIME7011.aUrlParams.length > 0) {
					sUrl = sUrl + '?' + this.oComponent.oModels.TIME7011.aUrlParams[0];
				}
				oTable.addColumn(new sap.ui.table.Column({

					multiLabels: [
						new sap.m.Panel({
							content: [
								new sap.m.FlexBox({
									items: [
										new sap.m.VBox({
											items: [
												new sap.m.Text({
													text: "IN"
												}).addStyleClass("zSmallFontColumnHeader"),
												new sap.m.Text({
													text: oEmployees[i].ClockIn
												}).addStyleClass("zSmallFontBlackColumnHeader sapUiSmallMarginEnd")
											],
											alignItems: "Start",
											fitContainer: true
										}),
										new sap.m.VBox({
											items: [
												new sap.m.Text({
													text: "OUT"
												}).addStyleClass("zSmallFontColumnHeader sapUiSmallMarginEnd"),
												new sap.m.Text({
													text: oEmployees[i].ClockOut
												}).addStyleClass("zSmallFontColumnHeader sapUiSmallMarginEnd")
											],
											alignItems: "End",
											fitContainer: true
										})
									],
									justifyContent: "SpaceBetween",
									alignItems: "Stretch"
								})
							]
						}),
						new sap.m.FlexBox({
							items: [
								new sap.m.Image({
									detailBox: new sap.m.LightBox({
										imageContent: new sap.m.LightBoxItem({
											imageSrc: sUrl,
											title: oEmployees[i].Ename,
											subtitle: oEmployees[i].CraftDescription
										})
									}),
									src: sUrl,
									width: "3rem",
									decorative: false,
									densityAware: false
										//	displaySize: "S",  for Avatar
										//	displayShape: "Circle" for Avatar
								}).addStyleClass("sapMImg sapMSLIImg sapUiSmallMarginEnd"),
								new sap.m.VBox({
									items: [
										new sap.m.Text({
											text: oEmployees[i].Ename
										}).addStyleClass("zMediumFontColumnHeader"),
										new sap.m.Text({
											text: oEmployees[i].CraftDescription
										}).addStyleClass("zSmallFontColumnHeader")
									]
								})
							]
						}),

						new sap.m.Text({
							text: oEmployees[i].EmpZztrfgrTx,
							width: "100%",
							textAlign: "Center"
						}).addStyleClass("zSmallFontCraftColumnHeader"),

						new sap.m.Text({
							text: (oEmployees[i].TotalHours === "" ? '0.00' : oEmployees[i].TotalHours) + " / " + oEmployees[i].PlannedHours +
								' Hours',
							width: "100%",
							textAlign: "Center"
						}).addStyleClass("zSmallFontGreenColumnHeader")
					],

					// label: new sap.m.Label({
					// 	text: oEmployees[i],
					// 	wrapping: true
					// }),

					width: "9rem",
					template:

						new sap.m.FlexBox({
						alignItems: "Start",
						justifyContent: "SpaceBetween",
						items: [
							new sap.m.Button({
								//	icon: "sap-icon://notification-2",
								//icon: "sap-icon://write-new-document",
								icon: {
									parts: [{
										path: longtextcol
									}, {
										path: HoursEditable // no need for this
									}],
									formatter: this.formatter.commentIcon.bind(this)
								},

								type: {
									parts: [{
										path: longtextcol
									}, {
										path: HoursEditable // no need for this
									}],
									formatter: this.formatter.commentIconColor.bind(this)
								},
								press: this.longtextPopover.bind(this)

							}).data("colno", i),

							new sap.m.Input({
								width: "4rem",
								value: '{' + columnID + '}',
								type: sap.m.InputType.Number,
								change: this.onInputHoursChanged.bind(this),
								visible: {
									parts: [{
										path: timetypecol
									}, {
										path: HoursEditable // no need for this
									}],
									formatter: this.formatter.visibleHrs.bind(this)
								},

								// type: {
								// 	path: parentID,
								// 	formatter: formatter.Type

								// },
								//editable: !this.isReadOnly,
								editable: {
									path: 'app>/timePageReadOnly',
									formatter: function (a) {
										return !a;
									}
								},
								valueState: sap.ui.core.ValueState.None,
								// valueState: {
								// 	parts: [{
								// 		path: parentID
								// 	}, {
								// 		path: HoursEditable
								// 	}],
								// 	formatter: formatter.ValueState
								// },
								showValueStateMessage: false
							}),

							new sap.m.CheckBox({
								visible: {
									parts: [{
										path: timetypecol
									}, {
										path: HoursEditable // no need for this
									}],
									formatter: this.formatter.visiblePD.bind(this)
								},
								editable: {
									path: 'app>/timePageReadOnly',
									formatter: function (a) {
										return !a;
									}
								}
							}).bindProperty("selected", {
								type: new BooleanType(),
								path: qntycol
							})

							,

							new sap.m.Button({
								icon: {
									parts: [{
											path: classcol
										}, {
											path: trfstcol
										}, {
											path: sEmpZztrfgr
										}, {
											path: sEmpPersk
										}

									],
									formatter: this.formatter.classIcon.bind(this)
								},
								customData: [new sap.ui.core.CustomData({
									"key": "colno",
									"value": i
								})],
								enabled: {
									parts: [{
										path: timetypecol
									}, {
										path: columnID

									}, {
										path: qntycol
									}, {
										path: classcol
									}, {
										path: trfstcol

									}, {
										path: sEmpZztrfgr
									}, {
										path: sEmpPersk
									}],
									formatter: this.formatter.classIconEnabled.bind(this)
								},
								tooltip: {
									parts: [{
										path: classcol
									}, {
										path: trfstcol

									}, {
										path: sEmpZztrfgr
									}, {
										path: sEmpPersk
									}],
									formatter: this.formatter.classIconTooltip.bind(this)
								},
								type: {
									parts: [{
										path: classcol
									}, {
										path: trfstcol

									}, {
										path: sEmpZztrfgr
									}, {
										path: sEmpPersk
									}],
									formatter: this.formatter.classIconColor.bind(this)
								},
								press: this.handleValueHelpClass.bind(this)

							})

							/*,

															selected: {
																path: qntycol,
																formatter: this.formatter.getBooleanValue.bind(this)
															}*/
							// selected: {
							// 	parts: [{
							// 		path: columnID
							// 	}, {
							// 		path: HoursEditable // no need for this
							// 	}],
							// 	formatter: this.formatter.selectedPDCheckbox.bind(this)
							// },

						]
					})
				}));

			}

			oTable.setFixedColumnCount(4);
			var oModel = this.getView().getModel("crewTimeRedesign");
			oTable.setEditable(!this.isReadOnly);
			oTable.setModel(oModel);
			oTable.bindRows("/CrewTime");
		},

		// _buildTableModel: function (oEmployees, CrewTime) {

		// 	this.timesheetRows = [];

		// 	this.timesheetRows.push({

		// 		/*					Costcode:
		// 							CostCodeTx:
		// 							Activity:
		// 							TimeType:*/

		// 	});
		// },

		_addNewBlankRowToTable: function (SelectedCostCode, hours, qty) {
			var aCrewTimeRedesign = this.getProperty("crewTimeRedesign", "/CrewTime");
			var rowStruct;
			var itemData = [];

			rowStruct = {
				JobCode: SelectedCostCode.JobCode,
				CrewId: SelectedCostCode.CrewId,
				Costcode: SelectedCostCode.Costcode,
				CostcodeTx: SelectedCostCode.CostcodeTx,
				CostCodeTotalHours: 0.00,
				TimeType: this.getDefaultTimeType(SelectedCostCode.Zzcst, SelectedCostCode.Zzssc, SelectedCostCode.Zzptjcd),
				Zzact: SelectedCostCode.Zzact,
				Zzcst: SelectedCostCode.Zzcst,
				Zzssc: SelectedCostCode.Zzssc,
				Zzptjcd: SelectedCostCode.Zzptjcd,
				IsDeletedRow: false,
				isNewRow: true
			};

			if (this.timeTypeCategory[rowStruct.TimeType] !== 'PD') {
				if (hours !== undefined && parseFloat(hours) > 0) {
					for (var i = 0; i < this.oEmployees.length; i++) {
						const Hours = 'Hours' + i;
						rowStruct[Hours] = hours;
					}
				}
			} else {
				if (qty === true) {
					for (var i = 0; i < this.oEmployees.length; i++) {
						const qntycol = 'Qnty' + i;
						rowStruct[qntycol] = 'X';
					}
				}
			}
			if (aCrewTimeRedesign.length === undefined) {
				itemData.push(rowStruct);
				aCrewTimeRedesign = itemData;
			} else {
				aCrewTimeRedesign.push(rowStruct);
			}

			var oModelRedesign = this.getView().getModel("crewTimeRedesign");
			oModelRedesign.setProperty("/CrewTime", aCrewTimeRedesign, null, true);
			this.hideBusyIndicator();

		},

		getDefaultTimeType: function (Zzcst, Zzssc, Zzptjcd) {

			var aSearchHelpTimeType = this.getModel("searchHelpTimeType").getProperty("/SearchHelpTimeType");

			if (aSearchHelpTimeType.results.length !== undefined) {

				let index = aSearchHelpTimeType.results.findIndex(
					row => row.JobCode === Zzptjcd &&
					row.CostCode === Zzcst &&
					row.ZZSSC === Zzssc &&
					row.TimeType === "ST"
				);
				if (index > -1) {
					return "ST";
				} else {

					let index = aSearchHelpTimeType.results.findIndex(
						row => row.JobCode === Zzptjcd &&
						row.CostCode === Zzcst &&
						row.ZZSSC === Zzssc
					);

					if (index > -1) {
						return aSearchHelpTimeType.results[index].TimeType;
					} else {
						return "";
					}
				}
			}
		},
		// Layout buttons
		onCloseDetailPress: function () {
			var oModel = this.getView().getModel("app");
			oModel.setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
			this.getOwnerComponent().getRouter().navTo("CrewList", {}, true);
		},

		/**
		 * Toggle between full and non full screen mode.
		 */
		toggleFullScreen: function () {
			var oModel = this.getView().getModel("app");
			var bFullScreen = oModel.getProperty("/actionButtonsInfo/endColumn/fullScreen");
			oModel.setProperty("/actionButtonsInfo/endColumn/fullScreen", !bFullScreen);
			if (!bFullScreen) {
				// store current layout and go full screen
				oModel.setProperty("/previousLayout", oModel.getProperty("/layout"));
				oModel.setProperty("/layout", "EndColumnFullScreen");
			} else {
				// reset to previous layout
				oModel.setProperty("/layout", oModel.getProperty("/previousLayout"));
			}
		},
		onInputHoursChanged: function (e) {

			if (isNaN(e.getParameter("newValue")) || e.getParameter("newValue") < 0) {
				e.getSource().setValueState("Error");
				e.getSource().setShowValueStateMessage(true);
				e.getSource().setValueStateText("Enter positive number")
			} else if (e.getParameter("newValue") > 0) {
				var n = e.getParameter("newValue");
				if (this.hoursRule === '1006') {
					this.check1006HoursFormat(n, e);
					//this.checkCountry34HoursFormat(n, e);
				} else if (this.hoursRule === '1003') {
					this.check1003HoursFormat(n, e);
					//this.checkCountry13HoursFormat(n, e);
				} else {
					//no rule defined
				}
			} else if (e.getParameter("newValue") === "") {
				e.getSource().setValueState("None");
			}

		},
		check1003HoursFormat: function (n, e) {
			if (n.split(".")[1] !== undefined && n.split(".")[1].length > 1) {
				for (var i = 1; i < n.split(".")[1].length; i++) {
					if (n.split(".")[1][i] > 0) {
						e.getSource().setValueState("Error");
						e.getSource().setShowValueStateMessage(true);
						e.getSource().setValueStateText("Number of hours can only have one digit after decimal.")
						break;
					} else {
						e.getSource().setValueState("None");
					}
				}
			} else {
				e.getSource().setValueState("None");
			}
		},
		check1006HoursFormat: function (n, e) {
			if (n.split(".")[1] !== undefined && n.split(".")[1].length > 2) {
				for (var i = 2; i < n.split(".")[1].length; i++) {
					if (n.split(".")[1][i] > 0) {
						e.getSource().setValueState("Error");
						e.getSource().setShowValueStateMessage(true);
						e.getSource().setValueStateText("Number of hours can only have two digits after decimal.");
						break;
					} else {
						var dec = 0;
						dec = n.split(".")[1];
						if (dec % 25 === 0) {
							e.getSource().setValueState("None");
						} else {
							e.getSource().setValueState("Error");
							e.getSource().setShowValueStateMessage(true);
							e.getSource().setValueStateText("Number of hours can only be in increment of 0.25");
							break;
						}

					}
				}
			} else if (n.split(".")[1] !== undefined && n.split(".")[1].length >= 1 && n.split(".")[1].length <= 2) {
				var dec = 0;
				dec = n.split(".")[1];
				if (dec <= 9) {
					dec = dec * 10;
				}
				if (dec % 25 === 0) {
					e.getSource().setValueState("None");
				} else {
					e.getSource().setValueState("Error");
					e.getSource().setShowValueStateMessage(true);
					e.getSource().setValueStateText("Number of hours can only be in increment of 0.25");
				}
			} else {
				e.getSource().setValueState("None");
			}
		},

		onSearchHelpCostCodeLoad: function (aSearchHelpCostCode) {
			/*			this.getModel("searchHelpCostCode").setSizeLimit(aSearchHelpCostCode.length);
						this.setProperty("searchHelpCostCode", "/SearchHelpCostCode", aSearchHelpCostCode);*/

			this._aSearchHelpCostCode = jQuery.extend(true, [], aSearchHelpCostCode.results);
			this.setModel(new sap.ui.model.json.JSONModel(aSearchHelpCostCode.results), "searchHelpCostCode");
		},

		onSearchHelpUnassignedCostCodeLoad: function (aSearchHelpUnassignedCostCode) {
			this.setModel(new sap.ui.model.json.JSONModel(aSearchHelpUnassignedCostCode.results), "searchHelpUnassignedCostCode");
		},

		onSearchHelpClassLoad: function (aSearchHelpClass) {
			this.getModel("searchHelpClass").setSizeLimit(aSearchHelpClass.length);
			this.setProperty("searchHelpClass", "/SearchHelpClass", aSearchHelpClass);
		},

		onSearchHelpActivityLoad: function (aSearchHelpActivity) {
			this.getModel("searchHelpActivity").setSizeLimit(aSearchHelpActivity.length);
			this.setProperty("searchHelpActivity", "/SearchHelpActivity", aSearchHelpActivity);

		},
		onSearchHelpTimeTypeLoad: function (aSearchHelpTimeType) {
			this.getModel("searchHelpTimeType").setSizeLimit(aSearchHelpTimeType.length);
			this.setProperty("searchHelpTimeType", "/SearchHelpTimeType", aSearchHelpTimeType);
			if (aSearchHelpTimeType.results.length !== undefined) {
				for (var i = 0; i < aSearchHelpTimeType.results.length; i++) {
					this.timeTypeCategory[aSearchHelpTimeType.results[i].TimeType] = aSearchHelpTimeType.results[i].Category;
					this.timeTypeDescription[aSearchHelpTimeType.results[i].TimeType] = aSearchHelpTimeType.results[i].TimeTypeTx;
				}
			}
		},
		_sortCostCodeSearchTable(e, oField) {
			var bDescending = false;
			if (e.getSource().getParent().getParent().getParent().getBinding("items").aSorters[0] !== undefined) {
				if (oField === e.getSource().getParent().getParent().getParent().getBinding("items").aSorters[0].sPath) {
					bDescending = e.getSource().getParent().getParent().getParent().getBinding("items").aSorters[0].bDescending;
				}
			}
			var oSorter = new sap.ui.model.Sorter({
				path: oField,
				descending: !bDescending
			});
			var oBinding = e.getSource().getParent().getParent().getParent().getBinding("items");
			oBinding.sort(oSorter);
		},
		onAddCostCode: function (oEvent) {
			var a = this;
			var aSearchHelpCostCode = this.getModel("searchHelpCostCode").getData();
			var d = {

				onSortCostCode: function (e) {
					a._sortCostCodeSearchTable(e, 'Costcode');
				},
				onSortCostCodeDesc: function (e) {
					a._sortCostCodeSearchTable(e, 'CostcodeTx');
				},
				handleClose: function (e) {
					a.oAddCostCodeDialog.setRememberSelections(false);
				},
				handleConfirm: function (e) {

					aSearchHelpCostCode = a.getModel("searchHelpCostCode").getData();
					for (var i = 0; i < e.getParameter("selectedContexts").length; i++) {
						var j = e.getParameter("selectedContexts")[i].getPath().split("/")[1];
						a._addNewBlankRowToTable(aSearchHelpCostCode[j]);
					}
					var oBinding = e.getSource().getBinding("items");
					oBinding.filter([]);
					oBinding.sort([]);
					a.oAddCostCodeDialog.setRememberSelections(false);
				},

				handleCostCodeSearch: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					//var oFilter = new Filter("Costcode", FilterOperator.Contains, sValue);
					var oFilter = new Filter({
						filters: [
							new sap.ui.model.Filter("Costcode", FilterOperator.Contains, sValue),
							new sap.ui.model.Filter("CostcodeTx", FilterOperator.Contains, sValue),
						],
						and: false
					});
					var oBinding = oEvent.getSource().getBinding("items");
					oBinding.filter([oFilter]);

				},
				dateConversion: function (d) {
					return a.formatter.dateConversion(d);
				}
			};
			if (!this.oAddCostCodeDialog) {
				this.oAddCostCodeDialog = sap.ui.xmlfragment(this.getView().getId(), "mytime.ZMOB_MY_TIME_Redesign.view.fragments.AddCostCode",
					d);
				this.getView().addDependent(this.oAddCostCodeDialog);
			}
			jQuery.sap.delayedCall(0, this, function () {
				this.oAddCostCodeDialog.open();

			});

		},
		onAddUnassignedCostCode: function (oEvent) {
			var a = this;
			var aSearchHelpUnassignedCostCode = this.getModel("searchHelpUnassignedCostCode").getData();
			var d = {

				onSortCostCode: function (e) {
					a._sortCostCodeSearchTable(e, 'Costcode');
				},
				onSortCostCodeDesc: function (e) {
					a._sortCostCodeSearchTable(e, 'CostcodeTx');
				},
				handleClose: function (e) {
					a.oAddUnassignedCostCodeDialog.setRememberSelections(false);
				},
				handleConfirm: function (e) {

					aSearchHelpUnassignedCostCode = a.getModel("searchHelpUnassignedCostCode").getData();
					for (var i = 0; i < e.getParameter("selectedContexts").length; i++) {
						var j = e.getParameter("selectedContexts")[i].getPath().split("/")[1];
						a._addNewBlankRowToTable(aSearchHelpUnassignedCostCode[j]);
					}
					a.oAddUnassignedCostCodeDialog.setRememberSelections(false);
				},

				handleCostCodeSearch: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					//var oFilter = new Filter("Costcode", FilterOperator.Contains, sValue);
					var oFilter = new Filter({
						filters: [
							new sap.ui.model.Filter("Costcode", FilterOperator.Contains, sValue),
							new sap.ui.model.Filter("CostcodeTx", FilterOperator.Contains, sValue),
						],
						and: false
					});
					var oBinding = oEvent.getSource().getBinding("items");
					oBinding.filter([oFilter]);
				},
				dateConversion: function (d) {
					return a.formatter.dateConversion(d);
				}
			};
			if (!this.oAddUnassignedCostCodeDialog) {
				this.oAddUnassignedCostCodeDialog = sap.ui.xmlfragment(this.getView().getId(),
					"mytime.ZMOB_MY_TIME_Redesign.view.fragments.AddUnassignedCostCode",
					d);
				this.getView().addDependent(this.oAddUnassignedCostCodeDialog);
			}
			jQuery.sap.delayedCall(0, this, function () {
				this.oAddUnassignedCostCodeDialog.open();
			});

		},
		onAddCostCodeHour: function (oEvent) {
			var a = this;
			var aSearchHelpCostCode = jQuery.extend(true, [], a.getModel("searchHelpCostCode").getData());

			// SAPC-5323 to show check box
			a.setModel(new sap.ui.model.json.JSONModel(aSearchHelpCostCode), "searchHelpCostCode");
			for (var m = 0; m < aSearchHelpCostCode.length; m++) {
				aSearchHelpCostCode[m]["TimeType"] = this.getDefaultTimeType(aSearchHelpCostCode[m].Zzcst, aSearchHelpCostCode[m].Zzssc,
					aSearchHelpCostCode[m].Zzptjcd);
				aSearchHelpCostCode[m]["Category"] = this.timeTypeCategory[aSearchHelpCostCode[m].TimeType];
			}

			// end
			var j = -2;
			var hour = 0;
			var qty = false;
			var selectedCostcode = "";
			var d = {

				onSortCostCode: function (e) {
					a._sortCostCodeSearchTable(e, 'Costcode');
				},
				onSortCostCodeDesc: function (e) {
					a._sortCostCodeSearchTable(e, 'CostcodeTx');
				},

				handleClose: function (e) {
					a.oAddCostCodeDialogHour.setRememberSelections(false);
					a.setModel(new sap.ui.model.json.JSONModel(a._aSearchHelpCostCode), "searchHelpCostCode");
				},
				handleConfirm: function (e) {

					aSearchHelpCostCode = a.getModel("searchHelpCostCode").getData();
					for (var i = 0; i < e.getParameter("selectedContexts").length; i++) {
						//	hour = e.getParameter("selectedItems")[i].getCells()[2].getValue();
						selectedCostcode = "";
						if (a.getModel("searchHelpCostCode").getProperty(e.getParameter("selectedContexts")[i].sPath).Category !== 'PD') {
							hour = a.getModel("searchHelpCostCode").getProperty(e.getParameter("selectedContexts")[i].sPath).Hours;
							selectedCostcode = a.getModel("searchHelpCostCode").getProperty(e.getParameter("selectedContexts")[i].sPath).Costcode;
							if (isNaN(hour) || hour < 0) {
								jQuery.sap.delayedCall(0, a, function () {
									a.oAddCostCodeDialogHour.setRememberSelections(true);
									a.oAddCostCodeDialogHour.open();
									MessageBox.error("Enter positive number in the hours field");
								});

								return;
							}
							if (hour.split(".")[1] !== undefined && hour.split(".")[1].length > 0) {
								var msg = a.checkHours(hour);
								if (msg !== undefined && msg !== 'S') {
									jQuery.sap.delayedCall(0, a, function () {
										a.oAddCostCodeDialogHour.setRememberSelections(true);
										a.oAddCostCodeDialogHour.open();
										MessageBox.error(msg);
									});
									return;
								}
								/*								for (var i = 1; i < hour.split(".")[1].length; i++) {
																	if (hour.split(".")[1][i] > 0) {
																		jQuery.sap.delayedCall(0, a, function () {
																			a.oAddCostCodeDialogHour.setRememberSelections(true);
																			a.oAddCostCodeDialogHour.open();
																			MessageBox.error("Number of hours can only have one digit after decimal");
																		});
																		return;
																	}
																}*/
							}

						}
					}

					for (var i = 0; i < e.getParameter("selectedContexts").length; i++) {
						j = e.getParameter("selectedContexts")[i].getPath().split("/")[1];
						//hour = e.getParameter("selectedItems")[i].getCells()[2].getValue();
						var sPath = e.getParameter("selectedContexts")[i].sPath;
						hour = a.getModel("searchHelpCostCode").getProperty(sPath).Hours;
						qty = a.getModel("searchHelpCostCode").getProperty(sPath).Qty;
						//e.getParameter("selectedItems")[i].getCells()[2].setValue("");
						a.getModel("searchHelpCostCode").setProperty(sPath + "/Hours", "");
						a.getModel("searchHelpCostCode").setProperty(sPath + "/Qty", false);
						//e.getParameter("selectedItems")[i].getCells()[2].setValueState("None");
						a.getModel("searchHelpCostCode").setProperty(sPath + "/valueState", "None");
						a._addNewBlankRowToTable(aSearchHelpCostCode[j], hour, qty);

					}
					a.oAddCostCodeDialogHour.setRememberSelections(false);
					var oBinding = e.getSource().getBinding("items");
					oBinding.filter([]);
					oBinding.sort([]);

					a.setModel(new sap.ui.model.json.JSONModel(a._aSearchHelpCostCode), "searchHelpCostCode");

				},
				onHoursChange: function (e) {
					var sPath = e.getSource().getParent().getParent().getBindingContextPath();
					if (a.getModel("searchHelpCostCode").getProperty(sPath).Category !== 'PD') {
						if (isNaN(e.getParameter("newValue")) || e.getParameter("newValue") < 0) {
							//e.getSource().setValueState("Error");
							//e.getSource().setShowValueStateMessage(true);
							//e.getSource().setValueStateText("Enter positive number")

							a.getModel("searchHelpCostCode").setProperty(sPath + "/valueState", "Error");
							a.getModel("searchHelpCostCode").setProperty(sPath + "/valueStateText", "Enter positive number");

						} else if (e.getParameter("newValue") > 0) {
							//e.getSource().setValueState("None");

							var n = e.getParameter("newValue");
							if (n.split(".")[1] !== undefined && n.split(".")[1].length > 0) {
								var msg = a.checkHours(n);
								if (msg !== undefined && msg !== 'S') {
									a.getModel("searchHelpCostCode").setProperty(sPath + "/valueState", "Error");
									//e.getSource().setShowValueStateMessage(true);
									a.getModel("searchHelpCostCode").setProperty(sPath + "/valueStateText", msg);
									return;
								} else {
									e.getSource().setValueState("None");
								}
							} else {
								a.getModel("searchHelpCostCode").setProperty(sPath + "/valueState", "None");
							}

						} else if (e.getParameter("newValue") === "") {
							//e.getSource().setValueState("None");
							a.getModel("searchHelpCostCode").setProperty(sPath + "/valueState", "None");
						}
					}
				},
				handleCostCodeSearch: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					//var oFilter = new Filter("Costcode", FilterOperator.Contains, sValue);
					var oFilter = new Filter({
						filters: [
							new sap.ui.model.Filter("Costcode", FilterOperator.Contains, sValue),
							new sap.ui.model.Filter("CostcodeTx", FilterOperator.Contains, sValue),
						],
						and: false
					});
					var oBinding = oEvent.getSource().getBinding("items");
					oBinding.filter([oFilter]);
				},
				dateConversion: function (d) {
					return a.formatter.dateConversion(d);
				}
			};
			if (!this.oAddCostCodeDialogHour) {
				this.oAddCostCodeDialogHour = sap.ui.xmlfragment(this.getView().getId(),
					"mytime.ZMOB_MY_TIME_Redesign.view.fragments.AddCostCodeHour",
					d);
				this.getView().addDependent(this.oAddCostCodeDialogHour);
			}
			jQuery.sap.delayedCall(0, this, function () {
				this.oAddCostCodeDialogHour.setRememberSelections(true);
				this.oAddCostCodeDialogHour.open();
			});

		},

		onSave: function (oEvent) {
			this.onSend("SIGN");
		},
		onApprove: function (oEvent) {
			this.onSend("APPROVE");
		},
		checkHours: function (n) {
			if (this.hoursRule !== undefined && this.hoursRule !== "" && this.hoursRule === '1006') {
				if (n.split(".")[1] !== undefined && n.split(".")[1].length > 2) {
					for (var z = 1; z < n.split(".")[1].length; z++) {
						if (n.split(".")[1][z] > 0) {
							return 'Number of hours can be in increment of 0.25';
						}
					}
				} else if (n.split(".")[1] !== undefined && n.split(".")[1].length >= 1 && n.split(".")[1].length <= 2) {
					var dec = 0;
					dec = n.split(".")[1];
					if (dec <= 9) {
						dec = dec * 10;
					}
					if (dec % 25 !== 0) {
						return 'Number of hours can be in increment of 0.25';
					}
				}

			} else if (this.hoursRule !== undefined && this.hoursRule !== "" && this.hoursRule === '1003'){
				if (n.split(".")[1] !== undefined && n.split(".")[1].length > 1) {
					for (var z = 1; z < n.split(".")[1].length; z++) {
						if (n.split(".")[1][z] > 0) {
							return 'Number of hours can only have one digit after decimal.';
						}
					}
				}
			}

			return 'S';
		},
		onSend: function (oAction) {

			this.showBusyIndicator(4000, 1);
			var CrewTime = [];
			var aCrewTimeRedesign = this.getProperty("crewTimeRedesign", "/CrewTime");
			var results
			for (var i = 0; i < this.oEmployees.length; i++) {
				const Hours = 'Hours' + i;
				const Qnty = 'Qnty' + i;
				const HoursCounter = 'HoursCounter' + i;

				for (var j = 0; j < aCrewTimeRedesign.length; j++) {
					if ((aCrewTimeRedesign[j].isNewRow === true || aCrewTimeRedesign[j][HoursCounter] === undefined) && (aCrewTimeRedesign[j][Hours] ===
							undefined || aCrewTimeRedesign[j][Hours] === 0 || aCrewTimeRedesign[j][Hours] === "") && (aCrewTimeRedesign[j][Qnty] ===
							undefined || aCrewTimeRedesign[j][Qnty] ===
							false || aCrewTimeRedesign[j][Qnty] ===
							"")) {
						// don't do anything in these situations

					} else {
						// added aCrewTimeRedesign[j][Hours] !== undefined
						// added condition to check the Time Type is not PD hours						
						if (this.timeTypeCategory[aCrewTimeRedesign[j].TimeType] !== 'PD') {
							if (aCrewTimeRedesign[j][Hours] !== undefined && (isNaN(aCrewTimeRedesign[j][Hours]) || aCrewTimeRedesign[j][Hours] < 0)) {
								MessageBox.error("Enter positive number in the hours field");
								this.hideBusyIndicator();
								return;
							} else if (aCrewTimeRedesign[j][Hours] > 0) {
								var n = aCrewTimeRedesign[j][Hours];
								var msg = this.checkHours(n);
								if (msg !== undefined && msg !== 'S') {
									MessageBox.error(msg);
									this.hideBusyIndicator();
									return;
								}
							}
						}
						CrewTime.push(this.onSaveToEmpFill(i, this.oEmployees[i], aCrewTimeRedesign[j]));
					}
				}
				for (var j = 0; j < this.deletedRows.length; j++) {
					if (this.deletedRows[j].isNewRow === true || this.deletedRows[j][HoursCounter] === undefined) {

					} else {
						CrewTime.push(this.onSaveToEmpFill(i, this.oEmployees[i], this.deletedRows[j]));
					}
				}

			}
			this.getView().setModel(new JSONModel(), "CrewList");
			this.setProperty("CrewList", "/JobCode", this.oEmployees[0].JobCode);
			this.setProperty("CrewList", "/CrewId", this.oEmployees[0].CrewId);
			this.setProperty("CrewList", "/Description", "");
			this.setProperty("CrewList", "/EffectiveDate", this.oEmployees[0].EffectiveDate);
			this.setProperty("CrewList", "/Shift", "");
			this.setProperty("CrewList", "/ShiftDescription", "");
			this.setProperty("CrewList", "/CrewEffectiveDate", this.oEmployees[0].CrewEffectiveDate);
			this.setProperty("CrewList", "/FmPernr", "");
			this.setProperty("CrewList", "/FmName", "");
			this.setProperty("CrewList", "/FmWerks", "");
			this.setProperty("CrewList", "/Status", "");
			this.setProperty("CrewList", "/StatusTx", "");
			this.setProperty("CrewList", "/Action", oAction);

			this.setProperty("CrewList", "/ToEmpTime", CrewTime);
			var oData1 = this.getModel("CrewList").getData();
			this.oComponent.getDataProvider().SendTime(this, oData1, oAction);

		},
		onSaveToEmpFill: function (iRowNo, oEmployee, oCrewTime) {
			const Hours = 'Hours' + iRowNo;
			const HoursEditable = 'HoursEditable' + iRowNo;
			const Qnty = 'Qnty' + iRowNo;
			const DeleteFlag = 'DeleteFlag' + iRowNo;
			const LongText = 'LongText' + iRowNo;
			const LongTextData = 'LongText_Data' + iRowNo;
			const HoursCounter = 'HoursCounter' + iRowNo;
			const HoursRefcount = 'HoursRefcount' + iRowNo;
			const ParentId = 'ParentId' + iRowNo;
			const Class = 'Class' + iRowNo;
			const Trfst = 'Trfst' + iRowNo;

			var fillStruct = {
				JobCode: oEmployee.JobCode,
				CrewId: oEmployee.CrewId,
				Pernr: oEmployee.Pernr,
				Workdate: oEmployee.EffectiveDate,
				Zzcst: oCrewTime.Zzcst,
				Zzptjcd: oCrewTime.Zzptjcd,
				Zzssc: oCrewTime.Zzssc,
				Zzact: oCrewTime.Zzact,
				Class: oCrewTime[Class],
				Trfst: oCrewTime[Trfst],
				Prakn: oCrewTime.Prakn,
				Prakz: oCrewTime.Prakz,
				TimeType: oCrewTime.TimeType,
				Costcode: oCrewTime.Costcode,
				CostcodeTx: oCrewTime.CostcodeTx,
				ZzactEditable: "",
				ClassEditable: "",
				ClassTx: "",
				DeleteFlag: oCrewTime.IsDeletedRow === true ? 'X' : '',
				ParentId: oCrewTime[ParentId],
				IsNewRecord: false,
				IsEditable: false,
				Hours: oCrewTime[Hours],
				Qnty: (this.timeTypeCategory[oCrewTime.TimeType] === 'PD') ? oCrewTime[Qnty] : "",
				Counter: oCrewTime[HoursCounter],
				RefCounter: oCrewTime[HoursRefcount],
				LongText: oCrewTime[LongText],
				LongText_Data: oCrewTime[LongTextData]
			};
			return fillStruct;

		},

		onSaveTimeSuccess: function (oAction) {
			this.hideBusyIndicator();
			//	var oDate = oEvent.getParameter("value");
			this.showBusyIndicator(4000, 1);
			this.oComponent.getDataProvider().loadCrewTimebyDate(this, this.sCrew.EffectiveDate, this.sCrew);
			this.oComponent.getDataProvider().loadCrew(this, this.sCrew.EffectiveDate, this.sCrew);
			this.oComponent.getDataProvider().loadSearchHelpActivity(this, this.sCrew.EffectiveDate, this.sCrew.JobCode);

			this.hideBusyIndicator();
			var _mess;
			if (oAction === "APPROVE") {
				_mess = this.getView().getModel("i18n").getResourceBundle().getText("M.APPROVE");
			}
			if (oAction === "SIGN") {
				_mess = this.getView().getModel("i18n").getResourceBundle().getText("M.SIGN");
			}

			//	MessageBox.success(_mess);

			MessageToast.show(_mess, {
				duration: 5000,
				width: "15em",
				my: "center bottom",
				at: "center bottom",
				of: window,
				offset: "0 0",
				collision: "fit fit",
				onClose: null,
				autoClose: true,
				animationTimingFunction: "ease",
				animationDuration: 2000,
				closeOnBrowserNavigation: true
			});
			this.getView().getModel().attachBatchRequestCompleted(function () {
				//console.log("completed");
			});

			this.getView().getModel().refresh();

		},
		onDeleteCC: function (oEvent) {
			var a = this;
			var oTable = this.byId("idEmpTable");
			var selectedData = [];
			var aIndices = oTable.getSelectedIndices();

			if (aIndices.length < 1) {
				MessageToast.show("No Cost Code Selected");
			} else {

				/*	var msg = "Are you sure to delete the selected costcode?";
					MessageBox.warning(msg, {
							actions: ["Delete", "Cancel"],
							emphasizedAction: "Cancel",
							initialFocus: "Cancel",
							onClose: function (sAction) {
								if (sAction === 'Delete') {
									a.showBusyIndicator(4000, 1);
									var aCrewTimeRedesign = a.getView().getModel("crewTimeRedesign").getProperty("/CrewTime");
									
									for (var i = aIndices.length - 1; i >= 0; i--) {
										//fetch the data of selected rows by index
										var tableContext = oTable.getContextByIndex(aIndices[i]);
										var data = oTable.getModel("crewTimeRedesign").getProperty(tableContext.getPath());
										data.IsDeletedRow = true;
										a.deletedRows.push(data);
										aCrewTimeRedesign.splice(aIndices[i], 1);
									}
									a.getView().getModel("crewTimeRedesign").setProperty("/CrewTime", aCrewTimeRedesign, null, true);
									oTable.clearSelection();
									a.hideBusyIndicator();
								}
							}
						})*/
				var aCrewTimeRedesign = this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime");
				this.showBusyIndicator(4000, 1);
				for (var i = aIndices.length - 1; i >= 0; i--) {
					//fetch the data of selected rows by index
					var tableContext = oTable.getContextByIndex(aIndices[i]);
					var data = oTable.getModel("crewTimeRedesign").getProperty(tableContext.getPath());
					data.IsDeletedRow = true;
					this.deletedRows.push(data);
					aCrewTimeRedesign.splice(aIndices[i], 1);
				}
				this.getView().getModel("crewTimeRedesign").setProperty("/CrewTime", aCrewTimeRedesign, null, true);
				oTable.clearSelection();
				this.hideBusyIndicator();

			}
		},
		// _updateDelCC: function (oSelectedData) {
		// 	var oModel = this.getView().getModel("crewTimeRedesign");
		// 	var aCrewTime = oModel.getProperty("/CrewTime");

		// 	for (var k = 0; k < oSelectedData.length; k++) {
		// 		for (var i = 0; i < aCrewTime.CrewTime.length; i++) {
		// 			if (aCrewTime.CrewTime[i].Time !== undefined) {
		// 				var a = aCrewTime.CrewTime[i].Time.length;
		// 				if (a > 0) {
		// 					for (var j = 0; j < aCrewTime.CrewTime[i].Time.length; j++) {
		// 						if (aCrewTime.CrewTime[i].Time[j] === oSelectedData[k]) {
		// 							//	aCrewTime.CrewTime[i].Time.splice(j, 1); //removing 1 record from i th index.
		// 							aCrewTime.CrewTime[i].Time[j].DeleteFlag = "X";
		// 							//	oModel.refresh();
		// 							break;
		// 						}
		// 					}
		// 				}
		// 			}
		// 		}
		// 	}

		// 	// var oFilter = new sap.ui.model.Filter({
		// 	// 	filters: [new sap.ui.model.Filter("Delete", "EQ", "X")],
		// 	// 	and: false
		// 	// });
		// 	// aCrewTime.CrewTime.filter.apply(oFilter, sap.ui.model.FilterType.Application);
		// 	//	this.jModel.setProperty("/Crew", oRoot);
		// 	//var oModel = this.getView().getModel("crewTime
		// 	var oTreeTable = this.getView().byId("TreeTable");
		// 	var oBinding = oTreeTable.getBinding("rows");
		// 	var filterArray = [];

		// 	filterArray.push(new sap.ui.model.Filter({
		// 		path: "DeleteFlag",
		// 		operator: "NE",
		// 		value1: "X"
		// 	}));
		// 	oBinding.filter(filterArray);

		// 	oModel.setProperty("/CrewTime", aCrewTime, null, true);
		// },		
		onButtonPress: function (oEvent) {
			var oButton = oEvent.getSource();
			this.byId("actionSheet").openBy(oButton);
		},
		hideBusyIndicator: function () {
			sap.ui.core.BusyIndicator.hide();
		},
		showBusyIndicator: function (iDuration, iDelay) {
			sap.ui.core.BusyIndicator.show(iDelay);
			if (iDuration && iDuration > 0) {
				if (this._sTimeoutId) {
					jQuery.sap.clearDelayedCall(this._sTimeoutId);
					this._sTimeoutId = null;
				}
				this._sTimeoutId = jQuery.sap.delayedCall(iDuration, this, function () {
					this.hideBusyIndicator();
				});
			}
		},

		handleValueHelpTimeType: function (oEvent) {

			this.selectedValueHelp = oEvent.getSource();
			var rowno = this.selectedValueHelp.getBindingContext().getPath().split('/')[2];
			var row = this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime")[rowno];

			var oModel = new sap.ui.model.json.JSONModel();
			var asearchHelpTimeType = this.getProperty("searchHelpTimeType", "/SearchHelpTimeType");
			oModel.setData(asearchHelpTimeType);
			var oButton = oEvent.getSource();
			if (!this._TimeTypeDialog) {
				this._TimeTypeDialog = Fragment.load({
					id: that.getView().getId(),
					name: "mytime.ZMOB_MY_TIME_Redesign.view.fragments.TimeType",
					controller: that
				}).then(function (oDialog) {
					oDialog.setModel(oModel);
					return oDialog;
				});

			}
			this._TimeTypeDialog.then(function (oDialog) {
				that._configSearchHelp(oButton, oDialog);
				var oBinding = oDialog.getBinding("items");
				var filterArray = [];
				filterArray.push(new sap.ui.model.Filter({
					path: "CostCode",
					operator: "EQ",
					value1: row.Zzcst
				}));
				filterArray.push(new sap.ui.model.Filter({
					path: "JobCode",
					operator: "EQ",
					value1: row.Zzptjcd
				}));
				filterArray.push(new sap.ui.model.Filter({
					path: "ZZSSC",
					operator: "EQ",
					value1: row.Zzssc
				}));
				oBinding.filter(filterArray);
				oDialog.open();
			}.bind(this));
		},

		handleTimeTypeSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oBinding = oEvent.getSource().getBinding("items");
			var rowno = this.selectedValueHelp.getBindingContext().getPath().split('/')[2];
			var row = this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime")[rowno];
			var filterArray = [];
			filterArray.push(new sap.ui.model.Filter({
				path: "CostCode",
				operator: "EQ",
				value1: row.Zzcst
			}));
			filterArray.push(new sap.ui.model.Filter({
				path: "JobCode",
				operator: "EQ",
				value1: row.Zzptjcd
			}));
			filterArray.push(new sap.ui.model.Filter({
				path: "ZZSSC",
				operator: "EQ",
				value1: row.Zzssc
			}));

			filterArray.push(new sap.ui.model.Filter({

				path: "TimeType",
				operator: FilterOperator.Contains,
				value1: sValue
			}));
			oBinding.filter(filterArray);

			/*			var aFilters = oBinding.aFilters;
						if (oBinding.aFilters !== undefined && oBinding.aFilters.length !== undefined && oBinding.aFilters.length > 0) {
							aFilters.push(
								new sap.ui.model.Filter({
									path: "TimeType",
									operator: FilterOperator.Contains,
									value1: sValue
								})
							)
							oBinding.filter(aFilters);
					
						}

			*/
		},
		handleValueHelpActivity: function (oEvent) {

			this.selectedValueHelp = oEvent.getSource();
			var oModel = new sap.ui.model.json.JSONModel();
			var asearchHelpActivity = this.getProperty("searchHelpActivity", "/SearchHelpActivity");
			oModel.setData(asearchHelpActivity);
			var oButton = oEvent.getSource();
			if (!this._ActivityDialog) {
				this._ActivityDialog = Fragment.load({
					id: that.getView().getId(),
					name: "mytime.ZMOB_MY_TIME_Redesign.view.fragments.Activity",
					controller: that
				}).then(function (oDialog) {
					oDialog.setModel(oModel);
					return oDialog;
				});

			}
			this._ActivityDialog.then(function (oDialog) {
				that._configSearchHelp(oButton, oDialog);
				oDialog.open();
			}.bind(this));
		},
		handleValueHelpClass: function (oEvent) {

			if (this.getView().getModel("app").getProperty("/timePageReadOnly") === true) {
				this.displayClassPopover(oEvent);

			} else {
				this.selectedValueHelp = oEvent.getSource();
				var spath = oEvent.getSource().getBindingContext().getPath();
				var rowno = spath.split('/')[2];
				var tableempcol = oEvent.getSource().data("colno");

				var oModel = new sap.ui.model.json.JSONModel();
				var asearchHelpClass = this.getProperty("searchHelpClass", "/SearchHelpClass");
				oModel.setData(asearchHelpClass);
				oModel.setProperty("/tablerow", rowno);
				oModel.setProperty("/tablecol", tableempcol);
				oModel.setProperty("/Zztrfgr", this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime/" + rowno + "/Class" +
					tableempcol));
				oModel.setProperty("/Persk", this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime/" + rowno + "/Trfst" +
					tableempcol));
				var oButton = oEvent.getSource();
				if (!this._ClassDialog) {
					this._ClassDialog = Fragment.load({
						id: that.getView().getId(),
						name: "mytime.ZMOB_MY_TIME_Redesign.view.fragments.Class",
						controller: that
					}).then(function (oDialog) {
						oDialog.setModel(oModel);
						return oDialog;
					});

				}

				this._ClassDialog.then(function (oDialog) {
					oDialog.open();
				}.bind(this));

			}
		},

		displayClassPopover: function (oEvent) {
			var spath = oEvent.getSource().getBindingContext().getPath();
			var rowno = spath.split('/')[2];
			var tableempcol = oEvent.getSource().data("colno");

			var m = new sap.ui.model.json.JSONModel();
			m.setProperty("/tablerow", rowno);
			m.setProperty("/tablecol", tableempcol);
			m.setProperty("/Zztrfgr", this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime/" + rowno + "/Class" + tableempcol));
			m.setProperty("/Persk", this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime/" + rowno + "/Trfst" + tableempcol));

			this.setModel(m, "ClassModel");

			var S;
			if (S) {
				S.close();
				S.destroy();
			}
			var U = {

				handleClose: function (e) {

					S.close();
					S.destroy();
				},

				formatText: function (n) {
					return n;
				},
			};
			if (!S) {
				S = sap.ui.xmlfragment(this.getView().getId(), "mytime.ZMOB_MY_TIME_Redesign.view.fragments.ClassDescriptionPopOver", U);
				S.setPlacement(sap.m.PlacementType.Left);
				this.getView().addDependent(S);
			}
			var V = oEvent.getSource();
			jQuery.sap.delayedCall(0, this, function () {
				S.openBy(V);
			});

		},

		handleClassSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter({
				filters: [
					new sap.ui.model.Filter("Trfgr", FilterOperator.Contains, sValue),
					new sap.ui.model.Filter("Persk", FilterOperator.Contains, sValue),
					new sap.ui.model.Filter("ClassDesc", FilterOperator.Contains, sValue),
				],
				and: false
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},

		handleClassClose: function (oEvent) { // reset the filter
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([]);
			var sZztrfgr = "";
			var sPersk = "";
			var rowno = oEvent.getSource().getModel().getProperty("/tablerow");
			var colno = oEvent.getSource().getModel().getProperty("/tablecol");

			var aContexts = oEvent.getParameter("selectedContexts");
			if (aContexts && aContexts.length) {
				sZztrfgr = aContexts[0].getObject().Trfgr;
				sPersk = aContexts[0].getObject().Persk;

				this.getView().getModel("crewTimeRedesign").setProperty("/CrewTime/" + rowno + "/Class" + colno, sZztrfgr);
				this.getView().getModel("crewTimeRedesign").setProperty("/CrewTime/" + rowno + "/Trfst" + colno, sPersk);
				MessageToast.show("You have chosen " + aContexts.map(function (oContext) {
					return oContext.getObject().ClassDesc;
				}).join(", "));
			}
		},
		handleActivitySearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter({
				filters: [
					new sap.ui.model.Filter("Zzact", FilterOperator.Contains, sValue),
					new sap.ui.model.Filter("WorkpkgDesc", FilterOperator.Contains, sValue),
					new sap.ui.model.Filter("WorkpkgId", FilterOperator.Contains, sValue),
				],
				and: false
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},

		_configSearchHelp: function (oButton, oDialog) {
			// Multi-select if required
			var bMultiSelect = !!oButton.data("multi");
			oDialog.setMultiSelect(bMultiSelect);

			var sCustomConfirmButtonText = oButton.data("confirmButtonText");
			oDialog.setConfirmButtonText(sCustomConfirmButtonText);

			// Remember selections if required
			var bRemember = !!oButton.data("remember");
			oDialog.setRememberSelections(bRemember);

			//add Clear button if needed
			var bShowClearButton = !!oButton.data("showClearButton");
			oDialog.setShowClearButton(bShowClearButton);

			// Set growing property
			var bGrowing = oButton.data("growing");
			oDialog.setGrowing(bGrowing == "true");

			// Set growing threshold
			var sGrowingThreshold = oButton.data("threshold");
			if (sGrowingThreshold) {
				oDialog.setGrowingThreshold(parseInt(sGrowingThreshold));
			}

			// Set draggable property
			var bDraggable = !!oButton.data("draggable");
			oDialog.setDraggable(bDraggable);

			// Set draggable property
			var bResizable = !!oButton.data("resizable");
			oDialog.setResizable(bResizable);

			// Set style classes
			var sResponsiveStyleClasses =
				"sapUiResponsivePadding--header sapUiResponsivePadding--subHeader sapUiResponsivePadding--content sapUiResponsivePadding--footer";
			var bResponsivePadding = !!oButton.data("responsivePadding");
			oDialog.toggleStyleClass(sResponsiveStyleClasses, bResponsivePadding);

			// clear the old search filter
			oDialog.getBinding("items").filter([]);

		},
		handleActivityValueHelpClose: function (oEvent) {
			var oSelectedItem1 = oEvent.getParameter("selectedItem");
			if (oSelectedItem1) {
				this.selectedValueHelp.setValue(oSelectedItem1.getTitle());
			}
		},
		handleTimeTypeValueHelpClose: function (oEvent) {
			var oSelectedItem1 = oEvent.getParameter("selectedItem");
			if (oSelectedItem1) {
				this.selectedValueHelp.setValue(oSelectedItem1.getTitle());
			}
		},
		longtextPopover: function (oEvent) {
			if (this.getView().getModel("app").getProperty("/timePageReadOnly") === true) {
				this.displaylongtextPopover(oEvent);
			} else {
				this.editlongtextPopover(oEvent);
			}
		},
		editlongtextPopover: function (oEvent) {
			var S;
			var a = this;
			var tableempcol = oEvent.getSource().data("colno");
			const LongText = 'LongText' + tableempcol;
			const LongTextData = 'LongText_Data' + tableempcol;

			var m = new sap.ui.model.json.JSONModel();

			if (S) {
				S.close();
				S.destroy();
			}
			var U = {

				handleClose: function (e) {

					S.close();
					S.destroy();
				},
				handleOk: this.onLongTextSubmit.bind(this),
				onLongTextEdit: this.onLongTextEdit.bind(this),
				onLongTextDelete: this.onLongTextDelete.bind(this),
				onPost: this.onLongTextPost.bind(this),
				formatter: this.formatter.CheckBoxValue.bind(this),
				formatText: function (n) {
					return n;
				},
			};
			if (!S) {

				S = sap.ui.xmlfragment(this.getView().getId(), "mytime.ZMOB_MY_TIME_Redesign.view.fragments.EditLongTextPopOver", U);

				this.getView().addDependent(S);
			}
			var V = oEvent.getSource();
			var spath = V.getBindingContext().getPath();
			var rowno = spath.split('/')[2];
			var row = this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime")[rowno];
			S.bindElement({
				path: spath,
				model: "crewTimeRedesign"
			});

			m.setProperty('/EmpCol', tableempcol);
			m.setProperty('/LongText', row[LongText]);
			m.setProperty('/LongText_Data', row[LongTextData]);
			this.setModel(m, "longdata");

			jQuery.sap.delayedCall(0, this, function () {

				S.open(V);

			});
		},
		displaylongtextPopover: function (oEvent) {
			var S;
			var a = this;
			var tableempcol = oEvent.getSource().data("colno");
			const LongText = 'LongText' + tableempcol;
			const LongTextData = 'LongText_Data' + tableempcol;

			var m = new sap.ui.model.json.JSONModel();

			if (S) {
				S.close();
				S.destroy();
			}
			var U = {

				handleClose: function (e) {

					S.close();
					S.destroy();
				},

				formatText: function (n) {
					return n;
				},
			};
			if (!S) {
				S = sap.ui.xmlfragment(this.getView().getId(), "mytime.ZMOB_MY_TIME_Redesign.view.fragments.DisplayLongTextPopOver", U);
				S.setPlacement(sap.m.PlacementType.Left);
				this.getView().addDependent(S);
			}
			var V = oEvent.getSource();
			var spath = V.getBindingContext().getPath();
			var rowno = spath.split('/')[2];
			var row = this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime")[rowno];
			S.bindElement({
				path: spath,
				model: "crewTimeRedesign"
			});

			m.setProperty('/EmpCol', tableempcol);
			m.setProperty('/LongText', row[LongText]);
			m.setProperty('/LongText_Data', row[LongTextData]);
			this.setModel(m, "longdata");

			jQuery.sap.delayedCall(0, this, function () {

				S.openBy(V);

			});
		},
		onCostCodeQuickView: function (oEvent) {
			var S;
			var a = this;
			if (S) {
				S.close();
			}
			var U = {
				handleClose: function (e) {
					S.close();
				},
				getTimeTypeDescription: function (timetype) {

					return timetype + ' (' + a.timeTypeDescription[timetype] + ')';
				}

			};
			if (!S) {
				S = sap.ui.xmlfragment(this.getView().getId(), "mytime.ZMOB_MY_TIME_Redesign.view.fragments.CostCodeDescription", U);
				this.getView().addDependent(S);
			}
			var V = oEvent.getSource();
			var spath = V.getBindingContext().getPath();
			//	this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime");
			S.bindElement({
				path: spath,
				model: "crewTimeRedesign"
			});
			jQuery.sap.delayedCall(0, this, function () {
				S.openBy(V);
			});
		},
		getDaysDifference: function (a, b) {

			var sDate = new Date(a);

			const year = b.substring(0, 4);
			const month = b.substring(4, 6);
			const day = b.substring(6, 8);
			const eDate = new Date(year, month - 1, day);

			var diff1 = Math.abs(sDate.getTime() - eDate.getTime());
			var diff2 = Math.ceil(diff1 / (1000 * 60 * 60 * 24));
			return diff2;

		},
		onLongTextSubmit: function (e) {
			var i = e.getSource().getParent().getBindingContext("crewTimeRedesign").getPath().split('/')[2];
			var aCrewTimeRedesign = this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime");;
			var tabempcol = this.getView().getModel("longdata").getProperty("/EmpCol");
			const LongText = 'LongText' + tabempcol;
			const LongTextData = 'LongText_Data' + tabempcol;

			aCrewTimeRedesign[i][LongTextData] = this.getView().getModel("longdata").getProperty("/LongText_Data");
			aCrewTimeRedesign[i][LongText] = this.getView().getModel("longdata").getProperty("/LongText");
			this.getView().getModel("crewTimeRedesign").setProperty("/CrewTime", aCrewTimeRedesign, null, true);
			e.getSource().getParent().close();
			e.getSource().getParent().destroy();
		},
		onLongTextEdit: function (e) {
			if (e.getSource().getParent().getParent().getAggregation('items')[0].getText()) {
				this.byId('feedInput').setValue(e.getSource().getParent().getParent().getAggregation('items')[0].getText());
				//	this.byId('feedInput').setEnabled(true);
				this.getView().getModel("longdata").setProperty("/LongText", '');
				this.byId('feedInput').rerender();
			}
		},
		onLongTextDelete: function (e) {

			if (e.getSource().getParent().getParent().getAggregation('items')[0].getText()) {
				this.getView().getModel("longdata").setProperty("/LongText_Data", '');
				this.getView().getModel("longdata").setProperty("/LongText", '');
				this.byId('feedInput').setEnabled(false);
				e.getSource().getParent().getParent().getParent().getBeginButton().setEnabled(true);
			}
		},
		onLongTextPost: function (e) {
			//var i = e.getSource().getParent().getBindingContext("crewTimeRedesign").getPath().split('/')[2];
			var o = e.getSource().getParent().getAggregation('beginButton');
			//var aCrewTimeRedesign = this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime");;
			//var tabempcol = this.getView().getModel("longdata").getProperty("/EmpCol");
			//const LongText = 'LongText' + tabempcol;
			//const LongTextData = 'LongText_Data' + tabempcol;

			if (e.getParameter('value')) {
				//aCrewTimeRedesign[i][LongTextData] = e.getParameter('value');
				//aCrewTimeRedesign[i][LongText] = 'X';
				this.getView().getModel("longdata").setProperty("/LongText_Data", e.getParameter('value'));
				this.getView().getModel("longdata").setProperty("/LongText", 'X');
				//this.getView().getModel("crewTimeRedesign").setProperty("/CrewTime", aCrewTimeRedesign, null, true);
				this.byId('feedInput').setEnabled(false);
				o.setEnabled(true);
			}
			// 	
			// 	d[i].TimeEntryDataFields.LONGTEXT = 'X';
			// 	if (d[i].Counter !== "") {
			// 		d[i].TimeEntryOperation = 'U';
			// 		d[i].deleteButtonEnable = true;
			// 		d[i].addButtonEnable = true;
			// 	} else {
			// 		d[i].TimeEntryOperation = 'C';
			// 		d[i].deleteButtonEnable = true;
			// 		d[i].addButtonEnable = true;
			// 	}
			// 	var m = new J(d);
			// 	this.setModel(m, "TodoList");
			// 	o.setEnabled(true);

		},
		onCrewLoad: function (aCrew) {
			this.byId("idPageHeader").setTitle(this.sCrew.CrewId + ' (' + this.sCrew.Description + ') Timesheet');
			this.byId("idForeman").setText(aCrew.FmName);
			this.byId("idStatus").setText(aCrew.StatusTx);
			this.byId("idStatus").setState(formatter.Status(aCrew.StatusTx));
			this.byId("idDate").setValue(aCrew.EffectiveDate);
			var CrewEffdate = aCrew.CrewEffectiveDate.substring(5, 6) + "/" + aCrew.CrewEffectiveDate.substring(7, 8) + "/" + aCrew.CrewEffectiveDate
				.substring(0, 4);
			//this.byId("idEmpTable").setNoData("Crew Does not exist on the selected day, the start date of the crew is " + CrewEffdate);
			//    this.setProperty(this.sCrew, aCrew);
			this.sCrew.JobCode = aCrew.JobCode;
			this.sCrew.CrewId = aCrew.CrewId;
			this.sCrew.Description = aCrew.Description;
			this.sCrew.ShiftDescription = aCrew.ShiftDescription;
			this.sCrew.EffectiveDate = aCrew.EffectiveDate;
			this.sCrew.JobCode = aCrew.JobCode;
			this.sCrew.FmName = aCrew.FmName;
			this.sCrew.StatusTx = aCrew.StatusTx;
			this.sCrew.FmWerks = aCrew.FmWerks;
			this.sCrew.CrewEffectiveDate = aCrew.CrewEffectiveDate;
			this.sCrew.IsEditable = aCrew.IsEditable;
			this._updatePageSetting();
		},
		onCrewListError: function (oError) {
			var errorDetails = this.parseError(oError.responseText);
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.error(errorDetails, {
				styleClass: bCompact ? "sapUiSizeCompact" : ""
			});
		},
		onCrewTimeError: function (oError) {
			this.hideBusyIndicator();
			var errorDetails = this.parseError(oError.responseText);
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.error(errorDetails, {
				styleClass: bCompact ? "sapUiSizeCompact" : ""
			});
		},
		onTimebyDateError: function (oError, aCrew) {
			var errorDetails = this.parseError(oError.responseText);
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.error(errorDetails, {
				styleClass: bCompact ? "sapUiSizeCompact" : ""
			});
			this.byId("idDate").setValue(aCrew.EffectiveDate);
		},
		onCrewTimeErrors: function (oError) {
			this.hideBusyIndicator();
			var oBody = JSON.parse(oError.responseText);
			var aErrorDetails = oBody.error.message.value;
			var aErrorcode = oBody.error.innererror.errordetails[0].message;
			var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
			if (oBody.error.innererror.errordetails[0].severity !== "warning") {
				MessageBox.error(aErrorDetails, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				});
			} else {
				if (oBody.error.innererror.errordetails[0].severity === "warning") {
					that.onBack();
				}
			}
		},
		parseError: function (oError) {
			var messageText;
			try {
				// Try to parse as a JSON string
				messageText = JSON.parse(oError);
				messageText = messageText.error.code + ": " + messageText.error.message.value; // + "\n" + "Please contact Administrator.";	SAP-8326						
			} catch (err) {
				try {
					switch (typeof oError) {
					case "string": // XML or simple text
						if (oError.indexOf("<?xml") === 0) {
							var oXML = jQuery.parseXML(oError);
							var oXMLMsg = oXML.querySelector("message");
							if (oXMLMsg) {
								messageText = oXMLMsg.textContent;
							}
						} else {
							messageText = oError;
						}
						break;
					case "object": // Exception
						messageText = oError.toString();
						break;
					}
				} catch (err) {
					messageText = "An unknown error occurred!! Please contact Administrator !!";
				}
			}
			return messageText.replace("/IWBEP/CM_MGW_RT/022: ", "");
		}

	});
});