sap.ui.define([
	"mytime/ZMOB_MY_TIME_Redesign/controller/BaseController",
	"sap/ui/model/json/JSONModel"
], function (BaseController, JSONModel) {
	"use strict";

	return BaseController.extend("mytime.ZMOB_CREW_TIME.controller.App", {

		onInit: function () {

			var a = this;
			var oViewModel,
				fnSetAppNotBusy,
				iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			oViewModel = new JSONModel({
				busy: true,
				delay: 0
			});
			this.setModel(oViewModel, "appView");

			this.oViewApplicationId = new JSONModel({
				applicationId: "E",
			});
			fnSetAppNotBusy = function () {
				oViewModel.setProperty("/busy", false);
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			};

			try {
				var approverFlag = this.getOwnerComponent().getComponentData().startupParameters['TA'][0];
				if (approverFlag === 'X') {
					oViewModel.setProperty("/applicationId", "A");
					this.getOwnerComponent().getModel("app").setProperty("/applicationId", "A");
				}

			} catch (err) {};
//   Code Added for Time Admin Start Here
			try {
				var timeadminFlag = this.getOwnerComponent().getComponentData().startupParameters['AD'][0];

				if (timeadminFlag === 'Y') {
					oViewModel.setProperty("/timeadminId", "TA");
					this.getOwnerComponent().getModel("app").setProperty("/timeadminId", "TA");
					this.getOwnerComponent().getModel("app").setProperty("/isUserCrewTimeAdmin", false);
				}
				
			} catch (err) {};
//   Code Added for Time Admin End Here			
			this.getOwnerComponent().getModel("TIME7011").metadataLoaded().then(fnSetAppNotBusy);

			this.getOwnerComponent().getService("ShellUIService").then( // promise is returned
				function (oService) {
					var sTitle = (oViewModel.getProperty("/applicationId") === 'A') ? a.getView().getModel("i18n").getResourceBundle().getText(
						"Timesheet_Approval_Title") : a.getView().getModel("i18n").getResourceBundle().getText("Timesheet_Entry_Title");

					oService.setTitle(sTitle);
				},
				function (oError) {
					jQuery.sap.log.error("ShellUIService failed to load", oError, "");
				}
			);
			// apply content density mode to root view
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
		}
	});

});