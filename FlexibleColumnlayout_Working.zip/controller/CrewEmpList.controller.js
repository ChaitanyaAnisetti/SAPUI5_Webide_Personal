sap.ui.define(["mytime/ZMOB_MY_TIME_Redesign/controller/BaseController", "sap/ui/model/json/JSONModel",
	"mytime/ZMOB_MY_TIME_Redesign/js/Utilities", "sap/m/MessageBox", "sap/m/MessageToast", "mytime/ZMOB_MY_TIME_Redesign/js/formatter"
], function (e, t, r, i, o, s) {
	"use strict";
	return e.extend("mytime.ZMOB_MY_TIME_Redesign.controller.CrewEmpList", {
		formatter: s,
		onInit: function () {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oComponent = this.getOwnerComponent();
			this.sCrew = {};
			this._handleRouting()
		},
		_handleRouting: function () {
			this.getRouter().attachRouteMatched(function (e) {
				var t = e.getParameter("name");
				this.applicationId = this._getApplicationId();
				if (t === "CrewEmpList" || t === "CrewTime" && (this.sCrew.CrewId === undefined || this.sCrew.CrewId === "")) {
					this.sCrew.JobCode = e.getParameter("arguments").JobCode;
					this.sCrew.CrewId = e.getParameter("arguments").CrewId;
					this.sCrew.EffectiveDate = e.getParameter("arguments").EffectiveDate;
					this.byId("idDate").setValue(this.sCrew.EffectiveDate);
					this.getView().bindElement({
						path: "/CrewListSet(JobCode='" + this.sCrew.JobCode + "',CrewId='" + encodeURIComponent(this.sCrew.CrewId) +
							"',EffectiveDate='" + this.sCrew.EffectiveDate + "',ApplicationId='" + this.applicationId + "')",
						events: {
							change: function (e) {
								var t = e.getSource();
								t.refresh(false)
							},
							dataRequested: function () {},
							dataReceived: function () {}
						}
					});
					this._initializeCrewTimeDataServiceModels(this.sCrew)
				}
			}, this)
		},
		_getApplicationId: function () {
			var e = "E";
			try {
				var t = this.getOwnerComponent().getComponentData().startupParameters["TA"][0];
				if (t === "X") {
					e = "A"
				}
			} catch (e) {}
			return e
		},
		_initializeCrewTimeDataServiceModels: function (e) {
			this.getView().setModel(new t, "crewEmpList");
			this._initializeCrewEmployeeData(e)
		},
		_initializeCrewEmployeeData: function (e) {
			this.showBusyIndicator(4e3, 1);
			this.oComponent.getDataProvider().loadCrewEmployees(this, e)
		},
		onDateChange: function (e) {},
		onCrewEmpLoad: function (e) {
			var t = [];
			if (e !== undefined && e.length > 0) {
				t.push({
					Ename: "All Crew Members",
					Pernr: "00000000",
					EmpBecref: "00000000",
					CrewEffectiveDate: e[0].CrewEffectiveDate,
					JobCode: e[0].JobCode,
					CrewId: e[0].CrewId,
					Description: e[0].Description,
					EffectiveDate: e[0].EffectiveDate,
					Shift: e[0].Shift,
					ShiftDescription: e[0].ShiftDescription,
					EmpPersk: e[0].EmpPersk,
					EmpPersg: e[0].EmpPersg,
					EmpZztrfgr: e[0].EmpZztrfgr,
					EmpEffectiveDate: e[0].EmpEffectiveDate,
					DeleteFlag: " ",
					TotalHours: e[0].TotalHours,
					EmpZztrfgrTx: e[0].EmpZztrfgrTx
				})
			}
			for (var r = 0; r < e.length; r++) {
				t.push({
					Ename: e[r].Ename,
					ParentId: e[r].ParentId,
					CrewEffectiveDate: e[r].CrewEffectiveDate,
					JobCode: e[r].JobCode,
					CrewId: e[r].CrewId,
					Pernr: e[r].Pernr,
					Description: e[r].Description,
					EffectiveDate: e[r].EffectiveDate,
					Shift: e[r].Shift,
					ShiftDescription: e[r].ShiftDescription,
					EmpPersk: e[r].EmpPersk,
					EmpPersg: e[r].EmpPersg,
					EmpZztrfgr: e[r].EmpZztrfgr,
					EmpBecref: e[r].EmpBecref,
					EmpEffectiveDate: e[r].EmpEffectiveDate,
					DeleteFlag: " ",
					TotalHours: e[r].TotalHours,
					EmpZztrfgrTx: e[r].EmpZztrfgrTx,
					CraftDescription: e[r].CraftDescription
				})
			}
			this.getModel("crewEmpList").setSizeLimit(t.length);
			this.setProperty("crewEmpList", "/CrewListSet", t);
			this.hideBusyIndicator()
		},
		onCrewEmpError: function (e) {
			var t = this.parseError(e.responseText);
			var r = !!this.getView().$().closest(".sapUiSizeCompact").length;
			i.error(t, {
				styleClass: r ? "sapUiSizeCompact" : ""
			})
		},
		onTimesheet: function (e) {
			var t = "";
			var r = e.getParameter("listItem");
			var i = r.getBindingContextPath();
			var o = this.getProperty("crewEmpList", i);
			this.getRouter().navTo("CrewTime", {
				JobCode: o.JobCode,
				CrewId: o.CrewId,
				EffectiveDate: o.EffectiveDate,
				EmpBecref: o.EmpBecref
			})
		},
		hideBusyIndicator: function () {
			sap.ui.core.BusyIndicator.hide()
		},
		showBusyIndicator: function (e, t) {
			sap.ui.core.BusyIndicator.show(t);
			if (e && e > 0) {
				if (this._sTimeoutId) {
					jQuery.sap.clearDelayedCall(this._sTimeoutId);
					this._sTimeoutId = null
				}
				this._sTimeoutId = jQuery.sap.delayedCall(e, this, function () {
					this.hideBusyIndicator()
				})
			}
		},
		parseError: function (e) {
			var t;
			try {
				t = JSON.parse(e);
				t = t.error.code + ": " + t.error.message.value
			} catch (o) {
				try {
					switch (typeof e) {
					case "string":
						if (e.indexOf("<?xml") === 0) {
							var r = jQuery.parseXML(e);
							var i = r.querySelector("message");
							if (i) {
								t = i.textContent
							}
						} else {
							t = e
						}
						break;
					case "object":
						t = e.toString();
						break
					}
				} catch (e) {
					t = "An unknown error occurred!! Please contact Administrator !!"
				}
			}
			return t.replace("/IWBEP/CM_MGW_RT/022: ", "")
		},
		onCloseDetailPress: function () {
			var e = this.getView().getModel("app");
			e.setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
			this.getOwnerComponent().getRouter().navTo("CrewList", {}, true)
		},
		toggleFullScreen: function () {
			var e = this.getView().getModel("app");
			var t = e.getProperty("/actionButtonsInfo/midColumn/fullScreen");
			e.setProperty("/actionButtonsInfo/midColumn/fullScreen", !t);
			if (!t) {
				e.setProperty("/previousLayout", e.getProperty("/layout"));
				e.setProperty("/layout", "MidColumnFullScreen")
			} else {
				e.setProperty("/layout", e.getProperty("/previousLayout"))
			}
		}
	})
});