sap.ui.define([
	"mytime/ZMOB_MY_TIME_Redesign/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"mytime/ZMOB_MY_TIME_Redesign/js/Utilities",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"mytime/ZMOB_MY_TIME_Redesign/js/formatter",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, JSONModel, Utilities, MessageBox, MessageToast, formatter, Fragment, Filter, FilterOperator) {
	"use strict";
	var that;
	return Controller.extend("mytime.ZMOB_MY_TIME_Redesign.controller.CrewList", {
		formatter: formatter,
		onInit: function () {
			that = this;
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oComponent = this.getOwnerComponent();
			this.sCrewList = [];
			this.sCrewListRetro = [];
			this.EffectiveDate = "";
			this.applicationId = this._getApplicationId();
			this.timeadminId = this._getTimeAdminId();
			this.isDateChanged = false;
			this._handleRouting();
		},
		_handleRouting: function () {
			//   Code Added for Time Admin Start Here 			
			if (this.timeadminId === "TA") {
				this.getOwnerComponent().getService("ShellUIService").then( // promise is returned
					function (oService) {
						oService.setTitle("Time Admin");
					}
				);
				//   Code Added for Crew List Retro in Time Admin Start Here - SAPC-5402
				this.getView().byId("idTableRetro1").setVisible(false);
				this.getView().byId("idCrewListRetro1").setVisible(false);
				this.getView().byId("idCrewList").setVisible(false);
				//   Code Added for Crew List Retro in Time Admin End Here - SAPC-5402
				this.getView().byId("idPageHeader").setVisible(false);
				this.getView().setModel(new JSONModel(), "searchHelpProjCode");
				this.getView().setModel(new JSONModel(), "searchHelpCrewId");
				this._initializeSearchHelpProjCode();
				this.getRouter().attachRouteMatched(function (oEvent) {
					var sNavigationName = oEvent.getParameter("name");
					if ((sNavigationName === "CrewList" || sNavigationName === "CrewTime" || sNavigationName === "CrewEmpList") && (this.sCrewList.length ===
							undefined || this.sCrewList.length === 0)) {
						if (oEvent.getParameter("arguments").JobCode !== undefined && oEvent.getParameter("arguments").JobCode !== "") {
							this.byId("idPrj").setValue(oEvent.getParameter("arguments").JobCode);
						}
						if (oEvent.getParameter("arguments").CrewId !== undefined && oEvent.getParameter("arguments").CrewId !== "") {
							this.byId("idCrewId").setValue(oEvent.getParameter("arguments").CrewId);
						}
						if (oEvent.getParameter("arguments").EffectiveDate !== undefined && oEvent.getParameter("arguments").EffectiveDate !== "") {
							this.byId("idDate1").setValue(oEvent.getParameter("arguments").EffectiveDate);
						}
					}
				}, this);
			}
			//   Code Added for Time Admin End Here
			else { // added else so that the following statements do not run for TA

				this.getRouter().attachRouteMatched(function (oEvent) {
					var sNavigationName = oEvent.getParameter("name");
					this.EffectiveDate = oEvent.getParameter("arguments").EffectiveDate;
					// if (sNavigationName === "CrewList" || ((sNavigationName === "CrewTime" || sNavigationName === "CrewEmpList") && (this.sCrewList.length ===
					if ((sNavigationName === "CrewList" || sNavigationName === "CrewTime" || sNavigationName === "CrewEmpList") && (this.sCrewList.length ===
							undefined || this.sCrewList.length === 0)) {
						this._initializeCrewListDataServiceModels();
					}
				}, this);
				//   Code Added for Crew List Retro Start Here
				if (this.applicationId === "A") {
					this._initializeCrewListRetroDataServiceModels();
				} else {
					this.getView().byId("idTableRetro").setVisible(false);
					this.getView().byId("idCrewListRetro").setVisible(false);
					//   Code Added for Crew List Retro in Time Admin Start Here - SAPC-5402
					this.getView().byId("idTableRetro1").setVisible(false);
					this.getView().byId("idCrewListRetro1").setVisible(false);
					//   Code Added for Crew List Retro in Time Admin Start Here - SAPC-5402
				}
				//   Code Added for Crew List Retro End Here			
			}
		},

		onTableLoadFinished: function (e) {
			this.sCrewList = this.getView().byId("idTable").getItems();

			// need to think if we need a flag for date change or it is fine

			if (this.getView().getModel("app").getProperty("/layout") !== "OneColumn") {
				if (this.isDateChanged === true) {
					this.isDateChanged = false;
					var item = this.getView().byId("idTable").getItems();
					if (item !== undefined) {
						this.getView().byId("idTable").setSelectedItem(this.getView().byId("idTable").getItems()[0]);
						this.getView().byId("idTable").getItems()[0].firePress();
					}
				}
			} else {
				this.isDateChanged = false;
			}
			this.hideBusyIndicator();
		},

		onTableRetroLoadFinished: function (e) {
			this.sCrewListRetro = this.getView().byId("idTableRetro").getItems();

			if (this.sCrewListRetro.length === undefined || this.sCrewListRetro.length === 0) {
				this.getView().byId("idTableRetro").setVisible(false);
				this.getView().byId("idCrewListRetro").setVisible(false);

			} else {
				this.getView().byId("idTableRetro").setVisible(true);
				this.getView().byId("idCrewListRetro").setVisible(true);
			}

		},
		onRetroTableLoadFinished: function (e) {
			this.sCrewListRetro = this.getView().byId("idTableRetro1").getItems();

			if (this.sCrewListRetro.length === undefined || this.sCrewListRetro.length === 0) {
				this.getView().byId("idTableRetro1").setVisible(false);
				this.getView().byId("idCrewListRetro1").setVisible(false);

			} else {
				this.getView().byId("idTableRetro1").setVisible(true);
				this.getView().byId("idCrewListRetro1").setVisible(true);
			}

		},
		_getApplicationId: function () {
			var appId = this.getOwnerComponent().getModel("app").getProperty("/applicationId");

			if (appId === undefined || appId === "" || (appId !== "A" && appId !== "TA")) {
				return "E";
			} else {
				return appId;
			}
		},
		_getTimeAdminId: function () {
			var TimeAdminId = this.getOwnerComponent().getModel("app").getProperty("/timeadminId");

			if (TimeAdminId !== undefined && TimeAdminId !== "" && TimeAdminId === "TA") {
				return "TA";
			} else {
				TimeAdminId = "";
				return TimeAdminId;
			}
		},
		_initializeCrewListDataServiceModels: function () {
			/*			this.getView().setModel(new JSONModel(), "CrewList");
						// write code to get the effective date and load the data based on the date
						this.byId("idDate").setDateValue(new Date());
						this._initializeCrewListData();*/

			var oDate = new Date();
			var Month = oDate.getMonth() + 1;
			var oDay = oDate.getDate();
			Month = Month < 10 ? "0" + Month : Month;
			oDay = oDay < 10 ? "0" + oDay : oDay;
			var sDate = oDate.getFullYear() + "" + Month + "" + oDay;

			if (this.EffectiveDate !== undefined && this.EffectiveDate !== null && this.EffectiveDate !== "") {
				sDate = this.EffectiveDate;
			}

			this.byId("idDate").setValue(sDate);

			var a = this;
			var oTable = this.getView().byId("idTable");
			var oBinding = oTable.getBinding("items");

			this.getView().getModel().attachRequestFailed(function (oError) {
				var errorDetails = a.parseError(oError.getParameter("response").responseText);
				var bCompact = !!a.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(errorDetails, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				});
			});

			var oTableFilter = [];
			var oFilter = new sap.ui.model.Filter('EffectiveDate', sap.ui.model.FilterOperator.EQ, sDate);
			oTableFilter.push(oFilter);
			oFilter = new sap.ui.model.Filter('ApplicationId', sap.ui.model.FilterOperator.EQ, this.applicationId);
			oTableFilter.push(oFilter);
			oBinding.aFilters = null;
			oBinding.filter(oTableFilter);
		},
		_initializeCrewListData: function () {
			this.setData("CrewList", {
				selection: {
					Action: "",
					Usrid: "",
					JobCode: "",
					CrewId: "",
					Option: "",
					Description: "",
					EffectiveDate: new Date(),
					Shift: "",
					ShiftDescription: "",
					FmName: "",
					FmWerks: "",
					StatusTx: "",
					CrewEffectiveDate: new Date()
				},
				CrewListSet: []

			});
			this.showBusyIndicator(4000, 1);
			this.oComponent.getDataProvider().loadCrewList(this);

		},
		onCrewListLoad: function (aCrewList) {
			this.getModel("CrewList").setSizeLimit(aCrewList.length);
			this.setProperty("CrewList", "/CrewListSet", aCrewList);
			this.sCrewList = aCrewList;
			this.hideBusyIndicator();
		},
		onCrewListError: function (oError) {
			var errorDetails = this.parseError(oError.responseText);
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.error(errorDetails, {
				styleClass: bCompact ? "sapUiSizeCompact" : ""
			});
		},
		//   Code Added for Retro Crew List Start Here
		_initializeCrewListRetroDataServiceModels: function () {
			var oDate = new Date();
			var Month = oDate.getMonth() + 1;
			var oDay = oDate.getDate();
			Month = Month < 10 ? "0" + Month : Month;
			oDay = oDay < 10 ? "0" + oDay : oDay;
			var sDate = oDate.getFullYear() + "" + Month + "" + oDay;

			//	var oRetroModel = this.getOwnerComponent().getModel("CrewListRetroSet");
			var oRetroModel = this.getOwnerComponent().getModel();
			var mParameters = {};
			mParameters.filters = [new sap.ui.model.Filter({
					path: "EffectiveDate",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sDate
				}),
				new sap.ui.model.Filter({
					path: "ApplicationId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: "A"
				})
			];
			mParameters.success = function (oData, response) {
				var a = this;
				var oTable = that.getView().byId("idTableRetro");
				var oBinding = oTable.getBinding("items");

				that.getView().getModel().attachRequestFailed(function (oError) {
					var errorDetails = a.parseError(oError.getParameter("response").responseText);
					var bCompact = !!a.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.error(errorDetails, {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					});
				});

				var oTableFilter = [];
				var oFilter = new sap.ui.model.Filter('EffectiveDate', sap.ui.model.FilterOperator.LT, sDate);
				oTableFilter.push(oFilter);
				oFilter = new sap.ui.model.Filter('ApplicationId', sap.ui.model.FilterOperator.EQ, "A");
				oTableFilter.push(oFilter);
				oBinding.aFilters = null;
				oBinding.filter(oTableFilter);
			};
			oRetroModel.read("/CrewListRetroSet", mParameters);

		},
		//   Code Added for Crew List Retro in Time Admin Start Here - SAPC-5402
		_initializeCrewList1DataServiceModels: function () {
			var oJobCode = this.byId("idPrj").getValue();
			var oCrewId = this.byId("idCrewId").getValue();
			var oEffectiveDate = this.byId("idDate1").getValue();
			//	this.byId("idDate2").setValue(oEffectiveDate);

			var a = this;
			var oTable = this.getView().byId("idCrewList");
			var oBinding = oTable.getBinding("items");

			this.getView().getModel().attachRequestFailed(function (oError) {
				var errorDetails = a.parseError(oError.getParameter("response").responseText);
				var bCompact = !!a.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(errorDetails, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				});
			});

			var oTableFilter = [];
			var oFilter = new sap.ui.model.Filter('EffectiveDate', sap.ui.model.FilterOperator.EQ, oEffectiveDate);
			oTableFilter.push(oFilter);
			oFilter = new sap.ui.model.Filter('ApplicationId', sap.ui.model.FilterOperator.EQ, this.applicationId);
			oTableFilter.push(oFilter);
			oFilter = new sap.ui.model.Filter('JobCode', sap.ui.model.FilterOperator.EQ, oJobCode);
			oTableFilter.push(oFilter);
			oFilter = new sap.ui.model.Filter('CrewId', sap.ui.model.FilterOperator.EQ, oCrewId);
			oTableFilter.push(oFilter);
			oBinding.aFilters = null;
			oBinding.filter(oTableFilter);
		},
		_initializeCrewListRetro1DataServiceModels: function () {

			var oJobCode = this.byId("idPrj").getValue();
			var oCrewId = this.byId("idCrewId").getValue();
			var oEffectiveDate = this.byId("idDate1").getValue();
			var a = this;
			var oTable = that.getView().byId("idTableRetro1");
			var oBinding = oTable.getBinding("items");

			that.getView().getModel().attachRequestFailed(function (oError) {
				var errorDetails = a.parseError(oError.getParameter("response").responseText);
				var bCompact = !!a.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(errorDetails, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				});
			});
			var oTableFilter = [];
			var oFilter = new sap.ui.model.Filter('EffectiveDate', sap.ui.model.FilterOperator.LT, oEffectiveDate);
			oTableFilter.push(oFilter);
			oFilter = new sap.ui.model.Filter('ApplicationId', sap.ui.model.FilterOperator.EQ, "A");
			oTableFilter.push(oFilter);
			oFilter = new sap.ui.model.Filter('JobCode', sap.ui.model.FilterOperator.EQ, oJobCode);
			oTableFilter.push(oFilter);
			oFilter = new sap.ui.model.Filter('CrewId', sap.ui.model.FilterOperator.EQ, oCrewId);
			oTableFilter.push(oFilter);
			oBinding.aFilters = null;
			oBinding.filter(oTableFilter);
			this.sCrewListRetro = this.getView().byId("idTableRetro1").getItems();
			//	var oRetroModel = this.getOwnerComponent().getModel("CrewListRetroSet");
			// var oRetroModel = this.getOwnerComponent().getModel();
			// var mParameters = {};
			// mParameters.filters = [new sap.ui.model.Filter({
			// 		path: "EffectiveDate",
			// 		operator: sap.ui.model.FilterOperator.EQ,
			// 		value1: oEffectiveDate
			// 	}),
			// 	new sap.ui.model.Filter({
			// 		path: "ApplicationId",
			// 		operator: sap.ui.model.FilterOperator.EQ,
			// 		value1: "A"
			// 	}),
			// 	new sap.ui.model.Filter({
			// 		path: "CrewId",
			// 		operator: sap.ui.model.FilterOperator.EQ,
			// 		value1: oCrewId
			// 	}),
			// 	new sap.ui.model.Filter({
			// 		path: "JobCode",
			// 		operator: sap.ui.model.FilterOperator.EQ,
			// 		value1: oJobCode
			// 	})
			// ];
			// mParameters.success = function (oData, response) {
			// 	var oTable = that.getView().byId("idTableRetro1");
			// 	var oBinding = oTable.getBinding("items");

			// 	that.getView().getModel().attachRequestFailed(function (oError) {
			// 		var errorDetails = a.parseError(oError.getParameter("response").responseText);
			// 		var bCompact = !!a.getView().$().closest(".sapUiSizeCompact").length;
			// 		MessageBox.error(errorDetails, {
			// 			styleClass: bCompact ? "sapUiSizeCompact" : ""
			// 		});
			// 	});

			// 	var oTableFilter = [];
			// 	var oFilter = new sap.ui.model.Filter('EffectiveDate', sap.ui.model.FilterOperator.LT, oEffectiveDate);
			// 	oTableFilter.push(oFilter);
			// 	oFilter = new sap.ui.model.Filter('ApplicationId', sap.ui.model.FilterOperator.EQ, "A");
			// 	oTableFilter.push(oFilter);
			// 	oFilter = new sap.ui.model.Filter('JobCode', sap.ui.model.FilterOperator.EQ, oJobCode);
			// 	oTableFilter.push(oFilter);
			// 	oFilter = new sap.ui.model.Filter('CrewId', sap.ui.model.FilterOperator.EQ, oCrewId);
			// 	oTableFilter.push(oFilter);
			// 	oBinding.aFilters = null;
			// 	oBinding.filter(oTableFilter);
			// };
			// oRetroModel.read("/CrewListRetroSet", mParameters);

		},
		//   Code Added for Crew List Retro in Time Admin End Here - SAPC-5402
		onRetroTimesheet: function (oEvent) {
			var bReplace = "";

			var oItem = oEvent.getParameter("listItem");
			var oCtx;
			var aId;
			if (oItem === undefined || oItem === null) {
				oCtx = oEvent.getSource().getBindingContextPath();
				aId = oEvent.getSource().getBindingContext().getObject();
			} else {
				oCtx = oItem.getBindingContextPath();
				aId = oItem.getBindingContext().getObject();
			}

			this.getRouter().navTo("CrewEmpList", {
					"JobCode": aId.JobCode,
					"CrewId": aId.CrewId,
					"EffectiveDate": aId.EffectiveDate
				},
				bReplace);

		},
		//   Code Added for Crew List Retro End Here

		/*		onTimesheet: function (oEvent) {
					var bReplace = "";
					
					
					var a = oEvent.getSource().getSelected();
					if (a === true) {
						oEvent.getSource().setSelected(false);
					} else {
						oEvent.getSource().setSelected(true);
					}

					var _Id = oEvent.getSource().getId();
					var _o = _Id.substr(_Id.lastIndexOf("-") + 1, _Id.length);
					var aId = this.getProperty("CrewList", "/CrewListSet/" + _o + "/");
					if (aId !== undefined && aId.length !== 0) {
						this.setProperty("CrewList", "/selection/JobCode", aId.JobCode);
						this.setProperty("CrewList", "/selection/CrewId", aId.CrewId);
						this.setProperty("CrewList", "/selection/Description", aId.Description);
						this.setProperty("CrewList", "/selection/EffectiveDate", aId.EffectiveDate);
						this.setProperty("CrewList", "/selection/Shift", aId.Shift);
						this.setProperty("CrewList", "/selection/ShiftDescription", aId.ShiftDescription);
						this.setProperty("CrewList", "/selection/FmName", aId.FmName);
						this.setProperty("CrewList", "/selection/FmWerks", aId.FmWerks);
						this.setProperty("CrewList", "/selection/StatusTx", aId.StatusTx);
						this.setProperty("CrewList", "/selection/CrewEffectiveDate", aId.CrewEffectiveDate);

					}

					if (aId.StatusTx === undefined || aId.StatusTx === "" || aId.StatusTx === null) {
						aId.StatusTx = "None";
					}

					if ((aId.Status !== '20' && aId.Status !== '30') && this.applicationId === 'A') {
						var _mess = this.getView().getModel("i18n").getResourceBundle().getText("M.NOTREADYAPPROVAL");

						MessageToast.show(_mess, {
							duration: 5000,
							width: "15em",
							my: "center bottom",
							at: "center bottom",
							of: window,
							offset: "0 0",
							collision: "fit fit",
							onClose: null,
							autoClose: true,
							animationTimingFunction: "ease",
							animationDuration: 2000,
							closeOnBrowserNavigation: true
						});
					} else {
						this.getRouter().navTo("CrewEmpList", {
								"JobCode": aId.JobCode,
								"CrewId": aId.CrewId,
								"Description": aId.Description === "" ? aId.CrewId : aId.Description,
								"EffectiveDate": aId.EffectiveDate,
								"Shift": aId.Shift,
								"ShiftDescription": aId.ShiftDescription,
								"FmName": aId.FmName,
								"FmWerks": aId.FmWerks,
								"StatusTx": aId.StatusTx,
								"CrewEffectiveDate": aId.CrewEffectiveDate
							},
							bReplace);
					}

				},*/

		onTimesheet: function (oEvent) {
			var bReplace = "";

			var oItem = oEvent.getParameter("listItem");
			var oCtx;
			var aId;
			if (oItem === undefined || oItem === null) {
				oCtx = oEvent.getSource().getBindingContextPath();
				aId = oEvent.getSource().getBindingContext().getObject();
			} else {
				oCtx = oItem.getBindingContextPath();
				aId = oItem.getBindingContext().getObject();
			}
			if ((aId.Status !== '20' && aId.Status !== '30') && this.applicationId === 'A') {

				// show the message in this case, but keep going to the second column view so that dates are the same
				var _mess = this.getView().getModel("i18n").getResourceBundle().getText("M.NOTREADYAPPROVAL");

				MessageToast.show(_mess, {
					duration: 5000,
					width: "15em",
					my: "center bottom",
					at: "center bottom",
					of: window,
					offset: "0 0",
					collision: "fit fit",
					onClose: null,
					autoClose: true,
					animationTimingFunction: "ease",
					animationDuration: 2000,
					closeOnBrowserNavigation: true
				});
			}

			this.getRouter().navTo("CrewEmpList", {
					"JobCode": aId.JobCode,
					"CrewId": aId.CrewId,
					"EffectiveDate": aId.EffectiveDate
				},
				bReplace);

		},

		onDateChange: function (oEvent) {

			this.isDateChanged = true;
			//			this.showBusyIndicator(4000, 1);
			//	var	oDP = oEvent.getSource(),
			var oDate = oEvent.getParameter("value");
			//	bValid = oEvent.getParameter("valid");

			this.showBusyIndicator(4000, 1);
			this.getView().byId("idTable").removeSelections();

			var oTable = this.getView().byId("idTable");
			var oBinding = oTable.getBinding("items");
			var oTableFilter = [];
			var oFilter = new sap.ui.model.Filter('EffectiveDate', sap.ui.model.FilterOperator.EQ, oDate);
			oTableFilter.push(oFilter);
			oFilter = new sap.ui.model.Filter('ApplicationId', sap.ui.model.FilterOperator.EQ, this.applicationId);
			oTableFilter.push(oFilter);
			oBinding.aFilters = null;
			oBinding.filter(oTableFilter);
			//	this.oComponent.getDataProvider().loadCrewListbyDate(this, oDate);

			//   Code Added for Crew List Retro Start Here
			if (this.applicationId === "A") {
				this.getView().byId("idTableRetro").removeSelections();
				var oTable1 = this.getView().byId("idTableRetro");
				var oBinding1 = oTable1.getBinding("items");
				var oTableFilter1 = [];
				var oFilter1 = new sap.ui.model.Filter('EffectiveDate', sap.ui.model.FilterOperator.LT, oDate);
				oTableFilter1.push(oFilter1);
				oFilter1 = new sap.ui.model.Filter('ApplicationId', sap.ui.model.FilterOperator.EQ, this.applicationId);
				oTableFilter1.push(oFilter1);
				oBinding1.aFilters1 = null;
				oBinding1.filter(oTableFilter1);
			}
			//   Code Added for Crew List Retro End Here
		},
		onCrewListLoadbyDate: function (aCrewList) {
			this.getModel("CrewList").setSizeLimit(aCrewList.length);
			this.setProperty("CrewList", "/CrewListSet", "");
			this.setProperty("CrewList", "/CrewListSet", aCrewList);
			this.sCrewList = aCrewList;
			this.hideBusyIndicator();
		},

		//   Code Added for Time Admin Start Here
		_initializeSearchHelpCrewId: function (oJobCode) {
			this.setData("searchHelpCrewId", {
				selection: {
					JobCode: "",
					CrewId: "",
					CrewDes: "",
					EffectiveDate: ""
				},
				SearchHelpCrewId: []
			});
			this.oComponent.getDataProvider().loadSearchHelpCrewId(this, oJobCode);
		},
		_initializeSearchHelpProjCode: function () {
			var oDate = new Date();
			var Month = oDate.getMonth() + 1;
			var oDay = oDate.getDate();
			Month = Month < 10 ? "0" + Month : Month;
			oDay = oDay < 10 ? "0" + oDay : oDay;
			var sDate = oDate.getFullYear() + "" + Month + "" + oDay;

			this.byId("idDate1").setValue(sDate);

			that.setData("searchHelpProjCode", {
				selection: {
					Role: "",
					JobCode: "",
					EffectiveDate: ""
				},
				SearchHelpProjCode: []
			});
			that.oComponent.getDataProvider().loadSearchHelpProjCode(this);
		},
		onSearchHelpProjCodeLoad: function (aProjCodeList) {
			this.getModel("searchHelpProjCode").setSizeLimit(aProjCodeList.length);
			this.setProperty("searchHelpProjCode", "/SearchHelpProjCode", aProjCodeList);
			this.hideBusyIndicator();
		},
		onSearchHelpCrewIdLoad: function (aCrewIdList) {
			this.getModel("searchHelpCrewId").setSizeLimit(aCrewIdList.length);
			this.setProperty("searchHelpCrewId", "/SearchHelpCrewId", aCrewIdList);
			this.hideBusyIndicator();
		},
		handleValueHelpProjCode: function (oEvent) {
			this.selectedValueHelp = oEvent.getSource();
			var oModel = new sap.ui.model.json.JSONModel();
			var asearchHelpProjCode = this.getProperty("searchHelpProjCode", "/SearchHelpProjCode");
			oModel.setData(asearchHelpProjCode);
			var oButton = oEvent.getSource();
			if (!this._ProjCodeDialog) {
				this._ProjCodeDialog = Fragment.load({
					id: that.getView().getId(),
					name: "mytime.ZMOB_MY_TIME_Redesign.view.fragments.ProjCode",
					controller: that
				}).then(function (oDialog) {
					oDialog.setModel(oModel);
					return oDialog;
				});

			}
			this._ProjCodeDialog.then(function (oDialog) {
				that._configSearchHelp(oButton, oDialog);
				oDialog.open();
			}.bind(this));
		},
		handleProjCodeSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Crewid", FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handleProjCodeValueHelpClose: function (oEvent) {
			var oSelectedItem1 = oEvent.getParameter("selectedItem");
			if (oSelectedItem1) {
				this.selectedValueHelp.setValue(oSelectedItem1.getTitle());
				var JobCodeTxt = oSelectedItem1.mAggregations.attributes[0].mProperties.text;
				this.byId("idJobCodeTxt").setText(JobCodeTxt);
			}
		},
		handleValueHelpCrewId: function (oEvent) {
			that.selectedValueHelp = oEvent.getSource();
			var oButton = oEvent.getSource();
			var oJobCode = this.byId("idPrj").getValue();
			if (oJobCode === "") {
				MessageToast.show("No Project Code Selected");
			} else {
				this.showBusyIndicator(4000, 1);
				var mParameters = {};
				var oCrewIdModel = this.getOwnerComponent().getModel("TIME7012");
				mParameters.filters = [new sap.ui.model.Filter({
					path: "JobCode",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oJobCode
				})];
				mParameters.success = function (oData, response) {
					var data = oData;
					that.getModel("searchHelpCrewId").setSizeLimit(data.length);
					that.setProperty("searchHelpCrewId", "/SearchHelpCrewId", data);
					var oModel = new sap.ui.model.json.JSONModel();
					var asearchHelpCrewId = that.getProperty("searchHelpCrewId", "/SearchHelpCrewId");
					oModel.setData(asearchHelpCrewId);
					//var oButton = oEvent.getSource();
					if (!that._CrewIdDialog) {
						that._CrewIdDialog = Fragment.load({
							id: that.getView().getId(),
							name: "mytime.ZMOB_MY_TIME_Redesign.view.fragments.CrewId",
							controller: that
						}).then(function (oDialog) {
							oDialog.setModel(oModel);
							return oDialog;
						});

					}
					that._CrewIdDialog.then(function (oDialog) {
						that._configSearchHelp(oButton, oDialog);
						oDialog.setModel(oModel);
						oDialog.open();
					}.bind(that));
				};
				mParameters.error = function (oError) {
					var errorDetails = that.parseError(oError.responseText);
					var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.error(errorDetails, {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					});
				};
				oCrewIdModel.read("/SearchHelpCrewIdSet", mParameters);
				this.hideBusyIndicator();
			}
		},
		handleCrewIdValueHelpClose: function (oEvent) {
			var oSelectedItem1 = oEvent.getParameter("selectedItem");
			if (oSelectedItem1) {
				this.selectedValueHelp.setValue(oSelectedItem1.getTitle());
				var Des = oSelectedItem1.mAggregations.attributes[0].mProperties.text;
				this.byId("idCrewDes").setText(Des);
			}
		},
		handleCrewIdSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Crewid", FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		_configSearchHelp: function (oButton, oDialog) {
			// Multi-select if required
			var bMultiSelect = !!oButton.data("multi");
			oDialog.setMultiSelect(bMultiSelect);

			var sCustomConfirmButtonText = oButton.data("confirmButtonText");
			oDialog.setConfirmButtonText(sCustomConfirmButtonText);

			// Remember selections if required
			var bRemember = !!oButton.data("remember");
			oDialog.setRememberSelections(bRemember);

			//add Clear button if needed
			var bShowClearButton = !!oButton.data("showClearButton");
			oDialog.setShowClearButton(bShowClearButton);

			// Set growing property
			var bGrowing = oButton.data("growing");
			oDialog.setGrowing(bGrowing == "true");

			// Set growing threshold
			var sGrowingThreshold = oButton.data("threshold");
			if (sGrowingThreshold) {
				oDialog.setGrowingThreshold(parseInt(sGrowingThreshold));
			}

			// Set draggable property
			var bDraggable = !!oButton.data("draggable");
			oDialog.setDraggable(bDraggable);

			// Set draggable property
			var bResizable = !!oButton.data("resizable");
			oDialog.setResizable(bResizable);

			// Set style classes
			var sResponsiveStyleClasses =
				"sapUiResponsivePadding--header sapUiResponsivePadding--subHeader sapUiResponsivePadding--content sapUiResponsivePadding--footer";
			var bResponsivePadding = !!oButton.data("responsivePadding");
			oDialog.toggleStyleClass(sResponsiveStyleClasses, bResponsivePadding);

			// clear the old search filter
			oDialog.getBinding("items").filter([]);

		},
		onTimeRecordingPress: function (oEvent) {
			//   Code Added for Crew List Retro in Time Admin Start Here - SAPC-5402
			this.getView().byId("idTableRetro1").setVisible(false);
			this.getView().byId("idCrewListRetro1").setVisible(false);
			this.getView().byId("idCrewList").setVisible(false);
			//   Code Added for Crew List Retro in Time Admin Start Here - SAPC-5402
			var bReplace = "";
			var oJobCode = this.byId("idPrj").getValue();
			var oCrewId = this.byId("idCrewId").getValue();
			var oEffectiveDate = this.byId("idDate1").getValue();

			if (oJobCode === undefined || oJobCode === "") {
				MessageBox.error("Select Project Code");
				return;
			}
			if (oCrewId === undefined || oCrewId === "") {
				MessageBox.error("Select Crew Id");
				return;
			}
			if (oEffectiveDate === undefined || oEffectiveDate === "") {
				MessageBox.error("Select Effective Date");
				return;
			}
			var oViewModel = new JSONModel({
				busy: true,
				delay: 0
			});
			this.setModel(oViewModel, "appView");
			oViewModel.setProperty("/applicationId", "E");
			this.getOwnerComponent().getModel("app").setProperty("/applicationId", "E");
			this.getOwnerComponent().getComponentData().startupParameters['TA'][0] = "";
			this.getRouter().navTo("CrewEmpList", {
					"JobCode": oJobCode,
					"CrewId": oCrewId,
					"EffectiveDate": oEffectiveDate
				},
				bReplace);
		},
		onTimeApprovalPress: function (oEvent) {
			var bReplace = "";

			var oJobCode = this.byId("idPrj").getValue();
			var oCrewId = this.byId("idCrewId").getValue();
			var oEffectiveDate = this.byId("idDate1").getValue();
			if (oJobCode === undefined || oJobCode === "") {
				MessageBox.error("Select Project Code");
				return;
			}
			if (oCrewId === undefined || oCrewId === "") {
				MessageBox.error("Select Crew Id");
				return;
			}
			if (oEffectiveDate === undefined || oEffectiveDate === "") {
				MessageBox.error("Select Effective Date");
				return;
			}

			var oViewModel = new JSONModel({
				busy: true,
				delay: 0
			});
			this.setModel(oViewModel, "appView");
			oViewModel.setProperty("/applicationId", "A");
			this.getOwnerComponent().getModel("app").setProperty("/applicationId", "A");
			this.getOwnerComponent().getComponentData().startupParameters['TA'][0] = 'X';

			//   Code COmmented for Crew List Retro in Time Admin Start Here - SAPC-5402
			// this.getRouter().navTo("CrewEmpList", {
			// 		"JobCode": oJobCode,
			// 		"CrewId": oCrewId,
			// 		"EffectiveDate": oEffectiveDate
			// 	},
			// 	bReplace);
			//   Code Commented for Crew List Retro in Time Admin Start Here - SAPC-5402

			//   Code Added for Crew List Retro in Time Admin Start Here - SAPC-5402
			this.applicationId = this._getApplicationId();
			if (this.applicationId === "A") {
				this._initializeCrewList1DataServiceModels();
				this._initializeCrewListRetro1DataServiceModels();
				this.getView().byId("idCrewList").setVisible(true);

				// if (this.sCrewListRetro.length === undefined || this.sCrewListRetro.length === 0) {
				// 	this.getView().byId("idTableRetro1").setVisible(false);
				// 	this.getView().byId("idCrewListRetro1").setVisible(false);

				// } else {
				// 	this.getView().byId("idTableRetro1").setVisible(true);
				// 	this.getView().byId("idCrewListRetro1").setVisible(true);
				// }

			} else {
				this.getView().byId("idTableRetro1").setVisible(false);
				this.getView().byId("idCrewListRetro1").setVisible(false);
				this.getView().byId("idCrewList").setVisible(false);
			}
			//   Code Added for Crew List Retro in Time Admin End Here - SAPC-5402
		},
		onClear: function (oEvent) {
			this.byId("idPrj").setValue("");
			this.byId("idCrewId").setValue("");
			this.byId("idDate1").setValue("");
			this.byId("idCrewDes").setText("");
			this.byId("idJobCodeTxt").setText("");
			//   Code Added for Crew List Retro in Time Admin Start Here - SAPC-5402
			this.getView().byId("idTableRetro1").setVisible(false);
			this.getView().byId("idCrewListRetro1").setVisible(false);
			this.getView().byId("idCrewList").setVisible(false);
			//   Code Added for Crew List Retro in Time Admin End Here - SAPC-5402
		},
		//   Code Added for Time Admin End Here
		hideBusyIndicator: function () {
			sap.ui.core.BusyIndicator.hide();
		},
		showBusyIndicator: function (iDuration, iDelay) {
			sap.ui.core.BusyIndicator.show(iDelay);
			if (iDuration && iDuration > 0) {
				if (this._sTimeoutId) {
					jQuery.sap.clearDelayedCall(this._sTimeoutId);
					this._sTimeoutId = null;
				}
				this._sTimeoutId = jQuery.sap.delayedCall(iDuration, this, function () {
					this.hideBusyIndicator();
				});
			}
		},

		submitInputHelp: function (e) {
			var sid = e.getParameter("id");
			var recordFound = this._validateInput(e.getParameter("newValue"), sid);

			if (recordFound <= -1) {
				this.byId(sid).setValueState("Error");
				this.byId(sid).setValueStateText("Select a valid project");
				return;

			} else {
				this.byId(sid).setValueState("None");
			}

		},

		_validateInput: function (value, sid) {

			var jsonData = "";
			var s;
			var a = this;
			var isError = true;

			var rowExistsIndex = -2;
			if (sid.indexOf("idPrj") >= 0) {
				s = this.getProperty("searchHelpProjCode", "/SearchHelpProjCode");
				if (s !== undefined) {
					jsonData = s.results;
					rowExistsIndex = this._findExistingHelpInput(value, jsonData);
				}
			} else if (sid.indexOf("idCrewId") >= 0) {
				s = that.getProperty("searchHelpCrewId", "/SearchHelpCrewId");
				if (s !== undefined) {
					jsonData = s.results;
					rowExistsIndex = this._findExistingHelpInput1(value, jsonData);
				}
			}

			if (rowExistsIndex > -1) {
				if (sid.indexOf("idPrj") >= 0) {
					this.byId("idJobCodeTxt").setText(jsonData[rowExistsIndex]);
				} else if (sid.indexOf("idCrewId") >= 0) {
					this.byId("idCrewDes").setText(jsonData[rowExistsIndex]);
				}
			} else {
				if (sid.indexOf("idPrj") >= 0) {
					this.byId("idJobCodeTxt").setText("");
				} else if (sid.indexOf("idCrewId") >= 0) {
					this.byId("idCrewDes").setText("");
				}
			}

			if (value === "") {
				return 0; // No data so no need to show any error
			}
			return rowExistsIndex;
		},

		_findExistingHelpInput: function (oRow, oTableRows) {
			let index = oTableRows.findIndex(
				row => row.JobCode === oRow
			);
			return index;
		},

		_findExistingHelpInput1: function (oRow, oTableRows) {
			let index = oTableRows.findIndex(
				row => row.Crewid === oRow
			);
			return index;
		},
		parseError: function (oError) {
			var messageText;
			try {
				// Try to parse as a JSON string
				messageText = JSON.parse(oError);
				messageText = messageText.error.code + ": " + messageText.error.message.value; // + "\n" + "Please contact Administrator.";	SAP-8326						
			} catch (err) {
				try {
					switch (typeof oError) {
					case "string": // XML or simple text
						if (oError.indexOf("<?xml") === 0) {
							var oXML = jQuery.parseXML(oError);
							var oXMLMsg = oXML.querySelector("message");
							if (oXMLMsg) {
								messageText = oXMLMsg.textContent;
							}
						} else {
							messageText = oError;
						}
						break;
					case "object": // Exception
						messageText = oError.toString();
						break;
					}
				} catch (err) {
					messageText = "An unknown error occurred!! Please contact Administrator !!";
				}
			}
			return messageText.replace("/IWBEP/CM_MGW_RT/022: ", "");
		}

	});
});