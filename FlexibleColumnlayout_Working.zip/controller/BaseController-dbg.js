sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function (Controller, History) {
	"use strict";
	return Controller.extend("mytime.ZMOB_MY_TIME_Redesign.controller.BaseController", {
		/**
		 * Convenience method for accessing the router.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		/**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function (sName) {
			return this.getView().getModel(sName);
		},

		setData: function (M, d) {
			return this.getView().getModel(M).setData(d);
		},
		/**
		 * Convenience method for setting the view model.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Getter for the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},
		setProperty: function (M, p, n) {
			return this.getView().getModel(M).setProperty(p, n);
		},
		getProperty: function (M, p) {
			return this.getView().getModel(M).getProperty(p);
		},

		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */

		onNavBack: function (oEvent) {
			var oHistory, sPreviousHash;
			oHistory = History.getInstance();
			//var A = sap.ushell.Container.getService("CrossApplicationNavigati on");
			sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getRouter().navTo("appHome", {}, true /*no history*/ );
				//A.toExternal({ target: { shellHash: "#" } });
			}
		},
		parseError: function (oError) {
			var messageText;
			try {
				messageText = JSON.parse(oError);
				messageText = messageText.error.code + ": " + messageText.error.message.value;
			} catch (err) {
				try {
					switch (typeof oError) {
					case "string":
						if (oError.indexOf("<?xml") === 0) {
							var oXML = jQuery.parseXML(oError);
							var oXMLMsg = oXML.querySelector("message");
							if (oXMLMsg) {
								messageText = oXMLMsg.textContent;
							}
						} else {
							messageText = oError;
						}
						break;
					case "object":
						messageText = oError.toString();
						break;
					}
				} catch (oEvent) {
					messageText = this.getText("errorTextADM");
				}
			}
			return messageText.replace("/IWBEP/CM_MGW_RT/022: ", "");
		}

	});

});