sap.ui.define(["mytime/ZMOB_MY_TIME_Redesign/controller/BaseController", "sap/ui/model/json/JSONModel",
	"mytime/ZMOB_MY_TIME_Redesign/js/Utilities", "sap/m/MessageBox", "sap/m/MessageToast", "mytime/ZMOB_MY_TIME_Redesign/js/formatter",
	"sap/ui/core/Fragment", "sap/ui/model/Filter", "sap/ui/model/FilterOperator"
], function (e, t, i, r, s, a, o, n, d) {
	"use strict";
	var l;
	return e.extend("mytime.ZMOB_MY_TIME_Redesign.controller.CrewList", {
		formatter: a,
		onInit: function () {
			l = this;
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oComponent = this.getOwnerComponent();
			this.sCrewList = [];
			this.sCrewListRetro = [];
			this.EffectiveDate = "";
			this.applicationId = this._getApplicationId();
			this.timeadminId = this._getTimeAdminId();
			this.isDateChanged = false;
			this._handleRouting()
		},
		_handleRouting: function () {
			if (this.timeadminId === "TA") {
				this.getOwnerComponent().getService("ShellUIService").then(function (e) {
					e.setTitle("Time Admin")
				});
				this.getView().byId("idTableRetro1").setVisible(false);
				this.getView().byId("idCrewListRetro1").setVisible(false);
				this.getView().byId("idCrewList").setVisible(false);
				this.getView().byId("idPageHeader").setVisible(false);
				this.getView().setModel(new t, "searchHelpProjCode");
				this.getView().setModel(new t, "searchHelpCrewId");
				this._initializeSearchHelpProjCode();
				this.getRouter().attachRouteMatched(function (e) {
					var t = e.getParameter("name");
					if ((t === "CrewList" || t === "CrewTime" || t === "CrewEmpList") && (this.sCrewList.length === undefined || this.sCrewList.length ===
							0)) {
						if (e.getParameter("arguments").JobCode !== undefined && e.getParameter("arguments").JobCode !== "") {
							this.byId("idPrj").setValue(e.getParameter("arguments").JobCode)
						}
						if (e.getParameter("arguments").CrewId !== undefined && e.getParameter("arguments").CrewId !== "") {
							this.byId("idCrewId").setValue(e.getParameter("arguments").CrewId)
						}
						if (e.getParameter("arguments").EffectiveDate !== undefined && e.getParameter("arguments").EffectiveDate !== "") {
							this.byId("idDate1").setValue(e.getParameter("arguments").EffectiveDate)
						}
					}
				}, this)
			} else {
				this.getRouter().attachRouteMatched(function (e) {
					var t = e.getParameter("name");
					this.EffectiveDate = e.getParameter("arguments").EffectiveDate;
					if ((t === "CrewList" || t === "CrewTime" || t === "CrewEmpList") && (this.sCrewList.length === undefined || this.sCrewList.length ===
							0)) {
						this._initializeCrewListDataServiceModels()
					}
				}, this);
				if (this.applicationId === "A") {
					this._initializeCrewListRetroDataServiceModels()
				} else {
					this.getView().byId("idTableRetro").setVisible(false);
					this.getView().byId("idCrewListRetro").setVisible(false);
					this.getView().byId("idTableRetro1").setVisible(false);
					this.getView().byId("idCrewListRetro1").setVisible(false)
				}
			}
		},
		onTableLoadFinished: function (e) {
			this.sCrewList = this.getView().byId("idTable").getItems();
			if (this.getView().getModel("app").getProperty("/layout") !== "OneColumn") {
				if (this.isDateChanged === true) {
					this.isDateChanged = false;
					var t = this.getView().byId("idTable").getItems();
					if (t !== undefined) {
						this.getView().byId("idTable").setSelectedItem(this.getView().byId("idTable").getItems()[0]);
						this.getView().byId("idTable").getItems()[0].firePress()
					}
				}
			} else {
				this.isDateChanged = false
			}
			this.hideBusyIndicator()
		},
		onTableRetroLoadFinished: function (e) {
			this.sCrewListRetro = this.getView().byId("idTableRetro").getItems();
			if (this.sCrewListRetro.length === undefined || this.sCrewListRetro.length === 0) {
				this.getView().byId("idTableRetro").setVisible(false);
				this.getView().byId("idCrewListRetro").setVisible(false)
			} else {
				this.getView().byId("idTableRetro").setVisible(true);
				this.getView().byId("idCrewListRetro").setVisible(true)
			}
		},
		onRetroTableLoadFinished: function (e) {
			this.sCrewListRetro = this.getView().byId("idTableRetro1").getItems();
			if (this.sCrewListRetro.length === undefined || this.sCrewListRetro.length === 0) {
				this.getView().byId("idTableRetro1").setVisible(false);
				this.getView().byId("idCrewListRetro1").setVisible(false)
			} else {
				this.getView().byId("idTableRetro1").setVisible(true);
				this.getView().byId("idCrewListRetro1").setVisible(true)
			}
		},
		_getApplicationId: function () {
			var e = this.getOwnerComponent().getModel("app").getProperty("/applicationId");
			if (e === undefined || e === "" || e !== "A" && e !== "TA") {
				return "E"
			} else {
				return e
			}
		},
		_getTimeAdminId: function () {
			var e = this.getOwnerComponent().getModel("app").getProperty("/timeadminId");
			if (e !== undefined && e !== "" && e === "TA") {
				return "TA"
			} else {
				e = "";
				return e
			}
		},
		_initializeCrewListDataServiceModels: function () {
			var e = new Date;
			var t = e.getMonth() + 1;
			var i = e.getDate();
			t = t < 10 ? "0" + t : t;
			i = i < 10 ? "0" + i : i;
			var s = e.getFullYear() + "" + t + "" + i;
			if (this.EffectiveDate !== undefined && this.EffectiveDate !== null && this.EffectiveDate !== "") {
				s = this.EffectiveDate
			}
			this.byId("idDate").setValue(s);
			var a = this;
			var o = this.getView().byId("idTable");
			var n = o.getBinding("items");
			this.getView().getModel().attachRequestFailed(function (e) {
				var t = a.parseError(e.getParameter("response").responseText);
				var i = !!a.getView().$().closest(".sapUiSizeCompact").length;
				r.error(t, {
					styleClass: i ? "sapUiSizeCompact" : ""
				})
			});
			var d = [];
			var l = new sap.ui.model.Filter("EffectiveDate", sap.ui.model.FilterOperator.EQ, s);
			d.push(l);
			l = new sap.ui.model.Filter("ApplicationId", sap.ui.model.FilterOperator.EQ, this.applicationId);
			d.push(l);
			n.aFilters = null;
			n.filter(d)
		},
		_initializeCrewListData: function () {
			this.setData("CrewList", {
				selection: {
					Action: "",
					Usrid: "",
					JobCode: "",
					CrewId: "",
					Option: "",
					Description: "",
					EffectiveDate: new Date,
					Shift: "",
					ShiftDescription: "",
					FmName: "",
					FmWerks: "",
					StatusTx: "",
					CrewEffectiveDate: new Date
				},
				CrewListSet: []
			});
			this.showBusyIndicator(4e3, 1);
			this.oComponent.getDataProvider().loadCrewList(this)
		},
		onCrewListLoad: function (e) {
			this.getModel("CrewList").setSizeLimit(e.length);
			this.setProperty("CrewList", "/CrewListSet", e);
			this.sCrewList = e;
			this.hideBusyIndicator()
		},
		onCrewListError: function (e) {
			var t = this.parseError(e.responseText);
			var i = !!this.getView().$().closest(".sapUiSizeCompact").length;
			r.error(t, {
				styleClass: i ? "sapUiSizeCompact" : ""
			})
		},
		_initializeCrewListRetroDataServiceModels: function () {
			var e = new Date;
			var t = e.getMonth() + 1;
			var i = e.getDate();
			t = t < 10 ? "0" + t : t;
			i = i < 10 ? "0" + i : i;
			var s = e.getFullYear() + "" + t + "" + i;
			var a = this.getOwnerComponent().getModel();
			var o = {};
			o.filters = [new sap.ui.model.Filter({
				path: "EffectiveDate",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: s
			}), new sap.ui.model.Filter({
				path: "ApplicationId",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: "A"
			})];
			o.success = function (e, t) {
				var i = this;
				var a = l.getView().byId("idTableRetro");
				var o = a.getBinding("items");
				l.getView().getModel().attachRequestFailed(function (e) {
					var t = i.parseError(e.getParameter("response").responseText);
					var s = !!i.getView().$().closest(".sapUiSizeCompact").length;
					r.error(t, {
						styleClass: s ? "sapUiSizeCompact" : ""
					})
				});
				var n = [];
				var d = new sap.ui.model.Filter("EffectiveDate", sap.ui.model.FilterOperator.LT, s);
				n.push(d);
				d = new sap.ui.model.Filter("ApplicationId", sap.ui.model.FilterOperator.EQ, "A");
				n.push(d);
				o.aFilters = null;
				o.filter(n)
			};
			a.read("/CrewListRetroSet", o)
		},
		_initializeCrewList1DataServiceModels: function () {
			var e = this.byId("idPrj").getValue();
			var t = this.byId("idCrewId").getValue();
			var i = this.byId("idDate1").getValue();
			var s = this;
			var a = this.getView().byId("idCrewList");
			var o = a.getBinding("items");
			this.getView().getModel().attachRequestFailed(function (e) {
				var t = s.parseError(e.getParameter("response").responseText);
				var i = !!s.getView().$().closest(".sapUiSizeCompact").length;
				r.error(t, {
					styleClass: i ? "sapUiSizeCompact" : ""
				})
			});
			var n = [];
			var d = new sap.ui.model.Filter("EffectiveDate", sap.ui.model.FilterOperator.EQ, i);
			n.push(d);
			d = new sap.ui.model.Filter("ApplicationId", sap.ui.model.FilterOperator.EQ, this.applicationId);
			n.push(d);
			d = new sap.ui.model.Filter("JobCode", sap.ui.model.FilterOperator.EQ, e);
			n.push(d);
			d = new sap.ui.model.Filter("CrewId", sap.ui.model.FilterOperator.EQ, t);
			n.push(d);
			o.aFilters = null;
			o.filter(n)
		},
		_initializeCrewListRetro1DataServiceModels: function () {
			var e = this.byId("idPrj").getValue();
			var t = this.byId("idCrewId").getValue();
			var i = this.byId("idDate1").getValue();
			var s = this;
			var a = l.getView().byId("idTableRetro1");
			var o = a.getBinding("items");
			l.getView().getModel().attachRequestFailed(function (e) {
				var t = s.parseError(e.getParameter("response").responseText);
				var i = !!s.getView().$().closest(".sapUiSizeCompact").length;
				r.error(t, {
					styleClass: i ? "sapUiSizeCompact" : ""
				})
			});
			var n = [];
			var d = new sap.ui.model.Filter("EffectiveDate", sap.ui.model.FilterOperator.LT, i);
			n.push(d);
			d = new sap.ui.model.Filter("ApplicationId", sap.ui.model.FilterOperator.EQ, "A");
			n.push(d);
			d = new sap.ui.model.Filter("JobCode", sap.ui.model.FilterOperator.EQ, e);
			n.push(d);
			d = new sap.ui.model.Filter("CrewId", sap.ui.model.FilterOperator.EQ, t);
			n.push(d);
			o.aFilters = null;
			o.filter(n);
			this.sCrewListRetro = this.getView().byId("idTableRetro1").getItems()
		},
		onRetroTimesheet: function (e) {
			var t = "";
			var i = e.getParameter("listItem");
			var r;
			var s;
			if (i === undefined || i === null) {
				r = e.getSource().getBindingContextPath();
				s = e.getSource().getBindingContext().getObject()
			} else {
				r = i.getBindingContextPath();
				s = i.getBindingContext().getObject()
			}
			this.getRouter().navTo("CrewEmpList", {
				JobCode: s.JobCode,
				CrewId: s.CrewId,
				EffectiveDate: s.EffectiveDate
			}, t)
		},
		onTimesheet: function (e) {
			var t = "";
			var i = e.getParameter("listItem");
			var r;
			var a;
			if (i === undefined || i === null) {
				r = e.getSource().getBindingContextPath();
				a = e.getSource().getBindingContext().getObject()
			} else {
				r = i.getBindingContextPath();
				a = i.getBindingContext().getObject()
			}
			if (a.Status !== "20" && a.Status !== "30" && this.applicationId === "A") {
				var o = this.getView().getModel("i18n").getResourceBundle().getText("M.NOTREADYAPPROVAL");
				s.show(o, {
					duration: 5e3,
					width: "15em",
					my: "center bottom",
					at: "center bottom",
					of: window,
					offset: "0 0",
					collision: "fit fit",
					onClose: null,
					autoClose: true,
					animationTimingFunction: "ease",
					animationDuration: 2e3,
					closeOnBrowserNavigation: true
				})
			}
			this.getRouter().navTo("CrewEmpList", {
				JobCode: a.JobCode,
				CrewId: a.CrewId,
				EffectiveDate: a.EffectiveDate
			}, t)
		},
		onDateChange: function (e) {
			this.isDateChanged = true;
			var t = e.getParameter("value");
			this.showBusyIndicator(4e3, 1);
			this.getView().byId("idTable").removeSelections();
			var i = this.getView().byId("idTable");
			var r = i.getBinding("items");
			var s = [];
			var a = new sap.ui.model.Filter("EffectiveDate", sap.ui.model.FilterOperator.EQ, t);
			s.push(a);
			a = new sap.ui.model.Filter("ApplicationId", sap.ui.model.FilterOperator.EQ, this.applicationId);
			s.push(a);
			r.aFilters = null;
			r.filter(s);
			if (this.applicationId === "A") {
				this.getView().byId("idTableRetro").removeSelections();
				var o = this.getView().byId("idTableRetro");
				var n = o.getBinding("items");
				var d = [];
				var l = new sap.ui.model.Filter("EffectiveDate", sap.ui.model.FilterOperator.LT, t);
				d.push(l);
				l = new sap.ui.model.Filter("ApplicationId", sap.ui.model.FilterOperator.EQ, this.applicationId);
				d.push(l);
				n.aFilters1 = null;
				n.filter(d)
			}
		},
		onCrewListLoadbyDate: function (e) {
			this.getModel("CrewList").setSizeLimit(e.length);
			this.setProperty("CrewList", "/CrewListSet", "");
			this.setProperty("CrewList", "/CrewListSet", e);
			this.sCrewList = e;
			this.hideBusyIndicator()
		},
		_initializeSearchHelpCrewId: function (e) {
			this.setData("searchHelpCrewId", {
				selection: {
					JobCode: "",
					CrewId: "",
					CrewDes: "",
					EffectiveDate: ""
				},
				SearchHelpCrewId: []
			});
			this.oComponent.getDataProvider().loadSearchHelpCrewId(this, e)
		},
		_initializeSearchHelpProjCode: function () {
			var e = new Date;
			var t = e.getMonth() + 1;
			var i = e.getDate();
			t = t < 10 ? "0" + t : t;
			i = i < 10 ? "0" + i : i;
			var r = e.getFullYear() + "" + t + "" + i;
			this.byId("idDate1").setValue(r);
			l.setData("searchHelpProjCode", {
				selection: {
					Role: "",
					JobCode: "",
					EffectiveDate: ""
				},
				SearchHelpProjCode: []
			});
			l.oComponent.getDataProvider().loadSearchHelpProjCode(this)
		},
		onSearchHelpProjCodeLoad: function (e) {
			this.getModel("searchHelpProjCode").setSizeLimit(e.length);
			this.setProperty("searchHelpProjCode", "/SearchHelpProjCode", e);
			this.hideBusyIndicator()
		},
		onSearchHelpCrewIdLoad: function (e) {
			this.getModel("searchHelpCrewId").setSizeLimit(e.length);
			this.setProperty("searchHelpCrewId", "/SearchHelpCrewId", e);
			this.hideBusyIndicator()
		},
		handleValueHelpProjCode: function (e) {
			this.selectedValueHelp = e.getSource();
			var t = new sap.ui.model.json.JSONModel;
			var i = this.getProperty("searchHelpProjCode", "/SearchHelpProjCode");
			t.setData(i);
			var r = e.getSource();
			if (!this._ProjCodeDialog) {
				this._ProjCodeDialog = o.load({
					id: l.getView().getId(),
					name: "mytime.ZMOB_MY_TIME_Redesign.view.fragments.ProjCode",
					controller: l
				}).then(function (e) {
					e.setModel(t);
					return e
				})
			}
			this._ProjCodeDialog.then(function (e) {
				l._configSearchHelp(r, e);
				e.open()
			}.bind(this))
		},
		handleProjCodeSearch: function (e) {
			var t = e.getParameter("value");
			var i = new n("Crewid", d.Contains, t);
			var r = e.getSource().getBinding("items");
			r.filter([i])
		},
		handleProjCodeValueHelpClose: function (e) {
			var t = e.getParameter("selectedItem");
			if (t) {
				this.selectedValueHelp.setValue(t.getTitle());
				var i = t.mAggregations.attributes[0].mProperties.text;
				this.byId("idJobCodeTxt").setText(i)
			}
		},
		handleValueHelpCrewId: function (e) {
			l.selectedValueHelp = e.getSource();
			var t = e.getSource();
			var i = this.byId("idPrj").getValue();
			if (i === "") {
				s.show("No Project Code Selected")
			} else {
				this.showBusyIndicator(4e3, 1);
				var a = {};
				var n = this.getOwnerComponent().getModel("TIME7012");
				a.filters = [new sap.ui.model.Filter({
					path: "JobCode",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: i
				})];
				a.success = function (e, i) {
					var r = e;
					l.getModel("searchHelpCrewId").setSizeLimit(r.length);
					l.setProperty("searchHelpCrewId", "/SearchHelpCrewId", r);
					var s = new sap.ui.model.json.JSONModel;
					var a = l.getProperty("searchHelpCrewId", "/SearchHelpCrewId");
					s.setData(a);
					if (!l._CrewIdDialog) {
						l._CrewIdDialog = o.load({
							id: l.getView().getId(),
							name: "mytime.ZMOB_MY_TIME_Redesign.view.fragments.CrewId",
							controller: l
						}).then(function (e) {
							e.setModel(s);
							return e
						})
					}
					l._CrewIdDialog.then(function (e) {
						l._configSearchHelp(t, e);
						e.setModel(s);
						e.open()
					}.bind(l))
				};
				a.error = function (e) {
					var t = l.parseError(e.responseText);
					var i = !!l.getView().$().closest(".sapUiSizeCompact").length;
					r.error(t, {
						styleClass: i ? "sapUiSizeCompact" : ""
					})
				};
				n.read("/SearchHelpCrewIdSet", a);
				this.hideBusyIndicator()
			}
		},
		handleCrewIdValueHelpClose: function (e) {
			var t = e.getParameter("selectedItem");
			if (t) {
				this.selectedValueHelp.setValue(t.getTitle());
				var i = t.mAggregations.attributes[0].mProperties.text;
				this.byId("idCrewDes").setText(i)
			}
		},
		handleCrewIdSearch: function (e) {
			var t = e.getParameter("value");
			var i = new n("Crewid", d.Contains, t);
			var r = e.getSource().getBinding("items");
			r.filter([i])
		},
		_configSearchHelp: function (e, t) {
			var i = !!e.data("multi");
			t.setMultiSelect(i);
			var r = e.data("confirmButtonText");
			t.setConfirmButtonText(r);
			var s = !!e.data("remember");
			t.setRememberSelections(s);
			var a = !!e.data("showClearButton");
			t.setShowClearButton(a);
			var o = e.data("growing");
			t.setGrowing(o == "true");
			var n = e.data("threshold");
			if (n) {
				t.setGrowingThreshold(parseInt(n))
			}
			var d = !!e.data("draggable");
			t.setDraggable(d);
			var l = !!e.data("resizable");
			t.setResizable(l);
			var h =
				"sapUiResponsivePadding--header sapUiResponsivePadding--subHeader sapUiResponsivePadding--content sapUiResponsivePadding--footer";
			var u = !!e.data("responsivePadding");
			t.toggleStyleClass(h, u);
			t.getBinding("items").filter([])
		},
		onTimeRecordingPress: function (e) {
			this.getView().byId("idTableRetro1").setVisible(false);
			this.getView().byId("idCrewListRetro1").setVisible(false);
			this.getView().byId("idCrewList").setVisible(false);
			var i = "";
			var s = this.byId("idPrj").getValue();
			var a = this.byId("idCrewId").getValue();
			var o = this.byId("idDate1").getValue();
			if (s === undefined || s === "") {
				r.error("Select Project Code");
				return
			}
			if (a === undefined || a === "") {
				r.error("Select Crew Id");
				return
			}
			if (o === undefined || o === "") {
				r.error("Select Effective Date");
				return
			}
			var n = new t({
				busy: true,
				delay: 0
			});
			this.setModel(n, "appView");
			n.setProperty("/applicationId", "E");
			this.getOwnerComponent().getModel("app").setProperty("/applicationId", "E");
		//	this.getOwnerComponent().getComponentData().startupParameters["TA"][0] = "";
			this.getOwnerComponent().getComponentData().startupParameters.TA =[""];
			//Commented code to hide Crew Employee List View
			// this.getRouter().navTo("CrewEmpList", {
			// 	JobCode: s,
			// 	CrewId: a,
			// 	EffectiveDate: o
			// }, i)
				this.getRouter().navTo("CrewTime", {
				JobCode: s,
				CrewId: a,
				EffectiveDate: o,
				EmpBecref: "00000000"
			})
		},
		onTimeApprovalPress: function (e) {
			var i = "";
			var s = this.byId("idPrj").getValue();
			var a = this.byId("idCrewId").getValue();
			var o = this.byId("idDate1").getValue();
			if (s === undefined || s === "") {
				r.error("Select Project Code");
				return
			}
			if (a === undefined || a === "") {
				r.error("Select Crew Id");
				return
			}
			if (o === undefined || o === "") {
				r.error("Select Effective Date");
				return
			}
			var n = new t({
				busy: true,
				delay: 0
			});
			this.setModel(n, "appView");
			n.setProperty("/applicationId", "A");
			this.getOwnerComponent().getModel("app").setProperty("/applicationId", "A");
			this.getOwnerComponent().getComponentData().startupParameters["TA"][0] = "X";
			this.applicationId = this._getApplicationId();
			if (this.applicationId === "A") {
				this._initializeCrewList1DataServiceModels();
				this._initializeCrewListRetro1DataServiceModels();
				this.getView().byId("idCrewList").setVisible(true)
			} else {
				this.getView().byId("idTableRetro1").setVisible(false);
				this.getView().byId("idCrewListRetro1").setVisible(false);
				this.getView().byId("idCrewList").setVisible(false)
			}
		},
		onClear: function (e) {
			this.byId("idPrj").setValue("");
			this.byId("idCrewId").setValue("");
			this.byId("idDate1").setValue("");
			this.byId("idCrewDes").setText("");
			this.byId("idJobCodeTxt").setText("");
			this.getView().byId("idTableRetro1").setVisible(false);
			this.getView().byId("idCrewListRetro1").setVisible(false);
			this.getView().byId("idCrewList").setVisible(false)
		},
		hideBusyIndicator: function () {
			sap.ui.core.BusyIndicator.hide()
		},
		showBusyIndicator: function (e, t) {
			sap.ui.core.BusyIndicator.show(t);
			if (e && e > 0) {
				if (this._sTimeoutId) {
					jQuery.sap.clearDelayedCall(this._sTimeoutId);
					this._sTimeoutId = null
				}
				this._sTimeoutId = jQuery.sap.delayedCall(e, this, function () {
					this.hideBusyIndicator()
				})
			}
		},
		submitInputHelp: function (e) {
			var t = e.getParameter("id");
			var i = this._validateInput(e.getParameter("newValue"), t);
			if (i <= -1) {
				this.byId(t).setValueState("Error");
				this.byId(t).setValueStateText("Select a valid project");
				return
			} else {
				this.byId(t).setValueState("None")
			}
		},
		_validateInput: function (e, t) {
			var i = "";
			var r;
			var s = this;
			var a = true;
			var o = -2;
			if (t.indexOf("idPrj") >= 0) {
				r = this.getProperty("searchHelpProjCode", "/SearchHelpProjCode");
				if (r !== undefined) {
					i = r.results;
					o = this._findExistingHelpInput(e, i)
				}
			} else if (t.indexOf("idCrewId") >= 0) {
				r = l.getProperty("searchHelpCrewId", "/SearchHelpCrewId");
				if (r !== undefined) {
					i = r.results;
					o = this._findExistingHelpInput1(e, i)
				}
			}
			if (o > -1) {
				if (t.indexOf("idPrj") >= 0) {
					this.byId("idJobCodeTxt").setText(i[o])
				} else if (t.indexOf("idCrewId") >= 0) {
					this.byId("idCrewDes").setText(i[o])
				}
			} else {
				if (t.indexOf("idPrj") >= 0) {
					this.byId("idJobCodeTxt").setText("")
				} else if (t.indexOf("idCrewId") >= 0) {
					this.byId("idCrewDes").setText("")
				}
			}
			if (e === "") {
				return 0
			}
			return o
		},
		_findExistingHelpInput: function (e, t) {
			let i = t.findIndex(t => t.JobCode === e);
			return i
		},
		_findExistingHelpInput1: function (e, t) {
			let i = t.findIndex(t => t.Crewid === e);
			return i
		},
		parseError: function (e) {
			var t;
			try {
				t = JSON.parse(e);
				t = t.error.code + ": " + t.error.message.value
			} catch (s) {
				try {
					switch (typeof e) {
					case "string":
						if (e.indexOf("<?xml") === 0) {
							var i = jQuery.parseXML(e);
							var r = i.querySelector("message");
							if (r) {
								t = r.textContent
							}
						} else {
							t = e
						}
						break;
					case "object":
						t = e.toString();
						break
					}
				} catch (e) {
					t = "An unknown error occurred!! Please contact Administrator !!"
				}
			}
			return t.replace("/IWBEP/CM_MGW_RT/022: ", "")
		}
	})
});