sap.ui.define(["mytime/ZMOB_MY_TIME_Redesign/controller/BaseController", "sap/ui/model/json/JSONModel", "sap/m/MessageBox",
	"sap/ui/core/Fragment", "sap/m/MessageToast", "sap/ui/core/syncStyleClass", "mytime/ZMOB_MY_TIME_Redesign/js/formatter",
	"mytime/ZMOB_MY_TIME_Redesign/js/Utilities", "sap/m/Dialog", "sap/m/Button", "sap/m/library", "sap/m/List", "sap/m/StandardListItem",
	"sap/m/Text", "sap/m/Label", "sap/ui/model/FilterOperator", "sap/ui/model/Filter"
], function (e, t, s, o, r, i, a, n, l, d, u, p, c, g, m, h, C) {
	"use strict";
	var f;
	var T;
	var w;
	return e.extend("mytime.ZMOB_MY_TIME_Redesign.controller.CrewTime", {
		formatter: a,
		onInit: function () {
			f = this;
			this.isReadOnly = true;
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oComponent = this.getOwnerComponent();
			this.applicationId = this._getApplicationId();
			this._handleRouting();
			this.sCrew = {};
			this.timeTypeCategory = [];
			this.timeTypeDescription = [];
			this.deletedRows = [];
			this.oEmployees = [];
			this.countryCode = 13;
			this.hoursRule = "0000"
		},
		_handleRouting: function () {
			var e = this;
			this.getRouter().attachRouteMatched(function (e) {
				var t = e.getParameter("name");
				this.applicationId = this._getApplicationId();
				if (t === "CrewTime") {
					this.sCrew.JobCode = e.getParameter("arguments").JobCode;
					this.sCrew.CrewId = e.getParameter("arguments").CrewId;
					this.sCrew.EffectiveDate = e.getParameter("arguments").EffectiveDate;
					this.sCrew.EmpBecref = e.getParameter("arguments").EmpBecref;
					this.byId("idDate").setValue(this.sCrew.EffectiveDate);
					this.getView().bindElement({
						path: "/CrewListSet(JobCode='" + this.sCrew.JobCode + "',CrewId='" + encodeURIComponent(this.sCrew.CrewId) +
							"',EffectiveDate='" + this.sCrew.EffectiveDate + "',ApplicationId='" + this.applicationId + "')",
						events: {
							change: function (e) {
								var t = f.sCrew.EmpBecref;
								f.sCrew = e.getSource().getBoundContext().getObject();
								f.sCrew.EmpBecref = t;
								f._initializeCrewTimeDataServiceModels(f.sCrew);
								f._updatePageSetting();
								f._updateCrewTimeAdminRole()
							},
							dataRequested: function () {
								var e = 1
							},
							dataReceived: function (e) {
								var t = f.sCrew.EmpBecref;
								f.sCrew = e.getSource().getBoundContext().getObject();
								f.sCrew.EmpBecref = t;
								f._updatePageSetting();
								f._updateCrewTimeAdminRole()
							}
						}
					});
					try {
						var s = f.sCrew.EmpBecref;
						this.sCrew = this.getView().getElementBinding().getBoundContext().getObject();
						f.sCrew.EmpBecref = s;
						this._initializeCrewTimeDataServiceModels(this.sCrew);
						this._updatePageSetting();
						this._updateCrewTimeAdminRole()
					} catch (e) {}
				}
			}, this)
		},
		_updatePageSetting: function () {
			var e = this.getView().getModel("app");
			if (this.sCrew.EmpBecref === "00000000") {
				if (this.applicationId === "A") {
					this.isReadOnly = true;
					e.setProperty("/timePageReadOnly", true);
					if (this.sCrew.Status === "20") {
						e.setProperty("/approvalReady", true)
					} else {
						e.setProperty("/approvalReady", false)
					}
				} else {
					if (this.sCrew.IsEditable === false) {
						this.isReadOnly = true;
						e.setProperty("/timePageReadOnly", true);
						e.setProperty("/approvalReady", false)
					} else {
						this.isReadOnly = false;
						e.setProperty("/timePageReadOnly", false);
						e.setProperty("/approvalReady", false)
					}
				}
			} else {
				this.isReadOnly = true;
				e.setProperty("/timePageReadOnly", true);
				e.setProperty("/approvalReady", false)
			}
		},
		_updateCrewTimeAdminRole: function () {
			try {
				var e = this.getOwnerComponent().getComponentData().startupParameters["AD"][0];
				var t = this.getView().getModel("app");
				if (e === "Y" && this.sCrew.isTimeAdmin === "X") {
					t.setProperty("/isUserCrewTimeAdmin", true)
				}
			} catch (e) {}
		},
		_getApplicationId: function () {
			var e = "E";
			try {
				var t = this.getOwnerComponent().getComponentData().startupParameters["TA"][0];
				if (t === "X") {
					e = "A"
				}
			} catch (e) {}
			return e
		},
		_initializeCrewTimeDataServiceModels: function (e) {
			this.getView().setModel(new t, "Employees");
			this.getView().setModel(new t, "crewTimeRedesign");
			this.getView().setModel(new t, "timeTypes");
			this.getView().setModel(new t, "searchHelpTimeType");
			this._initializeSearchHelpTimeType(e);
			this.getView().setModel(new t, "crewTime");
			this._initializeCrewTimeData(e);
			this.getView().setModel(new t, "searchHelpClass");
			this._initializeSearchHelpClass(e);
			this._initializeSearchHelpCostCode(e);
			this._initializeSearchHelpUnassignedCostCode(e);
			this.getView().setModel(new t, "searchHelpActivity");
			this._initializeSearchHelpActivity(e)
		},
		_initializeCrewTimeData: function (e) {
			this.showBusyIndicator(4e3, 1);
			this.oComponent.getDataProvider().loadCrewTime(this, e)
		},
		_initializeSearchHelpClass: function (e) {
			this.setData("searchHelpClass", {
				selection: {
					Werks: "",
					Persg: "",
					Persk: "",
					Trfgr: "",
					Trfst: "",
					ClassDesc: ""
				},
				SearchHelpClass: []
			});
			this.oComponent.getDataProvider().loadSearchHelpClass(this, e.FmWerks)
		},
		_initializeSearchHelpCostCode: function (e) {
			this.oComponent.getDataProvider().loadSearchHelpCostCode(this, e)
		},
		_initializeSearchHelpUnassignedCostCode: function (e) {
			this.oComponent.getDataProvider().loadSearchHelpUnassignedCostCode(this, e)
		},
		_initializeSearchHelpActivity: function (e) {
			this.setData("searchHelpActivity", {
				selection: {
					JobCode: " ",
					Zzact: " ",
					EffectiveDate: " ",
					WorkpkgId: " ",
					WorkpkgDesc: " "
				},
				SearchHelpActivity: []
			});
			this.oComponent.getDataProvider().loadSearchHelpActivity(this, e.EffectiveDate, e.JobCode)
		},
		_initializeSearchHelpTimeType: function (e) {
			this.setData("searchHelpTimeType", {
				selection: {
					JobCode: " ",
					CrewId: " ",
					EffectiveDate: " ",
					TimeType: " ",
					TimeTypeTx: " "
				},
				SearchHelpActivity: []
			});
			this.oComponent.getDataProvider().loadSearchHelpTimeType(this, e)
		},
		onDateChange: function (e) {
			var t = e.getParameter("value");
			w = e.getParameter("value");
			this.showBusyIndicator(4e3, 1);
			this.oComponent.getDataProvider().loadCrewTimebyDate(this, t, this.sCrew);
			this.oComponent.getDataProvider().loadCrew(this, t, this.sCrew);
			this.oComponent.getDataProvider().loadSearchHelpActivity(this, t, this.sCrew.JobCode)
		},
		onCrewTimeLoad: function (e) {
			var t = {};
			var s = [];
			var o = [];
			this.deletedRows = [];
			this.oEmployees = [];
			var r = {};
			var i = [];
			for (var a = 0; a < e.length; a++) {
				o.push({
					ClockIn: e[a].ClockIn,
					ClockOut: e[a].ClockOut,
					CraftDescription: e[a].CraftDescription,
					CrewEffectiveDate: e[a].CrewEffectiveDate,
					CrewId: e[a].CrewId,
					Description: e[a].Description,
					EffectiveDate: e[a].EffectiveDate,
					EmpBecref: e[a].EmpBecref,
					EmpEffectiveDate: e[a].EmpEffectiveDate,
					EmpPersg: e[a].EmpPersg,
					EmpPersk: e[a].EmpPersk,
					EmpWerks: e[a].EmpWerks,
					EmpZztrfgr: e[a].EmpZztrfgr,
					EmpZztrfgrTx: e[a].EmpZztrfgrTx,
					Ename: e[a].Ename,
					JobCode: e[a].JobCode,
					ParentId: e[a].ParentId,
					Pernr: e[a].Pernr,
					PlannedHours: e[a].PlannedHours,
					Shift: e[a].Shift,
					ShiftDescription: e[a].ShiftDescription,
					TotalHours: e[a].TotalHours,
					EmpCountryCode: e[a].EmpCountryCode,
					HoursRule: e[a].HoursRule
				});
				this.oEmployees[a] = o[a];
				var n = e[a].ToEmpTime.results.length;
				if (n > 0) {
					for (var l = 0; l < e[a].ToEmpTime.results.length; l++) {
						s.push({
							Class: e[a].ToEmpTime.results[l].Class,
							ClassEditable: e[a].ToEmpTime.results[l].ClassEditable,
							ClassTx: e[a].ToEmpTime.results[l].ClassTx,
							Costcode: e[a].ToEmpTime.results[l].Costcode,
							CostcodeTx: e[a].ToEmpTime.results[l].CostcodeTx,
							Counter: e[a].ToEmpTime.results[l].Counter,
							CrewId: e[a].ToEmpTime.results[l].CrewId,
							Hours: e[a].ToEmpTime.results[l].Hours,
							IsEditable: e[a].ToEmpTime.results[l].IsEditable,
							IsNewRecord: e[a].ToEmpTime.results[l].IsNewRecord,
							JobCode: e[a].ToEmpTime.results[l].JobCode,
							LongText: e[a].ToEmpTime.results[l].LongText,
							LongText_Data: e[a].ToEmpTime.results[l].LongText_Data,
							ParentId: e[a].ToEmpTime.results[l].ParentId,
							Pernr: e[a].ToEmpTime.results[l].Pernr,
							Prakn: e[a].ToEmpTime.results[l].Prakn,
							Prakz: e[a].ToEmpTime.results[l].Prakz,
							Qnty: e[a].ToEmpTime.results[l].Qnty,
							RefCounter: e[a].ToEmpTime.results[l].RefCounter,
							TimeType: e[a].ToEmpTime.results[l].TimeType,
							Trfst: e[a].ToEmpTime.results[l].Trfst,
							Workdate: e[a].ToEmpTime.results[l].Workdate,
							Zzact: e[a].ToEmpTime.results[l].Zzact,
							ZzactEditable: e[a].ToEmpTime.results[l].ZzactEditable,
							Zzcst: e[a].ToEmpTime.results[l].Zzcst,
							Zzptjcd: e[a].ToEmpTime.results[l].Zzptjcd,
							Zzssc: e[a].ToEmpTime.results[l].Zzssc,
							DeleteFlag: ""
						})
					}
					t.CrewTime = o;
					t.CrewTime[a].Time = s;
					s = []
				} else {
					t.CrewTime = o
				}
			}
			this.getView().getModel("Employees").setProperty("/Employees", this.oEmployees, null, true);
			r = this._buildRows(this.oEmployees, t.CrewTime);
			var d = this.getView().getModel("crewTimeRedesign");
			d.setProperty("/CrewTime", r, null, true);
			this._buildTable(this.oEmployees);
			this.hideBusyIndicator()
		},
		_buildRows: function (e, t) {
			var s;
			var o = [];
			var r = -2;
			this.TotalTimesheetHours = 0;
			if (t !== undefined && t.length !== undefined) {
				for (var i = 0; i < t.length; i++) {
					if (t[i].Time !== undefined) {
						var a = t[i].Time.length;
						if (a > 0) {
							for (var n = 0; n < t[i].Time.length; n++) {
								const e = "Hours" + i;
								const a = "HoursEditable" + i;
								const d = "Qnty" + i;
								const u = "DeleteFlag" + i;
								const p = "LongText" + i;
								const c = "LongText_Data" + i;
								const g = "HoursCounter" + i;
								const m = "HoursRefcount" + i;
								const h = "ParentId" + i;
								const C = "Class" + i;
								const f = "Trfst" + i;
								s = {
									EmployeeColumnNo: i,
									Zzcst: t[i].Time[n].Zzcst,
									Zzptjcd: t[i].Time[n].Zzptjcd,
									Zzssc: t[i].Time[n].Zzssc,
									Zzact: t[i].Time[n].Zzact,
									Prakn: t[i].Time[n].Prakn,
									Prakz: t[i].Time[n].Prakz,
									TimeType: t[i].Time[n].TimeType,
									Costcode: t[i].Time[n].Costcode,
									CostcodeTx: t[i].Time[n].CostcodeTx,
									TimeType: t[i].Time[n].TimeType,
									IsDeletedRow: false,
									isNewRow: false,
									[e]: t[i].Time[n].Hours,
									[d]: t[i].Time[n].Qnty,
									[p]: t[i].Time[n].LongText,
									[c]: t[i].Time[n].LongText_Data,
									[g]: t[i].Time[n].Counter,
									[m]: t[i].Time[n].RefCounter,
									[h]: t[i].Time[n].ParentId,
									[C]: t[i].Time[n].Class,
									[f]: t[i].Time[n].Trfst,
									CostCodeTotalHours: "0.00"
								};
								r = -2;
								var l = false;
								while (l === false) {
									r = this._findRowInColumnStructTable(s, o, r);
									const e = "HoursCounter" + i;
									if (r === -1 || o[r][e] === undefined) {
										l = true
									}
								}
								if (r > -1) {
									o = this._mergeTableRows(s, o, r)
								} else {
									if (this.timeTypeCategory[t[i].Time[n].TimeType] !== "PD") {
										s.CostCodeTotalHours = t[i].Time[n].Hours;
										this.TotalTimesheetHours = parseFloat(this.TotalTimesheetHours) + parseFloat(s.CostCodeTotalHours)
									}
									o.push(s)
								}
							}
						}
					}
				}
			}
			o.sort(function (e, t) {
				const s = e.Costcode.toUpperCase();
				const o = t.Costcode.toUpperCase();
				if (s < o) {
					return -1
				}
				if (s > o) {
					return 1
				}
				return 0
			});
			return o
		},
		_findRowInColumnStructTable: function (e, t, s) {
			let o = t.findIndex((t, o) => t.Zzcst === e.Zzcst && t.Zzptjcd === e.Zzptjcd && t.Zzssc === e.Zzssc && t.Zzact === e.Zzact && t.TimeType ===
				e.TimeType && o > s);
			return o
		},
		_mergeTableRows: function (e, t, s) {
			var o = e.EmployeeColumnNo;
			const r = "Hours" + o;
			const i = "HoursEditable" + o;
			const a = "Qnty" + o;
			const n = "DeleteFlag" + o;
			const l = "LongText" + o;
			const d = "LongText_Data" + o;
			const u = "HoursCounter" + o;
			const p = "HoursRefcount" + o;
			const c = "Class" + o;
			const g = "Trfst" + o;
			const m = "ParentId" + o;
			if (this.timeTypeCategory[e.TimeType] !== "PD") {
				t[s].CostCodeTotalHours = parseFloat(t[s].CostCodeTotalHours) + parseFloat(e[r]);
				this.TotalTimesheetHours = parseFloat(this.TotalTimesheetHours) + parseFloat(e[r])
			}
			t[s][r] = e[r];
			t[s][i] = e[i];
			t[s][a] = e[a];
			t[s][n] = e[n];
			t[s][l] = e[l];
			t[s][d] = e[d];
			t[s][u] = e[u];
			t[s][p] = e[p];
			t[s][c] = e[c];
			t[s][g] = e[g];
			t[s][m] = e[m];
			return t
		},
		_buildTable: function (e) {
			var t = this.getView().byId("idEmpTable");
			var s = this.getView();
			t.destroyColumns();
			t.destroyRowSettingsTemplate();
			t.addColumn(new sap.ui.table.Column({
				multiLabels: [new sap.m.Label({
					visible: false
				}), new sap.m.Label({
					text: "{i18n>CT.CC}",
					wrapping: true
				}), new sap.m.Label({
					visible: false
				})],
				width: "9rem",
				template: new sap.m.Link({
					text: "{Costcode}",
					wrapping: true,
					press: this.onCostCodeQuickView.bind(this)
				})
			}));
			t.addColumn(new sap.ui.table.Column({
				multiLabels: [new sap.m.Label({
					visible: false
				}), new sap.m.Label({
					text: "Activity",
					wrapping: true
				}), new sap.m.Label({
					visible: false
				})],
				visible: true,
				width: "9rem",
				template: new sap.m.Input({
					type: "Text",
					value: "{Zzact}",
					placeholder: "Select Activity ...",
					showValueHelp: true,
					valueHelpOnly: true,
					valueHelpRequest: this.handleValueHelpActivity.bind(this),
					visible: true,
					editable: {
						path: "app>/timePageReadOnly",
						formatter: function (e) {
							return !e
						}
					}
				})
			}));
			t.addColumn(new sap.ui.table.Column({
				multiLabels: [new sap.m.Label({
					visible: false
				}), new sap.m.Label({
					text: "Time Type",
					wrapping: true
				}), new sap.m.Label({
					visible: false
				})],
				width: "6rem",
				template: new sap.m.Input({
					type: "Text",
					value: "{TimeType}",
					placeholder: "Enter Time Type ...",
					showValueHelp: true,
					valueHelpOnly: true,
					valueHelpRequest: this.handleValueHelpTimeType.bind(this),
					visible: true,
					editable: {
						path: "app>/timePageReadOnly",
						formatter: function (e) {
							return !e
						}
					}
				})
			}));
			t.addColumn(new sap.ui.table.Column({
				multiLabels: [new sap.m.Label({
					visible: false
				}), new sap.m.Label({
					text: "Total",
					wrapping: true
				}), new sap.m.Text({
					text: "",
					width: "100%",
					textAlign: "Center"
				}).addStyleClass("zSmallFontGreenColumnHeader"), new sap.m.Text({
					text: this.formatter.decimal(this.TotalTimesheetHours) + " Hours",
					width: "100%",
					textAlign: "Center"
				}).addStyleClass("zSmallFontGreenColumnHeader")],
				width: "5rem",
				template: new sap.m.ObjectNumber({
					number: {
						path: "CostCodeTotalHours",
						formatter: this.formatter.decimal.bind(this)
					},
					textAlign: "End"
				})
			}));
			var o;
			for (var r = 0; r < e.length; r++) {
				var i = "Hours" + r;
				var a = "LongText" + r;
				var n = "ParentId" + r;
				var l = "HoursEditable" + r;
				var d = "TimeType";
				var u = "Qnty" + r;
				var p = "Class" + r;
				var c = "Trfst" + r;
				var g = this.formatter.getBooleanStringType();
				var m = "/EmployeePictureSet(JobCode='" + e[r].JobCode + "',CrewId='" + e[r].CrewId + "',EmployeeId='" + e[r].Pernr + "')/$value";
				var h = "Employees>/Employees/" + r + "/EmpZztrfgr";
				var C = "Employees>/Employees/" + r + "/EmpPersk";
				if (e[r].EmpCountryCode !== undefined && e[r].EmpCountryCode !== null && e[r].EmpCountryCode !== "" && this.countryCode !== e[r].EmpCountryCode) {
					this.countryCode = e[r].EmpCountryCode
				}
				if (e[r].HoursRule !== undefined && e[r].HoursRule !== null && e[r].HoursRule !== "" && this.hoursRule !== e[r].HoursRule) {
					this.hoursRule = e[r].HoursRule
				}
				o = this.oComponent.oModels.TIME7011.sServiceUrl + m;
				if (this.oComponent.oModels.TIME7011.aUrlParams !== undefined && this.oComponent.oModels.TIME7011.aUrlParams.length > 0) {
					o = o + "?" + this.oComponent.oModels.TIME7011.aUrlParams[0]
				}
				t.addColumn(new sap.ui.table.Column({
					multiLabels: [new sap.m.Panel({
						content: [new sap.m.FlexBox({
							items: [new sap.m.VBox({
								items: [new sap.m.Text({
									text: "IN"
								}).addStyleClass("zSmallFontColumnHeader"), new sap.m.Text({
									text: e[r].ClockIn
								}).addStyleClass("zSmallFontBlackColumnHeader sapUiSmallMarginEnd")],
								alignItems: "Start",
								fitContainer: true
							}), new sap.m.VBox({
								items: [new sap.m.Text({
									text: "OUT"
								}).addStyleClass("zSmallFontColumnHeader sapUiSmallMarginEnd"), new sap.m.Text({
									text: e[r].ClockOut
								}).addStyleClass("zSmallFontColumnHeader sapUiSmallMarginEnd")],
								alignItems: "End",
								fitContainer: true
							})],
							justifyContent: "SpaceBetween",
							alignItems: "Stretch"
						})]
					}), new sap.m.FlexBox({
						items: [new sap.m.Image({
							detailBox: new sap.m.LightBox({
								imageContent: new sap.m.LightBoxItem({
									imageSrc: o,
									title: e[r].Ename,
									subtitle: e[r].CraftDescription
								})
							}),
							src: o,
							width: "3rem",
							decorative: false,
							densityAware: false
						}).addStyleClass("sapMImg sapMSLIImg sapUiSmallMarginEnd"), new sap.m.VBox({
							items: [new sap.m.Text({
								text: e[r].Ename
							}).addStyleClass("zMediumFontColumnHeader"), new sap.m.Text({
								text: e[r].CraftDescription
							}).addStyleClass("zSmallFontColumnHeader")]
						})]
					}), new sap.m.Text({
						text: e[r].EmpZztrfgrTx,
						width: "100%",
						textAlign: "Center"
					}).addStyleClass("zSmallFontCraftColumnHeader"), new sap.m.Text({
						text: (e[r].TotalHours === "" ? "0.00" : e[r].TotalHours) + " / " + e[r].PlannedHours + " Hours",
						width: "100%",
						textAlign: "Center"
					}).addStyleClass("zSmallFontGreenColumnHeader")],
					width: "9rem",
					template: new sap.m.FlexBox({
						alignItems: "Start",
						justifyContent: "SpaceBetween",
						items: [new sap.m.Button({
							icon: {
								parts: [{
									path: a
								}, {
									path: l
								}],
								formatter: this.formatter.commentIcon.bind(this)
							},
							type: {
								parts: [{
									path: a
								}, {
									path: l
								}],
								formatter: this.formatter.commentIconColor.bind(this)
							},
							press: this.longtextPopover.bind(this)
						}).data("colno", r), new sap.m.Input({
							width: "4rem",
							value: "{" + i + "}",
							type: sap.m.InputType.Number,
							change: this.onInputHoursChanged.bind(this),
							visible: {
								parts: [{
									path: d
								}, {
									path: l
								}],
								formatter: this.formatter.visibleHrs.bind(this)
							},
							editable: {
								path: "app>/timePageReadOnly",
								formatter: function (e) {
									return !e
								}
							},
							valueState: sap.ui.core.ValueState.None,
							showValueStateMessage: false
						}), new sap.m.CheckBox({
							visible: {
								parts: [{
									path: d
								}, {
									path: l
								}],
								formatter: this.formatter.visiblePD.bind(this)
							},
							editable: {
								path: "app>/timePageReadOnly",
								formatter: function (e) {
									return !e
								}
							}
						}).bindProperty("selected", {
							type: new g,
							path: u
						}), new sap.m.Button({
							icon: {
								parts: [{
									path: p
								}, {
									path: c
								}, {
									path: h
								}, {
									path: C
								}],
								formatter: this.formatter.classIcon.bind(this)
							},
							customData: [new sap.ui.core.CustomData({
								key: "colno",
								value: r
							})],
							enabled: {
								parts: [{
									path: d
								}, {
									path: i
								}, {
									path: u
								}, {
									path: p
								}, {
									path: c
								}, {
									path: h
								}, {
									path: C
								}],
								formatter: this.formatter.classIconEnabled.bind(this)
							},
							tooltip: {
								parts: [{
									path: p
								}, {
									path: c
								}, {
									path: h
								}, {
									path: C
								}],
								formatter: this.formatter.classIconTooltip.bind(this)
							},
							type: {
								parts: [{
									path: p
								}, {
									path: c
								}, {
									path: h
								}, {
									path: C
								}],
								formatter: this.formatter.classIconColor.bind(this)
							},
							press: this.handleValueHelpClass.bind(this)
						})]
					})
				}))
			}
			t.setFixedColumnCount(4);
			var f = this.getView().getModel("crewTimeRedesign");
			t.setEditable(!this.isReadOnly);
			t.setModel(f);
			t.bindRows("/CrewTime")
		},
		_addNewBlankRowToTable: function (e, t, s) {
			var o = this.getProperty("crewTimeRedesign", "/CrewTime");
			var r;
			var i = [];
			r = {
				JobCode: e.JobCode,
				CrewId: e.CrewId,
				Costcode: e.Costcode,
				CostcodeTx: e.CostcodeTx,
				CostCodeTotalHours: 0,
				TimeType: this.getDefaultTimeType(e.Zzcst, e.Zzssc, e.Zzptjcd),
				Zzact: e.Zzact,
				Zzcst: e.Zzcst,
				Zzssc: e.Zzssc,
				Zzptjcd: e.Zzptjcd,
				IsDeletedRow: false,
				isNewRow: true
			};
			if (this.timeTypeCategory[r.TimeType] !== "PD") {
				if (t !== undefined && parseFloat(t) > 0) {
					for (var a = 0; a < this.oEmployees.length; a++) {
						const e = "Hours" + a;
						r[e] = t
					}
				}
			} else {
				if (s === true) {
					for (var a = 0; a < this.oEmployees.length; a++) {
						const e = "Qnty" + a;
						r[e] = "X"
					}
				}
			}
			if (o.length === undefined) {
				i.push(r);
				o = i
			} else {
				o.push(r)
			}
			var n = this.getView().getModel("crewTimeRedesign");
			n.setProperty("/CrewTime", o, null, true);
			this.hideBusyIndicator()
		},
		getDefaultTimeType: function (e, t, s) {
			var o = this.getModel("searchHelpTimeType").getProperty("/SearchHelpTimeType");
			if (o.results.length !== undefined) {
				let r = o.results.findIndex(o => o.JobCode === s && o.CostCode === e && o.ZZSSC === t && o.TimeType === "ST");
				if (r > -1) {
					return "ST"
				} else {
					let r = o.results.findIndex(o => o.JobCode === s && o.CostCode === e && o.ZZSSC === t);
					if (r > -1) {
						return o.results[r].TimeType
					} else {
						return ""
					}
				}
			}
		},
		onCloseDetailPress: function () {
			var e = this.getView().getModel("app");
			e.setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
			this.getOwnerComponent().getRouter().navTo("CrewList", {}, true)
		},
		toggleFullScreen: function () {
			var e = this.getView().getModel("app");
			var t = e.getProperty("/actionButtonsInfo/endColumn/fullScreen");
			e.setProperty("/actionButtonsInfo/endColumn/fullScreen", !t);
			if (!t) {
				e.setProperty("/previousLayout", e.getProperty("/layout"));
				e.setProperty("/layout", "EndColumnFullScreen")
			} else {
				e.setProperty("/layout", e.getProperty("/previousLayout"))
			}
		},
		onInputHoursChanged: function (e) {
			if (isNaN(e.getParameter("newValue")) || e.getParameter("newValue") < 0) {
				e.getSource().setValueState("Error");
				e.getSource().setShowValueStateMessage(true);
				e.getSource().setValueStateText("Enter positive number")
			} else if (e.getParameter("newValue") > 0) {
				var t = e.getParameter("newValue");
				if (this.hoursRule === "1006") {
					this.check1006HoursFormat(t, e)
				} else if (this.hoursRule === "1003") {
					this.check1003HoursFormat(t, e)
				} else {}
			} else if (e.getParameter("newValue") === "") {
				e.getSource().setValueState("None")
			}
		},
		check1003HoursFormat: function (e, t) {
			if (e.split(".")[1] !== undefined && e.split(".")[1].length > 1) {
				for (var s = 1; s < e.split(".")[1].length; s++) {
					if (e.split(".")[1][s] > 0) {
						t.getSource().setValueState("Error");
						t.getSource().setShowValueStateMessage(true);
						t.getSource().setValueStateText("Number of hours can only have one digit after decimal.");
						break
					} else {
						t.getSource().setValueState("None")
					}
				}
			} else {
				t.getSource().setValueState("None")
			}
		},
		check1006HoursFormat: function (e, t) {
			if (e.split(".")[1] !== undefined && e.split(".")[1].length > 2) {
				for (var s = 2; s < e.split(".")[1].length; s++) {
					if (e.split(".")[1][s] > 0) {
						t.getSource().setValueState("Error");
						t.getSource().setShowValueStateMessage(true);
						t.getSource().setValueStateText("Number of hours can only have two digits after decimal.");
						break
					} else {
						var o = 0;
						o = e.split(".")[1];
						if (o % 25 === 0) {
							t.getSource().setValueState("None")
						} else {
							t.getSource().setValueState("Error");
							t.getSource().setShowValueStateMessage(true);
							t.getSource().setValueStateText("Number of hours can only be in increment of 0.25");
							break
						}
					}
				}
			} else if (e.split(".")[1] !== undefined && e.split(".")[1].length >= 1 && e.split(".")[1].length <= 2) {
				var o = 0;
				o = e.split(".")[1];
				if (o <= 9) {
					o = o * 10
				}
				if (o % 25 === 0) {
					t.getSource().setValueState("None")
				} else {
					t.getSource().setValueState("Error");
					t.getSource().setShowValueStateMessage(true);
					t.getSource().setValueStateText("Number of hours can only be in increment of 0.25")
				}
			} else {
				t.getSource().setValueState("None")
			}
		},
		onSearchHelpCostCodeLoad: function (e) {
			this._aSearchHelpCostCode = jQuery.extend(true, [], e.results);
			this.setModel(new sap.ui.model.json.JSONModel(e.results), "searchHelpCostCode")
		},
		onSearchHelpUnassignedCostCodeLoad: function (e) {
			this.setModel(new sap.ui.model.json.JSONModel(e.results), "searchHelpUnassignedCostCode")
		},
		onSearchHelpClassLoad: function (e) {
			this.getModel("searchHelpClass").setSizeLimit(e.length);
			this.setProperty("searchHelpClass", "/SearchHelpClass", e)
		},
		onSearchHelpActivityLoad: function (e) {
			this.getModel("searchHelpActivity").setSizeLimit(e.length);
			this.setProperty("searchHelpActivity", "/SearchHelpActivity", e)
		},
		onSearchHelpTimeTypeLoad: function (e) {
			this.getModel("searchHelpTimeType").setSizeLimit(e.length);
			this.setProperty("searchHelpTimeType", "/SearchHelpTimeType", e);
			if (e.results.length !== undefined) {
				for (var t = 0; t < e.results.length; t++) {
					this.timeTypeCategory[e.results[t].TimeType] = e.results[t].Category;
					this.timeTypeDescription[e.results[t].TimeType] = e.results[t].TimeTypeTx
				}
			}
		},
		_sortCostCodeSearchTable(e, t) {
			var s = false;
			if (e.getSource().getParent().getParent().getParent().getBinding("items").aSorters[0] !== undefined) {
				if (t === e.getSource().getParent().getParent().getParent().getBinding("items").aSorters[0].sPath) {
					s = e.getSource().getParent().getParent().getParent().getBinding("items").aSorters[0].bDescending
				}
			}
			var o = new sap.ui.model.Sorter({
				path: t,
				descending: !s
			});
			var r = e.getSource().getParent().getParent().getParent().getBinding("items");
			r.sort(o)
		},
		onAddCostCode: function (e) {
			var t = this;
			var s = this.getModel("searchHelpCostCode").getData();
			var o = {
				onSortCostCode: function (e) {
					t._sortCostCodeSearchTable(e, "Costcode")
				},
				onSortCostCodeDesc: function (e) {
					t._sortCostCodeSearchTable(e, "CostcodeTx")
				},
				handleClose: function (e) {
					t.oAddCostCodeDialog.setRememberSelections(false)
				},
				handleConfirm: function (e) {
					s = t.getModel("searchHelpCostCode").getData();
					for (var o = 0; o < e.getParameter("selectedContexts").length; o++) {
						var r = e.getParameter("selectedContexts")[o].getPath().split("/")[1];
						t._addNewBlankRowToTable(s[r])
					}
					var i = e.getSource().getBinding("items");
					i.filter([]);
					i.sort([]);
					t.oAddCostCodeDialog.setRememberSelections(false)
				},
				handleCostCodeSearch: function (e) {
					var t = e.getParameter("value");
					var s = new C({
						filters: [new sap.ui.model.Filter("Costcode", h.Contains, t), new sap.ui.model.Filter("CostcodeTx", h.Contains, t)],
						and: false
					});
					var o = e.getSource().getBinding("items");
					o.filter([s])
				},
				dateConversion: function (e) {
					return t.formatter.dateConversion(e)
				}
			};
			if (!this.oAddCostCodeDialog) {
				this.oAddCostCodeDialog = sap.ui.xmlfragment(this.getView().getId(), "mytime.ZMOB_MY_TIME_Redesign.view.fragments.AddCostCode", o);
				this.getView().addDependent(this.oAddCostCodeDialog)
			}
			jQuery.sap.delayedCall(0, this, function () {
				this.oAddCostCodeDialog.open()
			})
		},
		onAddUnassignedCostCode: function (e) {
			var t = this;
			var s = this.getModel("searchHelpUnassignedCostCode").getData();
			var o = {
				onSortCostCode: function (e) {
					t._sortCostCodeSearchTable(e, "Costcode")
				},
				onSortCostCodeDesc: function (e) {
					t._sortCostCodeSearchTable(e, "CostcodeTx")
				},
				handleClose: function (e) {
					t.oAddUnassignedCostCodeDialog.setRememberSelections(false)
				},
				handleConfirm: function (e) {
					s = t.getModel("searchHelpUnassignedCostCode").getData();
					for (var o = 0; o < e.getParameter("selectedContexts").length; o++) {
						var r = e.getParameter("selectedContexts")[o].getPath().split("/")[1];
						t._addNewBlankRowToTable(s[r])
					}
					t.oAddUnassignedCostCodeDialog.setRememberSelections(false)
				},
				handleCostCodeSearch: function (e) {
					var t = e.getParameter("value");
					var s = new C({
						filters: [new sap.ui.model.Filter("Costcode", h.Contains, t), new sap.ui.model.Filter("CostcodeTx", h.Contains, t)],
						and: false
					});
					var o = e.getSource().getBinding("items");
					o.filter([s])
				},
				dateConversion: function (e) {
					return t.formatter.dateConversion(e)
				}
			};
			if (!this.oAddUnassignedCostCodeDialog) {
				this.oAddUnassignedCostCodeDialog = sap.ui.xmlfragment(this.getView().getId(),
					"mytime.ZMOB_MY_TIME_Redesign.view.fragments.AddUnassignedCostCode", o);
				this.getView().addDependent(this.oAddUnassignedCostCodeDialog)
			}
			jQuery.sap.delayedCall(0, this, function () {
				this.oAddUnassignedCostCodeDialog.open()
			})
		},
		onAddCostCodeHour: function (e) {
			var t = this;
			var o = jQuery.extend(true, [], t.getModel("searchHelpCostCode").getData());
			t.setModel(new sap.ui.model.json.JSONModel(o), "searchHelpCostCode");
			for (var r = 0; r < o.length; r++) {
				o[r]["TimeType"] = this.getDefaultTimeType(o[r].Zzcst, o[r].Zzssc, o[r].Zzptjcd);
				o[r]["Category"] = this.timeTypeCategory[o[r].TimeType]
			}
			var i = -2;
			var a = 0;
			var n = false;
			var l = "";
			var d = {
				onSortCostCode: function (e) {
					t._sortCostCodeSearchTable(e, "Costcode")
				},
				onSortCostCodeDesc: function (e) {
					t._sortCostCodeSearchTable(e, "CostcodeTx")
				},
				handleClose: function (e) {
					t.oAddCostCodeDialogHour.setRememberSelections(false);
					t.setModel(new sap.ui.model.json.JSONModel(t._aSearchHelpCostCode), "searchHelpCostCode")
				},
				handleConfirm: function (e) {
					o = t.getModel("searchHelpCostCode").getData();
					for (var r = 0; r < e.getParameter("selectedContexts").length; r++) {
						l = "";
						if (t.getModel("searchHelpCostCode").getProperty(e.getParameter("selectedContexts")[r].sPath).Category !== "PD") {
							a = t.getModel("searchHelpCostCode").getProperty(e.getParameter("selectedContexts")[r].sPath).Hours;
							l = t.getModel("searchHelpCostCode").getProperty(e.getParameter("selectedContexts")[r].sPath).Costcode;
							if (isNaN(a) || a < 0) {
								jQuery.sap.delayedCall(0, t, function () {
									t.oAddCostCodeDialogHour.setRememberSelections(true);
									t.oAddCostCodeDialogHour.open();
									s.error("Enter positive number in the hours field")
								});
								return
							}
							if (a.split(".")[1] !== undefined && a.split(".")[1].length > 0) {
								var d = t.checkHours(a);
								if (d !== undefined && d !== "S") {
									jQuery.sap.delayedCall(0, t, function () {
										t.oAddCostCodeDialogHour.setRememberSelections(true);
										t.oAddCostCodeDialogHour.open();
										s.error(d)
									});
									return
								}
							}
						}
					}
					for (var r = 0; r < e.getParameter("selectedContexts").length; r++) {
						i = e.getParameter("selectedContexts")[r].getPath().split("/")[1];
						var u = e.getParameter("selectedContexts")[r].sPath;
						a = t.getModel("searchHelpCostCode").getProperty(u).Hours;
						n = t.getModel("searchHelpCostCode").getProperty(u).Qty;
						t.getModel("searchHelpCostCode").setProperty(u + "/Hours", "");
						t.getModel("searchHelpCostCode").setProperty(u + "/Qty", false);
						t.getModel("searchHelpCostCode").setProperty(u + "/valueState", "None");
						t._addNewBlankRowToTable(o[i], a, n)
					}
					t.oAddCostCodeDialogHour.setRememberSelections(false);
					var p = e.getSource().getBinding("items");
					p.filter([]);
					p.sort([]);
					t.setModel(new sap.ui.model.json.JSONModel(t._aSearchHelpCostCode), "searchHelpCostCode")
				},
				onHoursChange: function (e) {
					var s = e.getSource().getParent().getParent().getBindingContextPath();
					if (t.getModel("searchHelpCostCode").getProperty(s).Category !== "PD") {
						if (isNaN(e.getParameter("newValue")) || e.getParameter("newValue") < 0) {
							e.getSource().getParent().getParent().setSelected(false);
							t.getModel("searchHelpCostCode").setProperty(s + "/valueState", "Error");
							t.getModel("searchHelpCostCode").setProperty(s + "/valueStateText", "Enter positive number")
						} else if (e.getParameter("newValue") > 0) {
							var o = e.getParameter("newValue");
							if (o.split(".")[1] !== undefined && o.split(".")[1].length > 0) {
								var r = t.checkHours(o);
								if (r !== undefined && r !== "S") {
										e.getSource().getParent().getParent().setSelected(false);
									t.getModel("searchHelpCostCode").setProperty(s + "/valueState", "Error");
									t.getModel("searchHelpCostCode").setProperty(s + "/valueStateText", r);
									return
								} else {
										e.getSource().getParent().getParent().setSelected(true);
									e.getSource().setValueState("None")
								}
							} else {
									e.getSource().getParent().getParent().setSelected(true);
								t.getModel("searchHelpCostCode").setProperty(s + "/valueState", "None")
							}
						} else if (e.getParameter("newValue") === "") {
								e.getSource().getParent().getParent().setSelected(false);
							t.getModel("searchHelpCostCode").setProperty(s + "/valueState", "None")
						}
					}
				},
				handleCostCodeSearch: function (e) {
					var t = e.getParameter("value");
					var s = new C({
						filters: [new sap.ui.model.Filter("Costcode", h.Contains, t), new sap.ui.model.Filter("CostcodeTx", h.Contains, t)],
						and: false
					});
					var o = e.getSource().getBinding("items");
					o.filter([s])
				},
				dateConversion: function (e) {
					return t.formatter.dateConversion(e)
				}
			};
			if (!this.oAddCostCodeDialogHour) {
				this.oAddCostCodeDialogHour = sap.ui.xmlfragment(this.getView().getId(),
					"mytime.ZMOB_MY_TIME_Redesign.view.fragments.AddCostCodeHour", d);
				this.getView().addDependent(this.oAddCostCodeDialogHour)
			}
			jQuery.sap.delayedCall(0, this, function () {
				this.oAddCostCodeDialogHour.setRememberSelections(true);
				this.oAddCostCodeDialogHour.open()
			})
		},
		onSave: function (e) {
			this.onSend("SIGN")
		},
		onApprove: function (e) {
			this.onSend("APPROVE")
		},
		checkHours: function (e) {
			if (this.hoursRule !== undefined && this.hoursRule !== "" && this.hoursRule === "1006") {
				if (e.split(".")[1] !== undefined && e.split(".")[1].length > 2) {
					for (var t = 1; t < e.split(".")[1].length; t++) {
						if (e.split(".")[1][t] > 0) {
							return "Number of hours can be in increment of 0.25"
						}
					}
				} else if (e.split(".")[1] !== undefined && e.split(".")[1].length >= 1 && e.split(".")[1].length <= 2) {
					var s = 0;
					s = e.split(".")[1];
					if (s <= 9) {
						s = s * 10
					}
					if (s % 25 !== 0) {
						return "Number of hours can be in increment of 0.25"
					}
				}
			} else if (this.hoursRule !== undefined && this.hoursRule !== "" && this.hoursRule === "1003") {
				if (e.split(".")[1] !== undefined && e.split(".")[1].length > 1) {
					for (var t = 1; t < e.split(".")[1].length; t++) {
						if (e.split(".")[1][t] > 0) {
							return "Number of hours can only have one digit after decimal."
						}
					}
				}
			}
			return "S"
		},
		onSend: function (e) {
			this.showBusyIndicator(4e3, 1);
			var o = [];
			var r = this.getProperty("crewTimeRedesign", "/CrewTime");
			var i;
			for (var a = 0; a < this.oEmployees.length; a++) {
				const e = "Hours" + a;
				const t = "Qnty" + a;
				const i = "HoursCounter" + a;
				for (var n = 0; n < r.length; n++) {
					if ((r[n].isNewRow === true || r[n][i] === undefined) && (r[n][e] === undefined || r[n][e] === 0 || r[n][e] === "") && (r[n][t] ===
							undefined || r[n][t] === false || r[n][t] === "")) {} else {
						if (this.timeTypeCategory[r[n].TimeType] !== "PD") {
							if (r[n][e] !== undefined && (isNaN(r[n][e]) || r[n][e] < 0)) {
								s.error("Enter positive number in the hours field");
								this.hideBusyIndicator();
								return
							} else if (r[n][e] > 0) {
								var l = r[n][e];
								var d = this.checkHours(l);
								if (d !== undefined && d !== "S") {
									s.error(d);
									this.hideBusyIndicator();
									return
								}
							}
						}
						o.push(this.onSaveToEmpFill(a, this.oEmployees[a], r[n]))
					}
				}
				for (var n = 0; n < this.deletedRows.length; n++) {
					if (this.deletedRows[n].isNewRow === true || this.deletedRows[n][i] === undefined) {} else {
						o.push(this.onSaveToEmpFill(a, this.oEmployees[a], this.deletedRows[n]))
					}
				}
			}
			this.getView().setModel(new t, "CrewList");
			this.setProperty("CrewList", "/JobCode", this.oEmployees[0].JobCode);
			this.setProperty("CrewList", "/CrewId", this.oEmployees[0].CrewId);
			this.setProperty("CrewList", "/Description", "");
			this.setProperty("CrewList", "/EffectiveDate", this.oEmployees[0].EffectiveDate);
			this.setProperty("CrewList", "/Shift", "");
			this.setProperty("CrewList", "/ShiftDescription", "");
			this.setProperty("CrewList", "/CrewEffectiveDate", this.oEmployees[0].CrewEffectiveDate);
			this.setProperty("CrewList", "/FmPernr", "");
			this.setProperty("CrewList", "/FmName", "");
			this.setProperty("CrewList", "/FmWerks", "");
			this.setProperty("CrewList", "/Status", "");
			this.setProperty("CrewList", "/StatusTx", "");
			this.setProperty("CrewList", "/Action", e);
			this.setProperty("CrewList", "/ToEmpTime", o);
			var u = this.getModel("CrewList").getData();
			this.oComponent.getDataProvider().SendTime(this, u, e)
		},
		onSaveToEmpFill: function (e, t, s) {
			const o = "Hours" + e;
			const r = "HoursEditable" + e;
			const i = "Qnty" + e;
			const a = "DeleteFlag" + e;
			const n = "LongText" + e;
			const l = "LongText_Data" + e;
			const d = "HoursCounter" + e;
			const u = "HoursRefcount" + e;
			const p = "ParentId" + e;
			const c = "Class" + e;
			const g = "Trfst" + e;
			var m = {
				JobCode: t.JobCode,
				CrewId: t.CrewId,
				Pernr: t.Pernr,
				Workdate: t.EffectiveDate,
				Zzcst: s.Zzcst,
				Zzptjcd: s.Zzptjcd,
				Zzssc: s.Zzssc,
				Zzact: s.Zzact,
				Class: s[c],
				Trfst: s[g],
				Prakn: s.Prakn,
				Prakz: s.Prakz,
				TimeType: s.TimeType,
				Costcode: s.Costcode,
				CostcodeTx: s.CostcodeTx,
				ZzactEditable: "",
				ClassEditable: "",
				ClassTx: "",
				DeleteFlag: s.IsDeletedRow === true ? "X" : "",
				ParentId: s[p],
				IsNewRecord: false,
				IsEditable: false,
				Hours: s[o],
				Qnty: this.timeTypeCategory[s.TimeType] === "PD" ? s[i] : "",
				Counter: s[d],
				RefCounter: s[u],
				LongText: s[n],
				LongText_Data: s[l]
			};
			return m
		},
		onSaveTimeSuccess: function (e) {
			this.hideBusyIndicator();
			this.showBusyIndicator(4e3, 1);
			this.oComponent.getDataProvider().loadCrewTimebyDate(this, this.sCrew.EffectiveDate, this.sCrew);
			this.oComponent.getDataProvider().loadCrew(this, this.sCrew.EffectiveDate, this.sCrew);
			this.oComponent.getDataProvider().loadSearchHelpActivity(this, this.sCrew.EffectiveDate, this.sCrew.JobCode);
			this.hideBusyIndicator();
			var t;
			if (e === "APPROVE") {
				t = this.getView().getModel("i18n").getResourceBundle().getText("M.APPROVE")
			}
			if (e === "SIGN") {
				t = this.getView().getModel("i18n").getResourceBundle().getText("M.SIGN")
			}
			r.show(t, {
				duration: 5e3,
				width: "15em",
				my: "center bottom",
				at: "center bottom",
				of: window,
				offset: "0 0",
				collision: "fit fit",
				onClose: null,
				autoClose: true,
				animationTimingFunction: "ease",
				animationDuration: 2e3,
				closeOnBrowserNavigation: true
			});
			this.getView().getModel().attachBatchRequestCompleted(function () {});
			this.getView().getModel().refresh()
		},
		onDeleteCC: function (e) {
			var t = this;
			var s = this.byId("idEmpTable");
			var o = [];
			var i = s.getSelectedIndices();
			if (i.length < 1) {
				r.show("No Cost Code Selected")
			} else {
				var a = this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime");
				this.showBusyIndicator(4e3, 1);
				for (var n = i.length - 1; n >= 0; n--) {
					var l = s.getContextByIndex(i[n]);
					var d = s.getModel("crewTimeRedesign").getProperty(l.getPath());
					d.IsDeletedRow = true;
					this.deletedRows.push(d);
					a.splice(i[n], 1)
				}
				this.getView().getModel("crewTimeRedesign").setProperty("/CrewTime", a, null, true);
				s.clearSelection();
				this.hideBusyIndicator()
			}
		},
		onButtonPress: function (e) {
			var t = e.getSource();
			this.byId("actionSheet").openBy(t)
		},
		hideBusyIndicator: function () {
			sap.ui.core.BusyIndicator.hide()
		},
		showBusyIndicator: function (e, t) {
			sap.ui.core.BusyIndicator.show(t);
			if (e && e > 0) {
				if (this._sTimeoutId) {
					jQuery.sap.clearDelayedCall(this._sTimeoutId);
					this._sTimeoutId = null
				}
				this._sTimeoutId = jQuery.sap.delayedCall(e, this, function () {
					this.hideBusyIndicator()
				})
			}
		},
		handleValueHelpTimeType: function (e) {
			this.selectedValueHelp = e.getSource();
			var t = this.selectedValueHelp.getBindingContext().getPath().split("/")[2];
			var s = this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime")[t];
			var r = new sap.ui.model.json.JSONModel;
			var i = this.getProperty("searchHelpTimeType", "/SearchHelpTimeType");
			r.setData(i);
			var a = e.getSource();
			if (!this._TimeTypeDialog) {
				this._TimeTypeDialog = o.load({
					id: f.getView().getId(),
					name: "mytime.ZMOB_MY_TIME_Redesign.view.fragments.TimeType",
					controller: f
				}).then(function (e) {
					e.setModel(r);
					return e
				})
			}
			this._TimeTypeDialog.then(function (e) {
				f._configSearchHelp(a, e);
				var t = e.getBinding("items");
				var o = [];
				o.push(new sap.ui.model.Filter({
					path: "CostCode",
					operator: "EQ",
					value1: s.Zzcst
				}));
				o.push(new sap.ui.model.Filter({
					path: "JobCode",
					operator: "EQ",
					value1: s.Zzptjcd
				}));
				o.push(new sap.ui.model.Filter({
					path: "ZZSSC",
					operator: "EQ",
					value1: s.Zzssc
				}));
				t.filter(o);
				e.open()
			}.bind(this))
		},
		handleTimeTypeSearch: function (e) {
			var t = e.getParameter("value");
			var s = e.getSource().getBinding("items");
			var o = this.selectedValueHelp.getBindingContext().getPath().split("/")[2];
			var r = this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime")[o];
			var i = [];
			i.push(new sap.ui.model.Filter({
				path: "CostCode",
				operator: "EQ",
				value1: r.Zzcst
			}));
			i.push(new sap.ui.model.Filter({
				path: "JobCode",
				operator: "EQ",
				value1: r.Zzptjcd
			}));
			i.push(new sap.ui.model.Filter({
				path: "ZZSSC",
				operator: "EQ",
				value1: r.Zzssc
			}));
			i.push(new sap.ui.model.Filter({
				path: "TimeType",
				operator: h.Contains,
				value1: t
			}));
			s.filter(i)
		},
		handleValueHelpActivity: function (e) {
			this.selectedValueHelp = e.getSource();
			var t = new sap.ui.model.json.JSONModel;
			var s = this.getProperty("searchHelpActivity", "/SearchHelpActivity");
			t.setData(s);
			var r = e.getSource();
			if (!this._ActivityDialog) {
				this._ActivityDialog = o.load({
					id: f.getView().getId(),
					name: "mytime.ZMOB_MY_TIME_Redesign.view.fragments.Activity",
					controller: f
				}).then(function (e) {
					e.setModel(t);
					return e
				})
			}
			this._ActivityDialog.then(function (e) {
				f._configSearchHelp(r, e);
				e.open()
			}.bind(this))
		},
		handleValueHelpClass: function (e) {
			if (this.getView().getModel("app").getProperty("/timePageReadOnly") === true) {
				this.displayClassPopover(e)
			} else {
				this.selectedValueHelp = e.getSource();
				var t = e.getSource().getBindingContext().getPath();
				var s = t.split("/")[2];
				var r = e.getSource().data("colno");
				var i = new sap.ui.model.json.JSONModel;
				var a = this.getProperty("searchHelpClass", "/SearchHelpClass");
				i.setData(a);
				i.setProperty("/tablerow", s);
				i.setProperty("/tablecol", r);
				i.setProperty("/Zztrfgr", this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime/" + s + "/Class" + r));
				i.setProperty("/Persk", this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime/" + s + "/Trfst" + r));
				var n = e.getSource();
				if (!this._ClassDialog) {
					this._ClassDialog = o.load({
						id: f.getView().getId(),
						name: "mytime.ZMOB_MY_TIME_Redesign.view.fragments.Class",
						controller: f
					}).then(function (e) {
						e.setModel(i);
						return e
					})
				}
				this._ClassDialog.then(function (e) {
					e.open()
				}.bind(this))
			}
		},
		displayClassPopover: function (e) {
			var t = e.getSource().getBindingContext().getPath();
			var s = t.split("/")[2];
			var o = e.getSource().data("colno");
			var r = new sap.ui.model.json.JSONModel;
			r.setProperty("/tablerow", s);
			r.setProperty("/tablecol", o);
			r.setProperty("/Zztrfgr", this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime/" + s + "/Class" + o));
			r.setProperty("/Persk", this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime/" + s + "/Trfst" + o));
			this.setModel(r, "ClassModel");
			var i;
			if (i) {
				i.close();
				i.destroy()
			}
			var a = {
				handleClose: function (e) {
					i.close();
					i.destroy()
				},
				formatText: function (e) {
					return e
				}
			};
			if (!i) {
				i = sap.ui.xmlfragment(this.getView().getId(), "mytime.ZMOB_MY_TIME_Redesign.view.fragments.ClassDescriptionPopOver", a);
				i.setPlacement(sap.m.PlacementType.Left);
				this.getView().addDependent(i)
			}
			var n = e.getSource();
			jQuery.sap.delayedCall(0, this, function () {
				i.openBy(n)
			})
		},
		handleClassSearch: function (e) {
			var t = e.getParameter("value");
			var s = new C({
				filters: [new sap.ui.model.Filter("Trfgr", h.Contains, t), new sap.ui.model.Filter("Persk", h.Contains, t), new sap.ui.model.Filter(
					"ClassDesc", h.Contains, t)],
				and: false
			});
			var o = e.getSource().getBinding("items");
			o.filter([s])
		},
		handleClassClose: function (e) {
			var t = e.getSource().getBinding("items");
			t.filter([]);
			var s = "";
			var o = "";
			var i = e.getSource().getModel().getProperty("/tablerow");
			var a = e.getSource().getModel().getProperty("/tablecol");
			var n = e.getParameter("selectedContexts");
			if (n && n.length) {
				s = n[0].getObject().Trfgr;
				o = n[0].getObject().Persk;
				this.getView().getModel("crewTimeRedesign").setProperty("/CrewTime/" + i + "/Class" + a, s);
				this.getView().getModel("crewTimeRedesign").setProperty("/CrewTime/" + i + "/Trfst" + a, o);
				r.show("You have chosen " + n.map(function (e) {
					return e.getObject().ClassDesc
				}).join(", "))
			}
		},
		handleActivitySearch: function (e) {
			var t = e.getParameter("value");
			var s = new C({
				filters: [new sap.ui.model.Filter("Zzact", h.Contains, t), new sap.ui.model.Filter("WorkpkgDesc", h.Contains, t), new sap.ui.model
					.Filter("WorkpkgId", h.Contains, t)
				],
				and: false
			});
			var o = e.getSource().getBinding("items");
			o.filter([s])
		},
		_configSearchHelp: function (e, t) {
			var s = !!e.data("multi");
			t.setMultiSelect(s);
			var o = e.data("confirmButtonText");
			t.setConfirmButtonText(o);
			var r = !!e.data("remember");
			t.setRememberSelections(r);
			var i = !!e.data("showClearButton");
			t.setShowClearButton(i);
			var a = e.data("growing");
			t.setGrowing(a == "true");
			var n = e.data("threshold");
			if (n) {
				t.setGrowingThreshold(parseInt(n))
			}
			var l = !!e.data("draggable");
			t.setDraggable(l);
			var d = !!e.data("resizable");
			t.setResizable(d);
			var u =
				"sapUiResponsivePadding--header sapUiResponsivePadding--subHeader sapUiResponsivePadding--content sapUiResponsivePadding--footer";
			var p = !!e.data("responsivePadding");
			t.toggleStyleClass(u, p);
			t.getBinding("items").filter([])
		},
		handleActivityValueHelpClose: function (e) {
			var t = e.getParameter("selectedItem");
			if (t) {
				this.selectedValueHelp.setValue(t.getTitle())
			}
		},
		handleTimeTypeValueHelpClose: function (e) {
			var t = e.getParameter("selectedItem");
			if (t) {
				this.selectedValueHelp.setValue(t.getTitle())
			}
		},
		longtextPopover: function (e) {
			if (this.getView().getModel("app").getProperty("/timePageReadOnly") === true) {
				this.displaylongtextPopover(e)
			} else {
				this.editlongtextPopover(e)
			}
		},
		editlongtextPopover: function (e) {
			var t;
			var s = this;
			var o = e.getSource().data("colno");
			const r = "LongText" + o;
			const i = "LongText_Data" + o;
			var a = new sap.ui.model.json.JSONModel;
			if (t) {
				t.close();
				t.destroy()
			}
			var n = {
				handleClose: function (e) {
					t.close();
					t.destroy()
				},
				handleOk: this.onLongTextSubmit.bind(this),
				onLongTextEdit: this.onLongTextEdit.bind(this),
				onLongTextDelete: this.onLongTextDelete.bind(this),
				onPost: this.onLongTextPost.bind(this),
				formatter: this.formatter.CheckBoxValue.bind(this),
				formatText: function (e) {
					return e
				}
			};
			if (!t) {
				t = sap.ui.xmlfragment(this.getView().getId(), "mytime.ZMOB_MY_TIME_Redesign.view.fragments.EditLongTextPopOver", n);
				this.getView().addDependent(t)
			}
			var l = e.getSource();
			var d = l.getBindingContext().getPath();
			var u = d.split("/")[2];
			var p = this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime")[u];
			t.bindElement({
				path: d,
				model: "crewTimeRedesign"
			});
			a.setProperty("/EmpCol", o);
			a.setProperty("/LongText", p[r]);
			a.setProperty("/LongText_Data", p[i]);
			this.setModel(a, "longdata");
			jQuery.sap.delayedCall(0, this, function () {
				t.open(l)
			})
		},
		displaylongtextPopover: function (e) {
			var t;
			var s = this;
			var o = e.getSource().data("colno");
			const r = "LongText" + o;
			const i = "LongText_Data" + o;
			var a = new sap.ui.model.json.JSONModel;
			if (t) {
				t.close();
				t.destroy()
			}
			var n = {
				handleClose: function (e) {
					t.close();
					t.destroy()
				},
				formatText: function (e) {
					return e
				}
			};
			if (!t) {
				t = sap.ui.xmlfragment(this.getView().getId(), "mytime.ZMOB_MY_TIME_Redesign.view.fragments.DisplayLongTextPopOver", n);
				t.setPlacement(sap.m.PlacementType.Left);
				this.getView().addDependent(t)
			}
			var l = e.getSource();
			var d = l.getBindingContext().getPath();
			var u = d.split("/")[2];
			var p = this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime")[u];
			t.bindElement({
				path: d,
				model: "crewTimeRedesign"
			});
			a.setProperty("/EmpCol", o);
			a.setProperty("/LongText", p[r]);
			a.setProperty("/LongText_Data", p[i]);
			this.setModel(a, "longdata");
			jQuery.sap.delayedCall(0, this, function () {
				t.openBy(l)
			})
		},
		onCostCodeQuickView: function (e) {
			var t;
			var s = this;
			if (t) {
				t.close()
			}
			var o = {
				handleClose: function (e) {
					t.close()
				},
				getTimeTypeDescription: function (e) {
					return e + " (" + s.timeTypeDescription[e] + ")"
				}
			};
			if (!t) {
				t = sap.ui.xmlfragment(this.getView().getId(), "mytime.ZMOB_MY_TIME_Redesign.view.fragments.CostCodeDescription", o);
				this.getView().addDependent(t)
			}
			var r = e.getSource();
			var i = r.getBindingContext().getPath();
			t.bindElement({
				path: i,
				model: "crewTimeRedesign"
			});
			jQuery.sap.delayedCall(0, this, function () {
				t.openBy(r)
			})
		},
		getDaysDifference: function (e, t) {
			var s = new Date(e);
			const o = t.substring(0, 4);
			const r = t.substring(4, 6);
			const i = t.substring(6, 8);
			const a = new Date(o, r - 1, i);
			var n = Math.abs(s.getTime() - a.getTime());
			var l = Math.ceil(n / (1e3 * 60 * 60 * 24));
			return l
		},
		onLongTextSubmit: function (e) {
			var t = e.getSource().getParent().getBindingContext("crewTimeRedesign").getPath().split("/")[2];
			var s = this.getView().getModel("crewTimeRedesign").getProperty("/CrewTime");
			var o = this.getView().getModel("longdata").getProperty("/EmpCol");
			const r = "LongText" + o;
			const i = "LongText_Data" + o;
			s[t][i] = this.getView().getModel("longdata").getProperty("/LongText_Data");
			s[t][r] = this.getView().getModel("longdata").getProperty("/LongText");
			this.getView().getModel("crewTimeRedesign").setProperty("/CrewTime", s, null, true);
			e.getSource().getParent().close();
			e.getSource().getParent().destroy()
		},
		onLongTextEdit: function (e) {
			if (e.getSource().getParent().getParent().getAggregation("items")[0].getText()) {
				this.byId("feedInput").setValue(e.getSource().getParent().getParent().getAggregation("items")[0].getText());
				this.getView().getModel("longdata").setProperty("/LongText", "");
				this.byId("feedInput").rerender()
			}
		},
		onLongTextDelete: function (e) {
			if (e.getSource().getParent().getParent().getAggregation("items")[0].getText()) {
				this.getView().getModel("longdata").setProperty("/LongText_Data", "");
				this.getView().getModel("longdata").setProperty("/LongText", "");
				this.byId("feedInput").setEnabled(false);
				e.getSource().getParent().getParent().getParent().getBeginButton().setEnabled(true)
			}
		},
		onLongTextPost: function (e) {
			var t = e.getSource().getParent().getAggregation("beginButton");
			if (e.getParameter("value")) {
				this.getView().getModel("longdata").setProperty("/LongText_Data", e.getParameter("value"));
				this.getView().getModel("longdata").setProperty("/LongText", "X");
				this.byId("feedInput").setEnabled(false);
				t.setEnabled(true)
			}
		},
		onCrewLoad: function (e) {
			this.byId("idPageHeader").setTitle(this.sCrew.CrewId + " (" + this.sCrew.Description + ") Timesheet");
			this.byId("idForeman").setText(e.FmName);
			this.byId("idStatus").setText(e.StatusTx);
			this.byId("idStatus").setState(a.Status(e.StatusTx));
			this.byId("idDate").setValue(e.EffectiveDate);
			var t = e.CrewEffectiveDate.substring(5, 6) + "/" + e.CrewEffectiveDate.substring(7, 8) + "/" + e.CrewEffectiveDate.substring(0, 4);
			this.sCrew.JobCode = e.JobCode;
			this.sCrew.CrewId = e.CrewId;
			this.sCrew.Description = e.Description;
			this.sCrew.ShiftDescription = e.ShiftDescription;
			this.sCrew.EffectiveDate = e.EffectiveDate;
			this.sCrew.JobCode = e.JobCode;
			this.sCrew.FmName = e.FmName;
			this.sCrew.StatusTx = e.StatusTx;
			this.sCrew.FmWerks = e.FmWerks;
			this.sCrew.CrewEffectiveDate = e.CrewEffectiveDate;
			this.sCrew.IsEditable = e.IsEditable;
			this._updatePageSetting()
		},
		onCrewListError: function (e) {
			var t = this.parseError(e.responseText);
			var o = !!this.getView().$().closest(".sapUiSizeCompact").length;
			s.error(t, {
				styleClass: o ? "sapUiSizeCompact" : ""
			})
		},
		onCrewTimeError: function (e) {
			this.hideBusyIndicator();
			var t = this.parseError(e.responseText);
			var o = !!this.getView().$().closest(".sapUiSizeCompact").length;
			s.error(t, {
				styleClass: o ? "sapUiSizeCompact" : ""
			})
		},
		onTimebyDateError: function (e, t) {
			var o = this.parseError(e.responseText);
			var r = !!this.getView().$().closest(".sapUiSizeCompact").length;
			s.error(o, {
				styleClass: r ? "sapUiSizeCompact" : ""
			});
			this.byId("idDate").setValue(t.EffectiveDate)
		},
		onCrewTimeErrors: function (e) {
			this.hideBusyIndicator();
			var t = JSON.parse(e.responseText);
			var o = t.error.message.value;
			var r = t.error.innererror.errordetails[0].message;
			var i = !!f.getView().$().closest(".sapUiSizeCompact").length;
			if (t.error.innererror.errordetails[0].severity !== "warning") {
				s.error(o, {
					styleClass: i ? "sapUiSizeCompact" : ""
				})
			} else {
				if (t.error.innererror.errordetails[0].severity === "warning") {
					f.onBack()
				}
			}
		},
		parseError: function (e) {
			var t;
			try {
				t = JSON.parse(e);
				t = t.error.code + ": " + t.error.message.value
			} catch (r) {
				try {
					switch (typeof e) {
					case "string":
						if (e.indexOf("<?xml") === 0) {
							var s = jQuery.parseXML(e);
							var o = s.querySelector("message");
							if (o) {
								t = o.textContent
							}
						} else {
							t = e
						}
						break;
					case "object":
						t = e.toString();
						break
					}
				} catch (e) {
					t = "An unknown error occurred!! Please contact Administrator !!"
				}
			}
			return t.replace("/IWBEP/CM_MGW_RT/022: ", "")
		}
	})
});