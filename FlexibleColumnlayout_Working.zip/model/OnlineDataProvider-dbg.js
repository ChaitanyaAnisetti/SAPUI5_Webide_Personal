sap.ui.define([
	"sap/ui/Device",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/format/DateFormat"
], function (Device, Filter, FilterOperator, DateFormat) {
	"use strict";
	var oDateFormatter = DateFormat.getDateInstance({
		UTC: true,
		style: "medium"
	});
	return {

		_getApplicationId: function (oDelegate) {
			var appId = oDelegate.applicationId;

			if (appId === undefined || appId === "" || appId !== "A") {
				return "E";
			} else {
				return appId;
			}
		},
		_readCrewList: function (oDelegate, fnCallBack, fnCallError) {
			//			var aUser = sap.ushell.Container.getService("UserInfo").getId(); 
			var oDate = new Date();
			var Month = oDate.getMonth() + 1;
			var oDay = oDate.getDate();
			Month = Month < 10 ? "0" + Month : Month;
			oDay = oDay < 10 ? "0" + oDay : oDay;
			var sDate = oDate.getFullYear() + Month + oDay;

			var aFilters = [new sap.ui.model.Filter({
					path: "EffectiveDate",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sDate
				}),
				new sap.ui.model.Filter({
					path: "ApplicationId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: this._getApplicationId(oDelegate)
				})
			];
			oDelegate.oComponent.oModels.TIME7011.read("/CrewListSet", {
				async: true,
				filters: aFilters,
				success: fnCallBack,
				error: fnCallError
			});
		},
		_readCrewListbyDate: function (oDelegate, oDate, fnCallBack, fnCallError) {
			var aFilters = [new sap.ui.model.Filter({
					path: "EffectiveDate",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oDate
				}),
				new sap.ui.model.Filter({
					path: "ApplicationId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: this._getApplicationId(oDelegate)
				})

			];
			oDelegate.oComponent.oModels.TIME7011.read("/CrewListSet", {
				async: true,
				filters: aFilters,
				success: fnCallBack,
				error: fnCallError
			});
		},
		_readCrew: function (oDelegate, oDate, oCrew, fnCallBack, fnCallError) {
			var aMap = "/CrewListSet(JobCode='" + oCrew.JobCode + "',CrewId='" + encodeURIComponent(oCrew.CrewId) + "',EffectiveDate='" + oDate + "',ApplicationId='" +
				this._getApplicationId(oDelegate) + "')";

			oDelegate.oComponent.oModels.TIME7011.read(aMap, {
				async: true,
				success: fnCallBack,
				error: fnCallError
			});
		},
		_readCrewTime: function (oDelegate, oRecord, fnCallBack, fnCallError) {
			//	var oEffDate = new Date(oRecord.EffectiveDate);
			var aFilters = [new sap.ui.model.Filter({
					path: "JobCode",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oRecord.JobCode
				}),
				new sap.ui.model.Filter({
					path: "CrewId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oRecord.CrewId
				}),
				new sap.ui.model.Filter({
					path: "EffectiveDate",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oRecord.EffectiveDate
				}),
				new sap.ui.model.Filter({
					path: "ApplicationId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: this._getApplicationId(oDelegate)
				}),				
				new sap.ui.model.Filter({
					path: "EmpBecref",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oRecord.EmpBecref
				})
			];
			oDelegate.oComponent.oModels.TIME7011.read("/CrewEmpListSet", {
				async: true,
				urlParameters: {
					"$expand": "ToEmpTime"
				},
				filters: aFilters,
				success: fnCallBack,
				error: fnCallError
			});
		},

		_readCrewTimebyDate: function (oDelegate, oDate, oCrew, fnCallBack, fnCallError) {
			//	var oEffDate = new Date(oRecord.EffectiveDate);
			var aFilters = [new sap.ui.model.Filter({
					path: "JobCode",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oCrew.JobCode
				}),
				new sap.ui.model.Filter({
					path: "CrewId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oCrew.CrewId
				}),
				new sap.ui.model.Filter({
					path: "EffectiveDate",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oDate
				}),
				new sap.ui.model.Filter({
					path: "ApplicationId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: this._getApplicationId(oDelegate)
				}),				
				new sap.ui.model.Filter({
					path: "EmpBecref",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oCrew.EmpBecref
				})
			];
			oDelegate.oComponent.oModels.TIME7011.read("/CrewEmpListSet", {
				async: true,
				urlParameters: {
					"$expand": "ToEmpTime"
				},
				filters: aFilters,
				success: fnCallBack,
				error: fnCallError
			});
		},
		//		/sap/opu/odata/sap/ZE7009_TIME_ENTRY_SRV/CrewEmpListSet?$expand=ToEmpTime&$filter=JobCode eq '0000025658' and CrewId eq 'ELECTRICIAN1' and EffectiveDate eq '20220502'&$format=json

		_readCrewEmpList: function (oDelegate, oRecord, fnCallBack, fnCallError) {
			//	var oEffDate = new Date(oRecord.EffectiveDate);
			var aFilters = [new sap.ui.model.Filter({
					path: "JobCode",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oRecord.JobCode
				}),
				new sap.ui.model.Filter({
					path: "CrewId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oRecord.CrewId
				}),
				new sap.ui.model.Filter({
					path: "ApplicationId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: this._getApplicationId(oDelegate)
				}),				
				new sap.ui.model.Filter({
					path: "EffectiveDate",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oRecord.EffectiveDate
				})
			];
			oDelegate.oComponent.oModels.TIME7011.read("/CrewEmpListSet", {
				async: true,

				filters: aFilters,
				success: fnCallBack,
				error: fnCallError
			});
		},

		_readCrewEmpListByDate: function (oDelegate, oRecord, oDate, fnCallBack, fnCallError) {
			//	var oEffDate = new Date(oRecord.EffectiveDate);
			var aFilters = [new sap.ui.model.Filter({
					path: "JobCode",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oRecord.JobCode
				}),
				new sap.ui.model.Filter({
					path: "CrewId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oRecord.CrewId
				}),
				new sap.ui.model.Filter({
					path: "ApplicationId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: this._getApplicationId(oDelegate)
				}),				
				new sap.ui.model.Filter({
					path: "EffectiveDate",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oDate
				})
			];
			oDelegate.oComponent.oModels.TIME7011.read("/CrewEmpListSet", {
				async: true,

				filters: aFilters,
				success: fnCallBack,
				error: fnCallError
			});
		},

		/*		_readCrewTimeHeader: function (oDelegate, oRecord, fnCallBack, fnCallError) {
					//	var oEffDate = new Date(oRecord.EffectiveDate);
					var aFilters = [new sap.ui.model.Filter({
							path: "JobCode",
							operator: sap.ui.model.FilterOperator.EQ,
							value1: oRecord.JobCode
						}),
						new sap.ui.model.Filter({
							path: "CrewId",
							operator: sap.ui.model.FilterOperator.EQ,
							value1: oRecord.CrewId
						}),
						new sap.ui.model.Filter({
							path: "EffectiveDate",
							operator: sap.ui.model.FilterOperator.EQ,
							value1: oRecord.EffectiveDate
						})
					];
					oDelegate.oComponent.oModels.TIME.read("/TimeHeaderSet", {
						async: true,
						filters: aFilters,
						success: fnCallBack,
						error: fnCallError
					});
				},*/

		_readSearchHelpClass: function (oDelegate, oWerks, fnCallBack, fnCallError) {
			var aFilters = [new sap.ui.model.Filter({
				path: "Werks",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: oWerks
			})];
			oDelegate.oComponent.oModels.TIME7011.read("/SearchHelpClassSet", {
				async: true,
				filters: aFilters,
				success: fnCallBack,
				error: fnCallError
			});
		},
		_readSearchHelpCostCode: function (oDelegate, oCrew, fnCallBack, fnCallError) {
			var aFilters = [new sap.ui.model.Filter({
					path: "JobCode",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oCrew.JobCode
				}),
				new sap.ui.model.Filter({
					path: "CrewId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oCrew.CrewId
				}),
				new sap.ui.model.Filter({
					path: "EffectiveDate",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oCrew.EffectiveDate
				}),
			];
			oDelegate.oComponent.oModels.TIME7011.read("/SearchHelpCostCodeSet", {
				async: true,
				filters: aFilters,
				success: fnCallBack,
				error: fnCallError
			});
		},
		_readSearchHelpUnassignedCostCode: function (oDelegate, oCrew, fnCallBack, fnCallError) {
			var aFilters = [new sap.ui.model.Filter({
					path: "JobCode",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oCrew.JobCode
				}),
				new sap.ui.model.Filter({
					path: "CrewId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oCrew.CrewId
				}),
				new sap.ui.model.Filter({
					path: "EffectiveDate",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oCrew.EffectiveDate
				}),
				new sap.ui.model.Filter({
					path: "UnassignedToCrew",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: 'X'
				})
			];
			oDelegate.oComponent.oModels.TIME7011.read("/SearchHelpCostCodeSet", {
				async: true,
				filters: aFilters,
				success: fnCallBack,
				error: fnCallError
			});
		},		
		_readSearchHelpActivity: function (oDelegate, oDate, oJobCode, fnCallBack, fnCallError) {
			var aFilters = [new sap.ui.model.Filter({
					path: "JobCode",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oJobCode
				}),
				new sap.ui.model.Filter({
					path: "EffectiveDate",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oDate
				})
			];
			oDelegate.oComponent.oModels.TIME7011.read("/SearchHelpActivitySet", {
				async: true,
				filters: aFilters,
				success: fnCallBack,
				error: fnCallError
			});
		},
		_readSearchHelpTimeType: function (oDelegate, oCrew, fnCallBack, fnCallError) {
			var aFilters = [new sap.ui.model.Filter({
					path: "JobCode",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oCrew.JobCode
				}),
				new sap.ui.model.Filter({
					path: "CrewId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oCrew.CrewId
				}),
				new sap.ui.model.Filter({
					path: "EffectiveDate",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oCrew.EffectiveDate
				}),
			];
			oDelegate.oComponent.oModels.TIME7011.read("/SearchHelpTimeTypeSet", {
				async: true,
				filters: aFilters,
				success: fnCallBack,
				error: fnCallError
			});
		},

		_SaveTime: function (oDelegate, aCrewTime, fnCallBack, fnCallError) {
			oDelegate.oComponent.oModels.TIME7011.create("/CrewListSet", aCrewTime, {
				method: "POST",
				success: fnCallBack,
				error: fnCallError
			});
		},

		_readSearchHelpCrewId: function (oDelegate, oJobCode, fnCallBack, fnCallError) {

			var aFilters = [new sap.ui.model.Filter({
					path: "JobCode",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oJobCode
				})

			];
			oDelegate.oComponent.oModels.TIME7012.read("/SearchHelpCrewIdSet", {
				async: true,
				filters: aFilters,
				success: fnCallBack,
				error: fnCallError
			});
		},
		_readSearchHelpProjCode: function (oDelegate, fnCallBack, fnCallError) {
			oDelegate.oComponent.oModels.TIME7012.read("/SearchHelpProjCodeSet", {
				async: true,
				success: fnCallBack,
				error: fnCallError
			});
		},

	};
});