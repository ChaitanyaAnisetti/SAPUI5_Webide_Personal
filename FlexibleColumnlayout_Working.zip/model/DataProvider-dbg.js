sap.ui.define([
	"mytime/ZMOB_MY_TIME_Redesign/model/OnlineDataProvider",
	"mytime/ZMOB_MY_TIME_Redesign/js/Utilities"
], function (OnlineDataProvider, Utilities) {
	"use strict";
	return {
		Utilities: Utilities,
		loadCrewList: function (oDelegate) {
			var fnCallBack = jQuery.proxy(function (oData) {
				var aCrewList = {};
				if (oData) {
					aCrewList = oData.results;
					oDelegate.onCrewListLoad(aCrewList);
				}
			}, this);
			var fnCallError = jQuery.proxy(function (oError) {
				oDelegate.onCrewListError(oError);
			}, this);
			OnlineDataProvider._readCrewList(oDelegate, fnCallBack, fnCallError);
		},
		
		loadCrewListbyDate: function (oDelegate, oDate) {
			var fnCallBack = jQuery.proxy(function (oData) {
				var aCrewList = {};
				if (oData) {
					aCrewList = oData.results;
					oDelegate.onCrewListLoadbyDate(aCrewList);
				}
			}, this);
			var fnCallError = jQuery.proxy(function (oError) {
				oDelegate.onCrewListError(oError);
			}, this);
			OnlineDataProvider._readCrewListbyDate(oDelegate, oDate, fnCallBack, fnCallError);
		},
		loadCrewTime: function (oDelegate, oRecord) {
			var fnCallBack = jQuery.proxy(function (oData) {
				var aCrewTime = {};
				if (oData) {
					aCrewTime = oData.results;
					oDelegate.onCrewTimeLoad(aCrewTime);
				}
			}, this);
			var fnCallError = jQuery.proxy(function (oError) {
				oDelegate.onCrewTimeError(oError);
			}, this);
			OnlineDataProvider._readCrewTime(oDelegate, oRecord, fnCallBack, fnCallError);
		},
		loadCrewTimebyDate: function (oDelegate, oDate, oCrew) {
			var fnCallBack = jQuery.proxy(function (oData) {
				var aCrewTime = {};
				if (oData) {
					aCrewTime = oData.results;
					oDelegate.onCrewTimeLoad(aCrewTime);
				}
			}, this);
			var fnCallError = jQuery.proxy(function (oError) {
				oDelegate.onTimebyDateError(oError, oCrew);
			}, this);
			OnlineDataProvider._readCrewTimebyDate(oDelegate, oDate, oCrew, fnCallBack, fnCallError);
		},

		loadCrewEmployees: function (oDelegate, oRecord) {
			var fnCallBack = jQuery.proxy(function (oData) {
				var aCrewEmpList = {};
				if (oData) {
					aCrewEmpList = oData.results;
					oDelegate.onCrewEmpLoad(aCrewEmpList);
				}
			}, this);
			var fnCallError = jQuery.proxy(function (oError) {
				oDelegate.onCrewEmpError(oError);
			}, this);
			OnlineDataProvider._readCrewEmpList(oDelegate, oRecord, fnCallBack, fnCallError);
		},

		loadCrewEmployeesByDate: function (oDelegate, oRecord, oDate) {
			var fnCallBack = jQuery.proxy(function (oData) {
				var aCrewEmpList = {};
				if (oData) {
					aCrewEmpList = oData.results;
					oDelegate.onCrewEmpLoad(aCrewEmpList);
				}
			}, this);
			var fnCallError = jQuery.proxy(function (oError) {
				oDelegate.onCrewEmpError(oError);
			}, this);
			OnlineDataProvider._readCrewEmpListByDate(oDelegate, oRecord, oDate, fnCallBack, fnCallError);
		},

		loadCrewTimeHeader: function (oDelegate, oRecord) {
			var fnCallBack = jQuery.proxy(function (oData) {
				var aCrewTime = {};
				if (oData) {
					aCrewTime = oData.results;
					oDelegate.onCrewTimeHeaderLoad(aCrewTime);
				}
			}, this);
			var fnCallError = jQuery.proxy(function (oError) {
				oDelegate.onCrewTimeHeaderError(oError);
			}, this);
			OnlineDataProvider._readCrewTimeHeader(oDelegate, oRecord, fnCallBack, fnCallError);
		},

		loadCrew: function (oDelegate, oDate, oCrew) {
			var fnCallBack = jQuery.proxy(function (oData) {
				var aCrew = {};
				if (oData) {
					aCrew = oData;
					oDelegate.onCrewLoad(aCrew);
				}
			}, this);
			var fnCallError = jQuery.proxy(function (oError) {
				oDelegate.onCrewListError(oError);
			}, this);
			OnlineDataProvider._readCrew(oDelegate, oDate, oCrew, fnCallBack, fnCallError);
		},
		loadSearchHelpClass: function (oDelegate, oWerks) {
			var fnCallBack = jQuery.proxy(function (oData) {
				var aSearchHelpClass = {};
				if (oData) {
					aSearchHelpClass = oData;
					oDelegate.onSearchHelpClassLoad(aSearchHelpClass);
				}
			}, this);
			var fnCallError = jQuery.proxy(function (oError) {
				oDelegate.onCrewTimeError(oError);
			}, this);
			OnlineDataProvider._readSearchHelpClass(oDelegate, oWerks, fnCallBack, fnCallError);
		},
		loadSearchHelpCostCode: function (oDelegate, oCrew) {
			var fnCallBack = jQuery.proxy(function (oData) {
				var aSearchHelpCostCode = {};
				if (oData) {
					aSearchHelpCostCode = oData;
					oDelegate.onSearchHelpCostCodeLoad(aSearchHelpCostCode);
				}
			}, this);
			var fnCallError = jQuery.proxy(function (oError) {
				oDelegate.onCrewTimeError(oError);
			}, this);
			OnlineDataProvider._readSearchHelpCostCode(oDelegate, oCrew, fnCallBack, fnCallError);
		},
		loadSearchHelpUnassignedCostCode: function (oDelegate, oCrew) {
			var fnCallBack = jQuery.proxy(function (oData) {
				var aSearchHelpUnassignedCostCode = {};
				if (oData) {
					aSearchHelpUnassignedCostCode = oData;
					oDelegate.onSearchHelpUnassignedCostCodeLoad(aSearchHelpUnassignedCostCode);
				}
			}, this);
			var fnCallError = jQuery.proxy(function (oError) {
				oDelegate.onCrewTimeError(oError);
			}, this);
			OnlineDataProvider._readSearchHelpUnassignedCostCode(oDelegate, oCrew, fnCallBack, fnCallError);
		},		
		loadSearchHelpActivity: function (oDelegate, oDate, oJobCode) {
			var fnCallBack = jQuery.proxy(function (oData) {
				var aSearchHelpActivity = {};
				if (oData) {
					aSearchHelpActivity = oData;
					oDelegate.onSearchHelpActivityLoad(aSearchHelpActivity);
				}
			}, this);
			var fnCallError = jQuery.proxy(function (oError) {
				oDelegate.onCrewTimeError(oError);
			}, this);
			OnlineDataProvider._readSearchHelpActivity(oDelegate, oDate, oJobCode, fnCallBack, fnCallError);
		},
		loadSearchHelpTimeType: function (oDelegate, oCrew) {
			var fnCallBack = jQuery.proxy(function (oData) {
				var aSearchTimeType = {};
				if (oData) {
					aSearchTimeType = oData;
					oDelegate.onSearchHelpTimeTypeLoad(aSearchTimeType);
				}
			}, this);
			var fnCallError = jQuery.proxy(function (oError) {
				oDelegate.onCrewTimeError(oError);
			}, this);
			OnlineDataProvider._readSearchHelpTimeType(oDelegate, oCrew, fnCallBack, fnCallError);
		},
		SendTime: function (oDelegate, aCrewTime, aAction) {
			var fnCallBack = jQuery.proxy(function (oData) {
				oDelegate.onSaveTimeSuccess(aAction);
			}, this);
			var fnCallError = jQuery.proxy(function (oData) {
				oDelegate.onCrewTimeErrors(oData);
			}, this);
			OnlineDataProvider._SaveTime(oDelegate, aCrewTime, fnCallBack, fnCallError);
		},

		loadSearchHelpCrewId: function (oDelegate, oJobCode) {
			var fnCallBack = jQuery.proxy(function (oData) {
				var aSearchHelpCrewId = {};
				if (oData) {
					aSearchHelpCrewId = oData;
			
				oDelegate.onSearchHelpCrewIdLoad(aSearchHelpCrewId);
				}
			}, this);
			var fnCallError = jQuery.proxy(function (oError) {
				oDelegate.onCrewListError(oError);
			}, this);
			OnlineDataProvider._readSearchHelpCrewId(oDelegate, oJobCode, fnCallBack, fnCallError);
		},
		loadSearchHelpProjCode: function (oDelegate) {
			var fnCallBack = jQuery.proxy(function (oData) {
				var aSearchHelpProjCode = {};
				if (oData) {
					aSearchHelpProjCode = oData;
					oDelegate.onSearchHelpProjCodeLoad(aSearchHelpProjCode);
				}
			}, this);
			var fnCallError = jQuery.proxy(function (oError) {
				oDelegate.onCrewListError(oError);
			}, this);
			OnlineDataProvider._readSearchHelpProjCode(oDelegate, fnCallBack, fnCallError);
		},

	};
});