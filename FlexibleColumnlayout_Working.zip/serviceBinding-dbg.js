function initModel() {
	var sUrl = "/sap/opu/odata/sap/ZE7011_TIME_ENTRY_NEW_SRV/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}