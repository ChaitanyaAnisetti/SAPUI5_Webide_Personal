sap.ui.define(["sap/ui/core/format/DateFormat",
		"mytime/ZMOB_MY_TIME_Redesign/js/Constants"
		//	"ZMOB_CREW_TIME/js/Utilities"

	],

	function (DateFormat, Constant) {
		"use strict";
		return {

			ButtonText: function (oText) {
				return oText === "Add Cost Code" + "\n" + "to selected Employee";
			},

			editable: function (a) {
				return a === "" ? false : true;

			},
			Status: function (aStatus) {
				if (aStatus === "Approved") {
					return sap.ui.core.ValueState.Success;
				}
				if (aStatus === "None") {
					return sap.ui.core.ValueState.Error;
				} else {
					return sap.ui.core.ValueState.Warning;
				}

			},
			Editable: function (a) {
				if (a !== undefined && a !== "" && a !== null) {
					return true;
				} else {
					return false;
				}

				//	return a === "" ? false : true;

			}
		

		};
	});