sap.ui.define(["sap/ui/core/format/DateFormat",
		"mytime/ZMOB_MY_TIME_Redesign/js/Constants",
		"mytime/ZMOB_MY_TIME_Redesign/js/Utilities"

	],

	function (DateFormat, Constant, Utilities) {
		"use strict";
		return {

			ButtonText: function (oText) {
				return oText === "Add Cost Code" + "\n" + "to selected Employee";
			},

			editable: function (a) {
				return a === "" ? false : true;

			},
			Status: function (aStatus) {
				if (aStatus === "Approved") {
					return sap.ui.core.ValueState.Success;
				}
				if (aStatus === "None") {
					return sap.ui.core.ValueState.Error;
				}
				if (aStatus === "Signed(Revised)") {
					return sap.ui.core.ValueState.Error;
				} else {
					return sap.ui.core.ValueState.Warning;
				}

			},
			Editable: function (a, b) {
				if (a !== undefined && a !== "00000000" && a !== null && b === "X") {
					return true;
				} else {
					return false;
				}
			},
			ValueState: function (a, b) {
				if (a !== undefined && a !== "00000000" && a !== null && b === "X") {
					return "Information";
				} else {
					return "None";
				}
			},
			Visible: function (a) {
				if (a !== undefined && a !== "00000000" && a !== null) {
					return true;
				} else {
					return false;
				}
			},
			VisibleHead: function (a) {
				if (a !== undefined && a !== "00000000" && a !== null) {
					return false;
				} else {
					return true;
				}
			},
			Type: function (a) {
				if (a !== undefined && a !== "00000000" && a !== null) {
					var b = "Number";
					return b;
				} else {
					var c = "Text";
					//var c = "Number";
					return c;
				}
			},
			getBooleanValue: function (Ans) {
				var boolAns = new sap.ui.model.type.Boolean();
				if (Ans === "true") {
					boolAns = true;
				} else {
					boolAns = false;
				}
				return boolAns;
			},
			CheckBoxValue: function (Value) {

				var boolAns = new sap.ui.model.type.Boolean();
				if (Value === "X") {
					boolAns = true;
				} else {
					boolAns = false;
				}
				return boolAns;
			},
			crewdescription: function (a, b, c) {
				if (c === 'OneColumn') {
					return a;
				} else {
					return a + ' (' + b + ')';

				}
			},
			commentIcon: function (a, b) {
				if (a === 'X') {
					return 'sap-icon://write-new-document';
				} else {
					return 'sap-icon://notification-2';
				}

			},

			commentIconColor: function (a, b) {
				if (a === 'X') {
					return 'Emphasized';
				} else {
					return 'Transparent';
				}

			},
			classIcon: function (a, b, c, d) {
				if (a === null || b === null || c === null || d === null || a === undefined || b === undefined || c === undefined || d === undefined) {
					return 'sap-icon://person-placeholder';
				} else {
					if (a === c && b === d) {
						return 'sap-icon://person-placeholder';
					} else {
						return 'sap-icon://customer-history';

					}

				}
			},
			classIconColor: function (a, b, c, d) {
				if (a === null || b === null || c === null || d === null || a === undefined || b === undefined || c === undefined || d === undefined) {
					return 'Transparent';
				} else {
					if (a === c && b === d) {
						return 'Transparent';
					} else {
						return 'Emphasized';

					}

				}
			},
			classIconEnabled: function (a, b, c, d, e, f, g, h) {
				//added by mashraf5 JIRA SAPC-5401 09.09.2022//
				var isTimeAdmin = false;
				var TimeAdmin = this.getOwnerComponent().getComponentData().startupParameters['AD'];
				if (TimeAdmin !== undefined && TimeAdmin !== null) {
					TimeAdmin = this.getOwnerComponent().getComponentData().startupParameters['AD'][0];
					if (TimeAdmin === "Y") {
						isTimeAdmin = true;
					}
				}
				// end of 09.09.2022 changes
				
				if (d !== undefined && d !== null && d !== "" && d === f && this.getView().getModel("app").getProperty("/timePageReadOnly") === true) {
					return false;
				}
				if (e !== undefined && e !== null && e !== "" && e === g && this.getView().getModel("app").getProperty("/timePageReadOnly") === true) {
					return false;
				}

				if (this.timeTypeCategory[a] === 'PD') {
					if (c !== undefined || c === 'X' && isTimeAdmin === true) { //added isTimeAdmin condition by mashraf5 JIRA SAPC-5401 09.09.2022//
						return true;
					} else {
						return false;
					}
				} else {
					//added by sdwived5 JIRA SAPC-5401 09.05.2022//
					//if (b !== undefined && b !== "" && b > 0 && this.getOwnerComponent().getComponentData().startupParameters['AD'][0] === "Y") {
				
					if (b !== undefined && b !== "" && b > 0 && isTimeAdmin === true) { //replaced condition by mashraf5 JIRA SAPC-5401 09.09.2022//
						return true;
					} else {
						return false;
					}
				}

			},
			classIconTooltip: function (a, b, c, d) {
				var sTooltipText = "";

				if (a !== undefined && a !== null && a !== "") {
					if (a !== c) {
						sTooltipText = "Class: " + a + "\n";
					}
				}
				if (b !== undefined && b !== null && b !== "") {
					if (b !== d) {
						sTooltipText = sTooltipText + "Craft: " + b;
					}
				}
				if (a === undefined && b === undefined) {
					//return "Class: "+c+" Craft: "+d;
					sTooltipText = "";
				}

				if (sTooltipText === "") {
					if (this.getView().getModel("app").getProperty("/timePageReadOnly") === true) {
						sTooltipText = "Different class not assigned";
					} else {
						sTooltipText = "Assign different Class";
					}
				}
				return sTooltipText;
			},

			classCodeSelection: function (a, b, c, d) {
				if (a === c && b === d) {
					return true;
				} else
					return false;
			},
			visiblePD: function (a, b) {
				if (this.timeTypeCategory[a] === 'PD') {
					return true;
				} else {
					return false;
				}
			},
			visibleHrs: function (a, b) {
				if (this.timeTypeCategory[a] === 'PD') {
					return false;
				} else {
					return true;
				}
			},
			selectedPDCheckbox: function (a, b) {
				if (a !== undefined && a !== 0) {
					return true;
				} else {
					return false;
				}
			},

			getBooleanStringType: function () {
				return sap.ui.model.SimpleType.extend("BooleanStringType", {
					formatValue: function (a) {
						if (a !== undefined && a !== 0 && a !== "" && a !== false) {
							return true;
						} else {
							return false;
						}
					},
					parseValue: function (a) {
						if (a !== undefined && a !== 0 && a !== false) {
							return 'X';
						} else {
							return '';
						}
					},
					validateValue: function (s) {}
				});
			},
			decimal: function (a) {
				return parseFloat(a).toFixed(2);
			},
			dateConversion: function (inputDate) {
				var dateString = inputDate;
				var year = "00";
				var month = "00";
				var day = "00";
				var date1;
				if (dateString !== undefined && dateString !== null && dateString !== "") {
					if (dateString.length === 10 && dateString.indexOf("-") > -1) {
						const [year, month, day] = dateString.split('-');
						date1 = [month, day, year].join('/');
						return date1;
					} else {
						year = +dateString.substring(0, 4);
						month = +dateString.substring(4, 6);
						day = +dateString.substring(6, 8);
						date1 = new Date(year, month - 1, day);
						var date = new Date(date1);
						if (!isNaN(date.getTime())) {
							// Months use 0 index.
							return date.getMonth() + 1 + '/' + date.getDate() + '/' + date.getFullYear();
						}
					}

				}
			},
			_date: function (aValue) {
				if (aValue) {

					//var oDateFormat = DateFormat.getDateInstance();// also getDateTimeInstance() exist
					//var oDate = oDateFormat.format(new Date());

					var oDateFormat = DateFormat.getDateInstance({
						pattern: "MM/dd/yyyy"
					});
					var d = new Date(aValue);
					// d.setMinutes(d.getMinutes() + d.getTimezoneOffset());
					return oDateFormat.format(d);
				} else {
					return aValue;
				}
			},
		};
	});