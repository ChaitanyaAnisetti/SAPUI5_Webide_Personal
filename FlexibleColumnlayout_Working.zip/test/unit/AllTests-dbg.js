sap.ui.define([
	"mytime/ZMOB_MY_TIME_Redesign/test/unit/controller/View1.controller"
], function () {
	"use strict";
});