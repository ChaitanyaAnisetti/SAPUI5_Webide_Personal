/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"mytime/ZMOB_MY_TIME_Redesign/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});