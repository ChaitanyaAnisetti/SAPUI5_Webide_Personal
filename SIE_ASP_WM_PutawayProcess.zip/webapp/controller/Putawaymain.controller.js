sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageBox',
	'sap/m/MessagePopover',
	'sap/m/MessageItem',
	"sap/ui/model/json/JSONModel",
	"sap/ndc/BarcodeScanner",
		"sap/m/library"
], function (Controller, MessageBox, MessagePopover, MessageItem, JSONModel, BarcodeScanner, mobileLibrary) {
	"use strict";

	return Controller.extend("putaway.SIE_ASP_WM_PutawayProcess.controller.Putawaymain", {
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oFioriClient = this.getOwnerComponent().getFioriClient();
		
			this.oBusyDialog = new sap.m.BusyDialog();
		//	if(sap.ushell&&sap.ushell.Container){
			var Gid = sap.ushell.Container.getService("UserInfo").getId();
			//	var Gid = "Z004C4CT";
		   // var Gid = "Z003DXZR";
	var oViewModel = new JSONModel({
				isFioriClientAvailable: this.oFioriClient.isAvailable()
		//	isFioriClientAvailable:true
			});
			this.getView().setModel(oViewModel, "Putawaymain");
			var path1 = "/UserDefaultSet('" + Gid + "')";
			this.oBusyDialog.open();
			this.getOwnerComponent().getModel("ASP_WM_PUTAWAY").read(path1, {
				success: function (oData, oResponse) {

					if (oData.MsgType === "S") {
						this.WarehouseNo = oData.WarehouseNo;
						this.getOwnerComponent().getModel("localModel").setProperty("/LoginUserInfo", oData);
						//this.onCreateComponentForVboxLayout();
						this.oBusyDialog.close();
						if(!this.getView().byId("worklistGrid").getContent().length){
						this.onCreateGridLayout();
						}
					} else {
						this.oBusyDialog.close();
						sap.m.MessageBox.show(
							oData.MsgDesc, {
								icon: sap.m.MessageBox.Icon.ERROR,
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);
					}
				}.bind(this),
				error: function (err) {
					this.oBusyDialog.close();
					sap.m.MessageBox.show(
						"OData error in UserDefaultSet", {
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.CLOSE],
							onClose: function (oAction) {}
						}
					);

				}.bind(this)
			});
	oRouter.getRoute("Putawaymain").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function () {

			var Matyear = new Date().getFullYear();

			if (this.getOwnerComponent().getComponentData() && this.getOwnerComponent().getComponentData().startupParameters) {
				var startupParams = this.getOwnerComponent().getComponentData().startupParameters;
				//startupParams.Gid&&
				if (startupParams.MatYear && startupParams.MaterialNo && startupParams.WarehouseNo) {
					var WarehouseNo = startupParams.WarehouseNo[0];
					var Matyear = startupParams.MatYear[0];
					var oMatNo = startupParams.MaterialNo[0];
					var oMatItem = startupParams.MatItem[0];
					sap.ui.getCore().byId("oMatenoinput").setValue(oMatNo);
						sap.ui.getCore().byId("oMateIteminput").setValue(oMatItem);
					this._getMatDetail(WarehouseNo, Matyear, oMatNo, oMatItem);
				}
			}
			if (this.getOwnerComponent().getModel("localModel").getProperty("/pressBack") === "X") {
					sap.ui.getCore().byId("oMatenoinput").setValue("");
				sap.ui.getCore().byId("oMateIteminput").setValue("");
				var oPutawayMatModel = new JSONModel([]);
				this.getView().setModel(oPutawayMatModel, "oPutawayMatModel");
			} else {

			}
		      
		},
			onCreateGridLayout:function(){
			
			var that = this;
			var oGrid = this.getView().byId("worklistGrid");
				oGrid.destroyContent();
			var  oMaterialdocInput,oMaterialiteminput,that = this;
		
			
		
			var VBoxMatedocno = new sap.m.VBox();
			VBoxMatedocno.destroyItems();
			 VBoxMatedocno.addItem(
									new sap.m.ObjectIdentifier({
										title:"Mat.Doc.No",
										titleActive:false
									}) 
			); 
			
			var VBoxMateitem = new sap.m.VBox();
			VBoxMateitem.destroyItems();
			VBoxMateitem.addItem(
									new sap.m.ObjectIdentifier({
										title:"Mat.Item",
										titleActive:false
									}) 
			);
			/*	var VBoxScan = new sap.m.VBox();
				VBoxScan.destroyItems();
			VBoxScan.addItem(
									new sap.m.ObjectIdentifier({
										title:"",
										titleActive:false
									}).addStyleClass("sapUiTinyMarginBottom")
			);*/
		
			if(this.getView().getModel("Putawaymain").getProperty("/isFioriClientAvailable"))
			{
				if(sap.ui.getCore().byId("oMatenoinput")){
					sap.ui.getCore().byId("oMatenoinput").destroy(true);
				}
				oMaterialdocInput = new sap.m.Input("oMatenoinput",{
											enabled :true,
											editable:true,
											value:"",
											showValueHelp:true,
											valueHelpOnly:false,
											width:"60%",
											change:function(ovt){
												that.onChangeMaterialdoc(ovt);
											},
											liveChange:function(ovt)
			                                {
			                                		that.onlivechekvalueMaterialdoc(ovt);
			                                },
											valueHelpRequest:function(ovt){
												that.onBarCodeScanInputFields(ovt,"materialDoc");
											}
										}).addEventDelegate({
													onfocusin: function(oEvt) 
													{ 
														var oComId = oEvt.srcControl.getId();
														jQuery("#"+oComId).scannerDetection({
																		timeBeforeScanTest: 200, // wait for the next character for upto 200ms
																		//startChar: [120], // Prefix character for the cabled scanner (OPL6845R)
																		endChar: [13], // be sure the scan is complete if key 13 (enter) is detected
																		avgTimeByChar: 40, // it's not a barcode if a character takes longer than 40ms
																		onComplete: function(barcode, qty)
																		{
																			
																			var oArrstings;
																	    	oArrstings = barcode.split("|");
																	    	jQuery("#"+oEvt.srcControl.getId()).find('input').val("");
																	    	jQuery("#"+oEvt.srcControl.getId()).find('input').val(oArrstings[2]);
																	    	if(sap.ui.getCore().byId("oMateIteminput")){
																	    			jQuery("#oMateIteminput").find('input').val("");
																	    	jQuery("#oMateIteminput").find('input').val(oArrstings[3]);
																	    	}
							
																		}, // main callback function
																		onError: function(string){ 
																			//console.log("Error:" + string);
																		}
														});
														
													},
													onsapfocusleave: function(oEvt) { 
														var oComId = oEvt.srcControl.getId();
														jQuery("#"+oComId).scannerDetection(false);
													}
											});
				oMaterialdocInput._getValueHelpIcon().setSrc("sap-icon://bar-code");
				VBoxMatedocno.addItem(oMaterialdocInput);
				
				
					if(sap.ui.getCore().byId("oMateIteminput")){
					sap.ui.getCore().byId("oMateIteminput").destroy(true);
				}
				oMaterialiteminput = new sap.m.Input("oMateIteminput",{
											enabled :true,
											editable:true,
											width:"50%",
											value:"",
											showValueHelp:true,
											valueHelpOnly:false,
											change:function(ovt){
												that.onChangeMaterialitem(ovt);
											},
											
											liveChange:function(ovt)
			                                {
			                                		that.onlivechekvalueMaterialitem(ovt);
			                                },
											valueHelpRequest:function(ovt){
												that.onBarCodeScanInputFields(ovt,"materialItem");
											}
										}).addEventDelegate({
													onfocusin: function(oEvt) 
													{ 
														var oComId = oEvt.srcControl.getId();
														jQuery("#"+oComId).scannerDetection({
																		timeBeforeScanTest: 200, // wait for the next character for upto 200ms
																		//startChar: [120], // Prefix character for the cabled scanner (OPL6845R)
																		endChar: [13], // be sure the scan is complete if key 13 (enter) is detected
																		avgTimeByChar: 40, // it's not a barcode if a character takes longer than 40ms
																		onComplete: function(barcode, qty)
																		{
																			
																			var oArrstings;
																	    	oArrstings = barcode.split("|");
																	    	jQuery("#"+oEvt.srcControl.getId()).find('input').val("");
																	    	jQuery("#"+oEvt.srcControl.getId()).find('input').val(oArrstings[3]);
																	    	
							
																		}, // main callback function
																		onError: function(string){ 
																			//console.log("Error:" + string);
																		}
														});
														
													},
													onsapfocusleave: function(oEvt) { 
														var oComId = oEvt.srcControl.getId();
														jQuery("#"+oComId).scannerDetection(false);
													}
											});
				oMaterialiteminput._getValueHelpIcon().setSrc("sap-icon://bar-code");
				VBoxMateitem.addItem(oMaterialiteminput);

			/*	var oScanButton=	new sap.m.Button({
					                                  
			                                			text:"Scan",
			                                				type:"Emphasized",
			                                				iconFirst:true,
			                                				tooltip:"Scan",
			   			                                				press:function(evt){
			                          
			                                					that.onBarCodeScan(evt);
			                                				}
			                                			}).addStyleClass("sapUiTinyMarginTop")
				VBoxScan.addItem(oScanButton);	*/
			}else{
				if(sap.ui.getCore().byId("oMatenoinput")){
					sap.ui.getCore().byId("oMatenoinput").destroy(true);
				}
					if(sap.ui.getCore().byId("oMateIteminput")){
					sap.ui.getCore().byId("oMateIteminput").destroy(true);
				}
				oMaterialdocInput = new sap.m.Input("oMatenoinput",{value:"",width:"60%"});
				VBoxMatedocno.addItem(oMaterialdocInput);
				oMaterialiteminput = new sap.m.Input("oMateIteminput",{value:"",width:"50%"});
				VBoxMateitem.addItem(oMaterialiteminput);
				/*	var oScanButton=	new sap.m.Button({
					                                   
			                                			text:"Scan",
			                                				type:"Emphasized",
			                                				iconFirst:true,
			                                				tooltip:"Scan",
			   			                                				press:function(evt){
			                          
			                                					that.onBarCodeScan(evt);
			                                				}
			                                			}).addStyleClass("sapUiTinyMarginTop")
				VBoxScan.addItem(oScanButton);	*/
			}
			oGrid.destroyContent();
		
			oGrid.addContent(VBoxMatedocno);
			oGrid.addContent(VBoxMateitem);
		//	oGrid.addContent(VBoxScan);
			
		},
			onChangeMaterialdoc:function(oEvent){
				
				var sFValue = "";
					sFValue = oEvent.getSource().getValue();
				var	sSourceControl = oEvent.getSource(); 
				if(sFValue.length <= 18){
					sSourceControl.setValueState("None");	
				}else if (sFValue.length > 18){
					sSourceControl.setValueState("Error");
					sap.m.MessageToast.show("Material document no. max length is 18");
				}
					
		},
		
		onlivechekvalueMaterialdoc:function(oEvent){
			var that = this;
				var sFValue = "";
					sFValue = oEvent.getSource().getValue();
				var	sSourceControl = oEvent.getSource(); 

					if(sFValue.length > 0 ) 
					{
							sap.ui.getCore().byId(oEvent.getSource().getId()).onsapenter = function(e)
							{
									
									if(sFValue.slice(0,3) === "]d2") 
									{
											sap.m.MessageBox.warning("Please scan valid QR code");
									//	that.onDecodeStringtoValue(sSourceControl,sFValue);
										sSourceControl.setValue("");
									}else
									{  /// read QR Code..
										var oArrstings=sFValue.split("|");
										if(oArrstings.length > 1 &&  oArrstings[2])
										{
											sSourceControl.setValue("");
							    			sSourceControl.setValue(oArrstings[2]);
							    			if(sap.ui.getCore().byId("oMateIteminput")){
							    					sap.ui.getCore().byId("oMateIteminput").setValue("");
							    				sap.ui.getCore().byId("oMateIteminput").setValue(oArrstings[3]);
							    			}
							    			that.onChangeMaterialdoc(new sap.ui.base.Event("PutawaymateDoc", sSourceControl, {}));
										}else if(oArrstings.length === 1){
											sSourceControl.setValue("");
							    			sSourceControl.setValue(oArrstings[0]);
							    				if(sap.ui.getCore().byId("oMateIteminput")){
							    					sap.ui.getCore().byId("oMateIteminput").setValue("");
							    			//	sap.ui.getCore().byId("oMateIteminput").setValue(oArrstings[3]);
							    			}
							    			that.onChangeMaterialdoc(new sap.ui.base.Event("PutawaymateDoc", sSourceControl, {}));
										}
										
										
									}
									
							};
					}
		},
			onDecodeStringtoValue:function(oComponent,oStrings){
			//sap.m.MessageToast.show("onDecoder funciton");
			if(oStrings !== "" && oStrings.slice(0, 3) === "]d2")
			{
				sap.m.MessageBox.warning("Please scan valid QR code");
			/* 
					sap.m.MessageBox.information("I/p Livchange Init Result:"+" "+oStirngs);
				var objArray = parseBarcode(oStrings).parsedCodeItems;
					sap.m.MessageBox.information("I/p Livchange After Barcode Parse Result:"+" "+JSON.stringify(objArray));
				var obj = jQuery.grep(objArray, function(e){return e.ai === "91";})[0];
					sap.m.MessageBox.information("I/p Livchange Final Result:"+" "+ JSON.stringify(obj));
				if(obj && obj.data && obj.data.length > 0 )
				{
					
					oComponent.setValue(obj.data);
					this.onChangeMaterialNumber(new sap.ui.base.Event("PutawaymateDoc", oComponent, {}));			
				}else
				{
					if(obj === undefined){
						sap.m.MessageToast.show("AI 91 not found in barcode");
						oComponent.setValue("");
					}
									
					if(obj.data && obj.data.length === 0){
						sap.m.MessageToast.show("Material number value not found in barcode");
						oComponent.setValue("");
					}
				}*/
			}
		},
			onChangeMaterialitem:function(oEvent){
			var sFValue = "";
					sFValue = oEvent.getSource().getValue();
				var	sSourceControl = oEvent.getSource(); 
				if(sFValue.length <= 6)
				{
					sSourceControl.setValueState("None");	
				}else if (sFValue.length > 6)
				{
					sSourceControl.setValueState("Error");
					sap.m.MessageToast.show("Material item max length is 6");
				}
		},
		onlivechekvalueMaterialitem:function(oEvent){
			var that = this;
				var sFValue = "";
					sFValue = oEvent.getSource().getValue();
				var	sSourceControl = oEvent.getSource(); 

					if(sFValue.length > 0 ) 
					{
							sap.ui.getCore().byId(oEvent.getSource().getId()).onsapenter = function(e)
							{
									var oArrstings;
									oArrstings = sFValue.split("|");
									sSourceControl.setValue("");
									sSourceControl.setValue(oArrstings[3]);//special stock.
								/*	if(sap.ui.getCore().byId("oMatenoinput")){
										sap.ui.getCore().byId("oMatenoinput").setValue(oArrstings[2]);
									}*/
									that.onChangeMaterialitem(new sap.ui.base.Event("PutawaymateItem", sSourceControl, {}));	
								
							};
					}
		},
		/*	onCreateComponentForVboxLayout:function(){
			var oProductionOrderInput,that = this;
			var VBoxProductionOrder1 = this.getView().byId("VBoxProductionOrder1");
			VBoxProductionOrder1.destroyItems();
		
			
				
			oProductionOrderInput = new sap.m.MultiInput("filterProductionOrder",{
										showValueHelp:true,
										valueHelpOnly:true,
										valueHelpRequest:function(ovt){
											that.onBarCodeScan(ovt);
										}
					
			}).addEventDelegate({
									onfocusin: function(oEvt) 
									{ 
										var oComId = oEvt.srcControl.getId();
									
										
										jQuery("#"+oComId).scannerDetection
										({
												timeBeforeScanTest: 200, // wait for the next character for upto 200ms
												startChar: [120], // Prefix character for the cabled scanner (OPL6845R)
												endChar: [13], // be sure the scan is complete if key 13 (enter) is detected
												avgTimeByChar: 40, // it's not a barcode if a character takes longer than 40ms
												onComplete: function(barcode, qty)
												{
													if(barcode !== ""){						
														sap.ui.getCore().byId("filterProductionOrder").addToken(
																		new sap.m.Token({
														   						key: barcode,
														   						text: barcode
														   					})
														);
													}
											 	    sap.ui.getCore().byId("filterProductionOrder").focus();
												}, // main callback function
												onError: function(string){ 
												alert("error message")
												}
											});
														
									},
									onsapfocusleave: function(oEvt) { 
										var oComId = oEvt.srcControl.getId();
										jQuery("#"+oComId).scannerDetection(false);
									}
								});
			oProductionOrderInput._getValueHelpIcon().setSrc("sap-icon://bar-code");
			VBoxProductionOrder1.addItem(oProductionOrderInput);*/

		/*	var oButton = new sap.m.Button({
				icon:"sap-icon://bar-code",
				tooltip:"{i18n>BarcodeScanning}",
				width : sap.ui.Device.system.phone ? "100%" : "25%",
				type:"Emphasized",
				press:function(oEvt){that.onBarCodeScan(oEvt);}
			});*/
		//	VBoxProductionOrder1.addItem(oButton);
		/*	oProductionOrderInput.addValidator(function(args){
				return new sap.m.Token({key: args.text, text: args.text});
			});
		},*/
		onClearpress: function () {
				sap.ui.getCore().byId("oMatenoinput").setValue("");
			sap.ui.getCore().byId("oMateIteminput").setValue("");
			var oPutawayMatModel = new JSONModel([]);
			this.getView().setModel(oPutawayMatModel, "oPutawayMatModel");

		},

		onFilterpress: function () {
			//	var WarehouseNo = "A04";
			//		var WarehouseNo;

			var Matyear = new Date().getFullYear();

			var WarehouseNo = this.WarehouseNo;
			var oMatNo = sap.ui.getCore().byId("oMatenoinput").getValue();
			var oMatItem = sap.ui.getCore().byId("oMateIteminput").getValue();
			this._getMatDetail(WarehouseNo, Matyear, oMatNo, oMatItem);
		},
		_getMatDetail: function (WarehouseNo, Matyear, oMatNo, oMatItem) {
				/*if (oMatNo === "" || oMatItem === "") {
					sap.m.MessageBox.show(
						"Please enter required values", {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error",
							actions: [sap.m.MessageBox.Action.CLOSE],
							onClose: function (oAction) {}

						}
					);
					var oPutawayMatModel = new JSONModel([]);
					this.getView().setModel(oPutawayMatModel, "oPutawayMatModel");
				} else {
					if (oMatNo && oMatItem) {*/
			this.oBusyDialog.open();

			var sTr = "WarehouseNo eq '" + WarehouseNo + "'and  Matdoc eq '" + oMatNo + "'and Matyear eq '" + Matyear +
				"'and Matitem eq '" + oMatItem + "'";
			var oBindingInfo = {
				filters: null,
				urlParameters: {
					"$filter": sTr
				},
				success: function (oData, oResponse) {
					this.oBusyDialog.close();

					if (oResponse.data.results[0].MsgType1 === "S" || oResponse.data.results[0].MsgType1 === "") {
						var oPutawayMatModel = new JSONModel(oData.results);
						this.getView().setModel(oPutawayMatModel, "oPutawayMatModel");
					} else {
						var oPutawayMatModel = new JSONModel([]);
						this.getView().setModel(oPutawayMatModel, "oPutawayMatModel");
						sap.m.MessageBox.show(
							oResponse.data.results[0].MsgDesc, {
								icon: sap.m.MessageBox.Icon.ERROR,
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {

								}

							}
						);
					}
				}.bind(this),
				error: function (oError) {

					this.oBusyDialog.close();
					sap.m.MessageBox.error("Error");
				}.bind(this)
			};

			this.getOwnerComponent().getModel("ASP_WM_PUTAWAY").read("/Putaway_listSet", oBindingInfo);

			/*	}*/
			/*	}*/
		},
		onBarCodeScan: function () {

		if (cordova && cordova.plugins && cordova.plugins.barcodeScanner) {
				var that = this;
				cordova.plugins.barcodeScanner.scan(function (format) {
					var data = format;
					if(data.text&&data.cancelled==false){
					var Matyear = data.text.split("|")[1];
					var Matdocno = data.text.split("|")[2];
					var Matitem = data.text.split("|")[3];
				
					var WarehouseNo = that.WarehouseNo;
					sap.ui.getCore().byId("oMatenoinput").setValue(Matdocno);
					sap.ui.getCore().byId("oMateIteminput").setValue(Matitem);
					that._getMatDetail(WarehouseNo, Matyear, Matdocno, Matitem);
}
 else if (data.cancelled) {
				sap.m.MessageToast.show("Scan Cancelled");
			}
				}, function (error) {
					var a = error;
				}, {
					formats: "QR_CODE,PDF_417"
				});
			} else {
				BarcodeScanner.scan(
					this.onScanSuccess.bind(this),
					this.Error.bind(this)/*, {
						formats: "QR_CODE,PDF_417"
					}*/
				);
		 }
		},
		// onSuccess Callback 
		onScanSuccess: function (result) {
			var bCancelled = result.cancelled;
			sap.ui.getCore().byId("oMatenoinput").setValue("");
				sap.ui.getCore().byId("oMateIteminput").setValue("");
			if (result.text && bCancelled == false) {
				//	var WarehouseNo = "A04";
				var WarehouseNo = this.WarehouseNo;
				var Matyear = result.text.split("|")[0];
				var Matdocno = result.text.split("|")[1];
				var Matitem = result.text.split("|")[2];
					sap.ui.getCore().byId("oMatenoinput").setValue(Matdocno);
					sap.ui.getCore().byId("oMateIteminput").setValue(Matitem);
				this._getMatDetail(WarehouseNo, Matyear, Matdocno, Matitem);
			} else if (bCancelled) {
				sap.m.MessageToast.show("Scan Cancelled");
			}

		},
			onBarCodeScanInputFields: function(oEvent,oCustomData) 
		{
				 this.destinationtype = "";
				 this.destinationtype = oCustomData;
				 this.desctinationCntl = oEvent.getSource();
				
				BarcodeScanner.scan(
						this.onSuccess.bind(this),
						this.onError.bind(this)
				);
		},
			// onSuccess Callback 
		onSuccess: function(result) {
					var bCancelled = result.cancelled;
					this.onRetrieveStingFromScannerInfo(result.text);
					
					if (bCancelled) {
						sap.m.MessageToast.show("Scan Cancelled");
						this.desctinationCntl.setValueHelpOnly(false);  // cancel button pressed. allow user to input manually.
					}
		},
		// onError Callback
		onError: function(error) {
					sap.m.MessageToast.show(error, "Error");
		},
	onRetrieveStingFromScannerInfo:function(oStirngs) {
			
				var oArrstings;
				switch(this.destinationtype) {
				 
				  case "materialDoc":
				  		
			
				  		if(oStirngs.slice(0,1) === "\x1D")
						{
						sap.m.MessageBox.warning("Please scan valid QR code");
							this.desctinationCntl.setValue("");
						/*	var oResult ="]Q3"+oStirngs.replaceAll("\x1D","|");
							var objArray = parseBarcode(oResult).parsedCodeItems;
							sap.m.MessageBox.information("After Barcode Parse Result:"+" "+JSON.stringify(objArray));
							var obj = jQuery.grep(objArray, function(e){return e.ai === "91";})[0];
								sap.m.MessageBox.information("Final Result:"+" "+ JSON.stringify(obj));
							if(obj && obj.data && obj.data.length > 0 )
							{
								this.desctinationCntl.setValue(obj.data);
								this.onChangeMaterialdoc(new sap.ui.base.Event("PutawaymateDoc", this.desctinationCntl, {}));
												
							}else
							{
								if(obj === undefined){
									sap.m.MessageToast.show("AI 91 not found in barcode");
									this.desctinationCntl.setValue("");
								}
												
								if(obj.data && obj.data.length === 0){
									sap.m.MessageToast.show("Material document not found in barcode");
									this.desctinationCntl.setValue("");
								}
							}*/
						}else{
							oArrstings = oStirngs.split("|");
							if(oArrstings.length > 1 &&  oArrstings[2]){
								this.desctinationCntl.setValue("");
				    			this.desctinationCntl.setValue(oArrstings[2]);
				    				if(sap.ui.getCore().byId("oMateIteminput")){
							    				sap.ui.getCore().byId("oMateIteminput").setValue(oArrstings[3]);
							    			}
				    			this.onChangeMaterialdoc(new sap.ui.base.Event("PutawaymateDoc", this.desctinationCntl, {}));
							}else if(oArrstings.length === 1){
								this.desctinationCntl.setValue("");
				    			this.desctinationCntl.setValue(oArrstings[0]);
				    			this.onChangeMaterialdoc(new sap.ui.base.Event("PutawaymateDoc", this.desctinationCntl, {}));
							}
							
						}
				  		
				    break;
				  case "materialItem":
				  		oArrstings = oStirngs.split("|");
				    	this.desctinationCntl.setValue("");
				    	this.desctinationCntl.setValue(oArrstings[3]);
				    	if(sap.ui.getCore().byId("oMatenoinput")){
				    	/*	sap.ui.getCore().byId("oMatenoinput").setValue("")
										sap.ui.getCore().byId("oMatenoinput").setValue(oArrstings[2]);
									}*/
				    	}
				    	this.onChangeMaterialitem(new sap.ui.base.Event("PutawaymateItem", this.desctinationCntl, {}));	
				    break;
				  default:
				    // code block
				}
		},
		// onError Callback
		onError: function (error) {
			sap.m.MessageToast.show(error, "Error");
		},
		onConfirmationActionPress: function (oEvent) {
			var oSelectedObject = oEvent.getSource().getParent().getBindingContext("oPutawayMatModel").getObject();
			this.getOwnerComponent().getModel("localModel").setProperty("/pressBack", "");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("PutawayConfirmto", {
				Material: oSelectedObject.Material,
				WarehouseNo: oSelectedObject.WarehouseNo,
				Matdoc: oSelectedObject.Matdoc,
				Matyear: oSelectedObject.Matyear,
				TOitem: oSelectedObject.TOitem,
				TOno: oSelectedObject.TOno

			});

		}
	});
});