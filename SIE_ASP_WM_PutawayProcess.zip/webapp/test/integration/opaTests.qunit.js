/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"putaway/SIE_ASP_WM_PutawayProcess/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});