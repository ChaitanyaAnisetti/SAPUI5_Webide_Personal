sap.ui.define([
	"YMM_POOVP_Cust/YMM_POOVP_Cust/test/unit/controller/View1.controller"
], function () {
	"use strict";
});