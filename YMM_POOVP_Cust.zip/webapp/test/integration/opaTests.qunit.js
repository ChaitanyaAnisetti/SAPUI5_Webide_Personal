/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"YMM_POOVP_Cust/YMM_POOVP_Cust/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});