function initModel() {
	var sUrl = "/Gateway_CGD/sap/opu/odata/sap/YMM_PO_GR_INV_COUNT_CDS/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}