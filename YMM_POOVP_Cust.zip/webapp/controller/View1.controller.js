  sap.ui.define([
  	"sap/ui/core/mvc/Controller"

  ], function (Controller) {
  	"use strict";

  	return Controller.extend("YMM_POOVP_Cust.YMM_POOVP_Cust.controller.View1", {
  		onInit: function () {

  			this.oBindyear();
  			this.oDialog = this.byId("BusyDialog");
  			this.oDialog.open(3000);
  			this.oDialog.setBusy(true);
  			this._onModel1load();
  			//	this._onModel2load();
  			this.oDialog.setBusy(false);
  			this.oDialog.close();

  		},
  		oBindyear: function () {

  			var d = new Date();
  			var Monthdata = [{
  				"month": "January",
  				"key": 0
  			}, {
  				"month": "February",
  				"key": 1
  			}, {
  				"month": "March",
  				"key": 2
  			}, {
  				"month": "April",
  				"key": 3
  			}, {
  				"month": "May",
  				"key": 4
  			}, {
  				"month": "June",
  				"key": 5
  			}, {
  				"month": "July",
  				"key": 6
  			}, {
  				"month": "August",
  				"key": 7
  			}, {
  				"month": "September",
  				"key": 8
  			}, {
  				"month": "October",
  				"key": 9
  			}, {
  				"month": "November",
  				"key": 10
  			}, {
  				"month": "December",
  				"key": 11
  			}];

  			if (d.getMonth() >= 3) {
				var yeararray = [];
				var n = (d.getFullYear());
				for (var i = 0; i < 3; i++) {
					var obj = {};
					obj.year = n - i;
					yeararray.push(obj);
				}
				var yearmodel = new sap.ui.model.json.JSONModel();
				yearmodel.setData(yeararray);
				this.getView().byId("MoyearCombo").setModel(yearmodel);
				this.getView().byId("MoyearCombo").setSelectedKey(d.getFullYear());
				this.getView().byId("MoyearCombo").setSelectedItem(d.getFullYear());

			} else {
				var yeararray = [];
				var n = (d.getFullYear());
				for (var i = 0; i < 3; i++) {
					var obj = {};
					obj.year = n - i;
					yeararray.push(obj);
				}
				var yearmodel = new sap.ui.model.json.JSONModel();
				yearmodel.setData(yeararray);
				this.getView().byId("MoyearCombo").setModel(yearmodel);
				this.getView().byId("MoyearCombo").setSelectedKey(d.getFullYear() - 1);
				this.getView().byId("MoyearCombo").setSelectedItem(d.getFullYear() - 1);

			}

  		},
  		_onModel1load: function ()

  		{
  			//	var oDialog = this.byId("BusyDialog");
  			this.oDialog.open();
  			this.oDialog.setBusy(true);
  			this.oDialog.setBusyIndicatorDelay(3000);
  			var oUrl = "/sap/opu/odata/sap/YMM_PO_STATUS_DATA_CDS";
  			var that = this;
  			that.oYear = that.getView().byId("MoyearCombo")._getSelectedItemText();
  			var oModel2 = new sap.ui.model.json.JSONModel();
  			oModel2.setSizeLimit(10000);
  			this.getView().setModel(oModel2, "oStackedModel");
  			that.oDataModel2 = new sap.ui.model.odata.ODataModel(oUrl, true);
  			var path2 = "/ymm_PO_STATUS_DATA(p_fiscalyear='" + that.oYear + "')/Set";
  			that.oDataModel2.read(path2, null, null, false, function (oData, oResponse) {
  					var Data = oData.results;

  					if (Data) {
  						var months = ["April", "May", "June",
  							"July", "August", "September", "October", "November", "December", "January", "February", "March"
  						];
  						Data.sort(function (a, b) {
  							return months.indexOf(a.monthname) - months.indexOf(b.monthname);
  						});

  					}

  					that.getView().getModel("oStackedModel").setData(Data);
  					that._oVizFrame();
  					that._onModel2load();
  					that.oDialog.setBusy(false);
  					that.oDialog.close();

  				}.bind(this),
  				function (oData, oResponse) {}

  			);

  		},
  		_onModel2load: function () {
  			var oUrl2 = "/sap/opu/odata/sap/YMM_PO_GR_INV_COUNT_CDS";
  			var that = this;
  			that.oYear2 = that.getView().byId("MoyearCombo")._getSelectedItemText();
  			var oModel3 = new sap.ui.model.json.JSONModel();
  			oModel3.setSizeLimit(10000);
  			this.getView().setModel(oModel3, "oStackedModel2");
  			this.oDataModel3 = new sap.ui.model.odata.ODataModel(oUrl2, true);
  			var path3 = "/YMM_PO_GR_INV_COUNT(p_fiscalyear='" + that.oYear2 + "')/Set";
  			this.oDataModel3.read(path3, null, null, false, function (oData, oResponse) {
  				var Data = oData.results;
  				//	that.oBusyDialog.close();
  				if (Data) {
  					var months = ["April", "May", "June",
  						"July", "August", "September", "October", "November", "December", "January", "February", "March"
  					];
  					Data.sort(function (a, b) {
  						return months.indexOf(a.Monthname) - months.indexOf(b.Monthname);
  					});
  					//	that.getView().byId("oisdViame").getModel("oStackedModel2").setData(Data);
  					that.getView().byId("oisdViame").getModel("oStackedModel2").setData(Data);
  					that._oVizFrame2();

  				}
  			});

  		},
  		onYearChange: function () {

  			this._onModel1load();
  			//	this._onModel2load();

  		},

  		_oVizFrame: function () {

  			var oVizFrame = this.getView().byId("oisdViframe");
  			oVizFrame.setVizProperties({
  				plotArea: {
  					colorPalette: d3.scale.category20().range(),
  					dataLabel: {
  						showTotal: true
  					}
  				},
  				tooltip: {
  					visible: true
  				},
  				title: {
  					text: "PO Value Status"
  				}
  			});
  			var oDataset = new sap.viz.ui5.data.FlattenedDataset({
  				dimensions: [{
  					name: "Month Name",
  					value: "{oStackedModel>monthname}"
  				}],

  				measures: [{
  					name: "PO",
  					value: "{oStackedModel>NetValue}"
  				}, {
  					name: "GR",
  					value: "{oStackedModel>deliveredvalue}"
  				}, {
  					name: "Invoice",
  					value: "{oStackedModel>invoicevalue}"
  				}],

  				data: {
  					path: "oStackedModel>/"
  				}
  			});
  			oVizFrame.setDataset(oDataset);
  			oVizFrame.destroyFeeds();

  			oVizFrame.setModel(this.getView().getModel("oStackedModel"));

  			var oFeedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
  					"uid": "valueAxis",
  					"type": "Measure",
  					"values": ["PO"]

  				}),

  				oFeedValueAxis2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
  					"uid": "valueAxis",
  					"type": "Measure",
  					"values": ["GR"]

  				}),
  				oFeedValueAxis1 = new sap.viz.ui5.controls.common.feeds.FeedItem({
  					"uid": "valueAxis",
  					"type": "Measure",
  					"values": ["Invoice"]
  				}),

  				oFeedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
  					"uid": "categoryAxis",
  					"type": "Dimension",
  					"values": ["Month Name"]
  				});

  			oVizFrame.addFeed(oFeedValueAxis);

  			oVizFrame.addFeed(oFeedValueAxis2);
  			oVizFrame.addFeed(oFeedValueAxis1);
  			oVizFrame.addFeed(oFeedCategoryAxis);
  			var oPopOver = this.getView().byId("idopOver");
  			oPopOver.connect(oVizFrame.getVizUid());
  		},
  		_oVizFrame2: function () {
  			var oVizFrame2 = this.getView().byId("oisdViame");
  			oVizFrame2.setVizProperties({
  				plotArea: {
  					colorPalette: d3.scale.category20().range(),
  					//	colorPalette:["#7794b8",'#e82c2c', '#3c8049'],
  					//	colorPalette:["#7794b8",'#db6960', '#7ddb8a'],

  					/*	middel col - #b53351*/

  					dataLabel: {
  						showTotal: true

  					},
  					secondaryScale: {
  						fixedRange: true,
  						minValue: 0

  					}
  				},
  				tooltip: {
  					visible: true
  				},
  				title: {
  					text: "PO Count Status"
  				}
  			});
  			var oDataset2 = new sap.viz.ui5.data.FlattenedDataset({
  				dimensions: [{
  					name: "Month Name",
  					value: "{oStackedModel2>Monthname}"

  				}],

  				measures: [{
  					name: "PO COUNT",
  					value: "{oStackedModel2>NETCOUNT}"
  				}, {
  					name: "GR COUNT",
  					value: "{oStackedModel2>GRCOUNT}"
  				}, {
  					name: "INV COUNT",
  					value: "{oStackedModel2>INVCOUNT}"
  				}],

  				data: {
  					path: "oStackedModel2>/"
  				}
  			});
  			oVizFrame2.setDataset(oDataset2);
  			oVizFrame2.destroyFeeds();

  			oVizFrame2.setModel(this.getView().getModel("oStackedModel2"));

  			var oFeedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
  					"uid": "valueAxis",
  					"type": "Measure",
  					"values": ["PO COUNT"]

  				}),
  				oFeedValueAxis1 = new sap.viz.ui5.controls.common.feeds.FeedItem({
  					"uid": "valueAxis",
  					"type": "Measure",
  					"values": ["GR COUNT"]
  				}),
  				oFeedValueAxis2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
  					"uid": "valueAxis",
  					"type": "Measure",
  					"values": ["INV COUNT"]
  				}),

  				oFeedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
  					"uid": "categoryAxis",
  					"type": "Dimension",
  					"values": ["Month Name"]

  				});

  			oVizFrame2.addFeed(oFeedCategoryAxis);
  			oVizFrame2.addFeed(oFeedValueAxis);
  			oVizFrame2.addFeed(oFeedValueAxis1);
  			oVizFrame2.addFeed(oFeedValueAxis2);
  			var oPopOver2 = this.getView().byId("idoOver");
  			oPopOver2.connect(oVizFrame2.getVizUid());

  		}

  	});
  });