sap.ui.define([


], function () {
    return sap.ui.controller("pps.manage.milestone.plan.ext.controller.ObjectPageExt", {
        onInit: function () {
        },
        onTemplateLoad: function () {
            if (!this._oDialog) {
                this._oDialog = sap.ui.xmlfragment("pps.manage.milestone.plan.ext.fragments.LoadTemplate", this);
                this.getView().addDependent(this._oDialog);
            }
            this._oDialog.open();

        },


        closeDialog: function () {
            this._oDialog.close();
        },
        okPress: function () {
            this._oDialog.close();
        }


    });
});

