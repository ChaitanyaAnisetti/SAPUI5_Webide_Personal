jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
jQuery.sap.require("sap.ui.qunit.qunit-coverage");
jQuery.sap.require("sap.ui.qunit.qunit-css");
QUnit.config.autostart = false;
QUnit.config.testTimeout = 150000;
sap.ui.require([
	"sap/ui/test/Opa5",
	"sap/ui/test/opaQunit",
	"pps/manage/milestone/plan/test/integration/pages/Common",
	"pps/manage/milestone/plan/test/integration/pages/ListReport",
	"sap/suite/ui/generic/template/integration/testLibrary/ListReport/pages/ListReport",

	"sap/suite/ui/generic/template/integration/testLibrary/ObjectPage/pages/ObjectPage"
], function (Opa5, opaQunit, Common, ListReport, ObjectPage) {
	"use strict";
	Opa5.extendConfig({
		autoWait: true,
		arrangements: new Common(),
		viewNamespace: "sap.suite.ui.generic.template.view.",
		appParams: {
			"sap-ui-animation": false
		},
		timeout: 200,
		testLibs: {
			fioriElementsTestLibrary: {
				Common: {
					appId: "pps.manage.milestone.plan",
					entitySet: "MilestonePlan"
				}
			}
		}
	});

	sap.ui.require([
		"pps/manage/milestone/plan/test/integration/ListReportJourney"
		//		"pps/manage/milestone/plan/test/integration/ObjectPageJourney"

		,
		"./ObjectPageJourney"
	], function () {
		//	QUnit.config.testTimeout = 200000;
		QUnit.start();
	});
});