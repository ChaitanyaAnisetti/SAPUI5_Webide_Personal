/*global QUnit*/

sap.ui.define([
	"sap/ui/test/opaQunit"
], function(opaTest) {
	"use strict";
	

	opaTest("I should be able to open the Milestone Plan app", function (Given, When, Then) {
	
		// Arrangements
		Given.iStartTheApp();

		When.onTheGenericListReport
			.iExecuteTheSearch();
		
		Then.onTheGenericListReport
			.theResultListIsVisible();	
	
	});
	opaTest("List Item Pressed", function (Given, When, Then) {
		When.onTheGenericListReport
			.iNavigateFromListItemByLineNo(0);
			
		Then.onTheGenericObjectPage
		    .theObjectPageIsInDisplayMode();
	
    
		
	//	Then.iTeardownMyApp();
		     
		    
	//		Then.onTheGenericListReport.waitFor
	//	Then.onTheGenericListReport.theObjectPageHeaderTitleIsCorrect("MilestonePlanID 9");	
	//	Then.iTeardownMyApp();
	//	When.onTheGenericListReport.iNavigateFromListItemByLineNo(2);
//		When.onTheNotesFacet.iPressNotesSectionBt();
	//	When.onTheGenericObjectPage.iNavigateBack();
		
	//	 Then.onTheGenericObjectPage
		 //     .theObjectPageHeaderTitleIsCorrect("MilestonePlanID 9");
	});


});

//	QUnit.module("List Report Page Journey");

//	opaTest("Should Test Description", function(Given, When, Then) {
		// Arrangements
	//	Given.iStartMyApp();

		// Actions
	//	When.onMyPageUnderTest.iDoMyAction();

		// Assertions
	//	Then.onMyPageUnderTest.iDoMyAssertion();

		// Cleanup
	//	Then.iTeardownMyApp();
//	});

// });