# pps.manage.milestone.plan

In order to run the application you need users in **UYT/718** and **EDE/038**

Business Role: SAP_BR_PURCHASER_PPS
