sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageBox',
	'sap/m/MessagePopover',
	'sap/m/MessageItem',
	"sap/ui/model/json/JSONModel"
], function (Controller, MessageBox, MessagePopover, MessageItem, JSONModel) {
	"use strict";

	return Controller.extend("Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.controller.QIStockReleaseDispaly", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.view.QIStockReleaseDispaly
		 */

		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oFioriClient = this.getOwnerComponent().getFioriClient();
			oRouter.getRoute("QIStockReleaseDispaly").attachPatternMatched(this._onObjectMatched, this);
			this.oBusyDialog = new sap.m.BusyDialog();
			var oMatyear = new Date().getFullYear();
			this.Matyear = oMatyear.toString();
		},
		_onObjectMatched: function (oEvent) {
			if (oEvent.getParameter("arguments").WarehouseNo && oEvent.getParameter("arguments").MaterialNum) {
				this.WarehouseNo = oEvent.getParameter("arguments").WarehouseNo;
				this.MaterialNum = oEvent.getParameter("arguments").MaterialNum;
				//	this.Indicator = oEvent.getParameter("arguments").Indicator || "";
				this.Plant = oEvent.getParameter("arguments").Plant || "";
				this.Batchno = oEvent.getParameter("arguments").Batchno || "";
				this.SpecialStockNo = oEvent.getParameter("arguments").SpecialStockNo || "";
				this.Specialstockind = oEvent.getParameter("arguments").Specialstockind || "";
				this.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", null);
				this.oBusyDialog.open();

				var oBindingInfo = {
					success: function (oData, oResponse) {
						this.oBusyDialog.close();

						if (oData.MsgType1 === "S" || oData.MsgType1 === "") {
							this.oBusyDialog.close();

							this.getOwnerComponent().getModel("localModel").setProperty("/oQistockreleasedData", oData);
						} else {
							this.oBusyDialog.close();

							this.getOwnerComponent().getModel("localModel").setProperty("/oQistockreleasedData", "");
							sap.m.MessageBox.show(
								oData.MsgDesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					}.bind(this),
					error: function (oError) {
						this.oBusyDialog.close();
					}.bind(this)
				};

				/*//	(WarehouseNo='A04',Material='100000 073',Plant='9CB3',Batchno=' ',SpecialStockNo='3000001004000100',Specialstockind='E')*/
				this.getOwnerComponent().getModel("RELEASE_QI_STOCK_SRV").read("/Item_detailsSet(WarehouseNo='" + this.WarehouseNo +
					"',Material='" + this.MaterialNum + "',Plant='" + this.Plant + "',Batchno='" + this.Batchno + "',SpecialStockNo='" + this.SpecialStockNo +
					"',Specialstockind='" + this.Specialstockind + "')", oBindingInfo);
			}

		},
		onPressback: function () {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("QIStockReleaseScan");

		},

		onStockQunatitychange: function (oEvt) {

			var sValue1 = oEvt.getParameter("value");
			var sValue = Number(sValue1).toFixed(3);
			this.getView().byId("oStockQty").setText(sValue);
			oEvt.getSource().setValue(sValue);
		},

		onQItoBlock: function () {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");
			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("B");
			} else {
				var oPayload = {

					//	"UserGID": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/UserGID"),
					//  "UserGID":  sap.ushell.Container.getService("UserInfo").getId(),
					//"UserGID": "Z004C4CT",
					"MatDesc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MatDesc"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Material"),
					"MsgDesc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MsgDesc"),
					"MsgType1": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MsgType1"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Serialno"),
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStock"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Stockcat"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"SpecialStoc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStoc"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/WarehouseNo"),
					"Action": "B",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Batchno"),
					"Matyear": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matyear"),
					"Matitem": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matitem"),
					"Matdoc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matdoc"),
					"Indicator": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Indicator")

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("RELEASE_QI_STOCK_SRV").create("/Item_detailsSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.MsgType1 === "S") {

							that.oBusyDialog.close();
							sap.m.MessageBox.success(oData.MsgDesc, {

								actions: ["Go to Putaway process", "Go to QI Stock Release", "Close"],
								title: "QI stock released",
								onClose: function (oAction) {

									if (oAction == "Go to Putaway process") {

										that.onPutawayprocess(oData);

									} else {
										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							sap.m.MessageBox.show(
								oData.MsgDesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						sap.m.MessageBox.error("Error");
						that.getOwnerComponent().getModel("localModel").setProperty("/oQistockreleasedData", []);
					}
				});
			}
		},

		onQitour: function () {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("U");
			} else {
				var oPayload = {
					//	"UserGID": "Z004C4CT",
					//    "UserGID":  sap.ushell.Container.getService("UserInfo").getId(),
					//	"UserGID": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/UserGID"),
					"MatDesc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MatDesc"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Material"),
					"MsgDesc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MsgDesc"),
					"MsgType1": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MsgType1"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Serialno"),
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStock"),

					/*	"Indicator": "",*/
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Stockcat"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"SpecialStoc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStoc"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/WarehouseNo"),
					/*	"Action":  this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Action"),*/
					"Action": "U",

					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Batchno"),
					"Matyear":  this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matyear"),
					"Matitem": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matitem"),
					"Matdoc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matdoc"),
					"Indicator": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Indicator")

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("RELEASE_QI_STOCK_SRV").create("/Item_detailsSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.MsgType1 === "S") {
							that.oBusyDialog.close();
							sap.m.MessageBox.success(oData.MsgDesc, {

								actions: ["Go to Putaway process", "Go to QI Stock Release", "Close"],
								title: "Go to Putaway process",
								onClose: function (oAction) {

									if (oAction == "Go to Putaway process") {

										that.onPutawayprocess(oData);

									} else {
										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							sap.m.MessageBox.show(
								oData.MsgDesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						sap.m.MessageBox.error("Error");
						that.getOwnerComponent().getModel("localModel").setProperty("/oQistockreleasedData", []);
					}
				});
			}
		},
		onMaintainserialno: function () {

			var oVal = this.getView().byId("oStockQtychange").getValue();
			var bindVal = "";
			if (oVal) {
				oVal = Number(Number(oVal).toFixed(0));
				if (oVal <= 1) {
					var loopoVal = 1;
					//	bindVal = oVal;
				} else {
					var loopoVal = oVal;
				}
			} else {
				loopoVal = 0;
			}
			if (!this._Dialog1) {
				this._Dialog1 = sap.ui.xmlfragment(
					"Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.Fragment.MultipleQuantitieRows",
					this
				);
				this.getView().addDependent(this._Dialog1);
			}
			this._Dialog1.open();
			var oTable = sap.ui.getCore().byId("oRelaseStrtTable");
			var oColumn = new sap.m.Column({
				header: new sap.m.Label({
					text: "Serial No.s",
					required: true
				})
			});
			oTable.addColumn(oColumn);
			var oCell = [];
			var Data = [];
			var cell1 = new sap.m.Input({
				value: "{Serialno}"
			});
			oCell.push(cell1);

			for (var i = 0; i < loopoVal; i++) {
				var obj = {
					"Serialno": bindVal
				};
				Data.push(obj);
			}
			var Model = new sap.ui.model.json.JSONModel(Data);
			oTable.setModel(Model);
			var aColList = new sap.m.ColumnListItem("", {
				cells: oCell
			});
			oTable.bindItems("/", aColList);

		},
		onMaterialChangeStockClear: function () {
			var oVal = this.getView().byId("oStockQtychange").getValue();
			if (oVal) {
				oVal = Number(Number(oVal).toFixed(0));
			} else {
				oVal = 0;
			}

			var oTable = sap.ui.getCore().byId("oRelaseStrtTable");
			oTable.destroyItems();
			oTable.unbindItems();
			oTable.removeAllColumns();
			var oColumn = new sap.m.Column({
				header: new sap.m.Label({
					text: "Serial No.s",
					required: true
				})
			});
			oTable.addColumn(oColumn);
			var oCell = [];
			var Data = [];
			var cell1 = new sap.m.Input({
				value: "{Serialno}"
			});
			oCell.push(cell1);
			for (var i = 0; i < oVal; i++) {
				var obj = {
					"Serialno": ""
				};
				Data.push(obj);
			}
			var Model = new sap.ui.model.json.JSONModel(Data);
			oTable.setModel(Model);
			var aColList = new sap.m.ColumnListItem("", {
				cells: oCell
			});
			oTable.bindItems("/", aColList);
		},
		onMaterialChangeStockSave: function () {
			var oTable = sap.ui.getCore().byId("oRelaseStrtTable").getModel().getData().filter(function (x) {
				return x.Serialno === "";
			});
			if (!oTable.length) {
				var MaintainedSrnoData = sap.ui.getCore().byId("oRelaseStrtTable").getModel().getData();
				this.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", MaintainedSrnoData);
				this._Dialog1.destroy(true);
				this._Dialog1 = undefined;
			} else {
				sap.m.MessageBox.show(
					"Please enter valid Serial No.s", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.CLOSE],
						onClose: function (oAction) {}

					}
				);
			}

		},

		oMaintianSerialNoBtnPost: function (Action) {
			if (Action === "B" || Action === "U") {
				var oPayload = {
					//	"UserGID": "Z004C4CT",
					//	 "UserGID":  sap.ushell.Container.getService("UserInfo").getId(),
					//	"UserGID": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/UserGID"),
					"MatDesc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MatDesc"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Material"),
					"MsgDesc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MsgDesc"),
					"MsgType1": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MsgType1"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStock"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStockNo"),
					//	"SpecialStockNo": "",
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Stockcat"),

					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"SpecialStoc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStoc"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/WarehouseNo"),
					"Action": Action,
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Batchno"),
					"Matyear": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matyear"),
					"Matitem": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matitem"),
					"Matdoc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matdoc"),
					"Indicator": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Indicator"),
					"ITEM_SERIAL_NAV": this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData")

				};

				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("RELEASE_QI_STOCK_SRV").create("/Item_detailsSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.MsgType1 === "S") {

							that.oBusyDialog.close();
							sap.m.MessageBox.success(oData.MsgDesc, {

								actions: ["Go to Putaway process", "Go to QI Stock Release", "Close"],
								title: "QI stock released",
								onClose: function (oAction) {

									if (oAction == "Go to Putaway process") {

										that.onPutawayprocess(oData);

									} else {
										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							sap.m.MessageBox.show(
								oData.MsgDesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						sap.m.MessageBox.error("Error");
						that.getOwnerComponent().getModel("localModel").setProperty("/oQistockreleasedData", []);
					}
				});

				

			}
		},
		onMaterialChangeStockBack: function () {
			this._Dialog1.destroy(true);
			this._Dialog1 = undefined;
		},

		onPutawayprocess: function (oData) {
			var that = this;
			var Gid = that.getOwnerComponent().getModel("localModel").getProperty("/Gid");
			var oMateno = oData.Matdoc;
			var oMatyear = oData.Matyear;
			var oMatItem = oData.Matitem;
			var WarehouseNo = this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/WarehouseNo");
			var oCrossAppNavigator = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService && sap.ushell.Container.getService(
				"CrossApplicationNavigation");
			oCrossAppNavigator.isIntentSupported(["ZASP_WM_Putaway-display"])
				.done(function (aResponses) {

				})
				.fail(function () {
					new sap.m.MessageToast("Provide corresponding intent to navigate");
				});
			// generate the Hash to display ZASP_WM_Putaway
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "ZASP_WM_Putaway",
					action: "display"
				},
				params: {
					"Gid": Gid,
					"MaterialNo": oMateno,
					"MatYear": oMatyear,
					"MatItem": oMatItem,
					"WarehouseNo": WarehouseNo

					/*	"PreviousIntent": window.hasher.getHash().split("-")[0]*/

				}
			})) || "";
			//################ Outbound Navigation################//
			//Generate a  URL for the second application
			//var url = window.location.href.split('#')[0] + hash;
			//Navigate to second app 
			//	sap.m.URLHelper.redirect(url, true);
			//################ Outbound Navigation End################//
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});

		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.view.QIStockReleaseDispaly
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.view.QIStockReleaseDispaly
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.view.QIStockReleaseDispaly
		 */
		//	onExit: function() {
		//
		//	}

	});

});