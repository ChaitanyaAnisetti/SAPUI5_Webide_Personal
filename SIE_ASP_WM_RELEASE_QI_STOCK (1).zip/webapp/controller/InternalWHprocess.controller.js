sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"

], function (Controller, History) {
	"use strict";

	return Controller.extend("Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.controller.InternalWHprocess", {
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("InternalWHprocess").attachPatternMatched(this._onObjectMatched, this);
			this.oBusyDialog = new sap.m.BusyDialog();
		},
		_onObjectMatched: function (oEvent) {
		/*	var WarehouseNo = oEvent.getParameter("arguments").WarehouseNo;*/

		},

		onChangestockinfo: function (oEvent) {
		/*	var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("QIStockReleaseScan", {
				WarehouseNo: this.getOwnerComponent().getModel("localModel").getProperty("/LoginUserInfo/WarehouseNo")
				Plant: this.getOwnerComponent().getModel("localModel").getProperty("/LoginUserInfo/Plant")
			});*/
		},
		onQistockreleased : function()
		{
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("QIStockReleaseScan", {
				WarehouseNo: this.getOwnerComponent().getModel("localModel").getProperty("/LoginUserInfo/WarehouseNo")
		//		Plant: this.getOwnerComponent().getModel("localModel").getProperty("/LoginUserInfo/Plant")
			});
		}	
		
		
		
	});
});