jQuery.sap.require("sap.ndc.BarcodeScanner");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	'sap/m/MessageBox',
	'sap/m/MessagePopover',
	'sap/m/MessageItem'
], function (Controller, JSONModel, MessageBox, MessagePopover, MessageItem) {
	"use strict";

	return Controller.extend("Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.controller.QIStockReleaseScan", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.view.QIStockReleaseScan
		 */
		onInit: function () {

			
			this.oFioriClient = this.getOwnerComponent().getFioriClient();
			this.oBusyDialog = new sap.m.BusyDialog();
		
			
	//		var Gid = sap.ushell.Container.getService("UserInfo").getId();
        	var Gid = this.getOwnerComponent().getModel("localModel").getProperty("/Gid");
			var path1 = "/UserDefaultSet('" + Gid + "')";
			this.oBusyDialog.open();
			this.getOwnerComponent().getModel("RELEASE_QI_STOCK_SRV").read(path1, {
				success: function (oData, oResponse) {
					if (oData.MsgType === "S") {
						this.WarehouseNo = oData.WarehouseNo;
						this.getOwnerComponent().getModel("localModel").setProperty("/LoginUserInfo", oData);
						this.oBusyDialog.close();
					} else {
						this.oBusyDialog.close();
						sap.m.MessageBox.show(
							oData.MsgDesc, {
								icon: sap.m.MessageBox.Icon.ERROR,

								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);
					}
				}.bind(this),
				error: function (err) {
					this.oBusyDialog.close();
					sap.m.MessageBox.show(
						"OData error in UserDefaultSet", {
							icon: sap.m.MessageBox.Icon.ERROR,

							actions: [sap.m.MessageBox.Action.CLOSE],
							onClose: function (oAction) {}
						}
					);

				}.bind(this)
			});
		},
		/*_onObjectMatched: function (oEvent) {
			if (oEvent.getParameter("arguments").WarehouseNo) {
				this.WarehouseNo = oEvent.getParameter("arguments").WarehouseNo;
			}
		},*/
		onBackpress: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Mainview", {

			});
		},

		/*var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("QIStockReleaseDispaly", {

				});*/

		onMaterialChange: function () {
			var SelectedMaterial = this.getView().byId("oMatenoinput").getValue();
			var Plant = this.getOwnerComponent().getModel("localModel").getProperty("/LoginUserInfo/Plant"),
				Batchno = "",
				SpecialStockNo = "",
				Specialstockind = "";
			//(oSelectedMaterial,Plant,specialStockInd,specialStockNum,BatchNo
			this._CheckMaterial(SelectedMaterial, Plant, Specialstockind, SpecialStockNo, Batchno);
		},
		//barcode scanner functionalities....
		onBarCodeScan: function () {
			if (cordova.plugins && cordova.plugins.barcodeScanner) {
				cordova.plugins.barcodeScanner.scan(
					this.onSuccess.bind(this),
					this.onError.bind(this)
				);
			} else {

				sap.ndc.BarcodeScanner.scan(
					this.onSuccess.bind(this),
					this.onError.bind(this)
				);
			}
		},
		// onSuccess Callback 
		onSuccess: function (result) {
			var bCancelled = result.cancelled;
			this.getView().byId("oMatenoinput").setValue("");
			if (result.text && bCancelled == false) {
			//	this.getView().byId("oMatenoinput").setValue(result.text.split("|")[2]);
			this.getView().byId("oMatenoinput").setValue(parseInt(result.text.split("|")[4]));
				var SelectedMaterial = this.getView().byId("oMatenoinput").getValue();
				var Plant = result.text.split("|")[5] || "",
					Batchno = result.text.split("|")[10] || "",
					SpecialStockNo = result.text.split("|")[8] || "",
					Specialstockind = result.text.split("|")[7] || "";

				this._CheckMaterial(SelectedMaterial, Plant, Specialstockind, SpecialStockNo, Batchno);
			} else if (bCancelled) {
				sap.m.MessageToast.show("Scan Cancelled");
			}

		},

		// onError Callback
		onError: function (error) {
			sap.m.MessageToast.show(error, "Error");
		},
		_CheckMaterial: function (oSelectedMaterial, Plant, specialStockInd, specialStockNum, BatchNo) {
			var oSelectedMaterial=oSelectedMaterial,
			    Plant =Plant, 
			    specialStockInd =specialStockInd, 
			    specialStockNum = specialStockNum, 
			    BatchNo=BatchNo;

			this.oBusyDialog.open();
			var oBindingInfo = {
				success: function (oData, oResponse) {
					this.oBusyDialog.close();

					if (oData.MsgType === "S") {
						this.oBusyDialog.close();
						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						oRouter.navTo("QIStockReleaseDispaly", {
							WarehouseNo: this.getOwnerComponent().getModel("localModel").getProperty("/LoginUserInfo/WarehouseNo"),
							MaterialNum: oSelectedMaterial,
							Plant: Plant,
							Batchno: BatchNo,
							SpecialStockNo: specialStockNum,
							Specialstockind: specialStockInd
						});
					} else {
						this.oBusyDialog.close();
						sap.m.MessageBox.show(
							oData.MsgDesc, {
								icon: sap.m.MessageBox.Icon.ERROR,
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);
					}
				}.bind(this),
				error: function (oError) {
					this.oBusyDialog.close();
					sap.m.MessageBox.error("Error");
				}.bind(this)
			};

 /*Plant =Plant, 
			    specialStockInd =specialStockInd, 
			    specialStockNum = specialStockNum, 
			    BatchNo=BatchNo;*/
    //Chk_MaterialSet(WarehouseNo='A04',Material='100000070',Plant='9CB3',Batchno='0000000798',SpecialStockNo=' ',Specialstockind=' ')
			this.getOwnerComponent().getModel("RELEASE_QI_STOCK_SRV").read("/Chk_MaterialSet(WarehouseNo='" + this.WarehouseNo + "',Material='" +
				oSelectedMaterial + "',Plant='"+Plant+"',Batchno='"+BatchNo+"',SpecialStockNo='"+specialStockNum+"',Specialstockind='"+specialStockInd+"')", oBindingInfo);

		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.view.QIStockReleaseScan
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.view.QIStockReleaseScan
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.view.QIStockReleaseScan
		 */
		//	onExit: function() {
		//
		//	}

	});

});