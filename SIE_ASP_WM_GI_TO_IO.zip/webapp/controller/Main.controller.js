sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"gitoio/SIE_ASP_WM_GI_TO_IO/model/formatter",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment"
], function (Controller, JSONModel, Filter, FilterOperator, formatter, Fragment, MessageBox) {
	"use strict";

	return Controller.extend("gitoio.SIE_ASP_WM_GI_TO_IO.controller.Main", {
		formatter: formatter,
		onInit: function () {
			this._mainService = this.getOwnerComponent().getModel();
			this._checkAuthorisation();
		},
		_checkAuthorisation: function () {
			var GID = this.getOwnerComponent().getModel("localModel").getProperty("/Gid");
			//	var GID = "Z004C4CT";han
			var that = this;
			var pageId = this.getView().byId("page");
			pageId.setBusy(true);

			this._mainService.read("/UserDefaultSet('" + GID + "')", {
				success: function (data) {
					pageId.setBusy(false);

					if (data.MsgType === "S") {
						that._WarehouseNo = data.WarehouseNo;
					} else {
						sap.m.MessageBox.error(data.MsgDesc);

					}
				},
				error: function (Error) {
					pageId.setBusy(false);
					sap.m.MessageBox.error(that.getView().getModel("i18n").getResourceBundle().getText("noDataFoundError"));

				}
			});

		},
		onFilter: function (oEvent) {

			var that = this;
			var pageId = this.getView().byId("page");
			pageId.setBusy(true);
			var oGIModel = new JSONModel();
			var aGIModelFilters = [];
			if (this.getView().byId("idReqDateSel").getFrom() !== null || this.getView().byId("idReqDateSel").getTo() !== null) {
				var sReqdateFilter = new Filter({
					path: "Reqdate",
					operator: FilterOperator.BT,
					value1: this.getView().byId("idReqDateSel").getFrom(),
					value2: this.getView().byId("idReqDateSel").getTo()
				});
				aGIModelFilters.push(sReqdateFilter);
			} else {
				pageId.setBusy(false);
				sap.m.MessageBox.error(that.getView().getModel("i18n").getResourceBundle().getText("ReqDateMandatoryErr"));
				return;
			}
			if (this.getView().byId("idIpPlant").getValue()) {
				var sPlantFilter = new Filter({
					path: "Plant",
					operator: FilterOperator.EQ,
					value1: this.getView().byId("idIpPlant").getValue()
				});
				aGIModelFilters.push(sPlantFilter);
			}
			if (this.getView().byId("idIpCostCenter").getValue()) {
				var sCostCenterFilter = new Filter({
					path: "CostCenter",
					operator: FilterOperator.EQ,
					value1: this.getView().byId("idIpCostCenter").getValue()
				});
				aGIModelFilters.push(sCostCenterFilter);
			}
			if (this.getView().byId("idIpRequester").getValue()) {
				var sRequestorFilter = new Filter({
					path: "Requestor",
					operator: FilterOperator.EQ,
					value1: this.getView().byId("idIpRequester").getValue()
				});
				aGIModelFilters.push(sRequestorFilter);
			}

			var sWarehouseFilter = new Filter({
				path: "WarehouseNo",
				operator: FilterOperator.EQ,
				value1: this._WarehouseNo
			});
			aGIModelFilters.push(sWarehouseFilter);
			//	;*/

			this._mainService.read("/Goodissue_listSet", {
				filters: aGIModelFilters,
				success: function (data) {
							pageId.setBusy(false);
					if (data.results[0].MsgType1 === "S") {
						oGIModel.setData(data);
						that.getView().setModel(oGIModel, "oGIModel");
					} else {
						sap.m.MessageBox.error(data.results[0].MsgDesc);

					}
				},
				error: function (Error) {
					pageId.setBusy(false);
					sap.m.MessageBox.error(that.getView().getModel("i18n").getResourceBundle().getText("noDataFoundError"));
				}
			});

		},
		onPickingPress: function (oEvent) {
			var oSelectedItem = oEvent.getSource().getParent();
			var sPath = oSelectedItem.getBindingContextPath().split("/")[2];
			var sResNo = this.getView().getModel("oGIModel").getData().results[sPath].ResNO;
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("PostGI", {
				resNo: sResNo,
				WarehouseNo: this._WarehouseNo
			});
		},
		_handleValueHelpSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var sArray = oEvent.getParameter("itemsBinding").getModel().getData().results;
			var aKeys = Object.keys(sArray[0]);
			var sFilterProperty = aKeys[aKeys.length - 1];
			var oFilter = new sap.ui.model.Filter(
				sFilterProperty,
				sap.ui.model.FilterOperator.Contains, sValue
			);
			oEvent.getSource().getBinding("items").filter([oFilter]);
		},
		handleValueHelpForAll: function (oEvent) {
			if (!this._valueHelpDialogForMaterial) {
				this._valueHelpDialogForMaterial = sap.ui.xmlfragment(
					"gitoio.SIE_ASP_WM_GI_TO_IO.fragment.handleValueHelp",
					this
				);
			}
			this._sInput = oEvent.getSource();
			if (oEvent.getSource().getIdForLabel().includes("idIpCostCenter")) {
				this._getF4CCModel();
			} else if (oEvent.getSource().getIdForLabel().includes("idIpPlant")) {
				this._getF4PlantModel();

			} else if (oEvent.getSource().getIdForLabel().includes("idIpRequester")) {
				this._getF4RequestorModel();

			}
			this.getView().addDependent(this._valueHelpDialogForMaterial);
			this._valueHelpDialogForMaterial.open(oEvent.getSource().getValue());

		},
		_onSelectItem: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			if (oSelectedItem) {
				var sKey = oSelectedItem.getTitle();
				this._sInput.setValue(sKey);
			}
		},
		_getF4CCModel: function () {
			var that = this;
			var oCCF4Model = new JSONModel();
			var aCCF4ModelFilters = [];
			var sWarehouseFilter = new Filter({
				path: "WarehouseNo",
				operator: FilterOperator.EQ,
				value1: this._WarehouseNo
			});
			aCCF4ModelFilters.push(sWarehouseFilter);

			//	;*/

			this._mainService.read("/CostCenter_listSet", {
				filters: aCCF4ModelFilters,
				success: function (data) {

					oCCF4Model.setData(data);
					that.getView().setModel(oCCF4Model, "oCCF4Model");
				},
				error: function (Error) {

				}
			});
			var oTemplate = new sap.m.StandardListItem({
				title: "{oCCF4Model>CostCenter}",
			});
			sap.ui.getCore().byId("mySelectDialog").bindAggregation("items", "oCCF4Model>/results", oTemplate);
		},
		_getF4PlantModel: function () {
			var that = this;
			var oPlantF4Model = new JSONModel();
			var aPlantF4ModelFilters = [];
			var sWarehouseFilter = new Filter({
				path: "WarehouseNo",
				operator: FilterOperator.EQ,
				value1: this._WarehouseNo
			});
			aPlantF4ModelFilters.push(sWarehouseFilter);

			//	;*/

			this._mainService.read("/Plant_listSet", {
				filters: aPlantF4ModelFilters,
				success: function (data) {

					oPlantF4Model.setData(data);
					that.getView().setModel(oPlantF4Model, "oPlantF4Model");
				},
				error: function (Error) {

				}
			});
			var oTemplate = new sap.m.StandardListItem({
				title: "{oPlantF4Model>Plant}",
			});
			sap.ui.getCore().byId("mySelectDialog").bindAggregation("items", "oPlantF4Model>/results", oTemplate);
		},
		_getF4RequestorModel: function () {
			var that = this;
			var oRequestorF4Model = new JSONModel();
			var aRequestorF4ModelFilters = [];
			var sWarehouseFilter = new Filter({
				path: "WarehouseNo",
				operator: FilterOperator.EQ,
				value1: this._WarehouseNo
			});
			aRequestorF4ModelFilters.push(sWarehouseFilter);

			//	;*/

			this._mainService.read("/Requestor_listSet", {
				filters: aRequestorF4ModelFilters,
				success: function (data) {

					oRequestorF4Model.setData(data);
					that.getView().setModel(oRequestorF4Model, "oRequestorF4Model");
				},
				error: function (Error) {

				}
			});
			var oTemplate = new sap.m.StandardListItem({
				title: "{oRequestorF4Model>Requestor}",
			});
			sap.ui.getCore().byId("mySelectDialog").bindAggregation("items", "oRequestorF4Model>/results", oTemplate);

		}

	});
});