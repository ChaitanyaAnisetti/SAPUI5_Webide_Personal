sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"gitoio/SIE_ASP_WM_GI_TO_IO/model/formatter",
	"sap/m/MessageBox",
	"sap/ui/core/routing/History"
], function (Controller, JSONModel, Filter, FilterOperator, formatter, MessageBox, History) {
	"use strict";

	return Controller.extend("gitoio.SIE_ASP_WM_GI_TO_IO.controller.PostGI", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gitoio.SIE_ASP_WM_GI_TO_IO.view.PostGI
		 */
		formatter: formatter,
		onInit: function () {
			this._mainService = this.getOwnerComponent().getModel();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("PostGI").attachPatternMatched(this._onRouteMatched, this);
		},
		onNavBack: function (oEvent) {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("Main", true);
			}
		},
		_onRouteMatched: function (oEvent) {
			this.sResNo = oEvent.getParameter("arguments").resNo;
			this.sWarehouseNo = oEvent.getParameter("arguments").WarehouseNo;
			this._getGoodsIssueDetSet(this.sResNo, this.sWarehouseNo);
		},
		_getGoodsIssueDetSet: function (sResNo, sWarehouseNo) {
			var that = this;
			var pageId = this.getView().byId("postGIPage");
			pageId.setBusy(true);
			var oGIDetModel = new JSONModel();
			//	var oGIDetSerNoModel = new JSONModel();
			this._mainService.read("/Goodissue_detSet(WarehouseNo='" + sWarehouseNo + "',Pickno='" + sResNo + "')", {
				urlParameters: {
					"$expand": "ITEM_SERIAL_NAV"
				},
				success: function (data) {
					pageId.setBusy(false);
					if (data.MsgType === "S") {

						oGIDetModel.setData(data);
						that.getView().setModel(oGIDetModel, "oGIDetModel");
						/*	var sLine = {
								"WarehouseNo": "",
								"Serialno": "",
								"Pickno": ""
							};*/
						/*			data.ITEM_SERIAL_NAV.results.push({
										"WarehouseNo": sWarehouseNo,
										"Serialno": "",
										"Pickno": sResNo
									});
									data.ITEM_SERIAL_NAV.results.push({
										"WarehouseNo": sWarehouseNo,
										"Serialno": "",
										"Pickno": sResNo
									});
									oGIDetSerNoModel.setData(data.ITEM_SERIAL_NAV);
									that.getView().setModel(oGIDetSerNoModel, "oGIDetSerNoModel");*/

					} else {
						sap.m.MessageBox.error(data.MsgDesc);
					}

				},
				error: function (Error) {
					pageId.setBusy(false);
					sap.m.MessageBox.error(that.getView().getModel("i18n").getResourceBundle().getText("noDataFoundError"));
				}
			});

		},
		onSerialNumberClick: function () {
			this.count = 0;
			var oGIDetSerNoModel = new JSONModel([]);
		/*	var sGIDetModelData = new JSONModel([]);
        	this.getView().setModel(sGIDetModelData, "sGIDetModelData");*/
			var sGIDetModelData = this.getView().getModel("oGIDetModel").getData();
			sGIDetModelData.ITEM_SERIAL_NAV.results = [];
			var sConfQty = parseInt(sGIDetModelData.ConfQty, 10);
			if (sConfQty > 0) {
				if (sGIDetModelData.ITEM_SERIAL_NAV.results.length === 0) {
					for (var i = 0; i < sConfQty; i++) {
						sGIDetModelData.ITEM_SERIAL_NAV.results.push({
							"WarehouseNo": this.sWarehouseNo,
							"Serialno": "",
							"Pickno": this.sResNo
						});
					}
					oGIDetSerNoModel.setData(sGIDetModelData.ITEM_SERIAL_NAV);
					this.getView().setModel(oGIDetSerNoModel, "oGIDetSerNoModel");
				}

				if (!this._serialNumberPopup) {
					this._serialNumberPopup = sap.ui.xmlfragment(
						"gitoio.SIE_ASP_WM_GI_TO_IO.fragment.serialNo",
						this
					);
				}
				this.getView().addDependent(this._serialNumberPopup);
				this._serialNumberPopup.open();
			} else

			{
				sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("mandatoryConfQtyErr"));
			}
		},
		onConfPGI: function (oEvent) {
			//var that = this;
			var pageId = this.getView().byId("postGIPage");
			pageId.setBusy(true);
			var aGIDetData = this.getView().getModel("oGIDetModel").getData();
			/*	var aGIDetDetData = {
					"Action": aGIDetSrcData.Action,
					"ConfBatch": aGIDetSrcData.ConfBatch,
					"ConfBatchInd": aGIDetSrcData.ConfBatchInd,
					"ConfBin": aGIDetSrcData.ConfBin,
					"ConfQty": aGIDetSrcData.ConfQty,
					"ConfQtyUOM": aGIDetSrcData.ConfQtyUOM,
					"Intorder": aGIDetSrcData.Intorder,
					"MatDesc": aGIDetSrcData.MatDesc,
					"Material": aGIDetSrcData.Material,
					"MsgDesc": aGIDetSrcData.MsgDesc,
					"MsgType": aGIDetSrcData.MsgType,
					"PickQty": aGIDetSrcData.PickQty,
					"Pickitem": aGIDetSrcData.Pickitem,
					"Pickno": aGIDetSrcData.Pickno,
					"Plant": aGIDetSrcData.Plant,
					"Serialno": aGIDetSrcData.Serialno,
					"Sloc": aGIDetSrcData.Sloc,
					"WarehouseNo": aGIDetSrcData.WarehouseNo,
					"batch": aGIDetSrcData.batch,
					"indicator": aGIDetSrcData.indicator
				};*/

			this._mainService.create("/Goodissue_detSet", aGIDetData, {
				success: function (data) {

					pageId.setBusy(false);
					if (data.MsgType === "S") {
						sap.m.MessageBox.success(data.MsgDesc);
					} else {
						sap.m.MessageBox.error(data.MsgDesc);
					}
				},
				error: function () {
					pageId.setBusy(false);
				}
			});
		},
		fnClearSrNo: function () {
			var aData = this.getView().getModel("oGIDetSerNoModel").getData();
			for (var i = 0; i < aData.results.length; i++) {
				aData.results[i].Serialno = "";
			}
			this.getView().getModel("oGIDetSerNoModel").setData(aData);
		},
		fnCloseSrNo: function (oEvent) {
			if (this._serialNumberPopup) {
				this._serialNumberPopup.close();
				this._serialNumberPopup.destroy();
				this._serialNumberPopup = null;
			}
		},
		onChange: function (oEvent) {
				debugger;
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf gitoio.SIE_ASP_WM_GI_TO_IO.view.PostGI
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf gitoio.SIE_ASP_WM_GI_TO_IO.view.PostGI
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf gitoio.SIE_ASP_WM_GI_TO_IO.view.PostGI
		 */
		//	onExit: function() {
		//
		//	}

	});

});