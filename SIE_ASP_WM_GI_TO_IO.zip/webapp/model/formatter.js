sap.ui.define(["sap/ui/core/format/DateFormat"],
	function (DateFormat) {
		return {
			formatDate: function (sDate) {
				var datePattern = sap.ui.getCore().getConfiguration().getFormatSettings().getDatePattern("medium");
				var sFormattedDate = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: datePattern
				}).format(sDate);
				return sFormattedDate;
			},
			controlButtonVisibility: function (sGoodsIssueStat) {
				var bVisible = false;
				if (sGoodsIssueStat === "N") {
					bVisible = true;
				} else {
					bVisible = false;
				}
				return bVisible;
			},
			controlSerNoButtonVisibility:function(sInd){
				var bVisible = false;
				if (sInd === "X") {
					bVisible = true;
				} 
				else 
				{
					bVisible = false;
				}
				return bVisible;	
			},
			controlEnableBatch:function(sBatchInd){
					var bEnabled = false;
				if (sBatchInd === "X") {
					bEnabled = true;
				} 
				else 
				{
					bEnabled = false;
				}
				return bEnabled;	
			},
				setRowNo: function (oModel) {
				this.count = this.count + 1;
				return this.count;
			},
		};
	}
);