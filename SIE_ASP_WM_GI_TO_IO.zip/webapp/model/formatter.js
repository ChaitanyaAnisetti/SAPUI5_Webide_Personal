sap.ui.define(["sap/ui/core/format/DateFormat"],
	function (DateFormat) {
		return {
			formatDate: function (sDate) {
				var datePattern = sap.ui.getCore().getConfiguration().getFormatSettings().getDatePattern("medium");
				var sFormattedDate = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: datePattern
				}).format(sDate);
				return sFormattedDate;
			},
			statusbtn: function (ind) {

				switch (ind) {
				case "X":
					return 3;
				case "":
					return 7;
				default:
					return 7;
				}
			},
			StatusMain : function(Goodissue)
			{
				switch (Goodissue) {
				case "N":
					return 3;
				case "Y":
					return 7;
				}	
			},
			controlButtonVisibility: function (sGoodsIssueStat) {
				var bVisible = false;
				if (sGoodsIssueStat === "N") {
					bVisible = true;
				} else {
					bVisible = false;
				}
				return bVisible;
			},
			controlSerNoButtonVisibility: function (sInd) {
				var bVisible = false;
				if (sInd === "X") {
					bVisible = true;
				} else {
					bVisible = false;
				}
				return bVisible;
			},
			controlEnableBatch: function (sBatchInd) {
				var bEnabled = false;
				if (sBatchInd === "X") {
					bEnabled = true;
				} else {
					bEnabled = false;
				}
				return bEnabled;
			},
			setRowNo: function (oModel) {
				this.count = this.count + 1;
				return this.count;
			},
				Reqdate: function (Reqdate) {

				if (Reqdate == null || Reqdate == ""){
					return "";

				} else {
         			var year = Reqdate.substring(0, 4);
					var month = Reqdate.substring(4, 6);
					var day = Reqdate.substring(6, 8);
					var Reqdate = day + "." + month + "." + year;
					return Reqdate;

				}

			},
			Material: function (Material) {

				var str = Number(Material).toString();
				return str;
			}
		};
	}
);