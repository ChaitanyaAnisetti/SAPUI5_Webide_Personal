sap.ui.define([
	"gitoio/SIE_ASP_WM_GI_TO_IO/test/unit/controller/Main.controller"
], function () {
	"use strict";
});