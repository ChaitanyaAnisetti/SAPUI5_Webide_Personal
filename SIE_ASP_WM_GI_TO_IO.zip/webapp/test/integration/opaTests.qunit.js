/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"gitoio/SIE_ASP_WM_GI_TO_IO/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});