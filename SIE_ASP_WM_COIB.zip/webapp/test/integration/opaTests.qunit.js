/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"coib/SIE_ASP_WM_COIB/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});