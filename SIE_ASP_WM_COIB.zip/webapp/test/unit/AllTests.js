sap.ui.define([
	"coib/SIE_ASP_WM_COIB/test/unit/controller/COIBMain.controller"
], function () {
	"use strict";
});