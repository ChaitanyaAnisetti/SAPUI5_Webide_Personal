sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("coib.SIE_ASP_WM_COIB.controller.COIBMain", {
		onInit: function () {
	this._mainService = this.getOwnerComponent().getModel();
			this._checkAuthorisation();
		},
		_checkAuthorisation: function () {
			var GID = this.getOwnerComponent().getModel("localModel").getProperty("/Gid");
			//	var GID = "Z004C4CT";
			var that = this;
			var pageId = this.getView().byId("page");
			pageId.setBusy(true);

			this._mainService.read("/UserDefaultSet('" + GID + "')", {
				success: function (data) {
					pageId.setBusy(false);
					if (data.MsgType === "S") {
						that._WarehouseNo = data.WarehouseNo;
					} else {
						sap.m.MessageBox.error(data.MsgDesc);

					}
				},
				error: function (Error) {
					pageId.setBusy(false);
					sap.m.MessageBox.error(that.getView().getModel("i18n").getResourceBundle().getText("noDataFoundError"));

				}
			});

		},
		onProductionNumberChange:function(oEvent)
		{
				//	var sProdNo = oEvent.getParameter("value");
		var sProdNo  = this.getView().byId("idProductionNum").getValue();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("RouteCOIBOrdHeader", {
				prodNo: sProdNo,
				WarehouseNo: this._WarehouseNo
			});
		},
				onBarCodeScan: function () {
			if (cordova.plugins && cordova.plugins.barcodeScanner) {
				cordova.plugins.barcodeScanner.scan(
					this.onSuccess.bind(this),
					this.onError.bind(this)
				);
			} else {

				sap.ndc.BarcodeScanner.scan(
					this.onSuccess.bind(this),
					this.onError.bind(this)
				);
			}
		}
	});
});