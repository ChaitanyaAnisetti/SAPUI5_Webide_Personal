sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox"
	//	"phyinvcount/SIE_ASP_WM_PHY_INV_COUNT/model/formatter"
], function (Controller, JSONModel, Filter, FilterOperator, MessageBox) {
	"use strict";

	return Controller.extend("coib.SIE_ASP_WM_COIB.controller.COIBOrderHeader", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf coib.SIE_ASP_WM_COIB.view.COIBOrderHeader
		 */
		onInit: function () {
			this._mainService = this.getOwnerComponent().getModel();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("RouteCOIBOrdHeader").attachPatternMatched(this._onRouteMatched, this);
		},
		_onRouteMatched: function (oEvent) {
			this.sProdNo = oEvent.getParameter("arguments").prodNo;
			var sWarehouseNo = oEvent.getParameter("arguments").WarehouseNo;
			this._getProdOrderHeaderSet(this.sProdNo, sWarehouseNo);
		},
		_getProdOrderHeaderSet: function (sProdNo, sWarehouseNo) {
			var that = this;
			var pageId = this.getView().byId("idProdOrdHeader");
			pageId.setBusy(true);
			var oProdOrdHdrModel = new JSONModel();
			var oProdOrdSerNoModel = new JSONModel();

			this._mainService.read("/OrderHdrSet(WarehouseNo='" + sWarehouseNo + "',Order='" + sProdNo + "')", {
				urlParameters: {
					"$expand": "ITEMSET_NAV"
				},
				success: function (data) {
					pageId.setBusy(false);
					//	if (data.MsgType === "S") {
					oProdOrdHdrModel.setData(data);
					oProdOrdSerNoModel.setData(data.ITEMSET_NAV);
					that.getView().setModel(oProdOrdSerNoModel, "oProdOrdSerNoModel");
					that.getView().setModel(oProdOrdHdrModel, "oProdOrdHdrModel");
					/*	} 
						else {
								sap.m.MessageBox.error(data.MsgDesc);
						}*/
				},
				error: function (Error) {
					pageId.setBusy(false);
					sap.m.MessageBox.error(that.getView().getModel("i18n").getResourceBundle().getText("noDataFound"));

				}
			});
		},
		handleValueHelpForHeader: function (oEvent) {
			if (!this._valueHelpDialogForSrNo) {
				this._valueHelpDialogForSrNo = sap.ui.xmlfragment(
					"coib.SIE_ASP_WM_COIB.fragment.handleValueHelp",
					this
				);
			}
			this._sInput = oEvent.getSource();
			var sMaterial = this.getView().byId("idMaterialTxt").getText();
			this._getSrNoF4Model(sMaterial);
			this.getView().addDependent(this._valueHelpDialogForSrNo);
			this._valueHelpDialogForSrNo.open();
		},
		handleValueHelpForAll: function (oEvent) {
			if (!this._valueHelpDialogForSrNo) {
				this._valueHelpDialogForSrNo = sap.ui.xmlfragment(
					"coib.SIE_ASP_WM_COIB.fragment.handleValueHelp",
					this
				);
			}
			this._sInput = oEvent.getSource();
			var sMaterial = oEvent.getSource().getParent().getCells()[0].getText();
			this._getSrNoF4Model(sMaterial);
			this.getView().addDependent(this._valueHelpDialogForSrNo);
			this._valueHelpDialogForSrNo.open();

		},
		_getSrNoF4Model: function (sMaterial) {
			var that = this;
			this.getView().byId("idProdOrdHeader").setBusy(true);
			var oSrNoF4Model = new JSONModel();
			var aSrNoF4ModelFilters = [];
			var sProdNoFilter = new Filter({
				path: "Order",
				operator: FilterOperator.EQ,
				value1: this.sProdNo
			});
			aSrNoF4ModelFilters.push(sProdNoFilter);
			var sMatNoFilter = new Filter({
				path: "Material",
				operator: FilterOperator.EQ,
				value1: sMaterial
			});
			aSrNoF4ModelFilters.push(sMatNoFilter);

			//	;*/

			this._mainService.read("/Serialno_listSet", {
				filters: aSrNoF4ModelFilters,
				success: function (data) {
					that.getView().byId("idProdOrdHeader").setBusy(false);
					oSrNoF4Model.setData(data);
					that.getView().setModel(oSrNoF4Model, "oSrNoF4Model");
				},
				error: function (Error) {
					that.getView().byId("idProdOrdHeader").setBusy(false);
				}
			});
			var oTemplate = new sap.m.StandardListItem({
				title: "{oSrNoF4Model>Serialno}"
			});
			sap.ui.getCore().byId("mySelectDialog").bindAggregation("items", "oSrNoF4Model>/results", oTemplate);
		},
		_handleValueHelpSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var sArray = oEvent.getParameter("itemsBinding").getModel().getData().results;
			var aKeys = Object.keys(sArray[0]);
			var sFilterProperty = aKeys[aKeys.length - 1];
			var oFilter = new sap.ui.model.Filter(
				sFilterProperty,
				sap.ui.model.FilterOperator.Contains, sValue
			);
			oEvent.getSource().getBinding("items").filter([oFilter]);
		},
		_onSelectItem: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			if (oSelectedItem) {
				var sKey = oSelectedItem.getTitle();
				this._sInput.setValue(sKey);
			}
		},
		onSave: function (oEvent) {
				var sData = this.getView().getModel("oProdOrdHdrModel").getData();
				var that = this;
				var pageId = this.getView().byId("idProdOrdHeader");
				pageId.setBusy(true);

				this._mainService.create("/OrderHdrSet", sData, {
					success: function (data) {
						pageId.setBusy(false);
						if (data.MsgType === "S") {
							sap.m.MessageBox.success(data.MsgDesc);
						} else {
							sap.m.MessageBox.error(data.MsgDesc);
						}
					},
					error: function () {
						pageId.setBusy(false);
						sap.m.MessageBox.error(that.getView().getModel("i18n").getResourceBundle().getText("noDataFound"));
					}
				});
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf coib.SIE_ASP_WM_COIB.view.COIBOrderHeader
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf coib.SIE_ASP_WM_COIB.view.COIBOrderHeader
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf coib.SIE_ASP_WM_COIB.view.COIBOrderHeader
		 */
		//	onExit: function() {
		//
		//	}

	});

});