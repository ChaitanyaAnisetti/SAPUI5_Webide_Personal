sap.ui.define(function () {
	var Formatter = {

		Requesdate: function (ReqDate) {

			if (ReqDate) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var Datevalue = oDateFormat.format(new Date(ReqDate));
				return Datevalue;
			} else {
				return "";
			}
		},
		ExpDeldate: function (ExpDelDt) {
			if (ExpDelDt) {
				var oDateFormat2 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var Datevalue2 = oDateFormat2.format(new Date(ExpDelDt));
				return Datevalue2;
			} else {
				return "";
			}
		},

		OrdConfirmDate: function (OrdConfirmDate) {
			if (OrdConfirmDate) {
				var oDateFormatA = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var DatevalueA = oDateFormatA.format(new Date(OrdConfirmDate));
				return DatevalueA;
			} else {
				return "";

			}

		},
		InboundDelDate: function (InboundDelDate) {

			if (InboundDelDate) {
				var oDateFormatB = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var DatevalueB = oDateFormatB.format(new Date(InboundDelDate));
				return DatevalueB;
			} else {
				return "";
			}

		},
		GrEntryDate: function (GrEntryDate) {

			if (GrEntryDate) {
				var oDateFormatC = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var DatevalueC = oDateFormatC.format(new Date(GrEntryDate));
				return DatevalueC;
			} else {
				return "";

			}

		},
		IntDelDt: function (IntDelDt) {

			if (IntDelDt) {
				var oDateFormatD = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var DatevalueD = oDateFormatD.format(new Date(IntDelDt));
				return DatevalueD;
			} else {
				return "";
			}

		},
		InvEntryDate: function (InvEntryDate) {

			if (InvEntryDate) {
				var oDateFormatE = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var DatevalueE = oDateFormatE.format(new Date(InvEntryDate));
				return DatevalueE;
			} else {
				return "";

			}

		},

		oServiceNum: function (ASNUM) {
			if (ASNUM) {
				var oServceText = ASNUM.replace(/\b0+/g, '');
				return oServceText;
			}

		},
		UnitPrice: function (UnitPrice) {

			if (UnitPrice != null && UnitPrice != undefined) {

				return Number(UnitPrice).toFixed(3);

			};

		},

		TotalPrice: function (TotalPrice) {
			if (TotalPrice != null && TotalPrice != undefined) {

				return Number(TotalPrice).toFixed(3);

			};

		},
		/*TableDelDate: function (oDp2ref) {
			if (oDp2ref) {
				var oDateFormat2 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var Datevalue2 = oDateFormat2.format(new Date(oDp2ref));
				return Datevalue2;
			} else {
				return "";
			}
		},*/
		TableDelDate: function (oDp2ref) {
			if (oDp2ref) {
				var oDateFormat2 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var Datevalue2 = oDateFormat2.format(new Date(oDp2ref));
				return Datevalue2;
			} else {
				return "";
			}
		},

		formatDate: function (v) {

			if (v != null && v != "00000000") {
				var d = new Date(v);
				var day = d.getDate();
				var q = d.getFullYear();
				var w = d.getMonth();

				var myYear = q;
				// var sptdate = String(w).split(" ");
				var ab = w;
				var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
				var myMonth = months[ab];
				var combineDatestr = myMonth + " " + day + "," + myYear;
				return combineDatestr;

			} else {
				return "";
			}
		},

		DateofInvc: function (DateOfInvoice) {
			if (DateOfInvoice != null) {
				var oDateFormatA = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var DatevalueA = oDateFormatA.format(new Date(DateOfInvoice));
				return DatevalueA;
			} else {
				DatevalueA = "";
			}

		},
		Dateofposting: function (DateOfPosting) {
			if (DateOfPosting != null) {
				var oDateFormat3 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var Datevalue3 = oDateFormat3.format(new Date(DateOfPosting));
				return Datevalue3;
			} else {
				Datevalue3 = "";
			}

		},
		GrEnvDate: function (GrEnvDate) {
			if (GrEnvDate != null) {
				var oDateFormat4 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var Datevalue4 = oDateFormat4.format(new Date(GrEnvDate));
				return Datevalue4;
			} else {
				Datevalue4 = "";
			}

		},
		/*InboundDelDate: function (InboundDelDate) {
			if (InboundDelDate)
				var oDateFormat5 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
			var Datevalue5 = oDateFormat5.format(new Date(InboundDelDate));
			return Datevalue5;

		},
		IntDelDate: function (IntDelDate) {
			if (IntDelDate)
				var oDateFormat6 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
			var Datevalue6 = oDateFormat6.format(new Date(IntDelDate));
			return Datevalue6;

		},
		InvEntryDate: function (InvEntryDate) {
			if (InvEntryDate)
				var oDateFormat7 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
			var Datevalue7 = oDateFormat7.format(new Date(InvEntryDate));
			return Datevalue7;

		},
		OrdConfirmDate: function (OrdConfirmDate) {
			if (OrdConfirmDate)
				var oDateFormat8 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
			var Datevalue8 = oDateFormat8.format(new Date(OrdConfirmDate));
			return Datevalue8;

		},*/
		DateOfPost: function (DateOfPost) {
			if (DateOfPost != null) {
				var oDateFormat9 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var Datevalue9 = oDateFormat9.format(new Date(DateOfPost));
				return Datevalue9;
			} else {
				Datevalue9 = "";
			}

		},
		matnr: function (matnr) {
			if (matnr != undefined && matnr != null && matnr != "") {
				return matnr.replace(/\b0+/g, '');
			} else {
				return "";
			}
		},
		Status: function (Status) {
			if (Status == "Approved") {
				return "sap-icon://accept";
			} else if (Status == "Rejected") {
				return "sap-icon://decline";
			} else {
				return "";
			}
		},
		State: function (Status) {
			if (Status == "Approved") {
				return "Success";
			} else if (Status == "Rejected") {
				return "Error";
			} else {
				return "None";
			}
		},

	};

	return Formatter;
}, true);