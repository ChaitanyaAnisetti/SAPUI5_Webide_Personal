jQuery.sap.includeStyleSheet(sap.ui.resource("P2P", "css/style.css"));

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageBox',
	'sap/m/MessagePopover',
	"sap/ui/core/syncStyleClass",
	'sap/m/MessageItem',
	"sap/ui/model/Filter",

	"sap/m/UploadCollectionParameter",
	"sap/ui/model/FilterOperator",
	"sap/m/Dialog",
	"sap/m/BusyDialog",
	"sap/ui/core/Fragment"
], function (Controller, Dialog, MessageBox, MessagePopover, syncStyleClass, MessageItem, Filter, UploadCollectionParameter,
	FilterOperator, BusyDialog, Fragment) {
	"use strict";
	var iTimeoutId;
	debugger
var browser = navigator.userAgent.toLowerCase().indexOf('chrome') > -1 ? 'chrome' : 'other';
	/*	var oMessageTemplate = new sap.m.MessagePopoverItem({
			type: '{message>type}',
			title: '{message>message}',
			description: '{message>message}'
		});
		var oMessagePopover = new sap.m.MessagePopover({
			items: {
				path: 'message>/',
				template: oMessageTemplate
			}
		});*/
	var oMessageTemplate = new sap.m.MessagePopoverItem({
		type: '{type}',
		title: '{message}',
		description: '{message}'
	});
	var oMessagePopover = new sap.m.MessagePopover({
		items: {
			path: '/',
			template: oMessageTemplate
		}
	});
	oMessagePopover.setModel(sap.ui.getCore().getMessageManager().getMessageModel(), "message");
	return Controller.extend("P2P.controller.Creat", {

		onInit: function () {
			this.getRouter("Creat").attachRouteMatched(this.onRouteMatched, this);
			this.url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";
			var BusinessUnit_Model = new sap.ui.model.odata.v2.ODataModel(this.url, true);
			this.getView().setModel(BusinessUnit_Model, "BusinessUnit_Model");

			this.oModelunlockCreate = new sap.ui.model.odata.ODataModel(this.url, true

			);
			sap.ui.getCore().setModel(this.oModelunlockCreate, "oModelunlockCreate");
			//var that=this;
			this.oItemUlr = "/sap/opu/odata/sap/MMPUR_REQ_SSP_MAINTAIN_SRV";
			/*var Materialgrop_Model = new sap.ui.model.odata.v2.ODataModel(this.oItemUlr, true);
			this.getView().setModel(Materialgrop_Model);*/

			this.oModelItems = new sap.ui.model.odata.ODataModel(this.oItemUlr, true);
			sap.ui.getCore().setModel(this.oModelItems, "oModelItems");

			//create URL : 	http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/PR_HeaderSet
			//   http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/PR_HeaderSet('30000221')/PR_ItemSet

			//Create :   http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/PR_HeaderSet

		},
		onBack: function () {
			var that = this;

			that.getRouter().navTo("View1", {

				//var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				//	oRouter.navTo("View1", {

			});

		},
		getRouter: function () {

			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		onChangeExptype: function (oEvt) {
			
	/*	var oExtype =	this.getView().byId("idReqType").getModel();
		var oPicker = oExtype.getPicker();
          if (oPicker) {
            oPicker.attachBeforeOpen(function() {
            	
              
              oPicker.setContentMinWidth(oPicker.getWidth());
            });
          } else {
            window.alert("Picker is empty");
          }*/
			

			var oRequestType = this.getView().byId("idReqType").getSelectedKey();
			if (oRequestType === "ZSS") {

				this.getView().byId("idPGrp").getItems()[1].setEnabled(false);
			} else {
				this.getView().byId("idPGrp").getItems()[1].setEnabled(true);

			}

			this.oExpType = oEvt.getSource().getSelectedKey();
			if (this.oExpType == "" || this.oExpType == undefined || this.oExpType == null) {
				this.getView().byId("idPGrp").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);

				return;
			} else {
				this.getView().byId("idPGrp").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
			}

			if (this.oExpType == "K" || this.oExpType == "A") {
				this.getView().byId("catalogTab_coltotal").setVisible(true);
				this.getView().byId("catalogTabcoltotal").setVisible(false);
			} else {
				this.getView().byId("catalogTab_coltotal").setVisible(false);
				this.getView().byId("catalogTabcoltotal").setVisible(true);
			}

		},

		/****************************Bussiness Unit Search help Begin*****************************************/
		handleValueHelpBU1: function (oEvent) {

			this.getView().byId("InputValueBDept").setValue("");
			this.getView().byId("idBuApptext").setText("");

			var sInputValue = oEvent.getSource().getValue();
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment(
					"P2P.Fragment.Bussinessunit",
					this
				);
				this.getView().addDependent(this._valueHelpDialog);
			}
			var that = this;
			this.oModelunlockCreate.read("/ZmmshBuSet", null, null, true, function (oData, oRespone) {
				var Data = oData.results;
				var oBumodel = new sap.ui.model.json.JSONModel(Data);
				sap.ui.getCore().byId("oBuFrag").setModel(oBumodel);
				that._valueHelpDialog.open(sInputValue);
			}, function (error) {

			});

		},
		onBuCancel: function () {
			this._valueHelpDialog.destroy(true);
			this._valueHelpDialog = undefined;
		},
		//Bussiness Unit Fragment Confirm Press event Start
		onBuConfirm: function (oEvent) {

			var oSelectedItemBuDes = oEvent.getParameters().selectedItem.mProperties.description;
			this.oBuConfirmtitle = oEvent.getParameters().selectedItem.mProperties.title;

			if (oSelectedItemBuDes == "" || oSelectedItemBuDes == undefined || oSelectedItemBuDes == null) {
				this.getView().byId("InputValueBU1").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);

				return;
			} else {
				this.getView().byId("InputValueBU1").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
			}

			if (oSelectedItemBuDes) {
				var productInput = this.getView().byId("InputValueBU1");
				productInput.setValue(oSelectedItemBuDes);
				this.oBusinessdesc = productInput.mProperties.value;
			}
			oEvent.getSource().getBinding("items").filter([]);

			this._valueHelpDialog.destroy(true);
			this._valueHelpDialog = undefined;
		},
		//Bussiness Unit Fragment Confirm Press event End
		//Bussiness Unit Fragment Search items Press event Start
		handleBuConfirmSearch_Press: function (oEvt) {

			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oBuFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("ZzbuDesc", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("Zzbu", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		//Bussiness Unit Fragment Search items Press event End
		/****************************Bussiness Unit Search help End*************************************************/
		/****************************Bussiness Department Search help Start*****************************************/
		handleValueHelpBDept: function (oEvent) {
			this.getView().byId("idBuApptext").setText("");
			this.oBuConfirmtitle;
			var sInputValue2 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog2) {
				this._valueHelpDialog2 = sap.ui.xmlfragment(
					"P2P.Fragment.BussinessDept",
					this
				);
				this.getView().addDependent(this._valueHelpDialog2);
			}
			var that = this;
			//	this.oModelunlockCreate.read("/ZmmshDeptCode2Set", null, null, true, function (oData, oRespone) {
			this.oModelunlockCreate.read("/ZMM_DEPT_MASTERSet", null, null, true, function (oData, oRespone) {
				var Data = oData.results;

				var oFIlterResults = Data.filter(function (x) {
					return x.Zzbu == that.oBuConfirmtitle;

				});

				var oBuDeptmodel = new sap.ui.model.json.JSONModel(oFIlterResults);
				sap.ui.getCore().byId("oBuDeptFrag").setModel(oBuDeptmodel);
				that._valueHelpDialog2.open(sInputValue2);
			}, function (error) {

			});

		},
		onBuDeptCancel: function () {
			this._valueHelpDialog2.destroy(true);
			this._valueHelpDialog2 = undefined;
		},
		//Bussiness Unit Fragment Confirm Press event Start
		onBuDeptConfirm: function (oEvent) {
			var oSelectedItem = oEvent.getParameters().selectedItem.mProperties.description;

			if (oSelectedItem == "" || oSelectedItem == undefined || oSelectedItem == null) {
				this.getView().byId("InputValueBDept").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);

				return;
			} else {
				this.getView().byId("InputValueBDept").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
			}

			var oAppName = oEvent.getParameters().selectedItem.mProperties.info;
			this.BussDescbj = oEvent.getParameters().selectedItem.mProperties.title;
			this.getView().byId("idBuApptext").setText(oAppName);
			//	this.oBuDeptConfirmtitle = oEvent.getParameters().selectedItem.mProperties.title;
			if (oSelectedItem) {
				var productInputBuDp = this.getView().byId("InputValueBDept");
				productInputBuDp.setValue(oSelectedItem);
				this.oBusinesdeptdesc = productInputBuDp.mProperties.value;

			}
			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialog2.destroy(true);
			this._valueHelpDialog2 = undefined;
		},
		//Bussiness Unit Fragment Confirm Press event End
		//Bussiness Unit Fragment Search Press event Start
		handleBuDepConfSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oBuDeptFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("ZzdeptDesc2", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("ZzdeptCode2", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("ZzaprL3Name", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("ZzaprL3", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		//Bussiness Unit Fragment Search Press event End

		/****************************Bussiness Department Search help End*****************************************/
		/**************************** Plant Search help Start*****************************************/
		handleValueHelpPlnt: function (oEvent) {
			/*	this.oBuConfirmtitle;*/
			this.getView().byId("InputValueAgrmt").setValue("");
			var sInputValueP = oEvent.getSource().getValue();
			if (!this._valueHelpDialogP) {
				this._valueHelpDialogP = sap.ui.xmlfragment(
					"P2P.Fragment.Plant",
					this
				);
				this.getView().addDependent(this._valueHelpDialogP);
			}
			var that = this;
			this.oModelItems.read("/I_Plant", null, null, true, function (oData, oRespone) {
				var Data = oData.results;

				var oPlantmodl = new sap.ui.model.json.JSONModel(Data);
				sap.ui.getCore().byId("oidPlantFrag").setModel(oPlantmodl);
				that._valueHelpDialogP.open(sInputValueP);

			}, function (error) {

			});

		},

		_handlePlntHelpClose: function () {
			this._valueHelpDialogP.destroy(true);
			this._valueHelpDialogP = undefined;

		},

		//Plant  Fragment Confirm Press event Start
		_handlePlntHelpCnf: function (oEvent) {
			this.oSelectedItemplt = oEvent.getParameters().selectedItem.mProperties.title;
			if (this.oSelectedItemplt == "" || this.oSelectedItemplt == undefined || this.oSelectedItemplt == null) {
				this.getView().byId("InputValuePlnt").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);

				return;
			} else {
				this.getView().byId("InputValuePlnt").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
			}
			if (this.oSelectedItemplt === "1001" && (this.Catlogkey === "ZSM" || this.Catlogkey === "ZSC" || this.Catlogkey === "ZST"))  {
			
				sap.m.MessageBox.warning("Please specify delivery location as Madhapur or Manikonda in justification text.", {

					actions: ["OK and Proceed"],
					onClose: function (oAction) {

					}

				});
			} else {

			};

			var oAppName = oEvent.getParameters().selectedItem.mProperties.description;

			if (this.oSelectedItemplt) {
				this.productInputBuDp = this.getView().byId("InputValuePlnt");
				this.productInputBuDp.setValue(this.oSelectedItemplt);

			}

			this.oPurchaseGroup();

			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialogP.destroy(true);
			this._valueHelpDialogP = undefined;

		},

		//Plant  Fragment Confirm Press event End
		//Plant  Fragment Search Press event Start
		_handleValueplntcnfSearch: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oidPlantFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("PlantName", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		//Plant Fragment Search Press event End

		/**************************** Plant Search help End*****************************************/
		/********************************Requisitioner  Search help Start*****************************************/
		handleValueHelpReqr: function (oEvent) {
			var sInputValue3 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog3) {
				this._valueHelpDialog3 = sap.ui.xmlfragment(
					"P2P.Fragment.Requestioner",
					this
				);
				this.getView().addDependent(this._valueHelpDialog3);
			}
			var that = this;
			this.oModelunlockCreate.read("/ZmmshAfnamSet", null, null, true, function (oData, oRespone) {
				var Data = oData.results;
				var oReqmodel = new sap.ui.model.json.JSONModel(Data);
				sap.ui.getCore().byId("oRequisitionerFrag").setModel(oReqmodel);
				that._valueHelpDialog3.open(sInputValue3);
			}, function (error) {

			});

		},
		onReqCancel: function () {
			this._valueHelpDialog3.destroy(true);
			this._valueHelpDialog3 = undefined;

		},
		//Requsitioner Fragment Confirm Press event Start
		onReqConfirm: function (oEvent) {

			this.oSelectedItemReq = oEvent.getParameters().selectedItem.mProperties.title;
			if (this.oSelectedItemReq == "" || this.oSelectedItemReq == undefined || this.oSelectedItemReq == null) {
				this.getView().byId("InputValueRequr").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);

				return;
			} else {
				this.getView().byId("InputValueRequr").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
			}

			var oManagerName = oEvent.getParameters().selectedItem.mProperties.description;
			this.getView().byId("idManagertext").setText(oManagerName);
			if (this.oSelectedItemReq) {
				var productInputBuDp = this.getView().byId("InputValueRequr");
				productInputBuDp.setValue(this.oSelectedItemReq);

			}
			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialog3.destroy(true);
			this._valueHelpDialog3 = undefined;
		},
		//Requsitioner  Fragment Confirm Press event End
		//Requsitioner  Fragment Search Press event Start
		handleReqConfSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oRequisitionerFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("Afnam", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("ZzassName", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("ZzmngAssName", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		//Requsitioner Fragment Search Press event End

		/***********************************Requisitioner Search help End*****************************************/
		/****************************Manager Search help Start*****************************************************/
		handleValueHelpManager: function (oEvent) {

			this.oSelectedItemReq;
			var sInputValue4 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog4) {
				this._valueHelpDialog4 = sap.ui.xmlfragment(
					"P2P.Fragment.BussinessDept",
					this
				);
				this.getView().addDependent(this._valueHelpDialog4);
			}
			var that = this;
			this.oModelunlockCreate.read("/ZmmshDeptCode2Set", null, null, true, function (oData, oRespone) {
				var Data = oData.results;

				var oFIlterResults = Data.filter(function (x) {
					return x.ZzassName == this.oSelectedItemReq;

				});

				var oManagermodel = new sap.ui.model.json.JSONModel(oFIlterResults);
				sap.ui.getCore().byId("oManagerFrag").setModel(oManagermodel);
				that._valueHelpDialog4.open(sInputValue4);
			}, function (error) {

			});

		},

		/****************************Aggreement  Search help Start*******************************************/
		handleValueHelpAgrmt: function (oEvent) {

			var oPlnt = this.getView().byId("InputValuePlnt").getValue();
			if (oPlnt == "") {
				sap.m.MessageBox.error("Please select Location");
			} else {

				var sInputValue_ag = oEvent.getSource().getValue();
				if (!this._valueHelpDialog_a) {
					this._valueHelpDialog_a = sap.ui.xmlfragment(
						"P2P.Fragment.Aggrement",
						this
					);
					this.getView().addDependent(this._valueHelpDialog_a);
				}
				var that = this;
				this.oModelunlockCreate.read("/ymm_agreement_headerSet", null, null, true, function (oData, oRespone) {
					var Data = oData.results;

					var oFilteredAgr = Data.filter(function (x) {
						return x.werks == that.oSelectedItemplt;

					});

					var oAggrimodel = new sap.ui.model.json.JSONModel(oFilteredAgr);

					sap.ui.getCore().byId("oidAgrFrag").setModel(oAggrimodel);

					/*for (var i = 0; i < oFilteredAgr.length; i++) {
						if (a.indexOf(oFilteredAgr[i].werks) === -1) {
							a.push(oFilteredAgr[i].werks);
						}
					}*/

					/*	var obj = {};

						for (var i = 0, len = oFilteredAgr.length; i < len; i++)
							obj[oFilteredAgr[i]['ebeln']] = oFilteredAgr[i];

						var oEbeln = new Array();
						for (var key in obj)
							oEbeln.push(obj[key]);
						oAggrimodel.setProperty("/ebeln", oEbeln);
						var oAgrref = oAggrimodel.oData.ebeln;
						sap.ui.getCore().byId("oidAgrFrag").setModel(oAgrref);*/
					that._valueHelpDialog_a.open(sInputValue_ag);
				}, function (error) {

				});
			}

		},
		//Aggrement Fragment Confirm Press event Start
		handleValueHelpAgrCfrm: function (oEvent) {

			this.oAgrmnt = oEvent.getParameters().selectedItem.mProperties.title;
			//var oMatgrpName = oEvent.getParameters().selectedItem.mProperties.description;
			this.getView().byId("InputValueAgrmt").setValue(this.oAgrmnt);
			if (this.oSelectedagrmt) {
				this.Agrmrntvalue = sap.ui.getCore().byId("oidAgrFrag");
				this.Agrmrntvalue.setValue(this.oSelectedagrmt);
			}
			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialog_a.destroy(true);
			this._valueHelpDialog_a = undefined;
		},
		handleValueHelpAgrClose: function (oEvt) {
			//this._valueHelpDialog_a.close();
			this._valueHelpDialog_a.destroy(true);
			this._valueHelpDialog_a = undefined;
		},
		//Aggrement   Fragment Confirm Press event End
		//Aggrement   Fragment Search Press event Start
		handleValueHelpAgrSearch: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oidAgrFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("ebeln", sap.ui.model.FilterOperator.Contains, sQuery)

				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},

		//Aggrement Fragment Search Press event End

		/****************************Manager Department Search help End*****************************************/
		/****************************Material Group Search help Start*******************************************/
		handleValueHelpMatGrp: function (oEvent) {

			var sInputValue5 = oEvent.getSource().getValue();
			if (sInputValue5 === "0") {
				sap.ui.getCore().byId("idTxt_Glacnt").setText("");
			}

			if (!this._valueHelpDialog5) {
				this._valueHelpDialog5 = sap.ui.xmlfragment(
					"P2P.Fragment.MaterialGroup",
					this
				);
				this.getView().addDependent(this._valueHelpDialog5);
			}
			var that = this;
			this.oModelunlockCreate.read("/ymm_sh_glSet", null, null, true, function (oData, oRespone) {
				var Data = oData.results;

				/*	var oFIlterResults = Data.filter(function (x) {
						return x.ZzdeptCode2 == that.oBuConfirmtitle;

					});*/
				/* oMatGrpmodel*/
				var oMatrpmodel = new sap.ui.model.json.JSONModel(Data);
				sap.ui.getCore().byId("oMatgrpFrag").setModel(oMatrpmodel);

				that._valueHelpDialog5.open(sInputValue5);

			}, function (error) {

			});

		},
		//Material Group Fragment Confirm Press event Start
		onMatGrpConfirm: function (oEvent) {

			this.oNewMatmatnr = oEvent.getParameters().selectedItem.mProperties.title;
			this.oModelunlockCreate.read("/ymm_sh_glSet(matkl='" + this.oNewMatmatnr + "')", null, null, true, function (oData, oRespone) {
				var Data = oData;
				var oglrf = Data.sakto;

				var oGlacnt = sap.ui.getCore().byId("idTxt_Glacnt").setText(oglrf);

			});
			/*	var oGlref = that.oMatrpmodel.filter(function (x) {
					return x.matkl == this.oSelectedMatgrp;
				});*/

			var oMatgrpName = oEvent.getParameters().selectedItem.mProperties.description;
			sap.ui.getCore().byId("InputValueMatgrp").setValue(this.oSelectedMatgrp);
			if (this.oSelectedMatgrp) {
				this.productInputBuDp = sap.ui.getCore().byId("InputValueMatgrp");
				this.productInputBuDp.setValue(this.oSelectedMatgrp);
			}
			oEvent.getSource().getBinding("items").filter([]);
		},
		//Material Group  Fragment Confirm Press event End
		//Material Group  Fragment Search Press event Start
		handleMatgrpSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oMatgrpFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("matkl", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("WGBEZ", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		//Material Group Fragment Search Press event End
		/********************************Material Group Search help End*****************************************/
		onMaterGropchange: function (oEvt) {
			var oMatgrpval = sap.ui.getCore().byId("InputValueMatgrp").getValue();
			if (oMatgrpval === "0") {
				sap.ui.getCore().byId("idTxt_Glacnt").setText("");
			}

		},
		/***************************Material Code Search help Start*******************************************/
		handleValueHelpMatCode: function (oEvent) {

			var sInputValue11 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog11) {
				this._valueHelpDialog11 = sap.ui.xmlfragment(
					"P2P.Fragment.MaterialCode",
					this
				);
				this.getView().addDependent(this._valueHelpDialog11);
			}
			var that = this;

			var oMatcodel = "/ymm_material_codeSet(werks='" + this.oSelectedItemplt +
				"')/ymm_materialcode_ass_set_nav";
			this.oModelunlockCreate.read(oMatcodel, null, null, true, function (oData, oRespone) {
				var Data = oData.results;

				if (!Array.isArray(Data)) {
					Data = [oData];
				}

				var oMatodemodl = new sap.ui.model.json.JSONModel(Data);
				sap.ui.getCore().byId("oMatecodeFrag").setModel(oMatodemodl);
				that._valueHelpDialog11.open(sInputValue11);
			}, function (error) {

			});

		},
		//Material Code Fragment Confirm Press event Start
		onMatCodConfirm: function (oEvent) {

			this.oSelectedMatcode = oEvent.getParameters().selectedItem.mProperties.title;
			var oMatgrpName = oEvent.getParameters().selectedItem.mProperties.description;
			sap.ui.getCore().byId("InputValueMatCode").setValue(this.oSelectedMatcode);
			if (this.oSelectedMatcode) {
				this.productInputBuDp = sap.ui.getCore().byId("InputValueMatCode");
				this.productInputBuDp.setValue(this.oSelectedMatcode);

			}
			oEvent.getSource().getBinding("items").filter([]);
		},
		//Material Code  Fragment Confirm Press event End
		//Material Code  Fragment Search Press event Start
		handleMatCodSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oMatecodeFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("matnr", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("maktx", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		//Material Code Fragment Search Press event End
		/********************************Material Code Search help End*****************************************/

		/***************************Material Desc Search help Start*******************************************/
		handleValueHelpMatDesc: function (oEvent) {
			this.oSlectdAggrement = this.getView().byId("InputValueAgrmt").getValue();
			var sInputValue1_y = oEvent.getSource().getValue();
			if (!this._valueHelpDialog_y) {
				this._valueHelpDialog_y = sap.ui.xmlfragment(
					"P2P.Fragment.MaterialDescription",
					this
				);
				this.getView().addDependent(this._valueHelpDialog_y);
			}
			var that = this;

			if (that.Catlogkey === "ZSC") {
				var oMatDesccodeAgr = "/ymm_agreement_headerSet(ebeln='" + this.oSlectdAggrement + "'," + "werks='" + this.oSelectedItemplt +
					"')/ymm_agreement_assc_nav_set";

				this.oModelunlockCreate.read(oMatDesccodeAgr, null, null, true, function (oData, oRespone) {
					var Data1 = oData.results;

					if (!Array.isArray(Data1)) {
						Data1 = [oData];
					}

					var Data = Data1.filter(function (x) {
						return x.req_category == that.oBuyr;
					});

					var oMatodemodldes = new sap.ui.model.json.JSONModel(Data);
					sap.ui.getCore().byId("oMatDesFrag").setModel(oMatodemodldes);
					that._valueHelpDialog_y.open(sInputValue1_y);
				}, function (error) {

				});

			} else {

				var oMatcodel = "/ymm_material_codeSet(werks='" + this.oSelectedItemplt +
					"')/ymm_materialcode_ass_set_nav";
				this.oModelunlockCreate.read(oMatcodel, null, null, true, function (oData, oRespone) {
					var Data1 = oData.results;

					if (!Array.isArray(Data1)) {
						Data1 = [oData];
					}
					var Data = Data1.filter(function (x) {
						return x.req_category == that.oBuyr;
					});

					/*if ((that.oBuyr == "HARDWARE" || that.oBuyr == "SOFTWARE" || that.oBuyr == "MECHTRONIC" || that.oBuyr == "OFFLOADING")) {

						var Data = Data1.filter(function (x) {
							return x.WGBEZ60 == that.oBuyr;
						});

					} else {
						var Data = Data1.filter(function (x) {
						
							return x.WGBEZ60;
						});

					}*/

					var oMatodemodldes = new sap.ui.model.json.JSONModel(Data);
					sap.ui.getCore().byId("oMatDesFrag").setModel(oMatodemodldes);
					that._valueHelpDialog_y.open(sInputValue1_y);
				}, function (error) {

				});
			}

		},
		//Material Desc Fragment Confirm Press event Start
		onMatdesConfirm: function (oEvent) {

			if (this.Catlogkey === "ZSC") {

				this.oUntMeasure = oEvent.getParameter("selectedItem").getBindingContext().getObject().UnitOfMeasure;
				this.oCurrncy = oEvent.getParameter("selectedItem").getBindingContext().getObject().Currency;
				this.oPriceval = oEvent.getParameter("selectedItem").getBindingContext().getObject().NETPR;

				sap.ui.getCore().byId("InputValueUnit").setValue(this.oUntMeasure);
				sap.ui.getCore().byId("InputValueCurrency").setValue(this.oCurrncy);
				sap.ui.getCore().byId("idUntprce_Frag").setValue(this.oPriceval);

				this.Aggrementnum = oEvent.getParameter("selectedItem").getBindingContext().getObject().ebeln;
				this.oAggrntItemno = oEvent.getParameter("selectedItem").getBindingContext().getObject().ebelp;
				this.oNewMatcode = oEvent.getParameter("selectedItem").getBindingContext().getObject().matkl;
				this.oSelectedMaterialCode = oEvent.getParameter("selectedItem").getBindingContext().getObject().matnr;
				this.oNewMatmatnr = oEvent.getParameter("selectedItem").getBindingContext().getObject().matnr.replace(/\b0+/g, '');
				sap.ui.getCore().byId("InputValueMatCode").setValue(this.oNewMatmatnr);
				sap.ui.getCore().byId("InputValueMatgrp").setValue(this.oNewMatcode);

				this.oModelunlockCreate.read("/ymm_sh_glSet(matkl='" + this.oNewMatcode + "')", null, null, true, function (oData, oRespone) {
					var Data = oData;
					var oglrf = Data.sakto;
					var oZZCategry = Data.WGBEZ60;
					var oGlacnt = sap.ui.getCore().byId("idTxt_Glacnt").setText(oglrf);
					var zzcatryid = sap.ui.getCore().byId("idzzcategry").setText(oZZCategry);

				});

				/*	this.oModelunlockCreate.read("/ymm_material_codeSet(werks='" + this.oSelectedItemplt + "')/ymm_materialcode_ass_set_nav", null,
						null, true,
						function (oData, oRespone) {
							var Data = oData.results;

						});*/

				this.oSelectedMatdes = oEvent.getParameters().selectedItem.mProperties.title;
				var oMatDesc = oEvent.getParameters().selectedItem.mProperties.description;

				sap.ui.getCore().byId("InputValueMatDesc").setValue(this.oSelectedMatdes);
				if (this.oSelectedMatdes) {
					this.productInputBuDp = sap.ui.getCore().byId("InputValueMatDesc");
					this.productInputBuDp.setValue(this.oSelectedMatdes);

				}
				oEvent.getSource().getBinding("items").filter([]);

				this._valueHelpDialog_y.destroy(true);
				this._valueHelpDialog_y = undefined;

			} else {

				this.oNewMatcode = oEvent.getParameter("selectedItem").getBindingContext().getObject().matkl;
				this.oSelectedMaterialCode = oEvent.getParameter("selectedItem").getBindingContext().getObject().matnr;
				this.oNewMatmatnr = oEvent.getParameter("selectedItem").getBindingContext().getObject().matnr.replace(/\b0+/g, '');
				sap.ui.getCore().byId("InputValueMatCode").setValue(this.oNewMatmatnr);
				sap.ui.getCore().byId("InputValueMatgrp").setValue(this.oNewMatcode);

				this.oUntMeasure = oEvent.getParameter("selectedItem").getBindingContext().getObject().UnitOfMeasure;
				this.oCurrncy = oEvent.getParameter("selectedItem").getBindingContext().getObject().Currency;
				//	this.oPriceval = oEvent.getParameter("selectedItem").getBindingContext().getObject().NETPR;

				sap.ui.getCore().byId("InputValueUnit").setValue(this.oUntMeasure);
				sap.ui.getCore().byId("InputValueCurrency").setValue(this.oCurrncy);
				//	sap.ui.getCore().byId("idUntprce_Frag").setValue(this.oPriceval);

				this.oModelunlockCreate.read("/ymm_sh_glSet(matkl='" + this.oNewMatcode + "')", null, null, true, function (oData, oRespone) {
					var Data = oData;
					var oglrf = Data.sakto;
					var oZZCategry = Data.WGBEZ60;
					var oGlacnt = sap.ui.getCore().byId("idTxt_Glacnt").setText(oglrf);
					var zzcatryid = sap.ui.getCore().byId("idzzcategry").setText(oZZCategry);

				});

				this.oModelunlockCreate.read("/ymm_material_codeSet(werks='" + this.oSelectedItemplt + "')/ymm_materialcode_ass_set_nav", null,
					null, true,
					function (oData, oRespone) {
						var Data = oData.results;

					});

				this.oSelectedMatdes = oEvent.getParameters().selectedItem.mProperties.title;
				var oMatDesc = oEvent.getParameters().selectedItem.mProperties.description;
				sap.ui.getCore().byId("InputValueMatDesc").setValue(this.oSelectedMatdes);
				if (this.oSelectedMatdes) {
					this.productInputBuDp = sap.ui.getCore().byId("InputValueMatDesc");
					this.productInputBuDp.setValue(this.oSelectedMatdes);

				}
				oEvent.getSource().getBinding("items").filter([]);
				this._valueHelpDialog_y.destroy(true);
				this._valueHelpDialog_y = undefined;
			}
		},
		onMatdesCancel: function (oEvt) {
			//	this._valueHelpDialog_y.close();
			this._valueHelpDialog_y.destroy(true);
			this._valueHelpDialog_y = undefined;
		},

		//Material Desc  Fragment Confirm Press event End
		//Material Desc  Fragment Search Press event Start
		handleMatdesConfirmSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oMatDesFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("matnr", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("maktx", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		onLivematedesc: function () {

		},

		//Material Code Fragment Search Press event End
		/********************************Material Code Search help End*****************************************/

		/****************************Series Short text searchhelp Start*******************************************/
		handleValueHelpSerisDesc: function (oEvent) {
			this.oSlectdAggrement = this.getView().byId("InputValueAgrmt").getValue();
			var sInputValue_sd = oEvent.getSource().getValue();
			if (!this._valueHelpDialog_sd) {
				this._valueHelpDialog_sd = sap.ui.xmlfragment(
					"P2P.Fragment.ServiceDescription",
					this
				);
				this.getView().addDependent(this._valueHelpDialog_sd);
			}
			var that = this;
			/*var that = this;

			if (that.Catlogkey === "ZSC") {
				var oServesccodeAgr = "/ymm_agreement_headerSet(ebeln='" + this.oSlectdAggrement + "'," + "werks='" + this.oSelectedItemplt +
					"')/ymm_agreement_assc_nav_set";

				this.oModelunlockCreate.read(oServesccodeAgr, null, null, true, function (oData, oRespone) {
					var Data1 = oData.results;

					if (!Array.isArray(Data1)) {
						Data1 = [oData];
					}
						var Data = Data1.filter(function (x) {
					return x.req_category == that.oBuyr;
				});

					var oServDescmodel = new sap.ui.model.json.JSONModel(Data);

				sap.ui.getCore().byId("oServDescFrag").setModel(oServDescmodel);

				that._valueHelpDialog_sd.open(sInputValue_sd);
				}, function (error) {

				});

			} else {*/

			this.oModelunlockCreate.read("/ymm_service_shSet", null, null, true, function (oData, oRespone) {
				var Data1 = oData.results;
				if (!Array.isArray(Data1)) {
					Data1 = [oData];
				}
				var Data = Data1.filter(function (x) {
					return x.req_category == that.oBuyr;
				});

				var oServDescmodel = new sap.ui.model.json.JSONModel(Data);

				sap.ui.getCore().byId("oServDescFrag").setModel(oServDescmodel);

				that._valueHelpDialog_sd.open(sInputValue_sd);
			}, function (error) {

			});
			/*	}*/

		},
		//Aggrement Fragment Confirm Press event Start
		_handleValueHelpServDesCnfrm: function (oEvent) {
			var oNewMatcode = oEvent.getParameter("selectedItem").getBindingContext().getObject().matkl;
			this.oSelectedServDesc = oEvent.getParameters().selectedItem.mProperties.title;
			this.oSelectedServNum = oEvent.getParameters().selectedItem.mProperties.description;

			if (this.oSelectedServDesc) {
				this.oSerDec = sap.ui.getCore().byId("InputValueSeriesDesc");
				this.oSerDec.setValue(this.oSelectedServDesc);
			}
			sap.ui.getCore().byId("InputValueMatgrp").setValue(oNewMatcode);

			this.oModelunlockCreate.read("/ymm_sh_glSet(matkl='" + oNewMatcode + "')", null, null, true, function (oData, oRespone) {
				var Data = oData;
				var oglrf = Data.sakto;
				var oZZCategry = Data.WGBEZ60;
				var oGlacnt = sap.ui.getCore().byId("idTxt_Glacnt").setText(oglrf);
				var zzcatryid = sap.ui.getCore().byId("idzzcategry").setText(oZZCategry);

			});

			sap.ui.getCore().byId("InputValueServcCode").setValue(this.oSelectedServNum);

			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialog_sd.destroy(true);
			this._valueHelpDialog_sd = undefined;
		},
		_handleValueHelpServDesClose: function (oEvt) {
			//this._valueHelpDialog_a.close();
			this._valueHelpDialog_sd.destroy(true);
			this._valueHelpDialog_sd = undefined;
		},
		//Aggrement   Fragment Confirm Press event End
		//Aggrement   Fragment Search Press event Start
		_handleValueHelpServDesSearch: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oServDescFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("ASKTX", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("ASNUM", sap.ui.model.FilterOperator.Contains, sQuery)

				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},

		//***************Series Short text  Search help Press event End**************************************************/

		/****************************Purchase SPOC Group Search help Start*******************************************/
		handleValueHelpPurG: function (oEvent) {

			var sInputValue13 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog13) {
				this._valueHelpDialog13 = sap.ui.xmlfragment(
					"P2P.Fragment.PurchaseSPOC",
					this
				);
				this.getView().addDependent(this._valueHelpDialog13);
			}
			var that = this;

			/*	this.oReqKey = this.getView().byId("idPrType").getSelectedKey();
				var oUrlPurgrp = "/zmmsh_categorySet(ekgrp='" + this.oReqKey + "')";
				this.oModelunlockCreate.read(oUrlPurgrp, null, null, true, function (oData, oRespone) {
					var Data = oData;
					var oReqCategrymodel = new sap.ui.model.json.JSONModel(Data);
					sap.ui.getCore().byId("prchseSpocFrag").setModel(oReqCategrymodel);
					that._valueHelpDialog13.open(sInputValue13);
				}, function (error) {

				});*/

			/*	}, function (error) {

				});*/

		},
		//Purchase SPOC Fragment Confirm Press event Start
		onPurchGrpConfirm: function (oEvent) {

			this.oSelectedPucgrp = oEvent.getParameters().selectedItem.mProperties.title;
			var oPucrgrpName = oEvent.getParameters().selectedItem.mProperties.description;
			sap.ui.getCore().byId("InputValuePurG").setValue(this.oSelectedPucgrp);
			if (this.oSelectedPucgrp) {
				this.productInputPurcgrp = this.getView().byId("InputValuePurG");
				this.productInputPurcgrp.setValue(this.oSelectedPucgrp);

			}
			oEvent.getSource().getBinding("items").filter([]);
		},
		//Purchase SPOC  Fragment Confirm Press event End
		//Purchase SPOC   Fragment Search Press event Start
		handlePuchgrpSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("prchseSpocFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("Buyer", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("ekgrp", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		//Purchase SPOC Group Fragment Search Press event End
		/********************************Material Group Search help End*****************************************/

		/****************************Unit Search help Begin*****************************************/

		handleValueHelpUnit: function (oEvent) {

			var sInputValue6 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog6) {
				this._valueHelpDialog6 = sap.ui.xmlfragment(
					"P2P.Fragment.UnitSearchhelp",
					this
				);
				this.getView().addDependent(this._valueHelpDialog6);
			}
			var that = this;
			this.oModelItems.read("/I_UnitOfMeasure", null, null, true, function (oData, oRespone) {
				var Data = oData.results;
				var oUnitmodel = new sap.ui.model.json.JSONModel(Data);
				sap.ui.getCore().byId("oUnitsFrag").setModel(oUnitmodel);
				that._valueHelpDialog6.open(sInputValue6);
			}, function (error) {

			});

		},
		onUomCancel: function () {
			this._valueHelpDialog6.destroy(true);
			this._valueHelpDialog6 = undefined;

		},
		// Unit Fragment Confirm Press event Start
		oUomConfirm: function (oEvent) {

			var oSelectedUnit = oEvent.getParameters().selectedItem.mProperties.description;
			this.oBuConfirmtitleUnit = oEvent.getParameters().selectedItem.mProperties.title;
			if (this.oBuConfirmtitleUnit) {
				var productUnit = sap.ui.getCore().byId("InputValueUnit");
				productUnit.setValue(this.oBuConfirmtitleUnit);
			}
			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialog6.destroy(true);
			this._valueHelpDialog6 = undefined;

		},
		// Unit Fragment Confirm Press event End
		// Unit Fragment Search items Press event Start
		handleUomConfrmSearch_Press: function (oEvt) {

			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oUnitsFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("UnitOfMeasure", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("UnitOfMeasure_Text", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		// Unit Fragment Search items Press event End
		/****************************Unit Search help End*****************************************/
		/****************************Currency Search help Begin*****************************************/

		handleValueHelpCurrncy: function (oEvent) {
			var sInputValue7 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog7) {
				this._valueHelpDialog7 = sap.ui.xmlfragment(
					"P2P.Fragment.Currency",
					this
				);
				this.getView().addDependent(this._valueHelpDialog7);
			}
			var that = this;
			this.oModelItems.read("/I_Currency", null, null, true, function (oData, oRespone) {
				var Data = oData.results;
				var oCurrecymodel = new sap.ui.model.json.JSONModel(Data);
				sap.ui.getCore().byId("idCurrncyFrag").setModel(oCurrecymodel, "oCurrecymodel2");
				that._valueHelpDialog7.open(sInputValue7);
			}, function (error) {

			});

		},
		// Currency Fragment Confirm Press event Start
		onCurrConfirm: function (oEvent) {

			var oSelectedCurrncy = oEvent.getParameters().selectedItem.mProperties.description;
			this.oCurrncyConfirmtitle = oEvent.getParameters().selectedItem.mProperties.title;
			var Currncy = sap.ui.getCore().byId("InputValueCurrency");
			Currncy.setValue(this.oCurrncyConfirmtitle);

			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialog7.destroy(true);
			this._valueHelpDialog7 = undefined;

		},
		onCurrCancel: function (oEvent) {
			this._valueHelpDialog7.destroy(true);
			this._valueHelpDialog7 = undefined;

		},
		// Currency Fragment Confirm Press event End
		// Currency Fragment Search items Press event Start
		handleCurrncySearch_Press: function (oEvt) {

			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("idCurrncyFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("Currency", sap.ui.model.FilterOperator.Contains, sQuery)
				//	new sap.ui.model.Filter("Currency_Text", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		// Currency Fragment Search items Press event End
		/****************************Currency Search help End*****************************************/
		/****************************WBS Search help Begin*****************************************/

		handleValueHelpWbs: function (oEvent) {
			this.SelectedBuDesc = this.getView().byId("InputValueBU1").getValue();
			this.SelectedoPlant = this.getView().byId("InputValuePlnt").getValue();
			var sInputValue8 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog8) {
				this._valueHelpDialog8 = sap.ui.xmlfragment(
					"P2P.Fragment.WBS",
					this
				);
				this.getView().addDependent(this._valueHelpDialog8);
			}
			var that = this;

			/*   var Wbsurl = "ymm_cc_setSet(WERKS='1000',BU_DESC='A&D')?$expand=ymm_wbs_assc_nav_set"*/
			that.oModelunlockCreate.read("/ymm_cc_setSet(WERKS='" + that.SelectedoPlant + "',BU_DESC='" + that.SelectedBuDesc +
				"')?$expand=ymm_wbs_assc_nav_set", null, null, true,
				function (oData, oRespone) {
					var Data = oData.ymm_wbs_assc_nav_set.results;
					var oWBSmodel = new sap.ui.model.json.JSONModel(Data);
					sap.ui.getCore().byId("oWbsFrag").setModel(oWBSmodel);
					that._valueHelpDialog8.open(sInputValue8);
				},
				function (error) {

				});

		},
		onWbsCancel: function (oEvent) {
			this._valueHelpDialog8.destroy(true);
			this._valueHelpDialog8 = undefined;
		},

		// WBS Fragment Confirm Press event Start
		onWbsConfirm: function (oEvent) {

			var oSelectedWbs = oEvent.getParameters().selectedItem.mProperties.description;
			this.oWbsConfirmtitle = oEvent.getParameters().selectedItem.mProperties.title;
			var oWbs = sap.ui.getCore().byId("oWbscod");
			oWbs.setValue(this.oWbsConfirmtitle);

			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialog8.destroy(true);
			this._valueHelpDialog8 = undefined;

		},
		// WBS Fragment Confirm Press event End
		// WBS Fragment Search items Press event Start
		handleWbsConfirmSearch_Press: function (oEvt) {

			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oWbsFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("PSPNR", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("POST1", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		// WBS Fragment Search items Press event End
		/****************************WBS Search help End*****************************************/
		/****************************Cost center Search help Begin*****************************************/

		handleValueHelpCCode: function (oEvent) {
			this.SelectedBuDesc = this.getView().byId("InputValueBU1").getValue();
			this.SelectedoPlant = this.getView().byId("InputValuePlnt").getValue();
			var sInputValue9 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog9) {
				this._valueHelpDialog9 = sap.ui.xmlfragment(
					"P2P.Fragment.CostCenter",
					this
				);
				this.getView().addDependent(this._valueHelpDialog9);
			}
			var that = this;
			that.oModelunlockCreate.read("/ymm_cc_setSet(WERKS='" + that.SelectedoPlant + "',BU_DESC='" + that.SelectedBuDesc +
				"')?$expand=ymm_cc_nav_association_set", null, null, true,
				function (oData, oRespone) {
					var Data = oData.ymm_cc_nav_association_set.results;
					var oCCmodel = new sap.ui.model.json.JSONModel(Data);

					/*	var oWbsmodel = new sap.ui.model.json.JSONModel(Data);*/
					sap.ui.getCore().byId("oCCFrag").setModel(oCCmodel);
					that._valueHelpDialog9.open(sInputValue9);
				},
				function (error) {

				});

		},
		onCCCancel: function () {
			this._valueHelpDialog9.destroy(true);
			this._valueHelpDialog9 = undefined;
		},

		// Cost center Fragment Confirm Press event Start
		onCCConfirm: function (oEvent) {

			var oSelectedoCC = oEvent.getParameters().selectedItem.mProperties.description;
			this.oCCtitle = oEvent.getParameters().selectedItem.mProperties.title;
			var oCC = sap.ui.getCore().byId("oCCCode");
			oCC.setValue(this.oCCtitle);

			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialog9.destroy(true);
			this._valueHelpDialog9 = undefined;

		},
		// Cost center Fragment Confirm Press event End
		// Cost center Fragment Search items Press event Start
		handleCCConfirmSearch_Press: function (oEvt) {

			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oCCFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("kostl", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("LTEXT", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("prctr", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		onQuanity: function (oEvent) {
			var Qty = sap.ui.getCore().byId("idQntyFrag").getValue();
			var Quantiy =
				Qty.replace(/[^\d.]/g, '') // numbers and decimals only
				.replace(/(^[\d]{10})[\d]/g, '$1') // not more than 2 digits at the beginning
				.replace(/(\..*)\./g, '$1') // decimal can't exist more than once
				.replace(/(\.[\d]{3})./g, '$1');
			sap.ui.getCore().byId("idQntyFrag").setValue(Quantiy);
			this.oQtyId = sap.ui.getCore().byId("idQntyFrag").getValue();
			/*	this.oUntTprice.replace(/[^\d.]/g, '');*/
			this.oUntTprice = sap.ui.getCore().byId("idUntprce_Frag").getValue();

			this.totalval = this.oQtyId * this.oUntTprice;
			sap.ui.getCore().byId("idText_Frag").setText(this.totalval);

			/*	this.oCalc(Qty);*/
		},

		// Cost center Fragment Search items Press event End
		/****************************Cost center Search help End*****************************************/
		onChangeReqcategry: function (oEvent) {
			var that = this;
			this.oReqKey = this.getView().byId("idPrType").getSelectedKey();

			if (this.oReqKey == "" || this.oReqKey == undefined || this.oReqKey == null) {
				this.getView().byId("idPrType").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);

				return;
			} else {
				this.getView().byId("idPrType").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
			}
			that.oPurchaseGroup();
			//	this.oBuyr = oEvent.getSource()._getSelectedItemText();
			this.oBuyr = this.getView().byId("idPrType").getSelectedItem().getText();
			var GhdModel = new sap.ui.model.json.JSONModel();

			switch (this.oBuyr) {
			case "SOFTWARE":
				var SamData = {
					data: [{
							Reviewer: "Manager",
							Status: [

								{
									stats: "Forward",
									statskey: "forward"
								}, {
									stats: "No requirement",
									statskey: "Norequirement"
								}

							],
							Remarks: "",
							Action: [

								{
									Atcn: "Approve",
									ActnKey: "Approve"
								}, {
									Atcn: "Reject",
									ActnKey: "Reject"
								}

							]

						}, {
							Reviewer: "SAM",
							Status: [

								{
									stats: "Delivered from Inventory",
									statskey: "Inventory"
								}, {
									stats: "Back to back buy",
									statskey: "Backtobuy"
								}, {
									stats: "Allocated",
									statskey: "Allocated"
								}, {
									stats: "Non Standard",
									statskey: "Non Standard"
								}, {
									stats: "Quote Attached",
									statskey: "Quuote Attached"
								}

							],
							Remarks: "",
							Action: [

								{
									Atcn: "Approve",
									ActnKey: "Approve"
								}, {
									Atcn: "Reject",
									ActnKey: "Reject"
								}

							]

						},

						{
							Reviewer: "Buyer",
							Status: [

								{
									stats: "Quote attached",
									statskey: "Quoteattached"
								}, {
									stats: "Requirement Change",
									statskey: "Requirementchange"
								}

							],
							Remarks: "",
							Action: [

								{
									Atcn: "Approve",
									ActnKey: "Approve"
								}, {
									Atcn: "Reject",
									ActnKey: "Reject"
								}

							]

						}

					]

				};

				GhdModel.setData(SamData);
				this.getView().byId("oshmTable").setModel(GhdModel);

				break;
			case "HARDWARE":

				var HAMData = {
					data: [{
							Reviewer: "Manager",
							Status: [

								{
									stats: "Forward",
									statskey: "forward"
								}, {
									stats: "No requirement",
									statskey: "Norequirement"
								}

							],
							Remarks: "",
							Action: [

								{
									Atcn: "Approve",
									ActnKey: "Approve"
								}, {
									Atcn: "Reject",
									ActnKey: "Reject"
								}

							]

						}, {
							Reviewer: "HAM",
							Status: [

								{
									stats: "Delivered from Inventory",
									statskey: "Inventory"
								}, {
									stats: "Back to back buy",
									statskey: "Backtobuy"
								}, {
									stats: "Allocated",
									statskey: "Allocated"
								}, {
									stats: "Non Standard",
									statskey: "Non Standard"
								}, {
									stats: "Quote Attached",
									statskey: "Quuote Attached"
								}

							],
							Remarks: "",
							Action: [

								{
									Atcn: "Approve",
									ActnKey: "Approve"
								}, {
									Atcn: "Reject",
									ActnKey: "Reject"
								}

							]

						},

						{
							Reviewer: "Buyer",
							Status: [

								{
									stats: "Quote attached",
									statskey: "Quoteattached"
								}, {
									stats: "Requirement Change",
									statskey: "Requirementchange"
								}

							],
							Remarks: "",
							Action: [

								{
									Atcn: "Approve",
									ActnKey: "Approve"
								}, {
									Atcn: "Reject",
									ActnKey: "Reject"
								}

							]

						}

					]

				};
				GhdModel.setData(HAMData);
				this.getView().byId("oshmTable").setModel(GhdModel);
			default:
				var buyerData = {
					data: [{
						Reviewer: "Manager",
						Status: [

							{
								stats: "Forward",
								statskey: "forward"
							}, {
								stats: "No requirement",
								statskey: "Norequirement"
							}

						],
						Remarks: "",
						Action: [

							{
								Atcn: "Approve",
								ActnKey: "Approve"
							}, {
								Atcn: "Reject",
								ActnKey: "Reject"
							}

						]

					}, {
						Reviewer: "Buyer",
						Status: [

							{
								stats: "Quote attached",
								statskey: "Quoteattached"
							}, {
								stats: "Requirement Change",
								statskey: "Requirementchange"
							}

						],
						Remarks: "",
						Action: [

							{
								Atcn: "Approve",
								ActnKey: "Approve"
							}, {
								Atcn: "Reject",
								ActnKey: "Reject"
							}

						]

					}]

				};

				GhdModel.setData(buyerData);
				this.getView().byId("oshmTable").setModel(GhdModel);

			}
			//	var oUrlPurgrp = "/zmmsh_categorySet(ekgrp='" + this.oReqKey + "')";

			/* var oUrlPurgrp = "/zmmsh_categorySet(plant='" + this.oLocation + "',category='" + this.oBuyr +"')";
				
			this.oModelunlockCreate.read(oUrlPurgrp, null, null, true, function (oData, oRespone) {
					var Data = oData;
					var oPurGrpModel = new sap.ui.model.json.JSONModel(Data);
					that.getView().byId("idPuridGrop").setModel(oPurGrpModel);
					var xx = that.getView().byId("idPuridGrop").getModel().getData().Buyer;
					that.xx2 = that.getView().byId("idPuridGrop").getModel().getData().ekgrp;
					that.getView().byId("idPuridGrop").setValue(xx);
				},
				function (error) {

				});*/

		},

		oPurchaseGroup: function () {
			var that = this;
			that.Location = that.getView().byId("InputValuePlnt").getValue();
			that.Buyr = that.getView().byId("idPrType")._getSelectedItemText();
			that.getView().byId("idPuridGrop").setValue("");
			var oUrlPurgrp = "/zmmsh_categorySet(plant='" + that.Location + "',category='" + that.Buyr + "')";

			that.oModelunlockCreate.read(oUrlPurgrp, null, null, true, function (oData, oRespone) {
					var Data = oData;
					var oPurGrpModel = new sap.ui.model.json.JSONModel(Data);
					that.getView().byId("idPuridGrop").setModel(oPurGrpModel);
					var xx = that.getView().byId("idPuridGrop").getModel().getData().Buyer;
					that.xx2 = that.getView().byId("idPuridGrop").getModel().getData().ekgrp;
					that.getView().byId("idPuridGrop").setValue(xx);
				},
				function (error) {

				});
		},

		onChangeRequest: function (event) {

			/*	var oSelect = this.byId("idReqType");

				oSelect.setWrapItemsText(event.getParameter("state"));*/

			this.Catlogkey = this.getView().byId("idReqType").getSelectedKey();
			var oExpenseType = this.getView().byId("idPGrp").getSelectedKey();
			if (this.Catlogkey != "ZSS") {
				this.getView().byId("idPGrp").getItems()[1].setEnabled(true);

				/* this.getView().byId("idPGrp").setSelectedKey([1]);*/
			} else {
				this.getView().byId("idPGrp").getItems()[1].setEnabled(false);
				//	 this.getView().byId("idPGrp").setSelectedKey([0]);
				//	this.getView().byId("idPGrp").setSelectedItem(0);
				this.getView().byId("idPGrp").setValue("--Please Select Expense Type--");

			}

			this.getView().byId("oCreateId").setEnabled(true);
			this.getView().byId("oCancelId").setEnabled(true);

			if ((this.Catlogkey === "ZSM" || this.Catlogkey === "ZSC" || this.Catlogkey === "ZST")  && this.getView().byId("InputValuePlnt").getValue() === "1001") {

				sap.m.MessageBox.warning("Please specify delivery location as Madhapur or Manikonda in justification text.", {

					actions: ["OK and Proceed"],
					onClose: function (oAction) {

					}

				});
			
			} else {

			}

			if (this.Catlogkey == "" || this.Catlogkey == undefined || this.Catlogkey == null) {
				this.getView().byId("idReqType").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);

				return;
			} else {
				this.getView().byId("idReqType").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
			}

			if (this.Catlogkey === "ZSC") {
				this.getView().byId("idAgrmnt").setVisible(true);
				this.getView().byId("InputValueAgrmt").setVisible(true);

			} else {
				this.getView().byId("idAgrmnt").setVisible(false);
				this.getView().byId("InputValueAgrmt").setVisible(false);

			}
			if (this.Catlogkey === "ZSS") {
				/*	this.getView().byId("catalogSeies_col6").setVisible(true);
					this.getView().byId("catalogSeries_col1").setVisible(false);
					this.getView().byId("catalogseries_col3").setVisible(false);
					this.getView().byId("catalogTable_col6").setVisible(true);
					this.getView().byId("catalogTable_col1").setVisible(true);
					this.getView().byId("catalogTable_col3").setVisible(true);*/

			} else {
				/*	this.getView().byId("catalogSeies_col6").setVisible(false);
					this.getView().byId("catalogSeries_col1").setVisible(false);
					this.getView().byId("catalogseries_col3").setVisible(false);
					this.getView().byId("catalogTable_col6").setVisible(true);
					this.getView().byId("catalogTable_col1").setVisible(true);
					this.getView().byId("catalogTable_col3").setVisible(true);*/

			}

		},
		onChangeItem: function (oEvt) {

			//	this.SelectedItemtype = sap.ui.getCore().byId("idItmType")._getSelectedItemText();
			this.SelectedItemtype = sap.ui.getCore().byId("idItmType").getSelectedKey();
			sap.ui.getCore().byId("InputValueMatgrp").setValue("");

			if (this.SelectedItemtype == "0") {
				sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
				sap.ui.getCore().byId("oMatid").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
				sap.ui.getCore().byId("oServiceocde").setVisible(false);
				sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(false);
				sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);
				sap.ui.getCore().byId("idItmType").setSelectedKey("");
				sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(false);
				sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(false);

				sap.ui.getCore().byId("oMatedessdeslbl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
				sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatDesc").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
				sap.ui.getCore().byId("InputValueUnit").setEditable(true);
				sap.ui.getCore().byId("InputValueCurrency").setEditable(true);
				sap.ui.getCore().byId("idUntprce_Frag").setEditable(true);

			} else {
				sap.ui.getCore().byId("idItmType").setSelectedKey("9");
				//	sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(false);
				sap.ui.getCore().byId("InputValueMatCode").setVisible(false);
				sap.ui.getCore().byId("oMatid").setVisible(false);
				sap.ui.getCore().byId("oServiceocde").setVisible(true);
				sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(true);
				sap.ui.getCore().byId("oMatedessdeslbl").setVisible(false);
				sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
				sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatDesc").setVisible(false);
				sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(true);
				sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(true);
				sap.ui.getCore().byId("InputValueUnit").setEditable(true);
				sap.ui.getCore().byId("InputValueCurrency").setEditable(true);
				sap.ui.getCore().byId("idUntprce_Frag").setEditable(true);

			}

		},

		/*	onPressItems: function (oEvt) {
				
				if (!this._oDialog) {
					this._oDialog = sap.ui.xmlfragment("P2P.Fragment.Itemdetails", this);
					this.getView().addDependent(this._oDialog);
				}
				this.Catlogkey;
				sap.ui.getCore().byId("oSavebtnid").setText("Save");
				sap.ui.getCore().byId("InputValueMatCode").setEditable(false);
				sap.ui.getCore().byId("InputValueMatgrp").setEditable(false);

				switch (this.Catlogkey) {
				case "ZSM":
					sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
					sap.ui.getCore().byId("oMatid").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
					sap.ui.getCore().byId("oServiceocde").setVisible(false);
					sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(false);
					sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);
					sap.ui.getCore().byId("idItmType").setSelectedKey("");
					sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(false);
					sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(false);

					sap.ui.getCore().byId("oMatedessdeslbl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
					sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatDesc").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
					sap.ui.getCore().byId("InputValueUnit").setEditable(true);
					sap.ui.getCore().byId("InputValueCurrency").setEditable(true);
					sap.ui.getCore().byId("idUntprce_Frag").setEditable(true);
					// oSeriesshrtlbl

					break;
				case "ZSS" || "":
					sap.ui.getCore().byId("idItmType").setSelectedKey("9");
					sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(false);
					sap.ui.getCore().byId("InputValueMatCode").setVisible(false);
					sap.ui.getCore().byId("oMatid").setVisible(false);
					sap.ui.getCore().byId("oServiceocde").setVisible(true);
					sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(true);
					sap.ui.getCore().byId("oMatedessdeslbl").setVisible(false);
					sap.ui.getCore().byId("InputValueMatgrp").setVisible(false);
					sap.ui.getCore().byId("oMatgrplabl").setVisible(false);
					sap.ui.getCore().byId("InputValueMatDesc").setVisible(false);
					sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(true);
					sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(true);
					sap.ui.getCore().byId("InputValueUnit").setEditable(true);
					sap.ui.getCore().byId("InputValueCurrency").setEditable(true);
					sap.ui.getCore().byId("idUntprce_Frag").setEditable(true);

					break;
				case "ZSC":
					sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
					sap.ui.getCore().byId("oMatid").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
					sap.ui.getCore().byId("oServiceocde").setVisible(false);
					sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(false);
					sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);
					sap.ui.getCore().byId("idItmType").setSelectedKey("");
					sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(false);
					sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(false);

					sap.ui.getCore().byId("oMatedessdeslbl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
					sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatDesc").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
					sap.ui.getCore().byId("InputValueUnit").setEditable(false);
					sap.ui.getCore().byId("InputValueCurrency").setEditable(false);
					sap.ui.getCore().byId("idUntprce_Frag").setEditable(false);

				
					break;
				default:

				}

				var oSelectedExpType = this.getView().byId("idPGrp").getSelectedKey();
				switch (oSelectedExpType) {
				case "K" || "A":
					sap.ui.getCore().byId("oCC").setVisible(true);
					sap.ui.getCore().byId("oCCCode").setVisible(true);
					sap.ui.getCore().byId("oWbs").setVisible(false);
					sap.ui.getCore().byId("oWbscod").setVisible(false);
					this.getView().byId("navigationListem_h").setVisible(true);
					break;
				case "P":
					sap.ui.getCore().byId("oCC").setVisible(false);
					sap.ui.getCore().byId("oCCCode").setVisible(false);
					sap.ui.getCore().byId("oWbs").setVisible(true);
					sap.ui.getCore().byId("oWbscod").setVisible(true);
					this.getView().byId("navigationListItem_h").setVisible(true);
					break;
				case "A":
					sap.ui.getCore().byId("oCC").setVisible(true);
					sap.ui.getCore().byId("oCCCode").setVisible(true);
					sap.ui.getCore().byId("oWbs").setVisible(false);
					sap.ui.getCore().byId("oWbscod").setVisible(false);

					break;
				default:

				}

				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
				this._oDialog.open();

			

			},*/
		onChangeTextarea: function (oEvt) {
			this.oHeaderTxt = this.getView().byId("Procrjust").getValue();
			if (this.oHeaderTxt == "" || this.oHeaderTxt == undefined || this.oHeaderTxt == null) {

				this.getView().byId("Procrjust").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);

				return;
			} else {
				this.getView().byId("Procrjust").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
			}

		},
		/******************************Add Item Fragment Functionality-Begin***************************************/
		onPressItems: function (oEvt) {

			this.oRequesttype = this.getView().byId("idReqType").getSelectedKey();
			this.oExpensetype = this.getView().byId("idPGrp").getSelectedKey();
			this.oReqcategroy = this.getView().byId("idPrType").getSelectedKey();
			this.oBuval = this.getView().byId("InputValueBU1").getValue();
			this.oBudept = this.getView().byId("InputValueBDept").getValue();
			this.oLocation = this.getView().byId("InputValuePlnt").getValue();
			this.oRequid = this.getView().byId("InputValueRequr").getValue();
			this.oHeaderTxt = this.getView().byId("Procrjust").getValue();

			if (this.oRequesttype == "" || this.oRequesttype == undefined || this.oRequesttype == null) {

				this.getView().byId("idReqType").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);

				return;
			} else {
				this.getView().byId("idReqType").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
			}

			if (this.oExpensetype == "" || this.oExpensetype == undefined || this.oExpensetype == null) {

				this.getView().byId("idPGrp").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);

				return;
			} else {
				this.getView().byId("idPGrp").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
			}

			if (this.oBudept == "" || this.oBudept == undefined || this.oBudept == null) {

				this.getView().byId("InputValueBDept").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);

				return;
			} else {
				this.getView().byId("InputValueBDept").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
			}

			if (this.oReqcategroy == "" || this.oReqcategroy == undefined || this.oReqcategroy == null) {

				this.getView().byId("idPrType").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);

				return;
			} else {
				this.getView().byId("idPrType").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
			}

			if (this.oBuval == "" || this.oBuval == undefined || this.oBuval == null) {

				this.getView().byId("InputValueBU1").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);

				return;
			} else {
				this.getView().byId("InputValueBU1").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
			}

			if (this.oLocation == "" || this.oLocation == undefined || this.oLocation == null) {

				this.getView().byId("InputValuePlnt").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);

				return;
			} else {
				this.getView().byId("InputValuePlnt").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
			}

			if (this.oRequid == "" || this.oRequid == undefined || this.oRequid == null) {

				this.getView().byId("InputValueRequr").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);

				return;
			} else {
				this.getView().byId("InputValueRequr").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
			}
			if (this.oHeaderTxt == "" || this.oHeaderTxt == undefined || this.oHeaderTxt == null) {

				this.getView().byId("Procrjust").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);

				return;
			} else {
				this.getView().byId("Procrjust").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
			}

			/*	if () {

				} else

				{*/

			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("P2P.Fragment.Itemdetails", this);
				this.getView().addDependent(this._oDialog);
			}
			this.Catlogkey;
			sap.ui.getCore().byId("oSavebtnid").setText("Save");
			sap.ui.getCore().byId("InputValueMatCode").setEditable(false);
			sap.ui.getCore().byId("InputValueMatgrp").setEditable(false);

			switch (this.Catlogkey) {
			case "ZSM":
				sap.ui.getCore().byId("idItmType").setSelectedKey("");
				sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);

				sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
				sap.ui.getCore().byId("oMatid").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
				sap.ui.getCore().byId("oServiceocde").setVisible(false);
				sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(false);

				sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(false);
				sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(false);

				sap.ui.getCore().byId("oMatedessdeslbl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
				sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatDesc").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
				sap.ui.getCore().byId("InputValueUnit").setEditable(true);
				sap.ui.getCore().byId("InputValueCurrency").setEditable(true);
				sap.ui.getCore().byId("idUntprce_Frag").setEditable(true);
				// oSeriesshrtlbl

				break;
				//	switch (this.Catlogkey) {
			case "ZST":
				sap.ui.getCore().byId("idItmType").setSelectedKey("");
				sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);

				sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
				sap.ui.getCore().byId("oMatid").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
				sap.ui.getCore().byId("oServiceocde").setVisible(false);
				sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(false);

				sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(false);
				sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(false);

				sap.ui.getCore().byId("oMatedessdeslbl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
				sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatDesc").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
				sap.ui.getCore().byId("InputValueUnit").setEditable(true);
				sap.ui.getCore().byId("InputValueCurrency").setEditable(true);
				sap.ui.getCore().byId("idUntprce_Frag").setEditable(true);
				// oSeriesshrtlbl

				break;
			case "ZSS" || "":
				sap.ui.getCore().byId("idItmType").setSelectedKey("9");
				sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(false);
				sap.ui.getCore().byId("InputValueMatCode").setVisible(false);
				sap.ui.getCore().byId("oMatid").setVisible(false);
				sap.ui.getCore().byId("oServiceocde").setVisible(true);
				sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(true);
				sap.ui.getCore().byId("oMatedessdeslbl").setVisible(false);
				sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
				sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatDesc").setVisible(false);
				sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(true);
				sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(true);
				sap.ui.getCore().byId("InputValueUnit").setEditable(true);
				sap.ui.getCore().byId("InputValueCurrency").setEditable(true);
				sap.ui.getCore().byId("idUntprce_Frag").setEditable(true);

				break;
			case "ZSC":
				sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
				sap.ui.getCore().byId("oMatid").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
				sap.ui.getCore().byId("oServiceocde").setVisible(false);
				sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(false);
				sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);
				sap.ui.getCore().byId("idItmType").setSelectedKey("");
				sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(false);
				sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(false);

				sap.ui.getCore().byId("oMatedessdeslbl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
				sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatDesc").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
				sap.ui.getCore().byId("InputValueUnit").setEditable(false);
				sap.ui.getCore().byId("InputValueCurrency").setEditable(false);
				sap.ui.getCore().byId("idUntprce_Frag").setEditable(false);

				/*	sap.ui.getCore().byId("").setVisible(true);
					sap.ui.getCore().byId("").setVisible(true);*/
				break;
			default:

			}

			var oSelectedExpType = this.getView().byId("idPGrp").getSelectedKey();
			switch (oSelectedExpType) {
			case "K" || "A":
				sap.ui.getCore().byId("oCC").setVisible(true);
				sap.ui.getCore().byId("oCCCode").setVisible(true);
				sap.ui.getCore().byId("oWbs").setVisible(false);
				sap.ui.getCore().byId("oWbscod").setVisible(false);
				this.getView().byId("navigationListem_h").setVisible(true);
				break;
			case "P":
				sap.ui.getCore().byId("oCC").setVisible(false);
				sap.ui.getCore().byId("oCCCode").setVisible(false);
				sap.ui.getCore().byId("oWbs").setVisible(true);
				sap.ui.getCore().byId("oWbscod").setVisible(true);
				this.getView().byId("navigationListItem_h").setVisible(true);
				break;
			case "A":
				sap.ui.getCore().byId("oCC").setVisible(true);
				sap.ui.getCore().byId("oCCCode").setVisible(true);
				sap.ui.getCore().byId("oWbs").setVisible(false);
				sap.ui.getCore().byId("oWbscod").setVisible(false);

				break;
			default:

			}

			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog.open();

			/*	}*/

		},

		onCloseDialog: function (oEvent) {
			this._oDialog.close();
			this._oDialog.destroy(true);
			this._oDialog = undefined;
		},
		/******************************Add Item Fragment Functionality-End******************************************/

		onCloseDialog1: function (oEvent) {
			this._valueHelpDialog1.close();
		},
		/****************************Total Value calculation Functionality-Begin*************************************/
		onTotalval: function () {

			var oUnitval = sap.ui.getCore().byId("idUntprce_Frag").getValue();
			var idUnit =
				oUnitval.replace(/[^\d.]/g, '') // numbers and decimals only
				.replace(/(^[\d]{10})[\d]/g, '$1') // not more than 2 digits at the beginning
				.replace(/(\..*)\./g, '$1') // decimal can't exist more than once
				.replace(/(\.[\d]{3})./g, '$1');
			sap.ui.getCore().byId("idUntprce_Frag").setValue(idUnit);

			this.oQtyId = sap.ui.getCore().byId("idQntyFrag").getValue();
			//  this.oQtyId = this.oQtyId1.toFixed(3);
			/*	this.oUntTprice.replace(/[^\d.]/g, '');*/
			this.oUntTprice = sap.ui.getCore().byId("idUntprce_Frag").getValue();
			//  this.oUntTprice = this.oUntTprice1.toFixed(3);
			this.totalval1 = this.oQtyId * this.oUntTprice;
			this.totalval = this.totalval1.toFixed(3);

			sap.ui.getCore().byId("idText_Frag").setText(this.totalval);
		},
		/****************************Total Value calculation Functionality-End*************************************/
		handleDateChange: function (oEvent) {
			var Value = oEvent.getSource().getValue();

			var oDateFormat2 = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "dd/MM/yyyy"
			});
			var Datevalue = oDateFormat2.format(new Date(new Date(Value)));
			oEvent.getSource().setValue(Datevalue);

		},
		/****************************Table Row adding Functionality-Begin*****************************************/
		onAddDialog: function (oEvent) {

			var EndDate = sap.ui.getCore().byId("DP2").getDateValue();
			if (!EndDate) {
				EndDate = new Date(sap.ui.getCore().byId("DP2").getValue());
			}
			var CurrentDate = new Date();
			if (EndDate < CurrentDate) {
				//	sap.m.MessageBox.error("Date should be greater than or equal to current date");
				sap.ui.getCore().byId("DP2").setValueState("Error");
				sap.m.MessageBox.error("Please choose from Today date onwards");
				return;

			} else {

				sap.ui.getCore().byId("DP2").setValueState("None");

				this.FragItemItemtype = sap.ui.getCore().byId("idItmType").getSelectedKey();
				this.FragItemMatgrp = sap.ui.getCore().byId("InputValueMatgrp").getValue();
				this.FragItemMatCode = sap.ui.getCore().byId("InputValueMatCode").getValue();
				this.FragItemServShrttxtArea = sap.ui.getCore().byId("InputValueSerisshortDesc").getValue();
				this.FragItemServDesc = sap.ui.getCore().byId("InputValueSeriesDesc").getValue();
				this.FragItemServCode = sap.ui.getCore().byId("InputValueServcCode").getValue();
				//this.FragItemServCode = sap.ui.getCore().byId("InputValueServcCode").getValue();
				this.FragItemMatDesc = sap.ui.getCore().byId("InputValueMatDesc").getValue();
				this.FragItemQntyDesc = sap.ui.getCore().byId("idQntyFrag").getValue();
				this.FragItemUnitVal = sap.ui.getCore().byId("InputValueUnit").getValue();
				this.FragItemCurrncyVal = sap.ui.getCore().byId("InputValueCurrency").getValue();
				this.FragItemUnit = sap.ui.getCore().byId("idUntprce_Frag").getValue();
				this.FragItemTotalval = sap.ui.getCore().byId("idText_Frag").getText();
				//this.FragItemzzcatgry = sap.ui.getCore().byId("idzzcategry").getText();
				this.FragItemCoscentr = sap.ui.getCore().byId("oCCCode").getValue();
				this.FragItemWbscntr = sap.ui.getCore().byId("oWbscod").getValue();
				this.FragItemGlact = sap.ui.getCore().byId("idTxt_Glacnt").getText();
				this.FragItemText = sap.ui.getCore().byId("oitemtxt").getValue();
				this.Fragzzcategry = sap.ui.getCore().byId("idzzcategry").getText();

				this.FragItemDatex = sap.ui.getCore().byId("DP2").getDateValue();

				if (!this.FragItemDatex) {
					this.FragItemDatex = sap.ui.getCore().byId("DP2").getValue();
				}

				var oDateFormat2 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyy-MM-dd'T'HH:mm:ss"
				});

				this.FragItemDate = oDateFormat2.format(new Date(this.FragItemDatex));

				if (this.FragItemDatex == "" || this.FragItemDatex == undefined || this.FragItemDatex == null) {
					//	sap.m.MessageBox.error("Please select ModelYear");
					sap.ui.getCore().byId("DP2").setValueState("Error");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);
					//	sap.ui.core.BusyIndicator.hide();
					return;
				} else {
					sap.ui.getCore().byId("DP2").setValueState("None");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
				}

				if (this.FragItemQntyDesc == "" || this.FragItemQntyDesc == undefined || this.FragItemQntyDesc == null) {

					sap.ui.getCore().byId("idQntyFrag").setValueState("Error");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

					return;
				} else {
					sap.ui.getCore().byId("idQntyFrag").setValueState("None");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
				}
				if (this.FragItemUnitVal == "" || this.FragItemUnitVal == undefined || this.FragItemUnitVal == null) {

					sap.ui.getCore().byId("InputValueUnit").setValueState("Error");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

					return;
				} else {
					sap.ui.getCore().byId("InputValueUnit").setValueState("None");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
				}

				if (this.FragItemCurrncyVal == "" || this.FragItemCurrncyVal == undefined || this.FragItemCurrncyVal == null) {

					sap.ui.getCore().byId("InputValueCurrency").setValueState("Error");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

					return;
				} else {
					sap.ui.getCore().byId("InputValueCurrency").setValueState("None");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
				}

				if (this.FragItemUnit == "" || this.FragItemUnit == undefined || this.FragItemUnit == null) {

					sap.ui.getCore().byId("idUntprce_Frag").setValueState("Error");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

					return;
				} else {
					sap.ui.getCore().byId("idUntprce_Frag").setValueState("None");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
				}

				if (this.oExpType == "K" || this.oExpType == "A") {
					if (this.FragItemCoscentr == "" || this.FragItemCoscentr == undefined || this.FragItemCoscentr == null) {
						//	sap.m.MessageBox.error("Please select ModelYear");
						sap.ui.getCore().byId("oCCCode").setValueState("Error");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

						return;
					} else {
						sap.ui.getCore().byId("oCCCode").setValueState("None");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
					}
				} else {
					if (this.FragItemWbscntr == "" || this.FragItemWbscntr == undefined || this.FragItemCoscentr == null) {

						sap.ui.getCore().byId("oWbscod").setValueState("Error");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

						return;
					} else {
						sap.ui.getCore().byId("oWbscod").setValueState("None");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
					}
				}

			

				if (sap.ui.getCore().byId("InputValueSerisshortDesc").getEnabled() == true && (sap.ui.getCore().byId("idItmType").getSelectedKey() ==
						"9")) {
					if (this.FragItemServShrttxtArea == "" || this.FragItemServShrttxtArea == undefined || this.FragItemServShrttxtArea == null) {
						//	sap.m.MessageBox.error("Please select ModelYear");
						sap.ui.getCore().byId("InputValueSerisshortDesc").setValueState("Error");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

						return;
					} else {
						sap.ui.getCore().byId("InputValueSerisshortDesc").setValueState("None");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
					}
				} else {
					if (this.FragItemMatDesc == "" || this.FragItemMatDesc == undefined || this.FragItemMatDesc == null) {

						sap.ui.getCore().byId("InputValueMatDesc").setValueState("Error");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

						return;
					} else {
						sap.ui.getCore().byId("InputValueMatDesc").setValueState("None");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
					}
				}

			
				if (oEvent.getSource().getText() == "Save") {
					var oMainObj = {};
					oMainObj.oFragItemItemtypeRef = this.FragItemItemtype;
					oMainObj.oFragMatcodeRef = this.FragItemMatCode;
					oMainObj.oFragServcodeRef = this.FragItemServCode;
					oMainObj.oFragMatDescref = this.FragItemMatDesc;
					oMainObj.oFragMatGrpref = this.FragItemMatgrp;
					oMainObj.oFragSersShrttextref = this.FragItemServShrttxtArea;
					oMainObj.oFragSersDescref = this.FragItemServDesc;
					oMainObj.oFragSersCoderef = this.FragItemServCode;
					oMainObj.oFragQntyref = this.FragItemQntyDesc;
					oMainObj.oFragInputValueUnitref = this.FragItemUnitVal;
					oMainObj.oFragCurrencyref = this.FragItemCurrncyVal;
					oMainObj.oFragTotalValuref = this.FragItemTotalval;
					oMainObj.oFragzzcategryef = this.Fragzzcategry;
					oMainObj.oFrUnitpriceref = this.FragItemUnit;
					oMainObj.oFragWbscref = this.FragItemWbscntr;
					oMainObj.oDp2ref = this.FragItemDate;
					oMainObj.oFragItemCostCentr = this.FragItemCoscentr;
					oMainObj.oFragItemGlacntref = this.FragItemGlact;
					oMainObj.oFragItemtextref = this.FragItemText;
					oMainObj.FragItemUnitValref = this.FragItemUnitVal;
					//	oMainObj.Anln1 = this.FragItemAsset;

					/*	oMainObj.oFragItemdate = this.FragItemDate;*/

					/*	if (this.getView().byId("ItemTable1").getSelectedItems().length==0) {

							this.EditQnty = sap.ui.getCore().byId("idQntyFrag").setValue(this.oXQnty);
							this.Editmatgrp = sap.ui.getCore().byId("InputValueMatgrp").setValue(this.oXMatgrp);
							var oMAINEDITBJ = {};
							oMAINEDITBJ.oEditQntRef = this.EditQnty;
							oMAINEDITBJ.Editmatgrp = this.Editmatgrp;

							this.SelecteItems.push(oMAINEDITBJ);
							this.getView().byId("ItemTable1").getModel().refresh(true);

						} else {*/
					if (!this.getView().byId("ItemTable1").getModel()) {
						var ArrayData = [];
						ArrayData.push(oMainObj);
						var jsonData = new sap.ui.model.json.JSONModel(ArrayData);
						var oCreaTable = this.getView().byId("ItemTable1");
						oCreaTable.setModel(jsonData);
					} else if (this.getView().byId("ItemTable1").getModel()) {
						var ItemTableta = this.getView().byId("ItemTable1").getModel().getData();

						if (ItemTableta) {
							ItemTableta.push(oMainObj);

							this.getView().byId("ItemTable1").getModel().refresh(true);
							if (ItemTableta.length >= 0) {

								this.getView().byId("InputValueAgrmt").setEnabled(false);
								this.getView().byId("InputValuePlnt").setEnabled(false);
								this.getView().byId("InputValueRequr").setEnabled(false);
								this.getView().byId("InputValueBDept").setEnabled(false);
								this.getView().byId("InputValueBU1").setEnabled(false);
								this.getView().byId("idPrType").setEnabled(false);
								this.getView().byId("idPGrp").setEnabled(false);
								this.getView().byId("idReqType").setEnabled(false);
								this.getView().byId("idInputFileNumber").setEnabled(false);
								this.getView().byId("oUndbChecbx").setEnabled(false);
								/*	this.getView().byId("oCreateId").setEnabled(false);
					            this.getView().byId("oCancelId").setEnabled(false);*/

							} else {

								this.getView().byId("InputValueAgrmt").setEnabled(true);
								this.getView().byId("InputValuePlnt").setEnabled(true);
								this.getView().byId("InputValueRequr").setEnabled(true);
								this.getView().byId("InputValueBDept").setEnabled(true);
								this.getView().byId("InputValueBU1").setEnabled(true);
								this.getView().byId("idPrType").setEnabled(true);
								this.getView().byId("idPGrp").setEnabled(true);
								this.getView().byId("idReqType").setEnabled(true);
								this.getView().byId("idInputFileNumber").setEnabled(true);
								this.getView().byId("oUndbChecbx").setEnabled(true);
								/*	this.getView().byId("oCreateId").setEnabled(true);
					            this.getView().byId("oCancelId").setEnabled(true);*/

							}

						} else {
							var ArrayData2 = [];
							ArrayData2.push(oMainObj);
							var oJsonData = new sap.ui.model.json.JSONModel(ArrayData2);
							var oCreaTable2 = this.getView().byId("ItemTable1");

							oCreaTable2.setModel(oJsonData);
							if (oCreaTable2.getModel().getData().length >= "1") {

								this.getView().byId("InputValueAgrmt").setEnabled(false);
								this.getView().byId("InputValuePlnt").setEnabled(false);
								this.getView().byId("InputValueRequr").setEnabled(false);
								this.getView().byId("InputValueBDept").setEnabled(false);
								this.getView().byId("InputValueBU1").setEnabled(false);
								this.getView().byId("idPrType").setEnabled(false);
								this.getView().byId("idPGrp").setEnabled(false);
								this.getView().byId("idReqType").setEnabled(false);
								this.getView().byId("idInputFileNumber").setEnabled(false);
								this.getView().byId("oUndbChecbx").setEnabled(false);

							} else {

								this.getView().byId("InputValueAgrmt").setEnabled(true);
								this.getView().byId("InputValuePlnt").setEnabled(true);
								this.getView().byId("InputValueRequr").setEnabled(true);
								this.getView().byId("InputValueBDept").setEnabled(true);
								this.getView().byId("InputValueBU1").setEnabled(true);
								this.getView().byId("idPrType").setEnabled(true);
								this.getView().byId("idPGrp").setEnabled(true);
								this.getView().byId("idReqType").setEnabled(true);
								this.getView().byId("idInputFileNumber").setEnabled(true);
								this.getView().byId("oUndbChecbx").setEnabled(true);

							}
						}
					}
				} else if (oEvent.getSource().getText() == "Update") {
					var selectedItemPath = this.getView().byId("ItemTable1").getSelectedItems()[0].getBindingContext().getPath().substr(1);
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath];
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragItemItemtypeRef = this.FragItemItemtype;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragMatcodeRef = this.FragItemMatCode;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragServcodeRef = this.FragItemServCode;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragMatDescref = this.FragItemMatDesc;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragMatGrpref = this.FragItemMatgrp;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragSersShrttextref = this.FragItemServShrttxtArea;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragSersDescref = this.FragItemServDesc;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragSersCoderef = this.FragItemServCode;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragQntyref = this.FragItemQntyDesc;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragInputValueUnitref = this.FragItemUnitVal;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragCurrencyref = this.FragItemCurrncyVal;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragTotalValuref = this.FragItemTotalval;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragzzcategryef = this.Fragzzcategry;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFrUnitpriceref = this.FragItemUnit;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragWbscref = this.FragItemWbscntr;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oDp2ref = this.FragItemDate;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragItemCostCentr = this.FragItemCoscentr;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragItemGlacntref = this.FragItemGlact;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragItemtextref = this.FragItemText;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].FragItemUnitValref = this.FragItemUnitVal;
					this.getView().byId("ItemTable1").getModel().refresh(true);
				}
				/*}*/
				this._oDialog.close();
				this._oDialog.destroy(true);
				this._oDialog = undefined;
			}

		},
		/****************************Table Row adding Functionality-End*****************************************/
		/****************************Table Row deleting Functionality-Begin***************************************/
		onDelete: function (oEvent) {

			var oTable = this.getView().byId("ItemTable1");
			var sBindingPath = oEvent.oSource.getParent().getBindingContext().getPath();
			var selectedIndex = sBindingPath.split("/")[1];
			var oTableData = oTable.getModel().getData();
			oTableData.splice(selectedIndex, 1);
			oTable.getModel().setData(oTableData);
			if (oTableData.length == 0) {

				this.getView().byId("InputValueAgrmt").setEnabled(true);
				this.getView().byId("InputValuePlnt").setEnabled(true);
				this.getView().byId("InputValueRequr").setEnabled(true);
				this.getView().byId("InputValueBDept").setEnabled(true);
				this.getView().byId("InputValueBU1").setEnabled(true);
				this.getView().byId("idPrType").setEnabled(true);
				this.getView().byId("idPGrp").setEnabled(true);
				this.getView().byId("idReqType").setEnabled(true);
				this.getView().byId("idInputFileNumber").setEnabled(true);
				this.getView().byId("oUndbChecbx").setEnabled(true);
				this.getView().byId("Procrjust").setEnabled(true);
				//	this.getView().byId("oProJustlabel").setEnabled(true);

			} else if (oTableData.length >= 1) {
				this.getView().byId("InputValueAgrmt").setEnabled(false);
				this.getView().byId("InputValuePlnt").setEnabled(false);
				this.getView().byId("InputValueRequr").setEnabled(false);
				this.getView().byId("InputValueBDept").setEnabled(false);
				this.getView().byId("InputValueBU1").setEnabled(false);
				this.getView().byId("idPrType").setEnabled(false);
				this.getView().byId("idPGrp").setEnabled(false);
				this.getView().byId("idReqType").setEnabled(false);
				this.getView().byId("idInputFileNumber").setEnabled(false);
				this.getView().byId("oUndbChecbx").setEnabled(false);
				this.getView().byId("Procrjust").setEnabled(false);

			}

		},
		/****************************Table Row deleting Functionality-End*****************************************/
		onEdit: function (oEvent) {

			var oTabSelecteditem = this.getView().byId("ItemTable1").getModel().getData();
			this.SelecteItems = this.getView().byId("ItemTable1").getSelectedItems();

			if (this.SelecteItems.length > 0 && this.SelecteItems.length == 1) {
				if (!this._oDialog) {
					this._oDialog = sap.ui.xmlfragment("P2P.Fragment.Itemdetails", this);
					this.getView().addDependent(this._oDialog);

				}

				this.Catlogkey;

				sap.ui.getCore().byId("InputValueMatCode").setEditable(false);
				sap.ui.getCore().byId("InputValueMatgrp").setEditable(false);

				switch (this.Catlogkey) {
				case "ZSM":
					sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
					sap.ui.getCore().byId("oMatid").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
					sap.ui.getCore().byId("oServiceocde").setVisible(false);
					sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(false);
					sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);
					sap.ui.getCore().byId("idItmType").setSelectedKey("");
					sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(false);
					sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(false);

					sap.ui.getCore().byId("oMatedessdeslbl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
					sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatDesc").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
					// oSeriesshrtlbl

					break;
					//	switch (this.Catlogkey) {
				case "ZST":
					sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
					sap.ui.getCore().byId("oMatid").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
					sap.ui.getCore().byId("oServiceocde").setVisible(false);
					sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(false);
					sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);
					sap.ui.getCore().byId("idItmType").setSelectedKey("");
					sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(false);
					sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(false);

					sap.ui.getCore().byId("oMatedessdeslbl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
					sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatDesc").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
					// oSeriesshrtlbl

					break;
				case "ZSS" || "":
					sap.ui.getCore().byId("idItmType").setSelectedKey("9");
					sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(false);
					sap.ui.getCore().byId("InputValueMatCode").setVisible(false);
					sap.ui.getCore().byId("oMatid").setVisible(false);
					sap.ui.getCore().byId("oServiceocde").setVisible(true);
					sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(true);
					sap.ui.getCore().byId("oMatedessdeslbl").setVisible(false);
					sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
					sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatDesc").setVisible(false);
					sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(true);
					sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(true);

					break;
				case "ZSC":
					/*	sap.ui.getCore().byId("").setVisible(true);
						sap.ui.getCore().byId("").setVisible(true);*/
					break;
				default:

				}

				var oSelectedExpType = this.getView().byId("idPGrp").getSelectedKey();
				switch (oSelectedExpType) {
				case "K" || "A":
					sap.ui.getCore().byId("oCC").setVisible(true);
					sap.ui.getCore().byId("oCCCode").setVisible(true);
					sap.ui.getCore().byId("oWbs").setVisible(false);
					sap.ui.getCore().byId("oWbscod").setVisible(false);
					this.getView().byId("navigationListem_h").setVisible(true);
					break;
				case "P":
					sap.ui.getCore().byId("oCC").setVisible(false);
					sap.ui.getCore().byId("oCCCode").setVisible(false);
					sap.ui.getCore().byId("oWbs").setVisible(true);
					sap.ui.getCore().byId("oWbscod").setVisible(true);
					this.getView().byId("navigationListItem_h").setVisible(true);
					break;
				case "A":
					sap.ui.getCore().byId("oCC").setVisible(true);
					sap.ui.getCore().byId("oCCCode").setVisible(true);
					sap.ui.getCore().byId("oWbs").setVisible(false);
					sap.ui.getCore().byId("oWbscod").setVisible(false);

					break;
				default:

				}

				var oServiceShrEnable = this.SelecteItems[0].getBindingContext().getObject().oFragSersShrttextref;
				if (oServiceShrEnable != "" && oServiceShrEnable != 0 && oServiceShrEnable != undefined) {

					sap.ui.getCore().byId("idItmType").setSelectedKey("9");
					sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(false);
					sap.ui.getCore().byId("InputValueMatCode").setVisible(false);
					sap.ui.getCore().byId("oMatid").setVisible(false);
					sap.ui.getCore().byId("oServiceocde").setVisible(true);
					sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(true);
					sap.ui.getCore().byId("oMatedessdeslbl").setVisible(false);
					sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
					sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatDesc").setVisible(false);
					sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(true);
					sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(true);
					sap.ui.getCore().byId("InputValueUnit").setEditable(true);
					sap.ui.getCore().byId("InputValueCurrency").setEditable(true);
					sap.ui.getCore().byId("idUntprce_Frag").setEditable(true);

				} else {

					sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
					sap.ui.getCore().byId("oMatid").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
					sap.ui.getCore().byId("oServiceocde").setVisible(false);
					sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(false);
					sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);
					sap.ui.getCore().byId("idItmType").getItems()[1].setEnabled(false);
					//	sap.ui.getCore().byId("idItmType").setSelectedKey("");
					sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(false);
					sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(false);

					sap.ui.getCore().byId("oMatedessdeslbl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
					sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatDesc").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);

				}

				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
				sap.ui.getCore().byId("oSavebtnid").setText("Update");

				/*this.oXMatgrp = this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[0].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[1].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[2].mProperties.text;
				this.oXQnty = this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[3].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[4].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[5].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[6].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[7].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[8].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[9].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[10].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[11].mProperties.text;

			*/
				/*	this.EditQnty = sap.ui.getCore().byId("idQntyFrag").setValue(this.oXQnty);
					this.Editmatgrp = sap.ui.getCore().byId("InputValueMatgrp").setValue(this.oXMatgrp);*/
				var SelectedObject = this.getView().byId("ItemTable1").getSelectedItems()[0].getBindingContext().getObject();
				var Editmodel = new sap.ui.model.json.JSONModel(SelectedObject);
				sap.ui.getCore().byId("SimpleFormChange480").setModel(Editmodel);
				sap.ui.getCore().byId("oitemtxt").setModel(Editmodel);
				sap.ui.getCore().byId("SimpleFormChange480").bindElement("/");

				this._oDialog.open();

			} else {
				if (this.SelecteItems.length > 1) {
					sap.m.MessageBox.information("Please select only 'single' item to edit");
				} else {
					if (!this.SelecteItems > 0) {
						sap.m.MessageBox.information("Please select 'single' item to edit");
					}
					sap.m.MessageBox.information("Please select 'single' item to edit");
				}
			}

			/*	this.sBindingPathEdit = oEvent.oSource.getParent().getBindingContext().getPath();
				this.selectedIndexEdit = this.sBindingPathEdit.split("/")[1];
				this.oSelectedRowobj = oEvent.oSource.getModel().getData()[this.selectedIndexEdit];
				var oFragMatcodeRw = this.oSelectedRowobj.oFragMatcodeRef;
				var oFragMatDescRw = this.oSelectedRowobj.oFragMatDescref;
				var oFragMatGrpRw = this.oSelectedRowobj.oFragMatGrpref;
				var oFragQntyRw = this.oSelectedRowobj.oFragQntyref;
				var oFragInputValueUnitRw = this.oSelectedRowobj.oFragInputValueUnitref;
				var oFragCurrencyRw = this.oSelectedRowobj.oFragCurrencyref;
				var oFragTotalValuRw = this.oSelectedRowobj.oFragTotalValuref;
				var oFrUnitpriceRw = this.oSelectedRowobj.oFrUnitpriceref;
				var oFragWbscRw = this.oSelectedRowobj.oFragWbscref;
				var oDp2Rw = this.oSelectedRowobj.oDp2ref;
				var oFragItemtxtRw = this.oSelectedRowobj.oFragItemtxtref;

				this.oFragMatCodRf = sap.ui.getCore().byId("oMatcodeEdit").setValue(oFragMatcodeRw);
				this.oFragMatDescRf = sap.ui.getCore().byId("oMatDescEdit").setValue(oFragMatDescRw);
				this.oFragMatGrpRf = sap.ui.getCore().byId("oMatGrpEdit").setValue(oFragMatGrpRw);
				this.oFragQntyRf = sap.ui.getCore().byId("idQntyFragEdit").setValue(oFragQntyRw);
				this.oFragInputValueUnitRf = sap.ui.getCore().byId("InputValueUnitEdit").setValue(oFragInputValueUnitRw);
				this.oFragCurrencyRf = sap.ui.getCore().byId("idCurrency_FragEdit").setValue(oFragCurrencyRw);
				this.oFragTotalValuRf = sap.ui.getCore().byId("idText_FragEdit").setText(oFragTotalValuRw);
				this.oFrUnitpriceRf = sap.ui.getCore().byId("idUntprce_FragEdit").setValue(oFrUnitpriceRw);
				this.oFragWbscRf = sap.ui.getCore().byId("oWbscodEdit").setValue(oFragWbscRw);
				this.oDp2Rf = sap.ui.getCore().byId("DP2Edit").setValue(oDp2Rw);
				this.oFragItemtxtRf = sap.ui.getCore().byId("oitemtxtEdit").setValue(oFragItemtxtRw);*/

			/*	var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("Edit", {

				});*/

			/*	if (!this._oDialogEdit) {
					this._oDialogEdit = sap.ui.xmlfragment("P2P.Fragment.Edit", this);
					this.getView().addDependent(this._oDialogEdit);
				}

				this.sBindingPathEdit = oEvent.oSource.getParent().getBindingContext().getPath();
				this.selectedIndexEdit = this.sBindingPathEdit.split("/")[1];
				this.oSelectedRowobj = oEvent.oSource.getModel().getData()[this.selectedIndexEdit];
				var oFragMatcodeRw = this.oSelectedRowobj.oFragMatcodeRef;
				var oFragMatDescRw = this.oSelectedRowobj.oFragMatDescref;
				var oFragMatGrpRw = this.oSelectedRowobj.oFragMatGrpref;
				var oFragQntyRw = this.oSelectedRowobj.oFragQntyref;
				var oFragInputValueUnitRw = this.oSelectedRowobj.oFragInputValueUnitref;
				var oFragCurrencyRw = this.oSelectedRowobj.oFragCurrencyref;
				var oFragTotalValuRw = this.oSelectedRowobj.oFragTotalValuref;
				var oFrUnitpriceRw = this.oSelectedRowobj.oFrUnitpriceref;
				var oFragWbscRw = this.oSelectedRowobj.oFragWbscref;
				var oDp2Rw = this.oSelectedRowobj.oDp2ref;
				var oFragItemtxtRw = this.oSelectedRowobj.oFragItemtxtref;

				this.oFragMatCodRf = sap.ui.getCore().byId("oMatcodeEdit").setValue(oFragMatcodeRw);
				this.oFragMatDescRf = sap.ui.getCore().byId("oMatDescEdit").setValue(oFragMatDescRw);
				this.oFragMatGrpRf = sap.ui.getCore().byId("oMatGrpEdit").setValue(oFragMatGrpRw);
				this.oFragQntyRf = sap.ui.getCore().byId("idQntyFragEdit").setValue(oFragQntyRw);
				this.oFragInputValueUnitRf = sap.ui.getCore().byId("InputValueUnitEdit").setValue(oFragInputValueUnitRw);
				this.oFragCurrencyRf = sap.ui.getCore().byId("idCurrency_FragEdit").setValue(oFragCurrencyRw);
				this.oFragTotalValuRf = sap.ui.getCore().byId("idText_FragEdit").setText(oFragTotalValuRw);
				this.oFrUnitpriceRf = sap.ui.getCore().byId("idUntprce_FragEdit").setValue(oFrUnitpriceRw);
				this.oFragWbscRf = sap.ui.getCore().byId("oWbscodEdit").setValue(oFragWbscRw);
				this.oDp2Rf = sap.ui.getCore().byId("DP2Edit").setValue(oDp2Rw);
				this.oFragItemtxtRf = sap.ui.getCore().byId("oitemtxtEdit").setValue(oFragItemtxtRw);

				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialogEdit);
				this._oDialogEdit.open();*/
		},

		onCloseDialogEdit: function (oEvent) {
			this._oDialog.close();
			this._oDialog.destroy();
			this._oDialog = undefined;
			//this.Exit();
		},

		simulateServerRequest: function () {
			// simulate a longer running operation
			iTimeoutId = setTimeout(function () {
				this._pBusyDialog.then(function (oBusyDialog) {
					oBusyDialog.close();
				});
			}.bind(this), 3000);

		},

		onDialogClosed: function (oEvent) {
			clearTimeout(iTimeoutId);

			if (oEvent.getParameter("cancelPressed")) {
				/*sap.m.MessageToast.show("The operation has been cancelled");*/
			} else {
				/*	sap.m.MessageToast.show("The operation has been completed");*/
			}
		},

		onCreate: function (oEvent) {
			

		
			this.oRequesttype = this.getView().byId("idReqType").getSelectedKey();
			this.oExpensetype = this.getView().byId("idPGrp").getSelectedKey();
			this.oReqcategroy = this.getView().byId("idPrType").getSelectedKey();
			this.oBuval = this.getView().byId("InputValueBU1").getValue();
			this.oBudept = this.getView().byId("InputValueBDept").getValue();
			this.oRequid = this.getView().byId("InputValueRequr").getValue();
			this.oLocation = this.getView().byId("InputValuePlnt").getValue();
			this.oHeaderTxt = this.getView().byId("Procrjust").getValue();

			if (this.oRequesttype == "" || this.oRequesttype == undefined || this.oRequesttype == null) {

				this.getView().byId("idReqType").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);
				this.getView().byId("oCreateId").setEnabled(true);

				return;
			} else {
				this.getView().byId("idReqType").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
				this.getView().byId("oCreateId").setEnabled(false);
			}

			if (this.oExpensetype == "" || this.oExpensetype == undefined || this.oExpensetype == null) {

				this.getView().byId("idPGrp").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);
				this.getView().byId("oCreateId").setEnabled(true);

				return;
			} else {
				this.getView().byId("idPGrp").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
				this.getView().byId("oCreateId").setEnabled(false);
			}

			if (this.oReqcategroy == "" || this.oReqcategroy == undefined || this.oReqcategroy == null) {

				this.getView().byId("idPrType").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);
				this.getView().byId("oCreateId").setEnabled(true);

				return;
			} else {
				this.getView().byId("idPrType").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
				this.getView().byId("oCreateId").setEnabled(false);
			}

			if (this.oBuval == "" || this.oBuval == undefined || this.oBuval == null) {

				this.getView().byId("InputValueBU1").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);
				this.getView().byId("oCreateId").setEnabled(true);

				return;
			} else {
				this.getView().byId("InputValueBU1").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
				this.getView().byId("oCreateId").setEnabled(false);
			}

			if (this.oBudept == "" || this.oBudept == undefined || this.oBudept == null) {

				this.getView().byId("InputValueBDept").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);
				this.getView().byId("oCreateId").setEnabled(true);

				return;
			} else {
				this.getView().byId("InputValueBDept").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
				this.getView().byId("oCreateId").setEnabled(false);
			}

			if (this.oRequid == "" || this.oRequid == undefined || this.oRequid == null) {

				this.getView().byId("InputValueRequr").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);
				this.getView().byId("oCreateId").setEnabled(true);

				return;
			} else {
				this.getView().byId("InputValueRequr").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
				this.getView().byId("oCreateId").setEnabled(false);
			}

			if (this.oLocation == "" || this.oLocation == undefined || this.oLocation == null) {

				this.getView().byId("InputValuePlnt").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);
				this.getView().byId("oCreateId").setEnabled(true);

				return;
			} else {
				this.getView().byId("InputValuePlnt").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
				this.getView().byId("oCreateId").setEnabled(false);
			}

			if (this.oHeaderTxt == "" || this.oHeaderTxt == undefined || this.oHeaderTxt == null) {

				this.getView().byId("Procrjust").setValueState("Error");
				this.getView().byId("creatErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", true);
				this.getView().byId("oCreateId").setEnabled(true);

				return;
			} else {
				this.getView().byId("Procrjust").setValueState("None");
				this.getView().byId("creatErrMsgStrip").setProperty("visible", false);
				this.getView().byId("oCreateId").setEnabled(false);
			}

			//		this.getView().byId("oCreateId").setEnabled(false);

			this.getView().byId("oCreateId").setEnabled(false);
			var oRequesttype = this.getView().byId("idReqType").getSelectedKey(); // payload name - DocType
			var oExpType = this.getView().byId("idPGrp").getSelectedKey(); // payload name - Zzcategoty
			var oRequestCategry = this.getView().byId("idPrType")._getSelectedItemText(); // payload name - Zzcategoty
			var oBussinessUnit = this.oBuConfirmtitle; //Zzbu // this.getView().byId("InputValueBU1").getValue(); //   this.oBuConfirmtitle; // payload name - Zzbu
			var oBussinessDept = this.BussDescbj; // this.getView().byId("InputValueBDept").getValue();//this.oBuConfirmtitle; // payload name - ZzdeptCode2
			var oBusDescir = this.getView().byId("InputValueBU1").getValue(); //this.oBusinessdesc;
			var oBusinesDeptDesc = this.getView().byId("InputValueBDept").getValue(); //this.oBusinesdeptdesc;

			var oBussinessAprvname = this.getView().byId("idBuApptext").mProperties.text.split("-")[0];
			var oBussinessAprv = this.getView().byId("idBuApptext").mProperties.text.split("-")[1]; // payload name - ZzaprL3
			var oRequsitioner = this.getView().byId("InputValueRequr").getValue();
			var oHeaderText = this.getView().byId("Procrjust").getValue();

			var oManager = this.getView().byId("idManagertext").getText(); // payload name  -ZzassName2
			var oPlant = this.getView().byId("InputValuePlnt").getValue(); // payload name  - Plant

			var oUnbudgetCheckBoxref = this.getView().byId("oUndbChecbx").getSelected();
			var oUnbudgetCheckBox;
			if (oUnbudgetCheckBoxref == true) {
				oUnbudgetCheckBox = "YY";
			} else if (oUnbudgetCheckBoxref == false) {
				oUnbudgetCheckBox = "ZZ";

			}

			if (this.oRequesttype == "ZSM" || this.oRequesttype == "ZSS" || this.oRequesttype == "ZST") {
				var oAggrmentno = "";
				var oAggrItemno = "";

			} else {
				var oAggrmentno = this.getView().byId("InputValueAgrmt").getValue();
				var oAggrItemno = this.oAggrntItemno;
			}

			var that = this;

			var oPurcGroup = that.xx2; //this.getView().byId("idPurcGrp").getValue();// payload name  - PurGroup
			//	var oProcuJust = this.getView().byId("Procrjust").getValue(); // no need to send
			var oDate = new Date();
			var oPurcretdateref = oDate.setHours(0, 0, 0);
			var oDateFormat5 = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyy-MM-dd'T'HH:mm:ss"
			});

			var oPurcretdate = oDateFormat5.format(new Date(oPurcretdateref));

			
			var batchUrls = [];
			var headeritem = {};

			var PR_ItemSet = [];
			var oTable = this.getView().byId("ItemTable1").getModel().getData();
			var xxoTable = this.getView().byId("ItemTable1").getModel().getData();
			var newData = this.getView().byId("ItemTable1").getModel().getData();
			
			if (newData == null) {
				sap.m.MessageBox.information("Please add atleast 1 item to create Purchase Requisition");
				this.getView().byId("oCreateId").setEnabled(true);
			} else if (newData.length == 0 || newData.length == null || newData.length == undefined) {
				sap.m.MessageBox.information("Please add atleast 1 item to create Purchase Requisition");
				this.getView().byId("oCreateId").setEnabled(true);
			} else {
				this.getView().byId("oCreateId").setEnabled(false);
				if (!this._pBusyDialog) {
					this._pBusyDialog = Fragment.load({
						name: "P2P.Fragment.BusyDialog",
						controller: this
					}).then(function (oBusyDialog) {
						this.getView().addDependent(oBusyDialog);

						return oBusyDialog;
					}.bind(this));
				}
				this._pBusyDialog.then(function (oBusyDialog) {
					oBusyDialog.open();
					this.simulateServerRequest();
				}.bind(this));

				var itemkeycause = "00";
				for (var a = 0; a < newData.length; a++) {
					if (newData.length > 8) {
						var concatcause = "00";
					} else if (newData.length > 98) {
						var concatcause = "0";
					} else {
						var concatcause = "000";
					}
					var totalcauseitemkey = +itemkeycause + +"10";
					itemkeycause = totalcauseitemkey;
					var resultkey = concatcause + totalcauseitemkey;
					var resultcausekey = concatcause + totalcauseitemkey;

					newData[a].PreqItem = resultkey;
				}

				this.getView().byId("ItemTable1").getModel().refresh(true);

				for (var i = 0; i < oTable.length; i++) {

					if (oTable[i].oFragSersShrttextref != "") {
						var oentry = {
							"Itemtext": oTable[i].oFragItemtextref,
							"PreqNo": "",
							"DeleteIndicator": false,
							"Pstyp": "9",
							/*	"Pstyp": oTable[i].FragItemItemtypeRef,*/ //Item Type in Fragment
							"Bednr": "",
							"PreqItem": oTable[i].PreqItem,
							"DocType": oRequesttype, /// filre up and have to give// doctype last time verey l icham
							"Konnr": oAggrmentno,
							"Ktpnr": oAggrItemno,
							"Banpr": "03",
							"PurGroup": oPurcGroup,
							"Blckd": "",
							"PreqDate": oPurcretdate,
							"Blckt": "",
							"Plant": oPlant,
							"AccountType": oExpType,
							"Vbeln": "",
							"CostCtr": oTable[i].oFragItemCostCentr,
							"Vbelp": "000000",
							"Anln1": "",
							"WbsElem": oTable[i].oFragWbscref,
							"Requisitioner": oRequsitioner,
							"Headertext": oHeaderText,
							"MaterialDesc": oTable[i].oFragSersShrttextref,
							"Material": oTable[i].oFragMatcodeRef,
							"MatGrp": oTable[i].oFragMatGrpref,
							// "MatGrp": "50067",
							"Quantity": oTable[i].oFragQntyref,
							"Unit": oTable[i].oFragInputValueUnitref,
							"DelivDate": oTable[i].oDp2ref,
							"UnitPrice": oTable[i].oFrUnitpriceref,
							"TotalPrice": oTable[i].oFragTotalValuref,
							"Currency": oTable[i].oFragCurrencyref,
							"Zzbu": oBussinessUnit, //Bussiness unit
							"ZzbuDesc": oBusDescir, // Bussiness unit desc
							"ZzdeptCode": oUnbudgetCheckBox, //Bussiness Department 
							"ZzdeptDesc": "ZZDLM", //Bussiness Department description
							"ZzdeptCode2": oBussinessDept, //oBussinessUnit
							"ZzdeptDesc2": oBusinesDeptDesc, //Bussiness Dept
							"ZzaprL3": oBussinessAprv, //approver id
							"ZzaprL3Name": oBussinessAprvname, // approver name
							"ZzassName2": oManager, //
							"Memory": true,
							"ReqCategory": oRequestCategry,
							"Sakto": oTable[i].oFragItemGlacntref, //GL account
							"Zzcategoty": oTable[i].oFragzzcategryef, //
							"Service": oTable[i].oFragSersCoderef,
							"ServiceName": oTable[i].oFragSersShrttextref,
							"Packno": "",
							"ServQuan": oTable[i].oFragQntyref,
							"ServPrice": oTable[i].oFrUnitpriceref,
							"ServUom": oTable[i].oFragInputValueUnitref

						};

					} else {

						var oentry = {
							"Itemtext": oTable[i].oFragItemtextref,
							"PreqNo": "",
							"DeleteIndicator": false,
							"Pstyp": "0", //Item Type in Fragment
							"Bednr": "",
							"PreqItem": oTable[i].PreqItem,
							"DocType": oRequesttype, /// filre up and have to give// doctype last time verey l icham
							"Konnr": oAggrmentno,
							"Ktpnr": oAggrItemno,
							"Banpr": "03",
							"PurGroup": oPurcGroup,
							"Blckd": "",
							"PreqDate": oPurcretdate,
							"Blckt": "",
							"Plant": oPlant,
							"AccountType": oExpType,
							"Vbeln": "",
							"CostCtr": oTable[i].oFragItemCostCentr,
							"Vbelp": "000000",
							"Anln1": "",
							"WbsElem": oTable[i].oFragWbscref,
							"Requisitioner": oRequsitioner,
							"Headertext": oHeaderText,
							"MaterialDesc": oTable[i].oFragMatDescref,
							"Material": oTable[i].oFragMatcodeRef,
							"MatGrp": oTable[i].oFragMatGrpref,
							"Quantity": oTable[i].oFragQntyref,
							"Unit": oTable[i].oFragInputValueUnitref,
							"DelivDate": oTable[i].oDp2ref,
							"UnitPrice": oTable[i].oFrUnitpriceref,
							"TotalPrice": oTable[i].oFragTotalValuref,
							"Currency": oTable[i].oFragCurrencyref,
							"Zzbu": oBussinessUnit, //Bussiness unit
							"ZzbuDesc": oBusDescir, // Bussiness unit desc
							"ZzdeptCode": oUnbudgetCheckBox, //Bussiness Department 
							"ZzdeptDesc": "ZZDLM", //Bussiness Department description
							"ZzdeptCode2": oBussinessDept, //oBussinessUnit
							"ZzdeptDesc2": oBusinesDeptDesc, //Bussiness Dept
							"ZzaprL3": oBussinessAprv, //approver id
							"ZzaprL3Name": oBussinessAprvname, // approver name
							"ZzassName2": oManager, //
							"Memory": true,
							"ReqCategory": oRequestCategry,
							"Sakto": oTable[i].oFragItemGlacntref, //GL account
							"Zzcategoty": oTable[i].oFragzzcategryef //

						};

					}

					PR_ItemSet.push(oentry);

				}

				that.getView().byId("oCreateId").setEnabled(false);
				//	sap.ui.getCore().byId("oBuferdailogclosid")._getCancelButton().setEnabled(false);

				/*	this.oModelunlockCreate.setHeaders({
					"Content-Type": "application/json",
					"X-Requested-With": "XMLHttpRequest",
					"DataServiceVersion": "2.0",
					"Accept": "application/json",
					"Method": "POST"
				});*/

				headeritem = {

					"PR_ItemSet": PR_ItemSet,

					"Banfn": "",
					"Bsart": oRequesttype

				};

				//	var path = "/PR_HeaderSet";
				var that = this;

				that.getView().byId("oCreateId").setEnabled(false);

			

				that.oModelunlockCreate.create("/PR_HeaderSet", headeritem, null, function (oData, oResponse) {

						that.getView().byId("oCreateId").setEnabled(false);
						that.getView().byId("idReqType").setSelectedKey(0);
						that.getView().byId("idPGrp").setSelectedKey("");
						that.getView().byId("idPrType").setSelectedKey("");
						that.getView().byId("InputValueBU1").setValue("");
						that.getView().byId("idBuApptext").setText(""); // Approver name id
						that.getView().byId("InputValueBDept").setValue("");
						that.getView().byId("InputValueRequr").setValue("");
						that.getView().byId("idManagertext").setText(""); //Manager
						that.getView().byId("InputValuePlnt").setValue("");
						that.getView().byId("idPuridGrop").setValue("");
						that.getView().byId("Procrjust").setValue("");
						that.getView().byId("InputValueAgrmt").setValue("");

						that.getView().byId("oCancelId").setEnabled(true);
						that.getView().byId("ohedertxtcret").setValue("");
						that.getView().byId("oUndbChecbx").setSelected(false);

						that.getView().byId("ErrorMessages").setVisible(false);

						that.Attachments(oData);
						//	sap.ui.getCore().byId("oBuferdailogclosid")._getCancelButton().setEnabled(true);

						/* that.oBusyIn.close();*/
						sap.m.MessageBox.success("Purchase Requisition" + " " + oResponse.data.Banfn + " " + "has been Created.", {

							actions: ["OK,return to home page", "Stay on this page"],
							onClose: function (oAction) {

								if (oAction == "OK,return to home page") {

									that.onNavback();

								}

							}

						});

						//	var oAttachDumModelA = new sap.ui.model.json.JSONModel();
						//	var oAttachDummyidA = that.getView().byId("idAttachTableItm").setModel(oAttachDumModelA);

						var ootabl = that.getView().byId("ItemTable1");
						var xxtab = ootabl.getModel().getData();

						while (xxtab.length > 0) {
							{
								xxtab.pop();
							}
						}
						ootabl.getModel().updateBindings();

						that.getView().byId("InputValueAgrmt").setEnabled(true);
						that.getView().byId("InputValuePlnt").setEnabled(true);
						that.getView().byId("InputValueRequr").setEnabled(true);
						that.getView().byId("InputValueBDept").setEnabled(true);
						that.getView().byId("InputValueBU1").setEnabled(true);
						that.getView().byId("idPrType").setEnabled(true);
						that.getView().byId("idPGrp").setEnabled(true);
						that.getView().byId("idReqType").setEnabled(true);
						that.getView().byId("idInputFileNumber").setEnabled(true);
						that.getView().byId("oUndbChecbx").setEnabled(true);
						that.getView().byId("Procrjust").setEnabled(true);
						that.getView().byId("oCreateId").setEnabled(true);
						that.getView().byId("oBusyindicatorid").setVisible(false);

					

					},

					function (err) { //Error Callback
						that.getView().byId("oCreateId").setEnabled(true);
						that.getView().byId("ErrorMessages").setVisible(true);
						that.getView().byId("oCancelId").setEnabled(true);
						//////////working code///////////////
						/*	if (err.response.statusCode === 400) {*/
						var obj = JSON.parse(err.response.body);
						if (obj.error.innererror.errordetails.length > 0) {
							that.getView().byId("oBusyindicatorid").setVisible(false);
							sap.ui.core.BusyIndicator.hide();

							var model = new sap.ui.model.json.JSONModel(obj.error.innererror.errordetails);
							oMessagePopover.setModel(model);
							oMessagePopover.toggle(that.getView().byId("ErrorMessages"));
							var viewModel = new sap.ui.model.json.JSONModel();
							viewModel.setData({
								messagesLength: obj.error.innererror.errordetails.length + ''
							});

							that.getView().setModel(viewModel);

						} else {

							sap.m.MessageBox.error(obj.error.message.value);
						}

					});

			}
		},
		Attachments: function (oData) {
			this.getView().byId("oCreateId").setEnabled(false);

			try {

				if (oData) {

					//	var Ponumber = "00" + oData.Banfn; ///need to add 00
					var Ponumber = oData.Banfn;
					var ab = this.getView().byId("idAttachTableItm").getModel().getData().results;
					var arra = [];

					/*	arra.push(Filetype);
						arra.push(fileName);*/

					this._bUploading = true;
					///sap/opu/odata/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ztgetattachmentSet
					var that = this;
					var a = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

					var f = {

						headers: {

							"X-Requested-With": "XMLHttpRequest",

							"Content-Type": "application/atom+xml",

							"DataServiceVersion": "2.0",

							"X-CSRF-Token": "Fetch"

						},
						requestUri: a,

						method: "GET"

					};
					var oHeaders;
					var oDatamodel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV");
					// this.getView().getModel("oDataModel");
					//	this.getView().setBusy(true);
					var that = this;

					oDatamodel._request(f, function (data, oSuccess) {

						var oToken = oSuccess.headers['x-csrf-token'];
						var Countr = 1;
						for (var i = 0; i < ab.length; i++) {

							var Filetype = that.getView().byId("idAttachTableItm").getModel().getData().results[i].mimeType;
							var fileName = that.getView().byId("idAttachTableItm").getModel().getData().results[i].fileName;
							var SelectedFile = that.getView().byId("idAttachTableItm").getModel().getData().results[i].SelectedFile;
							oHeaders = {
								"X-Requested-With": "XMLHttpRequest",

								"Content-Type": "application/atom+json",

								"DataServiceVersion": "2.0",
								"x-csrf-token": oToken,
								"slug": Ponumber + "/" + fileName,

							};
							var oURL = oDatamodel.sServiceUrl + "/ztgetattachmentSet";
							jQuery.ajax({
								type: 'POST',
								dataType: "json",
								url: oURL,
								async: true,
								headers: oHeaders,

								cache: false,

								contentType: Filetype,

								processData: false,

								data: SelectedFile,

								success: function (data, oResponse) {

									Countr++;
									var oAttachDumModelA = new sap.ui.model.json.JSONModel({
										"results": []
									});
									var oAttachDummyidA = that.getView().byId("idAttachTableItm").setModel(oAttachDumModelA);
									if (ab.length == Countr) {
										sap.m.MessageBox.success("Attachment has been sent");

									}

								},
								error: function (data, oResponse) {
									that.getView().byId("oCreateId").setEnabled(true);
									//	sap.m.MessageBox.success("Failed to Sent attachment");
									Countr++;
									if (ab.length == Countr) {
										sap.m.MessageBox.error("Duplicate Data");

									}
								}
							});

						}
					});

				}
			} catch (oException) {
				this.getView().byId("oCreateId").setEnabled(true);

			}
		},
		handleMessagePopoverPress: function (oEvent) {
			oMessagePopover.toggle(oEvent.getSource());
		},
		onSaveEdit: function (oEvent) {

			var oEditObj = {};
			oEditObj.oEditMatcod = this.oFragMatCodRf;
			oEditObj.oEditMatDesc = this.oFragMatDescRf;
			oEditObj.oEditMatGr = this.oFragMatGrpRf;
			oEditObj.oEditQnty = this.oFragQntyRf;
			oEditObj.oEditInpuValUnt = this.oFragInputValueUnitRf;
			oEditObj.oEditCurncy = this.oFragCurrencyRf;
			oEditObj.oEditTotalval = this.oFragTotalValuRf;
			oEditObj.oEditUnitprice = this.oFrUnitpriceRf;
			oEditObj.oEditWbsc = this.oFragWbscRf;
			oEditObj.oEditoDp2 = this.oDp2Rf;
			oEditObj.oEditItemtxt = this.oFragItemtxtRf;
			var oTableEdit2 = this.getView().byId("ItemTable1").getModel().getData()[this.selectedIndexEdit];
			oTableEdit2.oFragMatcodeRef = oEditObj.oEditMatcod;
			this.getView().byId("ItemTable1").getModel().refresh(true);

		},

		onCopy: function (oEvt) {
			var oTablecpy = this.getView().byId("ItemTable1").getModel().getData();
			/*	var oCopyItmObj = {};
				oCopyItmObj.oCopyMatcodeRef = this.FragItemMatCode;
				oCopyItmObj.oCopyServcodeRef = this.FragItemServCode;
				oCopyItmObj.oCopyMatDescref = this.FragItemMatDesc;
				oCopyItmObj.oCopyMatGrpref = this.FragItemMatgrp;
				oCopyItmObj.oCopyQntyref = this.FragItemQntyDesc;
				oCopyItmObj.oCopyInputValueUnitref = this.FragItemUnitVal;
				oCopyItmObj.oCopyCurrencyref = this.FragItemCurrncyVal;
				oCopyItmObj.oCopyTotalValuref = this.FragItemTotalval;
				oCopyItmObj.oCopyUnitpriceref = this.FragItemUnit;
				oCopyItmObj.oCopyWbscref = this.FragItemWbscntr;
				oCopyItmObj.oCopyDp2ref = this.FragItemDate;
				oCopyItmObj.oCopyItemCostCentr = this.FragItemCoscentr;
				oCopyItmObj.oCopyItemtextref = this.FragItemText;
				oCopyItmObj.CopyItemUnitValref = this.FragItemUnitVal;*/

			/*	var ItemTableta = this.getView().byId("ItemTable1").getModel().getData();*/
			var SelecteItems = this.getView().byId("ItemTable1").getSelectedItems();
			if (!SelecteItems.length) {
				sap.m.MessageBox.error("Please Select record to copy");
			} else {
				this.getView().byId("ItemTable1").removeSelections(true);
				/*for (var i = 0; i < SelecteItems.length; i++) {
					this.getView().byId("ItemTable1").getModel().getData().push(SelecteItems[i].getBindingContext().getObject());
				}*/
				for (var i = 0; i < SelecteItems.length; i++) {
					var oCopyItmObj = {};
					oCopyItmObj.oFragItemItemtypeRef = SelecteItems[i].getBindingContext().getObject().oFragItemItemtypeRef;
					oCopyItmObj.oFragMatcodeRef = SelecteItems[i].getBindingContext().getObject().oFragMatcodeRef;
					oCopyItmObj.oCopyServcodeRef = SelecteItems[i].getBindingContext().getObject().oCopyServcodeRef;
					oCopyItmObj.oFragMatDescref = SelecteItems[i].getBindingContext().getObject().oFragMatDescref;
					oCopyItmObj.oFragMatGrpref = SelecteItems[i].getBindingContext().getObject().oFragMatGrpref;

					oCopyItmObj.oFragSersShrttextref = SelecteItems[i].getBindingContext().getObject().oFragSersShrttextref;
					oCopyItmObj.oFragSersDescref = SelecteItems[i].getBindingContext().getObject().oFragSersDescref;
					oCopyItmObj.oFragSersCoderef = SelecteItems[i].getBindingContext().getObject().oFragSersCoderef;

					oCopyItmObj.oFragQntyref = SelecteItems[i].getBindingContext().getObject().oFragQntyref;
					oCopyItmObj.oFragInputValueUnitref = SelecteItems[i].getBindingContext().getObject().oFragInputValueUnitref;
					oCopyItmObj.oFragCurrencyref = SelecteItems[i].getBindingContext().getObject().oFragCurrencyref;
					oCopyItmObj.oFragTotalValuref = SelecteItems[i].getBindingContext().getObject().oFragTotalValuref;
					oCopyItmObj.oFragzzcategryef = SelecteItems[i].getBindingContext().getObject().oFragzzcategryef;
					oCopyItmObj.oFrUnitpriceref = SelecteItems[i].getBindingContext().getObject().oFrUnitpriceref;
					oCopyItmObj.oFragWbscref = SelecteItems[i].getBindingContext().getObject().oFragWbscref;
					oCopyItmObj.oDp2ref = SelecteItems[i].getBindingContext().getObject().oDp2ref;
					oCopyItmObj.oFragItemCostCentr = SelecteItems[i].getBindingContext().getObject().oFragItemCostCentr;
					oCopyItmObj.oFragItemtextref = SelecteItems[i].getBindingContext().getObject().oFragItemtextref;
					/*/*oCopyItmObj.CopyItemUnitValref = this.FragItemUnitVal;te;*/
					oCopyItmObj.oFragItemGlacntref = SelecteItems[i].getBindingContext().getObject().oFragItemGlacntref;

					this.getView().byId("ItemTable1").getModel().getData().push(oCopyItmObj);
				}

				this.getView().byId("ItemTable1").getModel().refresh(true);
			}

		},

		/** cloase event for frag
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf P2P.view.Detailed
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf P2P.view.Detailed
		 */
		onAfterRendering: function () {
			var that = this;
			//Bussiness Unit Searchhelp Start
			this.oModelunlockCreate.read("/ZmmshBuSet", null, null, true, function (oData, oRespone) {
				var Data = oData.results;
				var oBumodel = new sap.ui.model.json.JSONModel(Data);

				that.getView().byId("InputValueBU1").setModel(oBumodel);
			}, function (error) {

			});
			//Bussiness Unit Searchhelp End
			//Bussiness Dept. Searchhelp Start
			this.oModelunlockCreate.read("/ZmmshDeptCode2Set", null, null, true, function (oData, oRespone) {
				var Data = oData.results;
				var oBuDeptmodel = new sap.ui.model.json.JSONModel(Data);

				that.getView().byId("InputValueBDept").setModel(oBuDeptmodel);
			}, function (error) {

			});
			//Bussiness Dept. Searchhelp End

			//Request Category  combobox Start
			this.oModelunlockCreate.read("/zmmsh_categorySet", null, null, true, function (oData, oRespone) {
				var Data1 = oData.results;
				var obj = {};

				for (var i = 0, len = Data1.length; i < len; i++)
					obj[Data1[i]['category']] = Data1[i];

				var Data = new Array();
				for (var key in obj)
					Data.push(obj[key]);

				var oReqCategrymodel = new sap.ui.model.json.JSONModel(Data);
				that.getView().byId("idPrType").setModel(oReqCategrymodel, "ReqcateModel");

				/*	that.getView().byId("InputValueBDept").setModel(oBuDeptmodel);*/
			}, function (error) {

			});
			//Request Category combobox End
			//Requisitioner Searchhelp Start
			that.oModelunlockCreate.read("/ZmmshAfnamSet", null, null, true, function (oData, oRespone) {
				var Data = oData.results;

				var oReqmodel = new sap.ui.model.json.JSONModel(Data);
				that.getView().byId("InputValueRequr").setModel(oReqmodel);

			}, function (error) {

			});
			//Requisitioner Searchhelp End
			//Aggreement searchhelp
			/*	this.oModelunlockCreate.read("/ymm_agreement_headerSet", null, null, true, function (oData, oRespone) {
						var Data = oData.results;

						var oFilteredAgr = Data.filter(function (x) {
							return x.werks == that.oSelectedItemplt;

						});
						var oAggrimodelref = new sap.ui.model.json.JSONModel(oFilteredAgr);
						sap.ui.getCore().byId("oidAgrFrag").setModel(oAggrimodelref);*/

			//Aggreement searchhelp

			//Material Group Searchhelp Start
			/*	that.oModelunlockCreate.read("/ymm_sh_glSet", null, null, true, function (oData, oRespone) {
					var Data = oData.results;

					var oMatrpmodel = new sap.ui.model.json.JSONModel(Data);
					that.getView().byId("InputValueMatgrp").setModel(oMatrpmodel);

				}, function (error) {

				});*/
			//Material Group Searchhelp End
			//Purchase Group Searchhelp Start
			/*	var oUrlPurgrp = "/zmmsh_categorySet(ekgrp='" + this.oReqKey + "')";
				this.oModelunlockCreate.read(oUrlPurgrp, null, null, true, function (oData, oRespone) {
					var Data = oData.results;
					var PucgrpModel = new sap.ui.model.json.JSONModel(Data);
					that.getView().byId("idPurcGrp").setModel(PucgrpModel, "oPurchaseGrpModl");
				}, function (error) {

				});*/
			//Purchase Group Searchhelp End

			//Unit Searchhelp Start
			/*	this.oModelItems.read("/I_UnitOfMeasure", null, null, true, function (oData, oRespone) {
					var Data = oData.results;

					var oUnitmodel = new sap.ui.model.json.JSONModel(Data);
					that.getView().byId("InputValueUnit").setModel(oUnitmodel);

				}, function (error) {

				});*/
			//Plant fragment model start
			this.oModelItems.read("/I_Plant", null, null, true, function (oData, oRespone) {
				var Data = oData.results;

				var oPlantmodl = new sap.ui.model.json.JSONModel(Data);
				that.getView().byId("InputValuePlnt").setModel(oPlantmodl);

			}, function (error) {

			});
			//Plant fragment model End
			//Material Code fragment model start
			/*	var oPlantobj = this.oSelectedItemplt;
				var oMateGrop = this.oSelectedMatgrp;

				var oMatcodel = "/ymmsh_materialSet(WERKS='" + oPlantobj + "'," + "matkl='" + oMateGrop + "')";
				this.oModelunlockCreate.read(oMatcodel, null, null, true, function (oData, oRespone) {
					var Data = oData;

					var oMatodemodl = new sap.ui.model.json.JSONModel(Data);
					that.getView().byId("InputValueMatCode").setModel(oMatodemodl);

				}, function (error) {

				});*/
			//Material Code  fragment model End

			//Unit Searchhelp End
			//Currency Searchhelp Start
			/*	this.oModelItems.read("/I_Currency", null, null, true, function (oData, oRespone) {
					var Data = oData.results;

					var oCurrecymodel = new sap.ui.model.json.JSONModel(Data);
					that.getView().byId("InputValueCurrency").setModel(oCurrecymodel, "oCurrecymodel2");

				}, function (error) {

				});*/
			//Currency Searchhelp End
			//WBS Searchhelp Start
			/*this.oModelunlockCreate.read("/ymmsh_WBSSet", null, null, true, function (oData, oRespone) {
				var Data = oData.results;

				var oWBSmodel = new sap.ui.model.json.JSONModel(Data);
				that.getView().byId("oWbscod").setModel(oWBSmodel);

			}, function (error) {

			});*/
			//CC Searchhelp Start
			/*	that.oModelunlockCreate.read("/ymmsh_CostCenterSet", null, null, true, function (oData, oRespone) {
				var Data = oData.results;
				
				var oCCmodel = new sap.ui.model.json.JSONModel(Data);
				that.getView().byId("oCCCode").setModel(oCCmodel);
				
			}, function (error) {

			});*/
			//CC Searchhelp End

		},

		/*	onFileDeleted: function (oEvent) {
								var Index = oEvent.getSource().getBindingContext().getPath().split("/results")[1];
		
								var TableData = this.getView().byId("oFIleuploadrid").getModel().getData();
								TableData.results.splice(Index, 1);
								this.getView().byId("oFIleuploadrid").getModel().setData(TableData);
								this.getView().byId("oFIleuploadrid").getModel().refresh(true);
							},*/
		onChange: function (oEvent) {
			this.SelectedFile = oEvent.getParameter("files")[0];
			var reader = new FileReader();
			reader.readAsDataURL(oEvent.getParameter("files")[0]);
			var that = this;
			reader.onload = function () {

				that.result = reader.result;

			};
			reader.onerror = function (error) {};

		},

		onUploadComplete: function (oEvent) {
			var oUploadCollection = this.getView().byId("idAttachTableItm");
			oUploadCollection.setMode("MultiSelect");
			if (!oEvent.getSource().getModel()) {
				var model = new sap.ui.model.json.JSONModel({
					"results": []

				});
				oEvent.getSource().setModel(model);
			} else if (oEvent.getSource().getModel()) {
				if (oEvent.getSource().getModel().getData() == null) {

					var model = new sap.ui.model.json.JSONModel({
						"results": []

					});
					oEvent.getSource().setModel(model);

				}

			}
			/*	if (oEvent.getParameter("files")[0].status == "201") {
					var respose = oEvent.getParameter("files")[0].reponse;
					if (respose === undefined) {
						sap.m.MessageBox.show("Upload Failed", sap.m.MessageBox.Icon.ERROR, "Error");
						return;
					}*/
			var oData = oEvent.getSource().getModel().getData();
			var aItems = jQuery.extend(true, {}, oData).results;
			var oItem = {};
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				"items": ["jpg", "txt", "ppt", "doc", "xls", "xlsx", "pdf", "png", "msg"],
				"selected": ["jpg", "txt", "ppt", "doc", "xls", "xlsx", "pdf", "png", "msg"]
			}), "fileTypes");

			//	var a = this.oScopeAvailable;
			//var oSerialNum = oData.results.length+1;
			var oSerialNum = "";
			var sUploadedFile = oEvent.getParameter("files")[0].fileName;

			//http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ztgetattachmentSet

			//	var serviceUrl = "sap/opu/odata/sap/ZMYDELIVERABLES_APP_SRV";

			//	https://webidetesting5812206-l577e310e.dispatcher.ae1.hana.ondemand.com/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/PR_HeaderSet('30000554')?$expand=ymm_get_att_association_nav

			//FOL38000000000004EXT45000000000938

			//https://webidetesting5812206-l577e310e.dispatcher.ae1.hana.ondemand.com/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ztgetattachmentSet('FOL38000000000004EXT45000000000938')/$value

			//30000555 

			//	var sUrl = "/FileAttachmentSet(Deliverable='" + oSerialNum + "',File='" + sUploadedFile + "')/$value";
			//	var oUrl = "sap/opu/odata/sap/ZMYDELIVERABLES_REG_SRV/File(Deliverable='" + oSerialNum + "',File='" + sUploadedFile + "')/$value";
			// at the moment parameter fileName is not set in IE9
			var Filetype = sUploadedFile.substring(sUploadedFile.lastIndexOf('.'));
			var FileName = sUploadedFile.substring(0, sUploadedFile.lastIndexOf('.'));
			oItem = {
				"documentId": jQuery.now().toString(),
				"Deliverable": oSerialNum,
				"File": sUploadedFile,
				"fileName": sUploadedFile,
				"Mimetype": this.SelectedFile.type,
				"mimeType": this.SelectedFile.type,
				"enableEdit": false,
				"SelectedFile": this.SelectedFile
					/*	"url": serviceUrl + sUrl,*/
					/*	"sessionKey": a*/

			};
			oItem.visibleEdit = false;
			oItem.visibleDelete = true;
			/*	if(this.SelectedFile.type=="image/png"||this.SelectedFile.type=="image/jpeg"||this.SelectedFile.type=="image/bmp"
			||this.SelectedFile.type=="image/jpg"){
	oItem.thumbnailUrl=this.result;
			}*/
			aItems.unshift(oItem);
			var json2 = new sap.ui.model.json.JSONModel();
			json2.setData({
				"results": aItems

			});
			oUploadCollection.getModel().setData({
				"results": aItems
			});
			oUploadCollection.setModel(json2);

			oUploadCollection.getModel().refresh();
			//this.getView().byId("idTagName").setValue("");
			sap.ui.core.BusyIndicator.hide();
			var dispMsg = "";
			/*var respns = JSON.parse(oEvent.mParameters.files[0].headers['sap-message']);
									var msg = respns.message;
									var msgType = respns.severity.toUpperCase();
									if (msgType === "SUCCESS") {
										sap.m.MessageBox.show(msg, {
											title : "Success",
											icon : sap.m.MessageBox.Icon.SUCCESS,
											actions : [sap.m.MessageBox.Action.OK],
											styleClass : "messageBox",
											onClose : function(oEvt) {
												if ( oEvt === "OK") {
													//that.getView().byId("idTagName").setValue("");
													//that.callChargeDetailsAttach();
												}
											}
										});
									} else if (msgType === "ERROR") {

										sap.m.MessageBox.show(msg, {
											title : "Error",
											icon : sap.m.MessageBox.Icon.ERROR,
											actions : [sap.m.MessageBox.Action.OK],
											styleClass : "messageBox"
										});
										//that.onUploadTerminated();
									}
								}
								else{
									var message1 = $(oEvent.mParameters.files[0].responseRaw).find('message').first().text();
									if (message1===""){
										var error = (oEvent.mParameters.responseRaw);
										sap.m.MessageBox.show(error, {
											title : "Error",
											icon : sap.m.MessageBox.Icon.ERROR,
											actions : [sap.m.MessageBox.Action.OK],
											styleClass : "messageBox"
										});

									}
									else{
										sap.m.MessageBox.show(message1, {
											title : "Error",
											icon : sap.m.MessageBox.Icon.ERROR,
											actions : [sap.m.MessageBox.Action.OK],
											styleClass : "messageBox"
										});
										that.onUploadTerminated();
									}*/
			/*	}*/
		},

		onBeforeUploadStarts: function () {
			sap.ui.core.BusyIndicator.show();
		},

		onFileDeleted: function (oEvent) {
			var Index = oEvent.getSource().getBindingContext().getPath().split("/results")[1];
			//var CollectionData=

			this.getView().byId("idAttachTableItm").removeItem(this.getView().byId("idAttachTableItm").getItems()[Index]);
			var TableData = this.getView().byId("idAttachTableItm").getModel().getData();
			TableData.results.splice(Index, 1);
			this.getView().byId("idAttachTableItm").getModel().setData(TableData);
			this.getView().byId("idAttachTableItm").getModel().refresh(true);
		},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf P2P.view.Detailed
		 */
		onExit: function () {

			if (this._oDialog) {
				this._oDialog.destroy();
			}

		},

		/*********************************DATA*******************************/
		/*	
	
https://webidetesting9822649-l577e310e.dispatcher.ae1.hana.ondemand.com/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ZmmshBuSet





1.       BU(F4):

http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ZmmshBuSet

2.       Business Dept. (F4): http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ZmmshDeptCode2Set

3.       BU Approver (F4): http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ZmmshDeptCode2Set

4.       Requisationer  (F4):

http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ZmmshAfnamSet

5.       Manger (F4)

http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ZmmshAfnamSet

6.        Material Code ( F4) / Service Code (F4)

http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ymmsh_materialSet

7.       Material group  (F4)  / Service Group(F4)

http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/MMPUR_REQ_SSP_MAINTAIN_SRV/ymm_sh_glSet

8.       UOM:

http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/MMPUR_REQ_SSP_MAINTAIN_SRV/I_UnitOfMeasure

9.       Currency:

http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/MMPUR_REQ_SSP_MAINTAIN_SRV/I_Currency

10.   CC:

http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ymmsh_CostCenterSet

 

11.   WBS:

http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ymmsh_WBSSet
		
		
		
	

				},*/
		onPREdit: function () {

			//	this.getView().byId("oidPurrequsitn").setVisible(true);
			//	this.getView().byId("InputValuePR").setVisible(true);

		},
		onChangePrClick: function (oEvent) {

			var oPurReq = this.getView().byId("InputValuePR").getValue();
			var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";
			//	var that = this;
			this.oDataModel = new sap.ui.model.odata.ODataModel(url, true);
			/*	var oObject =  oPurReq;*/
			var readRequestURL2 = "/PR_HeaderSet('" + oPurReq + "')?$expand=PR_ItemSet";
			this.oDataModel.read(readRequestURL2, null, null, false, function (oData, oResponse) {

				var oObjemodel2 = oData;
				var oModel2 = new sap.ui.model.json.JSONModel(oObjemodel2);

				this.getView().byId("oDetailTable").setModel(oModel2);
			});

		},
		handleChangedate: function () {
			var EndDate = sap.ui.getCore().byId("DP2").getDateValue();
			if (!EndDate) {
				EndDate = new Date(sap.ui.getCore().byId("DP2").getValue());
			}
			var CurrentDate = new Date();
			if (EndDate < CurrentDate) {
				sap.m.MessageBox.error("Please choose from Today date onwards");
				sap.ui.getCore().byId("DP2").setValueState("Error");
			} else {
				sap.ui.getCore().byId("DP2").setValueState("None");
			}

		},

		onRouteMatched: function (oEvent) {

			/*		       var oParameters = oEvent.getParameters().arguments.Dummy;
						if (oParameters === "Yes") {
						
							this.getView().byId("InputValuePR").setVisible(true);
							this.getView().byId("oTilteId").setTitle("Edit Purchase Requisition");
							this.getView().byId("idmdunr").setVisible(true);
							this.getView().byId("iddumgetext").setVisible(true);

							this.getView().byId("idReqType").setEditable(true);
							this.getView().byId("InputValuePlnt").setEditable(false);
							this.getView().byId("oSamHamGrid").setVisible(true);
							this.getView().byId("oProJustlabel").setVisible(false);
							this.getView().byId("Procrjust").setVisible(false);
							this.getView().byId("oidFlex1").setVisible(false);
							this.getView().byId("oidFlex2").setVisible(false);
							this.getView().byId("oidFlex3").setVisible(false);
							this.getView().byId("oidFlex4").setVisible(false);
							this.getView().byId("oidFlex5").setVisible(false);
							this.getView().byId("oidFlex6").setVisible(false);
							this.getView().byId("oCreateId").setText("Save");

							var url = "/sap/opu/odata/sap/YMM_PR_DETAILS_EBAN_SRV";
							var that = this;
							that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);
							var path = "/YMM_AGEINGSet"; 
							that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

								var oObjemodel = oData.results;

								var oPRDetailsModelref = new sap.ui.model.json.JSONModel(oObjemodel);
								oPRDetailsModelref.setSizeLimit(100000);

								that.getView().byId("InputValuePR").setModel(oPRDetailsModelref, "oPRDetailsModel");
							});

						} else {

							this.getView().byId("oidPurrequsitn").setVisible(false);
							this.getView().byId("InputValuePR").setVisible(false);
							this.getView().byId("oTilteId").setTitle("Create Purchase Requisition");
							this.getView().byId("idmdunr").setVisible(false);
							this.getView().byId("iddumgetext").setVisible(false);

							this.getView().byId("idReqType").setEditable(true);
							this.getView().byId("InputValuePlnt").setEditable(true);
							this.getView().byId("oSamHamGrid").setVisible(false);
							this.getView().byId("oProJustlabel").setVisible(true);
							this.getView().byId("Procrjust").setVisible(true);
							this.getView().byId("oidFlex1").setVisible(true);
							this.getView().byId("oidFlex2").setVisible(true);
							this.getView().byId("oidFlex3").setVisible(true);
							this.getView().byId("oidFlex4").setVisible(true);
							this.getView().byId("oidFlex5").setVisible(true);
							this.getView().byId("oidFlex6").setVisible(true);
							this.getView().byId("oCreateId").setText("Create");

						}*/

		},
		handleUploadComplete: function (oEvent) {
			this.getView().busyView.setVisible(false);
		},
		handleEquDMSFileSelect: function (oEvent) {

			this.getView().busyView.setVisible(false);
			if (navigator.appVersion.toString().includes('.NET') > 0) {

				var obj = oEvent.getSource().getSelectedItem().getBindingContext().getObject();
				var filetype = this.getFileContentType(obj.ObjType);

				var downloadData = filetype + ";base64," + obj.FileContent;

				var blob = this.b64toBlob(obj.FileContent, filetype);

				var selectedItem = oEvent.getSource().getSelectedItem();
				oEvent.getSource().setSelectedItem(selectedItem, false);
				window.navigator.msSaveBlob(blob, obj.Descript + "." + obj.ObjType);
			} else {}

			this.selectedAttach = "EQ";

			this.fileSelectCounter++;
		},
		getFileContentType: function (objectType) {
			if (objectType) {
				objectType = objectType.toUpperCase();
			}

			if (objectType === 'PNG' || objectType === 'png') {
				return 'image/png';
			}
			if (objectType === 'PDF') {
				return 'application/pdf';
			}
			if (objectType == 'XLS') {
				return 'application/vnd.ms-excel';
			}
			if (objectType == 'DOC') {
				return 'application/msword';
			}
			if (objectType == 'JPG' || objectType == 'JPEG') {
				//return 'image/jpg';
				return 'image/jpeg';
			}
			if (objectType == 'VDS') {
				return 'application/vds';
			}
			if (objectType == 'prt') {
				return 'application/prt';
			}
			if (objectType == 'jt') {
				return 'application/jt';
			}
			return 'text/plain';
		},
		b64toBlob: function (base64Data, contentType, sliceSize) {

			var byteCharacters,
				byteArray,
				byteNumbers,
				blobData,
				blob;

			contentType = contentType || '';

			byteCharacters = atob(base64Data);

			// Get blob data sliced or not
			blobData = sliceSize ? getBlobDataSliced() : getBlobDataAtOnce();

			blob = new Blob(blobData, {
				type: contentType
			});

			return blob;

			/*
			 * Get blob data in one slice.
			 * => Fast in IE on new Blob(...)
			 */
			function getBlobDataAtOnce() {
				byteNumbers = new Array(byteCharacters.length);

				for (var i = 0; i < byteCharacters.length; i++) {
					byteNumbers[i] = byteCharacters.charCodeAt(i);
				}

				byteArray = new Uint8Array(byteNumbers);

				return [byteArray];
			}

			/*
			 * Get blob data in multiple slices.
			 * => Slow in IE on new Blob(...)
			 */
			function getBlobDataSliced() {

				var slice,
					byteArrays = [];

				for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
					slice = byteCharacters.slice(offset, offset + sliceSize);

					byteNumbers = new Array(slice.length);

					for (var i = 0; i < slice.length; i++) {
						byteNumbers[i] = slice.charCodeAt(i);
					}

					byteArray = new Uint8Array(byteNumbers);

					// Add slice
					byteArrays.push(byteArray);
				}

				return byteArrays;
			}
		},
		handleFileChange: function (oEvent) {

			this.getView().busyView.setVisible(true);
			var sUploadedFile = oEvent.getParameter("files")[0];
			var that = this;
			this.fileName = sUploadedFile.name;
			this.sFileName = this.fileName;
			this.sFileType = this.fileName.split('.')[1];
			//this.sFileName = "";
			this.sFileSize = sUploadedFile.size / 1000;

			var reader = new FileReader();
			reader.onload = (function (theFile) {
				return function (e) {
					var fileCon = e.target.result.split(',')[1];
					that.mimeType = that.fileName.split('.');
					that.mimeType = that.mimeType[that.mimeType.length - 1];
					var docId = "";
					docId = jQuery.now().toString();
					var fileName = that.sFileName.split(".").slice(0, -1).join(".") || this.sFileName + "";
					that.filePostingData = {
						"ExFilecontent": fileCon,
						"Filename": fileName,
						"Format": '.' + that.mimeType,
						"enableEdit": true,
						"documentId": docId,
						"fileSize": that.sFileSize
					};

					that.getView().busyView.setVisible(false);
				};
			})(sUploadedFile, this);
			reader.readAsDataURL(sUploadedFile);
		},
		onReject: function (oEvt) {

			this.getView().byId("idReqType").setSelectedKey(0);
			this.getView().byId("idPGrp").setSelectedKey("");
			this.getView().byId("idPrType").setSelectedKey("");
			this.getView().byId("InputValueBU1").setValue("");
			this.getView().byId("idBuApptext").setText("");
			this.getView().byId("InputValueBDept").setValue("");
			this.getView().byId("InputValueRequr").setValue("");
			this.getView().byId("idManagertext").setText("");
			this.getView().byId("InputValuePlnt").setValue("");
			this.getView().byId("idPuridGrop").setValue("");
			this.getView().byId("Procrjust").setValue("");
			this.getView().byId("InputValueAgrmt").setValue("");

			var ootabl = this.getView().byId("ItemTable1");
			var xxtab = ootabl.getModel().getData();

			while (xxtab.length > 0) {
				{
					xxtab.pop();
				}
			}
			ootabl.getModel().updateBindings();
			this.getView().byId("ErrorMessages").setVisible(false);

			/*	var modelx2 = new sap.ui.model.json.JSONModel([]);
						oMessagePopover.setModel(modelx2);
				
						var viewModelx2 = new sap.ui.model.json.JSONModel();
						viewModelx2.setData({
							messagesLength:  0+''
						});

						this.getView().setModel(viewModelx2);*/

		},
		handleFileDeletion: function (oEvent) {
			this.getView().busyView.setVisible(true);
			var idUrl = oEvent.getSource().getModel().getData().d.results[oEvent.getSource()._oItemForDelete._iLineNumber];
			if (idUrl.Linkobject != "") {
				var data = sap.ui.getCore().getModel('AppLabelsCollection').getData();
				var formatter = com.innovapptive.utils.Formatter.localizationForStaticFields;
				var msg = formatter(data, "ATTACH_CANNOT_DLT", "Cannot delete the attachment");
				this.getView().busyView.setVisible(false);
				sap.m.MessageToast.show(msg);
				return;

			}
			var objkey = idUrl.Objkey;
			var objId = idUrl.ObjId;
			var urlToCall = "WOAttachmentsCollection(ObjId='" + objId + "',Objkey='" + objkey + "')";
			var oService = "";
			var t = this;
			//this.getView().setBusy(true);
			oService.callDeleteServiceAttachment(urlToCall, null, function () {

				t.loadAttachmentsAftPosting();

			}, this);
		},
		loadAttachmentsAftPosting: function () {},

		onAddStartDateChange: function () {
			/*
			var today = new Date();
			var dd = today.getDate();
			var mm = today.getMonth() + 1; 

			var yyyy = today.getFullYear();
			if (dd < 10) {
			dd = '0' + dd;
			}
			if (mm < 10) {
			mm = '0' + mm;
			}
			var today = mm + '/' + dd + '/' + yyyy;
			if (sap.ui.getCore().byId("AddStartDate").getValue().length >= 6 && sap.ui.getCore().byId("AddStartDate").getValue().length < 11) {
			if (sap.ui.getCore().byId("AddStartDate").getValue().indexOf("/") != -1) {
			var DateValue = sap.ui.getCore().byId("AddStartDate").getValue().split("/");
			var dd = DateValue[1];
			var mm = DateValue[0]; //January is 0!

			// var yyyy =DateValue[2];
			var yyyy = sap.ui.getCore().byId("AddStartDate").getDateValue().getFullYear();
			} else {
			var DateValue = new Date(sap.ui.getCore().byId("AddStartDate").getValue());
			var dd = DateValue.getDate();
			var mm = DateValue.getMonth() + 1; //January is 0!

			var yyyy = DateValue.getFullYear();
			}
			if (dd < 10) {
			dd = '0' + dd;
			}
			if (mm < 10) {
			mm = '0' + mm;
			}
			var StartDateValue = mm + '/' + dd + '/' + yyyy;
			} else {
			var StartDateValue = new Date(sap.ui.getCore().byId("AddStartDate").getValue());
			var dd = StartDateValue.getDate();
			var mm = StartDateValue.getMonth() + 1; 
			var yyyy = StartDateValue.getFullYear();
			if (dd < 10) {
			dd = '0' + dd;
			}
			if (mm < 10) {
			mm = '0' + mm;
			}
			var StartDateValue = mm + '/' + dd + '/' + yyyy;
			}

			*/
		},
		/*onTypeMissmatch:function(){
			sap.m.MessageBox.warning("Please enter a proper file");
		}*/
		onNavback: function () {
			debugger
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View1", {

			});
			/*var oHistory = History.getInstance();
				var sPreviousHash = oHistory.getPreviousHash();

				if (sPreviousHash !== undefined) {
					window.history.go(-1);
				} else {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					oRouter.navTo("View1", {
						
					});
				}*/

		},
	});

});