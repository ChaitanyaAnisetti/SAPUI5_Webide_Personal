var Purch;
jQuery.sap.includeStyleSheet(sap.ui.resource("P2P", "css/style.css"));
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/m/MessageBox",
	"P2P/Formatter/Formatter",
	"sap/ui/model/Sorter",
	"sap/ui/core/routing/History",

], function (Controller, Filter, MessageBox, Formatter, Sorter, History) {
	"use strict";

	return Controller.extend("P2P.controller.View1", {

		onInit: function () {

			/*	var aLoggedUser = sap.ushell.Container.getUser().getId();*/
			//-------------------------------------Table Binding with Odata-----------------------------------//
			////////////////////////////working/////////////////////////////////////
			//    var oUrl = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/YmmshPrSet('30000352')";
			this.url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

			var that = this;
			that.oDataModel = new sap.ui.model.odata.ODataModel(that.url, true);
			that.getOwnerComponent().oDataModel = that.oDataModel;

			var path = "/ymm_userSet";
			that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

				var oObjemodel1 = oData.results;

				var oLoggeduserModel = new sap.ui.model.json.JSONModel(oObjemodel1);
				oLoggeduserModel.setSizeLimit(1000);

				that.getView().byId("oLogdusrId").setModel(oLoggeduserModel, "oUserDetails");
				that.Loggeduser = that.getView().byId("oLogdusrId").getModel("oUserDetails").getData()[0].SYUSER;
				that.getOwnerComponent().LoggedinUser = that.getView().byId("oLogdusrId").getModel("oUserDetails").getData()[0].SYUSER;

			});

			var url = "/sap/opu/odata/sap/YMM_PR_DETAILS_EBAN_SRV";
			var that = this;

			that.oRecrds = "49";
			that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

			var path = "/YMM_AGEINGSet?$top=" + that.oRecrds;
			that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

				var oObjemodel = oData.results;

				var oModel = new sap.ui.model.json.JSONModel(oObjemodel);
				oModel.setSizeLimit(100000);

				that.getView().byId("oMainTable").setModel(oModel, "oPRframe1Model");

				/*	var oProductNameColumn = that.getView().byId("oReqdateid");
					that.getView().byId("oMainTable").sort(oProductNameColumn, SortOrder.Ascending);*/
				that.getView().byId("idRecords").setSelectedKey(that.oRecrds);

				that.getView().byId("Items").setText("Items(" + "" + oObjemodel.length + "" + ")");
				var obj = {};

				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['Plant']] = oObjemodel[i];

				var plant = new Array();
				for (var key in obj)
					plant.push(obj[key]);
				oModel.setProperty("/Plant", plant);

				that.getView().byId("idPlnt").setModel(oModel, "oPRPlntModel");

				var obj = {};

				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['CreatedBy']] = oObjemodel[i];

				var CreatedBy = new Array();
				for (var key in obj)
					CreatedBy.push(obj[key]);

				oModel.setProperty("/CreatedBy", CreatedBy);
				that.getView().byId("idCreatby").setModel(oModel, "oCrtdbyModel");
				var obj = {};

				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['ReqFor']] = oObjemodel[i];

				var ReqFor = new Array();
				for (var key in obj)
					ReqFor.push(obj[key]);
				oModel.setProperty("/ReqFor", ReqFor);
				that.getView().byId("idRequisition").setModel(oModel, "oRequisitionModel");
				var obj = {};

				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['PurReq']] = oObjemodel[i];

				var PurReq = new Array();
				for (var key in obj)
					PurReq.push(obj[key]);
				oModel.setProperty("/PurReq", PurReq);
				that.getView().byId("idPrNumr").setModel(oModel, "oPrNumModel");
				var obj = {};

				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['PurchOrd']] = oObjemodel[i];

				var PurchOrd = new Array();
				for (var key in obj)
					PurchOrd.push(obj[key]);
				var PurchOrddata = PurchOrd.filter(function (x) {
					return x.PurchOrd != "";
				});
				oModel.setProperty("/PurchOrd", PurchOrddata);
				that.getView().byId("idPoNumb").setModel(oModel, "oPoNumModel");

			});

			// set the device model
			//	this.setModel(models.createDeviceModel(), "device");

			//call the chatbot function
		//	that.getChatBot();

			////////////////////////////working/////////////////////////////////////

			//-------------------------------------End Table Binding with Odata-----------------------------------//

		},
	/*	getChatBot: function () {
			debugger
		
			if (!document.getElementById("cai-webchat")) {
				var s = document.createElement("script");
				s.setAttribute("id", "cai-webchat");
				s.setAttribute("src", "https://cdn.cai.tools.sap/webchat/webchat.js");
				document.body.appendChild(s);
				
				s.setAttribute("channelId", "4369ceaa-b9cc-4a0c-8ba4-9689845fe822");
			s.setAttribute("token", "97bf3677f373472d7b699b6c3aa2558b");
			}
		
		},*/

		onClearAll: function () {
			this.getView().byId("idDP1").setValue("");
			this.getView().byId("idDP2").setValue("");
			this.getView().byId("idPlnt").setSelectedKey("");
			this.getView().byId("idCreatby").setSelectedKey("");
			this.getView().byId("idRequisition").setSelectedKey("");
			this.getView().byId("idPrNumr").setSelectedKey("");
			this.getView().byId("idPoNumb").setSelectedKey("");
		},
		OnAfterRendering: function () {

		},
		onPlatChange: function () {

			this.getView().byId("idPlnt").getModel("oPRPlntModel").getData();

			var oMainFiles = this.getView().byId("idPlnt").getModel().getData();

			var oMainFIlters = oMainFiles.filter(function (Plant, index) {
				return oMainFiles.indexOf(Plant);
			});

			var oMainFiles = this.getView().byId("idPlnt").getModel().getData().nodes;

			var oMainFIlters = oMainFiles.filter(function (Plant, index) {
				return oMainFiles.indexOf(Plant);
			});

		},
		onPRCreatdByChange: function () {

		},
		onRequisitionrChange: function () {

		},

		handleLinkPress1: function () {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Creat", {

			});

		},
		handleLinkPress2: function () {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Edit", {

			});

		},

		_onFioriAnalyticalListPageTableItemPress: function (oEvent) {

			var oSelectedPath = oEvent.mParameters.listItem.getBindingContextPath();
			Purch = oEvent.getSource().getModel("oPRframe1Model").mContexts[oSelectedPath].getObject();
			this.getOwnerComponent().PurchaseRequObj = oEvent.getSource().getModel("oPRframe1Model").mContexts[oSelectedPath].getObject();

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Detail", {

				/*	PurchaserReq: this.PurReq,
					oItemNum: this.Itemno,*/
			});

		},
		onFilterChange: function (oEvt) {

			var Plantvalue = this.getView().byId("idPlnt").getSelectedKey();
			var CreatedBy = this.getView().byId("idCreatby").getSelectedKey();
			var ReqFor = this.getView().byId("idRequisition").getSelectedKey();
			var PurReq = this.getView().byId("idPrNumr").getSelectedKey();
			var PurchOrd = this.getView().byId("idPoNumb").getSelectedKey();

			if (Plantvalue !== "" || CreatedBy !== "" || ReqFor !== "" || PurReq !== "" || PurchOrd !== "") {
				var that = this;

				that.oBusyIn = new sap.m.BusyDialog();
				that.oBusyIn.open(true);

				var url = "/sap/opu/odata/sap/YMM_PR_DETAILS_EBAN_SRV";

				that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);
				var oSelectedKey = that.getView().byId("idRecords").getSelectedKey();
				var path = "/YMM_AGEINGSet?$top=" + oSelectedKey;
				that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

					var oObjemodel = oData.results;

					that.oBusyIn.close();

					var oModel = new sap.ui.model.json.JSONModel(oObjemodel);
					oModel.setSizeLimit(100000);

					that.getView().byId("oMainTable").setModel(oModel, "oPRframe1Model");

				});

				var aFilters = [];
				/*	var FromDatevalue = this.getView().byId("idDP1").getValue();
					var ToDatevalue = this.getView().byId("idDP2").getValue();
					if (ToDatevalue != "" && FromDatevalue != "") {
						jQuery.sap.require("sap.ui.core.format.DateFormat");
						var oDateFormat1 = sap.ui.core.format.DateFormat.getDateTimeInstance({
							pattern: "yyyy-MM-dd'T'HH:mm:ss"
						});
						ToDatevalue = oDateFormat1.format(new Date(ToDatevalue));
						FromDatevalue = oDateFormat1.format(new Date(FromDatevalue));

						var filter = new sap.ui.model.Filter("ReqDate", sap.ui.model.FilterOperator.BT, FromDatevalue, ToDatevalue);
						aFilters.push(filter);
					} else if (ToDatevalue == "" && FromDatevalue != "") {

						jQuery.sap.require("sap.ui.core.format.DateFormat");
						var oDateFormat2 = sap.ui.core.format.DateFormat.getDateTimeInstance({
							pattern: "yyyy-MM-dd'T'HH:mm:ss"
						});

						FromDatevalue = oDateFormat2.format(new Date(FromDatevalue));

						var filter = new sap.ui.model.Filter("ReqDate", sap.ui.model.FilterOperator.EQ, FromDatevalue);
						aFilters.push(filter);

					} else if (ToDatevalue != "") {
						if (FromDatevalue == "") {
							sap.m.MessageBox.warning("Please Enter From Date");
							return;
						}
						jQuery.sap.require("sap.ui.core.format.DateFormat");
						var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
							pattern: "yyyy-MM-dd'T'HH:mm:ss"
						});
						ToDatevalue = oDateFormat.format(new Date(ToDatevalue));
						var filter = new sap.ui.model.Filter("ReqDate", sap.ui.model.FilterOperator.EQ, ToDatevalue);
						aFilters.push(filter);

					}*/

				var Plantvalue = this.getView().byId("idPlnt").getSelectedKey();
				if (Plantvalue != "") {
					var filter1 = new Filter("Plant", sap.ui.model.FilterOperator.EQ, Plantvalue);
					aFilters.push(filter1);
				}
				var CreatedBy = this.getView().byId("idCreatby").getSelectedKey();
				if (CreatedBy != "") {
					var filter2 = new Filter("CreatedBy", sap.ui.model.FilterOperator.EQ, CreatedBy);
					aFilters.push(filter2);
				}
				var ReqFor = this.getView().byId("idRequisition").getSelectedKey();
				if (ReqFor != "") {
					var filter3 = new Filter("ReqFor", sap.ui.model.FilterOperator.EQ, ReqFor);
					aFilters.push(filter3);
				}

				var PurReq = this.getView().byId("idPrNumr").getSelectedKey();
				if (PurReq != "") {
					var filter4 = new Filter("PurReq", sap.ui.model.FilterOperator.EQ, PurReq);
					aFilters.push(filter4);
				}
				var PurchOrd = this.getView().byId("idPoNumb").getSelectedKey();
				if (PurchOrd != "") {
					var filter5 = new Filter("PurchOrd", sap.ui.model.FilterOperator.EQ, PurchOrd);
					aFilters.push(filter5);
				}

				var table = this.getView().byId("oMainTable");
				var binding = table.getBinding("items");
				binding.filter(aFilters, "Application");
				this.getView().byId("Items").setText("Items(" + "" + binding.aIndices.length + "" + ")");

			} else {

				var that = this;
				that.oBusyIn = new sap.m.BusyDialog();
				that.oBusyIn.open(true);
				var url = "/sap/opu/odata/sap/YMM_PR_DETAILS_EBAN_SRV";

				that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);
				var oSelectedKey = that.getView().byId("idRecords").getSelectedKey();
				var path = "/YMM_AGEINGSet?$top=" + oSelectedKey;
				that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

					var oObjemodel = oData.results;
					that.oBusyIn.close();
					var oModel = new sap.ui.model.json.JSONModel(oObjemodel);
					oModel.setSizeLimit(100000);

					that.getView().byId("oMainTable").setModel(oModel, "oPRframe1Model");

					var obj = {};

					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Plant']] = oObjemodel[i];

					var plant = new Array();
					for (var key in obj)
						plant.push(obj[key]);
					oModel.setProperty("/Plant", plant);

					that.getView().byId("idPlnt").setModel(oModel, "oPRPlntModel");

					var obj = {};

					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['CreatedBy']] = oObjemodel[i];

					var CreatedBy = new Array();
					for (var key in obj)
						CreatedBy.push(obj[key]);

					oModel.setProperty("/CreatedBy", CreatedBy);
					that.getView().byId("idCreatby").setModel(oModel, "oCrtdbyModel");
					var obj = {};

					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['ReqFor']] = oObjemodel[i];

					var ReqFor = new Array();
					for (var key in obj)
						ReqFor.push(obj[key]);
					oModel.setProperty("/ReqFor", ReqFor);
					that.getView().byId("idRequisition").setModel(oModel, "oRequisitionModel");
					var obj = {};

					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['PurReq']] = oObjemodel[i];

					var PurReq = new Array();
					for (var key in obj)
						PurReq.push(obj[key]);
					oModel.setProperty("/PurReq", PurReq);
					that.getView().byId("idPrNumr").setModel(oModel, "oPrNumModel");
					var obj = {};

					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['PurchOrd']] = oObjemodel[i];

					var PurchOrd = new Array();
					for (var key in obj)
						PurchOrd.push(obj[key]);
					var PurchOrddata = PurchOrd.filter(function (x) {
						return x.PurchOrd != "";
					});
					oModel.setProperty("/PurchOrd", PurchOrddata);
					that.getView().byId("idPoNumb").setModel(oModel, "oPoNumModel");

				});

				// add filter for search
				var aFilters = [];
				var FromDatevalue = this.getView().byId("idDP1").getValue();
				var ToDatevalue = this.getView().byId("idDP2").getValue();
				if (ToDatevalue != "" && FromDatevalue != "") {
					jQuery.sap.require("sap.ui.core.format.DateFormat");
					var oDateFormat1 = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "yyyy-MM-dd'T'HH:mm:ss"
					});
					ToDatevalue = oDateFormat1.format(new Date(ToDatevalue));
					FromDatevalue = oDateFormat1.format(new Date(FromDatevalue));
					/*	var filter = new Filter("ReqDate", sap.ui.model.FilterOperator.EQ, Datevalue);*/
					var filter = new sap.ui.model.Filter("ReqDate", sap.ui.model.FilterOperator.BT, FromDatevalue, ToDatevalue);
					aFilters.push(filter);
				} else if (ToDatevalue == "" && FromDatevalue != "") {

					jQuery.sap.require("sap.ui.core.format.DateFormat");
					var oDateFormat2 = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "yyyy-MM-dd'T'HH:mm:ss"
					});

					FromDatevalue = oDateFormat2.format(new Date(FromDatevalue));

					var filter = new sap.ui.model.Filter("ReqDate", sap.ui.model.FilterOperator.EQ, FromDatevalue);
					aFilters.push(filter);

				} else if (ToDatevalue != "") {
					if (FromDatevalue == "") {
						sap.m.MessageBox.warning("Please Enter From Date");
						return;
					}
					jQuery.sap.require("sap.ui.core.format.DateFormat");
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "yyyy-MM-dd'T'HH:mm:ss"
					});
					ToDatevalue = oDateFormat.format(new Date(ToDatevalue));
					var filter = new sap.ui.model.Filter("ReqDate", sap.ui.model.FilterOperator.EQ, ToDatevalue);
					aFilters.push(filter);

				}

				var Plantvalue = this.getView().byId("idPlnt").getSelectedKey();
				if (Plantvalue != "") {
					var filter1 = new Filter("Plant", sap.ui.model.FilterOperator.EQ, Plantvalue);
					aFilters.push(filter1);
				}
				var CreatedBy = this.getView().byId("idCreatby").getSelectedKey();
				if (CreatedBy != "") {
					var filter2 = new Filter("CreatedBy", sap.ui.model.FilterOperator.EQ, CreatedBy);
					aFilters.push(filter2);
				}
				var ReqFor = this.getView().byId("idRequisition").getSelectedKey();
				if (ReqFor != "") {
					var filter3 = new Filter("ReqFor", sap.ui.model.FilterOperator.EQ, ReqFor);
					aFilters.push(filter3);
				}

				var PurReq = this.getView().byId("idPrNumr").getSelectedKey();
				if (PurReq != "") {
					var filter4 = new Filter("PurReq", sap.ui.model.FilterOperator.EQ, PurReq);
					aFilters.push(filter4);
				}
				var PurchOrd = this.getView().byId("idPoNumb").getSelectedKey();
				if (PurchOrd != "") {
					var filter5 = new Filter("PurchOrd", sap.ui.model.FilterOperator.EQ, PurchOrd);
					aFilters.push(filter5);
				}

				// update table binding
				var table = this.getView().byId("oMainTable");
				var binding = table.getBinding("items");
				binding.filter(aFilters, "Application");
				this.getView().byId("Items").setText("Items(" + "" + binding.aIndices.length + "" + ")");

			}

		},
		ExporttoExcellsheet: function () {

			var Context = this.getView().byId("oMainTable").getAggregation("items");
			if (Context.length == 0) {
				sap.m.MessageBox.error("No data available to export");
				return;
			} else {
				var items = Context.map(function (oEvent) {
					return oEvent.getBindingContext("oPRframe1Model").getObject();
				});
				this.JSONToCSVConvertor(items, "", true);
			}
		},
		JSONToCSVConvertor: function (JSONData, ReportTitle, ShowLabel) {
			var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
			var CSV = "";
			if (ShowLabel) {
				var row = "";
				row = row.slice(0, -1);
			}

			row += "Purchase Requisition" + ",";
			row += "Purchase  Order" + ",";
			row += "Requested Date" + ",";
			row += "Plant" + ",";
			row += "Material/Service Description" + ",";
			row += "Quantity" + ",";
			row += "Price" + ",";
			row += "Net Value" + ",";
			row += "Currency" + ",";
			row += "Status" + ",";
			/*	row += "Expense Type" + ",";*/
			row += "BU" + ",";
			row += "Created By" + ",";
			row += "PR Item" + ",";
			row += "Vendor Name" + ",";
			row += "PO Item" + ",";
			row += "PO Item Desc." + ",";
			row += "PO Value Inr" + ",";
			row += "PO Currency" + ",";
			row += "Order Confirm Date" + ",";
			row += "Inbound Del.Date" + ",";
			row += "Gr Entry Date" + ",";
			row += "Int.Del.Date" + ",";
			row += "Inv.Del.Date" + ",";
			row += "Inv.Entry Date" + ",";
			row += "Payment Status" + ",";
			row += "Reason on Hold" + ",";
			row += "Reason Text" + ",";
			row += "Date of Inv." + ",";
			row += "Date of Posting" + ",";

			CSV += row + '\r\n';
			//loop is to extract each row
			for (var i = 0; i < arrData.length; i++) {
				var row = "";
				var ReqDate;
				if (arrData[i].ReqDate != null) {

					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "dd/MM/yyyy"
					});
					var ReqDate = oDateFormat.format(new Date(arrData[i].ReqDate));

				}

				var OrdConfirmDate;
				if (arrData[i].OrdConfirmDate != null) {

					var oDateFormata1 = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "dd/MM/yyyy"
					});
					var OrdConfirmDate = oDateFormata1.format(new Date(arrData[i].OrdConfirmDate));

				}

				var InboundDelDate;
				if (arrData[i].InboundDelDate != null) {

					var oDateFormata2 = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "dd/MM/yyyy"
					});
					var InboundDelDate = oDateFormata2.format(new Date(arrData[i].InboundDelDate));

				}

				var GrEntryDate;
				if (arrData[i].GrEntryDate != null) {

					var oDateFormata3 = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "dd/MM/yyyy"
					});
					var GrEntryDate = oDateFormata3.format(new Date(arrData[i].GrEntryDate));

				}

				var GrEntryDate;
				if (arrData[i].GrEntryDate != null) {

					var oDateFormata4 = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "dd/MM/yyyy"
					});
					var GrEntryDate = oDateFormata4.format(new Date(arrData[i].GrEntryDate));

				}

				var IntDelDt;
				if (arrData[i].IntDelDt != null) {

					var oDateFormata5 = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "dd/MM/yyyy"
					});
					var IntDelDt = oDateFormata5.format(new Date(arrData[i].IntDelDt));

				}
				var InvEntryDate;
				if (arrData[i].InvEntryDate != null) {

					var oDateFormata6 = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "dd/MM/yyyy"
					});
					var InvEntryDate = oDateFormata6.format(new Date(arrData[i].InvEntryDate));

				}
				var DateOfInvoice;
				if (arrData[i].DateOfInvoice != null) {

					var oDateFormata7 = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "dd/MM/yyyy"
					});
					var DateOfInvoice = oDateFormata7.format(new Date(arrData[i].DateOfInvoice));

				}
				var DateOfPosting;
				if (arrData[i].DateOfPosting != null) {

					var oDateFormata8 = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "dd/MM/yyyy"
					});
					var DateOfPosting = oDateFormata8.format(new Date(arrData[i].DateOfPosting));

				}

				row += '"' + arrData[i].PurReq + '","' + arrData[i].PurchOrd + '","' + (ReqDate || "") + '","' + arrData[i].Plant +
					'","' +
					arrData[i].ItemDesc + '","' + arrData[i].QuantityPr + '","' + arrData[i].PricePr + '","' + arrData[i].PrValueInr + '","' +
					arrData[i].Currency + '","' + arrData[i].PrApprovedStatus + '","' + arrData[i].BusinessUnit + '","' + arrData[i].CreatedName +
					'","' + arrData[i].PrItem + '","' + arrData[i].VendName + '","' + arrData[i].PoItem + '","' + arrData[i].PoItemDesc + '","' +
					arrData[i].PoNetValue + '","' + arrData[i].PoCurrency + '","' + arrData[i].PoValueInr + '","' + (OrdConfirmDate || "") +
					'","' +
					(InboundDelDate || "") + '","' + (GrEntryDate || "") + '","' + (IntDelDt || "") + '","' + (
						InvEntryDate || "") +
					'","' + (arrData[i].PaymentStatus || "") + '","' + arrData[i].ReasonOnHold + '","' + arrData[i].ReasonText + '","' + (
						DateOfInvoice ||
						"") +
					'","' + (DateOfPosting || "") + '",';
				//}

				row.slice(1, row.length);
				CSV += row + '\r\n';
			}
			if (CSV == "") {
				/*	alert("Invalid data");*/
				return;
			}
			var fileName = "PR List Report";
			fileName += ReportTitle.replace(/ /g, "_");
			// Initialize file format you want csv or xls

			var blob = new Blob(["\ufeff" + CSV], {
				type: "text/csv;charset=utf-8,"
			});
			if (sap.ui.Device.browser.name === "ie" || sap.ui.Device.browser.name === "ed") { // IE 10+ , Edge (IE 12+)
				navigator.msSaveBlob(blob, "Report.csv");
			} else {
				var uri = 'data:text/csv;charset=utf-8,' + "\ufeff" + encodeURIComponent(CSV); //'data:application/vnd.ms-excel,' + escape(CSV);
				var link = document.createElement("a");

				link.href = uri;
				link.style = "visibility:hidden";
				link.download = fileName + ".csv";
				document.body.appendChild(link);
				link.click();
				document.body.removeChild(link);
			}

		},
		onLinkPress: function (oEvt) {

			var oSelectedPr = oEvt.oSource.getText();
			var that = this;
			that.Loggeduser;

			var oCrossAppNavigator = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService && sap.ushell.Container.getService(
				"CrossApplicationNavigation");
			oCrossAppNavigator.isIntentSupported(["P2PEdit-display"])
				.done(function (aResponses) {

				})
				.fail(function () {
					new sap.m.MessageToast("Provide corresponding intent to navigate");
				});
			// generate the Hash to display P2PEdit
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "P2PEdit",
					/*	semanticObject: "P2P_Status"*/
					action: "display"
				},
				params: {
					"PurReq": oSelectedPr,
					"LoggedUser": that.Loggeduser,
					"PreviousIntent": window.hasher.getHash().split("-")[0]

				}
			})) || "";
			//Generate a  URL for the second application
			/*	var url = window.location.href.split('#')[0] + hash;
				
				sap.m.URLHelper.redirect(url, true);
				*/
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		}

	});
});