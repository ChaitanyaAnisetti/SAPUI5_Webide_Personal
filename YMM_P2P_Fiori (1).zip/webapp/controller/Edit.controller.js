jQuery.sap.includeStyleSheet(sap.ui.resource("P2P", "css/style.css"));
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageBox',
	'sap/m/MessagePopover',
	'sap/m/MessageItem',
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/UploadCollectionParameter",
	"sap/m/Dialog",
	"sap/ui/core/routing/History"

], function (Controller, Dialog, MessageBox, MessagePopover, MessageItem, Filter, FilterOperator, UploadCollectionParameter, History) {
	"use strict";
var browser = navigator.userAgent.toLowerCase().indexOf('chrome') > -1 ? 'chrome' : 'other';
	/*	var oMessageTemplate = new MessageItem({

			title: '{message}'
		});

		var oMessagePopover = new MessagePopover({
			items: {
				path: '/',
				template: oMessageTemplate
			}
		});*/
	var oMessageTemplate = new sap.m.MessagePopoverItem({
		type: '{type}',
		title: '{message}',
		description: '{message}'
	});
	var oMessagePopover = new sap.m.MessagePopover({
		items: {
			path: '/',
			template: oMessageTemplate
		}
	});
	oMessagePopover.setModel(sap.ui.getCore().getMessageManager().getMessageModel(), "message");

	return Controller.extend("P2P.controller.Edit", {

		onInit: function () {
			debugger
			this.getRouter("Edit").attachRouteMatched(this.onRouteMatched, this);

			this.url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";
			var BusinessUnit_Model = new sap.ui.model.odata.ODataModel(this.url, true);
			this.getView().setModel(BusinessUnit_Model, "BusinessUnit_Model");

			this.oModelunlockCreate = new sap.ui.model.odata.ODataModel(this.url, true

			);
			sap.ui.getCore().setModel(this.oModelunlockCreate, "oModelunlockCreate");
			//var that=this;
			this.oItemUlr = "/sap/opu/odata/sap/MMPUR_REQ_SSP_MAINTAIN_SRV";

			this.oModelItems = new sap.ui.model.odata.ODataModel(this.oItemUlr, true);
			sap.ui.getCore().setModel(this.oModelItems, "oModelItems");

			this.url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";
			this.FiorilogModel = new sap.ui.model.odata.ODataModel(this.url, true);

			//create URL : http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/PR_HeaderSet
			//   http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/PR_HeaderSet('30000221')/PR_ItemSet

			//Create :   http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/PR_HeaderSet

		},
		handleMessagePopoverPress: function (oEvent) {
			oMessagePopover.toggle(oEvent.getSource());
		},
		onBack: function () {

			/*	var oHistory = History.getInstance();
				var sPreviousHash = oHistory.getPreviousHash();

				if (sPreviousHash !== undefined) {
					window.history.go(-1);
				} else {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					oRouter.navTo("View1", {
						
					});
				}*/

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View1", {

			});

		},
		getRouter: function () {

			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		onChangeExptype: function (oEvt) {
			var oRequestType = this.getView().byId("idReqType").getSelectedKey();
			if (oRequestType === "ZSS") {

				this.getView().byId("idPGrp").getItems()[1].setEnabled(false);
			} else {
				this.getView().byId("idPGrp").getItems()[1].setEnabled(true);

			}

			var oExpType = oEvt.getSource().getSelectedKey();
			if (oExpType == "K" || oExpType == "A") {
				this.getView().byId("catalogTab_coltotal").setVisible(true);
				this.getView().byId("catalogTabcoltotal").setVisible(false);
			} else {
				this.getView().byId("catalogTab_coltotal").setVisible(false);
				this.getView().byId("catalogTabcoltotal").setVisible(true);
			}

		},

		/****************************Bussiness Unit Search help Begin*****************************************/
		handleValueHelpBU1: function (oEvent) {
			this.getView().byId("InputValueBDept").setValue("");
			this.getView().byId("oidBussinessDept").setText("");
			this.getView().byId("idBuApptext").setText("");
			var sInputValue = oEvent.getSource().getValue();
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment(
					"P2P.Fragment.Bussinessunit",
					this
				);
				this.getView().addDependent(this._valueHelpDialog);
			}
			var that = this;
			this.oModelunlockCreate.read("/ZmmshBuSet", null, null, true, function (oData, oRespone) {
				var Data = oData.results;
				var oBumodel = new sap.ui.model.json.JSONModel(Data);
				sap.ui.getCore().byId("oBuFrag").setModel(oBumodel);
				that._valueHelpDialog.open(sInputValue);
			}, function (error) {

			});

		},
		onBuCancel: function () {
			this._valueHelpDialog.destroy(true);
			this._valueHelpDialog = undefined;
		},
		//Bussiness Unit Fragment Confirm Press event Start
		onBuConfirm: function (oEvent) {

			var oSelectedItemBuDes = oEvent.getParameters().selectedItem.mProperties.description;
			this.oBuConfirmtitle = oEvent.getParameters().selectedItem.mProperties.title;
			this.getView().byId("oBussinesidtext").setText(this.oBuConfirmtitle);
			if (oSelectedItemBuDes) {
				var productInput = this.getView().byId("InputValueBU1");
				productInput.setValue(oSelectedItemBuDes);
				this.oBusinessdesc = productInput.mProperties.value;
			}
			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialog.destroy(true);
			this._valueHelpDialog = undefined;
			// this.onBuCancel();

		},
		/* onBuCancel: function (oEvt) {

		this._valueHelpDialog.close();
		this._valueHelpDialog.destroy();

		this._valueHelpDialog = undefined;

		},*/

		//Bussiness Unit Fragment Confirm Press event End
		//Bussiness Unit Fragment Search items Press event Start
		handleBuConfirmSearch_Press: function (oEvt) {

			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oBuFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("ZzbuDesc", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("Zzbu", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		//Bussiness Unit Fragment Search items Press event End
		/****************************Bussiness Unit Search help End*************************************************/
		/****************************Bussiness Department Search help Start*****************************************/
		handleValueHelpBDept: function (oEvent) {

			this.oBuConfirmtitle = this.getView().byId("oBussinesidtext").getText();
			var sInputValue2 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog2) {
				this._valueHelpDialog2 = sap.ui.xmlfragment(
					"P2P.Fragment.BussinessDept",
					this
				);
				this.getView().addDependent(this._valueHelpDialog2);
			}
			var that = this;
			this.oModelunlockCreate.read("/ZMM_DEPT_MASTERSet", null, null, true, function (oData, oRespone) {
				var Data = oData.results;

				var oFIlterResults = Data.filter(function (x) {
					return x.Zzbu == that.oBuConfirmtitle;

				});

				var oBuDeptmodel = new sap.ui.model.json.JSONModel(oFIlterResults);
				sap.ui.getCore().byId("oBuDeptFrag").setModel(oBuDeptmodel);
				that._valueHelpDialog2.open(sInputValue2);
			}, function (error) {

			});

		},
		onBuDeptCancel: function () {
			this._valueHelpDialog2.destroy(true);
			this._valueHelpDialog2 = undefined;
		},
		//Bussiness Unit Fragment Confirm Press event Start
		onBuDeptConfirm: function (oEvent) {
			var oSelectedItem = oEvent.getParameters().selectedItem.mProperties.description;
			//	this.BussDescbj = oEvent.getParameters().selectedItem.mProperties.title;
			var oAppName = oEvent.getParameters().selectedItem.mProperties.info;
			this.getView().byId("idBuApptext").setText(oAppName);
			// this.oBuDeptConfirmtitle = oEvent.getParameters().selectedItem.mProperties.title;
			if (oSelectedItem) {
				var productInputBuDp = this.getView().byId("InputValueBDept");
				productInputBuDp.setValue(oSelectedItem);
				this.oBusinesdeptdesc = productInputBuDp.mProperties.value;

			}
			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialog2.destroy(true);
			this._valueHelpDialog2 = undefined;
		},
		//Bussiness Unit Fragment Confirm Press event End
		//Bussiness Unit Fragment Search Press event Start
		handleBuDepConfSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oBuDeptFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("ZzdeptDesc2", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("ZzdeptCode2", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		//Bussiness Unit Fragment Search Press event End

		/****************************Bussiness Department Search help End*****************************************/
		/**************************** Plant Search help Start*****************************************/
		handleValueHelpPlnt: function (oEvent) {
			/* this.oBuConfirmtitle;*/
			this.getView().byId("InputValueAgrmt").setValue("");
			var sInputValueP = oEvent.getSource().getValue();
			if (!this._valueHelpDialogP) {
				this._valueHelpDialogP = sap.ui.xmlfragment(
					"P2P.Fragment.Plant",
					this
				);
				this.getView().addDependent(this._valueHelpDialogP);
			}
			var that = this;
			this.oModelItems.read("/I_Plant", null, null, true, function (oData, oRespone) {
				var Data = oData.results;

				var oPlantmodl = new sap.ui.model.json.JSONModel(Data);
				sap.ui.getCore().byId("oidPlantFrag").setModel(oPlantmodl);
				that._valueHelpDialogP.open(sInputValueP);
			}, function (error) {

			});

		},
		_handlePlntHelpClose: function () {
			this._valueHelpDialogP.destroy(true);
			this._valueHelpDialogP = undefined;

		},
		//Plant  Fragment Confirm Press event Start
		_handlePlntHelpCnf: function (oEvent) {
			this.oSelectedItemplt = oEvent.getParameters().selectedItem.mProperties.title;
			//  this.oSelectedItemplt = this.getView().byId("InputValuePlnt").getValue();

			var oAppName = oEvent.getParameters().selectedItem.mProperties.description;
			/* this.getView().byId("InputValuePlnt").setText(oAppName);*/
			// this.oBuDeptConfirmtitle = oEvent.getParameters().selectedItem.mProperties.title;
			if (this.oSelectedItemplt) {
				this.productInputBuDp = this.getView().byId("InputValuePlnt");
				this.productInputBuDp.setValue(this.oSelectedItemplt);

			}
			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialogP.destroy(true);
			this._valueHelpDialogP = undefined;

			var that = this;
			that.oSelectedItemplt = this.getView().byId("InputValuePlnt").getValue();
			var oUrlPurgrp = "/zmmsh_categorySet(plant='" + that.oSelectedItemplt + "',category='" + that.oEditRequestCategoryDropdown + "')";

			that.oModelunlockCreate.read(oUrlPurgrp, null, null, true, function (oData, oRespone) {

					var Data = oData;
					var oPurGrpModel = new sap.ui.model.json.JSONModel(Data);

					that.getView().byId("idPuridGrop").setModel(oPurGrpModel);
					var xx = that.getView().byId("idPuridGrop").getModel().getData().Buyer;
					that.xx2 = that.getView().byId("idPuridGrop").getModel().getData().ekgrp;
					that.getView().byId("idPuridGrop").setValue(xx);
				},
				function (error) {

				});

		},
		//Plant  Fragment Confirm Press event End
		//Plant  Fragment Search Press event Start
		_handleValueplntcnfSearch: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oidPlantFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("PlantName", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		//Plant Fragment Search Press event End

		/**************************** Plant Search help End*****************************************/
		/********************************Requisitioner  Search help Start*****************************************/
		handleValueHelpReqr: function (oEvent) {
			var sInputValue3 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog3) {
				this._valueHelpDialog3 = sap.ui.xmlfragment(
					"P2P.Fragment.Requestioner",
					this
				);
				this.getView().addDependent(this._valueHelpDialog3);
			}
			var that = this;
			this.oModelunlockCreate.read("/ZmmshAfnamSet", null, null, true, function (oData, oRespone) {
				var Data = oData.results;
				var oReqmodel = new sap.ui.model.json.JSONModel(Data);
				sap.ui.getCore().byId("oRequisitionerFrag").setModel(oReqmodel);
				that._valueHelpDialog3.open(sInputValue3);
			}, function (error) {

			});

		},
		onReqCancel: function () {
			this._valueHelpDialog3.destroy(true);
			this._valueHelpDialog3 = undefined;

		},
		//Requsitioner Fragment Confirm Press event Start
		onReqConfirm: function (oEvent) {

			this.oSelectedItemReq = oEvent.getParameters().selectedItem.mProperties.title;
			var oManagerName = oEvent.getParameters().selectedItem.mProperties.description;
			this.getView().byId("idManagertext").setText(oManagerName);
			if (this.oSelectedItemReq) {
				var productInputBuDp = this.getView().byId("InputValueRequr");
				productInputBuDp.setValue(this.oSelectedItemReq);

			}
			oEvent.getSource().getBinding("items").filter([]);
		},
		//Requsitioner  Fragment Confirm Press event End
		//Requsitioner  Fragment Search Press event Start
		handleReqConfSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oRequisitionerFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("Afnam", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("ZzassName", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		//Requsitioner Fragment Search Press event End

		/***********************************Requisitioner Search help End*****************************************/
		/****************************Manager Search help Start*****************************************************/
		handleValueHelpManager: function (oEvent) {

			this.oSelectedItemReq;
			var sInputValue4 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog4) {
				this._valueHelpDialog4 = sap.ui.xmlfragment(
					"P2P.Fragment.BussinessDept",
					this
				);
				this.getView().addDependent(this._valueHelpDialog4);
			}
			var that = this;
			this.oModelunlockCreate.read("/ZmmshDeptCode2Set", null, null, true, function (oData, oRespone) {
				var Data = oData.results;

				var oFIlterResults = Data.filter(function (x) {
					return x.ZzassName == this.oSelectedItemReq;

				});

				var oManagermodel = new sap.ui.model.json.JSONModel(oFIlterResults);
				sap.ui.getCore().byId("oManagerFrag").setModel(oManagermodel);
				that._valueHelpDialog4.open(sInputValue4);
			}, function (error) {

			});

		},

		/****************************Aggreement  Search help Start*******************************************/
		handleValueHelpAgrmt: function (oEvent) {

			var oPlnt = this.getView().byId("InputValuePlnt").getValue();
			if (oPlnt == "") {
				sap.m.MessageBox.error("Please select Location");
			} else {

				var sInputValue_ag = oEvent.getSource().getValue();
				if (!this._valueHelpDialog_a) {
					this._valueHelpDialog_a = sap.ui.xmlfragment(
						"P2P.Fragment.Aggrement",
						this
					);
					this.getView().addDependent(this._valueHelpDialog_a);
				}
				var that = this;
				this.oModelunlockCreate.read("/ymm_agreement_headerSet", null, null, true, function (oData, oRespone) {
					var Data = oData.results;

					var oFilteredAgr = Data.filter(function (x) {
						return x.werks == oPlnt;

					});

					var oAggrimodel = new sap.ui.model.json.JSONModel(oFilteredAgr);

					sap.ui.getCore().byId("oidAgrFrag").setModel(oAggrimodel);

					/*for (var i = 0; i < oFilteredAgr.length; i++) {
						if (a.indexOf(oFilteredAgr[i].werks) === -1) {
							a.push(oFilteredAgr[i].werks);
						}
					}*/

					/*	var obj = {};

						for (var i = 0, len = oFilteredAgr.length; i < len; i++)
							obj[oFilteredAgr[i]['ebeln']] = oFilteredAgr[i];

						var oEbeln = new Array();
						for (var key in obj)
							oEbeln.push(obj[key]);
						oAggrimodel.setProperty("/ebeln", oEbeln);
						var oAgrref = oAggrimodel.oData.ebeln;
						sap.ui.getCore().byId("oidAgrFrag").setModel(oAgrref);*/
					that._valueHelpDialog_a.open(sInputValue_ag);
				}, function (error) {

				});
			}

		},
		//Aggrement Fragment Confirm Press event Start
		handleValueHelpAgrCfrm: function (oEvent) {

			this.oAgrmnt = oEvent.getParameters().selectedItem.mProperties.title;
			//var oMatgrpName = oEvent.getParameters().selectedItem.mProperties.description;
			this.getView().byId("InputValueAgrmt").setValue(this.oAgrmnt);
			if (this.oSelectedagrmt) {
				this.Agrmrntvalue = sap.ui.getCore().byId("oidAgrFrag");
				this.Agrmrntvalue.setValue(this.oSelectedagrmt);
			}
			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialog_a.destroy(true);
			this._valueHelpDialog_a = undefined;
		},
		/*	handleValueHelpAgrClose: function (oEvt) {
				this._valueHelpDialog_a.destroy(true);
				this._valueHelpDialog_a = undefined;
			},*/
		//Aggrement   Fragment Confirm Press event End
		//Aggrement   Fragment Search Press event Start
		handleValueHelpAgrSearch: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oidAgrFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("ebeln", sap.ui.model.FilterOperator.Contains, sQuery)

				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		handleValueHelpAgrClose: function () {
			//	this._valueHelpDialog_a.close();
			this._valueHelpDialog_a.destroy(true);
			this._valueHelpDialog_a = undefined;
		},

		/****************************Manager Department Search help End*****************************************/
		/****************************Material Group Search help Start*******************************************/
		handleValueHelpMatGrp: function (oEvent) {

			var sInputValue5 = oEvent.getSource().getValue();
			if (sInputValue5 === "0") {
				//	sap.ui.getCore().byId("idTxt_Glacnt").setText("");
				sap.ui.getCore().byId("idTxt_Glacnt").setValue("");
			}

			if (!this._valueHelpDialog5) {
				this._valueHelpDialog5 = sap.ui.xmlfragment(
					"P2P.Fragment.MaterialGroup",
					this
				);
				this.getView().addDependent(this._valueHelpDialog5);
			}
			var that = this;
			this.oModelunlockCreate.read("/ymm_sh_glSet", null, null, true, function (oData, oRespone) {
				var Data = oData.results;

				/* var oFIlterResults = Data.filter(function (x) {
				return x.ZzdeptCode2 == that.oBuConfirmtitle;

				});*/
				/* oMatGrpmodel*/
				var oMatrpmodel = new sap.ui.model.json.JSONModel(Data);
				sap.ui.getCore().byId("oMatgrpFrag").setModel(oMatrpmodel);

				that._valueHelpDialog5.open(sInputValue5);

			}, function (error) {

			});

		},
		//Material Group Fragment Confirm Press event Start
		onMatGrpConfirm: function (oEvent) {

			this.oSelectedMatgrp = oEvent.getParameters().selectedItem.mProperties.title;
			this.oModelunlockCreate.read("/ymm_sh_glSet(matkl='" + this.oSelectedMatgrp + "')", null, null, true, function (oData, oRespone) {
				var Data = oData;
				var oglrf = Data.sakto;
				this.oZZCategry = Data.WGBEZ60;
				/*	var oGlacnt = sap.ui.getCore().byId("idTxt_Glacnt").setText(oglrf);*/
				var oGlacnt = sap.ui.getCore().byId("idTxt_Glacnt").setValue(oglrf);

			});
			/* var oGlref = that.oMatrpmodel.filter(function (x) {
			return x.matkl == this.oSelectedMatgrp;
			});*/

			var oMatgrpName = oEvent.getParameters().selectedItem.mProperties.description;
			sap.ui.getCore().byId("InputValueMatgrp").setValue(this.oSelectedMatgrp);
			if (this.oSelectedMatgrp) {
				this.productInputBuDp = sap.ui.getCore().byId("InputValueMatgrp");
				this.productInputBuDp.setValue(this.oSelectedMatgrp);
			}
			oEvent.getSource().getBinding("items").filter([]);
		},
		//Material Group  Fragment Confirm Press event End
		//Material Group  Fragment Search Press event Start
		handleMatgrpSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oMatgrpFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("matkl", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("WGBEZ", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		//Material Group Fragment Search Press event End
		/********************************Material Group Search help End*****************************************/
		onMaterGropchange: function (oEvt) {
			var oMatgrpval = sap.ui.getCore().byId("InputValueMatgrp").getValue();
			if (oMatgrpval === "0") {
				//sap.ui.getCore().byId("idTxt_Glacnt").setText("");
				sap.ui.getCore().byId("idTxt_Glacnt").setValue("");
			}

		},
		/***************************Material Code Search help Start*******************************************/
		handleValueHelpMatCode: function (oEvent) {

			/*		var sInputValue11 = oEvent.getSource().getValue();
					if (!this._valueHelpDialog11) {
						this._valueHelpDialog11 = sap.ui.xmlfragment(
							"P2P.Fragment.MaterialCode",
							this
						);
						this.getView().addDependent(this._valueHelpDialog11);
					}
					var that = this;

					var oMatcodel = "/ymm_material_codeSet(matkl='" + this.oSelectedMatgrp + "'," + "werks='" + this.oSelectedItemplt +
						"')/ymm_materialcode_ass_set_nav";
					this.oModelunlockCreate.read(oMatcodel, null, null, true, function (oData, oRespone) {
						var Data1 = oData.results;

						
						if (!Array.isArray(Data1)) {
							Data1 = [oData];
						}

						if (that.oBuyr == "HARDWARE" || that.oBuyr == "SOFTWARE") {

							var Data = Data1.filter(function (x) {
							
								return x.WGBEZ60 == that.oBuyr;
							});

						} else {
							var Data = Data1.filter(function (x) {
							
								return x.WGBEZ60 == that.oBuyr;
							});
							
						}
						var oMatodemodl = new sap.ui.model.json.JSONModel(Data);
						sap.ui.getCore().byId("oMatecodeFrag").setModel(oMatodemodl);
						that._valueHelpDialog11.open(sInputValue11);
					}, function (error) {

					});*/
			var sInputValue11 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog11) {
				this._valueHelpDialog11 = sap.ui.xmlfragment(
					"P2P.Fragment.MaterialCode",
					this
				);
				this.getView().addDependent(this._valueHelpDialog11);
			}
			var that = this;

			var oMatcodel = "/ymm_material_codeSet(werks='" + this.oSelectedItemplt +
				"')/ymm_materialcode_ass_set_nav";
			this.oModelunlockCreate.read(oMatcodel, null, null, true, function (oData, oRespone) {
				var Data = oData.results;

				if (!Array.isArray(Data)) {
					Data = [oData];
				}

				var oMatodemodl = new sap.ui.model.json.JSONModel(Data);
				sap.ui.getCore().byId("oMatecodeFrag").setModel(oMatodemodl);
				that._valueHelpDialog11.open(sInputValue11);
			}, function (error) {

			});

		},
		//Material Code Fragment Confirm Press event Start
		onMatCodConfirm: function (oEvent) {

			this.oSelectedMatcode = oEvent.getParameters().selectedItem.mProperties.title;
			var oMatgrpName = oEvent.getParameters().selectedItem.mProperties.description;
			sap.ui.getCore().byId("InputValueMatCode").setValue(this.oSelectedMatcode);
			if (this.oSelectedMatcode) {
				this.productInputBuDp = sap.ui.getCore().byId("InputValueMatCode");
				this.productInputBuDp.setValue(this.oSelectedMatcode);

			}
			oEvent.getSource().getBinding("items").filter([]);
		},
		//Material Code  Fragment Confirm Press event End
		//Material Code  Fragment Search Press event Start
		handleMatCodSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oMatecodeFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("matnr", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("maktx", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		//Material Code Fragment Search Press event End
		/********************************Material Code Search help End*****************************************/

		/***************************Material Desc Search help Start*******************************************/
		handleValueHelpMatDesc: function (oEvent) {

			/*	var sInputValue1_y = oEvent.getSource().getValue();
			if (!this._valueHelpDialog_y) {
				this._valueHelpDialog_y = sap.ui.xmlfragment(
					"P2P.Fragment.MaterialDescription",
					this
				);
				this.getView().addDependent(this._valueHelpDialog_y);
			}
			var that = this;
			var oSelectedItemplt = this.getView().byId("InputValuePlnt").getValue();
		
			var oMatcodel = "/ymm_material_codeSet(werks='" + oSelectedItemplt +
				"')/ymm_materialcode_ass_set_nav";
			this.oModelunlockCreate.read(oMatcodel, null, null, true, function (oData, oRespone) {
				var Data = oData.results;

				if (!Array.isArray(Data)) {
					Data = [oData];
				}
				var oMatodemodldes = new sap.ui.model.json.JSONModel(Data);
				sap.ui.getCore().byId("oMatDesFrag").setModel(oMatodemodldes);
				that._valueHelpDialog_y.open(sInputValue1_y);
			}, function (error) {
f
			});*/
		//	this.oRequcategryid = this.getView().byId("idPrType").getSelectedItem().getText();
	this.oRequcategryid =	this.getView().byId("idPrType").getValue();
			this.oSlectdAggrement = this.getView().byId("InputValueAgrmt").getValue();
			this.oSelectedItemplt = this.getView().byId("InputValuePlnt").getValue();
			var sInputValue1_y = oEvent.getSource().getValue();
			if (!this._valueHelpDialog_y) {
				this._valueHelpDialog_y = sap.ui.xmlfragment(
					"P2P.Fragment.MaterialDescription",
					this
				);
				this.getView().addDependent(this._valueHelpDialog_y);
			}
			var that = this;

			if (that.Catlogkey === "ZSC") {
				var oMatDesccodeAgr = "/ymm_agreement_headerSet(ebeln='" + this.oSlectdAggrement + "'," + "werks='" + this.oSelectedItemplt +
					"')/ymm_agreement_assc_nav_set";

				this.oModelunlockCreate.read(oMatDesccodeAgr, null, null, true, function (oData, oRespone) {
					var Data1 = oData.results;

					if (!Array.isArray(Data1)) {
						Data1 = [oData];
					}

					var Data = Data1.filter(function (x) {
						return x.req_category == that.oRequcategryid;
					});
					var oMatodemodldes = new sap.ui.model.json.JSONModel(Data);
					sap.ui.getCore().byId("oMatDesFrag").setModel(oMatodemodldes);
					that._valueHelpDialog_y.open(sInputValue1_y);
				}, function (error) {

				});

			} else {

				var oMatcodel = "/ymm_material_codeSet(werks='" + this.oSelectedItemplt +
					"')/ymm_materialcode_ass_set_nav";
				this.oModelunlockCreate.read(oMatcodel, null, null, true, function (oData, oRespone) {
					var Data1 = oData.results;

					if (!Array.isArray(Data1)) {
						Data1 = [oData];
					}
					var Data = Data1.filter(function (x) {
						return x.req_category == that.oRequcategryid;
					});

					/*if ((that.oBuyr == "HARDWARE" || that.oBuyr == "SOFTWARE" || that.oBuyr == "MECHTRONIC" || that.oBuyr == "OFFLOADING")) {

						var Data = Data1.filter(function (x) {
							return x.WGBEZ60 == that.oBuyr;
						});

					} else {
						var Data = Data1.filter(function (x) {
						
							return x.WGBEZ60;
						});

					}*/

					var oMatodemodldes = new sap.ui.model.json.JSONModel(Data);
					sap.ui.getCore().byId("oMatDesFrag").setModel(oMatodemodldes);
					that._valueHelpDialog_y.open(sInputValue1_y);
				}, function (error) {

				});
			}

		},
		//Material Desc Fragment Confirm Press event Start
		onMatdesConfirm: function (oEvent) {
			/*	this.oNewMatcode = oEvent.getParameter("selectedItem").getBindingContext().getObject().matkl;
				this.oNewMatmatnr = oEvent.getParameter("selectedItem").getBindingContext().getObject().matnr.replace(/\b0+/g, '');
				sap.ui.getCore().byId("InputValueMatCode").setValue(this.oNewMatmatnr);
				sap.ui.getCore().byId("InputValueMatgrp").setValue(this.oNewMatcode);

				this.oSelectedMatdes = oEvent.getParameters().selectedItem.mProperties.title;
				var oMatDesc = oEvent.getParameters().selectedItem.mProperties.description;
				sap.ui.getCore().byId("InputValueMatDesc").setValue(this.oSelectedMatdes);
				if (this.oSelectedMatcode) {
					this.productInputBuDp = sap.ui.getCore().byId("InputValueMatDesc");
					this.productInputBuDp.setValue(this.oSelectedMatcode);

				}
				oEvent.getSource().getBinding("items").filter([]);

				this._valueHelpDialog_y.destroy(true);
				this._valueHelpDialog_y = undefined;*/
			if (this.Catlogkey === "ZSC") {

				this.oUntMeasure = oEvent.getParameter("selectedItem").getBindingContext().getObject().UnitOfMeasure;
				this.oCurrncy = oEvent.getParameter("selectedItem").getBindingContext().getObject().Currency;
				this.oPriceval = oEvent.getParameter("selectedItem").getBindingContext().getObject().NETPR;

				sap.ui.getCore().byId("InputValueUnit").setValue(this.oUntMeasure);
				sap.ui.getCore().byId("InputValueCurrency").setValue(this.oCurrncy);
				sap.ui.getCore().byId("idUntprce_Frag").setValue(this.oPriceval);

				this.Aggrementnum = oEvent.getParameter("selectedItem").getBindingContext().getObject().ebeln;
				sap.ui.getCore().byId("AggrmtItemNo").setText(oEvent.getParameter("selectedItem").getBindingContext().getObject().ebelp);

				this.oNewMatcode = oEvent.getParameter("selectedItem").getBindingContext().getObject().matkl;
				this.oSelectedMaterialCode = oEvent.getParameter("selectedItem").getBindingContext().getObject().matnr;
				this.oNewMatmatnr = oEvent.getParameter("selectedItem").getBindingContext().getObject().matnr.replace(/\b0+/g, '');
				sap.ui.getCore().byId("InputValueMatCode").setValue(this.oNewMatmatnr);
				sap.ui.getCore().byId("InputValueMatgrp").setValue(this.oNewMatcode);

				this.oModelunlockCreate.read("/ymm_sh_glSet(matkl='" + this.oNewMatcode + "')", null, null, true, function (oData, oRespone) {
					var Data = oData;
					var oglrf = Data.sakto;
					var oZZCategry = Data.WGBEZ60;
					//	var oGlacnt = sap.ui.getCore().byId("idTxt_Glacnt").setText(oglrf);
					var oGlacnt = sap.ui.getCore().byId("idTxt_Glacnt").setValue(oglrf);
					var zzcatryid = sap.ui.getCore().byId("idzzcategry").setText(oZZCategry);

				});

				this.oModelunlockCreate.read("/ymm_material_codeSet(werks='" + this.oSelectedItemplt + "')/ymm_materialcode_ass_set_nav", null,
					null, true,
					function (oData, oRespone) {
						var Data = oData.results;

					});

				this.oSelectedMatdes = oEvent.getParameters().selectedItem.mProperties.title;
				var oMatDesc = oEvent.getParameters().selectedItem.mProperties.description;

				sap.ui.getCore().byId("InputValueMatDesc").setValue(this.oSelectedMatdes);
				if (this.oSelectedMatdes) {
					this.productInputBuDp = sap.ui.getCore().byId("InputValueMatDesc");
					this.productInputBuDp.setValue(this.oSelectedMatdes);

				}
				oEvent.getSource().getBinding("items").filter([]);

				this._valueHelpDialog_y.destroy(true);
				this._valueHelpDialog_y = undefined;

			} else {

				this.oNewMatcode = oEvent.getParameter("selectedItem").getBindingContext().getObject().matkl;
				this.oSelectedMaterialCode = oEvent.getParameter("selectedItem").getBindingContext().getObject().matnr;
				this.oNewMatmatnr = oEvent.getParameter("selectedItem").getBindingContext().getObject().matnr.replace(/\b0+/g, '');
				sap.ui.getCore().byId("InputValueMatCode").setValue(this.oNewMatmatnr);
				sap.ui.getCore().byId("InputValueMatgrp").setValue(this.oNewMatcode);

				this.oUntMeasure = oEvent.getParameter("selectedItem").getBindingContext().getObject().UnitOfMeasure;
				this.oCurrncy = oEvent.getParameter("selectedItem").getBindingContext().getObject().Currency;
				//	this.oPriceval = oEvent.getParameter("selectedItem").getBindingContext().getObject().NETPR;

				sap.ui.getCore().byId("InputValueUnit").setValue(this.oUntMeasure);
				sap.ui.getCore().byId("InputValueCurrency").setValue(this.oCurrncy);
				//	sap.ui.getCore().byId("idUntprce_Frag").setValue(this.oPriceval);

				this.oModelunlockCreate.read("/ymm_sh_glSet(matkl='" + this.oNewMatcode + "')", null, null, true, function (oData, oRespone) {
					var Data = oData;
					var oglrf = Data.sakto;
					var oZZCategry = Data.WGBEZ60;
					//	var oGlacnt = sap.ui.getCore().byId("idTxt_Glacnt").setText(oglrf);
					var oGlacnt = sap.ui.getCore().byId("idTxt_Glacnt").setValue(oglrf);
					var zzcatryid = sap.ui.getCore().byId("idzzcategry").setText(oZZCategry);

				});

			/*	this.oModelunlockCreate.read("/ymm_material_codeSet(werks='" + this.oSelectedItemplt + "')/ymm_materialcode_ass_set_nav", null,
					null, true,
					function (oData, oRespone) {
						var Data = oData.results;

					});*/

				this.oSelectedMatdes = oEvent.getParameters().selectedItem.mProperties.title;
				var oMatDesc = oEvent.getParameters().selectedItem.mProperties.description;
				sap.ui.getCore().byId("InputValueMatDesc").setValue(this.oSelectedMatdes);
				if (this.oSelectedMatdes) {
					this.productInputBuDp = sap.ui.getCore().byId("InputValueMatDesc");
					this.productInputBuDp.setValue(this.oSelectedMatdes);

				}

				//	sap.ui.getCore().byId("InputValueMatDesc").setValue( oEvent.getParameter("selectedItem").getBindingContext().getObject().maktx);

				oEvent.getSource().getBinding("items").filter([]);
				this._valueHelpDialog_y.destroy(true);
				this._valueHelpDialog_y = undefined;
			}

		},
		//Material Desc  Fragment Confirm Press event End
		//Material Desc  Fragment Search Press event Start
		handleMatdesConfirmSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oMatDesFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("matnr", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("maktx", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		onMatdesCancel: function (oEvt) {
			//	this._valueHelpDialog_y.close();
			this._valueHelpDialog_y.destroy(true);
			this._valueHelpDialog_y = undefined;
		},
		onLivematedesc: function () {

		},

		//Material Code Fragment Search Press event End
		/********************************Material Code Search help End*****************************************/

		/********************************Service Desc Serach help start***********************************************/
		handleValueHelpSerisDesc: function (oEvent) {

			var sInputValue_sd = oEvent.getSource().getValue();
			if (!this._valueHelpDialog_sd) {
				this._valueHelpDialog_sd = sap.ui.xmlfragment(
					"P2P.Fragment.ServiceDescription",
					this
				);
				this.getView().addDependent(this._valueHelpDialog_sd);
			}
			var that = this;
			this.oModelunlockCreate.read("/ymm_service_shSet", null, null, true, function (oData, oRespone) {
				var Data1 = oData.results;
				if (!Array.isArray(Data1)) {
					Data1 = [oData];
				}
				var Data = Data1.filter(function (x) {
				//	return x.req_category == that.getView().byId("idPrType").getSelectedItem().getText();
					return x.req_category == 	that.getView().byId("idPrType").getValue();
				
				});

				var oServDescmodel = new sap.ui.model.json.JSONModel(Data);

				sap.ui.getCore().byId("oServDescFrag").setModel(oServDescmodel);

				that._valueHelpDialog_sd.open(sInputValue_sd);
			}, function (error) {

			});

		},
		//Aggrement Fragment Confirm Press event Start
		_handleValueHelpServDesCnfrm: function (oEvent) {
			var oNewMatcode = oEvent.getParameter("selectedItem").getBindingContext().getObject().matkl;
			this.oSelectedServDesc = oEvent.getParameters().selectedItem.mProperties.title;
			this.oSelectedServNum = oEvent.getParameters().selectedItem.mProperties.description;

			if (this.oSelectedServDesc) {
				this.oSerDec = sap.ui.getCore().byId("InputValueSeriesDesc");
				this.oSerDec.setValue(this.oSelectedServDesc);
			}
			sap.ui.getCore().byId("InputValueMatgrp").setValue(oNewMatcode);

			this.oModelunlockCreate.read("/ymm_sh_glSet(matkl='" + oNewMatcode + "')", null, null, true, function (oData, oRespone) {
				var Data = oData;
				var oglrf = Data.sakto;
				var oZZCategry = Data.WGBEZ60;
				var oGlacnt = sap.ui.getCore().byId("idTxt_Glacnt").setValue(oglrf);
				var zzcatryid = sap.ui.getCore().byId("idzzcategry").setText(oZZCategry);

			});

			sap.ui.getCore().byId("InputValueServcCode").setValue(this.oSelectedServNum);

			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialog_sd.destroy(true);
			this._valueHelpDialog_sd = undefined;
		},
		_handleValueHelpServDesClose: function (oEvt) {
			//this._valueHelpDialog_a.close();
			this._valueHelpDialog_sd.destroy(true);
			this._valueHelpDialog_sd = undefined;
		},
		//Aggrement   Fragment Confirm Press event End
		//Aggrement   Fragment Search Press event Start
		_handleValueHelpServDesSearch: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oServDescFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("ASKTX", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("ASNUM", sap.ui.model.FilterOperator.Contains, sQuery)

				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		/*********************************Service Desc search help end***********************************************/

		/****************************Purchase SPOC Group Search help Start*******************************************/
		handleValueHelpPurG: function (oEvent) {

			var sInputValue13 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog13) {
				this._valueHelpDialog13 = sap.ui.xmlfragment(
					"P2P.Fragment.PurchaseSPOC",
					this
				);
				this.getView().addDependent(this._valueHelpDialog13);
			}
			var that = this;

			/* this.oReqKey = this.getView().byId("idPrType").getSelectedKey();
			var oUrlPurgrp = "/zmmsh_categorySet(ekgrp='" + this.oReqKey + "')";
			this.oModelunlockCreate.read(oUrlPurgrp, null, null, true, function (oData, oRespone) {
			var Data = oData;
			var oReqCategrymodel = new sap.ui.model.json.JSONModel(Data);
			sap.ui.getCore().byId("prchseSpocFrag").setModel(oReqCategrymodel);
			that._valueHelpDialog13.open(sInputValue13);
			}, function (error) {

			});*/

			/* }, function (error) {

			});*/

		},
		//Purchase SPOC Fragment Confirm Press event Start
		onPurchGrpConfirm: function (oEvent) {

			this.oSelectedPucgrp = oEvent.getParameters().selectedItem.mProperties.title;
			var oPucrgrpName = oEvent.getParameters().selectedItem.mProperties.description;
			sap.ui.getCore().byId("InputValuePurG").setValue(this.oSelectedPucgrp);
			if (this.oSelectedPucgrp) {
				this.productInputPurcgrp = this.getView().byId("InputValuePurG");
				this.productInputPurcgrp.setValue(this.oSelectedPucgrp);

			}
			oEvent.getSource().getBinding("items").filter([]);
		},
		//Purchase SPOC  Fragment Confirm Press event End
		//Purchase SPOC   Fragment Search Press event Start
		handlePuchgrpSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("prchseSpocFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("Buyer", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("ekgrp", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		//Purchase SPOC Group Fragment Search Press event End
		/********************************Material Group Search help End*****************************************/

		/*handleValueHelpGLaccount: function(oEvnt)
		{
			
		},*/
		/****************************GLaccount Search help Begin*****************************************/

		handleValueHelpGLaccount: function (oEvent) {
			var sInputValue_Gl = oEvent.getSource().getValue();
			if (!this._valueHelpDialogGl) {
				this._valueHelpDialogGl = sap.ui.xmlfragment(
					"P2P.Fragment.GLAccount",
					this
				);
				this.getView().addDependent(this._valueHelpDialogGl);
			}
			var that = this;
			this.oModelunlockCreate.read("/ymm_sh_glSet", null, null, true, function (oData, oRespone) {
				var Data = oData.results;
				var oGlacntmodel = new sap.ui.model.json.JSONModel(Data);
				sap.ui.getCore().byId("oGLacntFrag").setModel(oGlacntmodel);
				that._valueHelpDialogGl.open(sInputValue_Gl);
			}, function (error) {

			});

		},
		// GLaccount Fragment Confirm Press event Start
		onGLconfirm: function (oEvent) {

			var oSelectedGLacnt = oEvent.getParameters().selectedItem.mProperties.description;
			this.oGLacntConfirmtitle = oEvent.getParameters().selectedItem.mProperties.title;
			var GLacnt = sap.ui.getCore().byId("idTxt_Glacnt");
			GLacnt.setValue(this.oGLacntConfirmtitle);

			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialogGl.destroy(true);
			this._valueHelpDialogGl = undefined;

		},
		onGLCancel: function (oEvent) {
			this._valueHelpDialogGl.destroy(true);
			this._valueHelpDialogGl = undefined;

		},
		// GLaccount Fragment Confirm Press event End
		// GLaccount Fragment Search items Press event Start
		handleGlacntConfirmSearch_Press: function (oEvt) {

			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oGLacntFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("sakto", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("TXT50", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		// GLaccount Fragment Search items Press event End
		/****************************GLaccount Search help End*****************************************/

		/****************************Unit Search help Begin*****************************************/

		handleValueHelpUnit: function (oEvent) {

			var sInputValue6 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog6) {
				this._valueHelpDialog6 = sap.ui.xmlfragment(
					"P2P.Fragment.UnitSearchhelp",
					this
				);
				this.getView().addDependent(this._valueHelpDialog6);
			}
			var that = this;
			this.oModelItems.read("/I_UnitOfMeasure", null, null, true, function (oData, oRespone) {
				var Data = oData.results;
				var oUnitmodel = new sap.ui.model.json.JSONModel(Data);
				sap.ui.getCore().byId("oUnitsFrag").setModel(oUnitmodel);
				that._valueHelpDialog6.open(sInputValue6);
			}, function (error) {

			});

		},
		onUomCancel: function () {
			this._valueHelpDialog6.destroy(true);
			this._valueHelpDialog6 = undefined;

		},
		// Unit Fragment Confirm Press event Start
		oUomConfirm: function (oEvent) {

			var oSelectedUnit = oEvent.getParameters().selectedItem.mProperties.description;
			this.oBuConfirmtitle = oEvent.getParameters().selectedItem.mProperties.title;
			if (this.oBuConfirmtitle) {
				var productUnit = sap.ui.getCore().byId("InputValueUnit");
				productUnit.setValue(this.oBuConfirmtitle);
			}
			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialog6.destroy(true);
			this._valueHelpDialog6 = undefined;

		},
		// Unit Fragment Confirm Press event End
		// Unit Fragment Search items Press event Start
		handleUomConfrmSearch_Press: function (oEvt) {

			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oUnitsFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("UnitOfMeasure", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("UnitOfMeasure_Text", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		// Unit Fragment Search items Press event End
		/****************************Unit Search help End*****************************************/
		/****************************Currency Search help Begin*****************************************/

		handleValueHelpCurrncy: function (oEvent) {
			var sInputValue7 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog7) {
				this._valueHelpDialog7 = sap.ui.xmlfragment(
					"P2P.Fragment.Currency",
					this
				);
				this.getView().addDependent(this._valueHelpDialog7);
			}
			var that = this;
			this.oModelItems.read("/I_Currency", null, null, true, function (oData, oRespone) {
				var Data = oData.results;
				var oCurrecymodel = new sap.ui.model.json.JSONModel(Data);
				sap.ui.getCore().byId("idCurrncyFrag").setModel(oCurrecymodel, "oCurrecymodel2");
				that._valueHelpDialog7.open(sInputValue7);
			}, function (error) {

			});

		},
		// Currency Fragment Confirm Press event Start
		onCurrConfirm: function (oEvent) {

			var oSelectedCurrncy = oEvent.getParameters().selectedItem.mProperties.description;
			this.oCurrncyConfirmtitle = oEvent.getParameters().selectedItem.mProperties.title;
			var Currncy = sap.ui.getCore().byId("InputValueCurrency");
			Currncy.setValue(this.oCurrncyConfirmtitle);

			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialog7.destroy(true);
			this._valueHelpDialog7 = undefined;

		},
		onCurrCancel: function (oEvent) {
			this._valueHelpDialog7.destroy(true);
			this._valueHelpDialog7 = undefined;

		},
		// Currency Fragment Confirm Press event End
		// Currency Fragment Search items Press event Start
		handleCurrncySearch_Press: function (oEvt) {

			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("idCurrncyFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("Currency", sap.ui.model.FilterOperator.Contains, sQuery),
				//	new sap.ui.model.Filter("Currency_Text", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		// Currency Fragment Search items Press event End
		/****************************Currency Search help End*****************************************/
		/****************************WBS Search help Begin*****************************************/

		handleValueHelpWbs: function (oEvent) {
			/*	var sInputValue8 = oEvent.getSource().getValue();
				if (!this._valueHelpDialog8) {
					this._valueHelpDialog8 = sap.ui.xmlfragment(
						"P2P.Fragment.WBS",
						this
					);
					this.getView().addDependent(this._valueHelpDialog8);
				}
				var that = this;
				that.oModelunlockCreate.read("/ymmsh_WBSSet", null, null, true, function (oData, oRespone) {
					var Data = oData.results;
					var oWBSmodel = new sap.ui.model.json.JSONModel(Data);

				
					sap.ui.getCore().byId("oWbsFrag").setModel(oWBSmodel);
					that._valueHelpDialog8.open(sInputValue8);
				}, function (error) {

				});*/
			this.SelectedBuDesc = this.getView().byId("InputValueBU1").getValue();
			this.SelectedoPlant = this.getView().byId("InputValuePlnt").getValue();
			var sInputValue8 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog8) {
				this._valueHelpDialog8 = sap.ui.xmlfragment(
					"P2P.Fragment.WBS",
					this
				);
				this.getView().addDependent(this._valueHelpDialog8);
			}
			var that = this;

			/*   var Wbsurl = "ymm_cc_setSet(WERKS='1000',BU_DESC='A&D')?$expand=ymm_wbs_assc_nav_set"*/
			that.oModelunlockCreate.read("/ymm_cc_setSet(WERKS='" + that.SelectedoPlant + "',BU_DESC='" + that.SelectedBuDesc +
				"')?$expand=ymm_wbs_assc_nav_set", null, null, true,
				function (oData, oRespone) {
					var Data = oData.ymm_wbs_assc_nav_set.results;
					var oWBSmodel = new sap.ui.model.json.JSONModel(Data);
					sap.ui.getCore().byId("oWbsFrag").setModel(oWBSmodel);
					that._valueHelpDialog8.open(sInputValue8);
				},
				function (error) {

				});

		},
		onWbsCancel: function (oEvent) {
			this._valueHelpDialog8.destroy(true);
			this._valueHelpDialog8 = undefined;
		},
		// WBS Fragment Confirm Press event Start
		onWbsConfirm: function (oEvent) {

			var oSelectedWbs = oEvent.getParameters().selectedItem.mProperties.description;
			this.oWbsConfirmtitle = oEvent.getParameters().selectedItem.mProperties.title;
			var oWbs = sap.ui.getCore().byId("oWbscod");
			oWbs.setValue(this.oWbsConfirmtitle);

			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialog8.destroy(true);
			this._valueHelpDialog8 = undefined;

		},
		// WBS Fragment Confirm Press event End
		// WBS Fragment Search items Press event Start
		handleWbsConfirmSearch_Press: function (oEvt) {

			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oWbsFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("PSPNR", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("POST1", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		// WBS Fragment Search items Press event End
		/****************************WBS Search help End*****************************************/
		/****************************Cost center Search help Begin*****************************************/

		handleValueHelpCCode: function (oEvent) {
			this.SelectedBuDesc = this.getView().byId("InputValueBU1").getValue();
			this.SelectedoPlant = this.getView().byId("InputValuePlnt").getValue();
			var sInputValue9 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog9) {
				this._valueHelpDialog9 = sap.ui.xmlfragment(
					"P2P.Fragment.CostCenter",
					this
				);
				this.getView().addDependent(this._valueHelpDialog9);
			}
			var that = this;
			that.oModelunlockCreate.read("/ymm_cc_setSet(WERKS='" + that.SelectedoPlant + "',BU_DESC='" + that.SelectedBuDesc +
				"')?$expand=ymm_cc_nav_association_set", null, null, true,
				function (oData, oRespone) {
					var Data = oData.ymm_cc_nav_association_set.results;
					var oCCmodel = new sap.ui.model.json.JSONModel(Data);

					/* var oWbsmodel = new sap.ui.model.json.JSONModel(Data);*/
					sap.ui.getCore().byId("oCCFrag").setModel(oCCmodel);
					that._valueHelpDialog9.open(sInputValue9);
				},
				function (error) {

				});

		},
		onCCCancel: function () {
			this._valueHelpDialog9.destroy(true);
			this._valueHelpDialog9 = undefined;
		},
		// Cost center Fragment Confirm Press event Start
		onCCConfirm: function (oEvent) {

			var oSelectedoCC = oEvent.getParameters().selectedItem.mProperties.description;
			this.oCCtitle = oEvent.getParameters().selectedItem.mProperties.title;
			var oCC = sap.ui.getCore().byId("oCCCode");
			oCC.setValue(this.oCCtitle);

			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialog9.destroy(true);
			this._valueHelpDialog9 = undefined;

		},
		// Cost center Fragment Confirm Press event End
		// Cost center Fragment Search items Press event Start
		handleCCConfirmSearch_Press: function (oEvt) {

			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oCCFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("kostl", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("LTEXT", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		onQuanity: function (oEvent) {
			/*	var Qty = sap.ui.getCore().byId("idQntyFrag").getValue();
				var Quantiy =
					Qty.replace(/[^\d.]/g, '') // numbers and decimals only
					.replace(/(^[\d]{10})[\d]/g, '$1') // not more than 2 digits at the beginning
					.replace(/(\..*)\./g, '$1') // decimal can't exist more than once
					.replace(/(\.[\d]{3})./g, '$1');
				sap.ui.getCore().byId("idQntyFrag").setValue(Quantiy);*/
			var Qty = sap.ui.getCore().byId("idQntyFrag").getValue();
			var Quantiy =
				Qty.replace(/[^\d.]/g, '') // numbers and decimals only
				.replace(/(^[\d]{10})[\d]/g, '$1') // not more than 2 digits at the beginning
				.replace(/(\..*)\./g, '$1') // decimal can't exist more than once
				.replace(/(\.[\d]{3})./g, '$1');
			sap.ui.getCore().byId("idQntyFrag").setValue(Quantiy);
			this.oQtyId = sap.ui.getCore().byId("idQntyFrag").getValue();
			/*	this.oUntTprice.replace(/[^\d.]/g, '');*/
			this.oUntTprice = sap.ui.getCore().byId("idUntprce_Frag").getValue();

			this.totalval = this.oQtyId * this.oUntTprice;
			sap.ui.getCore().byId("idText_Frag").setText(this.totalval);

		},

		// Cost center Fragment Search items Press event End
		/****************************Cost center Search help End*****************************************/
		onChangeReqcategry: function (oEvent) {
			/*

						var that = this;
						this.oReqKey = this.getView().byId("idPrType").getSelectedKey();
						this.oBuyr = oEvent.getSource()._getSelectedItemText();
						var GhdModel = new sap.ui.model.json.JSONModel();
						var Edtable = true;
						if (this.PendingWith == "PM") {
							Edtable = false;
						}

						switch (this.oBuyr) {
						case "SOFTWARE":

							var SamData = {
								data: [{
										Reviewer: "PR Creator/Manager",

										Status: [

											{
												stats: "Forward",
												statskey: "forward",
												editable: Edtable
											}, {
												stats: "No requirement",
												statskey: "Norequirement",
												editable: Edtable
											}

										],
										Remarks: "",
										Action: [

											{
												Atcn: "Approve",
												ActnKey: "A",
												editable: Edtable
											}, {
												Atcn: "Reject",
												ActnKey: "R",
												editable: Edtable
											}

										]

									}, {
										Reviewer: "SAM",
										Status: [

											{
												stats: "Delivered from Inventory",
												statskey: "Inventory",
												editable: Edtable
											}, {
												stats: "Back to back buy",
												statskey: "Backtobuy",
												editable: Edtable
											}, {
												stats: "Allocated",
												statskey: "Allocated",
												editable: Edtable
											}, {
												stats: "Non Standard",
												statskey: "Non Standard",
												editable: Edtable
											}, {
												stats: "Quote Attached",
												statskey: "Quuote Attached",
												editable: Edtable
											}

										],
										Remarks: "",
										Action: [

											{
												Atcn: "Approve",
												ActnKey: "A",
												editable: Edtable
											}, {
												Atcn: "Reject",
												ActnKey: "R",
												editable: Edtable
											}

										]

									},

									{
										Reviewer: "Buyer",
										Status: [

											{
												stats: "Quote attached",
												statskey: "Quoteattached",
												editable: Edtable
											}, {
												stats: "Requirement Change",
												statskey: "Requirementchange",
												editable: Edtable
											}

										],
										Remarks: "",
										Action: [

											{
												Atcn: "Approve",
												ActnKey: "A",
												editable: Edtable
											}, {
												Atcn: "Reject",
												ActnKey: "R",
												editable: Edtable
											}

										]

									}

								]

							};

							GhdModel.setData(SamData);
							this.getView().byId("oshmTable").setModel(GhdModel);

							break;
						case "HARDWARE":

							var HAMData = {
								data: [{
										Reviewer: "PR Creator/Manager",
										Status: [

											{
												stats: "Forward",
												statskey: "forward",
												editable: Edtable
											}, {
												stats: "No requirement",
												statskey: "Norequirement",
												editable: Edtable
											}

										],
										Remarks: "",
										Action: [

											{
												Atcn: "Approve",
												ActnKey: "A",
												editable: Edtable
											}, {
												Atcn: "Reject",
												ActnKey: "R",
												editable: Edtable
											}

										]

									}, {
										Reviewer: "HAM",
										Status: [

											{
												stats: "Delivered from Inventory",
												statskey: "Inventory",
												editable: Edtable
											}, {
												stats: "Back to back buy",
												statskey: "Backtobuy",
												editable: Edtable
											}, {
												stats: "Allocated",
												statskey: "Allocated",
												editable: Edtable
											}, {
												stats: "Non Standard",
												statskey: "Non Standard",
												editable: Edtable
											}, {
												stats: "Quote Attached",
												statskey: "Quuote Attached",
												editable: Edtable
											}

										],
										Remarks: "",
										Action: [

											{
												Atcn: "Approve",
												ActnKey: "A",
												editable: Edtable
											}, {
												Atcn: "Reject",
												ActnKey: "R",
												editable: Edtable
											}

										]

									},

									{
										Reviewer: "Buyer",
										Status: [

											{
												stats: "Quote attached",
												statskey: "Quoteattached",
												editable: Edtable
											}, {
												stats: "Requirement Change",
												statskey: "Requirementchange",
												editable: Edtable
											}

										],
										Remarks: "",
										Action: [

											{
												Atcn: "Approve",
												ActnKey: "A",
												editable: Edtable
											}, {
												Atcn: "Reject",
												ActnKey: "R",
												editable: Edtable
											}

										]

									}

								]

							};
							GhdModel.setData(HAMData);
							this.getView().byId("oshmTable").setModel(GhdModel);
							break;

						case "IT PROF.SERVICES":
							var buyerData = {
								data: [{
									Reviewer: "PR Creator/Manager",
									Status: [

										{
											stats: "Forward",
											statskey: "forward",
											editable: Edtable
										}, {
											stats: "No requirement",
											statskey: "Norequirement",
											editable: Edtable
										}

									],
									Remarks: "",
									Action: [

										{
											Atcn: "Approve",
											ActnKey: "A",
											editable: Edtable
										}, {
											Atcn: "Reject",
											ActnKey: "R",
											editable: Edtable
										}

									]

								}, {
									Reviewer: "Buyer",
									Status: [

										{
											stats: "Quote attached",
											statskey: "Quoteattached",
											editable: Edtable
										}, {
											stats: "Requirement Change",
											statskey: "Requirementchange",
											editable: Edtable
										}

									],
									Remarks: "",
									Action: [

										{
											Atcn: "Approve",
											ActnKey: "A",
											editable: Edtable
										}, {
											Atcn: "Reject",
											ActnKey: "R",
											editable: Edtable
										}

									]

								}]

							};

							GhdModel.setData(buyerData);
							this.getView().byId("oshmTable").setModel(GhdModel);
							break;

						case "CA INFRA":
							var buyerData = {
								data: [{
									Reviewer: "PR Creator/Manager",
									Status: [

										{
											stats: "Forward",
											statskey: "forward",
											editable: Edtable
										}, {
											stats: "No requirement",
											statskey: "Norequirement",
											editable: Edtable
										}

									],
									Remarks: "",
									Action: [

										{
											Atcn: "Approve",
											ActnKey: "A",
											editable: Edtable
										}, {
											Atcn: "Reject",
											ActnKey: "R",
											editable: Edtable
										}

									]

								}, {
									Reviewer: "Buyer",
									Status: [

										{
											stats: "Quote attached",
											statskey: "Quoteattached",
											editable: Edtable
										}, {
											stats: "Requirement Change",
											statskey: "Requirementchange",
											editable: Edtable
										}

									],
									Remarks: "",
									Action: [

										{
											Atcn: "Approve",
											ActnKey: "A",
											editable: Edtable
										}, {
											Atcn: "Reject",
											ActnKey: "R",
											editable: Edtable
										}

									]

								}]

							};

							GhdModel.setData(buyerData);
							this.getView().byId("oshmTable").setModel(GhdModel);
							break;

						case "MARKETING":
							var buyerData = {
								data: [{
									Reviewer: "PR Creator/Manager",
									Status: [

										{
											stats: "Forward",
											statskey: "forward",
											editable: Edtable
										}, {
											stats: "No requirement",
											statskey: "Norequirement",
											editable: Edtable
										}

									],
									Remarks: "",
									Action: [

										{
											Atcn: "Approve",
											ActnKey: "A",
											editable: Edtable
										}, {
											Atcn: "Reject",
											ActnKey: "R",
											editable: Edtable
										}

									]

								}, {
									Reviewer: "Buyer",
									Status: [

										{
											stats: "Quote attached",
											statskey: "Quoteattached",
											editable: Edtable
										}, {
											stats: "Requirement Change",
											statskey: "Requirementchange",
											editable: Edtable
										}

									],
									Remarks: "",
									Action: [

										{
											Atcn: "Approve",
											ActnKey: "A",
											editable: Edtable
										}, {
											Atcn: "Reject",
											ActnKey: "R",
											editable: Edtable
										}

									]

								}]

							};

							GhdModel.setData(buyerData);
							this.getView().byId("oshmTable").setModel(GhdModel);
							break;
						case "FACILITIES":
							var buyerData = {
								data: [{
									Reviewer: "PR Creator/Manager",
									Status: [

										{
											stats: "Forward",
											statskey: "forward",
											editable: Edtable
										}, {
											stats: "No requirement",
											statskey: "Norequirement",
											editable: Edtable
										}

									],
									Remarks: "",
									Action: [

										{
											Atcn: "Approve",
											ActnKey: "A",
											editable: Edtable
										}, {
											Atcn: "Reject",
											ActnKey: "R",
											editable: Edtable
										}

									]

								}, {
									Reviewer: "Buyer",
									Status: [

										{
											stats: "Quote attached",
											statskey: "Quoteattached",
											editable: Edtable
										}, {
											stats: "Requirement Change",
											statskey: "Requirementchange",
											editable: Edtable
										}

									],
									Remarks: "",
									Action: [

										{
											Atcn: "Approve",
											ActnKey: "A",
											editable: Edtable
										}, {
											Atcn: "Reject",
											ActnKey: "R",
											editable: Edtable
										}

									]

								}]

							};

							GhdModel.setData(buyerData);
							this.getView().byId("oshmTable").setModel(GhdModel);
							break;
						case "MECHATRONICS":
							var buyerData = {
								data: [{
									Reviewer: "PR Creator/Manager",
									Status: [

										{
											stats: "Forward",
											statskey: "forward",
											editable: Edtable
										}, {
											stats: "No requirement",
											statskey: "Norequirement",
											editable: Edtable
										}

									],
									Remarks: "",
									Action: [

										{
											Atcn: "Approve",
											ActnKey: "A",
											editable: Edtable
										}, {
											Atcn: "Reject",
											ActnKey: "R",
											editable: Edtable
										}

									]

								}, {
									Reviewer: "Buyer",
									Status: [

										{
											stats: "Quote attached",
											statskey: "Quoteattached",
											editable: Edtable
										}, {
											stats: "Requirement Change",
											statskey: "Requirementchange",
											editable: Edtable
										}

									],
									Remarks: "",
									Action: [

										{
											Atcn: "Approve",
											ActnKey: "A",
											editable: Edtable
										}, {
											Atcn: "Reject",
											ActnKey: "R",
											editable: Edtable
										}

									]

								}]

							};

							GhdModel.setData(buyerData);
							this.getView().byId("oshmTable").setModel(GhdModel);
							break;

						case "CONTINGENT HIRES":
							var buyerData = {
								data: [{
									Reviewer: "PR Creator/Manager",
									Status: [

										{
											stats: "Forward",
											statskey: "forward",
											editable: Edtable
										}, {
											stats: "No requirement",
											statskey: "Norequirement",
											editable: Edtable
										}

									],
									Remarks: "",
									Action: [

										{
											Atcn: "Approve",
											ActnKey: "A",
											editable: Edtable
										}, {
											Atcn: "Reject",
											ActnKey: "R",
											editable: Edtable
										}

									]

								}, {
									Reviewer: "Buyer",
									Status: [

										{
											stats: "Quote attached",
											statskey: "Quoteattached",
											editable: Edtable
										}, {
											stats: "Requirement Change",
											statskey: "Requirementchange",
											editable: Edtable
										}

									],
									Remarks: "",
									Action: [

										{
											Atcn: "Approve",
											ActnKey: "A",
											editable: Edtable
										}, {
											Atcn: "Reject",
											ActnKey: "R",
											editable: Edtable
										}

									]

								}]

							};

							GhdModel.setData(buyerData);
							this.getView().byId("oshmTable").setModel(GhdModel);
							break;

						case "NON IT PROF SERVICES":
							var buyerData = {
								data: [{
									Reviewer: "PR Creator/Manager",
									Status: [

										{
											stats: "Forward",
											statskey: "forward",
											editable: Edtable
										}, {
											stats: "No requirement",
											statskey: "Norequirement",
											editable: Edtable
										}

									],
									Remarks: "",
									Action: [

										{
											Atcn: "Approve",
											ActnKey: "A",
											editable: Edtable
										}, {
											Atcn: "Reject",
											ActnKey: "R",
											editable: Edtable
										}

									]

								}, {
									Reviewer: "Buyer",
									Status: [

										{
											stats: "Quote attached",
											statskey: "Quoteattached",
											editable: Edtable
										}, {
											stats: "Requirement Change",
											statskey: "Requirementchange",
											editable: Edtable
										}

									],
									Remarks: "",
									Action: [

										{
											Atcn: "Approve",
											ActnKey: "A",
											editable: Edtable
										}, {
											Atcn: "Reject",
											ActnKey: "R",
											editable: Edtable
										}

									]

								}]

							};

							GhdModel.setData(buyerData);
							this.getView().byId("oshmTable").setModel(GhdModel);
							break;

						case "APAC NON IT":
							var buyerData = {
								data: [{
									Reviewer: "PR Creator/Manager",
									Status: [

										{
											stats: "Forward",
											statskey: "forward",
											editable: Edtable
										}, {
											stats: "No requirement",
											statskey: "Norequirement",
											editable: Edtable
										}

									],
									Remarks: "",
									Action: [

										{
											Atcn: "Approve",
											ActnKey: "A",
											editable: Edtable
										}, {
											Atcn: "Reject",
											ActnKey: "R",
											editable: Edtable
										}

									]

								}, {
									Reviewer: "Buyer",
									Status: [

										{
											stats: "Quote attached",
											statskey: "Quoteattached",
											editable: Edtable
										}, {
											stats: "Requirement Change",
											statskey: "Requirementchange",

											editable: Edtable

										}

									],
									Remarks: "",
									Action: [{
											Atcn: "Approve",
											ActnKey: "A",
											editable: Edtable
										}, {
											Atcn: "Reject",
											ActnKey: "R",
											editable: Edtable
										}

									]

								}]

							};

							GhdModel.setData(buyerData);
							this.getView().byId("oshmTable").setModel(GhdModel);
							break;

						}
						var oUrlPurgrp = "/zmmsh_categorySet(ekgrp='" + this.oReqKey + "')";
						this.oModelunlockCreate.read(oUrlPurgrp, null, null, true, function (oData, oRespone) {
								var Data = oData;
								var oPurGrpModel = new sap.ui.model.json.JSONModel(Data);
								that.getView().byId("idPuridGrop").setModel(oPurGrpModel);
								var xx = that.getView().byId("idPuridGrop").getModel().getData().Buyer;
								that.xx2 = that.getView().byId("idPuridGrop").getModel().getData().ekgrp;
								that.getView().byId("idPuridGrop").setValue(xx);
							},
							function (error) {

							});

					*/
			that.oPurchaseGroup();

		},

		onChangeRequest: function () {

			this.Catlogkey = this.getView().byId("idReqType").getSelectedKey();
				var oExpenseType = this.getView().byId("idPGrp").getSelectedKey();
				if (this.Catlogkey != "ZSS") {
				this.getView().byId("idPGrp").getItems()[1].setEnabled(true);

				/* this.getView().byId("idPGrp").setSelectedKey([1]);*/
			} else {
				this.getView().byId("idPGrp").getItems()[1].setEnabled(false);
				//	 this.getView().byId("idPGrp").setSelectedKey([0]);
				//	this.getView().byId("idPGrp").setSelectedItem(0);
				this.getView().byId("idPGrp").setValue("--Please Select Expense Type--");

			}
			if (this.Catlogkey === "ZSC") {
				this.getView().byId("idAgrmnt").setVisible(true);
				this.getView().byId("InputValueAgrmt").setVisible(true);

			} else {
				this.getView().byId("idAgrmnt").setVisible(false);
				this.getView().byId("InputValueAgrmt").setVisible(false);

			}

		},
		onChangeItem: function (oEvt) {

			this.SelectedItemtype = sap.ui.getCore().byId("idItmType")._getSelectedItemText();

			/*	if (this.SelectedItemtype) {
					sap.ui.getCore().byId("InputValueMatCode").setVisible(false);
					sap.ui.getCore().byId("oMatid").setVisible(false);
					sap.ui.getCore().byId("oServiceocde").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(true);

				} else {
					sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
					sap.ui.getCore().byId("oMatid").setVisible(true);
					sap.ui.getCore().byId("oServiceocde").setVisible(false);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);

				}*/

			if (this.SelectedItemtype == "Material") {
				sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
				sap.ui.getCore().byId("oMatid").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
				sap.ui.getCore().byId("oServiceocde").setVisible(false);
				sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(false);
				sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);
				sap.ui.getCore().byId("idItmType").setSelectedKey("");
				sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(false);
				sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(false);

				sap.ui.getCore().byId("oMatedessdeslbl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
				sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatDesc").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
				sap.ui.getCore().byId("InputValueUnit").setEditable(true);
				sap.ui.getCore().byId("InputValueCurrency").setEditable(true);
				sap.ui.getCore().byId("idUntprce_Frag").setEditable(true);

			} else {
				sap.ui.getCore().byId("idItmType").setSelectedKey("9");
				//	sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(false);
				sap.ui.getCore().byId("InputValueMatCode").setVisible(false);
				sap.ui.getCore().byId("oMatid").setVisible(false);
				sap.ui.getCore().byId("oServiceocde").setVisible(true);
				sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(true);
				sap.ui.getCore().byId("oMatedessdeslbl").setVisible(false);
				sap.ui.getCore().byId("InputValueMatgrp").setVisible(false);
				sap.ui.getCore().byId("oMatgrplabl").setVisible(false);
				sap.ui.getCore().byId("InputValueMatDesc").setVisible(false);
				sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(true);
				sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(true);
				sap.ui.getCore().byId("InputValueUnit").setEditable(true);
				sap.ui.getCore().byId("InputValueCurrency").setEditable(true);
				sap.ui.getCore().byId("idUntprce_Frag").setEditable(true);

			}

		},
		/******************************Add Item Fragment Functionality-Begin***************************************/
		onPressItems: function (oEvt) {
			var oPrval = this.getView().byId("InputValuePR").getValue();
			if (oPrval == "" || oPrval == undefined || oPrval == null) {
				this.getView().byId("InputValuePR").setValueState("Error");
				this.getView().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
				this.getView().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

				return;
			} else {
				this.getView().byId("InputValuePR").setValueState("None");
				this.getView().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
			}

			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("P2P.Fragment.Edit_Itemdetails", this);
				this.getView().addDependent(this._oDialog);
			}
			this.Catlogkey = this.getView().byId("idReqType").getSelectedKey();
			sap.ui.getCore().byId("oSavebtnid").setText("Save");
			sap.ui.getCore().byId("InputValueMatCode").setEditable(false);
			sap.ui.getCore().byId("InputValueMatgrp").setEditable(false);

			/*	switch (this.Catlogkey) {
				case "ZSM":
					sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
					sap.ui.getCore().byId("oMatid").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
					sap.ui.getCore().byId("oServiceocde").setVisible(false);
					sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);
					sap.ui.getCore().byId("idItmType").setSelectedKey("");

					break;
				case "ZSS" || "":
					sap.ui.getCore().byId("idItmType").setSelectedKey("9");
					sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(false);
					sap.ui.getCore().byId("InputValueMatCode").setVisible(false);
					sap.ui.getCore().byId("oMatid").setVisible(false);
					sap.ui.getCore().byId("oServiceocde").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(true);

					break;
				case "ZSC":

					break;
				default:

				}*/
			switch (this.Catlogkey) {
			case "ZSM":
				sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
				sap.ui.getCore().byId("oMatid").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
				sap.ui.getCore().byId("oServiceocde").setVisible(false);
				sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(false);
				sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);
				sap.ui.getCore().byId("idItmType").setSelectedKey("");
				sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(false);
				sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(false);

				sap.ui.getCore().byId("oMatedessdeslbl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
				sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatDesc").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
				sap.ui.getCore().byId("InputValueUnit").setEditable(true);
				sap.ui.getCore().byId("InputValueCurrency").setEditable(true);
				sap.ui.getCore().byId("idUntprce_Frag").setEditable(true);
				// oSeriesshrtlbl

				break;
				//	switch (this.Catlogkey) {
			case "ZST":
				sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
				sap.ui.getCore().byId("oMatid").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
				sap.ui.getCore().byId("oServiceocde").setVisible(false);
				sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(false);
				sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);
				sap.ui.getCore().byId("idItmType").setSelectedKey("");
				sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(false);
				sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(false);

				sap.ui.getCore().byId("oMatedessdeslbl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
				sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatDesc").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
				sap.ui.getCore().byId("InputValueUnit").setEditable(true);
				sap.ui.getCore().byId("InputValueCurrency").setEditable(true);
				sap.ui.getCore().byId("idUntprce_Frag").setEditable(true);
				// oSeriesshrtlbl

				break;
			case "ZSS" || "":
				sap.ui.getCore().byId("idItmType").setSelectedKey("9");
				sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(false);
				sap.ui.getCore().byId("InputValueMatCode").setVisible(false);
				sap.ui.getCore().byId("oMatid").setVisible(false);
				sap.ui.getCore().byId("oServiceocde").setVisible(true);
				sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(true);
				sap.ui.getCore().byId("oMatedessdeslbl").setVisible(false);
				sap.ui.getCore().byId("InputValueMatgrp").setVisible(false);
				sap.ui.getCore().byId("oMatgrplabl").setVisible(false);
				sap.ui.getCore().byId("InputValueMatDesc").setVisible(false);
				sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(true);
				sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(true);
				sap.ui.getCore().byId("InputValueUnit").setEditable(true);
				sap.ui.getCore().byId("InputValueCurrency").setEditable(true);
				sap.ui.getCore().byId("idUntprce_Frag").setEditable(true);

				break;
			case "ZSC":
				sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
				sap.ui.getCore().byId("oMatid").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
				sap.ui.getCore().byId("oServiceocde").setVisible(false);
				sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(false);
				sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);
				sap.ui.getCore().byId("idItmType").setSelectedKey("");
				sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(false);
				sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(false);

				sap.ui.getCore().byId("oMatedessdeslbl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
				sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
				sap.ui.getCore().byId("InputValueMatDesc").setVisible(true);
				sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
				sap.ui.getCore().byId("InputValueUnit").setEditable(false);
				sap.ui.getCore().byId("InputValueCurrency").setEditable(false);
				sap.ui.getCore().byId("idUntprce_Frag").setEditable(false);

				/*	sap.ui.getCore().byId("").setVisible(true);
					sap.ui.getCore().byId("").setVisible(true);*/
				break;
			default:

			}

			var oSelectedExpType = this.getView().byId("idPGrp").getSelectedKey();
			switch (oSelectedExpType) {
			case "K" || "A":
				sap.ui.getCore().byId("oCC").setVisible(true);
				sap.ui.getCore().byId("oCCCode").setVisible(true);
				sap.ui.getCore().byId("oWbs").setVisible(false);
				sap.ui.getCore().byId("oWbscod").setVisible(false);
				this.getView().byId("navigationListem_h").setVisible(true);
				break;
			case "P":
				sap.ui.getCore().byId("oCC").setVisible(false);
				sap.ui.getCore().byId("oCCCode").setVisible(false);
				sap.ui.getCore().byId("oWbs").setVisible(true);
				sap.ui.getCore().byId("oWbscod").setVisible(true);
				this.getView().byId("navigationListItem_h").setVisible(true);
				break;
			case "A":
				sap.ui.getCore().byId("oCC").setVisible(true);
				sap.ui.getCore().byId("oCCCode").setVisible(true);
				sap.ui.getCore().byId("oWbs").setVisible(false);
				sap.ui.getCore().byId("oWbscod").setVisible(false);

				break;
			default:

			}

			sap.ui.getCore().byId("oAssetid").setVisible(false);
			sap.ui.getCore().byId("oAssetlablid").setVisible(false);
			sap.ui.getCore().byId("oSalordrlablid").setVisible(false);
			sap.ui.getCore().byId("oSalordrlid").setVisible(false);
			sap.ui.getCore().byId("oTracknolablid").setVisible(false);
			sap.ui.getCore().byId("oTracknoid").setVisible(false);
			sap.ui.getCore().byId("oReasnfrblcklablid").setVisible(false);
			sap.ui.getCore().byId("oReasnfrblckid").setVisible(false);

			if (this.FragItemAsset == "" || this.FragItemAsset == undefined || this.FragItemAsset == null) {
				sap.ui.getCore().byId("oAssetid").setVisible(false);
				sap.ui.getCore().byId("oAssetlablid").setVisible(false);
			} else {
				sap.ui.getCore().byId("oAssetid").setVisible(true);
				sap.ui.getCore().byId("oAssetlablid").setVisible(true);

			}

			if (this.FragItemSalsordrnum == "" || this.FragItemSalsordrnum == undefined || this.FragItemSalsordrnum == null) {
				sap.ui.getCore().byId("oSalordrlablid").setVisible(false);
				sap.ui.getCore().byId("oSalordrlid").setVisible(false);
			} else {
				sap.ui.getCore().byId("oSalordrlablid").setVisible(true);
				sap.ui.getCore().byId("oSalordrlid").setVisible(true);

			}

			if (this.FragItemTracknum == "" || this.FragItemTracknum == undefined || this.FragItemTracknum == null) {
				sap.ui.getCore().byId("oTracknolablid").setVisible(false);
				sap.ui.getCore().byId("oTracknoid").setVisible(false);
			} else {
				sap.ui.getCore().byId("oTracknolablid").setVisible(true);
				sap.ui.getCore().byId("oTracknoid").setVisible(true);

			}

			if (this.FragItemReasnforblk == "" || this.FragItemReasnforblk == undefined || this.FragItemReasnforblk == null) {
				sap.ui.getCore().byId("oReasnfrblcklablid").setVisible(false);
				sap.ui.getCore().byId("oReasnfrblckid").setVisible(false);
			} else {
				sap.ui.getCore().byId("oReasnfrblcklablid").setVisible(true);
				sap.ui.getCore().byId("oReasnfrblckid").setVisible(true);

			}

			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog.open();
		},

		onCloseDialog: function (oEvent) {
			this._oDialog.close();
			this._oDialog.destroy();
			this._oDialog = undefined;
		},
		/******************************Add Item Fragment Functionality-End******************************************/

		onCloseDialog1: function (oEvent) {
			this._valueHelpDialog1.close();
		},
		/****************************Total Value calculation Functionality-Begin*************************************/
		onTotalval: function () {
			var oUnitval = sap.ui.getCore().byId("idUntprce_Frag").getValue();
			var idUnit =
				oUnitval.replace(/[^\d.]/g, '') // numbers and decimals only
				.replace(/(^[\d]{10})[\d]/g, '$1') // not more than 2 digits at the beginning
				.replace(/(\..*)\./g, '$1') // decimal can't exist more than once
				.replace(/(\.[\d]{3})./g, '$1');

			sap.ui.getCore().byId("idUntprce_Frag").setValue(idUnit);

			this.oQtyId = sap.ui.getCore().byId("idQntyFrag").getValue();
			/*	this.oUntTprice.replace(/[^\d.]/g, '');*/
			this.oUntTprice = sap.ui.getCore().byId("idUntprce_Frag").getValue();

			this.totalval1 = this.oQtyId * this.oUntTprice;
			this.totalval = this.totalval1.toFixed(3);
			sap.ui.getCore().byId("idText_Frag").setText(this.totalval);

			/*	this.oQtyId = sap.ui.getCore().byId("idQntyFrag").getValue();
		
				this.oUntTprice = sap.ui.getCore().byId("idUntprce_Frag").getValue();

				this.totalval = this.oQtyId * this.oUntTprice;
				sap.ui.getCore().byId("idText_Frag").setText(this.totalval);*/
		},
		/****************************Total Value calculation Functionality-End*************************************/
		handleDateChange: function (oEvent) {
			var Value = oEvent.getSource().getValue();

			var oDateFormat2 = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "dd/MM/yyyy"
			});
			var Datevalue = oDateFormat2.format(new Date(new Date(Value)));
			oEvent.getSource().setValue(Datevalue);

		},
		/****************************Table Row adding Functionality-Begin*****************************************/
		onAddDialog: function (oEvent) {

			/*	var xxdate1 = sap.ui.getCore().byId("DP2").getValueState();
				if (xxdate1 == "Error") {
					sap.m.MessageBox.error("Please choose from Today date onwards");
				} else if (xxdate1 == "None") {*/
			var EndDate = sap.ui.getCore().byId("DP2").getDateValue();
			if (!EndDate) {
				EndDate = new Date(sap.ui.getCore().byId("DP2").getValue());
			}
			var CurrentDate = new Date();
			if (EndDate < CurrentDate) {
				//	sap.m.MessageBox.error("Date should be greater than or equal to current date");
				sap.ui.getCore().byId("DP2").setValueState("Error");
				sap.m.MessageBox.error("Please choose from Today date onwards");
				return;

			} else {

				sap.ui.getCore().byId("DP2").setValueState("None");

				this.FragItemItemtype = sap.ui.getCore().byId("idItmType").getSelectedKey();
				this.FragItemMatgrp = sap.ui.getCore().byId("InputValueMatgrp").getValue();
				this.FragItemMatCode = sap.ui.getCore().byId("InputValueMatCode").getValue();

				this.FragItemServCode = sap.ui.getCore().byId("InputValueServcCode").getValue();
				this.FragItemSerShortDesc = sap.ui.getCore().byId("InputValueSerisshortDesc").getValue();
				this.FragItemSersDesc = sap.ui.getCore().byId("InputValueSeriesDesc").getValue();

				this.FragItemMatDesc = sap.ui.getCore().byId("InputValueMatDesc").getValue();
				this.FragItemQntyDesc = sap.ui.getCore().byId("idQntyFrag").getValue();
				this.FragItemUnit = sap.ui.getCore().byId("InputValueUnit").getValue();
				this.FragItemCurrncyVal = sap.ui.getCore().byId("InputValueCurrency").getValue();
				this.FragItemUnitVal = sap.ui.getCore().byId("idUntprce_Frag").getValue();
				this.FragItemTotalval = sap.ui.getCore().byId("idText_Frag").getText();
				this.FragItemCoscentr = sap.ui.getCore().byId("oCCCode").getValue();
				this.FragItemWbscntr = sap.ui.getCore().byId("oWbscod").getValue();
				/*	this.FragItemGlact = sap.ui.getCore().byId("idTxt_Glacnt").getText();*/
				this.FragItemGlact = sap.ui.getCore().byId("idTxt_Glacnt").getValue();
				this.FragItemText = sap.ui.getCore().byId("oitemtxt").getValue();
				this.Fragzzcategory = sap.ui.getCore().byId("idzzcategry").getText();
				this.FragItemAsset = sap.ui.getCore().byId("oAssetid").getText();
				this.FragItemSalsordrnum = sap.ui.getCore().byId("oSalordrlid").getText();
				this.FragItemTracknum = sap.ui.getCore().byId("oTracknoid").getText();
				this.FragItemReasnforblk = sap.ui.getCore().byId("oReasnfrblckid").getText();
				this.FragItemAggrmntItemNumbr = sap.ui.getCore().byId("AggrmtItemNo").getText();
				this.FragItemPackNo = sap.ui.getCore().byId("PacknoId").getText();

				sap.ui.getCore().byId("oAssetid").setVisible(false);
				sap.ui.getCore().byId("oAssetlablid").setVisible(false);
				sap.ui.getCore().byId("oSalordrlablid").setVisible(false);
				sap.ui.getCore().byId("oSalordrlid").setVisible(false);
				sap.ui.getCore().byId("oTracknolablid").setVisible(false);
				sap.ui.getCore().byId("oTracknoid").setVisible(false);
				sap.ui.getCore().byId("oReasnfrblcklablid").setVisible(false);
				sap.ui.getCore().byId("oReasnfrblckid").setVisible(false);

				if (this.FragItemAsset == "" || this.FragItemAsset == undefined || this.FragItemAsset == null) {
					sap.ui.getCore().byId("oAssetid").setVisible(false);
					sap.ui.getCore().byId("oAssetlablid").setVisible(false);
				} else {
					sap.ui.getCore().byId("oAssetid").setVisible(true);
					sap.ui.getCore().byId("oAssetlablid").setVisible(true);

				}

				if (this.FragItemSalsordrnum == "" || this.FragItemSalsordrnum == undefined || this.FragItemSalsordrnum == null) {
					sap.ui.getCore().byId("oSalordrlablid").setVisible(false);
					sap.ui.getCore().byId("oSalordrlid").setVisible(false);
				} else {
					sap.ui.getCore().byId("oSalordrlablid").setVisible(true);
					sap.ui.getCore().byId("oSalordrlid").setVisible(true);

				}

				if (this.FragItemTracknum == "" || this.FragItemTracknum == undefined || this.FragItemTracknum == null) {
					sap.ui.getCore().byId("oTracknolablid").setVisible(false);
					sap.ui.getCore().byId("oTracknoid").setVisible(false);
				} else {
					sap.ui.getCore().byId("oTracknolablid").setVisible(true);
					sap.ui.getCore().byId("oTracknoid").setVisible(true);

				}

				if (this.FragItemReasnforblk == "" || this.FragItemReasnforblk == undefined || this.FragItemReasnforblk == null) {
					sap.ui.getCore().byId("oReasnfrblcklablid").setVisible(false);
					sap.ui.getCore().byId("oReasnfrblckid").setVisible(false);
				} else {
					sap.ui.getCore().byId("oReasnfrblcklablid").setVisible(true);
					sap.ui.getCore().byId("oReasnfrblckid").setVisible(true);

				}

				this.FragItemDatex = sap.ui.getCore().byId("DP2").getDateValue();
				if (!this.FragItemDatex) {
					this.FragItemDatex = sap.ui.getCore().byId("DP2").getValue();
				}

				var oDateFormat2 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyy-MM-dd'T'HH:mm:ss"
				});

				this.FragItemDate = oDateFormat2.format(new Date(this.FragItemDatex));

				if (this.FragItemDate == "" || this.FragItemDate == undefined || this.FragItemDate == null || this.FragItemDate ==
					"1970-01-01T05:30:00") {

					sap.ui.getCore().byId("DP2").setValueState("Error");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

					return;
				} else {
					sap.ui.getCore().byId("DP2").setValueState("None");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
				}

				/*	if (this.FragItemText == "" || this.FragItemText == undefined || this.FragItemText == null) {

						sap.ui.getCore().byId("oitemtxt").setValueState("Error");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

						return;
					} else {
						sap.ui.getCore().byId("oitemtxt").setValueState("None");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
					}*/

				if (this.FragItemQntyDesc == "" || this.FragItemQntyDesc == undefined || this.FragItemQntyDesc == null) {

					sap.ui.getCore().byId("idQntyFrag").setValueState("Error");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

					return;
				} else {
					sap.ui.getCore().byId("idQntyFrag").setValueState("None");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
				}
				if (this.FragItemUnit == "" || this.FragItemUnit == undefined || this.FragItemUnit == null) {

					sap.ui.getCore().byId("InputValueUnit").setValueState("Error");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

					return;
				} else {
					sap.ui.getCore().byId("InputValueUnit").setValueState("None");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
				}

				if (this.FragItemCurrncyVal == "" || this.FragItemCurrncyVal == undefined || this.FragItemCurrncyVal == null) {

					sap.ui.getCore().byId("InputValueCurrency").setValueState("Error");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

					return;
				} else {
					sap.ui.getCore().byId("InputValueCurrency").setValueState("None");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
				}

				if (this.FragItemUnitVal == "" || this.FragItemUnitVal == undefined || this.FragItemUnitVal == null) {

					sap.ui.getCore().byId("idUntprce_Frag").setValueState("Error");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

					return;
				} else {
					sap.ui.getCore().byId("idUntprce_Frag").setValueState("None");
					sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
				}

				if (sap.ui.getCore().byId("InputValueSerisshortDesc").getEnabled() == true && (sap.ui.getCore().byId("idItmType").getSelectedKey() ==
						"9")) {
					if (this.FragItemSerShortDesc == "" || this.FragItemSerShortDesc == undefined || this.FragItemSerShortDesc == null) {
						//	sap.m.MessageBox.error("Please select ModelYear");
						sap.ui.getCore().byId("InputValueSerisshortDesc").setValueState("Error");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

						return;
					} else {
						sap.ui.getCore().byId("InputValueSerisshortDesc").setValueState("None");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
					}
				} else {
					if (this.FragItemMatDesc == "" || this.FragItemMatDesc == undefined || this.FragItemMatDesc == null) {

						sap.ui.getCore().byId("InputValueMatDesc").setValueState("Error");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

						return;
					} else {
						sap.ui.getCore().byId("InputValueMatDesc").setValueState("None");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
					}
				}

				/*	if (sap.ui.getCore().byId("oCCCode").getEnabled() == true) {
						if (this.FragItemCoscentr == "" || this.FragItemCoscentr == undefined || this.FragItemCoscentr == null) {
							//	sap.m.MessageBox.error("Please select ModelYear");
							sap.ui.getCore().byId("oCCCode").setValueState("Error");
							sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
							sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

							return;
						} else {
							sap.ui.getCore().byId("oCCCode").setValueState("None");
							sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
						}
					} else {
						if (this.FragItemWbscntr == "" || this.FragItemWbscntr == undefined || this.FragItemWbscntr == null) {

							sap.ui.getCore().byId("oWbscod").setValueState("Error");
							sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
							sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

							return;
						} else {
							sap.ui.getCore().byId("oWbscod").setValueState("None");
							sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
						}
					}*/

				/*	this.FragItemCoscentr = sap.ui.getCore().byId("oCCCode").getValue();
			this.FragItemWbscntr = sap.ui.getCore().byId("oWbscod").getValue();*/

				/* ///////////////// previous code	
			   this.FragItemDatex = sap.ui.getCore().byId("DP2").getValue();
				var a = this.FragItemDatex.split("/");

				this.FragItemDate = new Date(a[1] + "-" + a[0] + "-" + a[2]);
				var oDateFormat2 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyy-MM-dd'T'HH:mm:ss"
				});
		

				this.FragItemDateXa = oDateFormat2.format(new Date(this.FragItemDate));*/

				/* var oFragMatcode = sap.ui.getCore().byId("oMatcode").getValue();
				var oFragMatDesc = sap.ui.getCore().byId("oMatDesc").getValue();
				var oFragMatGrp = sap.ui.getCore().byId("oMatGrp").getValue();
				var oFragQnty = sap.ui.getCore().byId("idQntyFrag").getValue();
				var oFragInputValueUnit = sap.ui.getCore().byId("InputValueUnit").getValue();
				var oFragCurrency = sap.ui.getCore().byId("idCurrency_Frag").getValue();
				var oFragTotalValu = sap.ui.getCore().byId("idText_Frag").getText();
				var oFrUnitprice = sap.ui.getCore().byId("idUntprce_Frag").getValue();
				var oFragWbsc = sap.ui.getCore().byId("oWbscod").getValue();
				var oDp2 = sap.ui.getCore().byId("DP2").getValue();
				var oFragItemtxt = sap.ui.getCore().byId("oitemtxt").getValue();*/

				/* var oMainObj = {};
				oMainObj.oFragMatcodeRef = oFragMatcode;
				oMainObj.oFragMatDescref = oFragMatDesc;
				oMainObj.oFragMatGrpref = oFragMatGrp;
				oMainObj.oFragQntyref = oFragQnty;
				oMainObj.oFragInputValueUnitref = oFragInputValueUnit;
				oMainObj.oFragCurrencyref = oFragCurrency;
				oMainObj.oFragTotalValuref = oFragTotalValu;
				oMainObj.oFrUnitpriceref = oFrUnitprice;
				oMainObj.oFragWbscref = oFragWbsc;
				oMainObj.oDp2ref = oDp2;
				oMainObj.oFragItemtxtref = oFragItemtxt;*/
				if (oEvent.getSource().getText() == "Save") {
					var oMainObj = {};
					oMainObj.Material = this.FragItemMatCode;
					oMainObj.Pstyp = this.FragItemItemtype;

					oMainObj.MatGrp = this.FragItemMatgrp;

					oMainObj.Currency = this.FragItemCurrncyVal;
					oMainObj.TotalPrice = this.FragItemTotalval;

					oMainObj.WbsElem = this.FragItemWbscntr;
					oMainObj.DelivDate = this.FragItemDate;
					oMainObj.CostCtr = this.FragItemCoscentr;
					oMainObj.Sakto = this.FragItemGlact;
					oMainObj.Itemtext = this.FragItemText;
					oMainObj.Zzcategoty = this.Fragzzcategory;
					oMainObj.Anln1 = this.FragItemAsset;
					oMainObj.Vbeln = this.FragItemSalsordrnum;
					oMainObj.Bednr = this.FragItemTracknum;
					oMainObj.Blckd = this.FragItemReasnforblk;
					oMainObj.Ktpnr = this.FragItemAggrmntItemNumbr;
					oMainObj.Packno = this.FragItemPackNo;
					oMainObj.DeleteIndicator = false;
					//this. = sap.ui.getCore().byId("").getText();

					/*	if (oMainObj.Pstyp == 0) {*/
					if (oMainObj.Pstyp != 9) {
						oMainObj.Quantity = this.FragItemQntyDesc;
						oMainObj.Unit = this.FragItemUnit;
						oMainObj.UnitPrice = this.FragItemUnitVal;
						oMainObj.MaterialDesc = this.FragItemMatDesc;
					} else if (oMainObj.Pstyp == 9) {
						oMainObj.Service = this.FragItemServCode;
						oMainObj.MaterialDesc = this.FragItemSerShortDesc;
						oMainObj.ServiceName = this.FragItemSersDesc;
						oMainObj.ServQuan = this.FragItemQntyDesc;
						oMainObj.ServPrice = this.FragItemUnitVal;
						oMainObj.ServUom = this.FragItemUnit;
					}

					// oMainObj.FragItemUnitValref = this.FragItemUnitVal;

					/* oMainObj.oFragItemdate = this.FragItemDate;*/

					/* if (this.getView().byId("ItemTable1").getSelectedItems().length==0) {

					this.EditQnty = sap.ui.getCore().byId("idQntyFrag").setValue(this.oXQnty);
					this.Editmatgrp = sap.ui.getCore().byId("InputValueMatgrp").setValue(this.oXMatgrp);
					var oMAINEDITBJ = {};
					oMAINEDITBJ.oEditQntRef = this.EditQnty;
					oMAINEDITBJ.Editmatgrp = this.Editmatgrp;

					this.SelecteItems.push(oMAINEDITBJ);
					this.getView().byId("ItemTable1").getModel().refresh(true);

					} else {*/
					oMainObj.ExistingPr = "";
					if (!this.getView().byId("ItemTable1").getModel()) {
						var ArrayData = [];
						ArrayData.push(oMainObj);
						var jsonData = new sap.ui.model.json.JSONModel(ArrayData);
						var oCreaTable = this.getView().byId("ItemTable1");
						oCreaTable.setModel(jsonData);
						this.TotalValCal();
					} else if (this.getView().byId("ItemTable1").getModel()) {
						var ItemTableta = this.getView().byId("ItemTable1").getModel().getData();
						if (ItemTableta) {
							ItemTableta.push(oMainObj);
							this.getView().byId("ItemTable1").getModel().refresh(true);
							this.TotalValCal();

							if (ItemTableta.length >= 0) {

								this.getView().byId("InputValueAgrmt").setEnabled(false);
								this.getView().byId("InputValuePlnt").setEnabled(false);
								this.getView().byId("InputValueRequr").setEnabled(false);
								this.getView().byId("InputValueBDept").setEnabled(false);
								this.getView().byId("InputValueBU1").setEnabled(false);
								this.getView().byId("idPrType").setEnabled(false);
								this.getView().byId("idPGrp").setEnabled(false);
								this.getView().byId("idReqType").setEnabled(false);
								this.getView().byId("idInputFileNumber").setEnabled(false);
								this.getView().byId("oUndbChecbx").setEnabled(false);

							} else {

								this.getView().byId("InputValueAgrmt").setEnabled(true);
								this.getView().byId("InputValuePlnt").setEnabled(true);
								this.getView().byId("InputValueRequr").setEnabled(true);
								this.getView().byId("InputValueBDept").setEnabled(true);
								this.getView().byId("InputValueBU1").setEnabled(true);
								this.getView().byId("idPrType").setEnabled(true);
								this.getView().byId("idPGrp").setEnabled(true);
								this.getView().byId("idReqType").setEnabled(true);
								this.getView().byId("idInputFileNumber").setEnabled(true);
								this.getView().byId("oUndbChecbx").setEnabled(true);

							}

						} else {
							var ArrayData2 = [];
							ArrayData2.push(oMainObj);
							var oJsonData = new sap.ui.model.json.JSONModel(ArrayData2);
							var oCreaTable2 = this.getView().byId("ItemTable1");
							oCreaTable2.setModel(oJsonData);
							this.TotalValCal();
							if (oCreaTable2.getModel().getData().length >= "1") {

								this.getView().byId("InputValueAgrmt").setEnabled(false);
								this.getView().byId("InputValuePlnt").setEnabled(false);
								this.getView().byId("InputValueRequr").setEnabled(false);
								this.getView().byId("InputValueBDept").setEnabled(false);
								this.getView().byId("InputValueBU1").setEnabled(false);
								this.getView().byId("idPrType").setEnabled(false);
								this.getView().byId("idPGrp").setEnabled(false);
								this.getView().byId("idReqType").setEnabled(false);
								this.getView().byId("idInputFileNumber").setEnabled(false);
								this.getView().byId("oUndbChecbx").setEnabled(false);
								this.getView().byId("ItemTable1").setMode("None");

							} else {

								this.getView().byId("InputValueAgrmt").setEnabled(true);
								this.getView().byId("InputValuePlnt").setEnabled(true);
								this.getView().byId("InputValueRequr").setEnabled(true);
								this.getView().byId("InputValueBDept").setEnabled(true);
								this.getView().byId("InputValueBU1").setEnabled(true);
								this.getView().byId("idPrType").setEnabled(true);
								this.getView().byId("idPGrp").setEnabled(true);
								this.getView().byId("idReqType").setEnabled(true);
								this.getView().byId("idInputFileNumber").setEnabled(true);
								this.getView().byId("oUndbChecbx").setEnabled(true);
								//	this.getView().byId("ItemTable1").setMode("MultiSelect");

							}

						}
					}
				} else if (oEvent.getSource().getText() == "Update") {
					var selectedItemPath = this.getView().byId("ItemTable1").getSelectedItems()[0].getBindingContext().getPath().substr(1);
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath];
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Pstyp = this.FragItemItemtype;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Material = this.FragItemMatCode;
					//this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].oFragServcodeRef = this.FragItemServCode;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Service = this.FragItemServCode;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].MaterialDesc = this.FragItemSerShortDesc;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].ServiceName = this.FragItemSersDesc;

					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].MaterialDesc = this.FragItemMatDesc;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].MatGrp = this.FragItemMatgrp;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Quantity = this.FragItemQntyDesc;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].UnitPrice = this.FragItemUnitVal;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Currency = this.FragItemCurrncyVal;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].TotalPrice = this.FragItemTotalval;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Zzcategoty = this.Fragzzcategory;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Unit = this.FragItemUnit;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].WbsElem = this.FragItemWbscntr;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].DelivDate = this.FragItemDate;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].CostCtr = this.FragItemCoscentr;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Sakto = this.FragItemGlact;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Itemtext = this.FragItemText;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Anln1 = this.FragItemAsset;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Vbeln = this.FragItemSalsordrnum;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Bednr = this.FragItemTracknum;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Blckd = this.FragItemReasnforblk;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Ktpnr = this.FragItemAggrmntItemNumbr;
					this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Packno = this.FragItemPackNo;

					if (this.FragItemItemtype == 0) {
						this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Quantity = this.FragItemQntyDesc;
						this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Unit = this.FragItemUnit;
						this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].UnitPrice = this.FragItemUnitVal;
						this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].MaterialDesc = this.FragItemMatDesc;
					} else if (this.FragItemItemtype == 9) {
						this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].Service = this.FragItemServCode;
						this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].MaterialDesc = this.FragItemSerShortDesc;
						this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].ServiceName = this.FragItemSersDesc;
						this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].ServQuan = this.FragItemQntyDesc;
						this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].ServPrice = this.FragItemUnitVal;
						this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].ServUom = this.FragItemUnit;
					}

					// this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].DelivDate =  this.FragItemDate;\&nbsp;
					// this.getView().byId("ItemTable1").getModel().getData()[selectedItemPath].FragItemUnitValref = this.FragItemUnitVal;
					this.getView().byId("ItemTable1").getModel().refresh(true);
					this.TotalValCal();
					this.FragItemSersDesc = sap.ui.getCore().byId("InputValueSeriesDesc").setValueState("Error");
					if (this.FragItemSersDesc == "" || this.FragItemSersDesc == undefined || this.FragItemSersDesc == null) {

						sap.ui.getCore().byId("InputValueSeriesDesc").setValueState("Error");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

						return;
					} else {
						sap.ui.getCore().byId("InputValueSeriesDesc").setValueState("None");
						sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
					}

					/*	if (this.FragItemDate == "" || this.FragItemDate == undefined || this.FragItemDate == null || this.FragItemDate ==
							"1970-01-01T05:30:00") {

							sap.ui.getCore().byId("DP2").setValueState("Error");
							sap.ui.getCore().byId("itemdetailsErrMsgStrip").setText("Please select mandatory fields");
							sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", true);

							return;
						} else {
							sap.ui.getCore().byId("DP2").setValueState("None");
							sap.ui.getCore().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
						}*/

				}
				/*}*/
				this._oDialog.close();
				this._oDialog.destroy(true);
				this._oDialog = undefined;
			}
		},
		/****************************Table Row adding Functionality-End*****************************************/
		handleChangedate: function () {
			var EndDate = sap.ui.getCore().byId("DP2").getDateValue();
			if (!EndDate) {
				EndDate = new Date(sap.ui.getCore().byId("DP2").getValue());
			}
			var CurrentDate = new Date();
			if (EndDate < CurrentDate) {
				//	sap.m.MessageBox.error("Date should be greater than or equal to current date");
				sap.ui.getCore().byId("DP2").setValueState("Error");
				sap.m.MessageBox.error("Please choose from Today date onwards");
				return;

			} else {

				sap.ui.getCore().byId("DP2").setValueState("None");
			}
		},
		/****************************Table Row deleting Functionality-Begin***************************************/
		onDelete: function (oEvent) {

			var oTable = this.getView().byId("ItemTable1");
			if (oEvent.getSource().getBindingContext().getObject().ExistingPr == "") {
				var sBindingPath = oEvent.getSource().getBindingContext().getPath();
				var selectedIndex = sBindingPath.split("/")[1];
				var oTableData = oTable.getModel().getData();
				oTableData.splice(selectedIndex, 1);
				oTable.getModel().setData(oTableData);

			} else {
				oEvent.getSource().getBindingContext().getObject().DeleteIndicator = true;
				//		var oTableData = oTable.getModel().getData();
				var sBindingPath = oEvent.getSource().getBindingContext().getPath();
				var selectedIndex = sBindingPath.split("/")[1];
				oTable.getItems()[selectedIndex].setVisible(false);
				//	this.getView().byId("ItemTable1").getItems()[]
			}

			oTable.getModel().refresh(true);
			this.onShmTableUpdate();
			var oTableData = oTable.getModel().getData().filter(function (x) {
				return x.DeleteIndicator == false;
			});
			if (oTableData.length == 0) {

				this.getView().byId("InputValueAgrmt").setEnabled(true);
				this.getView().byId("InputValuePlnt").setEnabled(true);
				this.getView().byId("InputValueRequr").setEnabled(true);
				this.getView().byId("InputValueBDept").setEnabled(true);
				this.getView().byId("InputValueBU1").setEnabled(true);
				this.getView().byId("idPrType").setEnabled(true);
				this.getView().byId("idPGrp").setEnabled(true);
				this.getView().byId("idReqType").setEnabled(true);
				this.getView().byId("idInputFileNumber").setEnabled(true);
				this.getView().byId("oUndbChecbx").setEnabled(true);
				//	this.getView().byId("Procrjust").setEnabled(true);
				//	this.getView().byId("oProJustlabel").setEnabled(true);

			} else if (oTableData.length >= 1) {
				this.getView().byId("InputValueAgrmt").setEnabled(false);
				this.getView().byId("InputValuePlnt").setEnabled(false);
				this.getView().byId("InputValueRequr").setEnabled(false);
				this.getView().byId("InputValueBDept").setEnabled(false);
				this.getView().byId("InputValueBU1").setEnabled(false);
				this.getView().byId("idPrType").setEnabled(false);
				this.getView().byId("idPGrp").setEnabled(false);
				this.getView().byId("idReqType").setEnabled(false);
				this.getView().byId("idInputFileNumber").setEnabled(false);
				this.getView().byId("oUndbChecbx").setEnabled(false);
				//	this.getView().byId("Procrjust").setEnabled(false);

			}

		},
		/****************************Table Row deleting Functionality-End*****************************************/
		onEdit: function (oEvent) {
			var oTabSelecteditem = this.getView().byId("ItemTable1").getModel().getData();
			this.SelecteItems = this.getView().byId("ItemTable1").getSelectedItems();
			if (this.SelecteItems.length > 0 && this.SelecteItems.length == 1) {
				if (!this._oDialog) {
					this._oDialog = sap.ui.xmlfragment("P2P.Fragment.Edit_Itemdetails", this);
					this.getView().addDependent(this._oDialog);

				}
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
				sap.ui.getCore().byId("oSavebtnid").setText("Update");
				sap.ui.getCore().byId("InputValueMatCode").setEditable(false);
				sap.ui.getCore().byId("InputValueMatgrp").setEditable(false);

				this.Catlogkey = this.getView().byId("idReqType").getSelectedKey();
				switch (this.Catlogkey) {
				case "ZSM":
					sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
					sap.ui.getCore().byId("oMatid").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
					sap.ui.getCore().byId("oServiceocde").setVisible(false);
					sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(false);
					sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);
					sap.ui.getCore().byId("idItmType").setSelectedKey("");
					sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(false);
					sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(false);

					sap.ui.getCore().byId("oMatedessdeslbl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
					sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatDesc").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
					sap.ui.getCore().byId("InputValueUnit").setEditable(true);
					sap.ui.getCore().byId("InputValueCurrency").setEditable(true);
					sap.ui.getCore().byId("idUntprce_Frag").setEditable(true);
					// oSeriesshrtlbl

					break;
					//	switch (this.Catlogkey) {
				case "ZST":
					sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
					sap.ui.getCore().byId("oMatid").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
					sap.ui.getCore().byId("oServiceocde").setVisible(false);
					sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(false);
					sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);
					sap.ui.getCore().byId("idItmType").setSelectedKey("");
					sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(false);
					sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(false);

					sap.ui.getCore().byId("oMatedessdeslbl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
					sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatDesc").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
					sap.ui.getCore().byId("InputValueUnit").setEditable(true);
					sap.ui.getCore().byId("InputValueCurrency").setEditable(true);
					sap.ui.getCore().byId("idUntprce_Frag").setEditable(true);
					// oSeriesshrtlbl

					break;
				case "ZSS" || "":
					sap.ui.getCore().byId("idItmType").setSelectedKey("9");
					sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(false);
					sap.ui.getCore().byId("InputValueMatCode").setVisible(false);
					sap.ui.getCore().byId("oMatid").setVisible(false);
					sap.ui.getCore().byId("oServiceocde").setVisible(true);
					sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(true);
					sap.ui.getCore().byId("oMatedessdeslbl").setVisible(false);
					sap.ui.getCore().byId("InputValueMatgrp").setVisible(false);
					sap.ui.getCore().byId("oMatgrplabl").setVisible(false);
					sap.ui.getCore().byId("InputValueMatDesc").setVisible(false);
					sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(true);
					sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(true);
					sap.ui.getCore().byId("InputValueUnit").setEditable(true);
					sap.ui.getCore().byId("InputValueCurrency").setEditable(true);
					sap.ui.getCore().byId("idUntprce_Frag").setEditable(true);

					break;
				case "ZSC":
					sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
					sap.ui.getCore().byId("oMatid").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
					sap.ui.getCore().byId("oServiceocde").setVisible(false);
					sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(false);
					sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);
					sap.ui.getCore().byId("idItmType").setSelectedKey("");
					sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(false);
					sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(false);

					sap.ui.getCore().byId("oMatedessdeslbl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
					sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatDesc").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
					sap.ui.getCore().byId("InputValueUnit").setEditable(false);
					sap.ui.getCore().byId("InputValueCurrency").setEditable(false);
					sap.ui.getCore().byId("idUntprce_Frag").setEditable(false);

					/*	sap.ui.getCore().byId("").setVisible(true);
						sap.ui.getCore().byId("").setVisible(true);*/
					break;
				default:

				}

				var oSelectedExpType = this.getView().byId("idPGrp").getSelectedKey();
				switch (oSelectedExpType) {
				case "K" || "A":
					sap.ui.getCore().byId("oCC").setVisible(true);
					sap.ui.getCore().byId("oCCCode").setVisible(true);
					sap.ui.getCore().byId("oWbs").setVisible(false);
					sap.ui.getCore().byId("oWbscod").setVisible(false);
					this.getView().byId("navigationListem_h").setVisible(true);
					break;
				case "P":
					sap.ui.getCore().byId("oCC").setVisible(false);
					sap.ui.getCore().byId("oCCCode").setVisible(false);
					sap.ui.getCore().byId("oWbs").setVisible(true);
					sap.ui.getCore().byId("oWbscod").setVisible(true);
					this.getView().byId("navigationListItem_h").setVisible(true);
					break;
				case "A":
					sap.ui.getCore().byId("oCC").setVisible(true);
					sap.ui.getCore().byId("oCCCode").setVisible(true);
					sap.ui.getCore().byId("oWbs").setVisible(false);
					sap.ui.getCore().byId("oWbscod").setVisible(false);

					break;
				default:

				}

				var oServiceShrEnable = this.SelecteItems[0].getBindingContext().getObject().ServiceName;
				var oPstypItemtype = this.SelecteItems[0].getBindingContext().getObject().Pstyp;
				if (oServiceShrEnable != "" && oServiceShrEnable != 0 && oServiceShrEnable != undefined || oPstypItemtype != "0") {

					sap.ui.getCore().byId("idItmType").setSelectedKey("9");
					sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(false);
					//	sap.ui.getCore().byId("idItmType").setSelectedKey("9");

					sap.ui.getCore().byId("InputValueMatCode").setVisible(false);
					sap.ui.getCore().byId("oMatid").setVisible(false);
					sap.ui.getCore().byId("oServiceocde").setVisible(true);
					sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(true);
					sap.ui.getCore().byId("oMatedessdeslbl").setVisible(false);
					sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
					sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatDesc").setVisible(false);
					sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(true);
					sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(true);
					sap.ui.getCore().byId("InputValueUnit").setEditable(true);
					sap.ui.getCore().byId("InputValueCurrency").setEditable(true);
					sap.ui.getCore().byId("idUntprce_Frag").setEditable(true);

				} else {

					sap.ui.getCore().byId("InputValueMatCode").setVisible(true);
					sap.ui.getCore().byId("oMatid").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);
					sap.ui.getCore().byId("oServiceocde").setVisible(false);
					sap.ui.getCore().byId("InputValueSeriesDesc").setVisible(false);
					sap.ui.getCore().byId("idItmType").getItems()[0].setEnabled(true);
					//	sap.ui.getCore().byId("idItmType").setSelectedKey("");
					sap.ui.getCore().byId("idItmType").getItems()[1].setEnabled(false);
					sap.ui.getCore().byId("oSeriesshrtlbl").setVisible(false);
					sap.ui.getCore().byId("InputValueSerisshortDesc").setVisible(false);

					sap.ui.getCore().byId("oMatedessdeslbl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatgrp").setVisible(true);
					sap.ui.getCore().byId("oMatgrplabl").setVisible(true);
					sap.ui.getCore().byId("InputValueMatDesc").setVisible(true);
					sap.ui.getCore().byId("InputValueServcCode").setVisible(false);

				}

				/*this.oXMatgrp = this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[0].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[1].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[2].mProperties.text;
				this.oXQnty = this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[3].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[4].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[5].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[6].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[7].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[8].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[9].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[10].mProperties.text;
				this.getView().byId("ItemTable1").getSelectedItems()[0].mAggregations.cells[11].mProperties.text;

				*/
				/* this.EditQnty = sap.ui.getCore().byId("idQntyFrag").setValue(this.oXQnty);
				this.Editmatgrp = sap.ui.getCore().byId("InputValueMatgrp").setValue(this.oXMatgrp);*/
				var SelectedObject = this.getView().byId("ItemTable1").getSelectedItems()[0].getBindingContext().getObject();
				var Editmodel = new sap.ui.model.json.JSONModel(SelectedObject);
				var oEdit_itemtxt = Editmodel.oData.Itemtext;
				sap.ui.getCore().byId("oitemtxt").setValue(oEdit_itemtxt);
				sap.ui.getCore().byId("InputValueMatDesc").setValue(SelectedObject.MaterialDesc);
				sap.ui.getCore().byId("InputValueMatgrp").setValue(SelectedObject.MatGrp);
				sap.ui.getCore().byId("InputValueMatCode").setValue(SelectedObject.Material);
				/* Service F4 fields*/
				sap.ui.getCore().byId("InputValueSeriesDesc").setValue(SelectedObject.ServiceName);
				sap.ui.getCore().byId("InputValueServcCode").setValue(SelectedObject.Service);
				sap.ui.getCore().byId("InputValueSerisshortDesc").setValue(SelectedObject.MaterialDesc);
				/* End Service F4 fields*/
				sap.ui.getCore().byId("InputValueCurrency").setValue(SelectedObject.Currency);
				sap.ui.getCore().byId("idzzcategry").setText(SelectedObject.Zzcategoty);
				sap.ui.getCore().byId("oCCCode").setValue(SelectedObject.CostCtr);
				sap.ui.getCore().byId("oWbscod").setValue(SelectedObject.WbsElem);
				sap.ui.getCore().byId("idTxt_Glacnt").setValue(SelectedObject.Sakto);
				sap.ui.getCore().byId("oAssetid").setText(SelectedObject.Anln1);
				sap.ui.getCore().byId("oSalordrlid").setText(SelectedObject.Vbeln);
				sap.ui.getCore().byId("oTracknoid").setText(SelectedObject.Bednr);
				sap.ui.getCore().byId("oReasnfrblckid").setText(SelectedObject.Blckd);
				sap.ui.getCore().byId("AggrmtItemNo").setText(SelectedObject.Ktpnr);
				sap.ui.getCore().byId("PacknoId").setText(SelectedObject.Packno);

				Editmodel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
				sap.ui.getCore().byId("SimpleFormChange480").setModel(Editmodel);
				//	sap.ui.getCore().byId("oitemtxt").setValue(oEdit_itemtxt);
				sap.ui.getCore().byId("SimpleFormChange480").bindElement("/");

				SelectedObject.Anln1; //Asset

				if (SelectedObject.Anln1 == "" || SelectedObject.Anln1 == undefined || SelectedObject.Anln1 == null) {
					sap.ui.getCore().byId("oAssetid").setVisible(false);
					sap.ui.getCore().byId("oAssetlablid").setVisible(false);
				} else {
					sap.ui.getCore().byId("oAssetid").setVisible(true);
					sap.ui.getCore().byId("oAssetlablid").setVisible(true);
					sap.ui.getCore().byId("oCCCode").setEditable(false);

				}
				SelectedObject.Vbeln; //SalesOrder
				if (SelectedObject.Vbeln == "" || SelectedObject.Vbeln == undefined || SelectedObject.Vbeln == null) {
					sap.ui.getCore().byId("oSalordrlablid").setVisible(false);
					sap.ui.getCore().byId("oSalordrlid").setVisible(false);
				} else {
					sap.ui.getCore().byId("oSalordrlablid").setVisible(true);
					sap.ui.getCore().byId("oSalordrlid").setVisible(true);

				}
				SelectedObject.Bednr; //Tracking Number
				if (SelectedObject.Bednr == "" || SelectedObject.Bednr == undefined || SelectedObject.Bednr == null) {
					sap.ui.getCore().byId("oTracknolablid").setVisible(false);
					sap.ui.getCore().byId("oTracknoid").setVisible(false);
				} else {
					sap.ui.getCore().byId("oTracknolablid").setVisible(true);
					sap.ui.getCore().byId("oTracknoid").setVisible(true);

				}
				SelectedObject.Blckd; // Reason for Bloack
				if (SelectedObject.Blckd == "" || SelectedObject.Blckd == undefined || SelectedObject.Blckd == null) {
					sap.ui.getCore().byId("oReasnfrblcklablid").setVisible(false);
					sap.ui.getCore().byId("oReasnfrblckid").setVisible(false);
				} else {
					sap.ui.getCore().byId("oReasnfrblcklablid").setVisible(true);
					sap.ui.getCore().byId("oReasnfrblckid").setVisible(true);

				}

				/*	var oEdit_itemtxt = Editmodel.oData.Itemtext
					Editmodel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
					sap.ui.getCore().byId("SimpleFormChange480").setModel(Editmodel);
					sap.ui.getCore().byId("oitemtxt").setValue(oEdit_itemtxt);
					sap.ui.getCore().byId("SimpleFormChange480").bindElement("/");*/

				this._oDialog.open();

			} else {
				if (this.SelecteItems.length > 1) {
					sap.m.MessageBox.information("Please select only 'single' item to edit");
				} else {
					if (!this.SelecteItems > 0) {
						sap.m.MessageBox.information("Please select 'single' item to edit");
					}
					sap.m.MessageBox.error("Please 'Add Item' before to edit");
				}
			}

			/* this.sBindingPathEdit = oEvent.oSource.getParent().getBindingContext().getPath();
			this.selectedIndexEdit = this.sBindingPathEdit.split("/")[1];
			this.oSelectedRowobj = oEvent.oSource.getModel().getData()[this.selectedIndexEdit];
			var oFragMatcodeRw = this.oSelectedRowobj.oFragMatcodeRef;
			var oFragMatDescRw = this.oSelectedRowobj.oFragMatDescref;
			var oFragMatGrpRw = this.oSelectedRowobj.oFragMatGrpref;
			var oFragQntyRw = this.oSelectedRowobj.oFragQntyref;
			var oFragInputValueUnitRw = this.oSelectedRowobj.oFragInputValueUnitref;
			var oFragCurrencyRw = this.oSelectedRowobj.oFragCurrencyref;
			var oFragTotalValuRw = this.oSelectedRowobj.oFragTotalValuref;
			var oFrUnitpriceRw = this.oSelectedRowobj.oFrUnitpriceref;
			var oFragWbscRw = this.oSelectedRowobj.oFragWbscref;
			var oDp2Rw = this.oSelectedRowobj.oDp2ref;
			var oFragItemtxtRw = this.oSelectedRowobj.oFragItemtxtref;

			this.oFragMatCodRf = sap.ui.getCore().byId("oMatcodeEdit").setValue(oFragMatcodeRw);
			this.oFragMatDescRf = sap.ui.getCore().byId("oMatDescEdit").setValue(oFragMatDescRw);
			this.oFragMatGrpRf = sap.ui.getCore().byId("oMatGrpEdit").setValue(oFragMatGrpRw);
			this.oFragQntyRf = sap.ui.getCore().byId("idQntyFragEdit").setValue(oFragQntyRw);
			this.oFragInputValueUnitRf = sap.ui.getCore().byId("InputValueUnitEdit").setValue(oFragInputValueUnitRw);
			this.oFragCurrencyRf = sap.ui.getCore().byId("idCurrency_FragEdit").setValue(oFragCurrencyRw);
			this.oFragTotalValuRf = sap.ui.getCore().byId("idText_FragEdit").setText(oFragTotalValuRw);
			this.oFrUnitpriceRf = sap.ui.getCore().byId("idUntprce_FragEdit").setValue(oFrUnitpriceRw);
			this.oFragWbscRf = sap.ui.getCore().byId("oWbscodEdit").setValue(oFragWbscRw);
			this.oDp2Rf = sap.ui.getCore().byId("DP2Edit").setValue(oDp2Rw);
			this.oFragItemtxtRf = sap.ui.getCore().byId("oitemtxtEdit").setValue(oFragItemtxtRw);*/

			/* var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Edit", {

			});*/

			/* if (!this._oDialogEdit) {
			this._oDialogEdit = sap.ui.xmlfragment("P2P.Fragment.Edit", this);
			this.getView().addDependent(this._oDialogEdit);
			}

			this.sBindingPathEdit = oEvent.oSource.getParent().getBindingContext().getPath();
			this.selectedIndexEdit = this.sBindingPathEdit.split("/")[1];
			this.oSelectedRowobj = oEvent.oSource.getModel().getData()[this.selectedIndexEdit];
			var oFragMatcodeRw = this.oSelectedRowobj.oFragMatcodeRef;
			var oFragMatDescRw = this.oSelectedRowobj.oFragMatDescref;
			var oFragMatGrpRw = this.oSelectedRowobj.oFragMatGrpref;
			var oFragQntyRw = this.oSelectedRowobj.oFragQntyref;
			var oFragInputValueUnitRw = this.oSelectedRowobj.oFragInputValueUnitref;
			var oFragCurrencyRw = this.oSelectedRowobj.oFragCurrencyref;
			var oFragTotalValuRw = this.oSelectedRowobj.oFragTotalValuref;
			var oFrUnitpriceRw = this.oSelectedRowobj.oFrUnitpriceref;
			var oFragWbscRw = this.oSelectedRowobj.oFragWbscref;
			var oDp2Rw = this.oSelectedRowobj.oDp2ref;
			var oFragItemtxtRw = this.oSelectedRowobj.oFragItemtxtref;

			this.oFragMatCodRf = sap.ui.getCore().byId("oMatcodeEdit").setValue(oFragMatcodeRw);
			this.oFragMatDescRf = sap.ui.getCore().byId("oMatDescEdit").setValue(oFragMatDescRw);
			this.oFragMatGrpRf = sap.ui.getCore().byId("oMatGrpEdit").setValue(oFragMatGrpRw);
			this.oFragQntyRf = sap.ui.getCore().byId("idQntyFragEdit").setValue(oFragQntyRw);
			this.oFragInputValueUnitRf = sap.ui.getCore().byId("InputValueUnitEdit").setValue(oFragInputValueUnitRw);
			this.oFragCurrencyRf = sap.ui.getCore().byId("idCurrency_FragEdit").setValue(oFragCurrencyRw);
			this.oFragTotalValuRf = sap.ui.getCore().byId("idText_FragEdit").setText(oFragTotalValuRw);
			this.oFrUnitpriceRf = sap.ui.getCore().byId("idUntprce_FragEdit").setValue(oFrUnitpriceRw);
			this.oFragWbscRf = sap.ui.getCore().byId("oWbscodEdit").setValue(oFragWbscRw);
			this.oDp2Rf = sap.ui.getCore().byId("DP2Edit").setValue(oDp2Rw);
			this.oFragItemtxtRf = sap.ui.getCore().byId("oitemtxtEdit").setValue(oFragItemtxtRw);

			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialogEdit);
			this._oDialogEdit.open();*/
		},

		onCloseDialogEdit: function (oEvent) {

			this._oDialog.close();
			this._oDialog.destroy(true);
			this._oDialog = undefined;
		},
		/* onChangePurGroup: function (oEvt) {
		this.oReqKey = this.getView().byId("idPrType").getSelectedKey();
		var oUrlPurgrp = "/zmmsh_categorySet(ekgrp='" + this.oReqKey + "')";
		this.oModelunlockCreate.read(oUrlPurgrp, null, null, true, function (oData, oRespone) {
		var Data = oData;
		var oPurGrpModel = new sap.ui.model.json.JSONModel(Data);

		sap.ui.getCore().setModel(oPurGrpModel, "oPurchaseGrpModl");
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\&nbsp;
		}, function (error) {

		});

		},*/
		onCreate: function (oEvent) {
			//this.getView().byId("idSave").setEnabled(true);
			var PRNumber = this.getView().byId("InputValuePR").getValue();
			var oRequesttype = this.getView().byId("idReqType").getSelectedKey(); // payload name - DocType
			var oExpType = this.getView().byId("idPGrp").getSelectedKey(); // payload name - Zzcategoty
			var oRequestCategry = this.getView().byId("idPrType")._getSelectedItemText(); // payload name - Zzcategoty

			var oBussinessUnit = this.getView().byId("oBussinesidtext").getText(); //Zzbu // this.getView().byId("InputValueBU1").getValue(); //   this.oBuConfirmtitle; // payload name - Zzbu
			//that.getView().byId("oidBussinessDept").getText();
			var oBussinessDept = this.getView().byId("oidBussinessDept").getText(); // this.getView().byId("InputValueBDept").getValue();//this.oBuConfirmtitle; // payload name - ZzdeptCode2
			var oBusDescir = this.getView().byId("InputValueBU1").getValue(); //this.oBusinessdesc;
			var oBusinesDeptDesc = this.getView().byId("InputValueBDept").getValue(); //this.oBusinesdeptdesc;

			var oBussinessAprvname = this.getView().byId("idBuApptext").mProperties.text.split("-")[0];
			var oBussinessAprv = this.getView().byId("idBuApptext").mProperties.text.split("-")[1]; // payload name - ZzaprL3
			var oRequsitioner = this.getView().byId("InputValueRequr").getValue();
			var oHeaderText = this.getView().byId("oTxtvalue").getValue();

			var oManager = this.getView().byId("idManagertext").getText(); // payload name  -ZzassName2
			var oPlant = this.getView().byId("InputValuePlnt").getValue();

			/*	var oBussinessUnit = this.getView().byId("oidBussinessDept").getText();
				var BussinessId = "A&D";
				var PRNumber = this.getView().byId("InputValuePR").getValue();
				var oBussinessDept = "A&D";
				var oBusDescir = "A&D";
				var oBusinesDeptDesc = "DM";
		
				var oBussinessAprvname = this.getView().byId("idBuApptext").mProperties.text.split("-")[0];
				var oBussinessAprv = "RU0895";
				var oRequsitioner = this.getView().byId("InputValueRequr").getValue();
		
				var oManager = this.getView().byId("idManagertext").getText();\&nbsp;
				var oPlant = this.getView().byId("InputValuePlnt").getValue(); */

			var oUnbudgetCheckBoxref = this.getView().byId("oUndbChecbx").getSelected();
			var oUnbudgetCheckBox;
			if (oUnbudgetCheckBoxref == true) {
				oUnbudgetCheckBox = "YY";
			} else if (oUnbudgetCheckBoxref == false) {
				oUnbudgetCheckBox = "ZZ";

			}
			var oAggrmentno = this.getView().byId("InputValueAgrmt").getValue();
			/*if (this.oRequesttype == "ZSM" || this.oRequesttype == "ZSS") {
				var oAggrmentno = "";
				var oAggrItemno = "";

			} else {
				var oAggrmentno = this.getView().byId("InputValueAgrmt").getValue();
				var oAggrItemno =  sap.ui.getCore().byId("AggrmtItemNo").getText();
			}
*/
			var that = this;
			that.getView().byId("idSave").setEnabled(false);
			var Memory = that.memory;
			var oPurcGroup = that.xx2; //this.getView().byId("idPurcGrp").getValue();// payload name  - PurGroup
			// var oProcuJust = this.getView().byId("Procrjust").getValue(); // no need to send
			var oDate = new Date();
			var oPurcretdateref = oDate.setHours(0, 0, 0);
			var oDateFormat5 = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyy-MM-dd'T'HH:mm:ss"
			});

			var oPurcretdate = oDateFormat5.format(new Date(oPurcretdateref));

			var GHDTableData = this.getView().byId("oshmTable").getModel().getData();

			var filteredGHDTableData = GHDTableData.data.filter(function (x) {
				return x.editable == true;
			});
			var ActnKey = "";
			var Remarks = "";
			var statskey = "";
			var ActnKey2 = "";
			var Approver2Action = "";
			if (filteredGHDTableData.length) {
				if ("ActnKey" in filteredGHDTableData[0]) {
					var ActnKey = filteredGHDTableData[0].ActnKey;
				}
				if ("Remarks" in filteredGHDTableData[0]) {
					var Remarks = filteredGHDTableData[0].Remarks;
				}
				if ("statskey" in filteredGHDTableData[0]) {
					var statskey = filteredGHDTableData[0].statskey;
				}
				if ("ActnKey2" in filteredGHDTableData[0]) {
					var ActnKey2 = filteredGHDTableData[0].ActnKey2;
				}
			}

			/*	for (var k = 0; k < GHDTableData.data.length; k++) {
					if (GHDTableData.data[k].editable == true) {
						if (!("statskey" in GHDTableData.data[k]) || GHDTableData.data[k].statskey == undefined || GHDTableData.data[k].statskey == "") {
							this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[1].setValueState("Error");
							sap.m.MessageBox.error("Please enter Status");
							return;
						} else {
							this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[1].setValueState("None");
						}
						if (!("Remarks" in GHDTableData.data[k]) || GHDTableData.data[k].Remarks == undefined || GHDTableData.data[k].Remarks == "") {
							this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[2].setValueState("Error");
							sap.m.MessageBox.error("Please enter Remarks");
							return;
						} else {
							this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[2].setValueState("None");
						}
						if (!("ActnKey" in GHDTableData.data[k]) || GHDTableData.data[k].ActnKey == undefined || GHDTableData.data[k].ActnKey == "") {
							this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[3].setValueState("Error");
							sap.m.MessageBox.error("Please enter Action");
							return;
						} else {
							this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[3].setValueState("None");
						}
						if ((filteredGHDTableData[0].Reviewer == "HAM" && filteredGHDTableData[0].ActnKey == "F") || (filteredGHDTableData[0].Reviewer ==
								"SAM" && filteredGHDTableData[0].ActnKey == "F"))

						{
							if (!("ActnKey2" in GHDTableData.data[k]) || GHDTableData.data[k].ActnKey2 == undefined || GHDTableData.data[k].ActnKey2 == "") {
								this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[4].setValueState("Error");
								sap.m.MessageBox.error("Please select one second level approver");
								return;
							} else {
								this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[4].setValueState("None");
							}

						} else {
							this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[4].setValueState("None");

						}

					} else {

					}
				}*/
			for (var k = 0; k < GHDTableData.data.length; k++) {
				if (GHDTableData.data[k].editable == true) {
					if (!("statskey" in GHDTableData.data[k]) || GHDTableData.data[k].statskey == undefined || GHDTableData.data[k].statskey == "") {
						this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[1].setValueState("Error");
						this.getView().byId("idSave").setEnabled(true);
						sap.m.MessageBox.error("Please enter Status in review tab");
						return;
					} else {
						this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[1].setValueState("None");
						this.getView().byId("idSave").setEnabled(false);
					}
					if (!("Remarks" in GHDTableData.data[k]) || GHDTableData.data[k].Remarks == undefined || GHDTableData.data[k].Remarks == "") {
						this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[2].setValueState("Error");
						this.getView().byId("idSave").setEnabled(true);
						sap.m.MessageBox.error("Please enter Remarks in review tab");
						return;
					} else {
						this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[2].setValueState("None");
						this.getView().byId("idSave").setEnabled(false);
					}
					if (!("ActnKey" in GHDTableData.data[k]) || GHDTableData.data[k].ActnKey == undefined || GHDTableData.data[k].ActnKey == "") {
						this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[3].setValueState("Error");
						this.getView().byId("idSave").setEnabled(true);
						sap.m.MessageBox.error("Please enter Action in review tab");
						return;
					} else {
						this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[3].setValueState("None");
						this.getView().byId("idSave").setEnabled(false);
					}
					if ((filteredGHDTableData[0].Reviewer == "HAM" && filteredGHDTableData[0].ActnKey == "F") || (filteredGHDTableData[0].Reviewer ==
							"SAM" && filteredGHDTableData[0].ActnKey == "F"))

					{
						if (!("ActnKey2" in GHDTableData.data[k]) || GHDTableData.data[k].ActnKey2 == undefined || GHDTableData.data[k].ActnKey2 == "") {
							this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[4].setValueState("Error");
							this.getView().byId("idSave").setEnabled(true);
							sap.m.MessageBox.error("Please select one second level approver in review tab");
							return;
						} else {
							this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[4].setValueState("None");
							this.getView().byId("idSave").setEnabled(false);
						}

					} else {
						this.getView().byId("oshmTable").getAggregation("items")[k].getCells()[4].setValueState("None");
						this.getView().byId("idSave").setEnabled(false);

					}

				} else {
					this.getView().byId("idSave").setEnabled(false);

				}
			}

			/*	
			var Action1 = "",
					Remarks1 = "",
					Status1 = "";
		
		
			if (this.PendingWith == "PM") {
					Action = GHDTableData.data[0].ActnKey;
					Remarks = GHDTableData.data[0].Remarks;
					Status = GHDTableData.data[0].statskey;
				} else if ((this.PendingWith == "SAM" || this.PendingWith == "HAM")) {
					Action = GHDTableData.data[1].ActnKey;
					Remarks = GHDTableData[1].Remarks;
					Status = GHDTableData.data[1].statskey;
				} else if ((this.PendingWith == "BUY")) {
					Action = GHDTableData.data[2].ActnKey;
					Remarks = GHDTableData.data[2].Remarks;
					Status = GHDTableData.data[2].statskey;
				}*/
			/*var	Action	= this.getView().byId("oshmTable").getModel().getData().data[0].ActnKey;
			var Status = this.getView().byId("oshmTable").getModel().getData().data[0].statskey;
			var Remarks = this.getView().byId("oshmTable").getModel().getData().data[0].Remarks;*/

			/* var oResultval = this.getView().byId("navigationt_i").setValue(resultcausekey);*/

			/*-------------------- data from table upladed file what about multiple docs attached???*/

			/*--------------------- data from table end */

			this.oModelunlockCreate.setHeaders({
				"Content-Type": "application/json",
				"X-Requested-With": "XMLHttpRequest",
				"DataServiceVersion": "2.0",
				"Accept": "application/json",
				"Method": "POST"
			});
			var batchUrls = [];
			var headeritem = {};

			/* this.oHeaderItemPR = "";
			this.oHeaderItemType = oRequesttype;

			headeritem.Banfn = this.oHeaderItemPR;
			headeritem.Bsart = this.oHeaderItemType;
			*/
			/* var Arr = [];
			var oTable = this.getView().byId("ItemTable1").getModel().getData();
			for (var i in oTable) {
			Arr.push(this.getView().byId("ItemTable1").getModel().getData()[i]);
			}*/

			var PR_ItemSet = [];
			var oTable = this.getView().byId("ItemTable1").getModel().getData();
			var newData = this.getView().byId("ItemTable1").getModel().getData();
			var itemkeycause = "00";
			for (var a = 0; a < newData.length; a++) {
				if (newData.length > 8) {
					var concatcause = "00";
				} else if (newData.length > 98) {
					var concatcause = "0";
				} else {
					var concatcause = "000";
				}
				var totalcauseitemkey = +itemkeycause + +"10";
				itemkeycause = totalcauseitemkey;
				var resultkey = concatcause + totalcauseitemkey;
				var resultcausekey = concatcause + totalcauseitemkey;

				newData[a].PreqItem = resultkey;
				if (newData[a].CostCtr != "") {
					newData[a].WbsElem = "";
				} else if (newData[a].WbsElem != "") {
					newData[a].CostCtr = "";
				}
			}

			this.getView().byId("ItemTable1").getModel().refresh(true);
			this.TotalValCal();
			for (var i = 0; i < oTable.length; i++) {
				if (oTable[i].ServiceName != "" && oTable[i].Pstyp == "9") {

					var oentry = {
						"Itemtext": oTable[i].Itemtext,
						"PreqNo": PRNumber,
						"DeleteIndicator": oTable[i].DeleteIndicator,
						"Pstyp": oTable[i].Pstyp,
						"Konnr": oAggrmentno,
						//	"Ktpnr": oAggrItemno,
						"Ktpnr": oTable[i].Ktpnr,
						"Bednr": "",
						"PreqItem": oTable[i].PreqItem,
						"DocType": oRequesttype, /// filre up and have to give// doctype last time verey l icham
						"Banpr": "03",
						"PurGroup": oPurcGroup,
						"Blckd": "",
						"PreqDate": oPurcretdate,
						"Blckt": "",
						"Plant": oPlant,
						"AccountType": oExpType,
						"Vbeln": "",
						"CostCtr": oTable[i].CostCtr,
						"Vbelp": "000000",
						"Anln1": oTable[i].Anln1,
						"WbsElem": oTable[i].WbsElem,
						"Requisitioner": oRequsitioner,
						"Headertext": oHeaderText,
						"MaterialDesc": oTable[i].MaterialDesc,
						"Material": oTable[i].Material,
						"MatGrp": oTable[i].MatGrp,
						"Quantity": oTable[i].Quantity,
						"Unit": oTable[i].Unit,
						"DelivDate": new Date(oTable[i].DelivDate), //oTable[i].DelivDate,
						"UnitPrice": oTable[i].UnitPrice,
						"TotalPrice": oTable[i].TotalPrice,
						"Currency": oTable[i].Currency,
						"Zzbu": oBussinessUnit, //Bussiness unit
						"ZzbuDesc": oBusDescir, // Bussiness unit desc
						"ZzdeptCode": oUnbudgetCheckBox, //Bussiness Department
						"ZzdeptDesc": "ZZDLM", //Bussiness Department description
						"ZzdeptCode2": oBussinessDept, //oBussinessUnit
						"ZzdeptDesc2": oBusinesDeptDesc, //Bussiness Dept
						"ZzaprL3": oBussinessAprv, //approver id
						"ZzaprL3Name": oBussinessAprvname, // approver name
						"ZzassName2": oManager, //
						"Sakto": oTable[i].Sakto, //GL account
						"Zzcategoty": oTable[i].Zzcategoty,
						"Memory": Memory,
						"ReqCategory": oRequestCategry,
						"Action": ActnKey,
						"Remarks": Remarks,
						"Status": statskey,
						"Service": oTable[i].Service,
						"ServiceName": oTable[i].ServiceName,
						"Packno": oTable[i].Packno,
						/*	"ServQuan": oTable[i].Quantity,
							"ServPrice": oTable[i].UnitPrice,
							"ServUom": oTable[i].Unit*/
						"ServQuan": oTable[i].ServQuan,
						"ServPrice": oTable[i].ServPrice,
						"ServUom": oTable[i].ServUom,
						"Approver2Id": ActnKey2,
						"Approver2Action": ""

					};
				} else {

					var oentry = {
						"Itemtext": oTable[i].Itemtext,
						"PreqNo": PRNumber,
						"DeleteIndicator": oTable[i].DeleteIndicator,
						"Pstyp": oTable[i].Pstyp,
						"Bednr": "",
						"PreqItem": oTable[i].PreqItem,
						"DocType": oRequesttype, /// filre up and have to give// doctype last time verey l icham
						"Konnr": oAggrmentno,
						//	"Ktpnr": oAggrItemno,
						"Ktpnr": oTable[i].Ktpnr,
						"Banpr": "03",
						"PurGroup": oPurcGroup,
						"Blckd": "",
						"PreqDate": oPurcretdate,
						"Blckt": "",
						"Plant": oPlant,
						"AccountType": oExpType,
						"Vbeln": "",
						"CostCtr": oTable[i].CostCtr,
						"Vbelp": "000000",
						"Anln1": oTable[i].Anln1,
						"WbsElem": oTable[i].WbsElem,
						"Requisitioner": oRequsitioner,
						"Headertext": oHeaderText,
						"MaterialDesc": oTable[i].MaterialDesc,
						"Material": oTable[i].Material,
						"MatGrp": oTable[i].MatGrp,
						"Quantity": oTable[i].Quantity,
						"Unit": oTable[i].Unit,
						"DelivDate": new Date(oTable[i].DelivDate), //oTable[i].DelivDate,
						"UnitPrice": oTable[i].UnitPrice,
						"TotalPrice": oTable[i].TotalPrice,
						"Currency": oTable[i].Currency,
						"Packno": oTable[i].Packno,
						"Zzbu": oBussinessUnit, //Bussiness unit
						"ZzbuDesc": oBusDescir, // Bussiness unit desc
						"ZzdeptCode": oUnbudgetCheckBox, //Bussiness Department
						"ZzdeptDesc": "ZZDLM", //Bussiness Department description
						"ZzdeptCode2": oBussinessDept, //oBussinessUnit
						"ZzdeptDesc2": oBusinesDeptDesc, //Bussiness Dept
						"ZzaprL3": oBussinessAprv, //approver id
						"ZzaprL3Name": oBussinessAprvname, // approver name
						"ZzassName2": oManager, //
						"Sakto": oTable[i].Sakto, //GL account
						"Zzcategoty": oTable[i].Zzcategoty,
						"Memory": Memory,
						"ReqCategory": oRequestCategry,
						"Action": ActnKey,
						"Remarks": Remarks,
						"Status": statskey,
						"Approver2Id": ActnKey2,
						"Approver2Action": ""
							/*"Service": oTable[i].Service,
							"ServiceName": oTable[i].ServiceName,
							"Packno": "",
							"ServQuan": oTable[i].Quantity,
							"ServPrice": oTable[i].UnitPrice,
							"ServUom": oTable[i].Unit
								"ServQuan": "",
							"ServPrice": "",
							"ServUom": ""*/

					};
				}
				PR_ItemSet.push(oentry);
			}
			that.getView().byId("idSave").setEnabled(false);
			/* var PR_ItemSet =[]; resoue type what value have topass*/

			headeritem = {

				"PR_ItemSet": PR_ItemSet,

				"Banfn": "",
				"Bsart": oRequesttype

			};

			var that = this;
			this.oModelunlockCreate.create("/PR_HeaderSet", headeritem, null, function (oData, oResponse) {
					that.getView().byId("ErrorMessages").setVisible(false);
					//that.Attachments(oResponse.data.PR_ItemSet.results[0].PreqNo);
					sap.ui.core.BusyIndicator.hide();

					that.Attachments(PRNumber);
					sap.m.MessageBox.success("Purchase Requisition" + " " + oResponse.data.PR_ItemSet.results[0].PreqNo + " " +
						"has been updated successfully.", {

							actions: ["OK,return to home page", "Stay on this page"],
							onClose: function (oAction) {

								if (oAction == "OK,return to home page") {
									debugger
									that.onNavback();

								}

							}
						});

					that.getView().byId("oshmTable").setVisible(false);
					that.getView().byId("idReqType").setSelectedKey(0);
					that.getView().byId("idPGrp").setSelectedKey("");
					that.getView().byId("idPrType").setSelectedKey("");
					that.getView().byId("InputValueBU1").setValue("");
					that.getView().byId("idBuApptext").setText("");
					that.getView().byId("InputValueBDept").setValue("");
					that.getView().byId("InputValueRequr").setValue("");
					that.getView().byId("idManagertext").setText("");
					that.getView().byId("InputValuePlnt").setValue("");
					that.getView().byId("idPuridGrop").setValue("");
					/*	that.getView().byId("Procrjust").setValue("");*/
					that.getView().byId("InputValueAgrmt").setValue("");
					that.getView().byId("idSave").setEnabled(false);
					that.getView().byId("idReject").setEnabled(false);
					that.getView().byId("oTxtvalue").setValue("");
					that.getView().byId("oCreatedbyId").setText("");
					that.getView().byId("oUndbChecbx").setSelected(false);

					//	that.getView().byId("InputValueAgrmt").setValue("");
					//	that.getView().byId("oUndbChecbx").setSelected(false);

					var ootabl = that.getView().byId("ItemTable1");
					var xxtab = ootabl.getModel().getData();
					while (xxtab.length > 0) {
						{
							xxtab.pop();
						}
					}
					ootabl.getModel().updateBindings();
					that.TotalValCal();
					that.getView().byId("InputValuePR").setValue("");
					var oGhdtableDummyModel = new sap.ui.model.json.JSONModel();
					var oGhdbummyid = that.getView().byId("oshmTable").setModel(oGhdtableDummyModel);
					/*	var oAttachDumModel = new sap.ui.model.json.JSONModel();
						var oAttachDummyid = that.getView().byId("oFIleuploadrid").setModel(oAttachDumModel);*/
					var oRelsestartDumModel = new sap.ui.model.json.JSONModel();
					var oRelsStratDummyid = that.getView().byId("oRelaseStrtTable").setModel(oRelsestartDumModel);
					var model = new sap.ui.model.json.JSONModel([]);
					oMessagePopover.setModel(model);
					//	oMessagePopover.toggle(that.getView().byId("ErrorMessages"));
					var viewModel = new sap.ui.model.json.JSONModel();
					viewModel.setData({
						messagesLength: 0 + ''
					});

					that.getView().setModel(viewModel);
				},
				function (err) { //Error Callback
					that.getView().byId("idSave").setEnabled(true);
					that.getView().byId("ErrorMessages").setVisible(true);

					//////////working code///////////////
					/*	if (err.response.statusCode === 400) {*/
					var obj = JSON.parse(err.response.body);
					that.getView().byId("idSave").setEnabled(true);
					if (obj.error.innererror.errordetails.length > 0) {
						var model = new sap.ui.model.json.JSONModel(obj.error.innererror.errordetails);
						oMessagePopover.setModel(model);
						oMessagePopover.toggle(that.getView().byId("ErrorMessages"));
						var viewModel = new sap.ui.model.json.JSONModel();
						viewModel.setData({
							messagesLength: obj.error.innererror.errordetails.length + ''
						});

						that.getView().setModel(viewModel);

					} else {
						var model = new sap.ui.model.json.JSONModel([]);
						oMessagePopover.setModel(model);
						//	oMessagePopover.toggle(that.getView().byId("ErrorMessages"));
						var viewModel = new sap.ui.model.json.JSONModel();
						viewModel.setData({
							messagesLength: 0 + ''
						});

						that.getView().setModel(viewModel);
						sap.m.MessageBox.error(obj.error.message.value);
					}

				});
			/*	function (err) { //Error Callback
					if (err.response) {
						if (err.response.statusCode === 400) {
							var obj = JSON.parse(err.response.body);
							var model = new sap.ui.model.json.JSONModel(obj.error.innererror.errordetails);
							oMessagePopover.setModel(model);
							oMessagePopover.toggle(that.getView().byId("ErrorMessages"));
							var viewModel = new sap.ui.model.json.JSONModel();
							viewModel.setData({
								messagesLength: obj.error.innererror.errordetails.length + ''
							});

							that.getView().setModel(viewModel);
						}
					}
				});*/

		},
		/*	handleMessagePopoverPress: function (oEvent) {
				oMessagePopover.toggle(oEvent.getSource());
			},*/
		onSaveEdit: function (oEvent) {

			var oEditObj = {};
			oEditObj.oEditMatcod = this.oFragMatCodRf;
			oEditObj.oEditMatDesc = this.oFragMatDescRf;
			oEditObj.oEditMatGr = this.oFragMatGrpRf;
			oEditObj.oEditQnty = this.oFragQntyRf;
			oEditObj.oEditInpuValUnt = this.oFragInputValueUnitRf;
			oEditObj.oEditCurncy = this.oFragCurrencyRf;
			oEditObj.oEditTotalval = this.oFragTotalValuRf;
			oEditObj.oEditUnitprice = this.oFrUnitpriceRf;
			oEditObj.oEditWbsc = this.oFragWbscRf;
			oEditObj.oEditoDp2 = this.oDp2Rf;
			oEditObj.oEditItemtxt = this.oFragItemtxtRf;
			var oTableEdit2 = this.getView().byId("ItemTable1").getModel().getData()[this.selectedIndexEdit];
			oTableEdit2.oFragMatcodeRef = oEditObj.oEditMatcod;
			this.getView().byId("ItemTable1").getModel().refresh(true);
			this.TotalValCal();

		},

		onCopy: function (oEvt) {
			var oTablecpy = this.getView().byId("ItemTable1").getModel().getData();
			/* var oCopyItmObj = {};
			oCopyItmObj.oCopyMatcodeRef = this.FragItemMatCode;
			oCopyItmObj.oCopyServcodeRef = this.FragItemServCode;
			oCopyItmObj.oCopyMatDescref = this.FragItemMatDesc;
			oCopyItmObj.oCopyMatGrpref = this.FragItemMatgrp;
			oCopyItmObj.oCopyQntyref = this.FragItemQntyDesc;
			oCopyItmObj.oCopyInputValueUnitref = this.FragItemUnitVal;
			oCopyItmObj.oCopyCurrencyref = this.FragItemCurrncyVal;
			oCopyItmObj.oCopyTotalValuref = this.FragItemTotalval;
			oCopyItmObj.oCopyUnitpriceref = this.FragItemUnit;
			oCopyItmObj.oCopyWbscref = this.FragItemWbscntr;
			oCopyItmObj.oCopyDp2ref = this.FragItemDate;
			oCopyItmObj.oCopyItemCostCentr = this.FragItemCoscentr;
			oCopyItmObj.oCopyItemtextref = this.FragItemText;
			oCopyItmObj.CopyItemUnitValref = this.FragItemUnitVal;*/

			/* var ItemTableta = this.getView().byId("ItemTable1").getModel().getData();*/
			var SelecteItems = this.getView().byId("ItemTable1").getSelectedItems();
			if (!SelecteItems.length) {
				sap.m.MessageBox.error("Please Select record to copy");
			}
			/*if (oTablecpy) {
			oTablecpy.push(oMainObj);
			this.getView().byId("ItemTable1").getModel().refresh(true);
			}*/
			else {
				this.getView().byId("ItemTable1").removeSelections(true);
				for (var i = 0; i < SelecteItems.length; i++) {
					var obj = {};
					obj.MatGrp = SelecteItems[i].getBindingContext().getObject().MatGrp;
					obj.Currency = SelecteItems[i].getBindingContext().getObject().Currency;
					obj.Material = SelecteItems[i].getBindingContext().getObject().Material;
					obj.MaterialDesc = SelecteItems[i].getBindingContext().getObject().MaterialDesc;

					obj.Service = SelecteItems[i].getBindingContext().getObject().Service;
					obj.MaterialDesc = SelecteItems[i].getBindingContext().getObject().MaterialDesc;
					obj.ServiceName = SelecteItems[i].getBindingContext().getObject().ServiceName;
					obj.ServQuan = SelecteItems[i].getBindingContext().getObject().ServQuan;
					obj.ServPrice = SelecteItems[i].getBindingContext().getObject().ServPrice;
					obj.ServUom = SelecteItems[i].getBindingContext().getObject().ServUom;
					obj.Pstyp = SelecteItems[i].getBindingContext().getObject().Pstyp;

					obj.Quantity = SelecteItems[i].getBindingContext().getObject().Quantity;
					obj.Unit = SelecteItems[i].getBindingContext().getObject().Unit;
					obj.UnitPrice = SelecteItems[i].getBindingContext().getObject().UnitPrice;
					obj.TotalPrice = SelecteItems[i].getBindingContext().getObject().TotalPrice;
					obj.CostCtr = SelecteItems[i].getBindingContext().getObject().CostCtr;
					obj.WbsElem = SelecteItems[i].getBindingContext().getObject().WbsElem;
					obj.DelivDate = SelecteItems[i].getBindingContext().getObject().DelivDate;
					obj.Sakto = SelecteItems[i].getBindingContext().getObject().Sakto;
					obj.Zzcategoty = SelecteItems[i].getBindingContext().getObject().Zzcategoty;
					obj.Anln1 = SelecteItems[i].getBindingContext().getObject().Anln1;
					obj.Vbeln = SelecteItems[i].getBindingContext().getObject().Vbeln;
					obj.Bednr = SelecteItems[i].getBindingContext().getObject().Bednr;
					obj.Blckd = SelecteItems[i].getBindingContext().getObject().Blckd;
					obj.Itemtext = SelecteItems[i].getBindingContext().getObject().Itemtext;
					obj.Ktpnr = SelecteItems[i].getBindingContext().getObject().Ktpnr;
					obj.Packno = "";
					obj.ExistingPr = "";
					obj.DeleteIndicator = SelecteItems[i].getBindingContext().getObject().DeleteIndicator;
					//oMainObj.Anln1 = this.FragItemAsset
					//	oMainObj.Vbeln = this.FragItemSalsordrnum
					//	oMainObj.Bednr = this.FragItemTracknum
					//	oMainObj.Blckd = this.FragItemReasnforblk

					this.getView().byId("ItemTable1").getModel().getData().push(obj);
				}

				this.getView().byId("ItemTable1").getModel().refresh(true);
				this.TotalValCal();
			}

		},

		/** cloase event for frag
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf P2P.view.Detailed
		 */
		// onBeforeRendering: function() {
		//
		// },

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf P2P.view.Detailed
		 */
		oTab: function () {
			
			var that = this;

			that.getView().byId("idIconTabBarNoIcons").setSelectedKey("oReviewtab");

		},
		onAfterRendering: function () {
			var that = this;
			that.oTab();

			/*	that.oDataModel = new sap.ui.model.odata.ODataModel(that.url, true);
				var path = "/YmmshPrSet";
				that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

				
					that.oObjemodelx = oData.results;

				});*/

			//PR list  Searchhelp Start
			this.oModelunlockCreate.read("/YmmshPrSet", null, null, true, function (oData, oRespone) {
				var Data = oData.results;
				var oPRDetailsModelref = new sap.ui.model.json.JSONModel(Data);

				that.getView().byId("InputValuePR").setModel(oPRDetailsModelref);
			}, function (error) {

			});
			//PR list Searchhelp End
			//Bussiness Unit Searchhelp Start
			this.oModelunlockCreate.read("/ZmmshBuSet", null, null, true, function (oData, oRespone) {
				var Data = oData.results;
				var oBumodel = new sap.ui.model.json.JSONModel(Data);

				that.getView().byId("InputValueBU1").setModel(oBumodel);
			}, function (error) {

			});
			//Bussiness Unit Searchhelp End
			//Bussiness Dept. Searchhelp Start
			this.oModelunlockCreate.read("/ZmmshDeptCode2Set", null, null, true, function (oData, oRespone) {
				var Data = oData.results;
				var oBuDeptmodel = new sap.ui.model.json.JSONModel(Data);

				that.getView().byId("InputValueBDept").setModel(oBuDeptmodel);
			}, function (error) {

			});
			//Bussiness Dept. Searchhelp End

			//Request Category  combobox Start
			this.oModelunlockCreate.read("/zmmsh_categorySet", null, null, true, function (oData, oRespone) {
				var Data1 = oData.results;
				var obj = {};

				for (var i = 0, len = Data1.length; i < len; i++)
					obj[Data1[i]['category']] = Data1[i];

				var Data = new Array();
				for (var key in obj)
					Data.push(obj[key]);

				var oReqCategrymodel = new sap.ui.model.json.JSONModel(Data);
				that.getView().byId("idPrType").setModel(oReqCategrymodel);

				/* that.getView().byId("InputValueBDept").setModel(oBuDeptmodel);*/
			}, function (error) {

			});
			//Request Category combobox End
			//Requisitioner Searchhelp Start
			that.oModelunlockCreate.read("/ZmmshAfnamSet", null, null, true, function (oData, oRespone) {
				var Data = oData.results;

				var oReqmodel = new sap.ui.model.json.JSONModel(Data);
				that.getView().byId("InputValueRequr").setModel(oReqmodel);

			}, function (error) {

			});
			//Requisitioner Searchhelp End
			//Material Group Searchhelp Start
			/* that.oModelunlockCreate.read("/ymm_sh_glSet", null, null, true, function (oData, oRespone) {
			var Data = oData.results;

			var oMatrpmodel = new sap.ui.model.json.JSONModel(Data);
			that.getView().byId("InputValueMatgrp").setModel(oMatrpmodel);

			}, function (error) {

			});*/
			//Material Group Searchhelp End
			//Purchase Group Searchhelp Start
			/* var oUrlPurgrp = "/zmmsh_categorySet(ekgrp='" + this.oReqKey + "')";
			this.oModelunlockCreate.read(oUrlPurgrp, null, null, true, function (oData, oRespone) {
			var Data = oData.results;
			var PucgrpModel = new sap.ui.model.json.JSONModel(Data);
			that.getView().byId("idPurcGrp").setModel(PucgrpModel, "oPurchaseGrpModl");
			}, function (error) {

			});*/
			//Purchase Group Searchhelp End

			//Unit Searchhelp Start
			/* this.oModelItems.read("/I_UnitOfMeasure", null, null, true, function (oData, oRespone) {
			var Data = oData.results;

			var oUnitmodel = new sap.ui.model.json.JSONModel(Data);
			that.getView().byId("InputValueUnit").setModel(oUnitmodel);

			}, function (error) {

			});*/
			//Plant fragment model start
			this.oModelItems.read("/I_Plant", null, null, true, function (oData, oRespone) {
				var Data = oData.results;

				var oPlantmodl = new sap.ui.model.json.JSONModel(Data);
				that.getView().byId("InputValuePlnt").setModel(oPlantmodl);

			}, function (error) {

			});
			//Plant fragment model End
			//Material Code fragment model start
			/* var oPlantobj = this.oSelectedItemplt;
			var oMateGrop = this.oSelectedMatgrp;

			var oMatcodel = "/ymmsh_materialSet(WERKS='" + oPlantobj + "'," + "matkl='" + oMateGrop + "')";
			this.oModelunlockCreate.read(oMatcodel, null, null, true, function (oData, oRespone) {
			var Data = oData;

			var oMatodemodl = new sap.ui.model.json.JSONModel(Data);
			that.getView().byId("InputValueMatCode").setModel(oMatodemodl);

			}, function (error) {

			});*/
			//Material Code  fragment model End

			//Unit Searchhelp End
			//Currency Searchhelp Start
			/* this.oModelItems.read("/I_Currency", null, null, true, function (oData, oRespone) {
			var Data = oData.results;

			var oCurrecymodel = new sap.ui.model.json.JSONModel(Data);
			that.getView().byId("InputValueCurrency").setModel(oCurrecymodel, "oCurrecymodel2");

			}, function (error) {

			});*/
			//Currency Searchhelp End
			//WBS Searchhelp Start
			/*this.oModelunlockCreate.read("/ymmsh_WBSSet", null, null, true, function (oData, oRespone) {
			var Data = oData.results;

			var oWBSmodel = new sap.ui.model.json.JSONModel(Data);
			that.getView().byId("oWbscod").setModel(oWBSmodel);

			}, function (error) {

			});*/
			//CC Searchhelp Start
			/* that.oModelunlockCreate.read("/ymmsh_CostCenterSet", null, null, true, function (oData, oRespone) {
			var Data = oData.results;

			var oCCmodel = new sap.ui.model.json.JSONModel(Data);
			that.getView().byId("oCCCode").setModel(oCCmodel);

			}, function (error) {

			});*/
			//CC Searchhelp End

		},
		onSuggestionItemSelectedTask: function (oEvent) {
			debugger;
			var oPrnumber1 = oEvent.mParameters.selectedItem.getText();
			this.getView().byId("InputValuePR").setValue(oPrnumber1);
			//	this.getView().byId("oxx").setVisible(false);

			//	this.onPrdesConfirm();

			this.getView().byId("idSave").setEnabled(true);
			this.getView().byId("idReject").setEnabled(true);

			var model = new sap.ui.model.json.JSONModel([]);
			oMessagePopover.setModel(model);
			//	oMessagePopover.toggle(that.getView().byId("ErrorMessages"));
			var viewModel = new sap.ui.model.json.JSONModel();
			viewModel.setData({
				messagesLength: 0 + ''
			});

			this.getView().setModel(viewModel);

			//	sap.ui.core.BusyIndicator.show();
         	this.oTab();
			var that = this;

			that.getView().byId("InputValuePR").setValueState("None");
			that.getView().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
			that.getView().byId("oshmTable").setVisible(true);
			var oPrnumber = that.getView().byId("InputValuePR").getValue();

			//	var oPrnumber = that.getView().byId("InputValuePR").setValue(oSelectedSujjVal);
			var readRequesinglePR = "/PR_HeaderSet('" + oPrnumber + "')?$expand=YMM_FIORI_LOGSet";
			that.oModelunlockCreate.read(readRequesinglePR, null, null, false, function (oData, oRespone) {

				//	that.oModelunlockCreate.read("/YMM_FIORI_LOGSet", null, null, false, function (oData, oRespone) {
				var Data = oData.YMM_FIORI_LOGSet.results;
				that.oFioriLogmodlref = Data;

			}, function (error) {
				that.oFioriLogmodlref = [];
			});

			that.onForwardUserdetails();

			var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

			that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);
			/* var oObject =  oPurReq;*/
			var readRequestURL2 = "/PR_HeaderSet('" + oPrnumber + "')?$expand=PR_ItemSet";
			that.oDataModel.read(readRequestURL2, null, null, false, function (oData, oResponse) {

				var oObjemodel2 = oData.PR_ItemSet.results;

				//var ghdObject=ghdData.filter(function(x){return x.})
				var oEditTableModel2 = new sap.ui.model.json.JSONModel(oObjemodel2);

				//that.getView().byId("idRequisition").setModel(oEditTableModel2);

				oEditTableModel2.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
				that.getView().byId("InputValuePR").setValue(oPrnumber);
				that.getView().byId("ItemTable1").setModel(oEditTableModel2);
				that.onShmTableUpdate();
				that.TotalValCal();
				that.oEditBussiUnit = oEditTableModel2.oData[0].Zzbu;
				that.oEditBusedept = oEditTableModel2.oData[0].ZzbuDesc;
				that.oEditBusedeptdesc = oEditTableModel2.oData[0].ZzdeptDesc2;
				that.oEditBussinessdeptcode = oEditTableModel2.oData[0].ZzdeptCode2;
				that.oEditDocType = oEditTableModel2.oData[0].DocType; //Request type
				that.oEditAccountType = oEditTableModel2.oData[0].AccountType; //Expense type
				that.oEditZzaprL3Name = oEditTableModel2.oData[0].ZzaprL3Name;
				that.oEditZzaprL3 = oEditTableModel2.oData[0].ZzaprL3;
				that.oEditRequisitioner = oEditTableModel2.oData[0].Requisitioner;
				that.oEditZzassName2 = oEditTableModel2.oData[0].ZzassName2;
				that.oEditZzassName2 = oEditTableModel2.oData[0].ZzassName2;
				that.oEditPlant = oEditTableModel2.oData[0].Plant;
				that.oEditRequestCategoryDropdown = oEditTableModel2.oData[0].ReqCategory;
				that.oEditRequestCategory = oEditTableModel2.oData[0].PurGroup;
				that.oEditText = oEditTableModel2.oData[0].Headertext;
				that.unbudgtedcheckbx = oEditTableModel2.oData[0].ZzdeptCode;
				that.oBuyr = oEditTableModel2.oData[0].Zzcategoty;
				that.oAggrementnumEdit = oEditTableModel2.oData[0].Konnr;
				that.oAggreItemnoEdit = oEditTableModel2.oData[0].Ktpnr;
				that.oCreatedbyname = oEditTableModel2.oData[0].Createdby;
				//	that.oPrCreatedby = oEvent.getParameter("selectedItem").getBindingContext().getObject().Ernam;
				that.oPrCreatedby = oEditTableModel2.oData[0].Createdby;
				// var oPRnumbr = oObjemodel2.Banfn;
				//oModel2.oData.PR_ItemSet.results[0].ZzdeptDesc2;
				//varoObjemodel2.Banfn;
				// this.getView().byId("InputValuePR").setModel(oModel2);&nbsp;\&nbsp;
				that.getView().byId("idReqType").setSelectedKey(that.oEditDocType);
				that.getView().byId("idPGrp").setSelectedKey(that.oEditAccountType);
				// that.getView().byId("oidBussinessDept").setText(that.oEditBussiUnit);
				that.getView().byId("oBussinesidtext").setText(that.oEditBussiUnit);

				that.getView().byId("InputValueBU1").setValue(that.oEditBusedept);
				that.getView().byId("InputValueBDept").setValue(that.oEditBusedeptdesc);
				that.getView().byId("oidBussinessDept").setText(that.oEditBussinessdeptcode);
				that.getView().byId("idBuApptext").setText(that.oEditZzaprL3Name + "-" + that.oEditZzaprL3);
				that.getView().byId("InputValueRequr").setValue(that.oEditRequisitioner);
				that.getView().byId("idManagertext").setText(that.oEditZzassName2);
				that.getView().byId("InputValuePlnt").setValue(that.oEditPlant);
				that.getView().byId("InputValueAgrmt").setValue(that.oAggrementnumEdit);
				that.getView().byId("oCreatedbyId").setText(that.oCreatedbyname);
				if (that.oEditDocType == "ZSC") {

					that.getView().byId("idAgrmnt").setVisible(true);
					that.getView().byId("InputValueAgrmt").setVisible(true);

				} else {
					that.getView().byId("idAgrmnt").setVisible(false);
					that.getView().byId("InputValueAgrmt").setVisible(false);

				}

				if (that.unbudgtedcheckbx == "YY") {
					that.getView().byId("oUndbChecbx").setSelected(true);
				} else if (that.unbudgtedcheckbx == "ZZ") {
					that.getView().byId("oUndbChecbx").setSelected(false);
				}
				//	that.getView().byId("idBuApptext").setText(that.oEditZzaprL3);
				//	that.getView().byId("idPrType").setText(that.oEditRequestCategoryDropdown);
				that.getView().byId("idPrType").setSelectedKey(that.oEditRequestCategory);
				that.getView().byId("idPrType").setValue(that.oEditRequestCategoryDropdown);
				that.getView().byId("oTxtvalue").setValue(that.oEditText);
				//	that.getView().byId("idzzcategry").setText(that.oEditZZcategory);\&nbsp;
				that.getView().byId("InputValueAgrmt").setEnabled(false);
				that.getView().byId("InputValuePlnt").setEnabled(false);
				that.getView().byId("InputValueRequr").setEnabled(false);
				that.getView().byId("InputValueBDept").setEnabled(false);
				that.getView().byId("InputValueBU1").setEnabled(false);
				that.getView().byId("idPrType").setEnabled(false);
				that.getView().byId("idPGrp").setEnabled(false);
				that.getView().byId("idReqType").setEnabled(false);
				that.getView().byId("idInputFileNumber").setEnabled(false);
				that.getView().byId("oUndbChecbx").setEnabled(false);

				if (that.oEditAccountType == "K" || that.oEditAccountType == "A") {
					that.getView().byId("catalogTab_coltotal").setVisible(true);
					that.getView().byId("catalogTabcoltotal").setVisible(false);
				} else {
					that.getView().byId("catalogTab_coltotal").setVisible(false);
					that.getView().byId("catalogTabcoltotal").setVisible(true);
				}
				that.getAttachMents(oPrnumber);

				that.oSelectedItemplt = that.getView().byId("InputValuePlnt").getValue();

				var oUrlPurgrp = "/zmmsh_categorySet(plant='" + that.oSelectedItemplt + "',category='" + that.oEditRequestCategoryDropdown +
					"')";
				//	var oUrlPurgrp = "/zmmsh_categorySet(ekgrp='" + that.oEditRequestCategory + "')";
				if (oObjemodel2.length) {
					oObjemodel2 = oObjemodel2[0];
				}
				var oRelaseStrt = [];
				for (var key in oObjemodel2) {

					if (oObjemodel2.hasOwnProperty(key)) {
						if (key == "Frgc1") {
							if (oObjemodel2.Frgc1 != "") {
								var obj = {
									"Frgc": oObjemodel2.Frgc1,
									"RelCodeDesc": oObjemodel2.RelCodeDesc1,
									"AprText": oObjemodel2.AprText1,
									"AprDate": oObjemodel2.AprDate1,
									"Status": oObjemodel2.Status1
								};
								oRelaseStrt.push(obj);
							}
						} else if (key == "Frgc2") {
							if (oObjemodel2.Frgc2 != "") {
								var obj = {
									"Frgc": oObjemodel2.Frgc2,
									"RelCodeDesc": oObjemodel2.RelCodeDesc2,
									"AprText": oObjemodel2.AprText2,
									"AprDate": oObjemodel2.AprDate2,
									"Status": oObjemodel2.Status2
								};
								oRelaseStrt.push(obj);
							}
						} else if (key == "Frgc3") {
							if (oObjemodel2.Frgc3 != "") {
								var obj = {
									"Frgc": oObjemodel2.Frgc3,
									"RelCodeDesc": oObjemodel2.RelCodeDesc3,
									"AprText": oObjemodel2.AprText3,
									"AprDate": oObjemodel2.AprDate3,
									"Status": oObjemodel2.Status3
								};
								oRelaseStrt.push(obj);
							}
						} else if (key == "Frgc4") {
							if (oObjemodel2.Frgc4 != "") {
								var obj = {
									"Frgc": oObjemodel2.Frgc4,
									"RelCodeDesc": oObjemodel2.RelCodeDesc4,
									"AprText": oObjemodel2.AprText4,
									"AprDate": oObjemodel2.AprDate4,
									"Status": oObjemodel2.Status4
								};
								oRelaseStrt.push(obj);
							}
						} else if (key == "Frgc5") {
							if (oObjemodel2.Frgc5 != "") {
								var obj = {
									"Frgc": oObjemodel2.Frgc5,
									"RelCodeDesc": oObjemodel2.RelCodeDesc5,
									"AprText": oObjemodel2.AprText5,
									"AprDate": oObjemodel2.AprDate5,
									"Status": oObjemodel2.Status5
								};
								oRelaseStrt.push(obj);
							}
						} else if (key == "Frgc6") {
							if (oObjemodel2.Frgc6 != "") {
								var obj = {
									"Frgc": oObjemodel2.Frgc6,
									"RelCodeDesc": oObjemodel2.RelCodeDesc6,
									"AprText": oObjemodel2.AprText6,
									"AprDate": oObjemodel2.AprDate6,
									"Status": oObjemodel2.Status6
								};
								oRelaseStrt.push(obj);
							}
						} else if (key == "Frgc7") {
							if (oObjemodel2.Frgc7 != "") {
								var obj = {
									"Frgc": oObjemodel2.Frgc7,
									"RelCodeDesc": oObjemodel2.RelCodeDesc7,
									"AprText": oObjemodel2.AprText7,
									"AprDate": oObjemodel2.AprDate7,
									"Status": oObjemodel2.Status7
								};
								oRelaseStrt.push(obj);
							}
						} else if (key == "Frgc8") {
							if (oObjemodel2.Frgc8 != "") {
								var obj = {
									"Frgc": oObjemodel2.Frgc8,
									"RelCodeDesc": oObjemodel2.RelCodeDesc8,
									"AprText": oObjemodel2.AprText8,
									"AprDate": oObjemodel2.AprDate8,
									"Status": oObjemodel2.Status8
								};
								oRelaseStrt.push(obj);
							}
						}
					}
				}
				var oRelaseStrtMode = new sap.ui.model.json.JSONModel(oRelaseStrt);
				that.getView().byId("oRelaseStrtTable").setModel(oRelaseStrtMode);

				that.oModelunlockCreate.read(oUrlPurgrp, null, null, true, function (oData, oRespone) {
						var Data = oData;
						var oPurGrpModel = new sap.ui.model.json.JSONModel(Data);
						that.getView().byId("idPuridGrop").setModel(oPurGrpModel);
						var xx = that.getView().byId("idPuridGrop").getModel().getData().Buyer;
						that.xx2 = that.getView().byId("idPuridGrop").getModel().getData().ekgrp;
						that.getView().byId("idPuridGrop").setValue(xx);
					},
					function (error) {

					});

			});

			var path = "/ymm_userSet";
			that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

				var oObjemodel1 = oData.results;

				var oLoggeduserModel = new sap.ui.model.json.JSONModel(oObjemodel1);
				oLoggeduserModel.setSizeLimit(1000);

				that.getView().byId("oLogdusrId").setModel(oLoggeduserModel, "oUserDetails");
				that.oLoggeduser = that.getView().byId("oLogdusrId").getModel("oUserDetails").getData()[0].SYUSER;

			});

			that.oLoggeduser;
			var ghdData = that.oFioriLogmodlref.filter(function (x) {
				/* return x.ZdocNo == oPrnumber && x.PendingWith == that.oLoggeduser;*/
				return x.ZdocNo == oPrnumber;
			});
			var ItemData = that.getView().byId("ItemTable1").getModel().getData();
			if (that.oPrCreatedby === that.oLoggeduser) {
				that.getView().byId("ItemTable1").setMode("MultiSelect");

				for (var k = 0; k < ItemData.length; k++) {
					that.getView().byId("ItemTable1").getModel().getData()[k].DeletebtnEnabled = true;
					that.getView().byId("ItemTable1").getModel().getData()[k].ExistingPr = that.getView().byId("ItemTable1").getModel().getData()[k]
						.PreqNo;
				}

			} else {
				that.getView().byId("ItemTable1").setMode("None");
				for (var k = 0; k < ItemData.length; k++) {
					that.getView().byId("ItemTable1").getModel().getData()[k].DeletebtnEnabled = false;
				}
			}
			that.getView().byId("ItemTable1").getModel().refresh(true);
			that.TotalValCal();
			// var ghdDatalastElement = ghdData[ghdData.length - 1];
			if (ghdData.length) {
				ghdData.sort(function (a, b) {
					var dateA = new Date(a.Zdate),
						dateB = new Date(b.Zdate);
					return dateB - dateA;
				});
				if (ghdData[0].PendingWith === "SAM" || ghdData[0].PendingWith === "HAM") {
					var Lvl2DataActF = ghdData.filter(function (x) {
						return ((x.CurrentStat === "02" || x.CurrentStat === "03") && x.Action == "F");
					});
					var Lvl2DataActA = ghdData.filter(function (x) {
						return ((x.CurrentStat === "02" || x.CurrentStat === "03") && x.Action == "A");
					});
					if (Lvl2DataActF.length) {
						Lvl2DataActA[0].Actn = Lvl2DataActF[0].Action;
						Lvl2DataActA[0].Approver2Id = Lvl2DataActF[0].Approver2Id;
						Lvl2DataActA[0].ReviewerRem = Lvl2DataActF[0].ReviewerRem;
						Lvl2DataActA[0].ReviewerStatus = Lvl2DataActF[0].ReviewerStatus;
						that.FilteredghdData = Lvl2DataActA[0];
						that.PendingWith = Lvl2DataActA[0].PendingWith;

					} else {
						that.FilteredghdData = ghdData[0];
						that.PendingWith = ghdData[0].PendingWith;
					}
				} else {
					that.FilteredghdData = ghdData[0];
					that.PendingWith = ghdData[0].PendingWith;

				}
			}
			if (that.oEditDocType == "ZSC") {

				if (ghdData.length) {

					if (that.PendingWith == "") {
						if (that.oLoggeduser == that.oPrCreatedby) {
							that.getView().byId("ItemTable1").setMode("MultiSelect");

							var ApprovManager = ghdData.filter(function (x) {
								//	return x.PendingWith == "SAM" || x.PendingWith == "HAM";
								return x.PendingWith == "SAM" || x.PendingWith == "HAM";
							});
							if (ApprovManager.length) {

								if (ApprovManager[0].Action = !"F") {
									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: false,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													},

													{
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
								} else {

									if (ApprovManager[1].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[1].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									} else if (ApprovManager[1].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									ApprovSAM[0].Remarks = ApprovManager[0].ReviewerRem;
									ApprovSAM[0].Status = ApprovManager[0].ReviewerStatus

									ApprovSAM[0].Approver2Id = ApprovManager[0].Approver2Id;

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									} else if (ApprovManager[0].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
									}

									/*	if (ApprovSAM[0].Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (ApprovSAM[0].Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (ApprovSAM[0].Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (ApprovSAM[0].Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (ApprovSAM[0].Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}, {
														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}

												],
												Remarks: ApprovManager[1].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: true,
												Action2: that.getView().getModel("oSecondLevUserslist").getData(),
												ActnKey2: ApprovSAM[0].Approver2Id,

												Action: [

													{
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}

												]

											}

										]

									};

								}
							} else {

								var ApprovManager = ghdData.filter(function (x) {
									return x.PendingWith == "";
								});

								if (ApprovManager[0].Action == "A") {
									var ApprovManagerActionKey = "A";
									var ApprovManagerAction = "Approve";
								} else if (ApprovManager[0].Action == "R") {
									var ApprovManagerActionKey = "R";
									var ApprovManagerAction = "Reject";
								}

								var SamData = {
									data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [{

												stats: ApprovManager[0].Status,
												statskey: ApprovManager[0].Status
											}, {
												stats: ApprovManager[0].Status,
												statskey: ApprovManager[0].Status
											}

										],
										Remarks: ApprovManager[0].Remarks,
										Action2Visible: false,
										Action: [

											{
												Atcn: ApprovManagerAction,
												ActnKey: ApprovManagerActionKey
											}, {
												Atcn: ApprovManagerAction,
												ActnKey: ApprovManagerActionKey
											}

										]

									}]
								};
							}
							var GhdModel = new sap.ui.model.json.JSONModel();
							GhdModel.setData(SamData);
							that.getView().byId("oshmTable").setModel(GhdModel);

							that.getView().byId("idSave").setEnabled(false);
							that.getView().byId("oAdditmbtn").setEnabled(false);
							that.getView().byId("edit").setEnabled(false);
							that.getView().byId("idcopy").setEnabled(false);
							that.getView().byId("idedit").setEnabled(false);

							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);

							that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
							that.getView().byId("oUndbChecbx").setEnabled(false);
							that.getView().byId("oTxtvalue").setEnabled(false);
							that.getView().byId("idReject").setEnabled(false);

						} else {
							that.getView().byId("ItemTable1").setMode("None");
							that.getView().byId("idSave").setEnabled(false);
							that.getView().byId("oAdditmbtn").setEnabled(false);
							that.getView().byId("edit").setEnabled(false);
							that.getView().byId("idcopy").setEnabled(false);
							that.getView().byId("idedit").setEnabled(false);

							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);

							that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
							that.getView().byId("oUndbChecbx").setEnabled(false);
							that.getView().byId("oTxtvalue").setEnabled(false);
							that.getView().byId("idReject").setEnabled(false);
							that.getView().byId("ItemTable1").setMode("None");
							var ApprovManager = ghdData.filter(function (x) {

								return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
							});

							if (ApprovManager.length) {

								if (ApprovManager[0].Action = !"F") {
									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: false,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													},

													{
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
								} else {

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									} else if (ApprovManager[0].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									ApprovSAM[0].Remarks = ApprovManager[0].ReviewerRem;
									ApprovSAM[0].Status = ApprovManager[0].ReviewerStatus

									ApprovSAM[0].Approver2Id = ApprovManager[0].Approver2Id;

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									} else if (ApprovManager[0].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
									}

									/*	if (ApprovSAM[0].Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (ApprovSAM[0].Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (ApprovSAM[0].Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (ApprovSAM[0].Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (ApprovSAM[0].Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}, {
														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}

												],
												Remarks: ApprovManager[1].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: true,

												Action2: that.getView().getModel("oSecondLevUserslist").getData(),
												ActnKey2: ApprovSAM[0].Approver2Id,

												Action: [

													{
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}

												]

											}

										]

									};

								}
							} else {

								var ApprovManager = ghdData.filter(function (x) {
									return x.PendingWith == "";
								});

								if (ApprovManager[0].Action == "A") {
									var ApprovManagerActionKey = "A";
									var ApprovManagerAction = "Approve";
								} else if (ApprovManager[0].Action == "R") {
									var ApprovManagerActionKey = "R";
									var ApprovManagerAction = "Reject";
								}

								var SamData = {
									data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [{

												stats: ApprovManager[0].Status,
												statskey: ApprovManager[0].Status
											}, {
												stats: ApprovManager[0].Status,
												statskey: ApprovManager[0].Status
											}

										],
										Remarks: ApprovManager[0].Remarks,
										Action2Visible: false,
										Action: [

											{
												Atcn: ApprovManagerAction,
												ActnKey: ApprovManagerActionKey
											}, {
												Atcn: ApprovManagerAction,
												ActnKey: ApprovManagerActionKey
											}

										]

									}]
								};
							}

							/*	var ApprovManager = ghdData.filter(function (x) {
								

									return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
								});
								ApprovManager.sort(function (a, b) {
									return a.CurrentStat - b.CurrentStat;

								});
								if (ApprovManager.length) {
									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: false,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													},

													{
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
								} else {

									var ApprovManager = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}

									var SamData = {
										data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [{

													stats: ApprovManager[0].Status,
													statskey: ApprovManager[0].Status
												}, {
													stats: ApprovManager[0].Status,
													statskey: ApprovManager[0].Status
												}

											],
											Remarks: ApprovManager[0].Remarks,
											Action2Visible: false,
											Action: [

												{
													Atcn: ApprovManagerAction,
													ActnKey: ApprovManagerActionKey
												}, {
													Atcn: ApprovManagerAction,
													ActnKey: ApprovManagerActionKey
												}

											]

										}]
									};

								}
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);*/
						}

					} else if (that.PendingWith == "PM") {
						var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";
						that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);
						var path = "/ymm_manager_setSet";
						that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

							var oManagermodelref1 = oData.results;
							that.oFilteredManager1 = oManagermodelref1.filter(function (x) {
								return x.User == that.oLoggeduser;
							});
						}, function (error) {
							that.oFilteredManager1 = [];
						});
						if (that.oFilteredManager1.length) {
							if (that.oLoggeduser == that.oFilteredManager1[0].User) {
								that.getView().byId("ItemTable1").setMode("MultiSelect");
								var PendindData = ghdData.filter(function (x) {
									return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
								});

								if (!PendindData.length) {
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: true,
												Status: [{

														stats: "--Please Select--"

													}, {

														stats: "Forward",
														statskey: "forward"
													}, {
														stats: "No requirement",
														statskey: "Norequirement"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{

														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											},

											{
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
								} else {
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: "--Please Select--"

													}, {

														stats: "Forward",
														statskey: "forward"
													}, {
														stats: "No requirement",
														statskey: "Norequirement"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{

														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}, {
												Reviewer: "SAM",
												editable: true,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};

								}
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

								that.getView().byId("idSave").setEnabled(true);
								that.getView().byId("oAdditmbtn").setEnabled(true);
								that.getView().byId("edit").setEnabled(true);
								that.getView().byId("idcopy").setEnabled(true);
								that.getView().byId("idedit").setEnabled(true);
								//that.getView().byId("oidAttach").setEnabled(true);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(true);
								//	that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(true);
								that.getView().byId("idReject").setEnabled(true);

							} else {
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								//	that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);

								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [{

													stats: "--Please Select--"

												}, {

													stats: "Forward",
													statskey: "forward"
												}, {
													stats: "No requirement",
													statskey: "Norequirement"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{

													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}
						} else if (that.oLoggeduser == that.oPrCreatedby) {
							that.getView().byId("idSave").setEnabled(true);
							that.getView().byId("oAdditmbtn").setEnabled(true);
							that.getView().byId("edit").setEnabled(true);
							that.getView().byId("idcopy").setEnabled(true);
							that.getView().byId("idedit").setEnabled(true);
							//that.getView().byId("oidAttach").setEnabled(false);
							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);
							// that.getView().byId("InputValuePR").setEnabled(false);
							//	that.getView().byId("oFIleuploadrid").setEnabled(false);
							that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
							that.getView().byId("oUndbChecbx").setEnabled(true);
							that.getView().byId("oTxtvalue").setEnabled(true);
							that.getView().byId("idReject").setEnabled(true);

							var SamData = {
								data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [{

												stats: "--Please Select--"

											}, {

												stats: "Forward",
												statskey: "forward"
											}, {
												stats: "No requirement",
												statskey: "Norequirement"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{

												Atcn: "--Please Select--"

											},

											{
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}, {
										Reviewer: "SAM",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											}, {
												stats: "Delivered from Inventory",
												statskey: "Inventory"
											}, {
												stats: "Back to back buy",
												statskey: "Backtobuy"
											}, {
												stats: "Allocated",
												statskey: "Allocated"
											}, {
												stats: "Non Standard",
												statskey: "Non Standard"
											}, {
												stats: "Quote Attached",
												statskey: "Quuote Attached"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [

											{
												Atcn: "--Please Select--"

											}, {
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									},

									{
										Reviewer: "Buyer",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											}, {
												stats: "Quote attached",
												statskey: "Quoteattached"
											}, {
												stats: "Requirement Change",
												statskey: "Requirementchange"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{
												Atcn: "--Please Select--"

											}, {
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}

								]

							};
							var GhdModel = new sap.ui.model.json.JSONModel();
							GhdModel.setData(SamData);
							that.getView().byId("oshmTable").setModel(GhdModel);

						} else if (that.oLoggeduser != that.oPrCreatedby || that.oLoggeduser != that.oFilteredManager1[0].User) {

							that.getView().byId("idSave").setEnabled(false);
							that.getView().byId("oAdditmbtn").setEnabled(false);
							that.getView().byId("edit").setEnabled(false);
							that.getView().byId("idcopy").setEnabled(false);
							that.getView().byId("idedit").setEnabled(false);
							//that.getView().byId("oidAttach").setEnabled(false);
							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);
							// that.getView().byId("InputValuePR").setEnabled(false);
							//	that.getView().byId("oFIleuploadrid").setEnabled(false);
							that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
							that.getView().byId("oUndbChecbx").setEnabled(false);
							that.getView().byId("oTxtvalue").setEnabled(false);
							that.getView().byId("idReject").setEnabled(false);

							var SamData = {
								data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [{

												stats: "--Please Select--"

											}, {

												stats: "Forward",
												statskey: "forward"
											}, {
												stats: "No requirement",
												statskey: "Norequirement"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{

												Atcn: "--Please Select--"

											},

											{
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}, {
										Reviewer: "SAM",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											}, {
												stats: "Delivered from Inventory",
												statskey: "Inventory"
											}, {
												stats: "Back to back buy",
												statskey: "Backtobuy"
											}, {
												stats: "Allocated",
												statskey: "Allocated"
											}, {
												stats: "Non Standard",
												statskey: "Non Standard"
											}, {
												stats: "Quote Attached",
												statskey: "Quuote Attached"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [

											{
												Atcn: "--Please Select--"

											}, {
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									},

									{
										Reviewer: "Buyer",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											}, {
												stats: "Quote attached",
												statskey: "Quoteattached"
											}, {
												stats: "Requirement Change",
												statskey: "Requirementchange"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{
												Atcn: "--Please Select--"

											}, {
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}

								]

							};
							var GhdModel = new sap.ui.model.json.JSONModel();
							GhdModel.setData(SamData);
							that.getView().byId("oshmTable").setModel(GhdModel);

						}

					} else if (that.PendingWith == "SAM") {

						var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

						that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

						var path = "/YMM_PR_SAMSet";
						that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

							var oHamsetmodelref = oData.results;
							that.oFilteredSAM = oHamsetmodelref.filter(function (x) {
								return x.AFNAM == that.oLoggeduser;
							});
						}, function (error) {
							that.oFilteredSAM = [];
						});
						if (that.oFilteredSAM.length) {
							if (that.oLoggeduser == that.oFilteredSAM[0].AFNAM) {
								that.getView().byId("ItemTable1").setMode("MultiSelect");

								if (that.oFilteredSAM.length) {
									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									} else if (that.FilteredghdData.Action == "F") {
										var ActionKey = "F";
										var Action = "Forward";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: true,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}, {
														Atcn: "Forward",
														ActnKey: "F"
													}

												],
												Action2: that.getView().getModel("oSecondLevUserslist").getData()

												/*	Action2: [

														{
															Atcn2: "--Please Select--"

														}, {
															Atcn2: "Vijay A",
															ActnKey2: "VA3833"
														}, {
															Atcn2: "Srinivas Ch",
															ActnKey2: "SC0430"
														}, {
															Atcn2: "Basha S",
															ActnKey2: "BS2931"
														}, {
															Atcn2: "Denis C",
															ActnKey2: "DC30338"
														}, {
															Atcn2: "Suman B",
															ActnKey2: "SB3817"
														}

													]*/

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									if (that.FilteredghdData.Actn === "F") {

										if (that.FilteredghdData.ReviewerStatus === "Inventory") {
											var stats = "Delivered from Inventory";
											var statskey = "Inventory"
										} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
											var stats = "Back to back buy";
											var statskey = "Backtobuy";
										} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
											var stats = "Allocated";
											var statskey = "Allocated";
										} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
											var stats = "Non Standard";
											var statskey = "Non Standard";
										} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
											var stats = "Quote Attached";
											var statskey = "Quuote Attached";
										}

										/*if (that.FilteredghdData.Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (that.FilteredghdData.Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (that.FilteredghdData.Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (that.FilteredghdData.Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (that.FilteredghdData.Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

										SamData.data.splice(1, 1);
										var Obj = {
											Reviewer: that.FilteredghdData.PendingWith,
											editable: false,
											Status: [{
													stats: stats,
													statskey: statskey
												}, {
													stats: stats,
													statskey: statskey

												}

											],
											Remarks: that.FilteredghdData.ReviewerRem,
											Action2Visible: true,
											Action2: that.getView().getModel("oSecondLevUserslist").getData(),
											ActnKey2: that.FilteredghdData.Approver2Id,

											Action: [

												{
													Atcn: "Forward",
													ActnKey: "F"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											]

										};

										SamData.data.splice(1, 0, Obj);
									}

									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);
									that.getView().byId("idSave").setEnabled(true);

									that.getView().byId("oAdditmbtn").setEnabled(true);
									that.getView().byId("edit").setEnabled(true);
									that.getView().byId("idcopy").setEnabled(true);
									that.getView().byId("idedit").setEnabled(true);
									//that.getView().byId("oidAttach").setEnabled(true);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

									//	that.getView().byId("oFIleuploadrid").setEnabled(true);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(true);
									that.getView().byId("idReject").setEnabled(true);

								} else {
									//Display code
									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									//that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									/* that.getView().byId("idSave").setEnabled(false);*/

									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													},

													{
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

								}

							} else {
								that.getView().byId("ItemTable1").setMode("None");
								//Display code
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								/* that.getView().byId("idSave").setEnabled(false);*/
								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}
						} else {

							if (that.oFilteredSAM.length == "0") {

								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								} else if (that.FilteredghdData.Action == "F") {
									var ActionKey = "F";
									var Action = "Forward";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action2Visible: false,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											],
											Action2: that.getView().getModel("oSecondLevUserslist").getData()

											/*Action2: [

												{
													Atcn2: "--Please Select--"

												}, {
													Atcn2: "Vijay A",
													ActnKey2: "VA3833"
												}, {
													Atcn2: "Srinivas Ch",
													ActnKey2: "SC0430"
												}, {
													Atcn2: "Basha S",
													ActnKey2: "BS2931"
												}, {
													Atcn2: "Denis C",
													ActnKey2: "DC30338"
												}, {
													Atcn2: "Suman B",
													ActnKey2: "SB3817"
												}

											]*/

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};

								var GhdModel = new sap.ui.model.json.JSONModel();
								if (that.FilteredghdData.Actn === "F") {

									if (that.FilteredghdData.ReviewerStatus === "Inventory") {
										var stats = "Delivered from Inventory";
										var statskey = "Inventory"
									} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
										var stats = "Back to back buy";
										var statskey = "Backtobuy";
									} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
										var stats = "Allocated";
										var statskey = "Allocated";
									} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
										var stats = "Non Standard";
										var statskey = "Non Standard";
									} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
										var stats = "Quote Attached";
										var statskey = "Quuote Attached";
									}

									/*	if (that.FilteredghdData.Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (that.FilteredghdData.Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (that.FilteredghdData.Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (that.FilteredghdData.Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (that.FilteredghdData.Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

									SamData.data.splice(1, 1);
									var Obj = {
										Reviewer: that.FilteredghdData.PendingWith,
										editable: false,
										Status: [{
												stats: stats,
												statskey: statskey
											}, {
												stats: stats,
												statskey: statskey

											}

										],
										Remarks: that.FilteredghdData.ReviewerRem,
										Action2Visible: true,
										Action2: that.getView().getModel("oSecondLevUserslist").getData(),
										ActnKey2: that.FilteredghdData.Approver2Id,

										Action: [

											{
												Atcn: "Forward",
												ActnKey: "F"
											}, {
												Atcn: "Forward",
												ActnKey: "F"
											}

										]

									};

									SamData.data.splice(1, 0, Obj);
								}

								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);
								that.getView().byId("idSave").setEnabled(false);

								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(true);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(true);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);

							} else {

								//Display code
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								/* that.getView().byId("idSave").setEnabled(false);*/

								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}

						}
						/* actual code
						
											if (that.oFilteredSAM.length) {
												if (that.oLoggeduser == that.oFilteredSAM[0].AFNAM) {
													that.getView().byId("ItemTable1").setMode("MultiSelect");
													if (that.oFilteredSAM.length) {
														if (that.FilteredghdData.Action == "A") {
															var ActionKey = "A";
															var Action = "Approve";
														} else if (that.FilteredghdData.Action == "R") {
															var ActionKey = "R";
															var Action = "Reject";
														} else if (that.FilteredghdData.Action == "F") {
															var ActionKey = "F";
															var Action = "Forward";
														}
														var SamData = {
															data: [{
																	Reviewer: "PR Creator/Manager",
																	editable: false,
																	Status: [

																		{
																			stats: that.FilteredghdData.Status,
																			statskey: that.FilteredghdData.Status
																		}, {
																			stats: that.FilteredghdData.Status,
																			statskey: that.FilteredghdData.Status
																		}

																	],
																	Remarks: that.FilteredghdData.Remarks,
																	Action2Visible: false,
																	Action: [

																		{
																			Atcn: Action,
																			ActnKey: ActionKey
																		}, {
																			Atcn: Action,
																			ActnKey: ActionKey
																		}

																	]

																}, {
																	Reviewer: "SAM",
																	editable: true,
																	Status: [{
																			stats: "--Please Select--"

																		}, {
																			stats: "Delivered from Inventory",
																			statskey: "Inventory"
																		}, {
																			stats: "Back to back buy",
																			statskey: "Backtobuy"
																		}, {
																			stats: "Allocated",
																			statskey: "Allocated"
																		}, {
																			stats: "Non Standard",
																			statskey: "Non Standard"
																		}, {
																			stats: "Quote Attached",
																			statskey: "Quuote Attached"
																		}

																	],
																	Remarks: "",
																	Action2Visible: false,
																	Action: [

																		{
																			Atcn: "--Please Select--"

																		}, {
																			Atcn: "Approve",
																			ActnKey: "A"
																		}, {
																			Atcn: "Reject",
																			ActnKey: "R"
																		}, {
																			Atcn: "Forward",
																			ActnKey: "F"
																		}

																	],

																	Action2: [

																		{
																			Atcn2: "--Please Select--"

																		}, {
																			Atcn2: "Vijay A",
																			ActnKey2: "VA3833"
																		}, {
																			Atcn2: "Srinivas Ch",
																			ActnKey2: "SC0430"
																		}, {
																			Atcn2: "Basha S",
																			ActnKey2: "BS2931"
																		}, {
																			Atcn2: "Denis C",
																			ActnKey2: "DC30338"
																		}, {
																			Atcn2: "Uman B",
																			ActnKey2: "SB3817"
																		}

																	]

																},

																{
																	Reviewer: "Buyer",
																	editable: false,
																	Status: [{
																			stats: "--Please Select--"

																		}, {
																			stats: "Quote attached",
																			statskey: "Quoteattached"
																		}, {
																			stats: "Requirement Change",
																			statskey: "Requirementchange"
																		}

																	],
																	Remarks: "",
																	Action2Visible: false,
																	Action: [{
																			Atcn: "--Please Select--"

																		}, {
																			Atcn: "Approve",
																			ActnKey: "A"
																		}, {
																			Atcn: "Reject",
																			ActnKey: "R"
																		}

																	]

																}

															]

														};

														var GhdModel = new sap.ui.model.json.JSONModel();
														if (that.FilteredghdData.Actn === "F") {

															if (that.FilteredghdData.ReviewerStatus === "Inventory") {
																var stats = "Delivered from Inventory";
																var statskey = "Inventory"
															} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
																var stats = "Back to back buy";
																var statskey = "Backtobuy";
															} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
																var stats = "Allocated";
																var statskey = "Allocated";
															} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
																var stats = "Non Standard";
																var statskey = "Non Standard";
															} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
																var stats = "Quote Attached";
																var statskey = "Quuote Attached";
															}

															if (that.FilteredghdData.Approver2Id === "VA3833") {
																var Atcn2 = "Vijay A";
																var ActnKey2 = "VA3833";
															} else if (that.FilteredghdData.Approver2Id === "SC0430") {
																var Atcn2 = "Srinivas Ch";
																var ActnKey2 = "SC0430";
															} else if (that.FilteredghdData.Approver2Id === "BS2931") {
																var Atcn2 = "Basha S";
																var ActnKey2 = "BS2931";
															} else if (that.FilteredghdData.Approver2Id === "DC30338") {
																var Atcn2 = "Denis C";
																var ActnKey2 = "DC30338";
															} else if (that.FilteredghdData.Approver2Id === "SB3817") {
																var Atcn2 = "Uman B";
																var ActnKey2 = "SB3817";
															}

															SamData.data.splice(1, 1);
															var Obj = {
																Reviewer: that.FilteredghdData.PendingWith,
																editable: false,
																Status: [{
																		stats: stats,
																		statskey: statskey
																	}, {
																		stats: stats,
																		statskey: statskey

																	}

																],
																Remarks: that.FilteredghdData.ReviewerRem,
																Action2Visible: true,
																Action2: [

																	{
																		Atcn2: Atcn2,
																		ActnKey2: ActnKey2
																	}, {
																		Atcn2: Atcn2,
																		ActnKey2: ActnKey2
																	}, {
																		Atcn2: Atcn2,
																		ActnKey2: ActnKey2
																	}, {
																		Atcn2: Atcn2,
																		ActnKey2: ActnKey2
																	}, {
																		Atcn2: Atcn2,
																		ActnKey2: ActnKey2
																	}

																],

																Action: [

																	{
																		Atcn: "Forward",
																		ActnKey: "F"
																	}, {
																		Atcn: "Forward",
																		ActnKey: "F"
																	}

																]

															};

															SamData.data.splice(1, 0, Obj);
														}

														GhdModel.setData(SamData);
														that.getView().byId("oshmTable").setModel(GhdModel);
														that.getView().byId("idSave").setEnabled(true);

														that.getView().byId("oAdditmbtn").setEnabled(true);
														that.getView().byId("edit").setEnabled(true);
														that.getView().byId("idcopy").setEnabled(true);
														that.getView().byId("idedit").setEnabled(true);

														that.getView().byId("InputValueAgrmt").setEnabled(false);
														that.getView().byId("InputValuePlnt").setEnabled(false);
														that.getView().byId("InputValueRequr").setEnabled(false);
														that.getView().byId("InputValueBDept").setEnabled(false);
														that.getView().byId("InputValueBU1").setEnabled(false);
														that.getView().byId("idPrType").setEnabled(false);
														that.getView().byId("idPGrp").setEnabled(false);
														that.getView().byId("idReqType").setEnabled(false);
														that.getView().byId("idInputFileNumber").setEnabled(false);

														that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
														that.getView().byId("oUndbChecbx").setEnabled(false);
														that.getView().byId("oTxtvalue").setEnabled(true);
														that.getView().byId("idReject").setEnabled(true);
														

													} else {
													
														that.getView().byId("idSave").setEnabled(false);
														that.getView().byId("oAdditmbtn").setEnabled(false);
														that.getView().byId("edit").setEnabled(false);
														that.getView().byId("idcopy").setEnabled(false);
														that.getView().byId("idedit").setEnabled(false);
													
														that.getView().byId("InputValueAgrmt").setEnabled(false);
														that.getView().byId("InputValuePlnt").setEnabled(false);
														that.getView().byId("InputValueRequr").setEnabled(false);
														that.getView().byId("InputValueBDept").setEnabled(false);
														that.getView().byId("InputValueBU1").setEnabled(false);
														that.getView().byId("idPrType").setEnabled(false);
														that.getView().byId("idPGrp").setEnabled(false);
														that.getView().byId("idReqType").setEnabled(false);
														that.getView().byId("idInputFileNumber").setEnabled(false);

													
														that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
														that.getView().byId("oUndbChecbx").setEnabled(false);
														that.getView().byId("oTxtvalue").setEnabled(false);
														that.getView().byId("idReject").setEnabled(false);
													
														if (that.FilteredghdData.Action == "A") {
															var ActionKey = "A";
															var Action = "Approve";
														} else if (that.FilteredghdData.Action == "R") {
															var ActionKey = "R";
															var Action = "Reject";
														}
														var SamData = {
															data: [{
																	Reviewer: "PR Creator/Manager",
																	editable: false,
																	Status: [

																		{
																			stats: that.FilteredghdData.Status,
																			statskey: that.FilteredghdData.Status
																		}, {
																			stats: that.FilteredghdData.Status,
																			statskey: that.FilteredghdData.Status
																		}

																	],
																	Remarks: that.FilteredghdData.Remarks,
																	Action: [

																		{
																			Atcn: Action,
																			ActnKey: ActionKey
																		}, {
																			Atcn: Action,
																			ActnKey: ActionKey
																		}

																	]

																}, {
																	Reviewer: "SAM",
																	editable: false,
																	Status: [{
																			stats: "--Please Select--"

																		}, {
																			stats: "Delivered from Inventory",
																			statskey: "Inventory"
																		}, {
																			stats: "Back to back buy",
																			statskey: "Backtobuy"
																		}, {
																			stats: "Allocated",
																			statskey: "Allocated"
																		}, {
																			stats: "Non Standard",
																			statskey: "Non Standard"
																		}, {
																			stats: "Quote Attached",
																			statskey: "Quuote Attached"
																		}

																	],
																	Remarks: "",
																	Action: [{
																			Atcn: "--Please Select--"

																		}, {
																			Atcn: "Approve",
																			ActnKey: "A"
																		}, {
																			Atcn: "Reject",
																			ActnKey: "R"
																		}

																	]

																},

																{
																	Reviewer: "Buyer",
																	editable: false,
																	Status: [{
																			stats: "--Please Select--"

																		},

																		{
																			stats: "Quote attached",
																			statskey: "Quoteattached"
																		}, {
																			stats: "Requirement Change",
																			statskey: "Requirementchange"
																		}

																	],
																	Remarks: "",
																	Action: [

																		{
																			Atcn: "--Please Select--"

																		}, {
																			Atcn: "Approve",
																			ActnKey: "A"
																		}, {
																			Atcn: "Reject",
																			ActnKey: "R"
																		}

																	]

																}

															]

														};
														var GhdModel = new sap.ui.model.json.JSONModel();
														GhdModel.setData(SamData);
														that.getView().byId("oshmTable").setModel(GhdModel);

													}

												

												} else {
													that.getView().byId("ItemTable1").setMode("None");
												
													that.getView().byId("idSave").setEnabled(false);
													that.getView().byId("oAdditmbtn").setEnabled(false);
													that.getView().byId("edit").setEnabled(false);
													that.getView().byId("idcopy").setEnabled(false);
													that.getView().byId("idedit").setEnabled(false);
												
													that.getView().byId("InputValueAgrmt").setEnabled(false);
													that.getView().byId("InputValuePlnt").setEnabled(false);
													that.getView().byId("InputValueRequr").setEnabled(false);
													that.getView().byId("InputValueBDept").setEnabled(false);
													that.getView().byId("InputValueBU1").setEnabled(false);
													that.getView().byId("idPrType").setEnabled(false);
													that.getView().byId("idPGrp").setEnabled(false);
													that.getView().byId("idReqType").setEnabled(false);
													that.getView().byId("idInputFileNumber").setEnabled(false);

												
													that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
													that.getView().byId("oUndbChecbx").setEnabled(false);
													that.getView().byId("oTxtvalue").setEnabled(false);
													that.getView().byId("idReject").setEnabled(false);
												
													if (that.FilteredghdData.Action == "A") {
														var ActionKey = "A";
														var Action = "Approve";
													} else if (that.FilteredghdData.Action == "R") {
														var ActionKey = "R";
														var Action = "Reject";
													}
													var SamData = {
														data: [{
																Reviewer: "PR Creator/Manager",
																editable: false,
																Status: [

																	{
																		stats: that.FilteredghdData.Status,
																		statskey: that.FilteredghdData.Status
																	}, {
																		stats: that.FilteredghdData.Status,
																		statskey: that.FilteredghdData.Status
																	}

																],
																Remarks: that.FilteredghdData.Remarks,
																Action: [

																	{
																		Atcn: Action,
																		ActnKey: ActionKey
																	}, {
																		Atcn: Action,
																		ActnKey: ActionKey
																	}

																]

															}, {
																Reviewer: "SAM",
																editable: false,
																Status: [{
																		stats: "--Please Select--"

																	}, {
																		stats: "Delivered from Inventory",
																		statskey: "Inventory"
																	}, {
																		stats: "Back to back buy",
																		statskey: "Backtobuy"
																	}, {
																		stats: "Allocated",
																		statskey: "Allocated"
																	}, {
																		stats: "Non Standard",
																		statskey: "Non Standard"
																	}, {
																		stats: "Quote Attached",
																		statskey: "Quuote Attached"
																	}

																],
																Remarks: "",
																Action: [{
																		Atcn: "--Please Select--"

																	}, {
																		Atcn: "Approve",
																		ActnKey: "A"
																	}, {
																		Atcn: "Reject",
																		ActnKey: "R"
																	}

																]

															},

															{
																Reviewer: "Buyer",
																editable: false,
																Status: [{
																		stats: "--Please Select--"

																	},

																	{
																		stats: "Quote attached",
																		statskey: "Quoteattached"
																	}, {
																		stats: "Requirement Change",
																		statskey: "Requirementchange"
																	}

																],
																Remarks: "",
																Action: [

																	{
																		Atcn: "--Please Select--"

																	}, {
																		Atcn: "Approve",
																		ActnKey: "A"
																	}, {
																		Atcn: "Reject",
																		ActnKey: "R"
																	}

																]

															}

														]

													};
													var GhdModel = new sap.ui.model.json.JSONModel();
													GhdModel.setData(SamData);
													that.getView().byId("oshmTable").setModel(GhdModel);

												}
											} else {

						
												that.getView().byId("idSave").setEnabled(false);
												that.getView().byId("oAdditmbtn").setEnabled(false);
												that.getView().byId("edit").setEnabled(false);
												that.getView().byId("idcopy").setEnabled(false);
												that.getView().byId("idedit").setEnabled(false);
						
												that.getView().byId("InputValueAgrmt").setEnabled(false);
												that.getView().byId("InputValuePlnt").setEnabled(false);
												that.getView().byId("InputValueRequr").setEnabled(false);
												that.getView().byId("InputValueBDept").setEnabled(false);
												that.getView().byId("InputValueBU1").setEnabled(false);
												that.getView().byId("idPrType").setEnabled(false);
												that.getView().byId("idPGrp").setEnabled(false);
												that.getView().byId("idReqType").setEnabled(false);
												that.getView().byId("idInputFileNumber").setEnabled(false);

						
												that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
												that.getView().byId("oUndbChecbx").setEnabled(false);
												that.getView().byId("oTxtvalue").setEnabled(false);
												that.getView().byId("idReject").setEnabled(false);
						

												if (that.FilteredghdData.Action == "A") {
													var ActionKey = "A";
													var Action = "Approve";
												} else if (that.FilteredghdData.Action == "R") {
													var ActionKey = "R";
													var Action = "Reject";
												}
												var SamData = {
													data: [{
															Reviewer: "PR Creator/Manager",
															editable: false,
															Status: [

																{
																	stats: that.FilteredghdData.Status,
																	statskey: that.FilteredghdData.Status
																}, {
																	stats: that.FilteredghdData.Status,
																	statskey: that.FilteredghdData.Status
																}

															],
															Remarks: that.FilteredghdData.Remarks,
															Action: [

																{
																	Atcn: Action,
																	ActnKey: ActionKey
																}, {
																	Atcn: Action,
																	ActnKey: ActionKey
																}

															]

														}, {
															Reviewer: "SAM",
															editable: false,
															Status: [{
																	stats: "--Please Select--"

																}, {
																	stats: "Delivered from Inventory",
																	statskey: "Inventory"
																}, {
																	stats: "Back to back buy",
																	statskey: "Backtobuy"
																}, {
																	stats: "Allocated",
																	statskey: "Allocated"
																}, {
																	stats: "Non Standard",
																	statskey: "Non Standard"
																}, {
																	stats: "Quote Attached",
																	statskey: "Quuote Attached"
																}

															],
															Remarks: "",
															Action: [

																{
																	Atcn: "--Please Select--"

																}, {
																	Atcn: "Approve",
																	ActnKey: "A"
																}, {
																	Atcn: "Reject",
																	ActnKey: "R"
																}

															]

														},

														{
															Reviewer: "Buyer",
															editable: false,
															Status: [{
																	stats: "--Please Select--"

																}, {
																	stats: "Quote attached",
																	statskey: "Quoteattached"
																}, {
																	stats: "Requirement Change",
																	statskey: "Requirementchange"
																}

															],
															Remarks: "",
															Action: [{
																	Atcn: "--Please Select--"

																}, {
																	Atcn: "Approve",
																	ActnKey: "A"
																}, {
																	Atcn: "Reject",
																	ActnKey: "R"
																}

															]

														}

													]

												};
												var GhdModel = new sap.ui.model.json.JSONModel();
												GhdModel.setData(SamData);
												that.getView().byId("oshmTable").setModel(GhdModel);

											}*/
					} else if (that.PendingWith == "HAM") {
						var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

						that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

						var path = "/YMM_PR_HAMSet";
						that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

							var oHamsetmodelref = oData.results;
							that.oFilteredHAM = oHamsetmodelref.filter(function (x) {
								return x.AFNAM == that.oLoggeduser;
							});
						}, function (error) {
							that.oFilteredHAM = [];
						});
						if (that.oFilteredHAM.length) {
							if (that.oLoggeduser == that.oFilteredHAM[0].AFNAM) {
								that.getView().byId("ItemTable1").setMode("MultiSelect");

								if (that.oFilteredHAM.length) {
									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									} else if (that.FilteredghdData.Action == "F") {
										var ActionKey = "F";
										var Action = "Forward";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "HAM",
												editable: true,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}, {
														Atcn: "Forward",
														ActnKey: "F"
													}

												],

												Action2: that.getView().getModel("oSecondLevUserslist").getData()

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									if (that.FilteredghdData.Actn === "F") {

										if (that.FilteredghdData.ReviewerStatus === "Inventory") {
											var stats = "Delivered from Inventory";
											var statskey = "Inventory"
										} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
											var stats = "Back to back buy";
											var statskey = "Backtobuy";
										} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
											var stats = "Allocated";
											var statskey = "Allocated";
										} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
											var stats = "Non Standard";
											var statskey = "Non Standard";
										} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
											var stats = "Quote Attached";
											var statskey = "Quuote Attached";
										}

										/*	if (that.FilteredghdData.Approver2Id === "VA3833") {
												var Atcn2 = "Vijay A";
												var ActnKey2 = "VA3833";
											} else if (that.FilteredghdData.Approver2Id === "SC0430") {
												var Atcn2 = "Srinivas Ch";
												var ActnKey2 = "SC0430";
											} else if (that.FilteredghdData.Approver2Id === "BS2931") {
												var Atcn2 = "Basha S";
												var ActnKey2 = "BS2931";
											} else if (that.FilteredghdData.Approver2Id === "DC30338") {
												var Atcn2 = "Denis C";
												var ActnKey2 = "DC30338";
											} else if (that.FilteredghdData.Approver2Id === "SB3817") {
												var Atcn2 = "Suman B";
												var ActnKey2 = "SB3817";
											}*/

										SamData.data.splice(1, 1);
										var Obj = {
											Reviewer: that.FilteredghdData.PendingWith,
											editable: false,
											Status: [{
													stats: stats,
													statskey: statskey
												}, {
													stats: stats,
													statskey: statskey

												}

											],
											Remarks: that.FilteredghdData.ReviewerRem,
											Action2Visible: true,
											Action2: that.getView().getModel("oSecondLevUserslist").getData(),
											ActnKey2: that.FilteredghdData.Approver2Id,
											/*	Action2: [

													{
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}

												],*/

											Action: [

												{
													Atcn: "Forward",
													ActnKey: "F"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											]

										};

										SamData.data.splice(1, 0, Obj);
									}

									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);
									that.getView().byId("idSave").setEnabled(true);

									that.getView().byId("oAdditmbtn").setEnabled(true);
									that.getView().byId("edit").setEnabled(true);
									that.getView().byId("idcopy").setEnabled(true);
									that.getView().byId("idedit").setEnabled(true);
									//that.getView().byId("oidAttach").setEnabled(true);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

									//	that.getView().byId("oFIleuploadrid").setEnabled(true);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(true);
									that.getView().byId("idReject").setEnabled(true);

								} else {
									//Display code
									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									//that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									/* that.getView().byId("idSave").setEnabled(false);*/

									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "HAM",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													},

													{
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

								}

							} else {
								that.getView().byId("ItemTable1").setMode("None");
								//Display code
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								/* that.getView().byId("idSave").setEnabled(false);*/
								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "HAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}
						} else {

							if (that.oFilteredHAM.length == "0") {

								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								} else if (that.FilteredghdData.Action == "F") {
									var ActionKey = "F";
									var Action = "Forward";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action2Visible: false,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "HAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											],
											Action2: that.getView().getModel("oSecondLevUserslist").getData()

											/*Action2: [

												{
													Atcn2: "--Please Select--"

												}, {
													Atcn2: "Vijay A",
													ActnKey2: "VA3833"
												}, {
													Atcn2: "Srinivas Ch",
													ActnKey2: "SC0430"
												}, {
													Atcn2: "Basha S",
													ActnKey2: "BS2931"
												}, {
													Atcn2: "Denis C",
													ActnKey2: "DC30338"
												}, {
													Atcn2: "Suman B",
													ActnKey2: "SB3817"
												}

											]*/

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};

								var GhdModel = new sap.ui.model.json.JSONModel();
								if (that.FilteredghdData.Actn === "F") {

									if (that.FilteredghdData.ReviewerStatus === "Inventory") {
										var stats = "Delivered from Inventory";
										var statskey = "Inventory"
									} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
										var stats = "Back to back buy";
										var statskey = "Backtobuy";
									} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
										var stats = "Allocated";
										var statskey = "Allocated";
									} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
										var stats = "Non Standard";
										var statskey = "Non Standard";
									} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
										var stats = "Quote Attached";
										var statskey = "Quuote Attached";
									}

									/*if (that.FilteredghdData.Approver2Id === "VA3833") {
										var Atcn2 = "Vijay A";
										var ActnKey2 = "VA3833";
									} else if (that.FilteredghdData.Approver2Id === "SC0430") {
										var Atcn2 = "Srinivas Ch";
										var ActnKey2 = "SC0430";
									} else if (that.FilteredghdData.Approver2Id === "BS2931") {
										var Atcn2 = "Basha S";
										var ActnKey2 = "BS2931";
									} else if (that.FilteredghdData.Approver2Id === "DC30338") {
										var Atcn2 = "Denis C";
										var ActnKey2 = "DC30338";
									} else if (that.FilteredghdData.Approver2Id === "SB3817") {
										var Atcn2 = "Suman B";
										var ActnKey2 = "SB3817";
									}*/

									SamData.data.splice(1, 1);
									var Obj = {
										Reviewer: that.FilteredghdData.PendingWith,
										editable: false,
										Status: [{
												stats: stats,
												statskey: statskey
											}, {
												stats: stats,
												statskey: statskey

											}

										],
										Remarks: that.FilteredghdData.ReviewerRem,
										Action2Visible: true,
										Action2: that.getView().getModel("oSecondLevUserslist").getData(),
										ActnKey2: that.FilteredghdData.Approver2Id,

										Action: [

											{
												Atcn: "Forward",
												ActnKey: "F"
											}, {
												Atcn: "Forward",
												ActnKey: "F"
											}

										]

									};

									SamData.data.splice(1, 0, Obj);
								}

								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);
								that.getView().byId("idSave").setEnabled(false);

								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(true);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(true);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);

							} else {

								//Display code
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								/* that.getView().byId("idSave").setEnabled(false);*/

								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "HAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}

						}
						/*if (that.oFilteredHAM.length) {
							if (that.oLoggeduser == that.oFilteredHAM[0].AFNAM) {
								that.getView().byId("ItemTable1").setMode("MultiSelect");

								if (that.oFilteredHAM.length) {
									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									} else if (that.FilteredghdData.Action == "F") {
										var ActionKey = "F";
										var Action = "Forward";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "HAM",
												editable: true,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}, {
														Atcn: "Forward",
														ActnKey: "F"
													}

												],

												Action2: [

													{
														Atcn2: "--Please Select--"

													}, {
														Atcn2: "Vijay A",
														ActnKey2: "VA3833"
													}, {
														Atcn2: "Srinivas Ch",
														ActnKey2: "SC0430"
													}, {
														Atcn2: "Basha S",
														ActnKey2: "BS2931"
													}, {
														Atcn2: "Denis C",
														ActnKey2: "DC30338"
													}, {
														Atcn2: "Uman B",
														ActnKey2: "SB3817"
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
									var GhdModel = new sap.ui.model.json.JSONModel();

									if (that.FilteredghdData.Actn === "F") {

										if (that.FilteredghdData.ReviewerStatus === "Inventory") {
											var stats = "Delivered from Inventory";
											var statskey = "Inventory"
										} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
											var stats = "Back to back buy";
											var statskey = "Backtobuy";
										} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
											var stats = "Allocated";
											var statskey = "Allocated";
										} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
											var stats = "Non Standard";
											var statskey = "Non Standard";
										} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
											var stats = "Quote Attached";
											var statskey = "Quuote Attached";
										}

										if (that.FilteredghdData.Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (that.FilteredghdData.Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (that.FilteredghdData.Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (that.FilteredghdData.Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (that.FilteredghdData.Approver2Id === "SB3817") {
											var Atcn2 = "Uman B";
											var ActnKey2 = "SB3817";
										}

										SamData.data.splice(1, 1);
										var Obj = {
											Reviewer: that.FilteredghdData.PendingWith,
											editable: false,
											Status: [{
													stats: stats,
													statskey: statskey
												}, {
													stats: stats,
													statskey: statskey

												}

											],
											Remarks: that.FilteredghdData.ReviewerRem,
											Action2Visible: true,

											Action2: [

												{
													Atcn2: Atcn2,
													ActnKey2: ActnKey2
												}, {
													Atcn2: Atcn2,
													ActnKey2: ActnKey2
												}, {
													Atcn2: Atcn2,
													ActnKey2: ActnKey2
												}, {
													Atcn2: Atcn2,
													ActnKey2: ActnKey2
												}, {
													Atcn2: Atcn2,
													ActnKey2: ActnKey2
												}

											],

											Action: [

												{
													Atcn: "Forward",
													ActnKey: "F"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											]

										};

										SamData.data.splice(1, 0, Obj);
									}

									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);
									that.getView().byId("idSave").setEnabled(true);

									that.getView().byId("oAdditmbtn").setEnabled(true);
									that.getView().byId("edit").setEnabled(true);
									that.getView().byId("idcopy").setEnabled(true);
									that.getView().byId("idedit").setEnabled(true);
								
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

								
									that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(true);
									that.getView().byId("idReject").setEnabled(true);

								} else {
									that.getView().byId("ItemTable1").setMode("None");
									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
								
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
								
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "HAM",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

								}

							
							} else {
								that.getView().byId("ItemTable1").setMode("None");
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
							
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);
							
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action2Visible: false,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "HAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}
						} else {
							that.getView().byId("ItemTable1").setMode("None");
							that.getView().byId("idSave").setEnabled(false);
							that.getView().byId("oAdditmbtn").setEnabled(false);
							that.getView().byId("edit").setEnabled(false);
							that.getView().byId("idcopy").setEnabled(false);
							that.getView().byId("idedit").setEnabled(false);
							//that.getView().byId("oidAttach").setEnabled(false);
							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);
							// that.getView().byId("InputValuePR").setEnabled(false);
							//that.getView().byId("oFIleuploadrid").setEnabled(false);
							that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
							that.getView().byId("oUndbChecbx").setEnabled(false);
							that.getView().byId("oTxtvalue").setEnabled(false);
							that.getView().byId("idReject").setEnabled(false);
							if (that.FilteredghdData.Action == "A") {
								var ActionKey = "A";
								var Action = "Approve";
							} else if (that.FilteredghdData.Action == "R") {
								var ActionKey = "R";
								var Action = "Reject";
							}
							var SamData = {
								data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [

											{
												stats: that.FilteredghdData.Status,
												statskey: that.FilteredghdData.Status
											}, {
												stats: that.FilteredghdData.Status,
												statskey: that.FilteredghdData.Status
											}

										],
										Remarks: that.FilteredghdData.Remarks,
										Action2Visible: false,
										Action: [

											{
												Atcn: Action,
												ActnKey: ActionKey
											}, {
												Atcn: Action,
												ActnKey: ActionKey
											}

										]

									}, {
										Reviewer: "Ham",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											}, {
												stats: "Delivered from Inventory",
												statskey: "Inventory"
											}, {
												stats: "Back to back buy",
												statskey: "Backtobuy"
											}, {
												stats: "Allocated",
												statskey: "Allocated"
											}, {
												stats: "Non Standard",
												statskey: "Non Standard"
											}, {
												stats: "Quote Attached",
												statskey: "Quuote Attached"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [

											{
												Atcn: "--Please Select--"

											}, {
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									},

									{
										Reviewer: "Buyer",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											}, {
												stats: "Quote attached",
												statskey: "Quoteattached"
											}, {
												stats: "Requirement Change",
												statskey: "Requirementchange"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{
												Atcn: "--Please Select--"

											}, {
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}

								]

							};
							var GhdModel = new sap.ui.model.json.JSONModel();
							GhdModel.setData(SamData);
							that.getView().byId("oshmTable").setModel(GhdModel);

						}*/
					} else if (that.PendingWith == "BUY") {}

				} else {
					if (that.oLoggeduser == that.oPrCreatedby) {
						that.getView().byId("ItemTable1").setMode("MultiSelect");

						that.getView().byId("idSave").setEnabled(true);
						that.getView().byId("oAdditmbtn").setEnabled(true);
						that.getView().byId("edit").setEnabled(true);
						that.getView().byId("idcopy").setEnabled(true);
						that.getView().byId("idedit").setEnabled(true);
						//that.getView().byId("oidAttach").setEnabled(true);
						that.getView().byId("InputValueAgrmt").setEnabled(false);
						that.getView().byId("InputValuePlnt").setEnabled(false);
						that.getView().byId("InputValueRequr").setEnabled(false);
						that.getView().byId("InputValueBDept").setEnabled(false);
						that.getView().byId("InputValueBU1").setEnabled(false);
						that.getView().byId("idPrType").setEnabled(false);
						that.getView().byId("idPGrp").setEnabled(false);
						that.getView().byId("idReqType").setEnabled(false);
						that.getView().byId("idInputFileNumber").setEnabled(false);
						that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
						//	that.getView().byId("oFIleuploadrid").setEnabled(true);
						that.getView().byId("oUndbChecbx").setEnabled(false);
						that.getView().byId("oTxtvalue").setEnabled(true);
						that.getView().byId("idReject").setEnabled(true);
						//	that.getView().byId("ItemTable1").setMode("MultiSelect");

						var SamData = {
							data: [{
									Reviewer: "PR Creator/Manager",
									editable: true,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Forward",
											statskey: "forward"
										}, {
											stats: "No requirement",
											statskey: "Norequirement"
										}

									],
									Remarks: "",
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								}, {
									Reviewer: "SAM",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Delivered from Inventory",
											statskey: "Inventory"
										}, {
											stats: "Back to back buy",
											statskey: "Backtobuy"
										}, {
											stats: "Allocated",
											statskey: "Allocated"
										}, {
											stats: "Non Standard",
											statskey: "Non Standard"
										}, {
											stats: "Quote Attached",
											statskey: "Quuote Attached"
										}

									],
									Remarks: "",
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								},

								{
									Reviewer: "Buyer",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Quote attached",
											statskey: "Quoteattached"
										}, {
											stats: "Requirement Change",
											statskey: "Requirementchange"
										}

									],
									Remarks: "",
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								}

							]

						};
						var GhdModel = new sap.ui.model.json.JSONModel();
						GhdModel.setData(SamData);
						that.getView().byId("oshmTable").setModel(GhdModel);

					} else {
						that.getView().byId("ItemTable1").setMode("None");
						var SamData = {
							data: [{
									Reviewer: "PR Creator/Manager",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Forward",
											statskey: "forward"
										}, {
											stats: "No requirement",
											statskey: "Norequirement"
										}

									],
									Remarks: "",
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								}, {
									Reviewer: "SAM",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Delivered from Inventory",
											statskey: "Inventory"
										}, {
											stats: "Back to back buy",
											statskey: "Backtobuy"
										}, {
											stats: "Allocated",
											statskey: "Allocated"
										}, {
											stats: "Non Standard",
											statskey: "Non Standard"
										}, {
											stats: "Quote Attached",
											statskey: "Quuote Attached"
										}

									],
									Remarks: "",
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								},

								{
									Reviewer: "Buyer",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Quote attached",
											statskey: "Quoteattached"
										}, {
											stats: "Requirement Change",
											statskey: "Requirementchange"
										}

									],
									Remarks: "",
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								}

							]

						};
						var GhdModel = new sap.ui.model.json.JSONModel();
						GhdModel.setData(SamData);
						that.getView().byId("oshmTable").setModel(GhdModel);

						that.getView().byId("idSave").setEnabled(false);
						that.getView().byId("oAdditmbtn").setEnabled(false);
						that.getView().byId("edit").setEnabled(false);
						that.getView().byId("idcopy").setEnabled(false);
						that.getView().byId("idedit").setEnabled(false);
						//that.getView().byId("oidAttach").setEnabled(false);
						that.getView().byId("InputValueAgrmt").setEnabled(false);
						that.getView().byId("InputValuePlnt").setEnabled(false);
						that.getView().byId("InputValueRequr").setEnabled(false);
						that.getView().byId("InputValueBDept").setEnabled(false);
						that.getView().byId("InputValueBU1").setEnabled(false);
						that.getView().byId("idPrType").setEnabled(false);
						that.getView().byId("idPGrp").setEnabled(false);
						that.getView().byId("idReqType").setEnabled(false);
						that.getView().byId("idInputFileNumber").setEnabled(false);
						//that.getView().byId("InputValuePR").setEnabled(false);
						//	that.getView().byId("oFIleuploadrid").setEnabled(false);
						that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
						that.getView().byId("oUndbChecbx").setEnabled(false);
						that.getView().byId("oTxtvalue").setEnabled(false);
						that.getView().byId("idReject").setEnabled(false);
						that.getView().byId("ItemTable1").setMode("None");

					}

				}

				//	var RequestCategory = that.getView().byId("idPrType").getSelectedItem();
				var RequestCategory = that.oEditRequestCategoryDropdown;
				if (RequestCategory) {
					//		RequestCategory = RequestCategory.getText();
					if (RequestCategory == "HARDWARE") {
						if (that.getView().byId("oshmTable").getModel().getData().data.length > 1) {
							that.getView().byId("oshmTable").getModel().getData().data[1].Reviewer = "HAM";
						}
					} else if (RequestCategory == "SOFTWARE") {
						if (that.getView().byId("oshmTable").getModel().getData().data.length > 1) {
							that.getView().byId("oshmTable").getModel().getData().data[1].Reviewer = "SAM";
						}
					} else {
						that.getView().byId("oshmTable").getModel().getData().data.splice(1, 1);
					}
					that.getView().byId("oshmTable").getModel().refresh(true);
				}

			} else {

				if (ghdData.length) {

					if (that.PendingWith == "") {

						if (that.oLoggeduser == that.oPrCreatedby) {
							that.getView().byId("ItemTable1").setMode("MultiSelect");
							var ApprovManager = ghdData.filter(function (x) {
								//	return x.PendingWith == "SAM" || x.PendingWith == "HAM";
								return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
							});

							if (that.oEditDocType === "ZSS") {
								if (ApprovManager[0].Action == "F") {

									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									} else if (ApprovManager[0].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
										ApprovManager[2].Status = ApprovManager[0].ReviewerStatus;
										ApprovManager[2].Remarks = ApprovManager[0].ReviewerRem;

									}

									var ApprovBuyer = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									if (ApprovBuyer[0].Action == "A") {
										var ApprovBuyerActionKey = "A";
										var ApprovBuyerAction = "Approve";
									} else if (ApprovBuyer[0].Action == "R") {
										var ApprovBuyerActionKey = "R";
										var ApprovBuyerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									/*	if (ApprovManager[0].Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (ApprovManager[0].Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (ApprovManager[0].Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (ApprovManager[0].Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (ApprovManager[0].Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}, {
														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}

												],
												Remarks: ApprovManager[1].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: "Approve",
														ActnKey: ApprovManager[1].Action
													}, {
														Atcn: "Approve",
														ActnKey: ApprovManager[1].Action
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: true,

												/*	Action2: [

														{
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}, {
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}, {
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}, {
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}, {
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}

													],*/
												Action2: that.getView().getModel("oSecondLevUserslist").getData(),
												ActnKey2: ApprovSAM[0].Approver2Id,

												Action: [{
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [

													{
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}, {
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}

												],
												Remarks: ApprovBuyer[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									////that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
								} else {
									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}
									var ApprovBuyer = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									if (ApprovBuyer[0].Action == "A") {
										var ApprovBuyerActionKey = "A";
										var ApprovBuyerAction = "Approve";
									} else if (ApprovBuyer[0].Action == "R") {
										var ApprovBuyerActionKey = "R";
										var ApprovBuyerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: false,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [

													{
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}, {
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}

												],
												Remarks: ApprovBuyer[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									////that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);

									//
								}
							} else {
								if (ApprovManager.length > 1) {
									var len = 1;
								} else {
									var len = 0;
								}

								if (ApprovManager[len].Action == "F") {

									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									} else if (ApprovManager[0].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
										ApprovManager[2].Status = ApprovManager[0].ReviewerStatus;
										ApprovManager[2].Remarks = ApprovManager[0].ReviewerRem;

									}

									var ApprovBuyer = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									if (ApprovBuyer[0].Action == "A") {
										var ApprovBuyerActionKey = "A";
										var ApprovBuyerAction = "Approve";
									} else if (ApprovBuyer[0].Action == "R") {
										var ApprovBuyerActionKey = "R";
										var ApprovBuyerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									/*	if (ApprovManager[0].Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (ApprovManager[0].Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (ApprovManager[0].Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (ApprovManager[0].Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (ApprovManager[0].Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}, {
														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}

												],
												Remarks: ApprovManager[1].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: "Approve",
														ActnKey: ApprovManager[1].Action
													}, {
														Atcn: "Approve",
														ActnKey: ApprovManager[1].Action
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: true,
												Action2: that.getView().getModel("oSecondLevUserslist").getData(),
												ActnKey2: ApprovSAM[0].Approver2Id,

												/*	Action2: [

														{
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}, {
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}, {
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}, {
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}, {
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}

													],*/

												Action: [{
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [

													{
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}, {
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}

												],
												Remarks: ApprovBuyer[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									////that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
								} else {
									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}
									var ApprovBuyer = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									if (ApprovBuyer[0].Action == "A") {
										var ApprovBuyerActionKey = "A";
										var ApprovBuyerAction = "Approve";
									} else if (ApprovBuyer[0].Action == "R") {
										var ApprovBuyerActionKey = "R";
										var ApprovBuyerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: false,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [

													{
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}, {
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}

												],
												Remarks: ApprovBuyer[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									////that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);

									//
								}
							}

							/*if (ApprovManager[0].Action == "A") {
								var ApprovManagerActionKey = "A";
								var ApprovManagerAction = "Approve";
							} else if (ApprovManager[0].Action == "R") {
								var ApprovManagerActionKey = "R";
								var ApprovManagerAction = "Reject";
							}
							var ApprovBuyer = ghdData.filter(function (x) {
								return x.PendingWith == "";
							});
							if (ApprovBuyer[0].Action == "A") {
								var ApprovBuyerActionKey = "A";
								var ApprovBuyerAction = "Approve";
							} else if (ApprovBuyer[0].Action == "R") {
								var ApprovBuyerActionKey = "R";
								var ApprovBuyerAction = "Reject";
							}

							var ApprovSAM = ghdData.filter(function (x) {
								return x.PendingWith == "BUY";
							});

							if (ApprovSAM[0].Action == "A") {
								var ApprovSAMManagerActionKey = "A";
								var ApprovSAMManagerAction = "Approve";
							} else if (ApprovSAM[0].Action == "R") {
								var ApprovSAMManagerActionKey = "R";
								var ApprovSAMManagerAction = "Reject";
							}

							var SamData = {
								data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [{

												stats: ApprovManager[0].Status,
												statskey: ApprovManager[0].Status
											}, {
												stats: ApprovManager[0].Status,
												statskey: ApprovManager[0].Status
											}

										],
										Remarks: ApprovManager[0].Remarks,
										Action: [

											{
												Atcn: ApprovManagerAction,
												ActnKey: ApprovManagerActionKey
											}, {
												Atcn: ApprovManagerAction,
												ActnKey: ApprovManagerActionKey
											}

										]

									}, {
										Reviewer: "SAM",
										editable: false,
										Status: [{
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}, {
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}, {
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}, {
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}, {
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}

										],
										Remarks: ApprovSAM[0].Remarks,
										Action: [{
												Atcn: ApprovSAMManagerAction,
												ActnKey: ApprovSAMManagerActionKey
											}, {
												Atcn: ApprovSAMManagerAction,
												ActnKey: ApprovSAMManagerActionKey
											}

										]

									},

									{
										Reviewer: "Buyer",
										editable: false,
										Status: [

											{
												stats: ApprovBuyer[0].Status,
												statskey: ApprovBuyer[0].Status
											}, {
												stats: ApprovBuyer[0].Status,
												statskey: ApprovBuyer[0].Status
											}

										],
										Remarks: ApprovBuyer[0].Remarks,
										Action: [

											{
												Atcn: ApprovSAMManagerAction,
												ActnKey: ApprovSAMManagerActionKey
											}, {
												Atcn: ApprovSAMManagerAction,
												ActnKey: ApprovSAMManagerActionKey
											}

										]

									}

								]

							};

							var GhdModel = new sap.ui.model.json.JSONModel();
							GhdModel.setData(SamData);
							that.getView().byId("oshmTable").setModel(GhdModel);

							that.getView().byId("idSave").setEnabled(false);
							that.getView().byId("oAdditmbtn").setEnabled(false);
							that.getView().byId("edit").setEnabled(false);
							that.getView().byId("idcopy").setEnabled(false);
							that.getView().byId("idedit").setEnabled(false);
						
							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);
						
							that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
							that.getView().byId("oUndbChecbx").setEnabled(false);
							that.getView().byId("oTxtvalue").setEnabled(false);
							that.getView().byId("idReject").setEnabled(false);

						} else {
							that.getView().byId("ItemTable1").setMode("None");
							that.getView().byId("idSave").setEnabled(false);
							that.getView().byId("oAdditmbtn").setEnabled(false);
							that.getView().byId("edit").setEnabled(false);
							that.getView().byId("idcopy").setEnabled(false);
							that.getView().byId("idedit").setEnabled(false);
						
							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);

							that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
							that.getView().byId("oUndbChecbx").setEnabled(false);
							that.getView().byId("oTxtvalue").setEnabled(false);
							that.getView().byId("idReject").setEnabled(false);
							that.getView().byId("ItemTable1").setMode("None");

							var ApprovManager = ghdData.filter(function (x) {
							
								return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
							});

							ApprovManager.sort(function (a, b) {
								return a.CurrentStat - b.CurrentStat;

							})
							if (ApprovManager[0].Action == "A") {
								var ApprovManagerActionKey = "A";
								var ApprovManagerAction = "Approve";
							} else if (ApprovManager[0].Action == "R") {
								var ApprovManagerActionKey = "R";
								var ApprovManagerAction = "Reject";
							}
							var ApprovBuyer = ghdData.filter(function (x) {
								return x.PendingWith == "";
							});
							if (ApprovBuyer[0].Action == "A") {
								var ApprovBuyerActionKey = "A";
								var ApprovBuyerAction = "Approve";
							} else if (ApprovBuyer[0].Action == "R") {
								var ApprovBuyerActionKey = "R";
								var ApprovBuyerAction = "Reject";
							}

							var ApprovSAM = ghdData.filter(function (x) {
								return x.PendingWith == "BUY";
							});

							if (ApprovSAM[0].Action == "A") {
								var ApprovSAMManagerActionKey = "A";
								var ApprovSAMManagerAction = "Approve";
							} else if (ApprovSAM[0].Action == "R") {
								var ApprovSAMManagerActionKey = "R";
								var ApprovSAMManagerAction = "Reject";
							}

							var SamData = {
								data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [{

												stats: ApprovManager[0].Status,
												statskey: ApprovManager[0].Status
											}, {
												stats: ApprovManager[0].Status,
												statskey: ApprovManager[0].Status
											}

										],
										Remarks: ApprovManager[0].Remarks,
										Action: [

											{
												Atcn: ApprovManagerAction,
												ActnKey: ApprovManagerActionKey
											}, {
												Atcn: ApprovManagerAction,
												ActnKey: ApprovManagerActionKey
											}

										]

									}, {
										Reviewer: "SAM",
										editable: false,
										Status: [{
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}, {
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}, {
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}, {
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}, {
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}

										],
										Remarks: ApprovSAM[0].Remarks,
										Action: [{
												Atcn: ApprovSAMManagerAction,
												ActnKey: ApprovSAMManagerActionKey
											}, {
												Atcn: ApprovSAMManagerAction,
												ActnKey: ApprovSAMManagerActionKey
											}

										]

									},

									{
										Reviewer: "Buyer",
										editable: false,
										Status: [

											{
												stats: ApprovBuyer[0].Status,
												statskey: ApprovBuyer[0].Status
											}, {
												stats: ApprovBuyer[0].Status,
												statskey: ApprovBuyer[0].Status
											}

										],
										Remarks: ApprovBuyer[0].Remarks,
										Action: [

											{
												Atcn: ApprovSAMManagerAction,
												ActnKey: ApprovSAMManagerActionKey
											}, {
												Atcn: ApprovSAMManagerAction,
												ActnKey: ApprovSAMManagerActionKey
											}

										]

									}

								]

							};
							var GhdModel = new sap.ui.model.json.JSONModel();
							GhdModel.setData(SamData);
							that.getView().byId("oshmTable").setModel(GhdModel);*/
						} else {

							var ApprovManager = ghdData.filter(function (x) {
								//	return x.PendingWith == "SAM" || x.PendingWith == "HAM";
								return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
							});

							if (that.oEditDocType === "ZSS") {
								if (ApprovManager[0].Action == "F") {

									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									} else if (ApprovManager[0].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
										ApprovManager[2].Status = ApprovManager[0].ReviewerStatus;
										ApprovManager[2].Remarks = ApprovManager[0].ReviewerRem;

									}

									var ApprovBuyer = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									if (ApprovBuyer[0].Action == "A") {
										var ApprovBuyerActionKey = "A";
										var ApprovBuyerAction = "Approve";
									} else if (ApprovBuyer[0].Action == "R") {
										var ApprovBuyerActionKey = "R";
										var ApprovBuyerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									/*	if (ApprovManager[0].Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (ApprovManager[0].Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (ApprovManager[0].Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (ApprovManager[0].Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (ApprovManager[0].Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}, {
														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}

												],
												Remarks: ApprovManager[1].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: "Approve",
														ActnKey: ApprovManager[1].Action
													}, {
														Atcn: "Approve",
														ActnKey: ApprovManager[1].Action
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: true,
												Action2: that.getView().getModel("oSecondLevUserslist").getData(),
												ActnKey2: ApprovSAM[0].Approver2Id,

												/*Action2: [

													{
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}

												],*/

												Action: [{
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [

													{
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}, {
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}

												],
												Remarks: ApprovBuyer[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									////that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
								} else {
									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}
									var ApprovBuyer = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									if (ApprovBuyer[0].Action == "A") {
										var ApprovBuyerActionKey = "A";
										var ApprovBuyerAction = "Approve";
									} else if (ApprovBuyer[0].Action == "R") {
										var ApprovBuyerActionKey = "R";
										var ApprovBuyerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: false,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [

													{
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}, {
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}

												],
												Remarks: ApprovBuyer[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									////that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);

									//
								}
							} else {

								if (ApprovManager.length > 1) {
									var len = 1;
								} else {
									var len = 0;
								}

								if (ApprovManager[len].Action == "F") {

									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									} else if (ApprovManager[0].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
										ApprovManager[2].Status = ApprovManager[0].ReviewerStatus;
										ApprovManager[2].Remarks = ApprovManager[0].ReviewerRem;

									}

									var ApprovBuyer = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									if (ApprovBuyer[0].Action == "A") {
										var ApprovBuyerActionKey = "A";
										var ApprovBuyerAction = "Approve";
									} else if (ApprovBuyer[0].Action == "R") {
										var ApprovBuyerActionKey = "R";
										var ApprovBuyerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									/*	if (ApprovManager[0].Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (ApprovManager[0].Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (ApprovManager[0].Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (ApprovManager[0].Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (ApprovManager[0].Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}, {
														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}

												],
												Remarks: ApprovManager[1].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: "Approve",
														ActnKey: ApprovManager[1].Action
													}, {
														Atcn: "Approve",
														ActnKey: ApprovManager[1].Action
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: true,
												Action2: that.getView().getModel("oSecondLevUserslist").getData(),
												ActnKey2: ApprovSAM[0].Approver2Id,

												/*Action2: [

													{
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}

												],*/

												Action: [{
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [

													{
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}, {
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}

												],
												Remarks: ApprovBuyer[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									////that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
								} else {
									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}
									var ApprovBuyer = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									if (ApprovBuyer[0].Action == "A") {
										var ApprovBuyerActionKey = "A";
										var ApprovBuyerAction = "Approve";
									} else if (ApprovBuyer[0].Action == "R") {
										var ApprovBuyerActionKey = "R";
										var ApprovBuyerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: false,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [

													{
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}, {
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}

												],
												Remarks: ApprovBuyer[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									////that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);

									//
								}
							}

						}

					} else if (that.PendingWith == "PM") {
						var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

						that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

						var path = "/ymm_manager_setSet";
						that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

							var oManagermodelref = oData.results;
							that.oFilteredManager = oManagermodelref.filter(function (x) {
								return x.User == that.oLoggeduser;
							});
						}, function (error) {
							that.oFilteredHAM = [];
						});

						if (that.oFilteredManager.length) {

							if (that.oLoggeduser == that.oFilteredManager[0].User) {
								that.getView().byId("ItemTable1").setMode("MultiSelect");
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: true,
											Status: [{

													stats: "--Please Select--"

												}, {

													stats: "Forward",
													statskey: "forward"
												}, {
													stats: "No requirement",
													statskey: "Norequirement"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{

													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{

													stats: "--Please Select--"

												},

												{
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,

											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

								that.getView().byId("idSave").setEnabled(true);
								that.getView().byId("oAdditmbtn").setEnabled(true);
								that.getView().byId("edit").setEnabled(true);
								that.getView().byId("idcopy").setEnabled(true);
								that.getView().byId("idedit").setEnabled(true);
								//that.getView().byId("oidAttach").setEnabled(true);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(true);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(true);
								that.getView().byId("idReject").setEnabled(true);

							} else {
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								//	that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);

								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Forward",
													statskey: "forward"
												}, {
													stats: "No requirement",
													statskey: "Norequirement"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}
						} else if (that.oLoggeduser == that.oPrCreatedby) { // implementd for Normal PR

							that.getView().byId("idSave").setEnabled(true);
							that.getView().byId("oAdditmbtn").setEnabled(true);
							that.getView().byId("edit").setEnabled(true);
							that.getView().byId("idcopy").setEnabled(true);
							that.getView().byId("idedit").setEnabled(true);
							//that.getView().byId("oidAttach").setEnabled(false);
							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);
							// that.getView().byId("InputValuePR").setEnabled(false);
							//	that.getView().byId("oFIleuploadrid").setEnabled(false);
							that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
							that.getView().byId("oUndbChecbx").setEnabled(true);
							that.getView().byId("oTxtvalue").setEnabled(true);
							that.getView().byId("idReject").setEnabled(true);

							var SamData = {
								data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											},

											{
												stats: "Forward",
												statskey: "forward"
											}, {
												stats: "No requirement",
												statskey: "Norequirement"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{
												Atcn: "--Please Select--"

											},

											{
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}, {
										Reviewer: "SAM",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											},

											{
												stats: "Delivered from Inventory",
												statskey: "Inventory"
											}, {
												stats: "Back to back buy",
												statskey: "Backtobuy"
											}, {
												stats: "Allocated",
												statskey: "Allocated"
											}, {
												stats: "Non Standard",
												statskey: "Non Standard"
											}, {
												stats: "Quote Attached",
												statskey: "Quuote Attached"
											}

										],
										Remarks: "",
										Action2Visible: true,
										Action: [{
												Atcn: "--Please Select--"

											},

											{
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									},

									{
										Reviewer: "Buyer",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											},

											{
												stats: "Quote attached",
												statskey: "Quoteattached"
											}, {
												stats: "Requirement Change",
												statskey: "Requirementchange"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{
												Atcn: "--Please Select--"

											},

											{
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}

								]

							};
							var GhdModel = new sap.ui.model.json.JSONModel();
							GhdModel.setData(SamData);
							that.getView().byId("oshmTable").setModel(GhdModel);

						} else if (that.oLoggeduser != that.oPrCreatedby || that.oLoggeduser != that.oFilteredManager[0].User) {

							that.getView().byId("idSave").setEnabled(false);
							that.getView().byId("oAdditmbtn").setEnabled(false);
							that.getView().byId("edit").setEnabled(false);
							that.getView().byId("idcopy").setEnabled(false);
							that.getView().byId("idedit").setEnabled(false);
							//that.getView().byId("oidAttach").setEnabled(false);
							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);
							// that.getView().byId("InputValuePR").setEnabled(false);
							//	that.getView().byId("oFIleuploadrid").setEnabled(false);
							that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
							that.getView().byId("oUndbChecbx").setEnabled(false);
							that.getView().byId("oTxtvalue").setEnabled(false);
							that.getView().byId("idReject").setEnabled(false);

							var SamData = {
								data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											},

											{
												stats: "Forward",
												statskey: "forward"
											}, {
												stats: "No requirement",
												statskey: "Norequirement"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{
												Atcn: "--Please Select--"

											},

											{
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}, {
										Reviewer: "SAM",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											},

											{
												stats: "Delivered from Inventory",
												statskey: "Inventory"
											}, {
												stats: "Back to back buy",
												statskey: "Backtobuy"
											}, {
												stats: "Allocated",
												statskey: "Allocated"
											}, {
												stats: "Non Standard",
												statskey: "Non Standard"
											}, {
												stats: "Quote Attached",
												statskey: "Quuote Attached"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{
												Atcn: "--Please Select--"

											},

											{
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									},

									{
										Reviewer: "Buyer",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											},

											{
												stats: "Quote attached",
												statskey: "Quoteattached"
											}, {
												stats: "Requirement Change",
												statskey: "Requirementchange"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{
												Atcn: "--Please Select--"

											},

											{
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}

								]

							};
							var GhdModel = new sap.ui.model.json.JSONModel();
							GhdModel.setData(SamData);
							that.getView().byId("oshmTable").setModel(GhdModel);

						}

					} else if (that.PendingWith == "SAM") {

						var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

						that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

						var path = "/YMM_PR_SAMSet";
						that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

							var oHamsetmodelref = oData.results;
							that.oFilteredSAM = oHamsetmodelref.filter(function (x) {
								return x.AFNAM == that.oLoggeduser;
							});
						}, function (error) {
							that.oFilteredSAM = [];
						});
						if (that.oFilteredSAM.length) {
							if (that.oLoggeduser == that.oFilteredSAM[0].AFNAM) {
								that.getView().byId("ItemTable1").setMode("MultiSelect");

								if (that.oFilteredSAM.length) {
									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									} else if (that.FilteredghdData.Action == "F") {
										var ActionKey = "F";
										var Action = "Forward";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: true,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}, {
														Atcn: "Forward",
														ActnKey: "F"
													}

												],

												/*	Action2: [

														{
															Atcn2: "--Please Select--"

														}, {
															Atcn2: "Vijay A",
															ActnKey2: "VA3833"
														}, {
															Atcn2: "Srinivas Ch",
															ActnKey2: "SC0430"
														}, {
															Atcn2: "Basha S",
															ActnKey2: "BS2931"
														}, {
															Atcn2: "Denis C",
															ActnKey2: "DC30338"
														}, {
															Atcn2: "Suman B",
															ActnKey2: "SB3817"
														}

													]*/
												Action2: that.getView().getModel("oSecondLevUserslist").getData()

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									if (that.FilteredghdData.Actn === "F") {

										if (that.FilteredghdData.ReviewerStatus === "Inventory") {
											var stats = "Delivered from Inventory";
											var statskey = "Inventory"
										} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
											var stats = "Back to back buy";
											var statskey = "Backtobuy";
										} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
											var stats = "Allocated";
											var statskey = "Allocated";
										} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
											var stats = "Non Standard";
											var statskey = "Non Standard";
										} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
											var stats = "Quote Attached";
											var statskey = "Quuote Attached";
										}

										/*	if (that.FilteredghdData.Approver2Id === "VA3833") {
												var Atcn2 = "Vijay A";
												var ActnKey2 = "VA3833";
											} else if (that.FilteredghdData.Approver2Id === "SC0430") {
												var Atcn2 = "Srinivas Ch";
												var ActnKey2 = "SC0430";
											} else if (that.FilteredghdData.Approver2Id === "BS2931") {
												var Atcn2 = "Basha S";
												var ActnKey2 = "BS2931";
											} else if (that.FilteredghdData.Approver2Id === "DC30338") {
												var Atcn2 = "Denis C";
												var ActnKey2 = "DC30338";
											} else if (that.FilteredghdData.Approver2Id === "SB3817") {
												var Atcn2 = "Suman B";
												var ActnKey2 = "SB3817";
											}*/

										SamData.data.splice(1, 1);
										var Obj = {
											Reviewer: that.FilteredghdData.PendingWith,
											editable: false,
											Status: [{
													stats: stats,
													statskey: statskey
												}, {
													stats: stats,
													statskey: statskey

												}

											],
											Remarks: that.FilteredghdData.ReviewerRem,
											Action2Visible: true,
											Action2: that.getView().getModel("oSecondLevUserslist").getData(),
											ActnKey2: that.FilteredghdData.Approver2Id,

											Action: [

												{
													Atcn: "Forward",
													ActnKey: "F"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											]

										};

										SamData.data.splice(1, 0, Obj);
									}

									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);
									that.getView().byId("idSave").setEnabled(true);

									that.getView().byId("oAdditmbtn").setEnabled(true);
									that.getView().byId("edit").setEnabled(true);
									that.getView().byId("idcopy").setEnabled(true);
									that.getView().byId("idedit").setEnabled(true);
									//that.getView().byId("oidAttach").setEnabled(true);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

									//	that.getView().byId("oFIleuploadrid").setEnabled(true);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(true);
									that.getView().byId("idReject").setEnabled(true);

								} else {
									//Display code
									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									//that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									/* that.getView().byId("idSave").setEnabled(false);*/

									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													},

													{
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

								}

							} else {
								that.getView().byId("ItemTable1").setMode("None");
								//Display code
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								/* that.getView().byId("idSave").setEnabled(false);*/
								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}
						} else {

							if (that.oFilteredSAM.length == "0") {

								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								} else if (that.FilteredghdData.Action == "F") {
									var ActionKey = "F";
									var Action = "Forward";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action2Visible: false,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											],

											/*	Action2: [

													{
														Atcn2: "--Please Select--"

													}, {
														Atcn2: "Vijay A",
														ActnKey2: "VA3833"
													}, {
														Atcn2: "Srinivas Ch",
														ActnKey2: "SC0430"
													}, {
														Atcn2: "Basha S",
														ActnKey2: "BS2931"
													}, {
														Atcn2: "Denis C",
														ActnKey2: "DC30338"
													}, {
														Atcn2: "Suman B",
														ActnKey2: "SB3817"
													}

												]*/
											Action2: that.getView().getModel("oSecondLevUserslist").getData()

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};

								var GhdModel = new sap.ui.model.json.JSONModel();
								if (that.FilteredghdData.Actn === "F") {

									if (that.FilteredghdData.ReviewerStatus === "Inventory") {
										var stats = "Delivered from Inventory";
										var statskey = "Inventory"
									} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
										var stats = "Back to back buy";
										var statskey = "Backtobuy";
									} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
										var stats = "Allocated";
										var statskey = "Allocated";
									} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
										var stats = "Non Standard";
										var statskey = "Non Standard";
									} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
										var stats = "Quote Attached";
										var statskey = "Quuote Attached";
									}

									/*	if (that.FilteredghdData.Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (that.FilteredghdData.Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (that.FilteredghdData.Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (that.FilteredghdData.Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (that.FilteredghdData.Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

									SamData.data.splice(1, 1);
									var Obj = {
										Reviewer: that.FilteredghdData.PendingWith,
										editable: false,
										Status: [{
												stats: stats,
												statskey: statskey
											}, {
												stats: stats,
												statskey: statskey

											}

										],
										Remarks: that.FilteredghdData.ReviewerRem,
										Action2Visible: true,
										Action2: that.getView().getModel("oSecondLevUserslist").getData(),
										ActnKey2: that.FilteredghdData.Approver2Id,

										Action: [

											{
												Atcn: "Forward",
												ActnKey: "F"
											}, {
												Atcn: "Forward",
												ActnKey: "F"
											}

										]

									};

									SamData.data.splice(1, 0, Obj);
								}

								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);
								that.getView().byId("idSave").setEnabled(false);

								that.getView().byId("oAdditmbtn").setEnabled(true);
								that.getView().byId("edit").setEnabled(true);
								that.getView().byId("idcopy").setEnabled(true);
								that.getView().byId("idedit").setEnabled(true);
								//that.getView().byId("oidAttach").setEnabled(true);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(true);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);

							} else {

								//Display code
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								/* that.getView().byId("idSave").setEnabled(false);*/

								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}

						}
					} else if (that.PendingWith == "HAM") {
						var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

						that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

						var path = "/YMM_PR_HAMSet";
						that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

							var oHamsetmodelref = oData.results;
							that.oFilteredHAM = oHamsetmodelref.filter(function (x) {
								return x.AFNAM == that.oLoggeduser;
							});
						}, function (error) {
							that.oFilteredHAM = [];
						});

						if (that.oFilteredHAM.length) {
							if (that.oLoggeduser == that.oFilteredHAM[0].AFNAM) {
								that.getView().byId("ItemTable1").setMode("MultiSelect");

								if (that.oFilteredHAM.length) {
									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									} else if (that.FilteredghdData.Action == "F") {
										var ActionKey = "F";
										var Action = "Forward";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "HAM",
												editable: true,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}, {
														Atcn: "Forward",
														ActnKey: "F"
													}

												],

												/*Action2: [

													{
														Atcn2: "--Please Select--"

													}, {
														Atcn2: "Vijay A",
														ActnKey2: "VA3833"
													}, {
														Atcn2: "Srinivas Ch",
														ActnKey2: "SC0430"
													}, {
														Atcn2: "Basha S",
														ActnKey2: "BS2931"
													}, {
														Atcn2: "Denis C",
														ActnKey2: "DC30338"
													}, {
														Atcn2: "Suman B",
														ActnKey2: "SB3817"
													}

												]*/
												Action2: that.getView().getModel("oSecondLevUserslist").getData()

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									if (that.FilteredghdData.Actn === "F") {

										if (that.FilteredghdData.ReviewerStatus === "Inventory") {
											var stats = "Delivered from Inventory";
											var statskey = "Inventory"
										} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
											var stats = "Back to back buy";
											var statskey = "Backtobuy";
										} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
											var stats = "Allocated";
											var statskey = "Allocated";
										} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
											var stats = "Non Standard";
											var statskey = "Non Standard";
										} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
											var stats = "Quote Attached";
											var statskey = "Quuote Attached";
										}

										/*	if (that.FilteredghdData.Approver2Id === "VA3833") {
												var Atcn2 = "Vijay A";
												var ActnKey2 = "VA3833";
											} else if (that.FilteredghdData.Approver2Id === "SC0430") {
												var Atcn2 = "Srinivas Ch";
												var ActnKey2 = "SC0430";
											} else if (that.FilteredghdData.Approver2Id === "BS2931") {
												var Atcn2 = "Basha S";
												var ActnKey2 = "BS2931";
											} else if (that.FilteredghdData.Approver2Id === "DC30338") {
												var Atcn2 = "Denis C";
												var ActnKey2 = "DC30338";
											} else if (that.FilteredghdData.Approver2Id === "SB3817") {
												var Atcn2 = "Suman B";
												var ActnKey2 = "SB3817";
											}*/

										SamData.data.splice(1, 1);
										var Obj = {
											Reviewer: that.FilteredghdData.PendingWith,
											editable: false,
											Status: [{
													stats: stats,
													statskey: statskey
												}, {
													stats: stats,
													statskey: statskey

												}

											],
											Remarks: that.FilteredghdData.ReviewerRem,
											Action2Visible: true,
											Action2: that.getView().getModel("oSecondLevUserslist").getData(),
											ActnKey2: that.FilteredghdData.Approver2Id,

											Action: [

												{
													Atcn: "Forward",
													ActnKey: "F"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											]

										};

										SamData.data.splice(1, 0, Obj);
									}

									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);
									that.getView().byId("idSave").setEnabled(true);

									that.getView().byId("oAdditmbtn").setEnabled(true);
									that.getView().byId("edit").setEnabled(true);
									that.getView().byId("idcopy").setEnabled(true);
									that.getView().byId("idedit").setEnabled(true);
									//that.getView().byId("oidAttach").setEnabled(true);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

									//	that.getView().byId("oFIleuploadrid").setEnabled(true);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(true);
									that.getView().byId("idReject").setEnabled(true);

								} else {
									//Display code
									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									//that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									/* that.getView().byId("idSave").setEnabled(false);*/

									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "HAM",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													},

													{
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

								}

							} else {
								that.getView().byId("ItemTable1").setMode("None");
								//Display code
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								/* that.getView().byId("idSave").setEnabled(false);*/
								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "HAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}
						} else {

							if (that.oFilteredHAM.length == "0") {

								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								} else if (that.FilteredghdData.Action == "F") {
									var ActionKey = "F";
									var Action = "Forward";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action2Visible: false,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "HAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											],

											Action2: that.getView().getModel("oSecondLevUserslist").getData()

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};

								var GhdModel = new sap.ui.model.json.JSONModel();
								if (that.FilteredghdData.Actn === "F") {

									if (that.FilteredghdData.ReviewerStatus === "Inventory") {
										var stats = "Delivered from Inventory";
										var statskey = "Inventory"
									} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
										var stats = "Back to back buy";
										var statskey = "Backtobuy";
									} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
										var stats = "Allocated";
										var statskey = "Allocated";
									} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
										var stats = "Non Standard";
										var statskey = "Non Standard";
									} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
										var stats = "Quote Attached";
										var statskey = "Quuote Attached";
									}

									/*if (that.FilteredghdData.Approver2Id === "VA3833") {
										var Atcn2 = "Vijay A";
										var ActnKey2 = "VA3833";
									} else if (that.FilteredghdData.Approver2Id === "SC0430") {
										var Atcn2 = "Srinivas Ch";
										var ActnKey2 = "SC0430";
									} else if (that.FilteredghdData.Approver2Id === "BS2931") {
										var Atcn2 = "Basha S";
										var ActnKey2 = "BS2931";
									} else if (that.FilteredghdData.Approver2Id === "DC30338") {
										var Atcn2 = "Denis C";
										var ActnKey2 = "DC30338";
									} else if (that.FilteredghdData.Approver2Id === "SB3817") {
										var Atcn2 = "Suman B";
										var ActnKey2 = "SB3817";
									}*/

									SamData.data.splice(1, 1);
									var Obj = {
										Reviewer: that.FilteredghdData.PendingWith,
										editable: false,
										Status: [{
												stats: stats,
												statskey: statskey
											}, {
												stats: stats,
												statskey: statskey

											}

										],
										Remarks: that.FilteredghdData.ReviewerRem,
										Action2Visible: true,
										Action2: that.getView().getModel("oSecondLevUserslist").getData(),
										ActnKey2: that.FilteredghdData.Approver2Id,

										Action: [

											{
												Atcn: "Forward",
												ActnKey: "F"
											}, {
												Atcn: "Forward",
												ActnKey: "F"
											}

										]

									};

									SamData.data.splice(1, 0, Obj);
								}

								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);
								that.getView().byId("idSave").setEnabled(false);

								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(true);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(true);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);

							} else {

								//Display code
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								/* that.getView().byId("idSave").setEnabled(false);*/

								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "HAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}

						}

					} else if (that.PendingWith == "BUY") {
						that.getView().byId("ItemTable1").setMode("MultiSelect");

						var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

						that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

						var path = "/YMM_PR_BUYER_IDSet";
						that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

							var oBuyretmodelref = oData.results;
							that.oFilteredBuyer = oBuyretmodelref.filter(function (x) {
								return x.afnam == that.oLoggeduser;
							});
						}, function (error) {
							that.oFilteredBuyer = [];
						});
						if (that.oFilteredBuyer.length) {
							if (that.oLoggeduser == that.oFilteredBuyer[0].afnam) {
								that.getView().byId("ItemTable1").setMode("MultiSelect");

								if (that.oFilteredBuyer.length) {
									var ApprovManager = ghdData.filter(function (x) {
										//	return x.PendingWith == "SAM" || x.PendingWith == "HAM";
										return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
									});

									if (ApprovManager.length > 1) {
										var len = 1;
									} else {
										var len = 0;
									}

									if (ApprovManager[len].Action == "F") {
										ApprovManager.sort(function (a, b) {
											return a.CurrentStat - b.CurrentStat;

										});
										if (ApprovManager[0].Action == "A") {
											var ApprovManagerActionKey = "A";
											var ApprovManagerAction = "Approve";
										} else if (ApprovManager[0].Action == "R") {
											var ApprovManagerActionKey = "R";
											var ApprovManagerAction = "Reject";
										} else if (ApprovManager[0].Action == "F") {
											var ApprovManagerActionKey = "F";
											var ApprovManagerAction = "Forward";
											ApprovManager[2].Status = ApprovManager[0].ReviewerStatus;
											ApprovManager[2].Remarks = ApprovManager[0].ReviewerRem;
											ApprovManager[2].Approver2Id = ApprovManager[0].Approver2Id;

										}
										var ApprovSAM = ghdData.filter(function (x) {
											return x.PendingWith == "BUY";
										});

										if (ApprovSAM[0].Action == "A") {
											var ApprovSAMManagerActionKey = "A";
											var ApprovSAMManagerAction = "Approve";
										} else if (ApprovSAM[0].Action == "R") {
											var ApprovSAMManagerActionKey = "R";
											var ApprovSAMManagerAction = "Reject";
										} else if (ApprovSAM[0].Action == "F") {
											var ApprovSAMManagerActionKey = "F";
											var ApprovSAMManagerAction = "Forward";
											ApprovSAM[0].Status = ApprovManager[0].ReviewerStatus;
											ApprovSAM[0].Remarks = ApprovManager[0].ReviewerRem;
											ApprovSAM[0].Approver2Id = ApprovManager[0].Approver2Id;

										}

										/*	if (ApprovSAM[0].Approver2Id === "VA3833") {
												var Atcn2 = "Vijay A";
												var ActnKey2 = "VA3833";
											} else if (ApprovSAM[0].Approver2Id === "SC0430") {
												var Atcn2 = "Srinivas Ch";
												var ActnKey2 = "SC0430";
											} else if (ApprovSAM[0].Approver2Id === "BS2931") {
												var Atcn2 = "Basha S";
												var ActnKey2 = "BS2931";
											} else if (ApprovSAM[0].Approver2Id === "DC30338") {
												var Atcn2 = "Denis C";
												var ActnKey2 = "DC30338";
											} else if (ApprovSAM[0].Approver2Id === "SB3817") {
												var Atcn2 = "Suman B";
												var ActnKey2 = "SB3817";
											}*/

										var SamData = {
											data: [{
													Reviewer: "PR Creator/Manager",
													editable: false,
													Status: [{

															stats: ApprovManager[1].Status,
															statskey: ApprovManager[1].Status
														}, {
															stats: ApprovManager[1].Status,
															statskey: ApprovManager[1].Status
														}

													],
													Remarks: ApprovManager[1].Remarks,
													Action2Visible: false,
													Action: [

														{
															Atcn: "Approve",
															ActnKey: ApprovSAM[0].Action
														}, {
															Atcn: "Approve",
															ActnKey: ApprovSAM[0].Action
														}

													]

												}, {
													Reviewer: "SAM",
													editable: false,
													Status: [{
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}, {
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}, {
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}, {
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}, {
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}

													],
													Remarks: ApprovSAM[0].Remarks,
													Action2Visible: true,
													Action2: that.getView().getModel("oSecondLevUserslist").getData(),
													ActnKey2: ApprovSAM[0].Approver2Id,

													Action: [{

															Atcn: "Forward",
															ActnKey: ApprovManager[0].Action
														}, {
															Atcn: "Forward",
															ActnKey: ApprovManager[0].Action
														}

													]

												},

												{
													Reviewer: "Buyer",
													editable: true,
													Status: [{
															stats: "--Please Select--"

														}, {
															stats: "Quote attached",
															statskey: "Quoteattached"
														}, {
															stats: "Requirement Change",
															statskey: "Requirementchange"
														}

													],
													Remarks: "",
													Action2Visible: false,
													Action: [{
															Atcn: "--Please Select--"

														},

														{
															Atcn: "Approve",
															ActnKey: "A"
														}, {
															Atcn: "Reject",
															ActnKey: "R"
														}

													]

												}

											]

										};

										var GhdModel = new sap.ui.model.json.JSONModel();
										GhdModel.setData(SamData);
										that.getView().byId("oshmTable").setModel(GhdModel);
										that.getView().byId("idSave").setEnabled(true);
										that.getView().byId("oAdditmbtn").setEnabled(true);
										that.getView().byId("edit").setEnabled(true);
										that.getView().byId("idcopy").setEnabled(true);
										that.getView().byId("idedit").setEnabled(true);
										//that.getView().byId("oidAttach").setEnabled(true);
										that.getView().byId("InputValueAgrmt").setEnabled(false);
										that.getView().byId("InputValuePlnt").setEnabled(false);
										that.getView().byId("InputValueRequr").setEnabled(false);
										that.getView().byId("InputValueBDept").setEnabled(false);
										that.getView().byId("InputValueBU1").setEnabled(false);
										that.getView().byId("idPrType").setEnabled(false);
										that.getView().byId("idPGrp").setEnabled(false);
										that.getView().byId("idReqType").setEnabled(false);
										that.getView().byId("idInputFileNumber").setEnabled(true);

										//that.getView().byId("oFIleuploadrid").setEnabled(true);
										that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
										that.getView().byId("oUndbChecbx").setEnabled(false);
										that.getView().byId("oTxtvalue").setEnabled(true);
										that.getView().byId("idReject").setEnabled(true);

									} else {

										ApprovManager.sort(function (a, b) {
											return a.CurrentStat - b.CurrentStat;

										})
										if (ApprovManager[0].Action == "A") {
											var ApprovManagerActionKey = "A";
											var ApprovManagerAction = "Approve";
										} else if (ApprovManager[0].Action == "R") {
											var ApprovManagerActionKey = "R";
											var ApprovManagerAction = "Reject";
										}
										var ApprovSAM = ghdData.filter(function (x) {
											return x.PendingWith == "BUY";
										});

										if (ApprovSAM[0].Action == "A") {
											var ApprovSAMManagerActionKey = "A";
											var ApprovSAMManagerAction = "Approve";
										} else if (ApprovSAM[0].Action == "R") {
											var ApprovSAMManagerActionKey = "R";
											var ApprovSAMManagerAction = "Reject";
										}

										var SamData = {
											data: [{
													Reviewer: "PR Creator/Manager",
													editable: false,
													Status: [{

															stats: ApprovManager[0].Status,
															statskey: ApprovManager[0].Status
														}, {
															stats: ApprovManager[0].Status,
															statskey: ApprovManager[0].Status
														}

													],
													Remarks: ApprovManager[0].Remarks,
													Action2Visible: false,
													Action: [

														{
															Atcn: ApprovManagerAction,
															ActnKey: ApprovManagerActionKey
														}, {
															Atcn: ApprovManagerAction,
															ActnKey: ApprovManagerActionKey
														}

													]

												}, {
													Reviewer: "SAM",
													editable: false,
													Status: [{
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}, {
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}, {
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}, {
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}, {
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}

													],
													Remarks: ApprovSAM[0].Remarks,
													Action2Visible: false,
													Action: [{
															Atcn: ApprovSAMManagerAction,
															ActnKey: ApprovSAMManagerActionKey
														}, {
															Atcn: ApprovSAMManagerAction,
															ActnKey: ApprovSAMManagerActionKey
														}

													]

												},

												{
													Reviewer: "Buyer",
													editable: true,
													Status: [{
															stats: "--Please Select--"

														}, {
															stats: "Quote attached",
															statskey: "Quoteattached"
														}, {
															stats: "Requirement Change",
															statskey: "Requirementchange"
														}

													],
													Remarks: "",
													Action2Visible: false,
													Action: [{
															Atcn: "--Please Select--"

														},

														{
															Atcn: "Approve",
															ActnKey: "A"
														}, {
															Atcn: "Reject",
															ActnKey: "R"
														}

													]

												}

											]

										};
										var GhdModel = new sap.ui.model.json.JSONModel();
										GhdModel.setData(SamData);
										that.getView().byId("oshmTable").setModel(GhdModel);
										that.getView().byId("idSave").setEnabled(true);
										that.getView().byId("oAdditmbtn").setEnabled(true);
										that.getView().byId("edit").setEnabled(true);
										that.getView().byId("idcopy").setEnabled(true);
										that.getView().byId("idedit").setEnabled(true);
										//that.getView().byId("oidAttach").setEnabled(true);
										that.getView().byId("InputValueAgrmt").setEnabled(false);
										that.getView().byId("InputValuePlnt").setEnabled(false);
										that.getView().byId("InputValueRequr").setEnabled(false);
										that.getView().byId("InputValueBDept").setEnabled(false);
										that.getView().byId("InputValueBU1").setEnabled(false);
										that.getView().byId("idPrType").setEnabled(false);
										that.getView().byId("idPGrp").setEnabled(false);
										that.getView().byId("idReqType").setEnabled(false);
										that.getView().byId("idInputFileNumber").setEnabled(true);

										//that.getView().byId("oFIleuploadrid").setEnabled(true);
										that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
										that.getView().byId("oUndbChecbx").setEnabled(false);
										that.getView().byId("oTxtvalue").setEnabled(true);
										that.getView().byId("idReject").setEnabled(true);

									}

								} else {
									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									//that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									//that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
									var ApprovManager = ghdData.filter(function (x) {
										//	return x.PendingWith == "SAM" || x.PendingWith == "HAM";

										return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
									});

									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}
									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}, {
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													},

													{
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);
								}

								/*	}, function (error) {

									});*/

							} else {
								that.getView().byId("ItemTable1").setMode("None");

								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);
								//that.getView().byId("InputValuePR").setEnabled(false);
								//	that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								var ApprovManager = ghdData.filter(function (x) {
									//	return x.PendingWith == "SAM" || x.PendingWith == "HAM";
									return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
								});
								ApprovManager.sort(function (a, b) {
									return a.CurrentStat - b.CurrentStat;

								});
								if (ApprovManager[0].Action == "A") {
									var ApprovManagerActionKey = "A";
									var ApprovManagerAction = "Approve";
								} else if (ApprovManager[0].Action == "R") {
									var ApprovManagerActionKey = "R";
									var ApprovManagerAction = "Reject";
								}
								var ApprovSAM = ghdData.filter(function (x) {
									return x.PendingWith == "BUY";
								});

								if (ApprovSAM[0].Action == "A") {
									var ApprovSAMManagerActionKey = "A";
									var ApprovSAMManagerAction = "Approve";
								} else if (ApprovSAM[0].Action == "R") {
									var ApprovSAMManagerActionKey = "R";
									var ApprovSAMManagerAction = "Reject";
								}

								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [{

													stats: ApprovManager[0].Status,
													statskey: ApprovManager[0].Status
												}, {
													stats: ApprovManager[0].Status,
													statskey: ApprovManager[0].Status
												}

											],
											Remarks: ApprovManager[0].Remarks,
											Action: [

												{
													Atcn: ApprovManagerAction,
													ActnKey: ApprovManagerActionKey
												}, {
													Atcn: ApprovManagerAction,
													ActnKey: ApprovManagerActionKey
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}, {
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}, {
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}, {
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}, {
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}

											],
											Remarks: ApprovSAM[0].Remarks,
											Action: [{
													Atcn: ApprovSAMManagerAction,
													ActnKey: ApprovSAMManagerActionKey
												}, {
													Atcn: ApprovSAMManagerAction,
													ActnKey: ApprovSAMManagerActionKey
												}

											]

										}, {
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};

								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}
						} else {

							if (that.oFilteredBuyer.length == "0") {
								var ApprovManager = ghdData.filter(function (x) {
									//	return x.PendingWith == "SAM" || x.PendingWith == "HAM";
									return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
								});
								if (ApprovManager.length > 1) {
									var len = 1;
								} else {
									var len = 0;
								}

								if (ApprovManager[len].Action == "F") {
									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});
									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									} else if (ApprovManager[0].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
										ApprovManager[2].Status = ApprovManager[0].ReviewerStatus;
										ApprovManager[2].Remarks = ApprovManager[0].ReviewerRem;
										ApprovManager[2].Approver2Id = ApprovManager[0].Approver2Id;

									}
									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									} else if (ApprovSAM[0].Action == "F") {
										var ApprovSAMManagerActionKey = "F";
										var ApprovSAMManagerAction = "Forward";
										ApprovSAM[0].Status = ApprovManager[0].ReviewerStatus;
										ApprovSAM[0].Remarks = ApprovManager[0].ReviewerRem;
										ApprovSAM[0].Approver2Id = ApprovManager[0].Approver2Id;

									}

									/*if (ApprovSAM[0].Approver2Id === "VA3833") {
										var Atcn2 = "Vijay A";
										var ActnKey2 = "VA3833";
									} else if (ApprovSAM[0].Approver2Id === "SC0430") {
										var Atcn2 = "Srinivas Ch";
										var ActnKey2 = "SC0430";
									} else if (ApprovSAM[0].Approver2Id === "BS2931") {
										var Atcn2 = "Basha S";
										var ActnKey2 = "BS2931";
									} else if (ApprovSAM[0].Approver2Id === "DC30338") {
										var Atcn2 = "Denis C";
										var ActnKey2 = "DC30338";
									} else if (ApprovSAM[0].Approver2Id === "SB3817") {
										var Atcn2 = "Suman B";
										var ActnKey2 = "SB3817";
									}*/

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}, {
														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}

												],
												Remarks: ApprovManager[1].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: "Approve",
														ActnKey: ApprovSAM[0].Action
													}, {
														Atcn: "Approve",
														ActnKey: ApprovSAM[0].Action
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: true,
												Action2: that.getView().getModel("oSecondLevUserslist").getData(),
												ActnKey2: ApprovSAM[0].Approver2Id,

												Action: [{

														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);
									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(true);
									that.getView().byId("edit").setEnabled(true);
									that.getView().byId("idcopy").setEnabled(true);
									that.getView().byId("idedit").setEnabled(true);
									//that.getView().byId("oidAttach").setEnabled(true);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(true);

									//that.getView().byId("oFIleuploadrid").setEnabled(true);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);

								} else {

									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									})
									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}
									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: false,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);
									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(true);
									that.getView().byId("edit").setEnabled(true);
									that.getView().byId("idcopy").setEnabled(true);
									that.getView().byId("idedit").setEnabled(true);
									//that.getView().byId("oidAttach").setEnabled(true);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(true);

									//that.getView().byId("oFIleuploadrid").setEnabled(true);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);

								}

							} else {

								that.getView().byId("ItemTable1").setMode("None");

								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);
								//that.getView().byId("InputValuePR").setEnabled(false);
								//	that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								var ApprovManager = ghdData.filter(function (x) {
									//	return x.PendingWith == "SAM" || x.PendingWith == "HAM";
									return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
								});
								ApprovManager.sort(function (a, b) {
									return a.CurrentStat - b.CurrentStat;

								});
								if (ApprovManager[0].Action == "A") {
									var ApprovManagerActionKey = "A";
									var ApprovManagerAction = "Approve";
								} else if (ApprovManager[0].Action == "R") {
									var ApprovManagerActionKey = "R";
									var ApprovManagerAction = "Reject";
								}
								var ApprovSAM = ghdData.filter(function (x) {
									return x.PendingWith == "BUY";
								});

								if (ApprovSAM[0].Action == "A") {
									var ApprovSAMManagerActionKey = "A";
									var ApprovSAMManagerAction = "Approve";
								} else if (ApprovSAM[0].Action == "R") {
									var ApprovSAMManagerActionKey = "R";
									var ApprovSAMManagerAction = "Reject";
								}

								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [{

													stats: ApprovManager[0].Status,
													statskey: ApprovManager[0].Status
												}, {
													stats: ApprovManager[0].Status,
													statskey: ApprovManager[0].Status
												}

											],
											Remarks: ApprovManager[0].Remarks,
											Action: [

												{
													Atcn: ApprovManagerAction,
													ActnKey: ApprovManagerActionKey
												}, {
													Atcn: ApprovManagerAction,
													ActnKey: ApprovManagerActionKey
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}, {
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}, {
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}, {
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}, {
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}

											],
											Remarks: ApprovSAM[0].Remarks,
											Action: [{
													Atcn: ApprovSAMManagerAction,
													ActnKey: ApprovSAMManagerActionKey
												}, {
													Atcn: ApprovSAMManagerAction,
													ActnKey: ApprovSAMManagerActionKey
												}

											]

										}, {
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};

								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}

						}
					}
				} else {
					if (that.oLoggeduser == that.oPrCreatedby) {
						that.getView().byId("ItemTable1").setMode("MultiSelect");

						that.getView().byId("idSave").setEnabled(true);
						that.getView().byId("oAdditmbtn").setEnabled(true);
						that.getView().byId("edit").setEnabled(true);
						that.getView().byId("idcopy").setEnabled(true);
						that.getView().byId("idedit").setEnabled(true);
						//that.getView().byId("oidAttach").setEnabled(true);
						that.getView().byId("InputValueAgrmt").setEnabled(true);
						that.getView().byId("InputValuePlnt").setEnabled(true);
						that.getView().byId("InputValueRequr").setEnabled(true);
						that.getView().byId("InputValueBDept").setEnabled(true);
						that.getView().byId("InputValueBU1").setEnabled(true);
						that.getView().byId("idPrType").setEnabled(true);
						that.getView().byId("idPGrp").setEnabled(true);
						that.getView().byId("idReqType").setEnabled(true);
						that.getView().byId("idInputFileNumber").setEnabled(true);
						that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
						//	that.getView().byId("oFIleuploadrid").setEnabled(true);
						that.getView().byId("oUndbChecbx").setEnabled(true);
						that.getView().byId("oTxtvalue").setEnabled(true);
						that.getView().byId("idReject").setEnabled(true);
						//	that.getView().byId("ItemTable1").setMode("MultiSelect");

						var SamData = {
							data: [{
									Reviewer: "PR Creator/Manager",
									editable: true,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Forward",
											statskey: "forward"
										}, {
											stats: "No requirement",
											statskey: "Norequirement"
										}

									],
									Remarks: "",
									Action2Visible: false,
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								}, {
									Reviewer: "SAM",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Delivered from Inventory",
											statskey: "Inventory"
										}, {
											stats: "Back to back buy",
											statskey: "Backtobuy"
										}, {
											stats: "Allocated",
											statskey: "Allocated"
										}, {
											stats: "Non Standard",
											statskey: "Non Standard"
										}, {
											stats: "Quote Attached",
											statskey: "Quuote Attached"
										}

									],
									Remarks: "",
									Action2Visible: false,
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								},

								{
									Reviewer: "Buyer",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Quote attached",
											statskey: "Quoteattached"
										}, {
											stats: "Requirement Change",
											statskey: "Requirementchange"
										}

									],
									Remarks: "",
									Action2Visible: false,
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								}

							]

						};
						var GhdModel = new sap.ui.model.json.JSONModel();
						GhdModel.setData(SamData);
						that.getView().byId("oshmTable").setModel(GhdModel);

					} else {
						that.getView().byId("ItemTable1").setMode("None");
						var SamData = {
							data: [{
									Reviewer: "PR Creator/Manager",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Forward",
											statskey: "forward"
										}, {
											stats: "No requirement",
											statskey: "Norequirement"
										}

									],
									Remarks: "",
									Action2Visible: false,
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								}, {
									Reviewer: "SAM",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Delivered from Inventory",
											statskey: "Inventory"
										}, {
											stats: "Back to back buy",
											statskey: "Backtobuy"
										}, {
											stats: "Allocated",
											statskey: "Allocated"
										}, {
											stats: "Non Standard",
											statskey: "Non Standard"
										}, {
											stats: "Quote Attached",
											statskey: "Quuote Attached"
										}

									],
									Remarks: "",
									Action2Visible: false,
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								},

								{
									Reviewer: "Buyer",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Quote attached",
											statskey: "Quoteattached"
										}, {
											stats: "Requirement Change",
											statskey: "Requirementchange"
										}

									],
									Remarks: "",
									Action2Visible: false,
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								}

							]

						};
						var GhdModel = new sap.ui.model.json.JSONModel();
						GhdModel.setData(SamData);
						that.getView().byId("oshmTable").setModel(GhdModel);

						that.getView().byId("idSave").setEnabled(false);
						that.getView().byId("oAdditmbtn").setEnabled(false);
						that.getView().byId("edit").setEnabled(false);
						that.getView().byId("idcopy").setEnabled(false);
						that.getView().byId("idedit").setEnabled(false);
						//that.getView().byId("oidAttach").setEnabled(false);
						that.getView().byId("InputValueAgrmt").setEnabled(false);
						that.getView().byId("InputValuePlnt").setEnabled(false);
						that.getView().byId("InputValueRequr").setEnabled(false);
						that.getView().byId("InputValueBDept").setEnabled(false);
						that.getView().byId("InputValueBU1").setEnabled(false);
						that.getView().byId("idPrType").setEnabled(false);
						that.getView().byId("idPGrp").setEnabled(false);
						that.getView().byId("idReqType").setEnabled(false);
						that.getView().byId("idInputFileNumber").setEnabled(false);
						//that.getView().byId("InputValuePR").setEnabled(false);
						//	that.getView().byId("oFIleuploadrid").setEnabled(false);
						that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
						that.getView().byId("oUndbChecbx").setEnabled(false);
						that.getView().byId("oTxtvalue").setEnabled(false);
						that.getView().byId("idReject").setEnabled(false);
						that.getView().byId("ItemTable1").setMode("None");

					}

				}

				//		var RequestCategory = that.getView().byId("idPrType").getSelectedItem();
				var RequestCategory = that.oEditRequestCategoryDropdown;
				if (RequestCategory) {
					//	RequestCategory = RequestCategory.getText();
					if (RequestCategory == "HARDWARE") {
						that.getView().byId("oshmTable").getModel().getData().data[1].Reviewer = "HAM";
					} else if (RequestCategory == "SOFTWARE") {
						that.getView().byId("oshmTable").getModel().getData().data[1].Reviewer = "SAM";
					} else {
						that.getView().byId("oshmTable").getModel().getData().data.splice(1, 1);
					}
					that.getView().byId("oshmTable").getModel().refresh(true);
				}

			}

			// var oPurReq = oEvent.oSource.getSelectedItem().mProperties.text;

			if (this.oSelectedMatcode) {
				this.productInputBuDp = sap.ui.getCore().byId("InputValueMatDesc");
				this.productInputBuDp.setValue(this.oSelectedMatcode);

			}
			//	oEvent.getSource().getBinding("items").filter([]);
			//	sap.ui.core.BusyIndicator.hide();
			//  that.listbusydialog.close();
			//	this.getAttachMents(oPrnumber);

			this.onShmTableUpdate();

		},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf P2P.view.Detailed
		 */
		onExit: function () {

			if (this._oDialog) {
				this._oDialog.destroy();
			}

		},

		onShmTableUpdate: function () {
			var oTableitems = this.getView().byId("ItemTable1").getItems();

			for (var h = 0; h < oTableitems.length; h++) {
				if (oTableitems[h].getBindingContext().getObject().DeleteIndicator == false) {
					this.getView().byId("ItemTable1").getItems()[h].setVisible(true);
				} else {
					this.getView().byId("ItemTable1").getItems()[h].setVisible(false);
				}
			}
			//	this.getView().byId("ItemTable1").getModel().refresh(true);
			this.TotalValCal();
		},
		/*********************************DATA*******************************/
		/*
		{
		  "@base": "http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/",
		  "id": "http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/PR_HeaderSet",
		  "title": "PR_HeaderSet",
		  "updated": "2019-12-20T09:55:42Z",
		  "category": {
		     "@term": "YMM_PR_CREATION_ASSOCIATION_SRV.PR_Header",
		     "@scheme": "http://schemas.microsoft.com/ado/2007/08/dataservices/scheme"
		  },
		  "link": [
		     {
		        "@href": "PR_HeaderSet",
		        "@rel": "self",
		        "@title": "PR_Header"
		     },
		     {
		        "@href": "PR_HeaderSet/PR_ItemSet",
		        "@rel": "http://schemas.microsoft.com/ado/2007/08/dataservices/related/PR_ItemSet",
		        "@title": "PR_ItemSet",
		        "inline": {
		           "feed": {
		              "@base": "http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/",
		              "id": "http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/PR_HeaderSet/PR_ItemSet",
		              "title": "PR_ItemSet",
		              "updated": "2019-12-20T09:55:42Z",
		              "author": {
		                 "name": null
		              },
		              "link": {
		                 "@href": "PR_HeaderSet/PR_ItemSet",
		                 "@rel": "self",
		                 "@title": "PR_ItemSet"
		              },
		              "entry": {
		                 "id": "http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/PR_ItemSet",
		                 "title": "PR_ItemSet",
		                 "updated": "2019-12-20T09:55:42Z",
		                 "category": {},
		                 "link": {},
		                 "content": {
		                    "properties": {
		                       "Itemtext": "",
		                       "PreqNo": "",
		                       "DeleteIndicator": "false",
		                       "Pstyp": "0",
		                       "Bednr": "",
		                       "PreqItem": "00010",
		                       "DocType": "ZSM",
		                       "Konnr": "",
		                       "Banpr": "03",
		                       "PurGroup": "101",
		                       "Blckd": "",
		                       "PreqDate": "2019-06-06T00:00:00",
		                       "Blckt": "",
		                       "Plant": "1000",
		                       "AccountType": "K",
		                       "Vbeln": "",
		                       "CostCtr": "1000000001",
		                       "Vbelp": "000000",
		                       "Anln1": "",
		                       "WbsElem": "00000000",
		                       "Requisitioner": "80",
		                       "MaterialDesc": "ABBYY_Perpetual License",
		                       "Material": "1700011",
		                       "MatGrp": "50000",
		                       "Quantity": "106.000",
		                       "Unit": "EA",
		                       "DelivDate": "2019-04-17T00:00:00",
		                       "UnitPrice": "100.000000000",
		                       "Currency": "INR",
		                       "Zzbu": "AD",
		                       "ZzbuDesc": "A&D",
		                       "ZzdeptCode": "ZZ",
		                       "ZzdeptDesc": "ZZDLM",
		                       "ZzdeptCode2": "AD",
		                       "ZzdeptDesc2": "A&D",
		                       "ZzaprL3": "RU0895",
		                       "ZzaprL3Name": "RK",
		                       "ZzassName2": "SANTOSH REDDY PATLOLLA",
		                       "Sakto": "4141120010",
		                       "Zzcategoty": "SOFTWARE"
		                    }
		                 }
		              }
		           }
		        }
		     }
		  ],
		  "content": {
		     "properties": {
		        "Banfn": "",
		        "Bsart": ""
		     }
		  }
		}
		Search helps

		https://webidetesting9822649-l577e310e.dispatcher.ae1.hana.ondemand.com/





		https://webidetesting9822649-l577e310e.dispatcher.ae1.hana.ondemand.com/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ZmmshBuSet





		1.       BU(F4):

		http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ZmmshBuSet

		2.       Business Dept. (F4): http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ZmmshDeptCode2Set

		3.       BU Approver (F4): http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ZmmshDeptCode2Set

		4.       Requisationer  (F4):

		http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ZmmshAfnamSet

		5.       Manger (F4)

		http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ZmmshAfnamSet

		6.        Material Code ( F4) / Service Code (F4)

		http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ymmsh_materialSet

		7.       Material group  (F4)  / Service Group(F4)

		http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/MMPUR_REQ_SSP_MAINTAIN_SRV/ymm_sh_glSet

		8.       UOM:

		http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/MMPUR_REQ_SSP_MAINTAIN_SRV/I_UnitOfMeasure

		9.       Currency:

		http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/MMPUR_REQ_SSP_MAINTAIN_SRV/I_Currency

		10.   CC:

		http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ymmsh_CostCenterSet

		\&nbsp;

		11.   WBS:

		http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ymmsh_WBSSet



		*/
		/* ********************************** XML Payload*******************************************************
		<?xml version="1.0" encoding="utf-8"?>
		<entry xml:base="http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/" xmlns="http://www.w3.org/2005/Atom" xmlns:m="http://schemas.microsoft.com/ado/2007/08/dataservices/metadata" xmlns:d="http://schemas.microsoft.c+
+
om/ado/2007/08/dataservices">
		<id>http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/PR_HeaderSet('30000388')</id>
		<title type="text">PR_HeaderSet('30000388')</title>
		<updated>2020-01-21T09:13:33Z</updated>
		<category term="YMM_PR_CREATION_ASSOCIATION_SRV.PR_Header" scheme="http://schemas.microsoft.com/ado/2007/08/dataservices/scheme"/>
		<link href="PR_HeaderSet('30000388')" rel="self" title="PR_Header"/>
		<link href="PR_HeaderSet('30000388')/PR_ItemSet" rel="http://schemas.microsoft.com/ado/2007/08/dataservices/related/PR_ItemSet" type="application/atom+xml;type=feed" title="PR_ItemSet">
		 <m:inline>
		  <feed xml:base="http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/">
		   <id>http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/PR_HeaderSet('30000388')/PR_ItemSet</id>
		   <title type="text">PR_ItemSet</title>
		   <updated>2020-01-21T09:13:33Z</updated>
		   <author>
		    <name/>
		   </author>
		   <link href="PR_HeaderSet('30000388')/PR_ItemSet" rel="self" title="PR_ItemSet"/>
		   <entry>
		    <id>http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/PR_ItemSet(PreqNo='30000388',PreqItem='00010')</id>
		    <title type="text">PR_ItemSet(PreqNo='30000388',PreqItem='00010')</title>
		    <updated>2020-01-21T09:13:33Z</updated>
		    <category term="YMM_PR_CREATION_ASSOCIATION_SRV.PR_Item" scheme="http://schemas.microsoft.com/ado/2007/08/dataservices/scheme"/>
		    <link href="PR_ItemSet(PreqNo='30000388',PreqItem='00010')" rel="self" title="PR_Item"/>
		    <content type="application/xml">
		     <m:properties>
		      <d:PreqNo></d:PreqNo>
		      <d:Itemtext/>
		      <d:DeleteIndicator>false</d:DeleteIndicator>
		      <d:Pstyp>0</d:Pstyp>
		      <d:Bednr/>
		      <d:PreqItem>00010</d:PreqItem>
		      <d:DocType>ZSM</d:DocType>
		      <d:Konnr/>
		      <d:Banpr>03</d:Banpr>
		      <d:PurGroup>101</d:PurGroup>
		      <d:Blckd/>
		      <d:PreqDate>2019-06-06T00:00:00</d:PreqDate>
		      <d:Blckt/>
		      <d:Plant>1000</d:Plant>
		      <d:AccountType>K</d:AccountType>
		      <d:Vbeln/>
		      <d:CostCtr>1000000001</d:CostCtr>
		      <d:Vbelp>000000</d:Vbelp>
		      <d:Anln1/>
		      <d:WbsElem>00000000</d:WbsElem>
		      <d:Requisitioner>80</d:Requisitioner>
		      <d:MaterialDesc>ABBYY_Perpetual License</d:MaterialDesc>
		      <d:Material>1700011</d:Material>
		      <d:MatGrp>50000</d:MatGrp>
		      <d:Quantity>106.000</d:Quantity>
		      <d:Unit>EA</d:Unit>
		      <d:DelivDate>2019-04-17T00:00:00</d:DelivDate>
		      <d:UnitPrice>100.000000000</d:UnitPrice>
		      <d:Currency>INR</d:Currency>
		      <d:Zzbu>AD</d:Zzbu>
		      <d:ZzbuDesc>A&amp;D</d:ZzbuDesc>
		      <d:ZzdeptCode>ZZ</d:ZzdeptCode>
		      <d:ZzdeptDesc>ZZDLM</d:ZzdeptDesc>
		      <d:ZzdeptCode2>AD</d:ZzdeptCode2>
		      <d:ZzdeptDesc2>A&amp;D</d:ZzdeptDesc2>
		      <d:ZzaprL3>RU0895</d:ZzaprL3>
		      <d:ZzaprL3Name>RK</d:ZzaprL3Name>
		      <d:ZzassName2>SANTOSH REDDY PATLOLLA</d:ZzassName2>
		      <d:Sakto>4141120010</d:Sakto>
		      <d:Zzcategoty>SOFTWARE</d:Zzcategoty>
		     </m:properties>
		    </content>
		   </entry>
		   <entry>
		    <id>http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/PR_ItemSet(PreqNo='30000388',PreqItem='00010')</id>
		    <title type="text">PR_ItemSet(PreqNo='30000388',PreqItem='00010')</title>
		    <updated>2020-01-21T09:13:33Z</updated>
		    <category term="YMM_PR_CREATION_ASSOCIATION_SRV.PR_Item" scheme="http://schemas.microsoft.com/ado/2007/08/dataservices/scheme"/>
		    <link href="PR_ItemSet(PreqNo='30000388',PreqItem='00010')" rel="self" title="PR_Item"/>
		    <content type="application/xml">
		     <m:properties>
		      <d:PreqNo></d:PreqNo>
		      <d:Itemtext/>
		      <d:DeleteIndicator>false</d:DeleteIndicator>
		      <d:Pstyp>0</d:Pstyp>
		      <d:Bednr/>
		      <d:PreqItem>00020</d:PreqItem>
		      <d:DocType>ZSM</d:DocType>
		      <d:Konnr/>
		      <d:Banpr>03</d:Banpr>
		      <d:PurGroup>101</d:PurGroup>
		      <d:Blckd/>
		      <d:PreqDate>2019-06-06T00:00:00</d:PreqDate>
		      <d:Blckt/>
		      <d:Plant>1000</d:Plant>
		      <d:AccountType>K</d:AccountType>
		      <d:Vbeln/>
		      <d:CostCtr>1000000001</d:CostCtr>
		      <d:Vbelp>000000</d:Vbelp>
		      <d:Anln1/>
		      <d:WbsElem>00000000</d:WbsElem>
		      <d:Requisitioner>80</d:Requisitioner>
		      <d:MaterialDesc>ABBYY_Perpetual License</d:MaterialDesc>
		      <d:Material>1700011</d:Material>
		      <d:MatGrp>50000</d:MatGrp>
		      <d:Quantity>106.000</d:Quantity>
		      <d:Unit>EA</d:Unit>
		      <d:DelivDate>2019-04-17T00:00:00</d:DelivDate>
		      <d:UnitPrice>100.000000000</d:UnitPrice>
		      <d:Currency>INR</d:Currency>
		      <d:Zzbu>AD</d:Zzbu>
		      <d:ZzbuDesc>A&amp;D</d:ZzbuDesc>
		      <d:ZzdeptCode>ZZ</d:ZzdeptCode>
		      <d:ZzdeptDesc>ZZDLM</d:ZzdeptDesc>
		      <d:ZzdeptCode2>AD</d:ZzdeptCode2>
		      <d:ZzdeptDesc2>A&amp;D</d:ZzdeptDesc2>
		      <d:ZzaprL3>RU0895</d:ZzaprL3>
		      <d:ZzaprL3Name>RK</d:ZzaprL3Name>
		      <d:ZzassName2>SANTOSH REDDY PATLOLLA</d:ZzassName2>
		      <d:Sakto>4141120010</d:Sakto>
		      <d:Zzcategoty>SOFTWARE</d:Zzcategoty>
		     </m:properties>
		    </content>
		   </entry>
		  </feed>
		 </m:inline>
		</link>
		<content type="application/xml">
		 <m:properties>
		  <d:Banfn>30000388</d:Banfn>
		  <d:Bsart>ZSM</d:Bsart>
		 </m:properties>
		</content>
		</entry>
		******************************************************************************/

		/* onPREdit: function (oEvt) {

		var Delete_dialog = new sap.m.Dialog({
		title: '',
		type: 'Message',

		content: new sap.m.Text({
		text: 'Do you want to Edit PR?'
		}),
		beginButton: new sap.m.Button({
		text: 'Yes',
		press: function () {

		Delete_dialog.close();

		}



		}),
		endButton: new sap.m.Button({
		text: 'No',
		press: function () {
		Delete_dialog.close();
		}
		})
		});
		Delete_dialog.open();

		},*/
		onPREdit: function () {

			this.getView().byId("oidPurrequsitn").setVisible(true);
			this.getView().byId("InputValuePR").setVisible(true);

		},

		/***************************PR List Search help Start*******************************************/
		handleValueHelpPR: function (oEvent) {

			var sInputValue_Pr = oEvent.getSource().getValue();
			if (!this._valueHelpDialog_Pr) {
				this._valueHelpDialog_Pr = sap.ui.xmlfragment(
					"P2P.Fragment.PRList",
					this
				);
				this.getView().addDependent(this._valueHelpDialog_Pr);
			}
			var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

			var that = this;
			that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);
			var path = "/YmmshPrSet";
			that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

				that.oObjemodelx = oData.results;

				/*	that.getOwnerComponent().oObjemodelx = that.oObjemodelx;*/

				//	var oPRDetailsModelref = new sap.ui.model.json.JSONModel(that.oObjemodelx.oObjemodelx);
				var oPRDetailsModelref = new sap.ui.model.json.JSONModel(that.oObjemodelx);
				oPRDetailsModelref.setSizeLimit(100000);

				sap.ui.getCore().byId("oPrListFrag").setModel(oPRDetailsModelref);
				that._valueHelpDialog_Pr.open(sInputValue_Pr);
			}, function (error) {

			});

		},

		getBusyindicator: function (oEvent) {
			this.oBusyIn = new sap.m.BusyDialog();
			this.oBusyIn.open(true);

		},
		//PR List Fragment Confirm Press event Start
		onPrdesConfirm: function (oEvent) {

			this.getBusyindicator();
			this.oBusyIn.setBusyIndicatorDelay(20000);
			this.getView().byId("idSave").setEnabled(true);
			this.getView().byId("idReject").setEnabled(true);

			var model = new sap.ui.model.json.JSONModel([]);
			oMessagePopover.setModel(model);
			//	oMessagePopover.toggle(that.getView().byId("ErrorMessages"));
			var viewModel = new sap.ui.model.json.JSONModel();
			viewModel.setData({
				messagesLength: 0 + ''
			});

			this.getView().setModel(viewModel);

			//	sap.ui.core.BusyIndicator.show();
	       this.oTab();
			var that = this;
		
			//that.getView().byId("idIconTabBarNoIcons").setSelectedKey("1");

			//	that.getView().byId("idIconTabBarNoIcons").setExpanded(true).mForwardedAggregations.items[1];

			/*	that.listbusydialog = new sap.m.BusyDialog({
				text: 'Data load in progress...'		
						});
						that.listbusydialog.open();*/
			that.getView().byId("InputValuePR").setValueState("None");
			that.getView().byId("itemdetailsErrMsgStrip").setProperty("visible", false);
			that.getView().byId("oshmTable").setVisible(true);
			var oPrnumber = oEvent.getParameter("selectedItem").getBindingContext().getObject().Banfn;
			that.oPrCreatedby = oEvent.getParameter("selectedItem").getBindingContext().getObject().Ernam;

			var readRequesinglePR = "/PR_HeaderSet('" + oPrnumber + "')?$expand=YMM_FIORI_LOGSet";
			that.oModelunlockCreate.read(readRequesinglePR, null, null, false, function (oData, oRespone) {

				//	this.oModelunlockCreate.read("/YMM_FIORI_LOGSet", null, null, false, function (oData, oRespone) {
				var Data = oData.YMM_FIORI_LOGSet.results;
				that.oFioriLogmodlref = Data;

			}, function (error) {
				that.oFioriLogmodlref = [];
			});
			that.onForwardUserdetails();
			// that.getBusyindicator();
			var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

			that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);
			/* var oObject =  oPurReq;*/
			var readRequestURL2 = "/PR_HeaderSet('" + oPrnumber + "')?$expand=PR_ItemSet";
			that.oDataModel.read(readRequestURL2, null, null, false, function (oData, oResponse) {

				var oObjemodel2 = oData.PR_ItemSet.results;

				//var ghdObject=ghdData.filter(function(x){return x.})
				var oEditTableModel2 = new sap.ui.model.json.JSONModel(oObjemodel2);

				//that.getView().byId("idRequisition").setModel(oEditTableModel2);

				oEditTableModel2.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
				that.getView().byId("InputValuePR").setValue(oPrnumber);
				that.getView().byId("ItemTable1").setModel(oEditTableModel2);
				that.onShmTableUpdate();
				that.TotalValCal();
				that.oEditBussiUnit = oEditTableModel2.oData[0].Zzbu;
				that.oEditBusedept = oEditTableModel2.oData[0].ZzbuDesc;
				that.oEditBusedeptdesc = oEditTableModel2.oData[0].ZzdeptDesc2;
				that.oEditBussinessdeptcode = oEditTableModel2.oData[0].ZzdeptCode2;
				that.oEditDocType = oEditTableModel2.oData[0].DocType; //Request type
				that.oEditAccountType = oEditTableModel2.oData[0].AccountType; //Expense type
				that.oEditZzaprL3Name = oEditTableModel2.oData[0].ZzaprL3Name;
				that.oEditZzaprL3 = oEditTableModel2.oData[0].ZzaprL3;
				that.oEditRequisitioner = oEditTableModel2.oData[0].Requisitioner;
				that.oEditZzassName2 = oEditTableModel2.oData[0].ZzassName2;
				that.oEditZzassName2 = oEditTableModel2.oData[0].ZzassName2;
				that.oEditPlant = oEditTableModel2.oData[0].Plant;
				that.oEditRequestCategoryDropdown = oEditTableModel2.oData[0].ReqCategory;
				that.oEditRequestCategory = oEditTableModel2.oData[0].PurGroup;
				that.oEditText = oEditTableModel2.oData[0].Headertext;
				that.unbudgtedcheckbx = oEditTableModel2.oData[0].ZzdeptCode;
				that.oBuyr = oEditTableModel2.oData[0].Zzcategoty;
				that.oAggrementnumEdit = oEditTableModel2.oData[0].Konnr;
				that.oAggreItemnoEdit = oEditTableModel2.oData[0].Ktpnr;
				that.oCreatedbyname = oEditTableModel2.oData[0].Createdby;

				// var oPRnumbr = oObjemodel2.Banfn;
				//oModel2.oData.PR_ItemSet.results[0].ZzdeptDesc2;
				//varoObjemodel2.Banfn;
				// this.getView().byId("InputValuePR").setModel(oModel2);&nbsp;\&nbsp;
				that.getView().byId("idReqType").setSelectedKey(that.oEditDocType);
				that.getView().byId("idPGrp").setSelectedKey(that.oEditAccountType);
				// that.getView().byId("oidBussinessDept").setText(that.oEditBussiUnit);
				that.getView().byId("oBussinesidtext").setText(that.oEditBussiUnit);

				that.getView().byId("InputValueBU1").setValue(that.oEditBusedept);
				that.getView().byId("InputValueBDept").setValue(that.oEditBusedeptdesc);
				that.getView().byId("oidBussinessDept").setText(that.oEditBussinessdeptcode);
				that.getView().byId("idBuApptext").setText(that.oEditZzaprL3Name + "-" + that.oEditZzaprL3);
				that.getView().byId("InputValueRequr").setValue(that.oEditRequisitioner);
				that.getView().byId("idManagertext").setText(that.oEditZzassName2);
				that.getView().byId("InputValuePlnt").setValue(that.oEditPlant);
				that.getView().byId("InputValueAgrmt").setValue(that.oAggrementnumEdit);
				that.getView().byId("oCreatedbyId").setText(that.oCreatedbyname);
				if (that.oEditDocType == "ZSC") {

					that.getView().byId("idAgrmnt").setVisible(true);
					that.getView().byId("InputValueAgrmt").setVisible(true);

				} else {
					that.getView().byId("idAgrmnt").setVisible(false);
					that.getView().byId("InputValueAgrmt").setVisible(false);

				}

				if (that.unbudgtedcheckbx == "YY") {
					that.getView().byId("oUndbChecbx").setSelected(true);
				} else if (that.unbudgtedcheckbx == "ZZ") {
					that.getView().byId("oUndbChecbx").setSelected(false);
				}
				debugger
				//	that.getView().byId("idBuApptext").setText(that.oEditZzaprL3);
			
			
				that.getView().byId("idPrType").setSelectedKey(that.oEditRequestCategory);
					that.getView().byId("idPrType").setValue(that.oEditRequestCategoryDropdown);
				//	that.getView().byId("idPrType").setSelectedItem().setText(that.oEditRequestCategoryDropdown);
				that.getView().byId("oTxtvalue").setValue(that.oEditText);
				//	that.getView().byId("idzzcategry").setText(that.oEditZZcategory);\&nbsp;
				that.getView().byId("InputValueAgrmt").setEnabled(false);
				that.getView().byId("InputValuePlnt").setEnabled(false);
				that.getView().byId("InputValueRequr").setEnabled(false);
				that.getView().byId("InputValueBDept").setEnabled(false);
				that.getView().byId("InputValueBU1").setEnabled(false);
				that.getView().byId("idPrType").setEnabled(false);
				that.getView().byId("idPGrp").setEnabled(false);
				that.getView().byId("idReqType").setEnabled(false);
				that.getView().byId("idInputFileNumber").setEnabled(false);
				that.getView().byId("oUndbChecbx").setEnabled(false);

				if (that.oEditAccountType == "K" || that.oEditAccountType == "A") {
					that.getView().byId("catalogTab_coltotal").setVisible(true);
					that.getView().byId("catalogTabcoltotal").setVisible(false);
				} else {
					that.getView().byId("catalogTab_coltotal").setVisible(false);
					that.getView().byId("catalogTabcoltotal").setVisible(true);
				}
				that.getAttachMents(oPrnumber);

				/*	var readRequestURL3 = "/PR_HeaderSet('" + oPrnumber + "')?$expand=ymm_get_att_association_nav";\&nbsp;
					that.oDataModel.read(readRequestURL3, null, null, false, function (oData, oResponse) {

						     that.oPRattchFoldrid = oData.ymm_get_att_association_nav.results[0].InstidB;
						
							},
							function (error) {

							});
					var readRequestURL4 = "ztgetattachmentSet('"+ that.oPRattchFoldrid +"')/$value";\&nbsp;
					that.oDataModel.read(readRequestURL4, null, null, false, function (oData, oResponse) {

						      var oDataAtt = oData;
							
						
							},
							function (error) {

							});	
							*/
				that.oSelectedItemplt = that.getView().byId("InputValuePlnt").getValue();
				var oUrlPurgrp = "/zmmsh_categorySet(plant='" + that.oSelectedItemplt + "',category='" + that.oEditRequestCategoryDropdown +
					"')";

				//	var oUrlPurgrp = "/zmmsh_categorySet(ekgrp='" + that.oEditRequestCategory + "')";
				if (oObjemodel2.length) {
					oObjemodel2 = oObjemodel2[0];
				}
				var oRelaseStrt = [];
				for (var key in oObjemodel2) {

					if (oObjemodel2.hasOwnProperty(key)) {
						if (key == "Frgc1") {
							if (oObjemodel2.Frgc1 != "") {
								var obj = {
									"Frgc": oObjemodel2.Frgc1,
									"RelCodeDesc": oObjemodel2.RelCodeDesc1,
									"AprText": oObjemodel2.AprText1,
									"AprDate": oObjemodel2.AprDate1,
									"Status": oObjemodel2.Status1
								};
								oRelaseStrt.push(obj);
							}
						} else if (key == "Frgc2") {
							if (oObjemodel2.Frgc2 != "") {
								var obj = {
									"Frgc": oObjemodel2.Frgc2,
									"RelCodeDesc": oObjemodel2.RelCodeDesc2,
									"AprText": oObjemodel2.AprText2,
									"AprDate": oObjemodel2.AprDate2,
									"Status": oObjemodel2.Status2
								};
								oRelaseStrt.push(obj);
							}
						} else if (key == "Frgc3") {
							if (oObjemodel2.Frgc3 != "") {
								var obj = {
									"Frgc": oObjemodel2.Frgc3,
									"RelCodeDesc": oObjemodel2.RelCodeDesc3,
									"AprText": oObjemodel2.AprText3,
									"AprDate": oObjemodel2.AprDate3,
									"Status": oObjemodel2.Status3
								};
								oRelaseStrt.push(obj);
							}
						} else if (key == "Frgc4") {
							if (oObjemodel2.Frgc4 != "") {
								var obj = {
									"Frgc": oObjemodel2.Frgc4,
									"RelCodeDesc": oObjemodel2.RelCodeDesc4,
									"AprText": oObjemodel2.AprText4,
									"AprDate": oObjemodel2.AprDate4,
									"Status": oObjemodel2.Status4
								};
								oRelaseStrt.push(obj);
							}
						} else if (key == "Frgc5") {
							if (oObjemodel2.Frgc5 != "") {
								var obj = {
									"Frgc": oObjemodel2.Frgc5,
									"RelCodeDesc": oObjemodel2.RelCodeDesc5,
									"AprText": oObjemodel2.AprText5,
									"AprDate": oObjemodel2.AprDate5,
									"Status": oObjemodel2.Status5
								};
								oRelaseStrt.push(obj);
							}
						} else if (key == "Frgc6") {
							if (oObjemodel2.Frgc6 != "") {
								var obj = {
									"Frgc": oObjemodel2.Frgc6,
									"RelCodeDesc": oObjemodel2.RelCodeDesc6,
									"AprText": oObjemodel2.AprText6,
									"AprDate": oObjemodel2.AprDate6,
									"Status": oObjemodel2.Status6
								};
								oRelaseStrt.push(obj);
							}
						} else if (key == "Frgc7") {
							if (oObjemodel2.Frgc7 != "") {
								var obj = {
									"Frgc": oObjemodel2.Frgc7,
									"RelCodeDesc": oObjemodel2.RelCodeDesc7,
									"AprText": oObjemodel2.AprText7,
									"AprDate": oObjemodel2.AprDate7,
									"Status": oObjemodel2.Status7
								};
								oRelaseStrt.push(obj);
							}
						} else if (key == "Frgc8") {
							if (oObjemodel2.Frgc8 != "") {
								var obj = {
									"Frgc": oObjemodel2.Frgc8,
									"RelCodeDesc": oObjemodel2.RelCodeDesc8,
									"AprText": oObjemodel2.AprText8,
									"AprDate": oObjemodel2.AprDate8,
									"Status": oObjemodel2.Status8
								};
								oRelaseStrt.push(obj);
							}
						}
					}
				}
				var oRelaseStrtMode = new sap.ui.model.json.JSONModel(oRelaseStrt);
				that.getView().byId("oRelaseStrtTable").setModel(oRelaseStrtMode);
				//	that.oBusyIn.close();
				that.oModelunlockCreate.read(oUrlPurgrp, null, null, true, function (oData, oRespone) {
						var Data = oData;
						var oPurGrpModel = new sap.ui.model.json.JSONModel(Data);
						that.getView().byId("idPuridGrop").setModel(oPurGrpModel);
						var xx = that.getView().byId("idPuridGrop").getModel().getData().Buyer;
						that.xx2 = that.getView().byId("idPuridGrop").getModel().getData().ekgrp;
						that.getView().byId("idPuridGrop").setValue(xx);
					},
					function (error) {

					});

			});

			that.oLoggeduser = that.getOwnerComponent().LoggedinUser;
		//	that.oLoggeduser = "RU0896"
			var ghdData = that.oFioriLogmodlref.filter(function (x) {
				/* return x.ZdocNo == oPrnumber && x.PendingWith == that.oLoggeduser;*/
				return x.ZdocNo == oPrnumber;
			});
			var ItemData = that.getView().byId("ItemTable1").getModel().getData();
			if (that.oPrCreatedby === that.oLoggeduser) {
				that.getView().byId("ItemTable1").setMode("MultiSelect");

				for (var k = 0; k < ItemData.length; k++) {
					that.getView().byId("ItemTable1").getModel().getData()[k].DeletebtnEnabled = true;
					that.getView().byId("ItemTable1").getModel().getData()[k].ExistingPr = that.getView().byId("ItemTable1").getModel().getData()[k].PreqNo;
				}

			} else {
				that.getView().byId("ItemTable1").setMode("None");
				for (var k = 0; k < ItemData.length; k++) {
					that.getView().byId("ItemTable1").getModel().getData()[k].DeletebtnEnabled = false;
				}
			}
			that.getView().byId("ItemTable1").getModel().refresh(true);
			that.TotalValCal();
			// var ghdDatalastElement = ghdData[ghdData.length - 1];
			if (ghdData.length) {
				ghdData.sort(function (a, b) {
					var dateA = new Date(a.Zdate),
						dateB = new Date(b.Zdate);
					return dateB - dateA;
				});
				if (ghdData[0].PendingWith === "SAM" || ghdData[0].PendingWith === "HAM") {
					var Lvl2DataActF = ghdData.filter(function (x) {
						return ((x.CurrentStat === "02" || x.CurrentStat === "03") && x.Action == "F");
					});
					var Lvl2DataActA = ghdData.filter(function (x) {
						return ((x.CurrentStat === "02" || x.CurrentStat === "03") && x.Action == "A");
					});
					if (Lvl2DataActF.length) {
						Lvl2DataActA[0].Actn = Lvl2DataActF[0].Action;
						Lvl2DataActA[0].Approver2Id = Lvl2DataActF[0].Approver2Id;
						Lvl2DataActA[0].ReviewerRem = Lvl2DataActF[0].ReviewerRem;
						Lvl2DataActA[0].ReviewerStatus = Lvl2DataActF[0].ReviewerStatus;
						that.FilteredghdData = Lvl2DataActA[0];
						that.PendingWith = Lvl2DataActA[0].PendingWith;

					} else {
						that.FilteredghdData = ghdData[0];
						that.PendingWith = ghdData[0].PendingWith;
					}
				} else {
					that.FilteredghdData = ghdData[0];
					that.PendingWith = ghdData[0].PendingWith;

				}
			}
			if (that.oEditDocType == "ZSC") {

				if (ghdData.length) {

					if (that.PendingWith == "") {
						if (that.oLoggeduser == that.oPrCreatedby) {
							that.getView().byId("ItemTable1").setMode("MultiSelect");

							var ApprovManager = ghdData.filter(function (x) {
								//	return x.PendingWith == "SAM" || x.PendingWith == "HAM";
								return x.PendingWith == "SAM" || x.PendingWith == "HAM";
							});
							if (ApprovManager.length) {

								if (ApprovManager[0].Action = !"F") {
									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: false,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													},

													{
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
								} else {

									if (ApprovManager[1].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[1].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									} else if (ApprovManager[1].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									ApprovSAM[0].Remarks = ApprovManager[0].ReviewerRem;
									ApprovSAM[0].Status = ApprovManager[0].ReviewerStatus

									ApprovSAM[0].Approver2Id = ApprovManager[0].Approver2Id;

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									} else if (ApprovManager[0].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
									}

									/*	if (ApprovSAM[0].Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (ApprovSAM[0].Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (ApprovSAM[0].Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (ApprovSAM[0].Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (ApprovSAM[0].Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}, {
														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}

												],
												Remarks: ApprovManager[1].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: true,
												Action2: that.getView().getModel("oSecondLevUserslist").getData(),
												ActnKey2: ApprovSAM[0].Approver2Id,

												Action: [

													{
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}

												]

											}

										]

									};

								}
							} else {

								var ApprovManager = ghdData.filter(function (x) {
									return x.PendingWith == "";
								});

								if (ApprovManager[0].Action == "A") {
									var ApprovManagerActionKey = "A";
									var ApprovManagerAction = "Approve";
								} else if (ApprovManager[0].Action == "R") {
									var ApprovManagerActionKey = "R";
									var ApprovManagerAction = "Reject";
								}

								var SamData = {
									data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [{

												stats: ApprovManager[0].Status,
												statskey: ApprovManager[0].Status
											}, {
												stats: ApprovManager[0].Status,
												statskey: ApprovManager[0].Status
											}

										],
										Remarks: ApprovManager[0].Remarks,
										Action2Visible: false,
										Action: [

											{
												Atcn: ApprovManagerAction,
												ActnKey: ApprovManagerActionKey
											}, {
												Atcn: ApprovManagerAction,
												ActnKey: ApprovManagerActionKey
											}

										]

									}]
								};
							}
							var GhdModel = new sap.ui.model.json.JSONModel();
							GhdModel.setData(SamData);
							that.getView().byId("oshmTable").setModel(GhdModel);

							that.getView().byId("idSave").setEnabled(false);
							that.getView().byId("oAdditmbtn").setEnabled(false);
							that.getView().byId("edit").setEnabled(false);
							that.getView().byId("idcopy").setEnabled(false);
							that.getView().byId("idedit").setEnabled(false);

							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);

							that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
							that.getView().byId("oUndbChecbx").setEnabled(false);
							that.getView().byId("oTxtvalue").setEnabled(false);
							that.getView().byId("idReject").setEnabled(false);

						} else {
							that.getView().byId("ItemTable1").setMode("None");
							that.getView().byId("idSave").setEnabled(false);
							that.getView().byId("oAdditmbtn").setEnabled(false);
							that.getView().byId("edit").setEnabled(false);
							that.getView().byId("idcopy").setEnabled(false);
							that.getView().byId("idedit").setEnabled(false);

							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);

							that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
							that.getView().byId("oUndbChecbx").setEnabled(false);
							that.getView().byId("oTxtvalue").setEnabled(false);
							that.getView().byId("idReject").setEnabled(false);
							that.getView().byId("ItemTable1").setMode("None");
							var ApprovManager = ghdData.filter(function (x) {

								return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
							});

							if (ApprovManager.length) {

								if (ApprovManager[0].Action = !"F") {
									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: false,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													},

													{
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
								} else {

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									} else if (ApprovManager[0].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									ApprovSAM[0].Remarks = ApprovManager[0].ReviewerRem;
									ApprovSAM[0].Status = ApprovManager[0].ReviewerStatus

									ApprovSAM[0].Approver2Id = ApprovManager[0].Approver2Id;

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									} else if (ApprovManager[0].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
									}

									/*	if (ApprovSAM[0].Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (ApprovSAM[0].Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (ApprovSAM[0].Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (ApprovSAM[0].Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (ApprovSAM[0].Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}, {
														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}

												],
												Remarks: ApprovManager[1].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: true,

												Action2: that.getView().getModel("oSecondLevUserslist").getData(),
												ActnKey2: ApprovSAM[0].Approver2Id,

												Action: [

													{
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}

												]

											}

										]

									};

								}
							} else {

								var ApprovManager = ghdData.filter(function (x) {
									return x.PendingWith == "";
								});

								if (ApprovManager[0].Action == "A") {
									var ApprovManagerActionKey = "A";
									var ApprovManagerAction = "Approve";
								} else if (ApprovManager[0].Action == "R") {
									var ApprovManagerActionKey = "R";
									var ApprovManagerAction = "Reject";
								}

								var SamData = {
									data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [{

												stats: ApprovManager[0].Status,
												statskey: ApprovManager[0].Status
											}, {
												stats: ApprovManager[0].Status,
												statskey: ApprovManager[0].Status
											}

										],
										Remarks: ApprovManager[0].Remarks,
										Action2Visible: false,
										Action: [

											{
												Atcn: ApprovManagerAction,
												ActnKey: ApprovManagerActionKey
											}, {
												Atcn: ApprovManagerAction,
												ActnKey: ApprovManagerActionKey
											}

										]

									}]
								};
							}

							/*	var ApprovManager = ghdData.filter(function (x) {
								

									return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
								});
								ApprovManager.sort(function (a, b) {
									return a.CurrentStat - b.CurrentStat;

								});
								if (ApprovManager.length) {
									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: false,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													},

													{
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
								} else {

									var ApprovManager = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}

									var SamData = {
										data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [{

													stats: ApprovManager[0].Status,
													statskey: ApprovManager[0].Status
												}, {
													stats: ApprovManager[0].Status,
													statskey: ApprovManager[0].Status
												}

											],
											Remarks: ApprovManager[0].Remarks,
											Action2Visible: false,
											Action: [

												{
													Atcn: ApprovManagerAction,
													ActnKey: ApprovManagerActionKey
												}, {
													Atcn: ApprovManagerAction,
													ActnKey: ApprovManagerActionKey
												}

											]

										}]
									};

								}
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);*/
						}

					} else if (that.PendingWith == "PM") {
						var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";
						that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);
						var path = "/ymm_manager_setSet";
						that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

							var oManagermodelref1 = oData.results;
							that.oFilteredManager1 = oManagermodelref1.filter(function (x) {
								return x.User == that.oLoggeduser;
							});
						}, function (error) {
							that.oFilteredManager1 = [];
						});
						if (that.oFilteredManager1.length) {
							if (that.oLoggeduser == that.oFilteredManager1[0].User) {
								that.getView().byId("ItemTable1").setMode("MultiSelect");
								var PendindData = ghdData.filter(function (x) {
									return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
								});

								if (!PendindData.length) {
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: true,
												Status: [{

														stats: "--Please Select--"

													}, {

														stats: "Forward",
														statskey: "forward"
													}, {
														stats: "No requirement",
														statskey: "Norequirement"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{

														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											},

											{
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
								} else {
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: "--Please Select--"

													}, {

														stats: "Forward",
														statskey: "forward"
													}, {
														stats: "No requirement",
														statskey: "Norequirement"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{

														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}, {
												Reviewer: "SAM",
												editable: true,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};

								}
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

								that.getView().byId("idSave").setEnabled(true);
								that.getView().byId("oAdditmbtn").setEnabled(true);
								that.getView().byId("edit").setEnabled(true);
								that.getView().byId("idcopy").setEnabled(true);
								that.getView().byId("idedit").setEnabled(true);
								//that.getView().byId("oidAttach").setEnabled(true);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(true);
								//	that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(true);
								that.getView().byId("idReject").setEnabled(true);

							} else {
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								//	that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);

								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [{

													stats: "--Please Select--"

												}, {

													stats: "Forward",
													statskey: "forward"
												}, {
													stats: "No requirement",
													statskey: "Norequirement"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{

													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}
						} else if (that.oLoggeduser == that.oPrCreatedby) {
							that.getView().byId("idSave").setEnabled(true);
							that.getView().byId("oAdditmbtn").setEnabled(true);
							that.getView().byId("edit").setEnabled(true);
							that.getView().byId("idcopy").setEnabled(true);
							that.getView().byId("idedit").setEnabled(true);
							//that.getView().byId("oidAttach").setEnabled(false);
							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);
							// that.getView().byId("InputValuePR").setEnabled(false);
							//	that.getView().byId("oFIleuploadrid").setEnabled(false);
							that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
							that.getView().byId("oUndbChecbx").setEnabled(true);
							that.getView().byId("oTxtvalue").setEnabled(true);
							that.getView().byId("idReject").setEnabled(true);

							var SamData = {
								data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [{

												stats: "--Please Select--"

											}, {

												stats: "Forward",
												statskey: "forward"
											}, {
												stats: "No requirement",
												statskey: "Norequirement"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{

												Atcn: "--Please Select--"

											},

											{
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}, {
										Reviewer: "SAM",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											}, {
												stats: "Delivered from Inventory",
												statskey: "Inventory"
											}, {
												stats: "Back to back buy",
												statskey: "Backtobuy"
											}, {
												stats: "Allocated",
												statskey: "Allocated"
											}, {
												stats: "Non Standard",
												statskey: "Non Standard"
											}, {
												stats: "Quote Attached",
												statskey: "Quuote Attached"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [

											{
												Atcn: "--Please Select--"

											}, {
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									},

									{
										Reviewer: "Buyer",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											}, {
												stats: "Quote attached",
												statskey: "Quoteattached"
											}, {
												stats: "Requirement Change",
												statskey: "Requirementchange"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{
												Atcn: "--Please Select--"

											}, {
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}

								]

							};
							var GhdModel = new sap.ui.model.json.JSONModel();
							GhdModel.setData(SamData);
							that.getView().byId("oshmTable").setModel(GhdModel);

						} else if (that.oLoggeduser != that.oPrCreatedby || that.oLoggeduser != that.oFilteredManager1[0].User) {

							that.getView().byId("idSave").setEnabled(false);
							that.getView().byId("oAdditmbtn").setEnabled(false);
							that.getView().byId("edit").setEnabled(false);
							that.getView().byId("idcopy").setEnabled(false);
							that.getView().byId("idedit").setEnabled(false);
							//that.getView().byId("oidAttach").setEnabled(false);
							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);
							// that.getView().byId("InputValuePR").setEnabled(false);
							//	that.getView().byId("oFIleuploadrid").setEnabled(false);
							that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
							that.getView().byId("oUndbChecbx").setEnabled(false);
							that.getView().byId("oTxtvalue").setEnabled(false);
							that.getView().byId("idReject").setEnabled(false);

							var SamData = {
								data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [{

												stats: "--Please Select--"

											}, {

												stats: "Forward",
												statskey: "forward"
											}, {
												stats: "No requirement",
												statskey: "Norequirement"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{

												Atcn: "--Please Select--"

											},

											{
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}, {
										Reviewer: "SAM",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											}, {
												stats: "Delivered from Inventory",
												statskey: "Inventory"
											}, {
												stats: "Back to back buy",
												statskey: "Backtobuy"
											}, {
												stats: "Allocated",
												statskey: "Allocated"
											}, {
												stats: "Non Standard",
												statskey: "Non Standard"
											}, {
												stats: "Quote Attached",
												statskey: "Quuote Attached"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [

											{
												Atcn: "--Please Select--"

											}, {
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									},

									{
										Reviewer: "Buyer",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											}, {
												stats: "Quote attached",
												statskey: "Quoteattached"
											}, {
												stats: "Requirement Change",
												statskey: "Requirementchange"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{
												Atcn: "--Please Select--"

											}, {
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}

								]

							};
							var GhdModel = new sap.ui.model.json.JSONModel();
							GhdModel.setData(SamData);
							that.getView().byId("oshmTable").setModel(GhdModel);

						}

					} else if (that.PendingWith == "SAM") {

						var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

						that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

						var path = "/YMM_PR_SAMSet";
						that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

							var oHamsetmodelref = oData.results;
							that.oFilteredSAM = oHamsetmodelref.filter(function (x) {
								return x.AFNAM == that.oLoggeduser;
							});
						}, function (error) {
							that.oFilteredSAM = [];
						});
						if (that.oFilteredSAM.length) {
							if (that.oLoggeduser == that.oFilteredSAM[0].AFNAM) {
								that.getView().byId("ItemTable1").setMode("MultiSelect");

								if (that.oFilteredSAM.length) {
									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									} else if (that.FilteredghdData.Action == "F") {
										var ActionKey = "F";
										var Action = "Forward";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: true,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}, {
														Atcn: "Forward",
														ActnKey: "F"
													}

												],
												Action2: that.getView().getModel("oSecondLevUserslist").getData()

												/*	Action2: [

														{
															Atcn2: "--Please Select--"

														}, {
															Atcn2: "Vijay A",
															ActnKey2: "VA3833"
														}, {
															Atcn2: "Srinivas Ch",
															ActnKey2: "SC0430"
														}, {
															Atcn2: "Basha S",
															ActnKey2: "BS2931"
														}, {
															Atcn2: "Denis C",
															ActnKey2: "DC30338"
														}, {
															Atcn2: "Suman B",
															ActnKey2: "SB3817"
														}

													]*/

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									if (that.FilteredghdData.Actn === "F") {

										if (that.FilteredghdData.ReviewerStatus === "Inventory") {
											var stats = "Delivered from Inventory";
											var statskey = "Inventory"
										} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
											var stats = "Back to back buy";
											var statskey = "Backtobuy";
										} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
											var stats = "Allocated";
											var statskey = "Allocated";
										} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
											var stats = "Non Standard";
											var statskey = "Non Standard";
										} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
											var stats = "Quote Attached";
											var statskey = "Quuote Attached";
										}

										/*if (that.FilteredghdData.Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (that.FilteredghdData.Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (that.FilteredghdData.Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (that.FilteredghdData.Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (that.FilteredghdData.Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

										SamData.data.splice(1, 1);
										var Obj = {
											Reviewer: that.FilteredghdData.PendingWith,
											editable: false,
											Status: [{
													stats: stats,
													statskey: statskey
												}, {
													stats: stats,
													statskey: statskey

												}

											],
											Remarks: that.FilteredghdData.ReviewerRem,
											Action2Visible: true,
											Action2: that.getView().getModel("oSecondLevUserslist").getData(),
											ActnKey2: that.FilteredghdData.Approver2Id,

											Action: [

												{
													Atcn: "Forward",
													ActnKey: "F"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											]

										};

										SamData.data.splice(1, 0, Obj);
									}

									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);
									that.getView().byId("idSave").setEnabled(true);

									that.getView().byId("oAdditmbtn").setEnabled(true);
									that.getView().byId("edit").setEnabled(true);
									that.getView().byId("idcopy").setEnabled(true);
									that.getView().byId("idedit").setEnabled(true);
									//that.getView().byId("oidAttach").setEnabled(true);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

									//	that.getView().byId("oFIleuploadrid").setEnabled(true);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(true);
									that.getView().byId("idReject").setEnabled(true);

								} else {
									//Display code
									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									//that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									/* that.getView().byId("idSave").setEnabled(false);*/

									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													},

													{
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

								}

							} else {
								that.getView().byId("ItemTable1").setMode("None");
								//Display code
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								/* that.getView().byId("idSave").setEnabled(false);*/
								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}
						} else {

							if (that.oFilteredSAM.length == "0") {

								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								} else if (that.FilteredghdData.Action == "F") {
									var ActionKey = "F";
									var Action = "Forward";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action2Visible: false,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											],
											Action2: that.getView().getModel("oSecondLevUserslist").getData()

											/*Action2: [

												{
													Atcn2: "--Please Select--"

												}, {
													Atcn2: "Vijay A",
													ActnKey2: "VA3833"
												}, {
													Atcn2: "Srinivas Ch",
													ActnKey2: "SC0430"
												}, {
													Atcn2: "Basha S",
													ActnKey2: "BS2931"
												}, {
													Atcn2: "Denis C",
													ActnKey2: "DC30338"
												}, {
													Atcn2: "Suman B",
													ActnKey2: "SB3817"
												}

											]*/

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};

								var GhdModel = new sap.ui.model.json.JSONModel();
								if (that.FilteredghdData.Actn === "F") {

									if (that.FilteredghdData.ReviewerStatus === "Inventory") {
										var stats = "Delivered from Inventory";
										var statskey = "Inventory"
									} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
										var stats = "Back to back buy";
										var statskey = "Backtobuy";
									} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
										var stats = "Allocated";
										var statskey = "Allocated";
									} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
										var stats = "Non Standard";
										var statskey = "Non Standard";
									} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
										var stats = "Quote Attached";
										var statskey = "Quuote Attached";
									}

									/*	if (that.FilteredghdData.Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (that.FilteredghdData.Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (that.FilteredghdData.Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (that.FilteredghdData.Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (that.FilteredghdData.Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

									SamData.data.splice(1, 1);
									var Obj = {
										Reviewer: that.FilteredghdData.PendingWith,
										editable: false,
										Status: [{
												stats: stats,
												statskey: statskey
											}, {
												stats: stats,
												statskey: statskey

											}

										],
										Remarks: that.FilteredghdData.ReviewerRem,
										Action2Visible: true,
										Action2: that.getView().getModel("oSecondLevUserslist").getData(),
										ActnKey2: that.FilteredghdData.Approver2Id,

										Action: [

											{
												Atcn: "Forward",
												ActnKey: "F"
											}, {
												Atcn: "Forward",
												ActnKey: "F"
											}

										]

									};

									SamData.data.splice(1, 0, Obj);
								}

								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);
								that.getView().byId("idSave").setEnabled(false);

								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(true);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(true);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);

							} else {

								//Display code
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								/* that.getView().byId("idSave").setEnabled(false);*/

								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}

						}
						/* actual code
						
											if (that.oFilteredSAM.length) {
												if (that.oLoggeduser == that.oFilteredSAM[0].AFNAM) {
													that.getView().byId("ItemTable1").setMode("MultiSelect");
													if (that.oFilteredSAM.length) {
														if (that.FilteredghdData.Action == "A") {
															var ActionKey = "A";
															var Action = "Approve";
														} else if (that.FilteredghdData.Action == "R") {
															var ActionKey = "R";
															var Action = "Reject";
														} else if (that.FilteredghdData.Action == "F") {
															var ActionKey = "F";
															var Action = "Forward";
														}
														var SamData = {
															data: [{
																	Reviewer: "PR Creator/Manager",
																	editable: false,
																	Status: [

																		{
																			stats: that.FilteredghdData.Status,
																			statskey: that.FilteredghdData.Status
																		}, {
																			stats: that.FilteredghdData.Status,
																			statskey: that.FilteredghdData.Status
																		}

																	],
																	Remarks: that.FilteredghdData.Remarks,
																	Action2Visible: false,
																	Action: [

																		{
																			Atcn: Action,
																			ActnKey: ActionKey
																		}, {
																			Atcn: Action,
																			ActnKey: ActionKey
																		}

																	]

																}, {
																	Reviewer: "SAM",
																	editable: true,
																	Status: [{
																			stats: "--Please Select--"

																		}, {
																			stats: "Delivered from Inventory",
																			statskey: "Inventory"
																		}, {
																			stats: "Back to back buy",
																			statskey: "Backtobuy"
																		}, {
																			stats: "Allocated",
																			statskey: "Allocated"
																		}, {
																			stats: "Non Standard",
																			statskey: "Non Standard"
																		}, {
																			stats: "Quote Attached",
																			statskey: "Quuote Attached"
																		}

																	],
																	Remarks: "",
																	Action2Visible: false,
																	Action: [

																		{
																			Atcn: "--Please Select--"

																		}, {
																			Atcn: "Approve",
																			ActnKey: "A"
																		}, {
																			Atcn: "Reject",
																			ActnKey: "R"
																		}, {
																			Atcn: "Forward",
																			ActnKey: "F"
																		}

																	],

																	Action2: [

																		{
																			Atcn2: "--Please Select--"

																		}, {
																			Atcn2: "Vijay A",
																			ActnKey2: "VA3833"
																		}, {
																			Atcn2: "Srinivas Ch",
																			ActnKey2: "SC0430"
																		}, {
																			Atcn2: "Basha S",
																			ActnKey2: "BS2931"
																		}, {
																			Atcn2: "Denis C",
																			ActnKey2: "DC30338"
																		}, {
																			Atcn2: "Uman B",
																			ActnKey2: "SB3817"
																		}

																	]

																},

																{
																	Reviewer: "Buyer",
																	editable: false,
																	Status: [{
																			stats: "--Please Select--"

																		}, {
																			stats: "Quote attached",
																			statskey: "Quoteattached"
																		}, {
																			stats: "Requirement Change",
																			statskey: "Requirementchange"
																		}

																	],
																	Remarks: "",
																	Action2Visible: false,
																	Action: [{
																			Atcn: "--Please Select--"

																		}, {
																			Atcn: "Approve",
																			ActnKey: "A"
																		}, {
																			Atcn: "Reject",
																			ActnKey: "R"
																		}

																	]

																}

															]

														};

														var GhdModel = new sap.ui.model.json.JSONModel();
														if (that.FilteredghdData.Actn === "F") {

															if (that.FilteredghdData.ReviewerStatus === "Inventory") {
																var stats = "Delivered from Inventory";
																var statskey = "Inventory"
															} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
																var stats = "Back to back buy";
																var statskey = "Backtobuy";
															} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
																var stats = "Allocated";
																var statskey = "Allocated";
															} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
																var stats = "Non Standard";
																var statskey = "Non Standard";
															} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
																var stats = "Quote Attached";
																var statskey = "Quuote Attached";
															}

															if (that.FilteredghdData.Approver2Id === "VA3833") {
																var Atcn2 = "Vijay A";
																var ActnKey2 = "VA3833";
															} else if (that.FilteredghdData.Approver2Id === "SC0430") {
																var Atcn2 = "Srinivas Ch";
																var ActnKey2 = "SC0430";
															} else if (that.FilteredghdData.Approver2Id === "BS2931") {
																var Atcn2 = "Basha S";
																var ActnKey2 = "BS2931";
															} else if (that.FilteredghdData.Approver2Id === "DC30338") {
																var Atcn2 = "Denis C";
																var ActnKey2 = "DC30338";
															} else if (that.FilteredghdData.Approver2Id === "SB3817") {
																var Atcn2 = "Uman B";
																var ActnKey2 = "SB3817";
															}

															SamData.data.splice(1, 1);
															var Obj = {
																Reviewer: that.FilteredghdData.PendingWith,
																editable: false,
																Status: [{
																		stats: stats,
																		statskey: statskey
																	}, {
																		stats: stats,
																		statskey: statskey

																	}

																],
																Remarks: that.FilteredghdData.ReviewerRem,
																Action2Visible: true,
																Action2: [

																	{
																		Atcn2: Atcn2,
																		ActnKey2: ActnKey2
																	}, {
																		Atcn2: Atcn2,
																		ActnKey2: ActnKey2
																	}, {
																		Atcn2: Atcn2,
																		ActnKey2: ActnKey2
																	}, {
																		Atcn2: Atcn2,
																		ActnKey2: ActnKey2
																	}, {
																		Atcn2: Atcn2,
																		ActnKey2: ActnKey2
																	}

																],

																Action: [

																	{
																		Atcn: "Forward",
																		ActnKey: "F"
																	}, {
																		Atcn: "Forward",
																		ActnKey: "F"
																	}

																]

															};

															SamData.data.splice(1, 0, Obj);
														}

														GhdModel.setData(SamData);
														that.getView().byId("oshmTable").setModel(GhdModel);
														that.getView().byId("idSave").setEnabled(true);

														that.getView().byId("oAdditmbtn").setEnabled(true);
														that.getView().byId("edit").setEnabled(true);
														that.getView().byId("idcopy").setEnabled(true);
														that.getView().byId("idedit").setEnabled(true);

														that.getView().byId("InputValueAgrmt").setEnabled(false);
														that.getView().byId("InputValuePlnt").setEnabled(false);
														that.getView().byId("InputValueRequr").setEnabled(false);
														that.getView().byId("InputValueBDept").setEnabled(false);
														that.getView().byId("InputValueBU1").setEnabled(false);
														that.getView().byId("idPrType").setEnabled(false);
														that.getView().byId("idPGrp").setEnabled(false);
														that.getView().byId("idReqType").setEnabled(false);
														that.getView().byId("idInputFileNumber").setEnabled(false);

														that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
														that.getView().byId("oUndbChecbx").setEnabled(false);
														that.getView().byId("oTxtvalue").setEnabled(true);
														that.getView().byId("idReject").setEnabled(true);
														

													} else {
													
														that.getView().byId("idSave").setEnabled(false);
														that.getView().byId("oAdditmbtn").setEnabled(false);
														that.getView().byId("edit").setEnabled(false);
														that.getView().byId("idcopy").setEnabled(false);
														that.getView().byId("idedit").setEnabled(false);
													
														that.getView().byId("InputValueAgrmt").setEnabled(false);
														that.getView().byId("InputValuePlnt").setEnabled(false);
														that.getView().byId("InputValueRequr").setEnabled(false);
														that.getView().byId("InputValueBDept").setEnabled(false);
														that.getView().byId("InputValueBU1").setEnabled(false);
														that.getView().byId("idPrType").setEnabled(false);
														that.getView().byId("idPGrp").setEnabled(false);
														that.getView().byId("idReqType").setEnabled(false);
														that.getView().byId("idInputFileNumber").setEnabled(false);

													
														that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
														that.getView().byId("oUndbChecbx").setEnabled(false);
														that.getView().byId("oTxtvalue").setEnabled(false);
														that.getView().byId("idReject").setEnabled(false);
													
														if (that.FilteredghdData.Action == "A") {
															var ActionKey = "A";
															var Action = "Approve";
														} else if (that.FilteredghdData.Action == "R") {
															var ActionKey = "R";
															var Action = "Reject";
														}
														var SamData = {
															data: [{
																	Reviewer: "PR Creator/Manager",
																	editable: false,
																	Status: [

																		{
																			stats: that.FilteredghdData.Status,
																			statskey: that.FilteredghdData.Status
																		}, {
																			stats: that.FilteredghdData.Status,
																			statskey: that.FilteredghdData.Status
																		}

																	],
																	Remarks: that.FilteredghdData.Remarks,
																	Action: [

																		{
																			Atcn: Action,
																			ActnKey: ActionKey
																		}, {
																			Atcn: Action,
																			ActnKey: ActionKey
																		}

																	]

																}, {
																	Reviewer: "SAM",
																	editable: false,
																	Status: [{
																			stats: "--Please Select--"

																		}, {
																			stats: "Delivered from Inventory",
																			statskey: "Inventory"
																		}, {
																			stats: "Back to back buy",
																			statskey: "Backtobuy"
																		}, {
																			stats: "Allocated",
																			statskey: "Allocated"
																		}, {
																			stats: "Non Standard",
																			statskey: "Non Standard"
																		}, {
																			stats: "Quote Attached",
																			statskey: "Quuote Attached"
																		}

																	],
																	Remarks: "",
																	Action: [{
																			Atcn: "--Please Select--"

																		}, {
																			Atcn: "Approve",
																			ActnKey: "A"
																		}, {
																			Atcn: "Reject",
																			ActnKey: "R"
																		}

																	]

																},

																{
																	Reviewer: "Buyer",
																	editable: false,
																	Status: [{
																			stats: "--Please Select--"

																		},

																		{
																			stats: "Quote attached",
																			statskey: "Quoteattached"
																		}, {
																			stats: "Requirement Change",
																			statskey: "Requirementchange"
																		}

																	],
																	Remarks: "",
																	Action: [

																		{
																			Atcn: "--Please Select--"

																		}, {
																			Atcn: "Approve",
																			ActnKey: "A"
																		}, {
																			Atcn: "Reject",
																			ActnKey: "R"
																		}

																	]

																}

															]

														};
														var GhdModel = new sap.ui.model.json.JSONModel();
														GhdModel.setData(SamData);
														that.getView().byId("oshmTable").setModel(GhdModel);

													}

												

												} else {
													that.getView().byId("ItemTable1").setMode("None");
												
													that.getView().byId("idSave").setEnabled(false);
													that.getView().byId("oAdditmbtn").setEnabled(false);
													that.getView().byId("edit").setEnabled(false);
													that.getView().byId("idcopy").setEnabled(false);
													that.getView().byId("idedit").setEnabled(false);
												
													that.getView().byId("InputValueAgrmt").setEnabled(false);
													that.getView().byId("InputValuePlnt").setEnabled(false);
													that.getView().byId("InputValueRequr").setEnabled(false);
													that.getView().byId("InputValueBDept").setEnabled(false);
													that.getView().byId("InputValueBU1").setEnabled(false);
													that.getView().byId("idPrType").setEnabled(false);
													that.getView().byId("idPGrp").setEnabled(false);
													that.getView().byId("idReqType").setEnabled(false);
													that.getView().byId("idInputFileNumber").setEnabled(false);

												
													that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
													that.getView().byId("oUndbChecbx").setEnabled(false);
													that.getView().byId("oTxtvalue").setEnabled(false);
													that.getView().byId("idReject").setEnabled(false);
												
													if (that.FilteredghdData.Action == "A") {
														var ActionKey = "A";
														var Action = "Approve";
													} else if (that.FilteredghdData.Action == "R") {
														var ActionKey = "R";
														var Action = "Reject";
													}
													var SamData = {
														data: [{
																Reviewer: "PR Creator/Manager",
																editable: false,
																Status: [

																	{
																		stats: that.FilteredghdData.Status,
																		statskey: that.FilteredghdData.Status
																	}, {
																		stats: that.FilteredghdData.Status,
																		statskey: that.FilteredghdData.Status
																	}

																],
																Remarks: that.FilteredghdData.Remarks,
																Action: [

																	{
																		Atcn: Action,
																		ActnKey: ActionKey
																	}, {
																		Atcn: Action,
																		ActnKey: ActionKey
																	}

																]

															}, {
																Reviewer: "SAM",
																editable: false,
																Status: [{
																		stats: "--Please Select--"

																	}, {
																		stats: "Delivered from Inventory",
																		statskey: "Inventory"
																	}, {
																		stats: "Back to back buy",
																		statskey: "Backtobuy"
																	}, {
																		stats: "Allocated",
																		statskey: "Allocated"
																	}, {
																		stats: "Non Standard",
																		statskey: "Non Standard"
																	}, {
																		stats: "Quote Attached",
																		statskey: "Quuote Attached"
																	}

																],
																Remarks: "",
																Action: [{
																		Atcn: "--Please Select--"

																	}, {
																		Atcn: "Approve",
																		ActnKey: "A"
																	}, {
																		Atcn: "Reject",
																		ActnKey: "R"
																	}

																]

															},

															{
																Reviewer: "Buyer",
																editable: false,
																Status: [{
																		stats: "--Please Select--"

																	},

																	{
																		stats: "Quote attached",
																		statskey: "Quoteattached"
																	}, {
																		stats: "Requirement Change",
																		statskey: "Requirementchange"
																	}

																],
																Remarks: "",
																Action: [

																	{
																		Atcn: "--Please Select--"

																	}, {
																		Atcn: "Approve",
																		ActnKey: "A"
																	}, {
																		Atcn: "Reject",
																		ActnKey: "R"
																	}

																]

															}

														]

													};
													var GhdModel = new sap.ui.model.json.JSONModel();
													GhdModel.setData(SamData);
													that.getView().byId("oshmTable").setModel(GhdModel);

												}
											} else {

						
												that.getView().byId("idSave").setEnabled(false);
												that.getView().byId("oAdditmbtn").setEnabled(false);
												that.getView().byId("edit").setEnabled(false);
												that.getView().byId("idcopy").setEnabled(false);
												that.getView().byId("idedit").setEnabled(false);
						
												that.getView().byId("InputValueAgrmt").setEnabled(false);
												that.getView().byId("InputValuePlnt").setEnabled(false);
												that.getView().byId("InputValueRequr").setEnabled(false);
												that.getView().byId("InputValueBDept").setEnabled(false);
												that.getView().byId("InputValueBU1").setEnabled(false);
												that.getView().byId("idPrType").setEnabled(false);
												that.getView().byId("idPGrp").setEnabled(false);
												that.getView().byId("idReqType").setEnabled(false);
												that.getView().byId("idInputFileNumber").setEnabled(false);

						
												that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
												that.getView().byId("oUndbChecbx").setEnabled(false);
												that.getView().byId("oTxtvalue").setEnabled(false);
												that.getView().byId("idReject").setEnabled(false);
						

												if (that.FilteredghdData.Action == "A") {
													var ActionKey = "A";
													var Action = "Approve";
												} else if (that.FilteredghdData.Action == "R") {
													var ActionKey = "R";
													var Action = "Reject";
												}
												var SamData = {
													data: [{
															Reviewer: "PR Creator/Manager",
															editable: false,
															Status: [

																{
																	stats: that.FilteredghdData.Status,
																	statskey: that.FilteredghdData.Status
																}, {
																	stats: that.FilteredghdData.Status,
																	statskey: that.FilteredghdData.Status
																}

															],
															Remarks: that.FilteredghdData.Remarks,
															Action: [

																{
																	Atcn: Action,
																	ActnKey: ActionKey
																}, {
																	Atcn: Action,
																	ActnKey: ActionKey
																}

															]

														}, {
															Reviewer: "SAM",
															editable: false,
															Status: [{
																	stats: "--Please Select--"

																}, {
																	stats: "Delivered from Inventory",
																	statskey: "Inventory"
																}, {
																	stats: "Back to back buy",
																	statskey: "Backtobuy"
																}, {
																	stats: "Allocated",
																	statskey: "Allocated"
																}, {
																	stats: "Non Standard",
																	statskey: "Non Standard"
																}, {
																	stats: "Quote Attached",
																	statskey: "Quuote Attached"
																}

															],
															Remarks: "",
															Action: [

																{
																	Atcn: "--Please Select--"

																}, {
																	Atcn: "Approve",
																	ActnKey: "A"
																}, {
																	Atcn: "Reject",
																	ActnKey: "R"
																}

															]

														},

														{
															Reviewer: "Buyer",
															editable: false,
															Status: [{
																	stats: "--Please Select--"

																}, {
																	stats: "Quote attached",
																	statskey: "Quoteattached"
																}, {
																	stats: "Requirement Change",
																	statskey: "Requirementchange"
																}

															],
															Remarks: "",
															Action: [{
																	Atcn: "--Please Select--"

																}, {
																	Atcn: "Approve",
																	ActnKey: "A"
																}, {
																	Atcn: "Reject",
																	ActnKey: "R"
																}

															]

														}

													]

												};
												var GhdModel = new sap.ui.model.json.JSONModel();
												GhdModel.setData(SamData);
												that.getView().byId("oshmTable").setModel(GhdModel);

											}*/
					} else if (that.PendingWith == "HAM") {
						var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

						that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

						var path = "/YMM_PR_HAMSet";
						that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

							var oHamsetmodelref = oData.results;
							that.oFilteredHAM = oHamsetmodelref.filter(function (x) {
								return x.AFNAM == that.oLoggeduser;
							});
						}, function (error) {
							that.oFilteredHAM = [];
						});
						if (that.oFilteredHAM.length) {
							if (that.oLoggeduser == that.oFilteredHAM[0].AFNAM) {
								that.getView().byId("ItemTable1").setMode("MultiSelect");

								if (that.oFilteredHAM.length) {
									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									} else if (that.FilteredghdData.Action == "F") {
										var ActionKey = "F";
										var Action = "Forward";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "HAM",
												editable: true,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}, {
														Atcn: "Forward",
														ActnKey: "F"
													}

												],

												Action2: that.getView().getModel("oSecondLevUserslist").getData()

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									if (that.FilteredghdData.Actn === "F") {

										if (that.FilteredghdData.ReviewerStatus === "Inventory") {
											var stats = "Delivered from Inventory";
											var statskey = "Inventory"
										} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
											var stats = "Back to back buy";
											var statskey = "Backtobuy";
										} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
											var stats = "Allocated";
											var statskey = "Allocated";
										} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
											var stats = "Non Standard";
											var statskey = "Non Standard";
										} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
											var stats = "Quote Attached";
											var statskey = "Quuote Attached";
										}

										/*	if (that.FilteredghdData.Approver2Id === "VA3833") {
												var Atcn2 = "Vijay A";
												var ActnKey2 = "VA3833";
											} else if (that.FilteredghdData.Approver2Id === "SC0430") {
												var Atcn2 = "Srinivas Ch";
												var ActnKey2 = "SC0430";
											} else if (that.FilteredghdData.Approver2Id === "BS2931") {
												var Atcn2 = "Basha S";
												var ActnKey2 = "BS2931";
											} else if (that.FilteredghdData.Approver2Id === "DC30338") {
												var Atcn2 = "Denis C";
												var ActnKey2 = "DC30338";
											} else if (that.FilteredghdData.Approver2Id === "SB3817") {
												var Atcn2 = "Suman B";
												var ActnKey2 = "SB3817";
											}*/

										SamData.data.splice(1, 1);
										var Obj = {
											Reviewer: that.FilteredghdData.PendingWith,
											editable: false,
											Status: [{
													stats: stats,
													statskey: statskey
												}, {
													stats: stats,
													statskey: statskey

												}

											],
											Remarks: that.FilteredghdData.ReviewerRem,
											Action2Visible: true,
											Action2: that.getView().getModel("oSecondLevUserslist").getData(),
											ActnKey2: that.FilteredghdData.Approver2Id,
											/*	Action2: [

													{
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}

												],*/

											Action: [

												{
													Atcn: "Forward",
													ActnKey: "F"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											]

										};

										SamData.data.splice(1, 0, Obj);
									}

									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);
									that.getView().byId("idSave").setEnabled(true);

									that.getView().byId("oAdditmbtn").setEnabled(true);
									that.getView().byId("edit").setEnabled(true);
									that.getView().byId("idcopy").setEnabled(true);
									that.getView().byId("idedit").setEnabled(true);
									//that.getView().byId("oidAttach").setEnabled(true);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

									//	that.getView().byId("oFIleuploadrid").setEnabled(true);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(true);
									that.getView().byId("idReject").setEnabled(true);

								} else {
									//Display code
									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									//that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									/* that.getView().byId("idSave").setEnabled(false);*/

									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "HAM",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													},

													{
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

								}

							} else {
								that.getView().byId("ItemTable1").setMode("None");
								//Display code
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								/* that.getView().byId("idSave").setEnabled(false);*/
								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "HAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}
						} else {

							if (that.oFilteredHAM.length == "0") {

								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								} else if (that.FilteredghdData.Action == "F") {
									var ActionKey = "F";
									var Action = "Forward";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action2Visible: false,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "HAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											],
											Action2: that.getView().getModel("oSecondLevUserslist").getData()

											/*Action2: [

												{
													Atcn2: "--Please Select--"

												}, {
													Atcn2: "Vijay A",
													ActnKey2: "VA3833"
												}, {
													Atcn2: "Srinivas Ch",
													ActnKey2: "SC0430"
												}, {
													Atcn2: "Basha S",
													ActnKey2: "BS2931"
												}, {
													Atcn2: "Denis C",
													ActnKey2: "DC30338"
												}, {
													Atcn2: "Suman B",
													ActnKey2: "SB3817"
												}

											]*/

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};

								var GhdModel = new sap.ui.model.json.JSONModel();
								if (that.FilteredghdData.Actn === "F") {

									if (that.FilteredghdData.ReviewerStatus === "Inventory") {
										var stats = "Delivered from Inventory";
										var statskey = "Inventory"
									} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
										var stats = "Back to back buy";
										var statskey = "Backtobuy";
									} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
										var stats = "Allocated";
										var statskey = "Allocated";
									} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
										var stats = "Non Standard";
										var statskey = "Non Standard";
									} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
										var stats = "Quote Attached";
										var statskey = "Quuote Attached";
									}

									/*if (that.FilteredghdData.Approver2Id === "VA3833") {
										var Atcn2 = "Vijay A";
										var ActnKey2 = "VA3833";
									} else if (that.FilteredghdData.Approver2Id === "SC0430") {
										var Atcn2 = "Srinivas Ch";
										var ActnKey2 = "SC0430";
									} else if (that.FilteredghdData.Approver2Id === "BS2931") {
										var Atcn2 = "Basha S";
										var ActnKey2 = "BS2931";
									} else if (that.FilteredghdData.Approver2Id === "DC30338") {
										var Atcn2 = "Denis C";
										var ActnKey2 = "DC30338";
									} else if (that.FilteredghdData.Approver2Id === "SB3817") {
										var Atcn2 = "Suman B";
										var ActnKey2 = "SB3817";
									}*/

									SamData.data.splice(1, 1);
									var Obj = {
										Reviewer: that.FilteredghdData.PendingWith,
										editable: false,
										Status: [{
												stats: stats,
												statskey: statskey
											}, {
												stats: stats,
												statskey: statskey

											}

										],
										Remarks: that.FilteredghdData.ReviewerRem,
										Action2Visible: true,
										Action2: that.getView().getModel("oSecondLevUserslist").getData(),
										ActnKey2: that.FilteredghdData.Approver2Id,

										Action: [

											{
												Atcn: "Forward",
												ActnKey: "F"
											}, {
												Atcn: "Forward",
												ActnKey: "F"
											}

										]

									};

									SamData.data.splice(1, 0, Obj);
								}

								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);
								that.getView().byId("idSave").setEnabled(false);

								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(true);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(true);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);

							} else {

								//Display code
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								/* that.getView().byId("idSave").setEnabled(false);*/

								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "HAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}

						}
						/*if (that.oFilteredHAM.length) {
							if (that.oLoggeduser == that.oFilteredHAM[0].AFNAM) {
								that.getView().byId("ItemTable1").setMode("MultiSelect");

								if (that.oFilteredHAM.length) {
									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									} else if (that.FilteredghdData.Action == "F") {
										var ActionKey = "F";
										var Action = "Forward";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "HAM",
												editable: true,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}, {
														Atcn: "Forward",
														ActnKey: "F"
													}

												],

												Action2: [

													{
														Atcn2: "--Please Select--"

													}, {
														Atcn2: "Vijay A",
														ActnKey2: "VA3833"
													}, {
														Atcn2: "Srinivas Ch",
														ActnKey2: "SC0430"
													}, {
														Atcn2: "Basha S",
														ActnKey2: "BS2931"
													}, {
														Atcn2: "Denis C",
														ActnKey2: "DC30338"
													}, {
														Atcn2: "Uman B",
														ActnKey2: "SB3817"
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
									var GhdModel = new sap.ui.model.json.JSONModel();

									if (that.FilteredghdData.Actn === "F") {

										if (that.FilteredghdData.ReviewerStatus === "Inventory") {
											var stats = "Delivered from Inventory";
											var statskey = "Inventory"
										} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
											var stats = "Back to back buy";
											var statskey = "Backtobuy";
										} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
											var stats = "Allocated";
											var statskey = "Allocated";
										} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
											var stats = "Non Standard";
											var statskey = "Non Standard";
										} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
											var stats = "Quote Attached";
											var statskey = "Quuote Attached";
										}

										if (that.FilteredghdData.Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (that.FilteredghdData.Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (that.FilteredghdData.Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (that.FilteredghdData.Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (that.FilteredghdData.Approver2Id === "SB3817") {
											var Atcn2 = "Uman B";
											var ActnKey2 = "SB3817";
										}

										SamData.data.splice(1, 1);
										var Obj = {
											Reviewer: that.FilteredghdData.PendingWith,
											editable: false,
											Status: [{
													stats: stats,
													statskey: statskey
												}, {
													stats: stats,
													statskey: statskey

												}

											],
											Remarks: that.FilteredghdData.ReviewerRem,
											Action2Visible: true,

											Action2: [

												{
													Atcn2: Atcn2,
													ActnKey2: ActnKey2
												}, {
													Atcn2: Atcn2,
													ActnKey2: ActnKey2
												}, {
													Atcn2: Atcn2,
													ActnKey2: ActnKey2
												}, {
													Atcn2: Atcn2,
													ActnKey2: ActnKey2
												}, {
													Atcn2: Atcn2,
													ActnKey2: ActnKey2
												}

											],

											Action: [

												{
													Atcn: "Forward",
													ActnKey: "F"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											]

										};

										SamData.data.splice(1, 0, Obj);
									}

									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);
									that.getView().byId("idSave").setEnabled(true);

									that.getView().byId("oAdditmbtn").setEnabled(true);
									that.getView().byId("edit").setEnabled(true);
									that.getView().byId("idcopy").setEnabled(true);
									that.getView().byId("idedit").setEnabled(true);
								
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

								
									that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(true);
									that.getView().byId("idReject").setEnabled(true);

								} else {
									that.getView().byId("ItemTable1").setMode("None");
									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
								
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
								
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "HAM",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

								}

							
							} else {
								that.getView().byId("ItemTable1").setMode("None");
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
							
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);
							
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action2Visible: false,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "HAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}
						} else {
							that.getView().byId("ItemTable1").setMode("None");
							that.getView().byId("idSave").setEnabled(false);
							that.getView().byId("oAdditmbtn").setEnabled(false);
							that.getView().byId("edit").setEnabled(false);
							that.getView().byId("idcopy").setEnabled(false);
							that.getView().byId("idedit").setEnabled(false);
							//that.getView().byId("oidAttach").setEnabled(false);
							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);
							// that.getView().byId("InputValuePR").setEnabled(false);
							//that.getView().byId("oFIleuploadrid").setEnabled(false);
							that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
							that.getView().byId("oUndbChecbx").setEnabled(false);
							that.getView().byId("oTxtvalue").setEnabled(false);
							that.getView().byId("idReject").setEnabled(false);
							if (that.FilteredghdData.Action == "A") {
								var ActionKey = "A";
								var Action = "Approve";
							} else if (that.FilteredghdData.Action == "R") {
								var ActionKey = "R";
								var Action = "Reject";
							}
							var SamData = {
								data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [

											{
												stats: that.FilteredghdData.Status,
												statskey: that.FilteredghdData.Status
											}, {
												stats: that.FilteredghdData.Status,
												statskey: that.FilteredghdData.Status
											}

										],
										Remarks: that.FilteredghdData.Remarks,
										Action2Visible: false,
										Action: [

											{
												Atcn: Action,
												ActnKey: ActionKey
											}, {
												Atcn: Action,
												ActnKey: ActionKey
											}

										]

									}, {
										Reviewer: "Ham",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											}, {
												stats: "Delivered from Inventory",
												statskey: "Inventory"
											}, {
												stats: "Back to back buy",
												statskey: "Backtobuy"
											}, {
												stats: "Allocated",
												statskey: "Allocated"
											}, {
												stats: "Non Standard",
												statskey: "Non Standard"
											}, {
												stats: "Quote Attached",
												statskey: "Quuote Attached"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [

											{
												Atcn: "--Please Select--"

											}, {
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									},

									{
										Reviewer: "Buyer",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											}, {
												stats: "Quote attached",
												statskey: "Quoteattached"
											}, {
												stats: "Requirement Change",
												statskey: "Requirementchange"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{
												Atcn: "--Please Select--"

											}, {
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}

								]

							};
							var GhdModel = new sap.ui.model.json.JSONModel();
							GhdModel.setData(SamData);
							that.getView().byId("oshmTable").setModel(GhdModel);

						}*/
					} else if (that.PendingWith == "BUY") {}

				} else {
					if (that.oLoggeduser == that.oPrCreatedby) {
						that.getView().byId("ItemTable1").setMode("MultiSelect");

						that.getView().byId("idSave").setEnabled(true);
						that.getView().byId("oAdditmbtn").setEnabled(true);
						that.getView().byId("edit").setEnabled(true);
						that.getView().byId("idcopy").setEnabled(true);
						that.getView().byId("idedit").setEnabled(true);
						//that.getView().byId("oidAttach").setEnabled(true);
						that.getView().byId("InputValueAgrmt").setEnabled(false);
						that.getView().byId("InputValuePlnt").setEnabled(false);
						that.getView().byId("InputValueRequr").setEnabled(false);
						that.getView().byId("InputValueBDept").setEnabled(false);
						that.getView().byId("InputValueBU1").setEnabled(false);
						that.getView().byId("idPrType").setEnabled(false);
						that.getView().byId("idPGrp").setEnabled(false);
						that.getView().byId("idReqType").setEnabled(false);
						that.getView().byId("idInputFileNumber").setEnabled(false);
						that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
						//	that.getView().byId("oFIleuploadrid").setEnabled(true);
						that.getView().byId("oUndbChecbx").setEnabled(false);
						that.getView().byId("oTxtvalue").setEnabled(true);
						that.getView().byId("idReject").setEnabled(true);
						//	that.getView().byId("ItemTable1").setMode("MultiSelect");

						var SamData = {
							data: [{
									Reviewer: "PR Creator/Manager",
									editable: true,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Forward",
											statskey: "forward"
										}, {
											stats: "No requirement",
											statskey: "Norequirement"
										}

									],
									Remarks: "",
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								}, {
									Reviewer: "SAM",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Delivered from Inventory",
											statskey: "Inventory"
										}, {
											stats: "Back to back buy",
											statskey: "Backtobuy"
										}, {
											stats: "Allocated",
											statskey: "Allocated"
										}, {
											stats: "Non Standard",
											statskey: "Non Standard"
										}, {
											stats: "Quote Attached",
											statskey: "Quuote Attached"
										}

									],
									Remarks: "",
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								},

								{
									Reviewer: "Buyer",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Quote attached",
											statskey: "Quoteattached"
										}, {
											stats: "Requirement Change",
											statskey: "Requirementchange"
										}

									],
									Remarks: "",
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								}

							]

						};
						var GhdModel = new sap.ui.model.json.JSONModel();
						GhdModel.setData(SamData);
						that.getView().byId("oshmTable").setModel(GhdModel);

					} else {
						that.getView().byId("ItemTable1").setMode("None");
						var SamData = {
							data: [{
									Reviewer: "PR Creator/Manager",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Forward",
											statskey: "forward"
										}, {
											stats: "No requirement",
											statskey: "Norequirement"
										}

									],
									Remarks: "",
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								}, {
									Reviewer: "SAM",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Delivered from Inventory",
											statskey: "Inventory"
										}, {
											stats: "Back to back buy",
											statskey: "Backtobuy"
										}, {
											stats: "Allocated",
											statskey: "Allocated"
										}, {
											stats: "Non Standard",
											statskey: "Non Standard"
										}, {
											stats: "Quote Attached",
											statskey: "Quuote Attached"
										}

									],
									Remarks: "",
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								},

								{
									Reviewer: "Buyer",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Quote attached",
											statskey: "Quoteattached"
										}, {
											stats: "Requirement Change",
											statskey: "Requirementchange"
										}

									],
									Remarks: "",
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								}

							]

						};
						var GhdModel = new sap.ui.model.json.JSONModel();
						GhdModel.setData(SamData);
						that.getView().byId("oshmTable").setModel(GhdModel);

						that.getView().byId("idSave").setEnabled(false);
						that.getView().byId("oAdditmbtn").setEnabled(false);
						that.getView().byId("edit").setEnabled(false);
						that.getView().byId("idcopy").setEnabled(false);
						that.getView().byId("idedit").setEnabled(false);
						//that.getView().byId("oidAttach").setEnabled(false);
						that.getView().byId("InputValueAgrmt").setEnabled(false);
						that.getView().byId("InputValuePlnt").setEnabled(false);
						that.getView().byId("InputValueRequr").setEnabled(false);
						that.getView().byId("InputValueBDept").setEnabled(false);
						that.getView().byId("InputValueBU1").setEnabled(false);
						that.getView().byId("idPrType").setEnabled(false);
						that.getView().byId("idPGrp").setEnabled(false);
						that.getView().byId("idReqType").setEnabled(false);
						that.getView().byId("idInputFileNumber").setEnabled(false);
						//that.getView().byId("InputValuePR").setEnabled(false);
						//	that.getView().byId("oFIleuploadrid").setEnabled(false);
						that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
						that.getView().byId("oUndbChecbx").setEnabled(false);
						that.getView().byId("oTxtvalue").setEnabled(false);
						that.getView().byId("idReject").setEnabled(false);
						that.getView().byId("ItemTable1").setMode("None");

					}

				}

				//	var RequestCategory = that.getView().byId("idPrType").getSelectedItem();
				var RequestCategory = that.oEditRequestCategoryDropdown;
				if (RequestCategory) {
					//		RequestCategory = RequestCategory.getText();
					if (RequestCategory == "HARDWARE") {
						if (that.getView().byId("oshmTable").getModel().getData().data.length > 1) {
							that.getView().byId("oshmTable").getModel().getData().data[1].Reviewer = "HAM";
						}
					} else if (RequestCategory == "SOFTWARE") {
						if (that.getView().byId("oshmTable").getModel().getData().data.length > 1) {
							that.getView().byId("oshmTable").getModel().getData().data[1].Reviewer = "SAM";
						}
					} else {
						that.getView().byId("oshmTable").getModel().getData().data.splice(1, 1);
					}
					that.getView().byId("oshmTable").getModel().refresh(true);
				}

			} else {

				if (ghdData.length) {

					if (that.PendingWith == "") {

						if (that.oLoggeduser == that.oPrCreatedby) {
							that.getView().byId("ItemTable1").setMode("MultiSelect");
							var ApprovManager = ghdData.filter(function (x) {
								//	return x.PendingWith == "SAM" || x.PendingWith == "HAM";
								return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
							});

							if (that.oEditDocType === "ZSS") {
								if (ApprovManager[0].Action == "F") {

									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									} else if (ApprovManager[0].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
										ApprovManager[2].Status = ApprovManager[0].ReviewerStatus;
										ApprovManager[2].Remarks = ApprovManager[0].ReviewerRem;

									}

									var ApprovBuyer = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									if (ApprovBuyer[0].Action == "A") {
										var ApprovBuyerActionKey = "A";
										var ApprovBuyerAction = "Approve";
									} else if (ApprovBuyer[0].Action == "R") {
										var ApprovBuyerActionKey = "R";
										var ApprovBuyerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									/*	if (ApprovManager[0].Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (ApprovManager[0].Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (ApprovManager[0].Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (ApprovManager[0].Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (ApprovManager[0].Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}, {
														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}

												],
												Remarks: ApprovManager[1].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: "Approve",
														ActnKey: ApprovManager[1].Action
													}, {
														Atcn: "Approve",
														ActnKey: ApprovManager[1].Action
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: true,

												/*	Action2: [

														{
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}, {
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}, {
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}, {
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}, {
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}

													],*/
												Action2: that.getView().getModel("oSecondLevUserslist").getData(),
												ActnKey2: ApprovSAM[0].Approver2Id,

												Action: [{
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [

													{
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}, {
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}

												],
												Remarks: ApprovBuyer[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									////that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
								} else {
									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}
									var ApprovBuyer = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									if (ApprovBuyer[0].Action == "A") {
										var ApprovBuyerActionKey = "A";
										var ApprovBuyerAction = "Approve";
									} else if (ApprovBuyer[0].Action == "R") {
										var ApprovBuyerActionKey = "R";
										var ApprovBuyerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: false,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [

													{
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}, {
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}

												],
												Remarks: ApprovBuyer[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									////that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);

									//
								}
							} else {
								if (ApprovManager.length > 1) {
									var len = 1;
								} else {
									var len = 0;
								}

								if (ApprovManager[len].Action == "F") {

									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									} else if (ApprovManager[0].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
										ApprovManager[2].Status = ApprovManager[0].ReviewerStatus;
										ApprovManager[2].Remarks = ApprovManager[0].ReviewerRem;

									}

									var ApprovBuyer = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									if (ApprovBuyer[0].Action == "A") {
										var ApprovBuyerActionKey = "A";
										var ApprovBuyerAction = "Approve";
									} else if (ApprovBuyer[0].Action == "R") {
										var ApprovBuyerActionKey = "R";
										var ApprovBuyerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									/*	if (ApprovManager[0].Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (ApprovManager[0].Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (ApprovManager[0].Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (ApprovManager[0].Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (ApprovManager[0].Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}, {
														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}

												],
												Remarks: ApprovManager[1].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: "Approve",
														ActnKey: ApprovManager[1].Action
													}, {
														Atcn: "Approve",
														ActnKey: ApprovManager[1].Action
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: true,
												Action2: that.getView().getModel("oSecondLevUserslist").getData(),
												ActnKey2: ApprovSAM[0].Approver2Id,

												/*	Action2: [

														{
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}, {
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}, {
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}, {
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}, {
															Atcn2: Atcn2,
															ActnKey2: ActnKey2
														}

													],*/

												Action: [{
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [

													{
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}, {
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}

												],
												Remarks: ApprovBuyer[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									////that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
								} else {
									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}
									var ApprovBuyer = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									if (ApprovBuyer[0].Action == "A") {
										var ApprovBuyerActionKey = "A";
										var ApprovBuyerAction = "Approve";
									} else if (ApprovBuyer[0].Action == "R") {
										var ApprovBuyerActionKey = "R";
										var ApprovBuyerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: false,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [

													{
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}, {
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}

												],
												Remarks: ApprovBuyer[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									////that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);

									//
								}
							}

							/*if (ApprovManager[0].Action == "A") {
								var ApprovManagerActionKey = "A";
								var ApprovManagerAction = "Approve";
							} else if (ApprovManager[0].Action == "R") {
								var ApprovManagerActionKey = "R";
								var ApprovManagerAction = "Reject";
							}
							var ApprovBuyer = ghdData.filter(function (x) {
								return x.PendingWith == "";
							});
							if (ApprovBuyer[0].Action == "A") {
								var ApprovBuyerActionKey = "A";
								var ApprovBuyerAction = "Approve";
							} else if (ApprovBuyer[0].Action == "R") {
								var ApprovBuyerActionKey = "R";
								var ApprovBuyerAction = "Reject";
							}

							var ApprovSAM = ghdData.filter(function (x) {
								return x.PendingWith == "BUY";
							});

							if (ApprovSAM[0].Action == "A") {
								var ApprovSAMManagerActionKey = "A";
								var ApprovSAMManagerAction = "Approve";
							} else if (ApprovSAM[0].Action == "R") {
								var ApprovSAMManagerActionKey = "R";
								var ApprovSAMManagerAction = "Reject";
							}

							var SamData = {
								data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [{

												stats: ApprovManager[0].Status,
												statskey: ApprovManager[0].Status
											}, {
												stats: ApprovManager[0].Status,
												statskey: ApprovManager[0].Status
											}

										],
										Remarks: ApprovManager[0].Remarks,
										Action: [

											{
												Atcn: ApprovManagerAction,
												ActnKey: ApprovManagerActionKey
											}, {
												Atcn: ApprovManagerAction,
												ActnKey: ApprovManagerActionKey
											}

										]

									}, {
										Reviewer: "SAM",
										editable: false,
										Status: [{
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}, {
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}, {
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}, {
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}, {
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}

										],
										Remarks: ApprovSAM[0].Remarks,
										Action: [{
												Atcn: ApprovSAMManagerAction,
												ActnKey: ApprovSAMManagerActionKey
											}, {
												Atcn: ApprovSAMManagerAction,
												ActnKey: ApprovSAMManagerActionKey
											}

										]

									},

									{
										Reviewer: "Buyer",
										editable: false,
										Status: [

											{
												stats: ApprovBuyer[0].Status,
												statskey: ApprovBuyer[0].Status
											}, {
												stats: ApprovBuyer[0].Status,
												statskey: ApprovBuyer[0].Status
											}

										],
										Remarks: ApprovBuyer[0].Remarks,
										Action: [

											{
												Atcn: ApprovSAMManagerAction,
												ActnKey: ApprovSAMManagerActionKey
											}, {
												Atcn: ApprovSAMManagerAction,
												ActnKey: ApprovSAMManagerActionKey
											}

										]

									}

								]

							};

							var GhdModel = new sap.ui.model.json.JSONModel();
							GhdModel.setData(SamData);
							that.getView().byId("oshmTable").setModel(GhdModel);

							that.getView().byId("idSave").setEnabled(false);
							that.getView().byId("oAdditmbtn").setEnabled(false);
							that.getView().byId("edit").setEnabled(false);
							that.getView().byId("idcopy").setEnabled(false);
							that.getView().byId("idedit").setEnabled(false);
						
							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);
						
							that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
							that.getView().byId("oUndbChecbx").setEnabled(false);
							that.getView().byId("oTxtvalue").setEnabled(false);
							that.getView().byId("idReject").setEnabled(false);

						} else {
							that.getView().byId("ItemTable1").setMode("None");
							that.getView().byId("idSave").setEnabled(false);
							that.getView().byId("oAdditmbtn").setEnabled(false);
							that.getView().byId("edit").setEnabled(false);
							that.getView().byId("idcopy").setEnabled(false);
							that.getView().byId("idedit").setEnabled(false);
						
							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);

							that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
							that.getView().byId("oUndbChecbx").setEnabled(false);
							that.getView().byId("oTxtvalue").setEnabled(false);
							that.getView().byId("idReject").setEnabled(false);
							that.getView().byId("ItemTable1").setMode("None");

							var ApprovManager = ghdData.filter(function (x) {
							
								return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
							});

							ApprovManager.sort(function (a, b) {
								return a.CurrentStat - b.CurrentStat;

							})
							if (ApprovManager[0].Action == "A") {
								var ApprovManagerActionKey = "A";
								var ApprovManagerAction = "Approve";
							} else if (ApprovManager[0].Action == "R") {
								var ApprovManagerActionKey = "R";
								var ApprovManagerAction = "Reject";
							}
							var ApprovBuyer = ghdData.filter(function (x) {
								return x.PendingWith == "";
							});
							if (ApprovBuyer[0].Action == "A") {
								var ApprovBuyerActionKey = "A";
								var ApprovBuyerAction = "Approve";
							} else if (ApprovBuyer[0].Action == "R") {
								var ApprovBuyerActionKey = "R";
								var ApprovBuyerAction = "Reject";
							}

							var ApprovSAM = ghdData.filter(function (x) {
								return x.PendingWith == "BUY";
							});

							if (ApprovSAM[0].Action == "A") {
								var ApprovSAMManagerActionKey = "A";
								var ApprovSAMManagerAction = "Approve";
							} else if (ApprovSAM[0].Action == "R") {
								var ApprovSAMManagerActionKey = "R";
								var ApprovSAMManagerAction = "Reject";
							}

							var SamData = {
								data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [{

												stats: ApprovManager[0].Status,
												statskey: ApprovManager[0].Status
											}, {
												stats: ApprovManager[0].Status,
												statskey: ApprovManager[0].Status
											}

										],
										Remarks: ApprovManager[0].Remarks,
										Action: [

											{
												Atcn: ApprovManagerAction,
												ActnKey: ApprovManagerActionKey
											}, {
												Atcn: ApprovManagerAction,
												ActnKey: ApprovManagerActionKey
											}

										]

									}, {
										Reviewer: "SAM",
										editable: false,
										Status: [{
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}, {
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}, {
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}, {
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}, {
												stats: ApprovSAM[0].Status,
												statskey: ApprovSAM[0].Status
											}

										],
										Remarks: ApprovSAM[0].Remarks,
										Action: [{
												Atcn: ApprovSAMManagerAction,
												ActnKey: ApprovSAMManagerActionKey
											}, {
												Atcn: ApprovSAMManagerAction,
												ActnKey: ApprovSAMManagerActionKey
											}

										]

									},

									{
										Reviewer: "Buyer",
										editable: false,
										Status: [

											{
												stats: ApprovBuyer[0].Status,
												statskey: ApprovBuyer[0].Status
											}, {
												stats: ApprovBuyer[0].Status,
												statskey: ApprovBuyer[0].Status
											}

										],
										Remarks: ApprovBuyer[0].Remarks,
										Action: [

											{
												Atcn: ApprovSAMManagerAction,
												ActnKey: ApprovSAMManagerActionKey
											}, {
												Atcn: ApprovSAMManagerAction,
												ActnKey: ApprovSAMManagerActionKey
											}

										]

									}

								]

							};
							var GhdModel = new sap.ui.model.json.JSONModel();
							GhdModel.setData(SamData);
							that.getView().byId("oshmTable").setModel(GhdModel);*/
						} else {

							var ApprovManager = ghdData.filter(function (x) {
								//	return x.PendingWith == "SAM" || x.PendingWith == "HAM";
								return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
							});

							if (that.oEditDocType === "ZSS") {
								if (ApprovManager[0].Action == "F") {

									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									} else if (ApprovManager[0].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
										ApprovManager[2].Status = ApprovManager[0].ReviewerStatus;
										ApprovManager[2].Remarks = ApprovManager[0].ReviewerRem;

									}

									var ApprovBuyer = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									if (ApprovBuyer[0].Action == "A") {
										var ApprovBuyerActionKey = "A";
										var ApprovBuyerAction = "Approve";
									} else if (ApprovBuyer[0].Action == "R") {
										var ApprovBuyerActionKey = "R";
										var ApprovBuyerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									/*	if (ApprovManager[0].Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (ApprovManager[0].Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (ApprovManager[0].Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (ApprovManager[0].Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (ApprovManager[0].Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}, {
														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}

												],
												Remarks: ApprovManager[1].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: "Approve",
														ActnKey: ApprovManager[1].Action
													}, {
														Atcn: "Approve",
														ActnKey: ApprovManager[1].Action
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: true,
												Action2: that.getView().getModel("oSecondLevUserslist").getData(),
												ActnKey2: ApprovSAM[0].Approver2Id,

												/*Action2: [

													{
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}

												],*/

												Action: [{
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [

													{
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}, {
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}

												],
												Remarks: ApprovBuyer[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									////that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
								} else {
									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}
									var ApprovBuyer = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									if (ApprovBuyer[0].Action == "A") {
										var ApprovBuyerActionKey = "A";
										var ApprovBuyerAction = "Approve";
									} else if (ApprovBuyer[0].Action == "R") {
										var ApprovBuyerActionKey = "R";
										var ApprovBuyerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: false,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [

													{
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}, {
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}

												],
												Remarks: ApprovBuyer[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									////that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);

									//
								}
							} else {

								if (ApprovManager.length > 1) {
									var len = 1;
								} else {
									var len = 0;
								}

								if (ApprovManager[len].Action == "F") {

									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									} else if (ApprovManager[0].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
										ApprovManager[2].Status = ApprovManager[0].ReviewerStatus;
										ApprovManager[2].Remarks = ApprovManager[0].ReviewerRem;

									}

									var ApprovBuyer = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									if (ApprovBuyer[0].Action == "A") {
										var ApprovBuyerActionKey = "A";
										var ApprovBuyerAction = "Approve";
									} else if (ApprovBuyer[0].Action == "R") {
										var ApprovBuyerActionKey = "R";
										var ApprovBuyerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									/*	if (ApprovManager[0].Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (ApprovManager[0].Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (ApprovManager[0].Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (ApprovManager[0].Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (ApprovManager[0].Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}, {
														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}

												],
												Remarks: ApprovManager[1].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: "Approve",
														ActnKey: ApprovManager[1].Action
													}, {
														Atcn: "Approve",
														ActnKey: ApprovManager[1].Action
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: true,
												Action2: that.getView().getModel("oSecondLevUserslist").getData(),
												ActnKey2: ApprovSAM[0].Approver2Id,

												/*Action2: [

													{
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}, {
														Atcn2: Atcn2,
														ActnKey2: ActnKey2
													}

												],*/

												Action: [{
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [

													{
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}, {
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}

												],
												Remarks: ApprovBuyer[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									////that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
								} else {
									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}
									var ApprovBuyer = ghdData.filter(function (x) {
										return x.PendingWith == "";
									});
									if (ApprovBuyer[0].Action == "A") {
										var ApprovBuyerActionKey = "A";
										var ApprovBuyerAction = "Approve";
									} else if (ApprovBuyer[0].Action == "R") {
										var ApprovBuyerActionKey = "R";
										var ApprovBuyerAction = "Reject";
									}

									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: false,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [

													{
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}, {
														stats: ApprovBuyer[0].Status,
														statskey: ApprovBuyer[0].Status
													}

												],
												Remarks: ApprovBuyer[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									////that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);

									//
								}
							}

						}

					} else if (that.PendingWith == "PM") {
						var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

						that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

						var path = "/ymm_manager_setSet";
						that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

							var oManagermodelref = oData.results;
							that.oFilteredManager = oManagermodelref.filter(function (x) {
								return x.User == that.oLoggeduser;
							});
						}, function (error) {
							that.oFilteredHAM = [];
						});

						if (that.oFilteredManager.length) {

							if (that.oLoggeduser == that.oFilteredManager[0].User) {
								that.getView().byId("ItemTable1").setMode("MultiSelect");
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: true,
											Status: [{

													stats: "--Please Select--"

												}, {

													stats: "Forward",
													statskey: "forward"
												}, {
													stats: "No requirement",
													statskey: "Norequirement"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{

													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{

													stats: "--Please Select--"

												},

												{
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,

											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

								that.getView().byId("idSave").setEnabled(true);
								that.getView().byId("oAdditmbtn").setEnabled(true);
								that.getView().byId("edit").setEnabled(true);
								that.getView().byId("idcopy").setEnabled(true);
								that.getView().byId("idedit").setEnabled(true);
								//that.getView().byId("oidAttach").setEnabled(true);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(true);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(true);
								that.getView().byId("idReject").setEnabled(true);

							} else {
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								//	that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);

								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Forward",
													statskey: "forward"
												}, {
													stats: "No requirement",
													statskey: "Norequirement"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}
						} else if (that.oLoggeduser == that.oPrCreatedby) { // implementd for Normal PR

							that.getView().byId("idSave").setEnabled(true);
							that.getView().byId("oAdditmbtn").setEnabled(true);
							that.getView().byId("edit").setEnabled(true);
							that.getView().byId("idcopy").setEnabled(true);
							that.getView().byId("idedit").setEnabled(true);
							//that.getView().byId("oidAttach").setEnabled(false);
							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);
							// that.getView().byId("InputValuePR").setEnabled(false);
							//	that.getView().byId("oFIleuploadrid").setEnabled(false);
							that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
							that.getView().byId("oUndbChecbx").setEnabled(true);
							that.getView().byId("oTxtvalue").setEnabled(true);
							that.getView().byId("idReject").setEnabled(true);

							var SamData = {
								data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											},

											{
												stats: "Forward",
												statskey: "forward"
											}, {
												stats: "No requirement",
												statskey: "Norequirement"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{
												Atcn: "--Please Select--"

											},

											{
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}, {
										Reviewer: "SAM",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											},

											{
												stats: "Delivered from Inventory",
												statskey: "Inventory"
											}, {
												stats: "Back to back buy",
												statskey: "Backtobuy"
											}, {
												stats: "Allocated",
												statskey: "Allocated"
											}, {
												stats: "Non Standard",
												statskey: "Non Standard"
											}, {
												stats: "Quote Attached",
												statskey: "Quuote Attached"
											}

										],
										Remarks: "",
										Action2Visible: true,
										Action: [{
												Atcn: "--Please Select--"

											},

											{
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									},

									{
										Reviewer: "Buyer",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											},

											{
												stats: "Quote attached",
												statskey: "Quoteattached"
											}, {
												stats: "Requirement Change",
												statskey: "Requirementchange"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{
												Atcn: "--Please Select--"

											},

											{
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}

								]

							};
							var GhdModel = new sap.ui.model.json.JSONModel();
							GhdModel.setData(SamData);
							that.getView().byId("oshmTable").setModel(GhdModel);

						} else if (that.oLoggeduser != that.oPrCreatedby || that.oLoggeduser != that.oFilteredManager[0].User) {

							that.getView().byId("idSave").setEnabled(false);
							that.getView().byId("oAdditmbtn").setEnabled(false);
							that.getView().byId("edit").setEnabled(false);
							that.getView().byId("idcopy").setEnabled(false);
							that.getView().byId("idedit").setEnabled(false);
							//that.getView().byId("oidAttach").setEnabled(false);
							that.getView().byId("InputValueAgrmt").setEnabled(false);
							that.getView().byId("InputValuePlnt").setEnabled(false);
							that.getView().byId("InputValueRequr").setEnabled(false);
							that.getView().byId("InputValueBDept").setEnabled(false);
							that.getView().byId("InputValueBU1").setEnabled(false);
							that.getView().byId("idPrType").setEnabled(false);
							that.getView().byId("idPGrp").setEnabled(false);
							that.getView().byId("idReqType").setEnabled(false);
							that.getView().byId("idInputFileNumber").setEnabled(false);
							// that.getView().byId("InputValuePR").setEnabled(false);
							//	that.getView().byId("oFIleuploadrid").setEnabled(false);
							that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
							that.getView().byId("oUndbChecbx").setEnabled(false);
							that.getView().byId("oTxtvalue").setEnabled(false);
							that.getView().byId("idReject").setEnabled(false);

							var SamData = {
								data: [{
										Reviewer: "PR Creator/Manager",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											},

											{
												stats: "Forward",
												statskey: "forward"
											}, {
												stats: "No requirement",
												statskey: "Norequirement"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{
												Atcn: "--Please Select--"

											},

											{
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}, {
										Reviewer: "SAM",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											},

											{
												stats: "Delivered from Inventory",
												statskey: "Inventory"
											}, {
												stats: "Back to back buy",
												statskey: "Backtobuy"
											}, {
												stats: "Allocated",
												statskey: "Allocated"
											}, {
												stats: "Non Standard",
												statskey: "Non Standard"
											}, {
												stats: "Quote Attached",
												statskey: "Quuote Attached"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{
												Atcn: "--Please Select--"

											},

											{
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									},

									{
										Reviewer: "Buyer",
										editable: false,
										Status: [{
												stats: "--Please Select--"

											},

											{
												stats: "Quote attached",
												statskey: "Quoteattached"
											}, {
												stats: "Requirement Change",
												statskey: "Requirementchange"
											}

										],
										Remarks: "",
										Action2Visible: false,
										Action: [{
												Atcn: "--Please Select--"

											},

											{
												Atcn: "Approve",
												ActnKey: "A"
											}, {
												Atcn: "Reject",
												ActnKey: "R"
											}

										]

									}

								]

							};
							var GhdModel = new sap.ui.model.json.JSONModel();
							GhdModel.setData(SamData);
							that.getView().byId("oshmTable").setModel(GhdModel);

						}

					} else if (that.PendingWith == "SAM") {

						var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

						that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

						var path = "/YMM_PR_SAMSet";
						that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

							var oHamsetmodelref = oData.results;
							that.oFilteredSAM = oHamsetmodelref.filter(function (x) {
								return x.AFNAM == that.oLoggeduser;
							});
						}, function (error) {
							that.oFilteredSAM = [];
						});
						if (that.oFilteredSAM.length) {
							if (that.oLoggeduser == that.oFilteredSAM[0].AFNAM) {
								that.getView().byId("ItemTable1").setMode("MultiSelect");

								if (that.oFilteredSAM.length) {
									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									} else if (that.FilteredghdData.Action == "F") {
										var ActionKey = "F";
										var Action = "Forward";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: true,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}, {
														Atcn: "Forward",
														ActnKey: "F"
													}

												],

												/*	Action2: [

														{
															Atcn2: "--Please Select--"

														}, {
															Atcn2: "Vijay A",
															ActnKey2: "VA3833"
														}, {
															Atcn2: "Srinivas Ch",
															ActnKey2: "SC0430"
														}, {
															Atcn2: "Basha S",
															ActnKey2: "BS2931"
														}, {
															Atcn2: "Denis C",
															ActnKey2: "DC30338"
														}, {
															Atcn2: "Suman B",
															ActnKey2: "SB3817"
														}

													]*/
												Action2: that.getView().getModel("oSecondLevUserslist").getData()

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									if (that.FilteredghdData.Actn === "F") {

										if (that.FilteredghdData.ReviewerStatus === "Inventory") {
											var stats = "Delivered from Inventory";
											var statskey = "Inventory"
										} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
											var stats = "Back to back buy";
											var statskey = "Backtobuy";
										} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
											var stats = "Allocated";
											var statskey = "Allocated";
										} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
											var stats = "Non Standard";
											var statskey = "Non Standard";
										} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
											var stats = "Quote Attached";
											var statskey = "Quuote Attached";
										}

										/*	if (that.FilteredghdData.Approver2Id === "VA3833") {
												var Atcn2 = "Vijay A";
												var ActnKey2 = "VA3833";
											} else if (that.FilteredghdData.Approver2Id === "SC0430") {
												var Atcn2 = "Srinivas Ch";
												var ActnKey2 = "SC0430";
											} else if (that.FilteredghdData.Approver2Id === "BS2931") {
												var Atcn2 = "Basha S";
												var ActnKey2 = "BS2931";
											} else if (that.FilteredghdData.Approver2Id === "DC30338") {
												var Atcn2 = "Denis C";
												var ActnKey2 = "DC30338";
											} else if (that.FilteredghdData.Approver2Id === "SB3817") {
												var Atcn2 = "Suman B";
												var ActnKey2 = "SB3817";
											}*/

										SamData.data.splice(1, 1);
										var Obj = {
											Reviewer: that.FilteredghdData.PendingWith,
											editable: false,
											Status: [{
													stats: stats,
													statskey: statskey
												}, {
													stats: stats,
													statskey: statskey

												}

											],
											Remarks: that.FilteredghdData.ReviewerRem,
											Action2Visible: true,
											Action2: that.getView().getModel("oSecondLevUserslist").getData(),
											ActnKey2: that.FilteredghdData.Approver2Id,

											Action: [

												{
													Atcn: "Forward",
													ActnKey: "F"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											]

										};

										SamData.data.splice(1, 0, Obj);
									}

									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);
									that.getView().byId("idSave").setEnabled(true);

									that.getView().byId("oAdditmbtn").setEnabled(true);
									that.getView().byId("edit").setEnabled(true);
									that.getView().byId("idcopy").setEnabled(true);
									that.getView().byId("idedit").setEnabled(true);
									//that.getView().byId("oidAttach").setEnabled(true);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

									//	that.getView().byId("oFIleuploadrid").setEnabled(true);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(true);
									that.getView().byId("idReject").setEnabled(true);

								} else {
									//Display code
									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									//that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									/* that.getView().byId("idSave").setEnabled(false);*/

									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													},

													{
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

								}

							} else {
								that.getView().byId("ItemTable1").setMode("None");
								//Display code
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								/* that.getView().byId("idSave").setEnabled(false);*/
								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}
						} else {

							if (that.oFilteredSAM.length == "0") {

								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								} else if (that.FilteredghdData.Action == "F") {
									var ActionKey = "F";
									var Action = "Forward";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action2Visible: false,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											],

											/*	Action2: [

													{
														Atcn2: "--Please Select--"

													}, {
														Atcn2: "Vijay A",
														ActnKey2: "VA3833"
													}, {
														Atcn2: "Srinivas Ch",
														ActnKey2: "SC0430"
													}, {
														Atcn2: "Basha S",
														ActnKey2: "BS2931"
													}, {
														Atcn2: "Denis C",
														ActnKey2: "DC30338"
													}, {
														Atcn2: "Suman B",
														ActnKey2: "SB3817"
													}

												]*/
											Action2: that.getView().getModel("oSecondLevUserslist").getData()

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};

								var GhdModel = new sap.ui.model.json.JSONModel();
								if (that.FilteredghdData.Actn === "F") {

									if (that.FilteredghdData.ReviewerStatus === "Inventory") {
										var stats = "Delivered from Inventory";
										var statskey = "Inventory"
									} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
										var stats = "Back to back buy";
										var statskey = "Backtobuy";
									} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
										var stats = "Allocated";
										var statskey = "Allocated";
									} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
										var stats = "Non Standard";
										var statskey = "Non Standard";
									} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
										var stats = "Quote Attached";
										var statskey = "Quuote Attached";
									}

									/*	if (that.FilteredghdData.Approver2Id === "VA3833") {
											var Atcn2 = "Vijay A";
											var ActnKey2 = "VA3833";
										} else if (that.FilteredghdData.Approver2Id === "SC0430") {
											var Atcn2 = "Srinivas Ch";
											var ActnKey2 = "SC0430";
										} else if (that.FilteredghdData.Approver2Id === "BS2931") {
											var Atcn2 = "Basha S";
											var ActnKey2 = "BS2931";
										} else if (that.FilteredghdData.Approver2Id === "DC30338") {
											var Atcn2 = "Denis C";
											var ActnKey2 = "DC30338";
										} else if (that.FilteredghdData.Approver2Id === "SB3817") {
											var Atcn2 = "Suman B";
											var ActnKey2 = "SB3817";
										}*/

									SamData.data.splice(1, 1);
									var Obj = {
										Reviewer: that.FilteredghdData.PendingWith,
										editable: false,
										Status: [{
												stats: stats,
												statskey: statskey
											}, {
												stats: stats,
												statskey: statskey

											}

										],
										Remarks: that.FilteredghdData.ReviewerRem,
										Action2Visible: true,
										Action2: that.getView().getModel("oSecondLevUserslist").getData(),
										ActnKey2: that.FilteredghdData.Approver2Id,

										Action: [

											{
												Atcn: "Forward",
												ActnKey: "F"
											}, {
												Atcn: "Forward",
												ActnKey: "F"
											}

										]

									};

									SamData.data.splice(1, 0, Obj);
								}

								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);
								that.getView().byId("idSave").setEnabled(false);

								that.getView().byId("oAdditmbtn").setEnabled(true);
								that.getView().byId("edit").setEnabled(true);
								that.getView().byId("idcopy").setEnabled(true);
								that.getView().byId("idedit").setEnabled(true);
								//that.getView().byId("oidAttach").setEnabled(true);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(true);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);

							} else {

								//Display code
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								/* that.getView().byId("idSave").setEnabled(false);*/

								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}

						}
					} else if (that.PendingWith == "HAM") {
						var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

						that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

						var path = "/YMM_PR_HAMSet";
						that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

							var oHamsetmodelref = oData.results;
							that.oFilteredHAM = oHamsetmodelref.filter(function (x) {
								return x.AFNAM == that.oLoggeduser;
							});
						}, function (error) {
							that.oFilteredHAM = [];
						});

						if (that.oFilteredHAM.length) {
							if (that.oLoggeduser == that.oFilteredHAM[0].AFNAM) {
								that.getView().byId("ItemTable1").setMode("MultiSelect");

								if (that.oFilteredHAM.length) {
									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									} else if (that.FilteredghdData.Action == "F") {
										var ActionKey = "F";
										var Action = "Forward";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "HAM",
												editable: true,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}, {
														Atcn: "Forward",
														ActnKey: "F"
													}

												],

												/*Action2: [

													{
														Atcn2: "--Please Select--"

													}, {
														Atcn2: "Vijay A",
														ActnKey2: "VA3833"
													}, {
														Atcn2: "Srinivas Ch",
														ActnKey2: "SC0430"
													}, {
														Atcn2: "Basha S",
														ActnKey2: "BS2931"
													}, {
														Atcn2: "Denis C",
														ActnKey2: "DC30338"
													}, {
														Atcn2: "Suman B",
														ActnKey2: "SB3817"
													}

												]*/
												Action2: that.getView().getModel("oSecondLevUserslist").getData()

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									if (that.FilteredghdData.Actn === "F") {

										if (that.FilteredghdData.ReviewerStatus === "Inventory") {
											var stats = "Delivered from Inventory";
											var statskey = "Inventory"
										} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
											var stats = "Back to back buy";
											var statskey = "Backtobuy";
										} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
											var stats = "Allocated";
											var statskey = "Allocated";
										} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
											var stats = "Non Standard";
											var statskey = "Non Standard";
										} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
											var stats = "Quote Attached";
											var statskey = "Quuote Attached";
										}

										/*	if (that.FilteredghdData.Approver2Id === "VA3833") {
												var Atcn2 = "Vijay A";
												var ActnKey2 = "VA3833";
											} else if (that.FilteredghdData.Approver2Id === "SC0430") {
												var Atcn2 = "Srinivas Ch";
												var ActnKey2 = "SC0430";
											} else if (that.FilteredghdData.Approver2Id === "BS2931") {
												var Atcn2 = "Basha S";
												var ActnKey2 = "BS2931";
											} else if (that.FilteredghdData.Approver2Id === "DC30338") {
												var Atcn2 = "Denis C";
												var ActnKey2 = "DC30338";
											} else if (that.FilteredghdData.Approver2Id === "SB3817") {
												var Atcn2 = "Suman B";
												var ActnKey2 = "SB3817";
											}*/

										SamData.data.splice(1, 1);
										var Obj = {
											Reviewer: that.FilteredghdData.PendingWith,
											editable: false,
											Status: [{
													stats: stats,
													statskey: statskey
												}, {
													stats: stats,
													statskey: statskey

												}

											],
											Remarks: that.FilteredghdData.ReviewerRem,
											Action2Visible: true,
											Action2: that.getView().getModel("oSecondLevUserslist").getData(),
											ActnKey2: that.FilteredghdData.Approver2Id,

											Action: [

												{
													Atcn: "Forward",
													ActnKey: "F"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											]

										};

										SamData.data.splice(1, 0, Obj);
									}

									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);
									that.getView().byId("idSave").setEnabled(true);

									that.getView().byId("oAdditmbtn").setEnabled(true);
									that.getView().byId("edit").setEnabled(true);
									that.getView().byId("idcopy").setEnabled(true);
									that.getView().byId("idedit").setEnabled(true);
									//that.getView().byId("oidAttach").setEnabled(true);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

									//	that.getView().byId("oFIleuploadrid").setEnabled(true);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(true);
									that.getView().byId("idReject").setEnabled(true);

								} else {
									//Display code
									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									//that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);

									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
									// that.getView().byId("InputValuePR").setEnabled(false);
									/* that.getView().byId("idSave").setEnabled(false);*/

									if (that.FilteredghdData.Action == "A") {
										var ActionKey = "A";
										var Action = "Approve";
									} else if (that.FilteredghdData.Action == "R") {
										var ActionKey = "R";
										var Action = "Reject";
									}
									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [

													{
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}, {
														stats: that.FilteredghdData.Status,
														statskey: that.FilteredghdData.Status
													}

												],
												Remarks: that.FilteredghdData.Remarks,
												Action: [

													{
														Atcn: Action,
														ActnKey: ActionKey
													}, {
														Atcn: Action,
														ActnKey: ActionKey
													}

												]

											}, {
												Reviewer: "HAM",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Delivered from Inventory",
														statskey: "Inventory"
													}, {
														stats: "Back to back buy",
														statskey: "Backtobuy"
													}, {
														stats: "Allocated",
														statskey: "Allocated"
													}, {
														stats: "Non Standard",
														statskey: "Non Standard"
													}, {
														stats: "Quote Attached",
														statskey: "Quuote Attached"
													}

												],
												Remarks: "",
												Action: [{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													},

													{
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action: [

													{
														Atcn: "--Please Select--"

													}, {
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);

								}

							} else {
								that.getView().byId("ItemTable1").setMode("None");
								//Display code
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								/* that.getView().byId("idSave").setEnabled(false);*/
								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "HAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}
						} else {

							if (that.oFilteredHAM.length == "0") {

								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								} else if (that.FilteredghdData.Action == "F") {
									var ActionKey = "F";
									var Action = "Forward";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action2Visible: false,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "HAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}, {
													Atcn: "Forward",
													ActnKey: "F"
												}

											],

											Action2: that.getView().getModel("oSecondLevUserslist").getData()

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};

								var GhdModel = new sap.ui.model.json.JSONModel();
								if (that.FilteredghdData.Actn === "F") {

									if (that.FilteredghdData.ReviewerStatus === "Inventory") {
										var stats = "Delivered from Inventory";
										var statskey = "Inventory"
									} else if (that.FilteredghdData.ReviewerStatus === "BacktobuyBacktobuy") {
										var stats = "Back to back buy";
										var statskey = "Backtobuy";
									} else if (that.FilteredghdData.ReviewerStatus === "Allocated") {
										var stats = "Allocated";
										var statskey = "Allocated";
									} else if (that.FilteredghdData.ReviewerStatus === "Non Standard") {
										var stats = "Non Standard";
										var statskey = "Non Standard";
									} else if (that.FilteredghdData.ReviewerStatus === "Quuote Attached") {
										var stats = "Quote Attached";
										var statskey = "Quuote Attached";
									}

									/*if (that.FilteredghdData.Approver2Id === "VA3833") {
										var Atcn2 = "Vijay A";
										var ActnKey2 = "VA3833";
									} else if (that.FilteredghdData.Approver2Id === "SC0430") {
										var Atcn2 = "Srinivas Ch";
										var ActnKey2 = "SC0430";
									} else if (that.FilteredghdData.Approver2Id === "BS2931") {
										var Atcn2 = "Basha S";
										var ActnKey2 = "BS2931";
									} else if (that.FilteredghdData.Approver2Id === "DC30338") {
										var Atcn2 = "Denis C";
										var ActnKey2 = "DC30338";
									} else if (that.FilteredghdData.Approver2Id === "SB3817") {
										var Atcn2 = "Suman B";
										var ActnKey2 = "SB3817";
									}*/

									SamData.data.splice(1, 1);
									var Obj = {
										Reviewer: that.FilteredghdData.PendingWith,
										editable: false,
										Status: [{
												stats: stats,
												statskey: statskey
											}, {
												stats: stats,
												statskey: statskey

											}

										],
										Remarks: that.FilteredghdData.ReviewerRem,
										Action2Visible: true,
										Action2: that.getView().getModel("oSecondLevUserslist").getData(),
										ActnKey2: that.FilteredghdData.Approver2Id,

										Action: [

											{
												Atcn: "Forward",
												ActnKey: "F"
											}, {
												Atcn: "Forward",
												ActnKey: "F"
											}

										]

									};

									SamData.data.splice(1, 0, Obj);
								}

								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);
								that.getView().byId("idSave").setEnabled(false);

								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(true);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(true);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);

							} else {

								//Display code
								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);

								//	that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								// that.getView().byId("InputValuePR").setEnabled(false);
								/* that.getView().byId("idSave").setEnabled(false);*/

								if (that.FilteredghdData.Action == "A") {
									var ActionKey = "A";
									var Action = "Approve";
								} else if (that.FilteredghdData.Action == "R") {
									var ActionKey = "R";
									var Action = "Reject";
								}
								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [

												{
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}, {
													stats: that.FilteredghdData.Status,
													statskey: that.FilteredghdData.Status
												}

											],
											Remarks: that.FilteredghdData.Remarks,
											Action: [

												{
													Atcn: Action,
													ActnKey: ActionKey
												}, {
													Atcn: Action,
													ActnKey: ActionKey
												}

											]

										}, {
											Reviewer: "HAM",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Delivered from Inventory",
													statskey: "Inventory"
												}, {
													stats: "Back to back buy",
													statskey: "Backtobuy"
												}, {
													stats: "Allocated",
													statskey: "Allocated"
												}, {
													stats: "Non Standard",
													statskey: "Non Standard"
												}, {
													stats: "Quote Attached",
													statskey: "Quuote Attached"
												}

											],
											Remarks: "",
											Action: [

												{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										},

										{
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												}, {
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action: [{
													Atcn: "--Please Select--"

												}, {
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};
								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}

						}

					} else if (that.PendingWith == "BUY") {
						that.getView().byId("ItemTable1").setMode("MultiSelect");

						var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

						that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

						var path = "/YMM_PR_BUYER_IDSet";
						that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

							var oBuyretmodelref = oData.results;
							that.oFilteredBuyer = oBuyretmodelref.filter(function (x) {
								return x.afnam == that.oLoggeduser;
							});
						}, function (error) {
							that.oFilteredBuyer = [];
						});
						if (that.oFilteredBuyer.length) {
							if (that.oLoggeduser == that.oFilteredBuyer[0].afnam) {
								that.getView().byId("ItemTable1").setMode("MultiSelect");

								if (that.oFilteredBuyer.length) {
									var ApprovManager = ghdData.filter(function (x) {
										//	return x.PendingWith == "SAM" || x.PendingWith == "HAM";
										return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
									});

									if (ApprovManager.length > 1) {
										var len = 1;
									} else {
										var len = 0;
									}

									if (ApprovManager[len].Action == "F") {
										ApprovManager.sort(function (a, b) {
											return a.CurrentStat - b.CurrentStat;

										});
										if (ApprovManager[0].Action == "A") {
											var ApprovManagerActionKey = "A";
											var ApprovManagerAction = "Approve";
										} else if (ApprovManager[0].Action == "R") {
											var ApprovManagerActionKey = "R";
											var ApprovManagerAction = "Reject";
										} else if (ApprovManager[0].Action == "F") {
											var ApprovManagerActionKey = "F";
											var ApprovManagerAction = "Forward";
											ApprovManager[2].Status = ApprovManager[0].ReviewerStatus;
											ApprovManager[2].Remarks = ApprovManager[0].ReviewerRem;
											ApprovManager[2].Approver2Id = ApprovManager[0].Approver2Id;

										}
										var ApprovSAM = ghdData.filter(function (x) {
											return x.PendingWith == "BUY";
										});

										if (ApprovSAM[0].Action == "A") {
											var ApprovSAMManagerActionKey = "A";
											var ApprovSAMManagerAction = "Approve";
										} else if (ApprovSAM[0].Action == "R") {
											var ApprovSAMManagerActionKey = "R";
											var ApprovSAMManagerAction = "Reject";
										} else if (ApprovSAM[0].Action == "F") {
											var ApprovSAMManagerActionKey = "F";
											var ApprovSAMManagerAction = "Forward";
											ApprovSAM[0].Status = ApprovManager[0].ReviewerStatus;
											ApprovSAM[0].Remarks = ApprovManager[0].ReviewerRem;
											ApprovSAM[0].Approver2Id = ApprovManager[0].Approver2Id;

										}

										/*	if (ApprovSAM[0].Approver2Id === "VA3833") {
												var Atcn2 = "Vijay A";
												var ActnKey2 = "VA3833";
											} else if (ApprovSAM[0].Approver2Id === "SC0430") {
												var Atcn2 = "Srinivas Ch";
												var ActnKey2 = "SC0430";
											} else if (ApprovSAM[0].Approver2Id === "BS2931") {
												var Atcn2 = "Basha S";
												var ActnKey2 = "BS2931";
											} else if (ApprovSAM[0].Approver2Id === "DC30338") {
												var Atcn2 = "Denis C";
												var ActnKey2 = "DC30338";
											} else if (ApprovSAM[0].Approver2Id === "SB3817") {
												var Atcn2 = "Suman B";
												var ActnKey2 = "SB3817";
											}*/

										var SamData = {
											data: [{
													Reviewer: "PR Creator/Manager",
													editable: false,
													Status: [{

															stats: ApprovManager[1].Status,
															statskey: ApprovManager[1].Status
														}, {
															stats: ApprovManager[1].Status,
															statskey: ApprovManager[1].Status
														}

													],
													Remarks: ApprovManager[1].Remarks,
													Action2Visible: false,
													Action: [

														{
															Atcn: "Approve",
															ActnKey: ApprovSAM[0].Action
														}, {
															Atcn: "Approve",
															ActnKey: ApprovSAM[0].Action
														}

													]

												}, {
													Reviewer: "SAM",
													editable: false,
													Status: [{
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}, {
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}, {
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}, {
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}, {
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}

													],
													Remarks: ApprovSAM[0].Remarks,
													Action2Visible: true,
													Action2: that.getView().getModel("oSecondLevUserslist").getData(),
													ActnKey2: ApprovSAM[0].Approver2Id,

													Action: [{

															Atcn: "Forward",
															ActnKey: ApprovManager[0].Action
														}, {
															Atcn: "Forward",
															ActnKey: ApprovManager[0].Action
														}

													]

												},

												{
													Reviewer: "Buyer",
													editable: true,
													Status: [{
															stats: "--Please Select--"

														}, {
															stats: "Quote attached",
															statskey: "Quoteattached"
														}, {
															stats: "Requirement Change",
															statskey: "Requirementchange"
														}

													],
													Remarks: "",
													Action2Visible: false,
													Action: [{
															Atcn: "--Please Select--"

														},

														{
															Atcn: "Approve",
															ActnKey: "A"
														}, {
															Atcn: "Reject",
															ActnKey: "R"
														}

													]

												}

											]

										};

										var GhdModel = new sap.ui.model.json.JSONModel();
										GhdModel.setData(SamData);
										that.getView().byId("oshmTable").setModel(GhdModel);
										that.getView().byId("idSave").setEnabled(true);
										that.getView().byId("oAdditmbtn").setEnabled(true);
										that.getView().byId("edit").setEnabled(true);
										that.getView().byId("idcopy").setEnabled(true);
										that.getView().byId("idedit").setEnabled(true);
										//that.getView().byId("oidAttach").setEnabled(true);
										that.getView().byId("InputValueAgrmt").setEnabled(false);
										that.getView().byId("InputValuePlnt").setEnabled(false);
										that.getView().byId("InputValueRequr").setEnabled(false);
										that.getView().byId("InputValueBDept").setEnabled(false);
										that.getView().byId("InputValueBU1").setEnabled(false);
										that.getView().byId("idPrType").setEnabled(false);
										that.getView().byId("idPGrp").setEnabled(false);
										that.getView().byId("idReqType").setEnabled(false);
										that.getView().byId("idInputFileNumber").setEnabled(true);

										//that.getView().byId("oFIleuploadrid").setEnabled(true);
										that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
										that.getView().byId("oUndbChecbx").setEnabled(false);
										that.getView().byId("oTxtvalue").setEnabled(true);
										that.getView().byId("idReject").setEnabled(true);

									} else {

										ApprovManager.sort(function (a, b) {
											return a.CurrentStat - b.CurrentStat;

										})
										if (ApprovManager[0].Action == "A") {
											var ApprovManagerActionKey = "A";
											var ApprovManagerAction = "Approve";
										} else if (ApprovManager[0].Action == "R") {
											var ApprovManagerActionKey = "R";
											var ApprovManagerAction = "Reject";
										}
										var ApprovSAM = ghdData.filter(function (x) {
											return x.PendingWith == "BUY";
										});

										if (ApprovSAM[0].Action == "A") {
											var ApprovSAMManagerActionKey = "A";
											var ApprovSAMManagerAction = "Approve";
										} else if (ApprovSAM[0].Action == "R") {
											var ApprovSAMManagerActionKey = "R";
											var ApprovSAMManagerAction = "Reject";
										}

										var SamData = {
											data: [{
													Reviewer: "PR Creator/Manager",
													editable: false,
													Status: [{

															stats: ApprovManager[0].Status,
															statskey: ApprovManager[0].Status
														}, {
															stats: ApprovManager[0].Status,
															statskey: ApprovManager[0].Status
														}

													],
													Remarks: ApprovManager[0].Remarks,
													Action2Visible: false,
													Action: [

														{
															Atcn: ApprovManagerAction,
															ActnKey: ApprovManagerActionKey
														}, {
															Atcn: ApprovManagerAction,
															ActnKey: ApprovManagerActionKey
														}

													]

												}, {
													Reviewer: "SAM",
													editable: false,
													Status: [{
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}, {
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}, {
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}, {
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}, {
															stats: ApprovSAM[0].Status,
															statskey: ApprovSAM[0].Status
														}

													],
													Remarks: ApprovSAM[0].Remarks,
													Action2Visible: false,
													Action: [{
															Atcn: ApprovSAMManagerAction,
															ActnKey: ApprovSAMManagerActionKey
														}, {
															Atcn: ApprovSAMManagerAction,
															ActnKey: ApprovSAMManagerActionKey
														}

													]

												},

												{
													Reviewer: "Buyer",
													editable: true,
													Status: [{
															stats: "--Please Select--"

														}, {
															stats: "Quote attached",
															statskey: "Quoteattached"
														}, {
															stats: "Requirement Change",
															statskey: "Requirementchange"
														}

													],
													Remarks: "",
													Action2Visible: false,
													Action: [{
															Atcn: "--Please Select--"

														},

														{
															Atcn: "Approve",
															ActnKey: "A"
														}, {
															Atcn: "Reject",
															ActnKey: "R"
														}

													]

												}

											]

										};
										var GhdModel = new sap.ui.model.json.JSONModel();
										GhdModel.setData(SamData);
										that.getView().byId("oshmTable").setModel(GhdModel);
										that.getView().byId("idSave").setEnabled(true);
										that.getView().byId("oAdditmbtn").setEnabled(true);
										that.getView().byId("edit").setEnabled(true);
										that.getView().byId("idcopy").setEnabled(true);
										that.getView().byId("idedit").setEnabled(true);
										//that.getView().byId("oidAttach").setEnabled(true);
										that.getView().byId("InputValueAgrmt").setEnabled(false);
										that.getView().byId("InputValuePlnt").setEnabled(false);
										that.getView().byId("InputValueRequr").setEnabled(false);
										that.getView().byId("InputValueBDept").setEnabled(false);
										that.getView().byId("InputValueBU1").setEnabled(false);
										that.getView().byId("idPrType").setEnabled(false);
										that.getView().byId("idPGrp").setEnabled(false);
										that.getView().byId("idReqType").setEnabled(false);
										that.getView().byId("idInputFileNumber").setEnabled(true);

										//that.getView().byId("oFIleuploadrid").setEnabled(true);
										that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
										that.getView().byId("oUndbChecbx").setEnabled(false);
										that.getView().byId("oTxtvalue").setEnabled(true);
										that.getView().byId("idReject").setEnabled(true);

									}

								} else {
									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(false);
									that.getView().byId("edit").setEnabled(false);
									that.getView().byId("idcopy").setEnabled(false);
									that.getView().byId("idedit").setEnabled(false);
									//that.getView().byId("oidAttach").setEnabled(false);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(false);
									//that.getView().byId("InputValuePR").setEnabled(false);
									//	that.getView().byId("oFIleuploadrid").setEnabled(false);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);
									var ApprovManager = ghdData.filter(function (x) {
										//	return x.PendingWith == "SAM" || x.PendingWith == "HAM";

										return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
									});

									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});

									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}
									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											}, {
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													},

													{
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);
								}

								/*	}, function (error) {

									});*/

							} else {
								that.getView().byId("ItemTable1").setMode("None");

								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);
								//that.getView().byId("InputValuePR").setEnabled(false);
								//	that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								var ApprovManager = ghdData.filter(function (x) {
									//	return x.PendingWith == "SAM" || x.PendingWith == "HAM";
									return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
								});
								ApprovManager.sort(function (a, b) {
									return a.CurrentStat - b.CurrentStat;

								});
								if (ApprovManager[0].Action == "A") {
									var ApprovManagerActionKey = "A";
									var ApprovManagerAction = "Approve";
								} else if (ApprovManager[0].Action == "R") {
									var ApprovManagerActionKey = "R";
									var ApprovManagerAction = "Reject";
								}
								var ApprovSAM = ghdData.filter(function (x) {
									return x.PendingWith == "BUY";
								});

								if (ApprovSAM[0].Action == "A") {
									var ApprovSAMManagerActionKey = "A";
									var ApprovSAMManagerAction = "Approve";
								} else if (ApprovSAM[0].Action == "R") {
									var ApprovSAMManagerActionKey = "R";
									var ApprovSAMManagerAction = "Reject";
								}

								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [{

													stats: ApprovManager[0].Status,
													statskey: ApprovManager[0].Status
												}, {
													stats: ApprovManager[0].Status,
													statskey: ApprovManager[0].Status
												}

											],
											Remarks: ApprovManager[0].Remarks,
											Action: [

												{
													Atcn: ApprovManagerAction,
													ActnKey: ApprovManagerActionKey
												}, {
													Atcn: ApprovManagerAction,
													ActnKey: ApprovManagerActionKey
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}, {
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}, {
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}, {
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}, {
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}

											],
											Remarks: ApprovSAM[0].Remarks,
											Action: [{
													Atcn: ApprovSAMManagerAction,
													ActnKey: ApprovSAMManagerActionKey
												}, {
													Atcn: ApprovSAMManagerAction,
													ActnKey: ApprovSAMManagerActionKey
												}

											]

										}, {
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};

								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}
						} else {

							if (that.oFilteredBuyer.length == "0") {
								var ApprovManager = ghdData.filter(function (x) {
									//	return x.PendingWith == "SAM" || x.PendingWith == "HAM";
									return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
								});
								if (ApprovManager.length > 1) {
									var len = 1;
								} else {
									var len = 0;
								}

								if (ApprovManager[len].Action == "F") {
									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									});
									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									} else if (ApprovManager[0].Action == "F") {
										var ApprovManagerActionKey = "F";
										var ApprovManagerAction = "Forward";
										ApprovManager[2].Status = ApprovManager[0].ReviewerStatus;
										ApprovManager[2].Remarks = ApprovManager[0].ReviewerRem;
										ApprovManager[2].Approver2Id = ApprovManager[0].Approver2Id;

									}
									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									} else if (ApprovSAM[0].Action == "F") {
										var ApprovSAMManagerActionKey = "F";
										var ApprovSAMManagerAction = "Forward";
										ApprovSAM[0].Status = ApprovManager[0].ReviewerStatus;
										ApprovSAM[0].Remarks = ApprovManager[0].ReviewerRem;
										ApprovSAM[0].Approver2Id = ApprovManager[0].Approver2Id;

									}

									/*if (ApprovSAM[0].Approver2Id === "VA3833") {
										var Atcn2 = "Vijay A";
										var ActnKey2 = "VA3833";
									} else if (ApprovSAM[0].Approver2Id === "SC0430") {
										var Atcn2 = "Srinivas Ch";
										var ActnKey2 = "SC0430";
									} else if (ApprovSAM[0].Approver2Id === "BS2931") {
										var Atcn2 = "Basha S";
										var ActnKey2 = "BS2931";
									} else if (ApprovSAM[0].Approver2Id === "DC30338") {
										var Atcn2 = "Denis C";
										var ActnKey2 = "DC30338";
									} else if (ApprovSAM[0].Approver2Id === "SB3817") {
										var Atcn2 = "Suman B";
										var ActnKey2 = "SB3817";
									}*/

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}, {
														stats: ApprovManager[1].Status,
														statskey: ApprovManager[1].Status
													}

												],
												Remarks: ApprovManager[1].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: "Approve",
														ActnKey: ApprovSAM[0].Action
													}, {
														Atcn: "Approve",
														ActnKey: ApprovSAM[0].Action
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: true,
												Action2: that.getView().getModel("oSecondLevUserslist").getData(),
												ActnKey2: ApprovSAM[0].Approver2Id,

												Action: [{

														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}, {
														Atcn: "Forward",
														ActnKey: ApprovManager[0].Action
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};

									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);
									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(true);
									that.getView().byId("edit").setEnabled(true);
									that.getView().byId("idcopy").setEnabled(true);
									that.getView().byId("idedit").setEnabled(true);
									//that.getView().byId("oidAttach").setEnabled(true);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(true);

									//that.getView().byId("oFIleuploadrid").setEnabled(true);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);

								} else {

									ApprovManager.sort(function (a, b) {
										return a.CurrentStat - b.CurrentStat;

									})
									if (ApprovManager[0].Action == "A") {
										var ApprovManagerActionKey = "A";
										var ApprovManagerAction = "Approve";
									} else if (ApprovManager[0].Action == "R") {
										var ApprovManagerActionKey = "R";
										var ApprovManagerAction = "Reject";
									}
									var ApprovSAM = ghdData.filter(function (x) {
										return x.PendingWith == "BUY";
									});

									if (ApprovSAM[0].Action == "A") {
										var ApprovSAMManagerActionKey = "A";
										var ApprovSAMManagerAction = "Approve";
									} else if (ApprovSAM[0].Action == "R") {
										var ApprovSAMManagerActionKey = "R";
										var ApprovSAMManagerAction = "Reject";
									}

									var SamData = {
										data: [{
												Reviewer: "PR Creator/Manager",
												editable: false,
												Status: [{

														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}, {
														stats: ApprovManager[0].Status,
														statskey: ApprovManager[0].Status
													}

												],
												Remarks: ApprovManager[0].Remarks,
												Action2Visible: false,
												Action: [

													{
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}, {
														Atcn: ApprovManagerAction,
														ActnKey: ApprovManagerActionKey
													}

												]

											}, {
												Reviewer: "SAM",
												editable: false,
												Status: [{
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}, {
														stats: ApprovSAM[0].Status,
														statskey: ApprovSAM[0].Status
													}

												],
												Remarks: ApprovSAM[0].Remarks,
												Action2Visible: false,
												Action: [{
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}, {
														Atcn: ApprovSAMManagerAction,
														ActnKey: ApprovSAMManagerActionKey
													}

												]

											},

											{
												Reviewer: "Buyer",
												editable: false,
												Status: [{
														stats: "--Please Select--"

													}, {
														stats: "Quote attached",
														statskey: "Quoteattached"
													}, {
														stats: "Requirement Change",
														statskey: "Requirementchange"
													}

												],
												Remarks: "",
												Action2Visible: false,
												Action: [{
														Atcn: "--Please Select--"

													},

													{
														Atcn: "Approve",
														ActnKey: "A"
													}, {
														Atcn: "Reject",
														ActnKey: "R"
													}

												]

											}

										]

									};
									var GhdModel = new sap.ui.model.json.JSONModel();
									GhdModel.setData(SamData);
									that.getView().byId("oshmTable").setModel(GhdModel);
									that.getView().byId("idSave").setEnabled(false);
									that.getView().byId("oAdditmbtn").setEnabled(true);
									that.getView().byId("edit").setEnabled(true);
									that.getView().byId("idcopy").setEnabled(true);
									that.getView().byId("idedit").setEnabled(true);
									//that.getView().byId("oidAttach").setEnabled(true);
									that.getView().byId("InputValueAgrmt").setEnabled(false);
									that.getView().byId("InputValuePlnt").setEnabled(false);
									that.getView().byId("InputValueRequr").setEnabled(false);
									that.getView().byId("InputValueBDept").setEnabled(false);
									that.getView().byId("InputValueBU1").setEnabled(false);
									that.getView().byId("idPrType").setEnabled(false);
									that.getView().byId("idPGrp").setEnabled(false);
									that.getView().byId("idReqType").setEnabled(false);
									that.getView().byId("idInputFileNumber").setEnabled(true);

									//that.getView().byId("oFIleuploadrid").setEnabled(true);
									that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
									that.getView().byId("oUndbChecbx").setEnabled(false);
									that.getView().byId("oTxtvalue").setEnabled(false);
									that.getView().byId("idReject").setEnabled(false);

								}

							} else {

								that.getView().byId("ItemTable1").setMode("None");

								that.getView().byId("idSave").setEnabled(false);
								that.getView().byId("oAdditmbtn").setEnabled(false);
								that.getView().byId("edit").setEnabled(false);
								that.getView().byId("idcopy").setEnabled(false);
								that.getView().byId("idedit").setEnabled(false);
								//that.getView().byId("oidAttach").setEnabled(false);
								that.getView().byId("InputValueAgrmt").setEnabled(false);
								that.getView().byId("InputValuePlnt").setEnabled(false);
								that.getView().byId("InputValueRequr").setEnabled(false);
								that.getView().byId("InputValueBDept").setEnabled(false);
								that.getView().byId("InputValueBU1").setEnabled(false);
								that.getView().byId("idPrType").setEnabled(false);
								that.getView().byId("idPGrp").setEnabled(false);
								that.getView().byId("idReqType").setEnabled(false);
								that.getView().byId("idInputFileNumber").setEnabled(false);
								//that.getView().byId("InputValuePR").setEnabled(false);
								//	that.getView().byId("oFIleuploadrid").setEnabled(false);
								that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
								that.getView().byId("oUndbChecbx").setEnabled(false);
								that.getView().byId("oTxtvalue").setEnabled(false);
								that.getView().byId("idReject").setEnabled(false);
								var ApprovManager = ghdData.filter(function (x) {
									//	return x.PendingWith == "SAM" || x.PendingWith == "HAM";
									return x.PendingWith == "SAM" || x.PendingWith == "HAM" || x.PendingWith == "BUY";
								});
								ApprovManager.sort(function (a, b) {
									return a.CurrentStat - b.CurrentStat;

								});
								if (ApprovManager[0].Action == "A") {
									var ApprovManagerActionKey = "A";
									var ApprovManagerAction = "Approve";
								} else if (ApprovManager[0].Action == "R") {
									var ApprovManagerActionKey = "R";
									var ApprovManagerAction = "Reject";
								}
								var ApprovSAM = ghdData.filter(function (x) {
									return x.PendingWith == "BUY";
								});

								if (ApprovSAM[0].Action == "A") {
									var ApprovSAMManagerActionKey = "A";
									var ApprovSAMManagerAction = "Approve";
								} else if (ApprovSAM[0].Action == "R") {
									var ApprovSAMManagerActionKey = "R";
									var ApprovSAMManagerAction = "Reject";
								}

								var SamData = {
									data: [{
											Reviewer: "PR Creator/Manager",
											editable: false,
											Status: [{

													stats: ApprovManager[0].Status,
													statskey: ApprovManager[0].Status
												}, {
													stats: ApprovManager[0].Status,
													statskey: ApprovManager[0].Status
												}

											],
											Remarks: ApprovManager[0].Remarks,
											Action: [

												{
													Atcn: ApprovManagerAction,
													ActnKey: ApprovManagerActionKey
												}, {
													Atcn: ApprovManagerAction,
													ActnKey: ApprovManagerActionKey
												}

											]

										}, {
											Reviewer: "SAM",
											editable: false,
											Status: [{
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}, {
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}, {
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}, {
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}, {
													stats: ApprovSAM[0].Status,
													statskey: ApprovSAM[0].Status
												}

											],
											Remarks: ApprovSAM[0].Remarks,
											Action: [{
													Atcn: ApprovSAMManagerAction,
													ActnKey: ApprovSAMManagerActionKey
												}, {
													Atcn: ApprovSAMManagerAction,
													ActnKey: ApprovSAMManagerActionKey
												}

											]

										}, {
											Reviewer: "Buyer",
											editable: false,
											Status: [{
													stats: "--Please Select--"

												},

												{
													stats: "Quote attached",
													statskey: "Quoteattached"
												}, {
													stats: "Requirement Change",
													statskey: "Requirementchange"
												}

											],
											Remarks: "",
											Action2Visible: false,
											Action: [{
													Atcn: "--Please Select--"

												},

												{
													Atcn: "Approve",
													ActnKey: "A"
												}, {
													Atcn: "Reject",
													ActnKey: "R"
												}

											]

										}

									]

								};

								var GhdModel = new sap.ui.model.json.JSONModel();
								GhdModel.setData(SamData);
								that.getView().byId("oshmTable").setModel(GhdModel);

							}

						}
					}
				} else {
					if (that.oLoggeduser == that.oPrCreatedby) {
						that.getView().byId("ItemTable1").setMode("MultiSelect");

						that.getView().byId("idSave").setEnabled(true);
						that.getView().byId("oAdditmbtn").setEnabled(true);
						that.getView().byId("edit").setEnabled(true);
						that.getView().byId("idcopy").setEnabled(true);
						that.getView().byId("idedit").setEnabled(true);
						//that.getView().byId("oidAttach").setEnabled(true);
						that.getView().byId("InputValueAgrmt").setEnabled(true);
						that.getView().byId("InputValuePlnt").setEnabled(true);
						that.getView().byId("InputValueRequr").setEnabled(true);
						that.getView().byId("InputValueBDept").setEnabled(true);
						that.getView().byId("InputValueBU1").setEnabled(true);
						that.getView().byId("idPrType").setEnabled(true);
						that.getView().byId("idPGrp").setEnabled(true);
						that.getView().byId("idReqType").setEnabled(true);
						that.getView().byId("idInputFileNumber").setEnabled(true);
						that.getView().byId("oFIleuploadrid").setUploadEnabled(true);
						//	that.getView().byId("oFIleuploadrid").setEnabled(true);
						that.getView().byId("oUndbChecbx").setEnabled(true);
						that.getView().byId("oTxtvalue").setEnabled(true);
						that.getView().byId("idReject").setEnabled(true);
						//	that.getView().byId("ItemTable1").setMode("MultiSelect");

						var SamData = {
							data: [{
									Reviewer: "PR Creator/Manager",
									editable: true,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Forward",
											statskey: "forward"
										}, {
											stats: "No requirement",
											statskey: "Norequirement"
										}

									],
									Remarks: "",
									Action2Visible: false,
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								}, {
									Reviewer: "SAM",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Delivered from Inventory",
											statskey: "Inventory"
										}, {
											stats: "Back to back buy",
											statskey: "Backtobuy"
										}, {
											stats: "Allocated",
											statskey: "Allocated"
										}, {
											stats: "Non Standard",
											statskey: "Non Standard"
										}, {
											stats: "Quote Attached",
											statskey: "Quuote Attached"
										}

									],
									Remarks: "",
									Action2Visible: false,
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								},

								{
									Reviewer: "Buyer",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Quote attached",
											statskey: "Quoteattached"
										}, {
											stats: "Requirement Change",
											statskey: "Requirementchange"
										}

									],
									Remarks: "",
									Action2Visible: false,
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								}

							]

						};
						var GhdModel = new sap.ui.model.json.JSONModel();
						GhdModel.setData(SamData);
						that.getView().byId("oshmTable").setModel(GhdModel);

					} else {
						that.getView().byId("ItemTable1").setMode("None");
						var SamData = {
							data: [{
									Reviewer: "PR Creator/Manager",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Forward",
											statskey: "forward"
										}, {
											stats: "No requirement",
											statskey: "Norequirement"
										}

									],
									Remarks: "",
									Action2Visible: false,
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								}, {
									Reviewer: "SAM",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Delivered from Inventory",
											statskey: "Inventory"
										}, {
											stats: "Back to back buy",
											statskey: "Backtobuy"
										}, {
											stats: "Allocated",
											statskey: "Allocated"
										}, {
											stats: "Non Standard",
											statskey: "Non Standard"
										}, {
											stats: "Quote Attached",
											statskey: "Quuote Attached"
										}

									],
									Remarks: "",
									Action2Visible: false,
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								},

								{
									Reviewer: "Buyer",
									editable: false,
									Status: [{
											stats: "--Please Select--"

										},

										{
											stats: "Quote attached",
											statskey: "Quoteattached"
										}, {
											stats: "Requirement Change",
											statskey: "Requirementchange"
										}

									],
									Remarks: "",
									Action2Visible: false,
									Action: [{
											Atcn: "--Please Select--"

										},

										{
											Atcn: "Approve",
											ActnKey: "A"
										}, {
											Atcn: "Reject",
											ActnKey: "R"
										}

									]

								}

							]

						};
						var GhdModel = new sap.ui.model.json.JSONModel();
						GhdModel.setData(SamData);
						that.getView().byId("oshmTable").setModel(GhdModel);

						that.getView().byId("idSave").setEnabled(false);
						that.getView().byId("oAdditmbtn").setEnabled(false);
						that.getView().byId("edit").setEnabled(false);
						that.getView().byId("idcopy").setEnabled(false);
						that.getView().byId("idedit").setEnabled(false);
						//that.getView().byId("oidAttach").setEnabled(false);
						that.getView().byId("InputValueAgrmt").setEnabled(false);
						that.getView().byId("InputValuePlnt").setEnabled(false);
						that.getView().byId("InputValueRequr").setEnabled(false);
						that.getView().byId("InputValueBDept").setEnabled(false);
						that.getView().byId("InputValueBU1").setEnabled(false);
						that.getView().byId("idPrType").setEnabled(false);
						that.getView().byId("idPGrp").setEnabled(false);
						that.getView().byId("idReqType").setEnabled(false);
						that.getView().byId("idInputFileNumber").setEnabled(false);
						//that.getView().byId("InputValuePR").setEnabled(false);
						//	that.getView().byId("oFIleuploadrid").setEnabled(false);
						that.getView().byId("oFIleuploadrid").setUploadEnabled(false);
						that.getView().byId("oUndbChecbx").setEnabled(false);
						that.getView().byId("oTxtvalue").setEnabled(false);
						that.getView().byId("idReject").setEnabled(false);
						that.getView().byId("ItemTable1").setMode("None");

					}

				}

				//		var RequestCategory = that.getView().byId("idPrType").getSelectedItem();
				var RequestCategory = that.oEditRequestCategoryDropdown;
				if (RequestCategory) {
					//	RequestCategory = RequestCategory.getText();
					if (RequestCategory == "HARDWARE") {
						that.getView().byId("oshmTable").getModel().getData().data[1].Reviewer = "HAM";
					} else if (RequestCategory == "SOFTWARE") {
						that.getView().byId("oshmTable").getModel().getData().data[1].Reviewer = "SAM";
					} else {
						that.getView().byId("oshmTable").getModel().getData().data.splice(1, 1);
					}
					that.getView().byId("oshmTable").getModel().refresh(true);
				}

			}

			/* switch (this.PendingWith) {
			case "PM":

			var SamData = {
			data: [{
			Reviewer: "PR Creator/Manager",
			editable: true,
			Status: [

			{
			stats: "Forward",
			statskey: "forward"
			}, {
			stats: "No requirement",
			statskey: "Norequirement"
			}

			],
			Remarks: "",
			Action: [

			{
			Atcn: "Approve",
			ActnKey: "A"
			}, {
			Atcn: "Reject",
			ActnKey: "R"
			}

			]

			}, {
			Reviewer: "SAM",
			editable: false,
			Status: [

			{
			stats: "Delivered from Inventory",
			statskey: "Inventory"
			}, {
			stats: "Back to back buy",
			statskey: "Backtobuy"
			}, {
			stats: "Allocated",
			statskey: "Allocated"
			}, {
			stats: "Non Standard",
			statskey: "Non Standard"
			}, {
			stats: "Quote Attached",
			statskey: "Quuote Attached"
			}

			],
			Remarks: "",
			Action: [

			{
			Atcn: "Approve",
			ActnKey: "A"
			}, {
			Atcn: "Reject",
			ActnKey: "R"
			}

			]

			},

			{
			Reviewer: "Buyer",
			editable: false,
			Status: [

			{
			stats: "Quote attached",
			statskey: "Quoteattached"
			}, {
			stats: "Requirement Change",
			statskey: "Requirementchange"
			}

			],
			Remarks: "",
			Action: [

			{
			Atcn: "Approve",
			ActnKey: "A"
			}, {
			Atcn: "Reject",
			ActnKey: "R"
			}

			]

			}

			]

			};
			var GhdModel = new sap.ui.model.json.JSONModel();
			GhdModel.setData(SamData);
			this.getView().byId("oshmTable").setModel(GhdModel);

			break;

			case "SAM":
			var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

			that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

			var path = "/YMM_PR_SAMSet";
			that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

			var oSamsetmodelref = oData.results;

			   var oSamsetmodel = new sap.ui.model.json.JSONModel(oSamsetmodelref);

			}, function (error) {

			});

			var SamData = {
			data: [{
			Reviewer: "PR Creator/Manager",
			editable: false,
			Status: [

			{
			stats: "Forward",
			statskey: "forward"
			}, {
			stats: "No requirement",
			statskey: "Norequirement"
			}

			],
			Remarks: "",
			Action: [

			{
			Atcn: "Approve",
			ActnKey: "A"
			}, {
			Atcn: "Reject",
			ActnKey: "R"
			}

			]

			}, {
			Reviewer: "SAM",
			editable: true,
			Status: [

			{
			stats: "Delivered from Inventory",
			statskey: "Inventory"
			}, {
			stats: "Back to back buy",
			statskey: "Backtobuy"
			}, {
			stats: "Allocated",
			statskey: "Allocated"
			}, {
			stats: "Non Standard",
			statskey: "Non Standard"
			}, {
			stats: "Quote Attached",
			statskey: "Quuote Attached"
			}

			],
			Remarks: "",
			Action: [

			{
			Atcn: "Approve",
			ActnKey: "A"
			}, {
			Atcn: "Reject",
			ActnKey: "R"
			}

			]

			},

			{
			Reviewer: "Buyer",
			editable: false,
			Status: [

			{
			stats: "Quote attached",
			statskey: "Quoteattached"
			}, {
			stats: "Requirement Change",
			statskey: "Requirementchange"
			}

			],
			Remarks: "",
			Action: [

			{
			Atcn: "Approve",
			ActnKey: "A"
			}, {
			Atcn: "Reject",
			ActnKey: "R"
			}

			]

			}

			]

			};
			var GhdModel = new sap.ui.model.json.JSONModel();
			GhdModel.setData(SamData);
			this.getView().byId("oshmTable").setModel(GhdModel);

			break;

			case "HAM":
			var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

			that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

			var path = "/YMM_PR_HAMSet";
			that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

			var oHamsetmodelref = oData.results;
			var oHamsetmodel = new sap.ui.model.json.JSONModel(oHamsetmodelref);

			}, function (error) {

			});

			var SamData = {
			data: [{
			Reviewer: "PR Creator/Manager",
			editable: false,
			Status: [

			{
			stats: "Forward",
			statskey: "forward"
			}, {
			stats: "No requirement",
			statskey: "Norequirement"
			}

			],
			Remarks: "",
			Action: [

			{
			Atcn: "Approve",
			ActnKey: "A"
			}, {
			Atcn: "Reject",
			ActnKey: "R"
			}

			]

			}, {
			Reviewer: "HAM",
			editable: true,
			Status: [

			{
			stats: "Delivered from Inventory",
			statskey: "Inventory"
			}, {
			stats: "Back to back buy",
			statskey: "Backtobuy"
			}, {
			stats: "Allocated",
			statskey: "Allocated"
			}, {
			stats: "Non Standard",
			statskey: "Non Standard"
			}, {
			stats: "Quote Attached",
			statskey: "Quuote Attached"
			}

			],
			Remarks: "",
			Action: [

			{
			Atcn: "Approve",
			ActnKey: "A"
			}, {
			Atcn: "Reject",
			ActnKey: "R"
			}

			]

			},

			{
			Reviewer: "Buyer",
			editable: false,
			Status: [

			{
			stats: "Quote attached",
			statskey: "Quoteattached"
			}, {
			stats: "Requirement Change",
			statskey: "Requirementchange"
			}

			],
			Remarks: "",
			Action: [

			{
			Atcn: "Approve",
			ActnKey: "A"
			}, {
			Atcn: "Reject",
			ActnKey: "R"
			}

			]

			}

			]

			};
			var GhdModel = new sap.ui.model.json.JSONModel();
			GhdModel.setData(SamData);
			this.getView().byId("oshmTable").setModel(GhdModel);

			break;

			case "BUY":

			var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

			that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

			var path = "/YMM_PR_BUYER_IDSet";
			that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

			var oBuyrsetmodelref = oData.results;
			var oBuyrsetmodel = new sap.ui.model.json.JSONModel(oBuyrsetmodelref);

			}, function (error) {

			});

			var SamData = {
			data: [{
			Reviewer: "PR Creator/Manager",
			editable: false,
			Status: [

			{
			stats: "Forward",
			statskey: "forward"
			}, {
			stats: "No requirement",
			statskey: "Norequirement"
			}

			],
			Remarks: "",
			Action: [

			{
			Atcn: "Approve",
			ActnKey: "A"
			}, {
			Atcn: "Reject",
			ActnKey: "R"
			}

			]

			}, {
			Reviewer: "SAM",
			editable: false,
			Status: [

			{
			stats: "Delivered from Inventory",
			statskey: "Inventory"
			}, {
			stats: "Back to back buy",
			statskey: "Backtobuy"
			}, {
			stats: "Allocated",
			statskey: "Allocated"
			}, {
			stats: "Non Standard",
			statskey: "Non Standard"
			}, {
			stats: "Quote Attached",
			statskey: "Quuote Attached"
			}

			],
			Remarks: "",
			Action: [

			{
			Atcn: "Approve",
			ActnKey: "A"
			}, {
			Atcn: "Reject",
			ActnKey: "R"
			}

			]

			},

			{
			Reviewer: "Buyer",
			editable: true,
			Status: [

			{
			stats: "Quote attached",
			statskey: "Quoteattached"
			}, {
			stats: "Requirement Change",
			statskey: "Requirementchange"
			}

			],
			Remarks: "",
			Action: [

			{
			Atcn: "Approve",
			ActnKey: "A"
			}, {
			Atcn: "Reject",
			ActnKey: "R"
			}

			]

			}

			]

			};
			var GhdModel = new sap.ui.model.json.JSONModel();
			GhdModel.setData(SamData);
			this.getView().byId("oshmTable").setModel(GhdModel);

			break;

			}*/

			// var oPurReq = oEvent.oSource.getSelectedItem().mProperties.text;

			if (this.oSelectedMatcode) {
				this.productInputBuDp = sap.ui.getCore().byId("InputValueMatDesc");
				this.productInputBuDp.setValue(this.oSelectedMatcode);

			}
			oEvent.getSource().getBinding("items").filter([]);
			//	sap.ui.core.BusyIndicator.hide();
			//  that.listbusydialog.close();
			//	this.getAttachMents(oPrnumber);

			this.onShmTableUpdate();
			that.oBusyIn.close();
		},
		getAttachMents: function (oPrnumber) {
			var that = this;
			var model = new sap.ui.model.json.JSONModel();
			model.setData({
				"results": []
			});
			that.getView().byId("oFIleuploadrid").setModel(model);

			var readRequestURL3 = "/PR_HeaderSet('" + oPrnumber + "')?$expand=ymm_get_att_association_nav";
			that.oDataModel.read(readRequestURL3, null, null, false, function (oData, oResponse) {

					that.oPRattchFoldrid = oData.ymm_get_att_association_nav.results;

				},
				function (error) {
					that.oPRattchFoldrid = [];
				});
			var AttachMent_Data = [];
			for (var k = 0; k < that.oPRattchFoldrid.length; k++) {
				var readRequestURL4 = "ztgetattachmentSet('" + that.oPRattchFoldrid[k].InstidB + "')/$value";
				that.oDataModel.read(readRequestURL4, null, null, false, function (oData, oResponse) {
						var oItem = {};

						oItem.documentId = jQuery.now().toString();
						oItem.Deliverable = "";
						oItem.File = oResponse.headers["content-disposition"].split("filename=")[1];
						oItem.fileName = oResponse.headers["content-disposition"].split("filename=")[1];
						oItem.Mimetype = oResponse.headers["Content-Type"];
						oItem.mimeType = oResponse.headers["Content-Type"];
						oItem.enableEdit = false;
						oItem.body = oResponse.body;
						oItem.SelectedFile = oResponse.headers;
						oItem.requestUri = oResponse.requestUri;
						oItem.visibleEdit = false;
						oItem.visibleDelete = true;
						AttachMent_Data.push(oItem);
					},
					function (error) {

					});
			}
			var model = new sap.ui.model.json.JSONModel();
			model.setData({
				"results": AttachMent_Data
			});
			that.getView().byId("oFIleuploadrid").setModel(model);
			for (var i = 0; i < that.getView().byId("oFIleuploadrid").getItems().length; i++) {
				that.getView().byId("oFIleuploadrid").getItems()[i].attachPress(that.AttachMentDownload, that);
			}
		},

		//PR List  Fragment Confirm Press event End
		//PR List  Fragment Search Press event Start
		handlePrdesConfirmSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oPrListFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("Banfn", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("Txz01", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},

		onChangePrClick: function (oEvent) {

		},

		onReject: function () {
			this.getView().byId("InputValuePR").setValue("");
			this.getView().byId("idReqType").setSelectedKey(0);
			this.getView().byId("idPGrp").setSelectedKey("");
			this.getView().byId("idPrType").setSelectedKey("");
			this.getView().byId("InputValueBU1").setValue("");
			this.getView().byId("idBuApptext").setText("");
			this.getView().byId("InputValueBDept").setValue("");
			this.getView().byId("InputValueRequr").setValue("");
			this.getView().byId("idManagertext").setText("");
			this.getView().byId("InputValuePlnt").setValue("");
			this.getView().byId("idPuridGrop").setValue("");
			this.getView().byId("oCreatedbyId").setText("");

			this.getView().byId("InputValueAgrmt").setValue("");
			this.getView().byId("oTxtvalue").setValue("");
			/*this.getView().byId("oUndbChecbx").setSelected(false);*/

			var ootabl = this.getView().byId("ItemTable1");
			var xxtab = ootabl.getModel().getData();
			while (xxtab.length > 0) {
				{
					xxtab.pop();
				}
			}

			ootabl.getModel().updateBindings();
			this.TotalValCal();
			var oGhdtableDummyModel = new sap.ui.model.json.JSONModel();
			var oGhdbummyid = this.getView().byId("oshmTable").setModel(oGhdtableDummyModel);
			var oAttachDumModel = new sap.ui.model.json.JSONModel({
				"results": []
			});
			var oAttachDummyid = this.getView().byId("oFIleuploadrid").setModel(oAttachDumModel);
			var oRelsestartDumModel = new sap.ui.model.json.JSONModel();
			var oRelsStratDummyid = this.getView().byId("oRelaseStrtTable").setModel(oRelsestartDumModel);
			var model = new sap.ui.model.json.JSONModel([]);
			oMessagePopover.setModel(model);
			//	oMessagePopover.toggle(that.getView().byId("ErrorMessages"));
			var viewModel = new sap.ui.model.json.JSONModel();
			viewModel.setData({
				messagesLength: 0 + ''
			});

			this.getView().setModel(viewModel);

		},

		onRouteMatched: function (oEvent) {
			var that = this;
			/* this.oModelunlockCreate.read("/YMM_FIORI_LOGSet", null, null, true, function (oData, oRespone) {
			var Data = oData.results;
			that.oFioriLogmodlref = Data;

			}, function (error) {
			that.oFioriLogmodlref = [];
			});*/

			//var oParameters = oEvent.getParameters().arguments.Dummy;

			that.getOwnerComponent().oObjemodelx;

			that.oObjemodelx = that.getOwnerComponent();

			/* if (oParameters === "Yes") {
			this.getView().byId("oidPurrequsitn").setVisible(true);
			this.getView().byId("InputValuePR").setVisible(true);
			this.getView().byId("oTilteId").setTitle("Edit Purchase Requisition");
			this.getView().byId("idmdunr").setVisible(true);
			this.getView().byId("iddumgetext").setVisible(true);

			this.getView().byId("idReqType").setEditable(false);
			this.getView().byId("InputValuePlnt").setEditable(false);
			this.getView().byId("oSamHamGrid").setVisible(true);
			this.getView().byId("oProJustlabel").setVisible(false);
			this.getView().byId("Procrjust").setVisible(false);
			this.getView().byId("oidFlex1").setVisible(false);
			this.getView().byId("oidFlex2").setVisible(false);
			this.getView().byId("oidFlex3").setVisible(false);
			this.getView().byId("oidFlex4").setVisible(false);
			this.getView().byId("oidFlex5").setVisible(false);
			this.getView().byId("oidFlex6").setVisible(false);
			this.getView().byId("oCreateId").setText("Save");

			var url = "/sap/opu/odata/sap/YMM_PR_DETAILS_EBAN_SRV";
			var that = this;
			that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);
			var path = "/YMM_AGEINGSet";
			that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

			var oObjemodel = oData.results;

			var oPRDetailsModelref = new sap.ui.model.json.JSONModel(oObjemodel);
			oPRDetailsModelref.setSizeLimit(100000);

			that.getView().byId("InputValuePR").setModel(oPRDetailsModelref, "oPRDetailsModel");
			});

			} else {

			this.getView().byId("oidPurrequsitn").setVisible(false);
			this.getView().byId("InputValuePR").setVisible(false);
			this.getView().byId("oTilteId").setTitle("Create Purchase Requisition");
			this.getView().byId("idmdunr").setVisible(false);
			this.getView().byId("iddumgetext").setVisible(false);

			this.getView().byId("idReqType").setEditable(true);
			this.getView().byId("InputValuePlnt").setEditable(true);
			this.getView().byId("oSamHamGrid").setVisible(false);
			this.getView().byId("oProJustlabel").setVisible(true);
			this.getView().byId("Procrjust").setVisible(true);
			this.getView().byId("oidFlex1").setVisible(true);
			this.getView().byId("oidFlex2").setVisible(true);
			this.getView().byId("oidFlex3").setVisible(true);
			this.getView().byId("oidFlex4").setVisible(true);
			this.getView().byId("oidFlex5").setVisible(true);
			this.getView().byId("oidFlex6").setVisible(true);
			this.getView().byId("oCreateId").setText("Create");
			}
			*/

		},
		/*	onFileDeleted: function (oEvent) {
				var Index = oEvent.getSource().getBindingContext().getPath().split("/results")[1];
			
				var TableData = this.getView().byId("oFIleuploadrid").getModel().getData();
				TableData.results.splice(Index, 1);
				this.getView().byId("oFIleuploadrid").getModel().setData(TableData);
				this.getView().byId("oFIleuploadrid").getModel().refresh(true);
			},

			onUploadComplete: function (oEvent) {},*/
		onBeforeUploadStarts: function () {
			sap.ui.core.BusyIndicator.show();
		},
		onTableUpdate: function () {},
		onChange: function (oEvent) {
			this.SelectedFile = oEvent.getParameter("files")[0];
			var reader = new FileReader();
			reader.readAsDataURL(oEvent.getParameter("files")[0]);
			var that = this;
			reader.onload = function () {

				that.result = reader.result;

			};
			reader.onerror = function (error) {};

		},

		onUploadComplete: function (oEvent) {
			var oUploadCollection = this.getView().byId("oFIleuploadrid");
			if (!oEvent.getSource().getModel()) {
				var model = new sap.ui.model.json.JSONModel({
					"results": []

				});
				oEvent.getSource().setModel(model);
			} else if (oEvent.getSource().getModel()) {
				if (oEvent.getSource().getModel().getData() == null) {

					var model = new sap.ui.model.json.JSONModel({
						"results": []

					});
					oEvent.getSource().setModel(model);

				}

			}
			/*	if (oEvent.getParameter("files")[0].status == "201") {
					var respose = oEvent.getParameter("files")[0].reponse;
					if (respose === undefined) {
						sap.m.MessageBox.show("Upload Failed", sap.m.MessageBox.Icon.ERROR, "Error");
						return;
					}*/
			var oData = oEvent.getSource().getModel().getData();
			var aItems = jQuery.extend(true, {}, oData).results;
			var oItem = {};
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				"items": ["jpg", "txt", "ppt", "doc", "xls", "pdf", "xlsx", "png", "msg"],
				"selected": ["jpg", "txt", "ppt", "doc", "xls", "pdf", "xlsx", "png", "msg"]
			}), "fileTypes");

			//	var a = this.oScopeAvailable;
			//var oSerialNum = oData.results.length+1;
			var oSerialNum = "";
			var sUploadedFile = oEvent.getParameter("files")[0].fileName;

			//http://cyinsapcgd.corp.cyient.com:8000/sap/opu/odata/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ztgetattachmentSet

			//	var serviceUrl = "sap/opu/odata/sap/ZMYDELIVERABLES_APP_SRV";

			//	https://webidetesting5812206-l577e310e.dispatcher.ae1.hana.ondemand.com/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/PR_HeaderSet('30000554')?$expand=ymm_get_att_association_nav

			//FOL38000000000004EXT45000000000938

			//https://webidetesting5812206-l577e310e.dispatcher.ae1.hana.ondemand.com/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ztgetattachmentSet('FOL38000000000004EXT45000000000938')/$value

			//30000555\&nbsp;

			//	var sUrl = "/FileAttachmentSet(Deliverable='" + oSerialNum + "',File='" + sUploadedFile + "')/$value";
			//	var oUrl = "sap/opu/odata/sap/ZMYDELIVERABLES_REG_SRV/File(Deliverable='" + oSerialNum + "',File='" + sUploadedFile + "')/$value";
			// at the moment parameter fileName is not set in IE9
			var Filetype = sUploadedFile.substring(sUploadedFile.lastIndexOf('.'));
			var FileName = sUploadedFile.substring(0, sUploadedFile.lastIndexOf('.'));
			oItem = {
				"documentId": jQuery.now().toString(),
				"Deliverable": oSerialNum,
				"File": sUploadedFile,
				"fileName": sUploadedFile,
				"Mimetype": this.SelectedFile.type,
				"mimeType": this.SelectedFile.type,
				"enableEdit": false,
				"SelectedFile": this.SelectedFile
					/*	"url": serviceUrl + sUrl,*/
					/*	"sessionKey": a*/

			};
			oItem.visibleEdit = false;
			oItem.visibleDelete = true;
			/*	if(this.SelectedFile.type=="image/png"||this.SelectedFile.type=="image/jpeg"||this.SelectedFile.type=="image/bmp"
			||this.SelectedFile.type=="image/jpg"){
	oItem.thumbnailUrl=this.result;
			}*/
			aItems.unshift(oItem);
			var json2 = new sap.ui.model.json.JSONModel();
			json2.setData({
				"results": aItems

			});
			oUploadCollection.getModel().setData({
				"results": aItems
			});
			oUploadCollection.setModel(json2);

			oUploadCollection.getModel().refresh();
			for (var i = 0; i < oUploadCollection.getItems().length; i++) {
				oUploadCollection.getItems()[i].attachPress(this.AttachMentDownload, this);
			}
			//this.getView().byId("idTagName").setValue("");
			sap.ui.core.BusyIndicator.hide();
			var dispMsg = "";
			/*var respns = JSON.parse(oEvent.mParameters.files[0].headers['sap-message']);
									var msg = respns.message;
									var msgType = respns.severity.toUpperCase();
									if (msgType === "SUCCESS") {
										sap.m.MessageBox.show(msg, {
											title : "Success",
											icon : sap.m.MessageBox.Icon.SUCCESS,
											actions : [sap.m.MessageBox.Action.OK],
											styleClass : "messageBox",
											onClose : function(oEvt) {
												if ( oEvt === "OK") {
													//that.getView().byId("idTagName").setValue("");
													//that.callChargeDetailsAttach();
												}
											}
										});
									} else if (msgType === "ERROR") {

										sap.m.MessageBox.show(msg, {
											title : "Error",
											icon : sap.m.MessageBox.Icon.ERROR,
											actions : [sap.m.MessageBox.Action.OK],
											styleClass : "messageBox"
										});
										//that.onUploadTerminated();
									}
								}
								else{
									var message1 = $(oEvent.mParameters.files[0].responseRaw).find('message').first().text();
									if (message1===""){
										var error = (oEvent.mParameters.responseRaw);
										sap.m.MessageBox.show(error, {
											title : "Error",
											icon : sap.m.MessageBox.Icon.ERROR,
											actions : [sap.m.MessageBox.Action.OK],
											styleClass : "messageBox"
										});

									}
									else{
										sap.m.MessageBox.show(message1, {
											title : "Error",
											icon : sap.m.MessageBox.Icon.ERROR,
											actions : [sap.m.MessageBox.Action.OK],
											styleClass : "messageBox"
										});
										that.onUploadTerminated();
									}*/
			/*	}*/
		},

		/*	onBeforeUploadStarts: function () {
				sap.ui.core.BusyIndicator.show();
			},*/

		onFileDeleted: function (oEvent) {
			var Index = oEvent.getSource().getBindingContext().getPath().split("/results")[1];
			//var CollectionData=
			this.getView().byId("oFIleuploadrid").removeItem(this.getView().byId("oFIleuploadrid").getItems()[Index]);
			var TableData = this.getView().byId("oFIleuploadrid").getModel().getData();
			TableData.results.splice(Index, 1);
			this.getView().byId("oFIleuploadrid").getModel().setData(TableData);
			this.getView().byId("oFIleuploadrid").getModel().refresh(true);
		},
		Attachments: function (PRNumber) {
			try {

				if (PRNumber) {
					//	var Ponumber = "00" + PRNumber; ///need to add 00
					var Ponumber = PRNumber;
					var ab = this.getView().byId("oFIleuploadrid").getModel().getData().results;
					var arra = [];

					/*	arra.push(Filetype);
						arra.push(fileName);*/

					this._bUploading = true;
					///sap/opu/odata/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV/ztgetattachmentSet
					var that = this;
					var a = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

					var f = {

						headers: {

							"X-Requested-With": "XMLHttpRequest",

							"Content-Type": "application/atom+xml",

							"DataServiceVersion": "2.0",

							"X-CSRF-Token": "Fetch"

						},
						requestUri: a,

						method: "GET"

					};
					//	var oHeaders;
					var oDatamodel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV");
					// this.getView().getModel("oDataModel");
					//	this.getView().setBusy(true);
					var that = this;

					oDatamodel._request(f, function (data, oSuccess) {

						var oToken = oSuccess.headers['x-csrf-token'];
						var Countr = 1;
						for (var i = 0; i < ab.length; i++) {

							var Filetype = that.getView().byId("oFIleuploadrid").getModel().getData().results[i].mimeType;
							var fileName = that.getView().byId("oFIleuploadrid").getModel().getData().results[i].fileName;
							var SelectedFile = that.getView().byId("oFIleuploadrid").getModel().getData().results[i].SelectedFile;
							var oHeaders = {
								"X-Requested-With": "XMLHttpRequest",

								"Content-Type": "application/atom+json",

								"DataServiceVersion": "2.0",
								"x-csrf-token": oToken,
								"slug": Ponumber + "/" + fileName,

							};
							var MsgTxt = "";
							var oURL = oDatamodel.sServiceUrl + "/ztgetattachmentSet";
							jQuery.ajax({
								type: 'POST',
								dataType: "json",
								url: oURL,
								async: true,
								headers: oHeaders,

								cache: false,

								contentType: Filetype,

								processData: false,

								data: SelectedFile,

								success: function (data, oResponse) {

									Countr++;
									MsgTxt = "Attachment has been sent";
									var oAttachDumModel = new sap.ui.model.json.JSONModel({
										"results": []
									});
									that.getView().byId("oFIleuploadrid").setModel(oAttachDumModel);
									if (ab.length == Countr) {
										sap.m.MessageBox.success(MsgTxt);

									}
								},
								error: function (data, oResponse) {
									MsgTxt = "Duplicate files";
									Countr++;
									if (ab.length == Countr) {
										sap.m.MessageBox.error(MsgTxt);

									}
								}
							});

						}
					});

				}
			} catch (oException) {
				sap.ui.core.BusyIndicator.hide();
			}

		},
		AttachMentDownload: function (oEvent) {
			var data = oEvent;
			var reader = new FileReader();
			var FileType = oEvent.getSource().getBindingContext().getObject().Mimetype;
			var FileName = oEvent.getSource().getBindingContext().getObject().fileName;
			if (!("body" in oEvent.getSource().getBindingContext().getObject())) {
				reader.readAsDataURL(oEvent.getSource().getBindingContext().getObject().SelectedFile);
				var that = this;
				reader.onload = function () {

					var base64result = reader.result;

					function b64toBlob(b64Data, contentType, sliceSize) {
						contentType = contentType || '';
						sliceSize = sliceSize || 512;

						var byteCharacters = atob(b64Data.split("base64,")[1]);
						var byteArrays = [];

						for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
							var slice = byteCharacters.slice(offset, offset + sliceSize);

							var byteNumbers = new Array(slice.length);
							for (var i = 0; i < slice.length; i++) {
								byteNumbers[i] = slice.charCodeAt(i);
							}

							var byteArray = new Uint8Array(byteNumbers);

							byteArrays.push(byteArray);
						}

						var blob = new Blob(byteArrays, {
							type: contentType
						});
						return blob;
					}
					var blob = b64toBlob(base64result, FileType);
					var blobUrl = URL.createObjectURL(blob);
					var a = document.createElement('A');
					a.href = blobUrl;
					a.download = FileName;
					document.body.appendChild(a);
					a.click();
					a.emphasized = true;
					document.body.removeChild(a);
				};
				reader.onerror = function (error) {};
			} else {
				var sUrl = oEvent.getSource().getBindingContext().getObject().requestUri;
				var encodeUrl = encodeURI(sUrl);
				sap.m.URLHelper.redirect(encodeUrl, true);
			}

		},
		TotalValCal: function () {
			if (!this.getView().byId("ItemTable1").getModel().getData().length) {
				this.getView().byId("oidTotalsum").setText("0.000");
			} else if (this.getView().byId("ItemTable1").getModel().getData().length) {
				var CurrCode = this.getView().byId("ItemTable1").getModel().getData()[0].Currency;
				var AllItems = this.getView().byId("ItemTable1").getModel().getData().filter(function (x) {
					return (x.DeleteIndicator == false);
				});;
				var CurrencyFilterData = this.getView().byId("ItemTable1").getModel().getData().filter(function (x) {
					return (x.Currency == CurrCode && x.DeleteIndicator == false);
				});
				if (CurrencyFilterData.length == AllItems.length) {
					var Total = 0.000;
					for (var i = 0; i < CurrencyFilterData.length; i++) {
						Total += (parseFloat((CurrencyFilterData[i].TotalPrice)).toFixed(3)) * 1;
					}
					Total = parseFloat((Total)).toFixed(3);
					this.getView().byId("oidTotalsum").setText(Total + " " + CurrCode);
					this.getView().byId("oToatlsumLable").setVisible(true);

				} else {
					this.getView().byId("oidTotalsum").setText("");
					this.getView().byId("oToatlsumLable").setVisible(false);
				}
			}
		},

		onSamSelect: function (oEvent) {
			var SelectedKey = oEvent.getSource().getSelectedKey();
			var Path = oEvent.getSource().getBindingContext().getPath();
			if (SelectedKey === "F") {
				oEvent.getSource().getBindingContext().getProperty(Path).Action2Visible = true;
				this.getView().byId("osa").setVisible(true);

			} else {
				oEvent.getSource().getBindingContext().getProperty(Path).Action2Visible = false;
				this.getView().byId("osa").setVisible(false);
			}

		},
		onNavback: function () {
			debugger
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View1", {

			});
			/*var oHistory = History.getInstance();
				var sPreviousHash = oHistory.getPreviousHash();

				if (sPreviousHash !== undefined) {
					window.history.go(-1);
				} else {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					oRouter.navTo("View1", {
						
					});
				}*/

		},

		onForwardUserdetails: function () {
			this.oUserurl = "/sap/opu/odata/sap/YMM_2ND_APPROVER_SRV";
			this.o2ndLevUserlistModel = new sap.ui.model.odata.ODataModel(this.oUserurl, true);
			var that = this;
			var path1 = "/ymm_2nd_approver_detailsSet";
			this.o2ndLevUserlistModel.read(path1, null, null, false, function (oData, oResponse) {
					var oSecondLevApplist = oData.results;
					var oSecondLevUserslist = new sap.ui.model.json.JSONModel(oSecondLevApplist);
					that.getView().setModel(oSecondLevUserslist, "oSecondLevUserslist");
				},
				function (error) {
					that.getView().setModel([], "oSecondLevUserslist");
				}
			);
		}

	});

});