function initModel() {
	var sUrl = "/sap/opu/odata/sap/YMM_2ND_APPROVER_SRV/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}