sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"Sec_Le_ApproverList/YMM_P2P_SecondLevelApproverList/model/models"
], function (UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("Sec_Le_ApproverList.YMM_P2P_SecondLevelApproverList.Component", {

		metadata: {
			manifest: "json",
			async: true
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			var deviceModel = new sap.ui.model.json.JSONModel({
				isPhone: sap.ui.Device.system.phone
			});
			this.setModel(deviceModel, "device");

			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
		//	this.setModel(models.createDeviceModel(), "device");
		}
	});
});