jQuery.sap.require("sap.m.MessageBox");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/m/MessageBox",
	"Sec_Le_ApproverList/YMM_P2P_SecondLevelApproverList/Formatter/Formatter"
], function (Controller, Sorter, Filter, Formatter, MessageBox) {
	"use strict";

	return Controller.extend("Sec_Le_ApproverList.YMM_P2P_SecondLevelApproverList.controller.View1", {
		onInit: function () {

		},
		onSearch: function (oEvt) {;
			var that = this;
			var ootabl1 = that.getView().byId("idApproversTable");
			var xxtab2 = new sap.ui.model.json.JSONModel([]);
			ootabl1.setModel(xxtab2);
			that.getView().byId("ooid").setText("Items(" + "" + xxtab2.oData.length + "" + ")");

			ootabl1.getModel().updateBindings();
			that.getView().byId("oLableid").setText("");
			/*	that.getView().byId("oTextArea").setValue("");*/

			var aFilters = [];
			var sQuery = oEvt.getSource().getValue();
			if (sQuery && sQuery.length > 0) {

				var filter = ([new sap.ui.model.Filter([
					new sap.ui.model.Filter("PRnumber", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("Desc_of_Item", sap.ui.model.FilterOperator.Contains, sQuery)
					/*	new sap.ui.model.Filter("PrApprovedStatus", sap.ui.model.FilterOperator.Contains, sQuery)*/
				], false)]);
				aFilters.push(filter);

			}

			var list = this.getView().byId("Items");
			var binding = list.getBinding("items");
			binding.filter(aFilters, "Application");

		},
		onPressGo1: function (oEvent) {
			debugger

			var that = this;

			this.oSelectedPR = oEvent.getSource().getTitle();
			// var readRequestURL3 = "ymm_fiori_log_appr2_detSet('" + this.oSelectedPR + "')";

			var readRequestURL3 = "/ymm_headerSet('" + this.oSelectedPR + "')?$expand=ymm_2nd_approverSet";
			that.oDataModelAPL.read(readRequestURL3, null, null, false, function (oData, oResponse) {

				var oObjemodelAPL2 = oData.ymm_2nd_approverSet.results;
				that.oRequestype = oData.Bsart;
				var x1 = oObjemodelAPL2[0].Reviewed_by;
				var odate = oObjemodelAPL2[0].Reviewed_Date;

				var oApproverlistModel = new sap.ui.model.json.JSONModel(oObjemodelAPL2);

				that.getView().byId("idApproversTable").setModel(oApproverlistModel);
				that.getView().byId("ooid").setText("Items(" + "" + oObjemodelAPL2.length + "" + ")");
				that.getView().byId("oLableid").setText("PR" + "" + " " + that.oSelectedPR + "" + "");
				that.getView().byId("oRevBy").setText(x1);
				if (odate != null) {
				var oDateFormatA = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var DatevalueA = oDateFormatA.format(new Date(odate));
			//	return DatevalueA;
			} else {
				DatevalueA = "";

			}
			that.getView().byId("oRevDate").setText(DatevalueA);
				

			});

		},
		onPressApprove: function (oEvent) {

			var that = this;
			var oPrnum = that.getView().byId("oLableid").getText();
			if (oPrnum != "") {

				this.SelecteButton = oEvent.getSource().getText();
			
				var _odialog = new sap.m.Dialog({
					id: 'Oidd',
					title: 'Add comments',
					type: 'Message',

					state: 'Information',

					content: new sap.m.TextArea({
						value: '',
						id: 'oidex',
						width: '100%',
						height: '180%',
						maxLength: 100,

						liveChange: function (oEvent) {
							var oTextArea = oEvent.getSource(),
								iValueLength = oTextArea.getValue().length,
								//	iMaxLength = oTextArea.getMaxLength(100),
								iMaxLength = 100,
								sState = iValueLength > iMaxLength ? "Error" : "None";

							oTextArea.setValueState(sState);

						},

						valueLiveUpdate: true,
						showExceededText: true
					}),
					beginButton: new sap.m.Button({
						text: 'Proceed',
						press: function (oEvt) {

							that.oAccept();
							_odialog.destroy(true);
							_odialog = undefined;
							_odialog.close();

						},

					}),
					endButton: new sap.m.Button({
						text: 'Cancel',
						press: function () {
							_odialog.close();
							_odialog.destroy(true);
							_odialog = undefined;

						}
					})
				});
				_odialog.open();
			} else {

				sap.m.MessageBox.warning("Please choose any PR from the list");
			}

		},
		oAccept: function () {

			if (this.SelecteButton == "Reject") {

				var ActnKey = "R";
			} else {
				var ActnKey = "A";

			}

			var Remarks = sap.ui.getCore().byId("oidex").getValue();

			this.oDataModelAPL.setHeaders({
				"Content-Type": "application/json",
				"X-Requested-With": "XMLHttpRequest",
				"DataServiceVersion": "2.0",
				"Accept": "application/json",
				"Method": "POST"
			});
			var batchUrls = [];
			var headeritem = {};

			var ymm_2nd_approverSet = [];
			var oTable = this.getView().byId("idApproversTable").getModel().getData();

			for (var i = 0; i < oTable.length; i++) {

				var oentry = {
					"PRnumber": oTable[i].PRnumber,
					"Item_No": oTable[i].Item_No,
					"Desc_of_Item": oTable[i].Desc_of_Item,
					"Material_grp": oTable[i].Material_grp,
					"Quantity": oTable[i].Quantity,
					"Net_Price": oTable[i].Net_Price,
					"Currency": oTable[i].Currency,
					"Net_value": oTable[i].Net_value,
					"Plant": oTable[i].Plant,
					"BU_Name": oTable[i].BU_Name,
					"Created_by": oTable[i].Created_by,
					"Approve": ActnKey,
					"Comments": Remarks,
					"Reviewed_by": oTable[i].Reviewed_by,
					"Reviewed_Date": oTable[i].Reviewed_Date

				};

				ymm_2nd_approverSet.push(oentry);
			}
			var Reqtype = this.oRequestype;
			var oPr = "00" + this.oSelectedPR;

			/* var PR_ItemSet =[]; resoue type what value have topass*/

			headeritem = {

				"ymm_2nd_approverSet": ymm_2nd_approverSet,
				"banfn": oPr,
				"Bsart": Reqtype
			};

			var that = this;
			this.oDataModelAPL.create("/ymm_headerSet", headeritem, null, function (oData, oResponse) {

					//that.Attachments(oResponse.data.PR_ItemSet.results[0].PreqNo);

					if (that.SelecteButton === "Reject") {
						sap.m.MessageBox.information("Purchase Requisition" + " " + oResponse.data.ymm_2nd_approverSet.results[0].PRnumber + " " +
							"Rejected  successfully.");
					} else {
						sap.m.MessageBox.information("Purchase Requisition" + " " + oResponse.data.ymm_2nd_approverSet.results[0].PRnumber + " " +
							"Approved successfully.");
					}

					var ootabl1 = that.getView().byId("idApproversTable");
					var xxtab2 = new sap.ui.model.json.JSONModel([]);
					ootabl1.setModel(xxtab2);
					that.getView().byId("ooid").setText("Items(" + "" + xxtab2.oData.length + "" + ")");

					ootabl1.getModel().updateBindings();
					that.getView().byId("oLableid").setText("");
					that.handleRefresh();
				
					that.getView().byId("oRevBy").setText("");
					that.getView().byId("oRevDate").setText("");
				//	sap.ui.getCore().byId("oidex").setValue();

					//	that.TotalValCal();

				},
				function (err) { //Error Callback

				});

		},

		handleLiveChange_Textarea: function (oEvent) {
			var oTextArea = oEvent.getSource(),
				iValueLength = oTextArea.getValue().length,
				iMaxLength = oTextArea.getMaxLength(),
				sState = iValueLength > iMaxLength ? "Error" : "None";

			oTextArea.setValueState(sState);
		},

		onPressReject: function (oEvent) {

			var _odialogR = new sap.m.Dialog({
				title: 'Warning',
				type: 'Message',
				state: 'Warning',
				width: "120%",
				height: "180%",
				content: new sap.m.Text({
					text: 'Are you sure you want to Reject?',
					id: "oRejtex",
					width: "100%",
					height: "80%",
					maxLength: 100

					/*	liveChange: function (oEvent) {
							var oTextArea = oEvent.getSource(),
								iValueLength = oTextArea.getValue().length,
								iMaxLength = oTextArea.getMaxLength(),
								sState = iValueLength > iMaxLength ? "Error" : "None";

							oTextArea.setValueState(sState);

						},
				
						valueLiveUpdate: true,
						showExceededText: true*/
				}),
				beginButton: new sap.m.Button({
					text: 'Yes',
					press: function () {

						_odialogR.destroy(true);
						_odialogR = undefined;

						_odialogR.close();

					}

				}),
				endButton: new sap.m.Button({
					text: 'No',
					press: function () {
						_odialogR.close();
						_odialogR.destroy(true);
						_odialogR = undefined;

					}
				})
			});
			_odialogR.open();

		},
		onAfterRendering: function () {

			var url = "/sap/opu/odata/sap/YMM_2ND_APPROVER_SRV";
			var that = this;
			that.oDataModelAPL = new sap.ui.model.odata.ODataModel(url, true);

			var readRequestURL2 = "/ymm_2nd_approverSet";
			that.oDataModelAPL.read(readRequestURL2, null, null, false, function (oData, oResponse) {
				//duplicates removal code start
				var oObjemodelAPL = oData.results;

				var obj = {};
				for (var i = 0, len = oObjemodelAPL.length; i < len; i++) {
					obj[oObjemodelAPL[i]['PRnumber']] = oObjemodelAPL[i];

					var oAppLiModel = new Array();
					for (var key in obj)
						oAppLiModel.push(obj[key]);

				}

				var oApprxx = new sap.ui.model.json.JSONModel(oAppLiModel);

				that.getView().byId("Items").setModel(oApprxx);
				//duplicates removal code end
				that.getView().byId("master").setTitle("PR's(" + "" + oApprxx.oData.length + "" + ")");

				var ootabl1 = that.getView().byId("idApproversTable");
				var xxtab2 = new sap.ui.model.json.JSONModel([]);
				ootabl1.setModel(xxtab2);
				that.getView().byId("ooid").setText("Items(" + "" + xxtab2.oData.length + "" + ")");

				ootabl1.getModel().updateBindings();
				that.getView().byId("oLableid").setText("");

			

				that.getView().byId("oRevBy").setText("");
				that.getView().byId("oRevDate").setText("");
				//	sap.ui.getCore().byId("oidex").setValue();
				

			});

			//	this.handleRefresh();

		},
		handleRefresh: function () {

				this.onAfterRendering();

			setTimeout(function () {
				this.getView().byId("pullToRefresh").hide();
				this.onAfterRendering();
			}.bind(this), 100);

		},
		handleNavButtonPress: function () {
			var oSplitApp = this.getView().getParent().getParent();
			var oMaster = oSplitApp.getMasterPages()[0];
			oSplitApp.toMaster(oMaster, "flip");
		},

		TotalValCal: function () {
			/*	if (!this.getView().byId("idApproversTable").getModel().getData().length) {
					this.getView().byId("oidTotalsum").setText("0.000");
				} else if (this.getView().byId("idApproversTable").getModel().getData().length) {
					var CurrCode = this.getView().byId("idApproversTable").getModel().getData()[0].Currency;
					var AllItems = this.getView().byId("idApproversTable").getModel().getData().filter(function (x) {
						return (x.DeleteIndicator == false);
					});;
					var CurrencyFilterData = this.getView().byId("idApproversTable").getModel().getData().filter(function (x) {
						return (x.Currency == CurrCode && x.DeleteIndicator == false);
					});
					if (CurrencyFilterData.length == AllItems.length) {
						var Total = 0.000;
						for (var i = 0; i < CurrencyFilterData.length; i++) {
							Total += (parseFloat((CurrencyFilterData[i].TotalPrice)).toFixed(3)) * 1;
						}
						Total = parseFloat((Total)).toFixed(3);
						this.getView().byId("oidTotalsum").setText(Total + " " + CurrCode);
						this.getView().byId("oToatlsumLable").setVisible(true);

					} else {
						this.getView().byId("oidTotalsum").setText("");
						this.getView().byId("oToatlsumLable").setVisible(false);
					}
				}*/
		}

	});
});