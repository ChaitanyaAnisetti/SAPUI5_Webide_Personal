sap.ui.define([
	"sap/ui/test/Opa5",
	"./arrangements/Startup",
	"./NavigationJourney"
], function (Opa5, Startup) {
	"use strict";

	Opa5.extendConfig({
		arrangements: new Startup(),
		viewNamespace: "Sec_Le_ApproverList.YMM_P2P_SecondLevelApproverList.view.",
		autoWait: true
	});
});