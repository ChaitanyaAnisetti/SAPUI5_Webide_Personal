sap.ui.define([
	"Sec_Le_ApproverList/YMM_P2P_SecondLevelApproverList/test/unit/controller/View1.controller"
], function () {
	"use strict";
});