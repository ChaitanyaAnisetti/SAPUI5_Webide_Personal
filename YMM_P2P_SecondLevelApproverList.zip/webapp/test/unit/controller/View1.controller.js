/*global QUnit*/

sap.ui.define([
	"Sec_Le_ApproverList/YMM_P2P_SecondLevelApproverList/controller/View1.controller"
], function (Controller) {
	"use strict";

	QUnit.module("View1 Controller");

	QUnit.test("I should test the View1 controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});