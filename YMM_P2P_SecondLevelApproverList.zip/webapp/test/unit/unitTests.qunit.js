/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"Sec_Le_ApproverList/YMM_P2P_SecondLevelApproverList/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});