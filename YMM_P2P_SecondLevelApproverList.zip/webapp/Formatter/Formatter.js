sap.ui.define(function () {
	var Formatter = {

		PRnumber: function (PRnumber) {

			if (PRnumber != null && PRnumber != undefined) {

				return parseInt(PRnumber);

			};

		},
		Net_value: function (Net_value) {

			if (Net_value != null && Net_value != undefined) {

				return Number(Net_value).toFixed(3);

			};

		},
		Net_Price: function (Net_Price) {

			if (Net_Price != null && Net_Price != undefined) {

				return Number(Net_Price).toFixed(3);

			};

		},
		PRnumber: function (PRnumber) {

			if (PRnumber != null && PRnumber != undefined) {

				return Number(parseInt(PRnumber));

			};

		},
		Reviewed_Date: function (Reviewed_Date) {
			if (Reviewed_Date != null) {
				var oDateFormatA = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var DatevalueA = oDateFormatA.format(new Date(Reviewed_Date));
				return DatevalueA;
			} else {
				DatevalueA = "";

			}

		}

		/*parseInt(xx);*/

	};

	return Formatter;
}, true);