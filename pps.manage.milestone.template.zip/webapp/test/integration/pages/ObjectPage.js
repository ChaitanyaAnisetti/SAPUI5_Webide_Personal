sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/Ancestor",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/actions/EnterText",
	"sap/ui/test/actions/Press",
	"test/opareuse/control/CommonPageObject"
], function (Opa5, AggregationFilled, AggregationLengthEquals, Ancestor, PropertyStrictEquals, EnterText, Press,
	CommonPageObject) {
	"use strict";

	var sViewName = "";

	Opa5.createPageObjects({

		onObjectPage: {

			baseClass: CommonPageObject.createBaseClassForPageObject(sViewName),
			actions: jQuery.extend(CommonPageObject.getCommonActions(), {
				iClickOnCheckBoxInPopup: function (sId) {
					return this.waitFor({
						controlType: "sap.m.CheckBox",
						id: sId,
						actions: new Press(),
						errorMessage: "Could not find Checkbox for selecting all entries in value help"
					});
				}
			}),
			assertions: jQuery.extend(CommonPageObject.getCommonAssertions(), {
				// define here app specific assertions
			})
		}

	});
});