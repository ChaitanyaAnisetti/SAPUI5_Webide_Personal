/*global QUnit*/

sap.ui.define([
	"sap/ui/test/opaQunit"
], function (opaTest) {
	"use strict";

	QUnit.module("Object Page Extension Journey");

	//====================================================================================================
	// "Custom" OPA Tests
	//====================================================================================================

	/* ----------------------------------------------------------
	 * 1 Additional Properties: I should be able to open the app in edit mode
	 * ----------------------------------------------------------
	 */
	opaTest("I should be able to open the app in edit mode", function (Given, When, Then) {
		Given.iStartTheApp();

		When.onTheGenericListReport
			.iExecuteTheSearch();
		
		Then.onTheGenericListReport
			.theResultListIsVisible();	

	});
	
	opaTest("List Item Pressed", function (Given, When, Then) {
		When.onTheGenericListReport
			.iNavigateFromListItemByLineNo(0);
	});

});