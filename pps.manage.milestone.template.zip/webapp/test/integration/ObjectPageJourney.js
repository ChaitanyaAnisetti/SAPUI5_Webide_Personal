/*global QUnit*/

sap.ui.define([
	"sap/ui/test/opaQunit",
	"sap/ui/test/Opa5",
], function (opaTest, Opa5) {
	"use strict";

	module("Object Page Journey");

	//====================================================================================================
	// "Custom" OPA Tests
	//====================================================================================================

	// var iShouldSeeColumn = new sap.ui.test.Opa5({
	// 	findTable: function () {
	// 		return this.waitFor({
	// 			id: "pps.manage.milestone.template::sap.suite.ui.generic.template.ObjectPage.view.Details::MilestoneTemplate--template:::ObjectPageTable:::ColumnListItem:::sFacet::MilestonePlanTemplateDet-__clone133-sub",
	// 		//	id : "pps.manage.milestone.template::sap.suite.ui.generic.template.ObjectPage.view.Details::MilestoneTemplate--isEventMandatory-column-id",
	// 			success: function (oBtn) {
	// 				Opa5.assert.ok("text", "Mandatory Column is visible");
	// 			},
	// 			errorMessage: "Could not find Column"
	// 		});
	// 	}
	// });

	// sap.ui.test.Opa5.extendConfig({
	// 	assertions: iShouldSeeColumn
	// });

	// opaTest("Mandatory Column Visible", function (Given, When, Then) {
	// 	When.onTheGenericObjectPage.iClickTheButtonHavingLabel("Show Details");
	// 	Then.findTable();
	// });

});