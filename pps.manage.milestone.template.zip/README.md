# pps.manage.milestone.template
 
In order to run the application you need users in **UYT/718** and **EDE/038**
