sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("prom.Zpromise.controller.View1", {
		onInit: function () {

		},
		oSinglePromiseoperation: function () {
			debugger;

			var promise = new Promise(function (resolved, rejected) {
				//	var test = true;
				var test = false
				if (test == true) {
					resolved("Hey i was resolved..!!");

				} else {
					rejected("Hey i was rejected..!!");
				}
			});
			promise.then(function (param) {
				console.log(param);
			}, function (param) {
				console.log(param);
			});

		},
		oMultiPromiseoperation: function () {
			debugger

			var promise1 = new Promise(function (resolved, rejected) {
				var test = true;
				if (test) {

					setTimeout(function () {
						resolved("Hey i resolved at promise1");
					}, 700);

				} else {
					
					setTimeout(function(){ rejected("Hey i rejected at promise"); }, 1300);
					//rejected(Error(["Hey i rejected at promise1"]));
				}

			});
			var promise2 = new Promise(function (resolved, rejected) {
				var test = false;

				if (test) {

					setTimeout(function () {
						resolved("Hey i resolved at promise2");
					}, 100);

					//	resolved("Hey i resolved at promise2");

				} else {
					setTimeout(function () {
						rejected("Hey i rejected at promise2");
					}, 100);
					//		rejected(Error(["Hey i rejected at promise2"]));
				}
			});
			var promise3 = new Promise(function (resolved, rejected) {
				var test = true;
				if (test) {
					setTimeout(function() {resolved("Hey i reslved at promise3");},50);
					resolved("Hey i reslved at promise3");
				} else {
					setTimeout(function(){ rejected("Hey i rejected at promise3");},50);
				//	rejected(Error(["Hey i rejected at promise3"]));
				}

			});
			debugger
				Promise.all([promise1, promise2, promise3]).then(function (values) {
					window.alert(values);

				});
			/*	if (!Promise.allSettled) {
				debugger
				Promise.allSettled = function (promises) {
					let wrappedPromises = Array.from(promises).map(p =>
						this.resolve(p).then(
							val => ({

								state: "Fulfilled",
								value: val
							}),

							err => ({
								state: "rejected",
								value: err

							})

						)

					);
					return this.all(wrappedPromises);

				}

			}
			Promise.allSettled([promise1, promise2, promise3]).then(function(values){
				console.log(values)
			}
	);*/

			/*	for(let r of results) {
					if (r.state === "fulfilled") {
						console.log('fulfilled:', r.value);

					} else {
						console.log('rejected:', r.reason);

					}
				}*/

		}

	});

});