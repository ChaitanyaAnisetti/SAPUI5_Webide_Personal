sap.ui.define([
	"prom/Zpromise/test/unit/controller/View1.controller"
], function () {
	"use strict";
});