sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	'sap/ui/model/Filter',
	'sap/ui/model/json/JSONModel'
], function (Controller, MessageBox, Filter, JSONModel) {
	"use strict";

	return Controller.extend("reprintlabel.SIE_ASP_WM_ReprintLabel.controller.ProductLabelReprintItems", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf reprintlabel.SIE_ASP_WM_ReprintLabel.view.ProductLabelReprintItems
		 */
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			//	this.oFioriClient = this.getOwnerComponent().getFioriClient();
			oRouter.getRoute("ProductLabelReprintItems").attachPatternMatched(this._onObjectMatched, this);
			this.oBusyDialog = new sap.m.BusyDialog();

		},
		_onObjectMatched: function (oEvent) {

			if (oEvent.getParameter("arguments").Plant && oEvent.getParameter("arguments").Sloc) {
				var oSelectedPlant = oEvent.getParameter("arguments").Plant || "";
				var oSelectedSloc = oEvent.getParameter("arguments").Sloc || "";
				var FromDate = oEvent.getParameter("arguments").FromDate || "";
				var ToDate = oEvent.getParameter("arguments").ToDate || "";
				var Matedocno = oEvent.getParameter("arguments").Matedocno || "";
				var SpecialStockno = oEvent.getParameter("arguments").SpecialStockno || "";
				var SpecialStockInd = oEvent.getParameter("arguments").SpecialStockInd || "";
				var BatchNo = oEvent.getParameter("arguments").BatchNo || "";
				var MaterialNo = oEvent.getParameter("arguments").MaterialNo || "";
				var sTr = "";

				//	sTr = Plant eq '9CB3' and Sloc eq '0300' and (SpecialStockI eq 'E' or SpecialStockI eq 'Q') and (SpecialStockNoI eq '3000000193000100') and (BatchNoI eq '0000000008' or BatchNoI eq '0000000010') and (PostDate ge '20180801' and PostDate le '20180931') and (MatDocNoI eq '4900000324' or MatDocNoI eq '4900000325') and (MaterialI eq '000000000100003099' or MaterialI eq '000000000100003239')	
				sTr = "Plant eq '" + oSelectedPlant + "' and Sloc eq '" + oSelectedSloc + "'";
				if (SpecialStockInd) {
					sTr = sTr + " and (" + SpecialStockInd + ")";
				}
				if (SpecialStockno) {
					sTr = sTr + " and (" + SpecialStockno + ")";
				}
				if (BatchNo) {
					sTr = sTr + " and (" + BatchNo + ")";
				}
				if (FromDate && ToDate) {
					sTr = sTr + " and ( PostDate ge '" + FromDate +
						"' and PostDate le'" + ToDate + "')";
				}
				if (Matedocno) {
					sTr = sTr + " and (" + Matedocno + ")";
				}
				if (MaterialNo) {
					sTr = sTr + " and (" + MaterialNo + ")";
				}

				this.oBusyDialog.open();
				var oBindingInfo = {
					filters: null,
					urlParameters: {
						"$filter": sTr
					},
					success: function (oData, oResponse) {
						this.oBusyDialog.close();
						if (oData.results && oData.results[0].MsgType === "E") {
							var oPrdctlablreprintitemsmodel = new JSONModel([]);
							this.getView().setModel(oPrdctlablreprintitemsmodel, "oPrdctlablreprintitemsmodel");
							sap.m.MessageBox.error(
								oData.results[0].MsgDesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						} else {
							var oPrdctlablreprintitemsmodel = new JSONModel(oData.results);
							oPrdctlablreprintitemsmodel.setSizeLimit(oData.results.length);
							this.getView().setModel(oPrdctlablreprintitemsmodel, "oPrdctlablreprintitemsmodel");
						}
					}.bind(this),
					error: function (oError) {
						this.oBusyDialog.close();
						var sMsg;
						if (oError.responseText && JSON.parse(oError.responseText).error && JSON.parse(oError.responseText).error.message) {
							sMsg = JSON.parse(oError.responseText).error.message.value;
						} else {
							sMsg = "Error";
						}
						var oPrdctlablreprintitemsmodel = new JSONModel([]);
						this.getView().setModel(oPrdctlablreprintitemsmodel, "oPrdctlablreprintitemsmodel");
						sap.m.MessageBox.error(
							sMsg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);

					}.bind(this)
				};

				this.getOwnerComponent().getModel("LABEL_REPRINT").read("/MatDocFilterSet", oBindingInfo);

			}
		},
		onPrint: function () {
			var SelectedItem = this.getView().byId("oTableprintdata").getSelectedItem();

			if (SelectedItem) {
				var SelectedObject = SelectedItem.getBindingContext("oPrdctlablreprintitemsmodel").getObject();
				var NoLabel = SelectedObject.NoOfLabel;
				NoLabel.split(".");
				var oNofLabel = NoLabel.split(".")[0];
				var MatDocYear = new Date().getFullYear();
				var path = "PrntGS1LabelSet(MatDocNo='" + SelectedObject.MatDocNo +
					"',MatDocYear='" + MatDocYear + "',MatDocItem='" + SelectedObject.MatDocItem + "',LblType='PR',NoOfLabel='" + oNofLabel +
					"')/$value";
				var servicePath = "/sap/opu/odata/SIE/ASP_WM_LABEL_REPRINT_SRV/";
				var sUrl = servicePath + path;
				sap.m.URLHelper.redirect(sUrl, [false]);
			} else {

				sap.m.MessageBox.error("Please click on any line item to reprint");

			}
		},

		onGrlable: function () {
			var SelectedItem = this.getView().byId("oTableprintdata").getSelectedItem();
			if (SelectedItem) {
				var SelectedObject = SelectedItem.getBindingContext("oPrdctlablreprintitemsmodel").getObject();

				if (SelectedObject.Serialno != "X") {
					var NoLabel = SelectedObject.NoOfLabel;
					NoLabel.split(".");
					var oNofLabel = NoLabel.split(".")[0];
				} else {
					oNofLabel = "";
				}

				var MatDocYear = new Date().getFullYear();
				var path = "PrntGS1LabelSet(MatDocNo='" + SelectedObject.MatDocNo +
					"',MatDocYear='" + MatDocYear + "',MatDocItem='" + SelectedObject.MatDocItem + "',LblType='GR',NoOfLabel='" + oNofLabel +
					"')/$value";
				var servicePath = "/sap/opu/odata/SIE/ASP_WM_LABEL_REPRINT_SRV/";
				var sUrl = servicePath + path;
				sap.m.URLHelper.redirect(sUrl, [false]);
			} else {

				sap.m.MessageBox.error("Please click on any line item to reprint");

			}

		},
		onGslable: function () {
			var SelectedItem = this.getView().byId("oTableprintdata").getSelectedItem();
			if (SelectedItem) {
				var SelectedObject = SelectedItem.getBindingContext("oPrdctlablreprintitemsmodel").getObject();
				if (SelectedObject.Serialno != "X") {
					var NoLabel = SelectedObject.NoOfLabel;
					NoLabel.split(".");
					var oNofLabel = NoLabel.split(".")[0];
				} else {
					oNofLabel = "";
				}

				var MatDocYear = new Date().getFullYear();
				var path = "PrntGS1LabelSet(MatDocNo='" + SelectedObject.MatDocNo +
					"',MatDocYear='" + MatDocYear + "',MatDocItem='" + SelectedObject.MatDocItem + "',LblType='GS',NoOfLabel='" + oNofLabel +
					"')/$value";
				var servicePath = "/sap/opu/odata/SIE/ASP_WM_LABEL_REPRINT_SRV/";
				var sUrl = servicePath + path;
				sap.m.URLHelper.redirect(sUrl, [false]);
			} else {

				sap.m.MessageBox.error("Please click on any line item to reprint");

			}

		},

		onBack: function () {
			var oRouter = new sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ProductLabelReprintMain", {

			});

		},
		onPressback: function () {
			var oRouter = new sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ProductLabelReprintMain", {

			});
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf reprintlabel.SIE_ASP_WM_ReprintLabel.view.ProductLabelReprintItems
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf reprintlabel.SIE_ASP_WM_ReprintLabel.view.ProductLabelReprintItems
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf reprintlabel.SIE_ASP_WM_ReprintLabel.view.ProductLabelReprintItems
		 */
		//	onExit: function() {
		//
		//	}

	});

});