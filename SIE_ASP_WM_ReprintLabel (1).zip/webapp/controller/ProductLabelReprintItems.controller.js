sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	'sap/ui/model/Filter',
		'sap/m/Token',
	'sap/ui/model/json/JSONModel',
		"reprintlabel/SIE_ASP_WM_ReprintLabel/Formatter/Formatter"
], function (Controller, MessageBox, Filter,Token, JSONModel, Formatter) {
	"use strict";

	return Controller.extend("reprintlabel.SIE_ASP_WM_ReprintLabel.controller.ProductLabelReprintItems", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf reprintlabel.SIE_ASP_WM_ReprintLabel.view.ProductLabelReprintItems
		 */
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			//	this.oFioriClient = this.getOwnerComponent().getFioriClient();
			oRouter.getRoute("ProductLabelReprintItems").attachPatternMatched(this._onObjectMatched, this);
			this.oBusyDialog = new sap.m.BusyDialog();

		},
		_onObjectMatched: function (oEvent) {

			if (oEvent.getParameter("arguments").Plant && oEvent.getParameter("arguments").Sloc) {
				var oSelectedPlant = oEvent.getParameter("arguments").Plant || "";
				var oSelectedSloc = oEvent.getParameter("arguments").Sloc || "";
				var FromDate = oEvent.getParameter("arguments").FromDate || "";
				var ToDate = oEvent.getParameter("arguments").ToDate || "";
				var Matedocno = oEvent.getParameter("arguments").Matedocno || "";
				var SpecialStockno = oEvent.getParameter("arguments").SpecialStockno || "";
				var SpecialStockInd = oEvent.getParameter("arguments").SpecialStockInd || "";
				var BatchNo = oEvent.getParameter("arguments").BatchNo || "";
				var MaterialNo = oEvent.getParameter("arguments").MaterialNo || "";
				var sTr = "";

				//	sTr = Plant eq '9CB3' and Sloc eq '0300' and (SpecialStockI eq 'E' or SpecialStockI eq 'Q') and (SpecialStockNoI eq '3000000193000100') and (BatchNoI eq '0000000008' or BatchNoI eq '0000000010') and (PostDate ge '20180801' and PostDate le '20180931') and (MatDocNoI eq '4900000324' or MatDocNoI eq '4900000325') and (MaterialI eq '000000000100003099' or MaterialI eq '000000000100003239')	
				sTr = "Plant eq '" + oSelectedPlant + "' and Sloc eq '" + oSelectedSloc + "'";
				if (SpecialStockInd) {
					sTr = sTr + " and (" + SpecialStockInd + ")";
				}
				if (SpecialStockno) {
					sTr = sTr + " and (" + SpecialStockno + ")";
				}
				if (BatchNo) {
					sTr = sTr + " and (" + BatchNo + ")";
				}
				if (FromDate && ToDate) {
					sTr = sTr + " and ( PostDate ge '" + FromDate +
						"' and PostDate le'" + ToDate + "')";
				}
				if (Matedocno) {
					sTr = sTr + " and (" + Matedocno + ")";
				}
				if (MaterialNo) {
					sTr = sTr + " and (" + MaterialNo + ")";
				}

				this.oBusyDialog.open();
				var oBindingInfo = {
					filters: null,
					urlParameters: {
						"$filter": sTr
					},
					success: function (oData, oResponse) {
						this.oBusyDialog.close();
						if (oData.results && oData.results[0].MsgType === "E") {
							var oPrdctlablreprintitemsmodel = new JSONModel([]);
							this.getView().setModel(oPrdctlablreprintitemsmodel, "oPrdctlablreprintitemsmodel");
							MessageBox.error(
								oData.results[0].MsgDesc, {
									icon: MessageBox.Icon.ERROR,
									actions: [MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						} else {
							var oPrdctlablreprintitemsmodel = new JSONModel(oData.results);
							oPrdctlablreprintitemsmodel.setSizeLimit(oData.results.length);
							this.getView().setModel(oPrdctlablreprintitemsmodel, "oPrdctlablreprintitemsmodel");
						}
					}.bind(this),
					error: function (oError) {
						this.oBusyDialog.close();
						var sMsg;
						if (oError.responseText && JSON.parse(oError.responseText).error && JSON.parse(oError.responseText).error.message) {
							sMsg = JSON.parse(oError.responseText).error.message.value;
						} else {
							sMsg = "Error";
						}
						var oPrdctlablreprintitemsmodel = new JSONModel([]);
						this.getView().setModel(oPrdctlablreprintitemsmodel, "oPrdctlablreprintitemsmodel");
						MessageBox.error(
							sMsg, {
								icon: MessageBox.Icon.ERROR,
								actions: [MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);

					}.bind(this)
				};

				this.getOwnerComponent().getModel("LABEL_REPRINT").read("/MatDocFilterSet", oBindingInfo);

			}
		},
		onPrint: function () {
			var SelectedItem = this.getView().byId("oTableprintdata").getSelectedItem();

			if (SelectedItem) {
				var SelectedObject = SelectedItem.getBindingContext("oPrdctlablreprintitemsmodel").getObject();
				var NoLabel = SelectedObject.NoOfLabel;
				NoLabel.split(".");
				var oNofLabel = NoLabel.split(".")[0];
				var path = "/PrintLabelSet(MatDocNo='" + SelectedObject.MatDocNo +
					"',MatDocYear='" + SelectedObject.MatDocYear + "',MatDocItem='" + SelectedObject.MatDocItem + "',LblType='PR',NoOfLabel='" +
					oNofLabel + "')";
			var oSrnoTokens=SelectedItem.getAggregation("cells")[12].getTokens();
			var SrnoData = [];
				var Srno;
				for (var i = 0; i < oSrnoTokens.length; i++) {

					SrnoData.push(oSrnoTokens[i].getText());

				}
				var value;
				if (SrnoData.length > 1) {
					var Data = SrnoData.reduce(function (a, b) {

						if (value == undefined) {
							value = "Serialno eq " + "'";
						} else {
							value = "";

						}

						return value + (a || a) + "' or Serialno eq" + " " + "'" + b + "'";
					});
					Data = Data.replace(/''/g, "'");
				} else if (SrnoData.length == 1) {
					Data = "Serialno eq '" + SrnoData[0] + "'";
				} else {
					Data = "Serialno eq ''";
				}
				this._PostPrintValues(path,Data);
			} else {

				MessageBox.error("Please click on any line item to reprint");

			}
		},

		onGrlable: function () {
			var SelectedItem = this.getView().byId("oTableprintdata").getSelectedItem();
			if (SelectedItem) {
				var SelectedObject = SelectedItem.getBindingContext("oPrdctlablreprintitemsmodel").getObject();

				if (SelectedObject.Serialno != "X") {
					var NoLabel = SelectedObject.NoOfLabel;
					NoLabel.split(".");
					var oNofLabel = NoLabel.split(".")[0];
				} else {
					oNofLabel = "";
				}

				//	var MatDocYear = new Date().getFullYear();
				var path = "/PrintLabelSet(MatDocNo='" + SelectedObject.MatDocNo +
					"',MatDocYear='" + SelectedObject.MatDocYear + "',MatDocItem='" + SelectedObject.MatDocItem + "',LblType='GR',NoOfLabel='" +
					oNofLabel + "')";
						var oSrnoTokens=SelectedItem.getAggregation("cells")[12].getTokens();
			var SrnoData = [];
				var Srno;
				for (var i = 0; i < oSrnoTokens.length; i++) {

					SrnoData.push(oSrnoTokens[i].getText());

				}
				var value;
				if (SrnoData.length > 1) {
					var Data = SrnoData.reduce(function (a, b) {

						if (value == undefined) {
							value = "Serialno eq " + "'";
						} else {
							value = "";

						}

						return value + (a || a) + "' or Serialno eq" + " " + "'" + b + "'";
					});
					Data = Data.replace(/''/g, "'");
				} else if (SrnoData.length == 1) {
					Data = "Serialno eq '" + SrnoData[0] + "'";
				} else {
					Data = "Serialno eq ''";
				}
				this._PostPrintValues(path,Data);
			} else {

				MessageBox.error("Please click on any line item to reprint");

			}

		},
		onGslable: function () {
			var SelectedItem = this.getView().byId("oTableprintdata").getSelectedItem();
			if (SelectedItem) {
				var SelectedObject = SelectedItem.getBindingContext("oPrdctlablreprintitemsmodel").getObject();
				if (SelectedObject.Serialno != "X") {
					var NoLabel = SelectedObject.NoOfLabel;
					NoLabel.split(".");
					var oNofLabel = NoLabel.split(".")[0];
				} else {
					oNofLabel = "";
				}

				//	var MatDocYear = new Date().getFullYear();
				var path = "/PrintLabelSet(MatDocNo='" + SelectedObject.MatDocNo +
					"',MatDocYear='" + SelectedObject.MatDocYear + "',MatDocItem='" + SelectedObject.MatDocItem + "',LblType='GS',NoOfLabel='" +
					oNofLabel + "')";
				var oSrnoTokens=SelectedItem.getAggregation("cells")[12].getTokens();
			var SrnoData = [];
				var Srno;
				for (var i = 0; i < oSrnoTokens.length; i++) {

					SrnoData.push(oSrnoTokens[i].getText());

				}
				var value;
				if (SrnoData.length > 1) {
					var Data = SrnoData.reduce(function (a, b) {

						if (value == undefined) {
							value = "Serialno eq " + "'";
						} else {
							value = "";

						}

						return value + (a || a) + "' or Serialno eq" + " " + "'" + b + "'";
					});
					Data = Data.replace(/''/g, "'");
				} else if (SrnoData.length == 1) {
					Data = "Serialno eq '" + SrnoData[0] + "'";
				} else {
					Data = "Serialno eq ''";
				}
				this._PostPrintValues(path,Data);
			} else {

				MessageBox.error("Please click on any line item to reprint");

			}

		},

		onBack: function () {
			var oRouter = new sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ProductLabelReprintMain", {

			});

		},
		onPressback: function () {
			var oRouter = new sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ProductLabelReprintMain", {

			});
		},
		_PostPrintValues: function (path,sTr) {
			var that = this;
			this.oBusyDialog.open();
			var oBindingInfo = {
				filters: null,
					urlParameters: {
					"$filter": sTr
				},
				success: function (oData, oResponse) {
					this.oBusyDialog.close();
					if (oData && oData.MsgType === "S") {
						MessageBox.success(
							oData.MsgDesc, {
								icon: MessageBox.Icon.SUCCESS,
								actions: [MessageBox.Action.OK],
								onClose: function (oAction) {}

							});

					} else {
						MessageBox.error(
							oData.MsgDesc, {
								icon: MessageBox.Icon.ERROR,
								actions: [MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);
					}
				}.bind(this),
				error: function (oError) {
					this.oBusyDialog.close();
					var sMsg;
					if (oError.responseText && JSON.parse(oError.responseText).error && JSON.parse(oError.responseText).error.message) {
						sMsg = JSON.parse(oError.responseText).error.message.value;
					} else {
						sMsg = "Error";
					}
					MessageBox.error(
						sMsg, {
							icon: MessageBox.Icon.ERROR,
							actions: [MessageBox.Action.CLOSE],
							onClose: function (oAction) {}

						}
					);

				}.bind(this)
			};
			this.getOwnerComponent().getModel("LABEL_REPRINT").read(path, oBindingInfo);
		},
		onSerianNumValuehelpPress: function (oEvt) {
			if (!this._Dialog) {
				this._Dialog = sap.ui.xmlfragment(
					"reprintlabel.SIE_ASP_WM_ReprintLabel.view.SerialNo",
					this
				);
				var oSelMatDocno = oEvt.getSource().getBindingContext("oPrdctlablreprintitemsmodel").getObject().MatDocNo;

				var oSelMaItemno = oEvt.getSource().getBindingContext("oPrdctlablreprintitemsmodel").getObject().MatDocItem;
				var oSelMatyear = oEvt.getSource().getBindingContext("oPrdctlablreprintitemsmodel").getObject().MatDocYear;
				this._getSerianNumValuehelpData(oSelMatDocno, oSelMaItemno, oSelMatyear);
				this.getView().addDependent(this._Dialog);
			}
			this.Srnof4Id= oEvt.getSource().getId();
		

		},
		_getSerianNumValuehelpData: function (oSelMatDocno, oSelMaItemno, oSelMatyear) {
			var sTr = "MatDocNo eq '" + oSelMatDocno + "' and MatDocYear eq '" + oSelMatyear + "' and MatDocItem eq '" + oSelMaItemno + "'";
			this.oBusyDialog.open();
			var oBindingInfo = {
				filters: null,
				urlParameters: {
					"$filter": sTr
				},
				success: function (oData, oResponse) {
					
					this.oBusyDialog.close();
					if (oData.results && oData.results[0].Msgtype === "E") {
						var oSerialnoModel = new JSONModel([]);
						this.getView().setModel(oSerialnoModel, "oSerialnoModel");
					} else {
						var oSerialnoModel = new JSONModel(oData.results);
						//	oSerialnoModel.setSizeLimit(oData.results.length);
						this.getView().setModel(oSerialnoModel, "oSerialnoModel");
					}
						this._Dialog.open();
			var oTokens = this.getView().byId(this.Srnof4Id).getTokens();
				var SrhNoData = sap.ui.getCore().byId("oSerialnoid").getAggregation("items");
				if (oTokens.length && SrhNoData && SrhNoData.length) {
					for (var i = 0; i < oTokens.length; i++) {
						for (var j = 0; j < SrhNoData.length; j++) {
							if (oTokens[i].getText() === SrhNoData[j].getTitle()) {
								sap.ui.getCore().byId("oSerialnoid").getAggregation("items")[j].setSelected(true);
							}
						}
					}
				}

				}.bind(this),
				error: function (oError) {
					this.oBusyDialog.close();
						this._Dialog.open();

				}.bind(this)
			};

			this.getOwnerComponent().getModel("LABEL_REPRINT").read("/MaintainserialNumSet", oBindingInfo);

		},

		handleSerialnoSearch_Press: function (oEvent) {
			var aFilters = [];
			var sQuery = oEvent.getParameter("value");
			var list = sap.ui.getCore().byId("oSerialnoid");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("Serialno", sap.ui.model.FilterOperator.Contains, sQuery)

				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		onSerialnoConfirm: function (oEvent) {
				var aSelectedItems = oEvent.getParameter("selectedItems"),
				oMultiInput =this.getView().byId(this.Srnof4Id);

			if (aSelectedItems && aSelectedItems.length > 0) {
				oMultiInput.setTokens([]);
				aSelectedItems.forEach(function (oItem) {
					oMultiInput.addToken(new Token({
						text: oItem.getTitle()
					}));
				});
			} else {
				oMultiInput.setTokens([]);
			}
			//	this.oselectedStoragebinType = oEvent.getParameter('selectedItem').getProperty("description");
			/*	if (oSelectedItemStoragebin) {
					var oStorageInputval = this.getView().byId("filterStorageBin");
					oStorageInputval.setValue(oSelectedItemStoragebin);
				} else {
					this.getView().byId("filterStorageBin").setValue("");
				}*/
		//	oEvent.getSource().getBinding("items").filter([]);

			this._Dialog.destroy(true);
			this._Dialog = undefined;

		},
		onSerialnoCancel: function () {
			this._Dialog.destroy(true);
			this._Dialog = undefined;
		},
		handleSerialnoConfSearch: function (oEvt) {
			var StoragebinVal = oEvt.getSource().getValue();
			if (StoragebinVal) {
				//this._CheckStoragebin(StoragebinVal);
			} else {
				var oSerialnoModel = new JSONModel([]);
				this.getView().setModel(oSerialnoModel, "oSerialnoModel");
			}
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf reprintlabel.SIE_ASP_WM_ReprintLabel.view.ProductLabelReprintItems
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf reprintlabel.SIE_ASP_WM_ReprintLabel.view.ProductLabelReprintItems
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf reprintlabel.SIE_ASP_WM_ReprintLabel.view.ProductLabelReprintItems
		 */
		//	onExit: function() {
		//
		//	}

	});

});