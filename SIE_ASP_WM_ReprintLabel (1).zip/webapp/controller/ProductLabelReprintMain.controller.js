jQuery.sap.require("sap.ui.core.format.DateFormat");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	'sap/ui/model/Filter',
	'sap/ui/model/json/JSONModel',
	'sap/m/Token',
	'sap/ui/model/FilterOperator',
	"reprintlabel/SIE_ASP_WM_ReprintLabel/Formatter/Formatter",
	"sap/ui/core/library"

], function (Controller, MessageBox, Filter, JSONModel, Token, FilterOperator, Formatter, CoreLibrary) {
	"use strict";
	var ValueState = CoreLibrary.ValueState;
	return Controller.extend("reprintlabel.SIE_ASP_WM_ReprintLabel.controller.ProductLabelReprintMain", {
		onInit: function () {
			var oModel = new JSONModel(),
				dateFrom = new Date(),
				dateTo = new Date();

			dateTo.setDate(dateTo.getDate() + 30);
			/*	dateFrom.setUTCDate(new Date().getDate() - 1);

				dateFrom.setUTCMonth(new Date().getMonth());
				dateFrom.setUTCFullYear(new Date().getFullYear());

				dateTo.setUTCDate(new Date().getDate() - 1);
				dateTo.setUTCMonth(new Date().getMonth() + 1);
				dateTo.setUTCFullYear(new Date().getFullYear());*/
			dateFrom.setUTCDate(dateFrom.getDate() - 1);

			dateFrom.setUTCMonth(dateFrom.getMonth());
			dateFrom.setUTCFullYear(dateFrom.getFullYear());

			dateTo.setUTCDate(dateTo.getDate() - 1);
			dateTo.setUTCMonth(dateTo.getMonth());
			dateTo.setUTCFullYear(dateTo.getFullYear());

			oModel.setData({
				delimiterDRS1: "@",
				dateValueDRS1: dateFrom,
				secondDateValueDRS1: dateTo,
				dateFormatDRS1: "dd.MM.yyyy"
			});

			this.getView().setModel(oModel, "oDRSModel");

			var that = this;
			this.getView().byId("osloc").attachBrowserEvent("click", function () {
				if (that.getView().byId("oPlant").getSelectedKey() == "") {
					sap.m.MessageBox.error("Please select plant");
				}

			});
			this.oBusyDialog = new sap.m.BusyDialog();

			var Gid = this.getOwnerComponent().getModel("localModel").getProperty("/Gid");

			var path1 = "/UserDefaultSet('" + Gid + "')";
			this.oBusyDialog.open();
			this.getOwnerComponent().getModel("LABEL_REPRINT").read(path1, {
				success: function (oData, oResponse) {
					if (oData.MsgType === "S") {
						this.oWh = oData.WarehouseNo;
						this.oPlant = oData.Plant;
						this._getMaterialValuehelpData(oData.Plant, oData.WarehouseNo);
						this._getPlantValuehelpData(oData.UserGID, oData.WarehouseNo);
						this.getOwnerComponent().getModel("localModel").setProperty("/LoginUserInfo", oData);
						this.oBusyDialog.close();
					} else {
						this.oBusyDialog.close();
						sap.m.MessageBox.error(
							oData.MsgDesc, {
								icon: sap.m.MessageBox.Icon.ERROR,
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);
					}
				}.bind(this),
				error: function (err) {
					this.oBusyDialog.close();
					sap.m.MessageBox.show(
						"OData error in UserDefaultSet", {
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.CLOSE],
							onClose: function (oAction) {}
						}
					);

				}.bind(this)
			});
		},
		handleChangeDRS: function (oEvent) {
			var bValid = oEvent.getParameter("valid"),
				oEventSource = oEvent.getSource();

			this.getView().byId("oSpclstockindicator").setTokens([]);
			this.getView().byId("oSpclstockindicator").setValue("");
			this.getView().byId("oSpecialstockno").setTokens([]);
			this.getView().byId("oSpecialstockno").setValue("");
			this.getView().byId("oMatedocno").setTokens([]);
			this.getView().byId("oMatedocno").setValue("");

			if (bValid) {
				oEventSource.setValueState(ValueState.None);

				if (this.getView().byId("oPlant").getSelectedKey() && this.getView().byId("osloc").getSelectedKey() && this.getView().byId("DRS1")
					.getFrom() && this.getView().byId("DRS1").getTo()) {
					this._getStockIndValuehelpData();
				}
			} else {
				oEventSource.setValueState(ValueState.Error);
			}

		},
		_getStockIndValuehelpData: function () {

			if (this.getView().byId("oPlant").getSelectedKey() == "" || this.getView().byId("osloc").getSelectedKey() == "" || !(this.getView()
					.byId("DRS1").getFrom() && this.getView().byId("DRS1").getTo())) {
				sap.m.MessageBox.error("Please select required fields & choose From @ To dates");
			} else {
				var oSelectedPlant = this.getView().byId("oPlant").getSelectedKey();
				var oSelectedSloc = this.getView().byId("osloc").getSelectedKey();

				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyyMMdd"
				});
				var FromDate = this.getView().byId("DRS1").getFrom();
				FromDate = dateFormat.format(new Date(FromDate));
				var ToDate = this.getView().byId("DRS1").getTo();
				ToDate = dateFormat.format(new Date(ToDate));
				/*	FromDate = "20210701";
					ToDate = "20210731";*/
				var sTr = "Plant eq '" + oSelectedPlant + "' and Sloc eq '" + oSelectedSloc + "' and ( PostDate ge '" + FromDate +
					"' and PostDate le'" + ToDate + "')";

				this.oBusyDialog.open();
				var oBindingInfo = {
					filters: null,
					urlParameters: {
						"$filter": sTr
					},
					success: function (oData, oResponse) {
						this.oBusyDialog.close();
						var obj = {};
						var SpecialstockData = oData.results;
						for (var i = 0, len = SpecialstockData.length; i < len; i++)
							obj[SpecialstockData[i]['SpecialStock']] = SpecialstockData[i];
						SpecialstockData = new Array();
						for (var key in obj)
							SpecialstockData.push(obj[key]);
						var oStockIndModel = new JSONModel(SpecialstockData);
						oStockIndModel.setSizeLimit(SpecialstockData.length);

						this.getView().setModel(oStockIndModel, "oStockIndModel");

						var obj1 = {};
						var MatDocData = oData.results;
						for (var j = 0, len1 = MatDocData.length; j < len1; j++)
							obj1[MatDocData[j]['MatDocNo']] = MatDocData[j];
						MatDocData = new Array();
						for (var key1 in obj1)
							MatDocData.push(obj1[key1]);

						var MaterialdocModel = new JSONModel(MatDocData);
						MaterialdocModel.setSizeLimit(MatDocData.length);
						this.getView().setModel(MaterialdocModel, "MaterialdocModel");
					}.bind(this),
					error: function (oError) {
						this.oBusyDialog.close();
						var oStockIndModel = new JSONModel([]);
						this.getView().setModel(oStockIndModel, "oStockIndModel");
						var MaterialdocModel = new JSONModel([]);
						this.getView().setModel(MaterialdocModel, "MaterialdocModel");
					}.bind(this)
				};

				this.getOwnerComponent().getModel("LABEL_REPRINT").read("/MatDocFilterSet", oBindingInfo);

			}

		},
		_getMaterialValuehelpData: function (Plant, WarehouseNo) {
			var sTr = "WarehouseNo eq'" + WarehouseNo + "' and Plant eq '" + Plant + "'";
			this.oBusyDialog.open();
			var oBindingInfo = {
				filters: null,
				urlParameters: {
					"$filter": sTr
				},
				success: function (oData, oResponse) {
					this.oBusyDialog.close();
					if (oData.results && oData.results[0].Msgtype === "E") {
						sap.m.MessageBox.error(
							oData.results[0].Msgdesc, {
								icon: sap.m.MessageBox.Icon.ERROR,
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);
						var oMaterialModel = new JSONModel([]);
						this.getView().setModel(oMaterialModel, "oMaterialModel");
					} else {
						var oMaterialModel = new JSONModel(oData.results);
						oMaterialModel.setSizeLimit(oData.results.length);
						this.getView().setModel(oMaterialModel, "oMaterialModel");
					}

				}.bind(this),
				error: function (oError) {
					this.oBusyDialog.close();
					var oMaterialModel = new JSONModel([]);
					this.getView().setModel(oMaterialModel, "oMaterialModel");
				}.bind(this)
			};

			this.getOwnerComponent().getModel("LABEL_REPRINT").read("/SH_MaterialSet", oBindingInfo);

		},
		_getPlantValuehelpData: function (UserGID, WarehouseNo) {

			var sTr = "UserGID eq '" + UserGID + "' and WarehouseNo eq '" + WarehouseNo + "'";
			this.oBusyDialog.open();
			var oBindingInfo = {
				filters: null,
				urlParameters: {
					"$filter": sTr
				},
				success: function (oData, oResponse) {
					this.oBusyDialog.close();
					var oPlantModel = new JSONModel(oData.results);
					oPlantModel.setSizeLimit(oData.results.length);
					this.getView().setModel(oPlantModel, "oPlantModel");
				}.bind(this),
				error: function (oError) {
					this.oBusyDialog.close();
					var oPlantModel = new JSONModel([]);
					this.getView().setModel(oPlantModel, "oPlantModel");
				}.bind(this)
			};

			this.getOwnerComponent().getModel("LABEL_REPRINT").read("/SH_PlantSet", oBindingInfo);

		},
		handleMateNoValueHelp: function (oEvent) {

			if (!this._MatnoDialog) {
				this._MatnoDialog = sap.ui.xmlfragment(
					"reprintlabel.SIE_ASP_WM_ReprintLabel.Fragment.MaterialNo",
					this
				);
				this.getView().addDependent(this._MatnoDialog);

			}
	
			var oTokens = this.getView().byId("oMaterialno").getTokens();
			var MaterialnoData = sap.ui.getCore().byId("valueHelpMatnoDialog").getAggregation("items");
			if (oTokens.length && MaterialnoData && MaterialnoData.length) {
				for (var i = 0; i < oTokens.length; i++) {
					for (var j = 0; j < MaterialnoData.length; j++) {
						if (oTokens[i].getText() === MaterialnoData[j].getTitle()) {
							sap.ui.getCore().byId("valueHelpMatnoDialog").getAggregation("items")[j].setSelected(true);
						}
					}
				}
			}
			this._MatnoDialog.open();

		},
		_handleValueHelpMatnoSearch: function (oEvent) {
			var aFilters = [];
			var sQuery = oEvent.getParameter("value");
			var list = sap.ui.getCore().byId("valueHelpMatnoDialog");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("MatDes", sap.ui.model.FilterOperator.Contains, sQuery)

				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		_handleValueHelpMatnoConfirm: function (oEvent) {
			var aSelectedItems = oEvent.getParameter("selectedItems"),
				oMultiInput = this.byId("oMaterialno");
			oMultiInput.setTokens([]);
			if (aSelectedItems && aSelectedItems.length > 0) {

				aSelectedItems.forEach(function (oItem) {
					oMultiInput.addToken(new Token({
						text: oItem.getTitle()
					}));
				});
			}
			this._MatnoDialog.destroy(true);
			this._MatnoDialog = undefined;
		},

		_handleValueHelpMatnoClose: function () {
			this._MatnoDialog.destroy(true);
			this._MatnoDialog = undefined;
		},

		oPlantchange: function (oEvt) {

			var oSlocModel = new JSONModel([]);
			this.getView().setModel(oSlocModel, "oSlocModel");

			this.getView().byId("oBatchno").setTokens([]);
			this.getView().byId("oBatchno").setValue("");
			this.getView().byId("oSpclstockindicator").setTokens([]);
			this.getView().byId("oSpclstockindicator").setValue("");
			this.getView().byId("oSpecialstockno").setTokens([]);
			this.getView().byId("oSpecialstockno").setValue("");
			this.getView().byId("oMatedocno").setTokens([]);
			this.getView().byId("oMatedocno").setValue("");
			var oSelectedPlant = oEvt.getSource("items").getSelectedKey();
			var sTr = "Plant eq '" + oSelectedPlant + "'";
			this.oBusyDialog.open();
			var oBindingInfo = {
				filters: null,
				urlParameters: {
					"$filter": sTr
				},
				success: function (oData, oResponse) {
					this.oBusyDialog.close();
					if (oData.results && oData.results[0].Msgtype === "E") {
						sap.m.MessageBox.error(
							oData.results[0].Msgdesc, {
								icon: sap.m.MessageBox.Icon.ERROR,
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);
						var oSlocModel = new JSONModel([]);
						this.getView().setModel(oSlocModel, "oSlocModel");
					} else {
						var oSlocModel = new JSONModel(oData.results);
						oSlocModel.setSizeLimit(oData.results.length);
						this.getView().setModel(oSlocModel, "oSlocModel");
					}
				}.bind(this),
				error: function (oError) {
					this.oBusyDialog.close();
					var oSlocModel = new JSONModel([]);
					this.getView().setModel(oSlocModel, "oSlocModel");
				}.bind(this)
			};

			this.getOwnerComponent().getModel("LABEL_REPRINT").read("/SH_SlocSet", oBindingInfo);

		},
		oSlocChange: function (oEvt) {

			if (this.getView().byId("oPlant").getSelectedKey() == "") {
				sap.m.MessageBox.error("Please select required mandatory fields");
				return;
			}
			this.getView().byId("oBatchno").setTokens([]);
			this.getView().byId("oBatchno").setValue("");
			this.getView().byId("oSpclstockindicator").setTokens([]);
			this.getView().byId("oSpclstockindicator").setValue("");
			this.getView().byId("oSpecialstockno").setTokens([]);
			this.getView().byId("oSpecialstockno").setValue("");
			this.getView().byId("oMatedocno").setTokens([]);
			this.getView().byId("oMatedocno").setValue("");

			var oSelectedPlant = this.getView().byId("oPlant").getSelectedKey();
			var sTr = "Plant eq '" + oSelectedPlant + "'";
			this.oBusyDialog.open();
			var oBindingInfo = {
				filters: null,
				urlParameters: {
					"$filter": sTr
				},
				success: function (oData, oResponse) {
					this.oBusyDialog.close();
					if (oData.results && oData.results[0].MsgType1 === "E") {
						sap.m.MessageBox.error(
							oData.results[0].MsgDesc, {
								icon: sap.m.MessageBox.Icon.ERROR,
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);
						var oBatcNoModel = new JSONModel([]);
						this.getView().setModel(oBatcNoModel, "oBatcNoModel");
					} else {
						var oBatcNoModel = new JSONModel(oData.results);
						oBatcNoModel.setSizeLimit(oData.results.length);
						this.getView().setModel(oBatcNoModel, "oBatcNoModel");
					}

				}.bind(this),
				error: function (oError) {
					this.oBusyDialog.close();
					var oBatcNoModel = new JSONModel([]);
					this.getView().setModel(oBatcNoModel, "oBatcNoModel");
				}.bind(this)
			};

			this.getOwnerComponent().getModel("LABEL_REPRINT").read("/SH_BatchSet", oBindingInfo);

			if (this.getView().byId("oPlant").getSelectedKey() && this.getView().byId("DRS1").getFrom() && this.getView().byId("DRS1").getTo()) {
				this._getStockIndValuehelpData();
			}

		},

		handleBatchnoValueHelp: function (oEvent) {

			if (this.getView().byId("oPlant").getSelectedKey() == "") {
				sap.m.MessageBox.error("Please select required mandatory fields");
			} else {
				if (!this._BatchnoDialog) {
					this._BatchnoDialog = sap.ui.xmlfragment(
						"reprintlabel.SIE_ASP_WM_ReprintLabel.Fragment.BatchNo",
						this
					);
					this.getView().addDependent(this._BatchnoDialog);

				}
				var oTokens = this.getView().byId("oBatchno").getTokens();
				var BatchNoData = sap.ui.getCore().byId("valueHelpBatchoDialog").getAggregation("items");
				if (oTokens.length && BatchNoData && BatchNoData.length) {
					for (var i = 0; i < oTokens.length; i++) {
						for (var j = 0; j < BatchNoData.length; j++) {
							if (oTokens[i].getText() === BatchNoData[j].getTitle()) {
								sap.ui.getCore().byId("valueHelpBatchoDialog").getAggregation("items")[j].setSelected(true);
							}
						}
					}
				}
				this._BatchnoDialog.open();
			}

		},
		_handleValueHelpBatchSearch: function (oEvent) {
			var aFilters = [];
			var sQuery = oEvent.getParameter("value");
			var list = sap.ui.getCore().byId("valueHelpBatchoDialog");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("Batchno", sap.ui.model.FilterOperator.Contains, sQuery)

				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		_handleValueHelpBatchConfirm: function (oEvent) {
			var aSelectedItems = oEvent.getParameter("selectedItems"),
				oMultiInput = this.byId("oBatchno");

			if (aSelectedItems && aSelectedItems.length > 0) {
				oMultiInput.setTokens([]);
				aSelectedItems.forEach(function (oItem) {
					oMultiInput.addToken(new Token({
						text: oItem.getTitle()
					}));
				});
			} else {
				oMultiInput.setTokens([]);
			}

			this._BatchnoDialog.destroy(true);
			this._BatchnoDialog = undefined;
		},
		handleBatchnoChange: function (oevt) {
			if (this.getView().byId("oPlant").getSelectedKey() == "") {
				sap.m.MessageBox.error("Please select Plant");
				this.getView().byId("oBatchno").setTokens([]);
				this.getView().byId("oBatchno").setValue("");
			} else {
				var oValue = oevt.getSource().getValue();
				var MatData2 = oevt.getSource().getModel("oBatcNoModel").getData().filter(function (x) {
					return x.Batchno == oValue;
				});
				if (MatData2.length) {

				} else {
					if (oValue != "") {
						sap.m.MessageBox.warning("Please enter valid Batch No.");
					}
					oevt.getSource().setValue("");
					oevt.getSource().setTokens([]);

				}
			}

		},
		_handleValueHelpBatchClose: function () {
			this._BatchnoDialog.destroy(true);
			this._BatchnoDialog = undefined;
		},
		handleSpecialstockindValueHelp: function (oEvent) {

			if (this.getView().byId("oPlant").getSelectedKey() == "" || this.getView().byId("osloc").getSelectedKey() == "" || !(this.getView()
					.byId("DRS1").getFrom() && this.getView().byId("DRS1").getTo())) {
				sap.m.MessageBox.error("Please select required mandatory fields & posting date");
			} else {
				if (!this._SpecialStockindDialog) {
					this._SpecialStockindDialog = sap.ui.xmlfragment(
						"reprintlabel.SIE_ASP_WM_ReprintLabel.Fragment.SpecialStockindicator",
						this
					);
					this.getView().addDependent(this._SpecialStockindDialog);

				}
				var oTokens = this.getView().byId("oSpclstockindicator").getTokens();
				var oSpclstockindData = sap.ui.getCore().byId("valueHelpSplStkIndDialog").getAggregation("items");
				if (oTokens.length && oSpclstockindData && oSpclstockindData.length) {
					for (var i = 0; i < oTokens.length; i++) {
						for (var j = 0; j < oSpclstockindData.length; j++) {
							if (oTokens[i].getText() === oSpclstockindData[j].getTitle()) {
								sap.ui.getCore().byId("valueHelpSplStkIndDialog").getAggregation("items")[j].setSelected(true);
							}
						}
					}
				}
				this._SpecialStockindDialog.open();
			}

		},
		_handleValueHelpSplStkIndSearch: function (oEvent) {
			var aFilters = [];
			var sQuery = oEvent.getParameter("value");
			var list = sap.ui.getCore().byId("valueHelpSplStkIndDialog");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("SpecialStock", sap.ui.model.FilterOperator.Contains, sQuery)

				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		_handleValueHelpSplStkIndConfirm: function (oEvent) {
			var aSelectedItems = oEvent.getParameter("selectedItems"),
				oMultiInput = this.byId("oSpclstockindicator");

			if (aSelectedItems && aSelectedItems.length > 0) {
				oMultiInput.setTokens([]);
				this.byId("oSpecialstockno").setTokens([]);
				this.byId("oSpecialstockno").setValue("");
				aSelectedItems.forEach(function (oItem) {
					oMultiInput.addToken(new Token({
						text: oItem.getTitle()
					}));
				});
				this._getSpecialstockNo();
			} else {
				oMultiInput.setTokens([]);
				this.byId("oSpecialstockno").setTokens([]);
				this.byId("oSpecialstockno").setValue("");
				var SpecialstockNoModel = new JSONModel([]);
				this.getView().setModel(SpecialstockNoModel, "SpecialstockNoModel");
			}

			this._SpecialStockindDialog.destroy(true);
			this._SpecialStockindDialog = undefined;
		},
		handleSpecialstockindChange: function (oevt) {
			if (this.getView().byId("oPlant").getSelectedKey() == "" || this.getView().byId("osloc").getSelectedKey() == "" || !(this.getView()
					.byId("DRS1").getFrom() && this.getView().byId("DRS1").getTo())) {
				sap.m.MessageBox.error("Please select required mandatory fields & posting date");
				this.getView().byId("oSpclstockindicator").setTokens([]);
				this.getView().byId("oSpclstockindicator").setValue("");
			} else {

				var oValue = oevt.getSource().getValue();
				var MatData3 = oevt.getSource().getModel("oStockIndModel").getData().filter(function (x) {
					return x.SpecialStock == oValue;
				});
				if (MatData3.length) {

				} else {
					if (oValue != "") {
						sap.m.MessageBox.warning("Please enter valid Special Stock Indicator");
					}
					oevt.getSource().setValue("");
					oevt.getSource().setTokens([]);

					return;
				}

				if (this.getView().byId("oSpclstockindicator").getTokens().length) {
					this.byId("oSpecialstockno").setTokens([]);
					this.byId("oSpecialstockno").setValue("");
					this._getSpecialstockNo();
				} else {
					this.byId("oSpecialstockno").setTokens([]);
					this.byId("oSpecialstockno").setValue("");
					var SpecialstockNoModel = new JSONModel([]);
					this.getView().setModel(SpecialstockNoModel, "SpecialstockNoModel");
				}
			}

		},
		_handleValueHelpSplStkIndClose: function () {
			this._SpecialStockindDialog.destroy(true);
			this._SpecialStockindDialog = undefined;
		},

		handleMateDocnoValueHelp: function (oEvent) {

			if (this.getView().byId("oPlant").getSelectedKey() == "" || this.getView().byId("osloc").getSelectedKey() == "" || !(this.getView()
					.byId("DRS1").getFrom() && this.getView().byId("DRS1").getTo())) {
				sap.m.MessageBox.error("Please select required mandatory fields & Posting date 'From' & 'To'");
			} else {
				if (!this._MaterialDocDialog) {
					this._MaterialDocDialog = sap.ui.xmlfragment(
						"reprintlabel.SIE_ASP_WM_ReprintLabel.Fragment.MaterialDocNo",
						this
					);
					this.getView().addDependent(this._MaterialDocDialog);

				}
				var oTokens = this.getView().byId("oMatedocno").getTokens();
				var MatDocNoData = sap.ui.getCore().byId("valueHelpMatDocnoDialog").getAggregation("items");
				if (oTokens.length && MatDocNoData && MatDocNoData.length) {
					for (var i = 0; i < oTokens.length; i++) {
						for (var j = 0; j < MatDocNoData.length; j++) {
							if (oTokens[i].getText() === MatDocNoData[j].getTitle()) {
								sap.ui.getCore().byId("valueHelpMatDocnoDialog").getAggregation("items")[j].setSelected(true);
							}
						}
					}

				}

				this._MaterialDocDialog.open();
			}

		},
		_handleValueHelpMatDocnoSearch: function (oEvent) {
			var aFilters = [];
			var sQuery = oEvent.getParameter("value");
			var list = sap.ui.getCore().byId("valueHelpMatDocnoDialog");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("MatDocNo", sap.ui.model.FilterOperator.Contains, sQuery)

				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		_handleValueHelpMatDocnoConfirm: function (oEvent) {
			var aSelectedItems = oEvent.getParameter("selectedItems"),
				oMultiInput = this.byId("oMatedocno");

			if (aSelectedItems && aSelectedItems.length > 0) {
				oMultiInput.setTokens([]);
				aSelectedItems.forEach(function (oItem) {
					oMultiInput.addToken(new Token({
						text: oItem.getTitle()
					}));
				});
			} else {
				oMultiInput.setTokens([]);
			}
			this._MaterialDocDialog.destroy(true);
			this._MaterialDocDialog = undefined;
		},
		handleoMatedocnoChange: function (oevt) {
			if (this.getView().byId("oPlant").getSelectedKey() == "" || this.getView().byId("osloc").getSelectedKey() == "") {
				sap.m.MessageBox.error("Please select required mandatory fields & Special Stock Indicator");
				this.getView().byId("oSpclstockindicator").setTokens([]);
				this.getView().byId("oSpclstockindicator").setValue("");

			} else {
				var oValue = oevt.getSource().getValue();
				var MatData = oevt.getSource().getModel("MaterialdocModel").getData().filter(function (x) {
					return x.MatDocNo == oValue;
				});
				if (MatData.length) {

				} else {
					if (oValue != "") {
						sap.m.MessageBox.warning("Please enter valid Material Document No.");
					}
					oevt.getSource().setValue("");
					oevt.getSource().setTokens([]);

				}
			}

		},

		oMateChange: function (oevt) {

			var oValue = oevt.getSource().getValue();
			if(isNaN(oValue)){
		sap.m.MessageBox.warning("Please enter valid Material no.");
				oevt.getSource().setValue("");
				oevt.getSource().setTokens([]);
				return;
			}
		
			var MatData1 = oevt.getSource().getModel("oMaterialModel").getData().filter(function (x) {
					return ((x.Material)*1).toString()==(oValue*1).toString();
			//	return x.Material == oValue;
			});
			if (MatData1.length) {
					oevt.getSource().setValue(MatData1[0].Material);
			} else {
				if (oValue != "") {
					sap.m.MessageBox.warning("Please enter valid Material no.");
				}
				oevt.getSource().setValue("");
				oevt.getSource().setTokens([]);

			}

		},

		_handleValueHelpMatDocnoClose: function () {
			this._MaterialDocDialog.destroy(true);
			this._MaterialDocDialog = undefined;
		},
		_getSpecialstockNo: function () {

			var oSelectPlant = this.getView().byId("oPlant").getSelectedKey();
			var oSelectSloc = this.getView().byId("osloc").getSelectedKey();
			var oSelectSpecialStockInd = this.getView().byId("oSpclstockindicator").getTokens();
			if (oSelectSpecialStockInd && oSelectSpecialStockInd.length) {
				var oSelectSpecialStockIndData = [];
				for (var i = 0; i < oSelectSpecialStockInd.length; i++) {
					oSelectSpecialStockIndData.push(oSelectSpecialStockInd[i].getText());
				}

				var value2;
				if (oSelectSpecialStockIndData.length > 1) {
					var oSelectSpecialStockInd = oSelectSpecialStockIndData.reduce(function (a, b) {

						if (value2 == undefined) {
							value2 = "SpecialStockI eq " + "'";
						} else {
							value2 = "";

						}

						return value2 + (a || a) + "' or SpecialStockI eq" + " " + "'" + b + "'";
					});
					oSelectSpecialStockInd = oSelectSpecialStockInd.replace(/''/g, "'");
				} else {
					oSelectSpecialStockInd = "SpecialStockI eq '" + oSelectSpecialStockIndData[0] + "'";
				}

			} else {
				oSelectSpecialStockInd = "SpecialStockI eq ''";
			}
			//[0].getText();

			var sTr = "Plant eq '" + oSelectPlant + "' and Sloc eq '" + oSelectSloc + "' and (" + oSelectSpecialStockInd + ")";
			this.oBusyDialog.open();
			var oBindingInfo = {
				filters: null,
				urlParameters: {
					"$filter": sTr
				},
				success: function (oData, oResponse) {
					this.oBusyDialog.close();
					var obj = {};
					var SpecialstockData = oData.results;
					for (var i = 0, len = SpecialstockData.length; i < len; i++)
						obj[SpecialstockData[i]['SpecialStockNo']] = SpecialstockData[i];
					SpecialstockData = new Array();
					for (var key in obj)
						SpecialstockData.push(obj[key]);
					var SpecialstockNoModel = new JSONModel(SpecialstockData);
					SpecialstockNoModel.setSizeLimit(SpecialstockData.length);
					this.getView().setModel(SpecialstockNoModel, "SpecialstockNoModel");
				}.bind(this),
				error: function (oError) {
					this.oBusyDialog.close();
					var SpecialstockNoModel = new JSONModel([]);
					this.getView().setModel(SpecialstockNoModel, "SpecialstockNoModel");
				}.bind(this)
			};

			this.getOwnerComponent().getModel("LABEL_REPRINT").read("/MatDocFilterSet", oBindingInfo);

		},
		handleSpecialstocknoValueHelp: function (oEvent) {

			if (this.getView().byId("oPlant").getSelectedKey() == "" || this.getView().byId("osloc").getSelectedKey() == "" || this.getView().byId(
					"oSpclstockindicator").getTokens().length == "0") {
				sap.m.MessageBox.error("Please select required mandatory fields & Speical Stock Indicator");
			} else {
				if (!this._SpecialStocknoDialog) {
					this._SpecialStocknoDialog = sap.ui.xmlfragment(
						"reprintlabel.SIE_ASP_WM_ReprintLabel.Fragment.SpecialStockno",
						this
					);
					this.getView().addDependent(this._SpecialStocknoDialog);

				}
				var oTokens = this.getView().byId("oSpecialstockno").getTokens();
				var SpecialstockNoData = sap.ui.getCore().byId("valueHelpSplstknoDialog").getAggregation("items");
				if (oTokens.length && SpecialstockNoData && SpecialstockNoData.length) {
					for (var i = 0; i < oTokens.length; i++) {
						for (var j = 0; j < SpecialstockNoData.length; j++) {
							if (oTokens[i].getText() === SpecialstockNoData[j].getTitle()) {
								sap.ui.getCore().byId("valueHelpSplstknoDialog").getAggregation("items")[j].setSelected(true);
							}
						}
					}

				}

				this._SpecialStocknoDialog.open();
			}

		},
		_handleValueHelpSplstknoSearch: function (oEvent) {
			var aFilters = [];
			var sQuery = oEvent.getParameter("value");
			var list = sap.ui.getCore().byId("valueHelpSplstknoDialog");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("SpecialStockNo", sap.ui.model.FilterOperator.Contains, sQuery)

				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},
		_handleValueHelpSplstknoConfirm: function (oEvent) {
			var aSelectedItems = oEvent.getParameter("selectedItems"),
				oMultiInput = this.byId("oSpecialstockno");

			if (aSelectedItems && aSelectedItems.length > 0) {
				this.getView().byId("oSpecialstockno").setTokens([]);
				aSelectedItems.forEach(function (oItem) {
					oMultiInput.addToken(new Token({
						text: oItem.getTitle()
					}));
				});
			} else {
				this.getView().byId("oSpecialstockno").setTokens([]);

			}
			this._SpecialStocknoDialog.destroy(true);
			this._SpecialStocknoDialog = undefined;
		},
		handleoSpecialstocknoChange: function (oevt) {
			if (this.getView().byId("oPlant").getSelectedKey() == "" || this.getView().byId("osloc").getSelectedKey() == "" || this.getView().byId(
					"oSpclstockindicator").getTokens().length == "0") {
				sap.m.MessageBox.error("Please select required mandatory fields & SpecialStock Indicator");
			} else {

				var oValue = oevt.getSource().getValue();
				var MatData4 = oevt.getSource().getModel("SpecialstockNoModel").getData().filter(function (x) {
					return x.SpecialStockNo == oValue;
				});
				if (MatData4.length) {

				} else {
					if (oValue != "") {
						sap.m.MessageBox.warning("Please enter valid Special Stock No.");
					}
					oevt.getSource().setValue("");
					oevt.getSource().setTokens([]);

					return;
				}
			}
		},
		_handleValueHelpSplstknoClose: function () {
			this._SpecialStocknoDialog.destroy(true);
			this._SpecialStocknoDialog = undefined;
		},

		onFilter: function () {

			var oSelectedPlant = this.getView().byId("oPlant").getSelectedKey();
			var oSelectedSloc = this.getView().byId("osloc").getSelectedKey();

			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			// specialstockIndicator start
			var oSelectSpecialStockInd = this.getView().byId("oSpclstockindicator").getTokens();

			if (oSelectSpecialStockInd && oSelectSpecialStockInd.length) {
				var oSelectSpecialStockIndData = [];
				for (var i = 0; i < oSelectSpecialStockInd.length; i++) {
					oSelectSpecialStockIndData.push(oSelectSpecialStockInd[i].getText());
				}

				var value2;
				if (oSelectSpecialStockIndData.length > 1) {
					var oSelectSpecialStockInd = oSelectSpecialStockIndData.reduce(function (a, b) {

						if (value2 == undefined) {
							value2 = "SpecialStockI eq " + "'";
						} else {
							value2 = "";

						}

						return value2 + (a || a) + "' or SpecialStockI eq" + " " + "'" + b + "'";
					});
					oSelectSpecialStockInd = oSelectSpecialStockInd.replace(/''/g, "'");
				} else {
					oSelectSpecialStockInd = "SpecialStockI eq '" + oSelectSpecialStockIndData[0] + "'";
				}

			} else {
				oSelectSpecialStockInd = "";
			}
			// specialstockIndicator end

			// Batchno start
			var oSelectBatchNoI = this.getView().byId("oBatchno").getTokens();
			if (oSelectBatchNoI && oSelectBatchNoI.length) {
				var oSelectBatchNoData = [];
				for (var j = 0; j < oSelectBatchNoI.length; j++) {
					oSelectBatchNoData.push(oSelectBatchNoI[j].getText());
				}

				var value3;
				if (oSelectBatchNoData.length > 1) {
					var oSelectBatchNoI = oSelectBatchNoData.reduce(function (a, b) {

						if (value3 == undefined) {
							value3 = "BatchNoI eq " + "'";
						} else {
							value3 = "";

						}

						return value3 + (a || a) + "' or BatchNoI eq" + " " + "'" + b + "'";
					});
					oSelectBatchNoI = oSelectBatchNoI.replace(/''/g, "'");
				} else {
					oSelectBatchNoI = "BatchNoI eq '" + oSelectBatchNoData[0] + "'";
				}

			} else {
				oSelectBatchNoI = "";
			}
			// Batchno end

			// stock no start
			var oSelectSpecialStockno = this.getView().byId("oSpecialstockno").getTokens();
			if (oSelectSpecialStockno && oSelectSpecialStockno.length) {
				var oSelectSpecialStocknoData = [];
				for (var k = 0; k < oSelectSpecialStockno.length; k++) {
					oSelectSpecialStocknoData.push(oSelectSpecialStockno[k].getText());
				}

				var value4;
				if (oSelectSpecialStocknoData.length > 1) {
					var oSelectSpecialStockno = oSelectSpecialStocknoData.reduce(function (a, b) {

						if (value4 == undefined) {
							value4 = "SpecialStockNoI eq " + "'";
						} else {
							value4 = "";

						}

						return value4 + (a || a) + "' or SpecialStockNoI eq" + " " + "'" + b + "'";
					});
					oSelectSpecialStockno = oSelectSpecialStockno.replace(/''/g, "'");
				} else {
					oSelectSpecialStockno = "SpecialStockNoI eq '" + oSelectSpecialStocknoData[0] + "'";
				}

			} else {
				oSelectSpecialStockno = "";
			}
			// stock no end

			// Matdoc no start
			var oSelectoMatedocno = this.getView().byId("oMatedocno").getTokens();

			if (oSelectoMatedocno && oSelectoMatedocno.length) {
				var oSelectoMatedocnoData = [];
				for (var m = 0; m < oSelectoMatedocno.length; m++) {
					oSelectoMatedocnoData.push(oSelectoMatedocno[m].getText());
				}

				var value5;
				if (oSelectoMatedocnoData.length > 1) {
					var oSelectoMatedocno = oSelectoMatedocnoData.reduce(function (a, b) {

						if (value5 == undefined) {
							value5 = "MatDocNoI eq " + "'";
						} else {
							value5 = "";

						}

						return value5 + (a || a) + "' or MatDocNoI eq" + " " + "'" + b + "'";
					});
					oSelectoMatedocno = oSelectoMatedocno.replace(/''/g, "'");
				} else {
					oSelectoMatedocno = "MatDocNoI eq '" + oSelectoMatedocnoData[0] + "'";
				}

			} else {
				oSelectoMatedocno = "";
			}

			// Matdoc no end
			// Material no start
			var oSelectMaterialno = this.getView().byId("oMaterialno").getTokens();
			if (oSelectMaterialno && oSelectMaterialno.length) {
				var oSelectMaterialnoData = [];
				for (var n = 0; n < oSelectMaterialno.length; n++) {
					oSelectMaterialnoData.push(oSelectMaterialno[n].getText());
				}

				var value6;
				if (oSelectMaterialnoData.length > 1) {
					var oSelectMaterialno = oSelectMaterialnoData.reduce(function (a, b) {

						if (value6 == undefined) {
							value6 = "MaterialI eq " + "'";
						} else {
							value6 = "";

						}

						return value6 + (a || a) + "' or MaterialI eq" + " " + "'" + b + "'";
					});
					oSelectMaterialno = oSelectMaterialno.replace(/''/g, "'");
				} else {
					oSelectMaterialno = "MaterialI eq '" + oSelectMaterialnoData[0] + "'";
				}

			} else {
				oSelectMaterialno = "";
			}
			// Material no end
			// Posting date  start

			if (oSelectedPlant && oSelectedSloc && (oSelectSpecialStockInd || oSelectoMatedocno || oSelectSpecialStockno || (this.getView().byId(
					"DRS1").getFrom() && this.getView().byId("DRS1").getTo()))) {
				var FromDate = this.getView().byId("DRS1").getFrom();
				var ToDate = this.getView().byId("DRS1").getTo();
				if (FromDate && ToDate) {
					FromDate = dateFormat.format(new Date(FromDate));
					ToDate = dateFormat.format(new Date(ToDate));
				} else {
					FromDate = "";
					ToDate = "";
				}
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("ProductLabelReprintItems", {
					Plant: oSelectedPlant,
					Sloc: oSelectedSloc,
					FromDate: FromDate,
					ToDate: ToDate,
					Matedocno: oSelectoMatedocno,
					SpecialStockno: oSelectSpecialStockno,
					SpecialStockInd: oSelectSpecialStockInd,
					BatchNo: oSelectBatchNoI,
					MaterialNo: oSelectMaterialno

				});
				// Posting date  end
			} else {
				if (oSelectedPlant && oSelectedSloc) {
					sap.m.MessageBox.warning(
						"Please select 'Posting date' or 'Material doc.no' or 'special stock indicator' or 'special stock indicator'");
				} else {
					sap.m.MessageBox.error("Please select required mandatory fields");
				}
			}

		},
		onClear: function () {
			this.getView().byId("oMaterialno").setTokens([]);
			this.getView().byId("oMaterialno").setValue("");
			var oMaterialModel = new JSONModel([]);
			this.getView().setModel(oMaterialModel, "oMaterialModel");
			this.getView().byId("oBatchno").setTokens([]);
			this.getView().byId("oBatchno").setValue("");
			var oBatcNoModel = new JSONModel([]);
			this.getView().setModel(oBatcNoModel, "oBatcNoModel");
			this.getView().byId("oSpclstockindicator").setTokens([]);
			this.getView().byId("oSpclstockindicator").setValue("");
			var oStockIndModel = new JSONModel([]);
			this.getView().setModel(oStockIndModel, "oStockIndModel");
			this.getView().byId("oSpecialstockno").setTokens([]);
			this.getView().byId("oSpecialstockno").setValue("");
			var SpecialstockNoModel = new JSONModel([]);
			this.getView().setModel(SpecialstockNoModel, "SpecialstockNoModel");
			this.getView().byId("oMatedocno").setTokens([]);
			this.getView().byId("oMatedocno").setValue("");
			var MaterialdocModel = new JSONModel([]);
			this.getView().setModel(MaterialdocModel, "MaterialdocModel");

			this.getView().byId("oPlant").setSelectedKey("");
			var oPlantModel = new JSONModel([]);
			this.getView().setModel(oPlantModel, "oPlantModel");

			this.getView().byId("osloc").setSelectedKey("");
			var oSlocModel = new JSONModel([]);
			this.getView().setModel(oSlocModel, "oSlocModel");
			var oModel = new JSONModel(),
				dateFrom = new Date(),
				dateTo = new Date();

			dateTo.setDate(dateTo.getDate() + 30);

			dateFrom.setUTCDate(dateFrom.getDate() - 1);

			dateFrom.setUTCMonth(dateFrom.getMonth());
			dateFrom.setUTCFullYear(dateFrom.getFullYear());

			dateTo.setUTCDate(dateTo.getDate() - 1);
			dateTo.setUTCMonth(dateTo.getMonth());
			dateTo.setUTCFullYear(dateTo.getFullYear());

			oModel.setData({
				delimiterDRS1: "@",
				dateValueDRS1: dateFrom,
				secondDateValueDRS1: dateTo,
				dateFormatDRS1: "dd.MM.yyyy"
			});

			this.getView().setModel(oModel, "oDRSModel");

		}

	});
});