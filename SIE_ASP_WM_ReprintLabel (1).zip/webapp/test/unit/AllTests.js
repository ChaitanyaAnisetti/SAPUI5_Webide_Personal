sap.ui.define([
	"reprintlabel/SIE_ASP_WM_ReprintLabel/test/unit/controller/ProductLabelReprintMain.controller"
], function () {
	"use strict";
});