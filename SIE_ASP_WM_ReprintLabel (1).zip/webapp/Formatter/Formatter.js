sap.ui.define(function () {
	var Formatter = {

		MatNoparse: function (Material) {

			if (Material) {
				return (Material * 1).toString();
			} else {
				return "";
			}

		},
		/*PostingDate: function (PostingDate) {

			if (PostingDate) {
			
				var x = PostingDate.slice(0, 4);
				var y = PostingDate.slice(4, 6);
				var z = PostingDate.slice(6, 8);
				var a = z + "." + y + "." + x;
				return a;

			} else {
				return "";
			}

		}*/

	};

	return Formatter;
}, true);