function initModel() {
	var sUrl = "/FID_Client_700/sap/opu/odata/SIE/ASP_WM_LABEL_REPRINT_SRV/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}