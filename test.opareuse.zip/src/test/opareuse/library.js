/*!
 * ${copyright}
 */

/**
 * Initialization Code and shared classes of library opareuse.
 */
sap.ui.define(["jquery.sap.global",
		"sap/ui/core/library"
	], // library dependency
	function(jQuery) {

		"use strict";

		/**
		 * 
		 *
		 * @namespace
		 * @name opareuse
		 * @author SAP SE
		 * @version ${version}
		 * @public
		 */
	 	var test = {};
		// delegate further initialization of this library to the Core
		sap.ui.getCore().initLibrary({
			name: "test.opareuse",
			version: "${version}",
			dependencies: ["sap.ui.core"],
			types: [],
			interfaces: [],
			controls: [],
			elements: []
		});

		return test.opareuse;

	}, /* bExport= */ false);