/**
 * OPA Actions & Assertions for control sap.m.Title
 * @class CommonTitle
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"./CommonUtil"
], function(Opa5, PropertyStrictEquals, CommonUtil) {
	"use strict";

	var mControlType = "sap.m.Title";

	var CommonTitle = {};
	CommonTitle.actions = {};
	CommonTitle.assertions = new Opa5({

		/** Assertions **/

		/**
		 * Verify that a Title is visible, that is identified by its ID.
		 * @public
		 * @param {map/string}        		oOptionsOrID         			ID of the Title or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrID.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.id]				ID of the sap.m.Title control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonTitle
		 */
		iShouldSeeTitleByID: function(oOptionsOrID) {
			var oOptions = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["id"])) {
				return this.iShouldSeeControlByID(oOptions);
			}
		},

		/**
		 * Verify that a Title is visible, that is identified by its text.
		 * @public
		 * @param {map/string}     			oOptionsOrText         			Text of the Title control or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrText.viewName]		Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrText.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrText.text]			Text of the sap.m.Title control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonTitle
		 */
		iShouldSeeTitleByText: function(oOptionsOrText) {
			var oOptions = CommonUtil.resolveStringOrAttribute(oOptionsOrText, "text");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["text"])) {
				oOptions = CommonUtil.addOption(oOptions, {
					controlType: mControlType
				}, false);
				oOptions.matchers = [new PropertyStrictEquals({
					name: "text",
					value: oOptions.text
				})];
				return this.iShouldSeeControlByControlType(oOptions);
			}
		},

		/**
		 * Verify that a title is visible, that is identified by its i18n-key.
		 * @public
		 * @param {map}         			oOptionsOrKey         		Option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrKey.viewName]	Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrKey.viewNamespace]Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrKey.key]			I18n-key of the sap.m.Title control
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonTitle
		 */
		iShouldSeeTitleByI18nKey: function(oOptionsOrKey) {
			var options = CommonUtil.resolveStringOrAttribute((oOptionsOrKey), "key");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["key"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				return this.iShouldSeeControlByI18nKey(options);
			}
		}
	});

	return CommonTitle;
});