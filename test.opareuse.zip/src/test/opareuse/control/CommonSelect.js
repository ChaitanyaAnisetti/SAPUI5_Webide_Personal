/**
 * OPA Actions & Assertions for control sap.m.Select
 * @class CommonSelect
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"./CommonUtil",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/Ancestor"
], function (Opa5, CommonUtil, Press, Properties, Ancestor) {
	"use strict";

	var CommonSelect = {};
	CommonSelect.actions = new Opa5({

		/** Actions **/

		/**
		 * Selects an item by key in a Select, that is identified by its ID.
		 * @public
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the sap.m.Select control
		 * @param {string}       [oOptions.key]						Key of the item to be selected
		 * @return {jQuery.promise}									A promise that gets resolved on success
		 * @memberof CommonSelect
		 */
		iSelectKeyInSelectByID: function (oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "key"])) {
				var sSelector = "with the id \"" + options.id + "\"";
				return this.waitFor({
					id: options.id,
					viewName: this.viewName,
					viewNamespace: this.viewNamespace,
					actions: new Press(),
					success: function (oSelect) {
						this.waitFor({
							controlType: "sap.ui.core.Item",
							matchers: [
								new Ancestor(oSelect),
								new Properties({
									key: options.key
								})
							],
							actions: new Press(),
							errorMessage: "Cannot select " + options.key + " from " + options.id
						});
					},
					errorMessage: "Was not able to find the control " + sSelector
				});
			}
		},

		/**
		 * Selects an item in a Select, that is identified by its ID.
		 * @public
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewName]				Namespace (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the sap.m.Select control
		 * @param {string}       [oOptions.item]					Item to be selected
		 * @return {jQuery.promise}									A promise that gets resolved on success
		 * @memberof CommonSelect
		 */
		iSelectItemInSelectByID: function (oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "item"])) {
				var sSelector = "with the id \"" + options.id + "\"";
				return this.waitFor({
					id: options.id,
					viewName: this.viewName,
					viewNamespace: options.viewNamespace,
					actions: new Press(),
					success: function (oSelect) {
						this.waitFor({
							controlType: "sap.ui.core.Item",
							matchers: [
								new Ancestor(oSelect),
								new Properties({
									text: options.item
								})
							],
							actions: new Press(),
							errorMessage: "Cannot select " + options.key + " from " + options.id
						});
					},
					errorMessage: "Was not able to find the control " + sSelector
				});
			}
		}
	});
	CommonSelect.assertions = new Opa5({

		/** Assertions **/

		/**
		 * Verify that a Select is visible, that is identified by its ID.
		 * @public
		 * @param {string/map}         		oOptionsOrID         		ID of the Select or option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]    Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.m.Select control
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonSelect
		 */
		iShouldSeeSelectByID: function (oOptionsOrID) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id"])) {
				return this.iShouldSeeControlByID(options);
			}
		},

		/**
		 * Verify that the given key is selected in a sap.m.Select, that is identified by its ID.
		 * @public
		 * @param {string/map}         		oOptions	         		ID of the sap.m.Select or option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]    Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.m.Select control
		 * @param {string}      			[oOptions.key]				Expected key of the sap.m.Select control
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonSelect
		 */
		iShouldSeeKeyInSelectByID: function (oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "key"])) {
				options.attributeName = "selectedKey";
				options.attributeValue = options.key;
				options.fGetAttribute = function (oControl) {
					return oControl.getSelectedKey();
				};
				return this.iShouldSeeAttributeInControlByID(options);
			}
		},

		/**
		 * Verify that a passed value is selected in a sap.m.Select, that is identified by its ID.
		 * @public
		 * @param {string/map}         		oOptions	         		ID of the sap.m.Select or option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]    Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.m.Select control
		 * @param {string}      			[oOptions.value]			Expected Value of the sap.m.Select control
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonSelect
		 */
		iShouldSeeValueInSelectByID: function (oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "value"])) {
				options.attributeName = "selectedItem";
				options.attributeValue = options.value;
				options.fGetAttribute = function (oControl) {
					return oControl.getSelectedItem().getText();
				};
				return this.iShouldSeeAttributeInControlByID(options);
			}
		}

	});

	return CommonSelect;
});