/**
 * OPA Actions & Assertions for control sap.m.CommonLink
 * @class CommonLink
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/I18NText",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"./CommonUtil"
], function(Opa5, Press, I18NText, PropertyStrictEquals, CommonUtil) {
	"use strict";

	var mControlType = "sap.m.Link";

	var CommonLink = {};
	CommonLink.actions = new Opa5({
		/** Actions **/

		/**
		 * Press a Link control, that is identified by its ID.
		 * @public 
		 * @param {map/string}   oOptionsOrID         				ID of the Link or option map containing any of the following properties:
		 * @param {string}       [oOptionsOrID.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptionsOrID.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}       [oOptionsOrID.id]					ID of the sap.m.Link control
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonLink
		 */
		iPressLinkByID: function(oOptionsOrID) {
			var oOptions = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["id"])) {
				oOptions.actions = new Press();
				return this.iDoActionByID(oOptions);
			}
		},

		/**
		 * Press a Link control, that is identified by its text.
		 * @public 
		 * @param {map/string}   oOptionsOrText         			Text of the Link or option map containing any of the following properties:
		 * @param {string}       [oOptionsOrText.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptionsOrText.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}       [oOptionsOrText.text]				Text of the sap.m.Link
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonLink
		 */
		iPressLinkByText: function(oOptionsOrText) {
			var oOptions = CommonUtil.resolveStringOrAttribute(oOptionsOrText, "text");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["text"])) {
				oOptions = CommonUtil.addOption(oOptions, {
					controlType: mControlType
				}, false);
				oOptions.actions = new Press();
				return this.iDoActionByControlType(oOptions);
			}
		},

		/**
		 * Press a Link control, that is identified by its i18n-key.
		 * @public 
		 * @param {map/string}   oOptionsOrKey         			Text of the Link or option map containing any of the following properties:
		 * @param {string}      [oOptionsOrKey.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      [oOptionsOrKey.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}      [oOptionsOrKey.key]					I18n-key of the sap.m.Link control
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonLink
		 */
		iPressLinkByI18nKey: function(oOptionsOrKey) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrKey, "key");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["key"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				var properties = {
					key: options.key
				};
				CommonUtil.addOption(properties, {
					propertyName: options.propertyName || "text", //use "text" as default propertyName
					modelName: options.modelName,
					parameters: options.parameters
				});
				CommonUtil.addMatchers(options, new I18NText(properties));
				options.actions = new Press();
				return this.iDoActionByControlType(options);
			}
		}
	});
	CommonLink.assertions = new Opa5({
		/** Assertions **/

		/**
		 * Verify that a Link is visible, that is identified by its ID.
		 * @public 
		 * @param {map/string}    			oOptionsOrID         			Option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrID.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}                  [oOptionsOrID.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.id]				ID of the sap.m.Link control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonLink
		 */
		iShouldSeeLinkByID: function(oOptionsOrID) {
			var oOptions = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["id"])) {
				return this.iShouldSeeControlByID(oOptions);
			}
		},

		/**
		 * Verify that a Link is visible, that is identified by its text.
		 * @public 
		 * @param {map/string}    			oOptionsOrText         			Text of the Link or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrText.viewName]		Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrText.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrText.text]			Text of the sap.m.Link control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonLink
		 */
		iShouldSeeLinkByText: function(oOptionsOrText) {
			var oOptions = CommonUtil.resolveStringOrAttribute(oOptionsOrText, "text");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["text"])) {
				oOptions = CommonUtil.addOption(oOptions, {
					controlType: mControlType
				}, false);
				CommonUtil.addMatchers(oOptions, [new PropertyStrictEquals({
					name: "text",
					value: oOptions.text
				})]);
				return this.iShouldSeeControlByControlType(oOptions);
			}
		},

		/**
		 * Verify that a link is visible, that is identified by its i18n-key.
		 * @public
		 * @param {map}         			oOptionsOrKey         		Option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrKey.viewName]	Name (id) of the surrounding view (optional)
		 * @param {string}                  [oOptionsOrKey.viewNamespace]Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrKey.key]			I18n-key of the sap.m.Link control
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonLink
		 */
		iShouldSeeLinkByI18nKey: function(oOptionsOrKey) {
			var options = CommonUtil.resolveStringOrAttribute((oOptionsOrKey), "key");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["key"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				return this.iShouldSeeControlByI18nKey(options);
			}
		}
	});

	return CommonLink;
});