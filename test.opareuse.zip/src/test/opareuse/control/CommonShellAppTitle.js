/**
 * OPA Actions & Assertions for control sap.ushell.ui.shell.ShellAppTitle
 * @class CommonShellAppTitle
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"./CommonUtil"
], function(Opa5, CommonUtil) {
	"use strict";

	var mControlType = "sap.ushell.ui.shell.ShellAppTitle";

	var CommonShellAppTitle = {};
	CommonShellAppTitle.actions = {};
	CommonShellAppTitle.assertions = new Opa5({

		/** Assertions **/

		/**
		 * Verify that a ShellAppTitle is visible, that is identified by its text.
		 * @public 
		 * @param {map/string}        		oOptionsOrText         			Text of the Shell App Title or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrText.viewName]		Name (id) of the surrounding view (optional)
		 * @param {string}                  [oOptionsOrText.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrText.text]			Text of the sap.ushell.ui.shell.ShellAppTitle control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonShellAppTitle
		 */
		iShouldSeeAppTitleByText: function(oOptionsOrText) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrText, "text");
			options.viewName = "";
			options = CommonUtil.addOption(options, {
				controlType: mControlType
			}, false);
			options = CommonUtil.addOption(options, {
				id: "shellAppTitle"
			}, false);

			return this.iShouldSeeControlByText(options);
		}
	});

	return CommonShellAppTitle;
});