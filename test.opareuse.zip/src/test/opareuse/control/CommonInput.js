/**
 * OPA Actions & Assertions for control sap.m.Input
 * @class CommonInput
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"./CommonUtil"
], function(Opa5, CommonUtil) {
	"use strict";

	var mControlType = "sap.m.Input";

	var CommonInput = {};
	CommonInput.actions = new Opa5({
		/** Actions **/

		/**
		 * Enters a value in a sap.m.Input control, that is identified by its ID.
		 * @public 
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the sap.m.Input
		 * @param {string}       [oOptions.value]					Value to be entered
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonInput
		 */
		iEnterValueInInputByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "value"])) {
				return this.iEnterValueInInputBaseByID(options);
			}
		},

		/**
		 * Enters a new value in a sap.m.Input control, that is identified by its current value.
		 * @public 
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the sap.m.Input
		 * @param {string}       [oOptions.value]					Current Value of the sap.m.Input
		 * @param {string}       [oOptions.newValue]				New Value to be entered 
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonInput
		 */
		iEnterValueInInputByValue: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["value", "value"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				return this.iEnterValueInInputBaseByValue(options);
			}
		}
		});
		CommonInput.assertions = new Opa5({ 
		/** Assertions **/

		/**
		 * Verify that an Input control is visible, that is identified by its ID.
		 * @public 
		 * @param {map/string}     			oOptionsOrID         			Option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrID.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}                  [oOptionsOrID.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.id]				ID of the sap.m.Input control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonInput
		 */
		iShouldSeeInputByID: function(oOptionsOrID) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id"])) {
				return this.iShouldSeeInputBaseByID(options);
			}
		},

		/**
		 * Verify that an Input control is visible, that is identified by its value.
		 * @public 
		 * @param {map/string}     			oOptionsOrValue         		Option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrValue.viewName]		Name (id) of the surrounding view (optional)
		 * @param {string}                  [oOptionsOrValue.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrValue.value] 		Value of the input field
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonInput
		 */
		iShouldSeeInputByValue: function(oOptionsOrValue) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrValue, "value");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["value"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				return this.iShouldSeeInputBaseByValue(options);
			}
		},

		/**
		 * Verify that a passed value is contained in sap.m.Input, that is identified by its ID
		 * @public 
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.m.Input control
		 * @param {string}      			[oOptions.value]			Expected Value of the sap.m.Input control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonInput
		 */
		iShouldSeeValueInInputByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "value"])) {
				return this.iShouldSeeValueInInputBaseByID(options);
			}
		}
	});

	return CommonInput;
});