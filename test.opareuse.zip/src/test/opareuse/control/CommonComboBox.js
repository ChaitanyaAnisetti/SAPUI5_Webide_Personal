/**
 * OPA Actions & Assertions for control sap.m.ComboBox
 * @class CommonComboBox
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"./CommonUtil",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/Ancestor"
], function (Opa5, CommonUtil, Press, Properties, Ancestor) {
	"use strict";

	var CommonComboBox = {};
	CommonComboBox.actions = new Opa5({

		/** Actions **/

		/**
		 * Selects an item by key in a ComboBox, that is identified by its ID.
		 * @public
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the sap.m.ComboBox control
		 * @param {string}       [oOptions.key]						Key of the item to be selected
		 * @return {jQuery.promise}									A promise that gets resolved on success
		 * @memberof CommonComboBox
		 */
		iSelectKeyInComboBoxByID: function (oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "key"])) {
				var sSelector = "with the id \"" + options.id + "\"";
				return this.waitFor({
					id: options.id,
					viewName: this.viewName,
					viewNamespace: this.viewNamespace,
					actions: new Press(),
					success: function (oCombobox) {
						// WARNING: sap.m.StandardListItem has no key field. There is a special logic inside of 
						// ComboBox to convert the sap.ui.core.Item into sap.m.StandardListItem objects.
						// To support old scenarios the following method getItemByKey and compare of title is needed 
						var oItem = oCombobox.getItemByKey(options.key);
						this.waitFor({
							controlType: "sap.m.StandardListItem",
							matchers: [
								new Ancestor(oCombobox),
								new Properties({
									title: oItem.getText()
								})
							],
							actions: new Press(),
							errorMessage: "Cannot select " + options.key + " from " + options.id
						});
					},
					errorMessage: "Was not able to find the control " + sSelector
				});
			}
		},

		/**
		 * Selects an item in a combobox, that is identified by its ID.
		 * @public
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewName]				Namespace (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the combobox
		 * @param {string}       [oOptions.item]					Item to be selected
		 * @return {jQuery.promise}									A promise that gets resolved on success
		 * @memberof CommonComboBox
		 */
		iSelectItemInComboBoxByID: function (oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "item"])) {
				var sSelector = "with the id \"" + options.id + "\"";
				return this.waitFor({
					id: options.id,
					viewName: this.viewName,
					viewNamespace: options.viewNamespace,
					actions: new Press(),
					success: function (oCombobox) {
						this.waitFor({
							controlType: "sap.m.StandardListItem",
							matchers: [
								new Ancestor(oCombobox),
								new Properties({
									title: options.item
								})
							],
							actions: new Press(),
							errorMessage: "Cannot select " + options.key + " from " + options.id
						});
					},
					errorMessage: "Was not able to find the control " + sSelector
				});
			}
		}
	});
	CommonComboBox.assertions = new Opa5({

		/** Assertions **/

		/**
		 * Verify that a combobox is visible, that is identified by its ID.
		 * @public
		 * @param {string/map}         		oOptionsOrID         		ID of the ComboBox or option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the combobox
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonComboBox
		 */
		iShouldSeeComboBoxByID: function (oOptionsOrID) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id"])) {
				return this.iShouldSeeControlByID(options);
			}
		}
	});

	return CommonComboBox;
});