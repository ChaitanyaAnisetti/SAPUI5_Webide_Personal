/**
 * OPA Actions & Assertions for control sap.m.Button
 * @class CommonButton
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/I18NText",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"./CommonUtil"
], function (Opa5, Press, I18NText, PropertyStrictEquals, CommonUtil) {
	"use strict";

	var CommonNavigation = {};

	CommonNavigation.actions = new Opa5({
		/** Actions **/

	});

	CommonNavigation.assertions = new Opa5({
		/** Assertions **/

		/**
		 * Verify that a dummy page is shown with the correct intent and parameters
		 * @public
		 * @param {string/map}         		oOptions         				Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.semanticObject]		Semantic Object of the navigation target
		 * @param {string}      			[oOptions.action]				Action of the navigation target
		 * @param {map}      				[oOptions.params]				Map containing navigation params, e.g. params: {id: "A-1234", mode: "display"}
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonButton
		 */
		iShouldSeeAppByIntentAndParameters: function (oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["semanticObject", "action"])) {
				return this.waitFor({
					check: function () {
						try {
							var oParsedHash = Opa5.getWindow().sap.ushell.Container.getService("URLParsing")
								.parseShellHash(Opa5.getWindow().document.location.hash);
							return (oParsedHash.semanticObject === options.semanticObject);
						} catch (e) {
							var sHash = (Opa5 && Opa5.getWindow() && Opa5.getWindow().document) ? Opa5.getWindow().document.location.hash : "";
							throw new Error("Exception when parsing hash: " + sHash + " with error: " + e.message);
						}
					},
					success: function () {
						var oParsedHash = Opa5.getWindow().sap.ushell.Container.getService("URLParsing")
							.parseShellHash(Opa5.getWindow().document.location.hash);
						Opa5.assert.strictEqual(oParsedHash.semanticObject, options.semanticObject, "The hash semantic object is ok");
						Opa5.assert.strictEqual(oParsedHash.action, options.action, "The hash action is ok");
						for (var key in options.params) {
							var par = options.params[key];
							Opa5.assert.strictEqual(oParsedHash.params[key][0], par, "Param '" + key + "' is ok");
						}
					},
					error: function () {
						var sHash = Opa5.getWindow().document.location.hash;
						Opa5.assert.ok(false, "Current hash value: " + sHash);
						Opa5.assert.ok(false, "Expected semantic object: " + options.semanticObject);
						Opa5.assert.ok(false, "Expected action: " + options.action);
					}
				});
			}
		}
	});

	return CommonNavigation;
});