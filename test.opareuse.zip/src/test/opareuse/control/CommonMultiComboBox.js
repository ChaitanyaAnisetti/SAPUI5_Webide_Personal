/**
 * OPA Actions & Assertions for control sap.m.MultiComboBox
 * @class CommonMultiComboBox
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"./CommonUtil"
], function(Opa5, CommonUtil) {
	"use strict";

	var CommonMultiComboBox = {};
	CommonMultiComboBox.actions = new Opa5({

		/** Actions **/
		/**
		 * Select the given keys in a sap.m.MultiComboBox, that is identified by its ID.
		 * @public
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the sap.m.ComboBox control
		 * @param {string[]}     [oOptions.keys]					Array of keys of the items to be selected
		 * @return {jQuery.promise}									A promise that gets resolved on success
		 * @memberof CommonMultiComboBox
		 */
		iSelectKeysInMultiComboBoxByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "keys"])) {
				if (!$.isArray(options.keys)) {
					options.keys = options.keys.split(",");
				}
				var sSelector = "with the id \"" + options.id + "\" and keys " + options.keys;
				return this.waitFor({
					id: options.id,
					viewName: this.viewName,
					viewNamespace: options.viewNamespace,
					success: function(oMultiCombobox) {
						if (oMultiCombobox) {
							oMultiCombobox.setSelectedKeys(options.keys);
						}
					},
					errorMessage: "Was not able to find the control " + sSelector
				});
			}
		}

	});
	CommonMultiComboBox.assertions = new Opa5({

		/** Assertions **/

		/**
		 * Verify that a sap.m.MultiComboBox is visible, that is identified by its ID.
		 * @public
		 * @param {string/map}         		oOptionsOrID         		ID of the sap.m.MultiComboBox or option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.m.MultiComboBox
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonMultiComboBox
		 */
		iShouldSeeMultiComboBoxByID: function(oOptionsOrID) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id"])) {
				return this.iShouldSeeControlByID(options);
			}
		},
		
		/**
		 * Verify that the given keys are selected in a sap.m.MultiComboBox, that is identified by its ID.
		 * @public
		 * @param {string/map}         		oOptions	         		ID of the sap.m.MultiComboBox or option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]    Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.m.MultiComboBox
		 * @param {string[]}      			[oOptions.keys]				Array of keys of the items to be selected
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonMultiComboBox
		 */
		iShouldSeeKeysInMultiComboBoxByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "keys"])) {
				if (!$.isArray(options.keys)) {
					options.keys = options.keys.split(",");
				}
				options.keys.sort();
				options.attributeName = "selectedKeys";
				options.attributeValue = options.keys;
				options.fGetAttribute = function(oControl) {
					return oControl.getSelectedKeys().sort();
				};                         
				return this.iShouldSeeAttributeInControlByID(options);
			}
		}
	});

	return CommonMultiComboBox;
});