/**
 * OPA Actions & Assertions for control sap.ushell.ui.shell.ShellHeadItem
 * @class CommonShellHeadItem
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"./CommonUtil"
], function(Opa5, Press, PropertyStrictEquals) {
	"use strict";

	var mControlType = "sap.ushell.ui.shell.ShellHeadItem";

	var CommonShellHeadItem = {};
	CommonShellHeadItem.actions = new Opa5({

		/**
		 * Presses the Back button in the Shell Header
		 * @return {jQuery.promise}							A promise that gets resolved on success
		 * @memberof CommonShellHeadItem
		 */
		iPressBackButton: function(oOptions) {
			var options = oOptions || {};
			options.viewName = "";
			options.controlType = mControlType;
			options.matchers = [new PropertyStrictEquals({
				name: "id",
				value: "backBtn"
			})];
			options.actions = new Press();
			return this.iDoActionByControlType(options);
		},

		/**
		 * Presses the Home button in the Shell Header
		 * @return {jQuery.promise}							A promise that gets resolved on success
		 * @memberof CommonShellHeadItem
		 */
		iPressHomeButton: function(oOptions) {
			var options = oOptions || {};
			options.viewName = "";
			options.controlType = mControlType;
			options.matchers = [new PropertyStrictEquals({
				name: "id",
				value: "homeBtn"
			})];
			options.actions = new Press();
			return this.iDoActionByControlType(options);
		},

		/**
		 * Presses the Me button in the Shell Header
		 * @return {jQuery.promise}							A promise that gets resolved on success
		 * @memberof CommonShellHeadItem
		 */
		iPressMeButton: function(oOptions) {
			var options = oOptions || {};
			options.viewName = "";
			options.controlType = mControlType;
			options.matchers = [new PropertyStrictEquals({
				name: "id",
				value: "meAreaHeaderButton"
			})];
			options.id = "meAreaHeaderButton";
			options.actions = new Press();
			return this.iDoActionByID(options);
		},

		/**
		 * Presses the Search button in the Shell Header
		 * @return {jQuery.promise}							A promise that gets resolved on success
		 * @memberof CommonShellHeadItem
		 */
		iPressSearchButton: function(oOptions) {
			var options = oOptions || {};
			options.viewName = "";
			options.controlType = mControlType;
			options.matchers = [new PropertyStrictEquals({
				name: "id",
				value: "sf"
			})];
			options.actions = new Press();
			return this.iDoActionByControlType(options);
		}
	});
	CommonShellHeadItem.assertions = {};

	return CommonShellHeadItem;
});