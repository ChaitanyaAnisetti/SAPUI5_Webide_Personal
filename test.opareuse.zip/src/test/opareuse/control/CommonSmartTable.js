/**
 * OPA Actions & Assertions for control sap.ui.comp.smarttable.SmartTable
 * @class CommonSmartTable
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/Ancestor",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"./CommonUtil"
], function(Opa5, AggregationLengthEquals, Ancestor, PropertyStrictEquals, CommonUtil) {
	"use strict";

	var mControlType = "sap.ui.comp.smarttable.SmartTable";

	var CommonSmartTable = {};
	CommonSmartTable.actions = new Opa5({
		/** Actions **/

		/**
		 * Press on a specific row in a Smart Table control.
		 * @public 
		 * @param {map/integer}  oOptionsOrRow         					Option map containing any of the following properties:
		 * @param {string}       [oOptionsOrRow.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptionsOrRow.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptionsOrRow.row]					Table row to be pressed
		 * @return {jQuery.promise}										A promise that gets resolved on success* 
		 * @memberof CommonSmartTable
		 */
		iPressOnRowInSmartTable: function(oOptionsOrRow) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrRow, "row");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["row"])) {
				CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				options.actions = function(aSmartTable) {
					var oSmartTable = $.isArray(aSmartTable) ? aSmartTable[0] : aSmartTable;
					oSmartTable.getItems()[1].getItems()[options.row - 1].$().tap();
				};
				return this.iDoActionByControlType(options);
			}
		},

		/**
		 * Press on a specific row in a Smart Table control, that is identified by its ID.
		 * @public 
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the sap.ui.comp.smarttable.SmartTable
		 * @param {string}       [oOptions.row]						Table row to be pressed
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonSmartTable
		 */
		iPressOnRowInSmartTableByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["row", "id"])) {
				options.actions = function(oSmartTable) {
					oSmartTable.getItems()[1].getItems()[options.row - 1].$().tap();
				};
				return this.iDoActionByID(options);
			}	
		},

		/**
		 * Press on a specific row in a Smart Table control, that is identified by its entity set.
		 * @public 
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.entitySet]				Entity Set of the sap.ui.comp.smarttable.SmartTable
		 * @param {string}       [oOptions.row]						Table row to be pressed
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonSmartTable
		 */
		iPressOnRowInSmartTableByEntitySet: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["row", "entitySet"])) {
				CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				CommonUtil.addMatchers(options, [new PropertyStrictEquals({
					name: "entitySet",
					value: options.entitySet
				})]);
				return this.iPressOnRowInSmartTable(options);
			}
		},

		/**
		 * Press on a button with a given text within a Smart Table control with a given entity set.
		 * @public 
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.entitySet]				Entity Set of the sap.ui.comp.smarttable.SmartTable
		 * @param {string}       [oOptions.text]					Text of the sap.m.Button
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonSmartTable
		 */
		/*iPressButtonInSmartTableByButtonTextAndEntitySet: function(oOptions) {
			var options = oOptions;
			options = CommonUtil.addOption(options, {
				controlType: mControlType
			}, false);
			CommonUtil.addMatchers(options, [new PropertyStrictEquals({
				name: "entitySet",
				value: options.entitySet
			})]);
			options = CommonUtil.addOption(options, {
				nestedControlType: "sap.m.OverflowToolbarButton"
			}, false);
			options = CommonUtil.addOption(options, {
				nestedAttributeName: "text"
			}, false);
			options = CommonUtil.addOption(options, {
				nestedAttributeValue: options.text
			}, false);
			options = CommonUtil.addOption(options, {
				nestedActions: function(oButton) {
					oButton.$().trigger("tap");
				}
			});
			options.success = function(aTable) {
				var oTable = aTable[0];
				var sId = oTable.getId();
				options.id = sId;
				delete options.controlType;
				return this.iDoActionOnNestedControlByID(options);
			}.bind(this);
			return this.iDoSuccessByControlType(options);
		},*/

		/**
		 * Open the personalization dialog of a Smart Table.
		 * @public 
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]			Namespace of the surrounding view (optional)
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonSmartTable
		 */
		iPersonalizeSmartTable: function(oOptions) {
			var options = oOptions;
			options = CommonUtil.addOption(options, {
				controlType: mControlType
			}, false);
			options = CommonUtil.addOption(options, {
				nestedControlType: "sap.m.OverflowToolbarButton"
			}, false);
			options = CommonUtil.addOption(options, {
				nestedAttributeName: "icon"
			}, false);
			options = CommonUtil.addOption(options, {
				nestedAttributeValue: "sap-icon://action-settings"
			}, false);
			options = CommonUtil.addOption(options, {
				nestedActions: function(oButton) {
					oButton.$().trigger("tap");
				}
			});
			options.actions = function(aTable) {
				var oTable = $.isArray(aTable) ? aTable[0] : aTable;
				var sId = oTable.getId();
				options.id = sId;
				delete options.controlType;
				return this.iDoActionOnNestedControlByID(options);
			}.bind(this);
			return this.iDoActionByControlType(options);
		},

		/**
		 * Press on icon in a specific row in a SmartTable control, that is identified by its entity set and a textual content.
		 * @public
		 * @param {map}          oOptions         							Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]						Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]				Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.icon]							Icon on which the action shall be executed
		 * @param {string}       [oOptions.entitySet]						Entity Set of the sap.ui.comp.smarttable.SmartTable
		 * @param {string}       [oOptions.text]							Text that identifies the row to be selected
		 * @return {jQuery.promise}											A promise that gets resolved on success* 
		 * @memberof CommonSmartTable
		 */
		iPressIconInSmartTableByTextContentInRowAndEntitySet: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["icon", "entitySet", "text"])) {
				CommonUtil.addOption(options, {
					actionControlType: "sap.ui.core.Icon",
					actionControlAttributeName: "src",
					actionControlAttributeValue: options.icon
				}, true);
				return this.iPressControlInSmartTableByEntitySetAndTextContent(options);
			}
		},

		/**
		 * Press on control in a specific row in a SmartTable control, that is identified by its entity set and a textual content.
		 * @public
		 * @param {map}          oOptions         							Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]						Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]		            Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.actionControlType]				ControlType of the control on which the action shall be executed
		 * @param {string}       [oOptions.actionControlAttributeName]		Attribute Name to identify the control on which the action shall be executed
		 * @param {string}       [oOptions.actionControlAttributeValue]		Attribute Value to identify the control on which the action shall be executed
		 * @param {string}       [oOptions.entitySet]						Entity Set of the sap.ui.comp.smarttable.SmartTable
		 * @param {string}       [oOptions.text]							Text that identifies the row to be selected
		 * @return {jQuery.promise}											A promise that gets resolved on success* 
		 * @memberof CommonSmartTable
		 */
		iPressControlInSmartTableByEntitySetAndTextContent: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["actionControlType", "actionControlAttributeName",
					"actionControlAttributeValue", "entitySet", "text"
				])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				CommonUtil.addMatchers(options, new PropertyStrictEquals({
					name: "entitySet",
					value: options.entitySet
				}), false);
				options.actions = function(aTable) {
					var oTable = $.isArray(aTable) ? aTable[0] : aTable;
					var sId = oTable.getId();
					options.id = sId;
					options = CommonUtil.addOption(options, {
						nestedControlType: "sap.m.Text"
					}, false);
					options = CommonUtil.addOption(options, {
						nestedAttributeName: "text"
					}, false);
					options = CommonUtil.addOption(options, {
						nestedAttributeValue: options.text
					}, false);
					options = CommonUtil.addOption(options, {
						nestedActions: function(oText) {
							var oListItemBase = oText.getParent();
							while (!jQuery.isEmptyObject(oListItemBase) && !CommonUtil.isTypeOfUI5(oListItemBase, "sap.m.ListItemBase")) {
								oListItemBase = oListItemBase.getParent();
							}
							if (!jQuery.isEmptyObject(oListItemBase)) {
								return this.waitFor({
									controlType: options.actionControlType,
									matchers: [new Ancestor(oListItemBase), new PropertyStrictEquals({
										name: options.actionControlAttributeName,
										value: options.actionControlAttributeValue
									})],
									actions: new sap.ui.test.actions.Press()
								});
							}
						}.bind(this)
					});
					return this.iDoActionOnNestedControlByID(options);
				}.bind(this);
				return this.iDoActionByControlType(options);
			}
		},
		
		/**
		 * Toggle the selection of a specific row in a sap.ui.comp.smarttable.SmartTable control, that is identified by id.
		 * @public
		 * @param {map}          oOptions         				Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.id]					ID of the sap.ui.comp.smarttable.SmartTable control
		 * @param {string}       [oOptions.row]					Row to be selected
		 * @return {jQuery.promise}								A promise that gets resolved on success* 
		 * @memberof CommonSmartTable
		 */
		iToggleRowSelectionInSmartTableByRowAndID: function(oOptions) {
			return this.iToggleRowSelectionInTableByRowAndID(oOptions);
		},

		/**
		 * Toggle the selection of a specific row in a SmartTable control, that is identified by textual content and entity set.
		 * @public
		 * @param {map}         oOptions	    					Option map containing any of the following properties:
		 * @param {string}      [oOptions.viewName]					Name (id) of the surrounding view (optional)
		 * @param {string}      [oOptions.viewNamespace]		    Namespace of the surrounding view (optional)
		 * @param {string}      [oOptions.text]						Text that identifies the row to be selected
		 * @param {string}  	[oOptions.entitySet]				Entity Set of the sap.ui.comp.smarttable.SmartTable
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonSmartTable
		 */
		iToggleRowSelectionInSmartTableByTextContentAndEntitySet: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["text", "entitySet"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				options = CommonUtil.addMatchers(options, [new PropertyStrictEquals({
					name: "entitySet",
					value: options.entitySet
				})]);
				options = CommonUtil.addOption(options, {
					nestedControlType: "sap.m.Text"
				}, false);
				options = CommonUtil.addOption(options, {
					nestedAttributeName: "text"
				}, false);
				options = CommonUtil.addOption(options, {
					nestedAttributeValue: options.text
				}, false);
				options = CommonUtil.addOption(options, {
					nestedActions: function(oText) {
						var oListItemBase = oText.getParent();
						while (!jQuery.isEmptyObject(oListItemBase) && !CommonUtil.isTypeOfUI5(oListItemBase, "sap.m.ListItemBase")) {
							oListItemBase = oListItemBase.getParent();
						}
						if (!jQuery.isEmptyObject(oListItemBase)) {
							var table = oListItemBase.getParent();
							table.setSelectedItem(oListItemBase, true, true);
						}
					}.bind(this)
				});
				options.actions = function(aTable) {
					var oTable = $.isArray(aTable) ? aTable[0] : aTable;
					var sId = oTable.getId();
					options.id = sId;
					delete options.controlType;
					return this.iDoActionOnNestedControlByID(options);
				}.bind(this);

				return this.iDoActionByControlType(options);
			}
		}
	});
	CommonSmartTable.assertions = new Opa5({

		/** Assertions **/

		/**
		 * Verify that a SmartTable is visible, that is identified by its ID.
		 * @public 
		 * @param {map/string}         		oOptionsOrID         			ID of the Smart Table or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrID.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}                  [oOptionsOrID.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.id]				ID of the sap.ui.comp.smarttable.SmartTable
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonSmartTable
		 */
		iShouldSeeSmartTableByID: function(oOptionsOrID) {
			var oOptions = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["id"])) {
				return this.iShouldSeeControlByID(oOptions);
			}
		},

		/**
		 * Verify that a SmartTable is visible, that is identified by its header.
		 * @public 
		 * @param {map/string}         		oOptionsOrHeader         			Header of the Smart Table or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrHeader.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrHeader.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrHeader.header]			Header of the sap.ui.comp.smarttable.SmartTable
		 * @return {jQuery.promise}												A promise that gets resolved on success
		 * @memberof CommonSmartTable
		 */
		iShouldSeeSmartTableByHeader: function(oOptionsOrHeader) {
			var oOptions = CommonUtil.resolveStringOrAttribute(oOptionsOrHeader, "header");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["header"])) {
				oOptions = CommonUtil.addOption(oOptions, {
					controlType: mControlType
				}, false);
				CommonUtil.addMatchers(oOptions, [new PropertyStrictEquals({
					name: "header",
					value: oOptions.header
				})]);
				return this.iShouldSeeControlByControlType(oOptions);
			}
		},

		/**
		 * Verify that a SmartTable is visible, that is identified by its entity set.
		 * @public 
		 * @param {map/string}     			oOptionsOrEntitySet         			Entity set of Smart Table or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrEntitySet.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrEntitySet.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrEntitySet.entitySet]			Entity Set of the sap.ui.comp.smarttable.SmartTable
		 * @return {jQuery.promise}													A promise that gets resolved on success
		 * @memberof CommonSmartTable
		 */
		iShouldSeeSmartTableByEntitySet: function(oOptionsOrEntitySet) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrEntitySet, "entitySet");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["entitySet"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				CommonUtil.addMatchers(options, [new PropertyStrictEquals({
					name: "entitySet",
					value: options.entitySet
				})]);
				return this.iShouldSeeControlByControlType(options);
			}
		},

		/**
		 * @param {map/string}     			oOptions         			Entity set of Smart Table or option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.entitySet]		Entity Set of the sap.ui.comp.smarttable.SmartTable
		 * @param {number}      			[oOptions.length]			Expected number of items in the list
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonSmartTable
		 */
		iShouldSeeLengthOfSmartTableByEntitySet: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["entitySet", "length"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				options = CommonUtil.addMatchers(options, [new PropertyStrictEquals({
					name: "entitySet",
					value: options.entitySet
				})]);
				options.attributeName = "length";
				options.attributeValue = options.length;
				options.fGetAttribute = function(oControl) {
					return oControl._getRowCount();
				};
				return this.iShouldSeeAttributeInControl(options);
				//return this.iShouldSeeLengthOfListBase(options);
			}
		},

		/**
		 * Verify that a passed text content is contained in a SmartTable, that is identified by its text content and entity set.
		 * @public
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.m.Table control
		 * @param {string}      			[oOptions.entitySet]		Entity Set of the sap.ui.comp.smarttable.SmartTable
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonTable
		 */
		iShouldSeeTextContentInSmartTableByEntitySet: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["text", "entitySet"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				options = CommonUtil.addMatchers(options, [new PropertyStrictEquals({
					name: "entitySet",
					value: options.entitySet
				})]);
				options = CommonUtil.addOption(options, {
					nestedControlType: "sap.m.Text"
				}, false);
				options = CommonUtil.addOption(options, {
					nestedAttributeName: "text"
				}, false);
				options = CommonUtil.addOption(options, {
					nestedAttributeValue: options.text
				}, false);
				options = CommonUtil.addOption(options, {
					nestedSuccess: function() {
						Opa5.assert.ok(true, "Found table with entity set '" + options.entitySet + "' and text content '" + options.text + "'");
					}
				});
				options.success = function(aTable) {
					var oTable = aTable[0];
					var sId = oTable.getId();
					options.id = sId;
					delete options.controlType;
					return this.iShouldSeeSuccessOnNestedControlByID(options);
				}.bind(this);

				return this.iShouldSeeSuccessByControlType(options);
			}
		}
	});

	return CommonSmartTable;
});