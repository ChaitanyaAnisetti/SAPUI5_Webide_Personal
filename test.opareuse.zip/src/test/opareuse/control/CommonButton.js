/**
 * OPA Actions & Assertions for control sap.m.Button
 * @class CommonButton
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/I18NText",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"./CommonUtil"
], function (Opa5, Press, I18NText, PropertyStrictEquals, CommonUtil) {
	"use strict";

	var mControlType = "sap.m.Button";
	var CommonButton = {};

	CommonButton.actions = new Opa5({
		/** Actions **/

		/**
		 * Presses a button, that is identified by its ID
		 * @public
		 * @param {string/map}	oOptionsOrID						ID of the button to be pressed or map containing any of the following properties
		 * @param {string}       [oOptionsOrID.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptionsOrID.id]					ID of the button to be pressed
		 * @return {jQuery.promise}									A promise that gets resolved on success 
		 * @memberof CommonButton
		 */
		iPressButtonByID: function (oOptionsOrID) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id"])) {
				options.actions = new Press();
				return this.iDoActionByID(options);
			}
		},

		/**
		 * Presses a button, that is identified by its text.
		 * @public
		 * @param {string/map}      		oOptionsOrText				Text of the button to be pressed or map containing any of the following properties:
		 * @param {string}      			[oOptionsOrText.viewName]	Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrText.viewNamespace]	Namespace  of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrText.text]		Text of the button to be pressed
		 * @param {sap.ui.test.matchers}	[oOptionsOrText.text]		Additional matchers, e.g. matcher on property "icon" (optional)
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonButton
		 */
		iPressButtonByText: function (oOptionsOrText) {
			var options = CommonUtil.resolveStringOrAttribute((oOptionsOrText), "text");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["text"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType,
					viewName: "" // do not restrict on specific view
				}, false);
				CommonUtil.addMatchers(options, [new PropertyStrictEquals({
					name: "text",
					value: options.text
				})]);
				options.actions = new Press();
				return this.iDoActionByControlType(options);
			}
		},

		/**
		 * Presses a button, that is identified by its i18n-key.
		 * @public
		 * @param {map}         			oOptions         						Option map containing any of the following properties:
		 * @param {boolean}					[oOptions.overflowButtonHandlingNeeded]	if true, it is checked if button is potentially hidden by the overflow button
		 * @param {string}      			[oOptions.viewName]						Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]				Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.key]							I18n-key of the button to be pressed
		 * @param {sap.ui.test.matchers}	[oOptions.matchers]						Additional matchers, e.g. matcher on property "icon" (optional)
		 * @return {jQuery.promise}													A promise that gets resolved on success
		 * @memberof CommonButton
		 */
		iPressButtonByI18nKey: function (oOptionsOrKey) {

			if (oOptionsOrKey && oOptionsOrKey.overflowButtonHandlingNeeded) {
				this.iClickOnOverflowbutton();
			}

			var options = CommonUtil.resolveStringOrAttribute((oOptionsOrKey), "key");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["key"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType,
					viewName: "" // do not restrict on specific view
				}, false);
				var properties = {
					key: options.key
				};
				CommonUtil.addOption(properties, {
					propertyName: options.propertyName || "text", //use "text" as default propertyName
					modelName: options.modelName,
					parameters: options.parameters
				});
				CommonUtil.addMatchers(options, new I18NText(properties));
				options.actions = new Press();
				return this.iDoActionByControlType(options);
			}
		},

		/**
		 * Presses a button, that is identified by its icon.
		 * @public
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.icon]				Icon of the button to be pressed
		 * @param {sap.ui.test.matchers}	[oOptions.text]				Additional matchers, e.g. matcher on property "icon" (optional)
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonButton
		 */
		iPressButtonByIcon: function (oOptionsOrIcon) {
			var options = CommonUtil.resolveStringOrAttribute((oOptionsOrIcon), "icon");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["icon"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType,
					viewName: "" // do not restrict on specific view
				}, false);
				CommonUtil.addMatchers(options, [new PropertyStrictEquals({
					name: "icon",
					value: options.icon
				})]);
				options.actions = new Press();
				return this.iDoActionByControlType(options);
			}
		},

		/**
		 * Presses the overflow (...) button 
		 * In cases of buttons which could be hidden due to missing space, this function should be called right before the button click action
		 * in order to display the overflow button menu
		 * @public
		 * @memberof CommonButton
		 */
		iClickOnOverflowbutton: function () {
			return this.waitFor({
				id: new RegExp("ObjectPageHeader", "i"), // i: case insensitive
				actions: function (oObjectHeader) {
					// getVisible() does not work because overflowbutton is always visible
					// Instead of visible, the style attribute display is used
					// display: none; invisbile
					// ! display: none; visible
					var oOverflowButton = oObjectHeader.getAggregation("_overflowButton");

					if (oOverflowButton) {
						if (oOverflowButton.getDomRef()) {
							if (oOverflowButton.getDomRef().getAttribute("style") !== "display: none;") {
								new Press().executeOn(oOverflowButton);
							}
						}
					}
				},
				errorMessage: "Could not find object page header"
			});
		}

		/**,
		 * Presses a button, that is contained in a parent control like a SmartTable, and is identified by its sub ID.
		 * @public
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.buttonID]		    ID of the control without the parent prefix, e.g. btnGo
		 * @param {string}      			[oOptions.controlType]		Control type of the parent, e.g. "sap.ui.comp.smartfilterbar.SmartFilterBar"
		 * @param {sap.ui.test.matchers}	[oOptions.matchers]			Additional matchers, e.g. matcher on property "icon" (optional)
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonButton
		 */
		/*iPressButtonByIDInControlOfType: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["buttonID", "controlType"])) {
				options.actions = function(aFilterBar) {
					var oFilterBar = aFilterBar[0] || aFilterBar;
					var sId = oFilterBar.getId();
					return this.iDoActionOnNestedControlByID({
						id: sId,
						nestedControlType: mControlType,
						nestedAttributeName: "id",
						nestedAttributeValue: sId + "-" + options.buttonID,
						nestedActions: function(oControl) {
							//oControl.$().trigger("tap");
							new Press();
						}
					});
				}.bind(this);
				return this.iDoActionByControlType(options);
			}
		}*/
	});

	CommonButton.assertions = new Opa5({
		/** Assertions **/

		/**
		 * Verify that a Button is visible, that is identified by its ID.
		 * @public
		 * @param {map}         			oOptionsOrID         			Option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrID.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.id]				ID of the button
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonButton
		 */
		iShouldSeeButtonByID: function (oOptionsOrID) {
			var options = CommonUtil.resolveStringOrAttribute((oOptionsOrID), "id");
			return this.iShouldSeeControlByID(options);
		},

		/**
		 * Verify that a button is visible, that is identified by its text.
		 * @public
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.m.Button control
		 * @param {sap.ui.test.matchers}	[oOptions.text]				Additional matchers, e.g. matcher on property "icon" (optional)
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonButton
		 */
		iShouldSeeButtonByText: function (oOptionsOrText) {
			var options = CommonUtil.resolveStringOrAttribute((oOptionsOrText), "text");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["text"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType,
					viewName: "" // do not restrict on specific view
				}, false);
				CommonUtil.addMatchers(options, [new PropertyStrictEquals({
					name: "text",
					value: options.text
				})]);
				return this.iShouldSeeControlByControlType(options);
			}
		},

		/**
		 * Verify that a button is visible, that is identified by its i18n-key.
		 * @public
		 * @param {map}         			oOptionsOrKey         		Option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrKey.viewName]	Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrKey.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrKey.key]			I18n-key of the button
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonButton
		 */
		iShouldSeeButtonByI18nKey: function (oOptionsOrKey) {
			var options = CommonUtil.resolveStringOrAttribute((oOptionsOrKey), "key");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["key"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType,
					viewName: "" // do not restrict on specific view
				}, false);
				return this.iShouldSeeControlByI18nKey(options);
			}
		},

		/**
		 * Verify that a button is visible, that is identified by its icon
		 * @public
		 * @param {string/map}         		oOptionsOrIcon         			Icon of the button or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrIcon.viewName]		Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrIcon.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrIcon.icon]			Icon of the button to be pressed
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonButton
		 */
		iShouldSeeButtonByIcon: function (oOptionsOrIcon) {
			var options = CommonUtil.resolveStringOrAttribute((oOptionsOrIcon), "icon");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["icon"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType,
					viewName: "" // do not restrict on specific view
				}, false);
				CommonUtil.addMatchers(options, [new PropertyStrictEquals({
					name: "icon",
					value: options.icon
				})]);
				return this.iShouldSeeControlByControlType(options);
			}
		}
	});

	return CommonButton;
});