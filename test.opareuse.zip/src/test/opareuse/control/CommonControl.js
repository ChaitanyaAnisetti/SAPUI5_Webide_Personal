/**
 * OPA Actions & Assertions for control sap.ui.core.Control
 * @class CommonControl
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/matchers/Ancestor",
	"sap/ui/test/matchers/I18NText",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"./CommonUtil"
], function(Opa5, Ancestor, I18NText, PropertyStrictEquals, CommonUtil) {
	"use strict";

	var mControlType = "sap.ui.core.Control";
    var CommonControl = {};
	CommonControl.actions = new Opa5({
		/** Actions **/
		/**
		 * Triggers an OPA5 action on a control, that is identified by its ID.
		 * @public
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the control
		 * @param {string}		 [oOptions.viewNamespace]			Namespace of the control
		 * @callback		     [oOptions.actions]					Callback to action, e.g. new Press()
		 * @param {string}       [oOptions.matchers]				Pass a set of additional matchers
		 * @return {jQuery.promise}									A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		iDoActionByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "actions"])) {
				var sSelector = "with the id " + options.id;
				var sMatcher = CommonUtil.matchersToString(options.matchers);
				if (sMatcher.length > 0) {
					sSelector += " and " + sMatcher;
				}
				return this.waitFor({
					id: options.id,
					viewName: options.hasOwnProperty("viewName") ? options.viewName : this.viewName,
					viewNamespace: options.hasOwnProperty("viewNamespace") ? options.viewNamespace : this.viewNamespace,
					matchers: options.matchers || [],
					actions: options.actions,
					errorMessage: "Was not able to find the control " + sSelector
				});
			}
		},

		/**
		 * Triggers an OPA5 action on a control, that is identified by its type.
		 * @public
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.controlType]				Type of the control, e.g. sap.m.Button
		 * @callback		     [oOptions.actions]					Callback to action, e.g. new Press()
		 * @param {string}       [oOptions.matchers]				Pass a set of matchers
		 * @return {jQuery.promise}									A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		iDoActionByControlType: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["controlType", "actions"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				var sSelector = "with the controlType '" + options.controlType + "'";
				var sMatcher = CommonUtil.matchersToString(options.matchers);
				if (sMatcher.length > 0) {
					sSelector += " and " + sMatcher;
				}
				sSelector += " that matches one unique entry.";
				return this.waitFor({
					viewName: options.hasOwnProperty("viewName") ? options.viewName : this.viewName,
					viewNamespace: options.hasOwnProperty("viewNamespace") ? options.viewNamespace : this.viewNamespace,
					controlType: options.controlType,
					matchers: options.matchers || [],
					check: function(aControl) {
						return aControl.length === 1;
					},
					actions: options.actions,
					errorMessage: "Was not able to find the control " + sSelector
				});
			}
		},

		/**
		 * Triggers an OPA5 action on a control, that is identified by its control type, an optional attribute and the ID of its ancestor control.
		 * @public
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the ancestor control
		 * @param {string}       [oOptions.nestedControlType]		Type of the nested control, e.g. sap.m.CheckBox
		 * @param {string}       [oOptions.nestedAttributeName]		Name of the attribute of the nested control (optional) 
		 * @param {string}       [oOptions.nestedAttributeValue]	Value of the attribute of the nested control (otional)
		 * @callback		     [oOptions.nestedActions]		 	Callback to action, e.g. new Press()
		 * @return {jQuery.promise}									A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		iDoActionOnNestedControlByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "nestedControlType"])) {
				options.actions = function(oControl) {
					var sSelector = "with the controlType '" + options.nestedControlType + "'";
					var nestedMatchers = [new Ancestor(oControl)];
					if (options.nestedAttributeName && options.nestedAttributeValue) {
						nestedMatchers.push(new PropertyStrictEquals({
							name: options.nestedAttributeName,
							value: options.nestedAttributeValue
						}));
						var sMatcher = CommonUtil.matchersToString(nestedMatchers);
						if (sMatcher.length > 0) {
							sSelector += " and " + sMatcher;
						}
					}
					sSelector += " that matches one unique entry.";
					return this.waitFor({
						controlType: options.nestedControlType,
						matchers: nestedMatchers || [],
						//check: function(aControl) {
							//return aControl.length === 1;
						//	return aControl[0];
							//return true;
						//},
						actions: function(aCtrl) {
							var oCtrl = $.isArray(aCtrl) ? aCtrl[0] : aCtrl;
							options.nestedActions(oCtrl);
						},
						errorMessage: "Was not able to find the control with " + sSelector
					});
				}.bind(this);
				return this.iDoActionByID(options);
			}
		}

		/**
		 * Triggers an OPA5 success on a control, that is identified by its ID.
		 * @public
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the control
		 * @callback		     oOptions.success					Callback to success function
		 * @param {string}       [oOptions.matchers]				Pass a set of additional matchers
		 * @return {jQuery.promise}									A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		/*iDoSuccessByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["id", "success"])) {
				//if ($.isEmptyObject(options.matchers)) {
				//	options.matchers = [];
				//}
				var sSelector = "with the id '" + oOptions.id + "'";
				var sMatcher = CommonUtil.matchersToString(options.matchers);
				if (sMatcher.length > 0) {
					sSelector += " and " + sMatcher;
				}
				return this.waitFor({
					id: oOptions.id,
					viewName: options.hasOwnProperty("viewName") ? options.viewName : this.viewName,
					matchers: options.matchers || [],
					success: function(oControl) {
						return oOptions.success(oControl);
					},
					errorMessage: "Was not able to find the control " + sSelector
				});
			}
		},*/

		/**
		 * Triggers an OPA5 success on a control, that is identified by its type.
		 * @public
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.controlType]				Type of the control, e.g. sap.m.Button
		 * @callback		     oOptions.nestedSuccess				Callback to success function
		 * @return {jQuery.promise}									A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		/*iDoSuccessByControlType: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["controlType", "nestedSuccess"])) {
				if ($.isEmptyObject(options.matchers)) {
					options.matchers = [];
				}
				var sSelector = "with the controlType '" + options.controlType + "'";
				var sMatcher = CommonUtil.matchersToString(options.matchers);
				if (sMatcher.length > 0) {
					sSelector += " and " + sMatcher;
				}
				sSelector += " that matches one unique entry.";
				return this.waitFor({
					viewName: options.hasOwnProperty("viewName") ? options.viewName : this.viewName,
					controlType: options.controlType,
					matchers: options.matchers,
					check: function(aControl) {
						return aControl.length === 1;
					},
					success: options.nestedSuccess,
					errorMessage: "Was not able to find the control " + sSelector
				});
			}
		},*/

		/**
		 * Triggers an OPA5 success on a control, that is identified by its control type, an optional attribute and the ID of its ancestor control.
		 * @public
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the ancestor control
		 * @param {string}       [oOptions.nestedControlType]		Type of the nested control, e.g. sap.m.CheckBox
		 * @param {string}       [oOptions.nestedAttributeName]		Attribute Name of the nested control (optional)
		 * @param {string}       [oOptions.nestedAttributeValue]	Attribute Value of the nested control (optional)
		 * @callback		     oOptions.nestedSuccess				Callback to success function
		 * @return {jQuery.promise}									A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		/*iDoSuccessOnNestedControlByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["id", "nestedControlType", "nestedAttributeName", "nestedAttributeValue"])) {
				options.success = function(oControl) {
					var nestedMatchers = [
						new PropertyStrictEquals({
							name: options.nestedAttributeName,
							value: options.nestedAttributeValue
						}),
						new Ancestor(oControl)
					];
					var sSelector = "with the controlType '" + options.nestedControlType + "'";
					var sMatcher = CommonUtil.matchersToString(nestedMatchers);
					if (sMatcher.length > 0) {
						sSelector += " and " + sMatcher;
					}
					return this.waitFor({
						controlType: options.nestedControlType,
						matchers: nestedMatchers || [],
						check: function(aControl) {
							return aControl.length === 1;
						},
						success: function(aCtrl) {
							var oCtrl = aCtrl[0];
							return options.nestedSuccess(oCtrl);
						},
						errorMessage: "Was not able to find the control " + sSelector
					});
				}.bind(this);
				return this.iDoSuccessByID(oOptions);
			}
		}*/
	});
	/** Assertions **/
	CommonControl.assertions = new Opa5({

		/**
		 * Triggers an OPA5 success on a control, that is identified by its ID.
		 * @public
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the control
		 * @callback		     oOptions.success					Callback to success function
		 * @param {string}       [oOptions.matchers]				Pass a set of additional matchers
		 * @return {jQuery.promise}									A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		iShouldSeeSuccessByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["id", "success"])) {
				var sSelector = "with the id '" + oOptions.id + "'";
				var sMatcher = CommonUtil.matchersToString(options.matchers);
				if (sMatcher.length > 0) {
					sSelector += " and " + sMatcher;
				}
				return this.waitFor({
					id: oOptions.id,
					viewName: options.hasOwnProperty("viewName") ? options.viewName : this.viewName,
					viewNamespace: options.hasOwnProperty("viewNamespace") ? options.viewNamespace : this.viewNamespace,
					matchers: options.matchers || [],
					success: function(oControl) {
						return oOptions.success(oControl);
					},
					errorMessage: "Was not able to find the control " + sSelector
				});
			}
		},
		
		
		/**
		 * Triggers an OPA5 success on a control, that is identified by its control type, an optional attribute and the ID of its ancestor control.
		 * @public
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the ancestor control
		 * @param {string}       [oOptions.nestedControlType]		Type of the nested control, e.g. sap.m.CheckBox
		 * @param {string}       [oOptions.nestedAttributeName]		Attribute Name of the nested control (optional)
		 * @param {string}       [oOptions.nestedAttributeValue]	Attribute Value of the nested control (optional)
		 * @callback		     oOptions.nestedSuccess				Callback to success function
		 * @return {jQuery.promise}									A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		iShouldSeeSuccessOnNestedControlByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "nestedControlType", "nestedAttributeName", "nestedAttributeValue"])) {
				options.success = function(oControl) {
					var nestedMatchers = [
						new PropertyStrictEquals({
							name: options.nestedAttributeName,
							value: options.nestedAttributeValue
						}),
						new Ancestor(oControl)
					];
					var sSelector = "with the controlType '" + options.nestedControlType + "'";
					var sMatcher = CommonUtil.matchersToString(nestedMatchers);
					if (sMatcher.length > 0) {
						sSelector += " and " + sMatcher;
					}
					return this.waitFor({
						controlType: options.nestedControlType,
						matchers: nestedMatchers || [],
						check: function(aControl) {
							return aControl.length === 1;
						},
						success: function(aCtrl) {
							var oCtrl = aCtrl[0];
							options.nestedSuccess(oCtrl);
						},
						errorMessage: "Was not able to find the control " + sSelector
					});
				}.bind(this);
				return this.iShouldSeeSuccessByID(options);
			}
		},
		
		/**
		 * Triggers an OPA5 success on a control, that is identified by its type.
		 * @public
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.controlType]				Type of the control, e.g. sap.m.Button
		 * @callback		     oOptions.success					Callback to success function
		 * @return {jQuery.promise}									A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		iShouldSeeSuccessByControlType: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["controlType", "success"])) {
				/*options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);*/
				//if ($.isEmptyObject(options.matchers)) {
				//	options.matchers = [];
				//}
				var sSelector = "with the controlType '" + options.controlType + "'";
				var sMatcher = CommonUtil.matchersToString(options.matchers);
				if (sMatcher.length > 0) {
					sSelector += " and " + sMatcher;
				}
				sSelector += " that matches one unique entry.";
				return this.waitFor({
					viewName: options.hasOwnProperty("viewName") ? options.viewName : this.viewName,
					viewNamespace: options.hasOwnProperty("viewNamespace") ? options.viewNamespace : this.viewNamespace,
					controlType: options.controlType,
					matchers: options.matchers || [],
					check: function(aControl) {
						return aControl.length === 1;
					},
					success: options.success,
					errorMessage: "Was not able to find the control " + sSelector
				});
			}
		},
		
		
		/**
		 * Trigger success when a Control is visible, that is identified by its ID.
		 * @public
		 * @param {string/map}         		oOptionsOrID         		ID of the control or map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.ui.core.Control control
		 * @param {string}      			[oOptions.matchers] 		
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		iShouldSeeControlByID: function(oOptionsOrID) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id"])) {
				// Initialize optional options
				var sSelector = "with the id '" + options.id + "'";
				var sMatcher = CommonUtil.matchersToString(options.matchers);
				if (sMatcher.length > 0) {
					sSelector += " and " + sMatcher;
				}
				options.success = function() {
					Opa5.assert.ok(true, "Found the control " + sSelector);
				};
				return this.iShouldSeeSuccessByID(options);
			}
		},

		/**
		 * Verify that a Control is visible, that is identified by its type.
		 * @public
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.controlType]		Type of the control, e.g. sap.m.Button
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		iShouldSeeControlByControlType: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["controlType"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				var sSelector = "with the controlType '" + options.controlType + "'";
				var sMatcher = CommonUtil.matchersToString(options.matchers);
				if (sMatcher.length > 0) {
					sSelector += " and " + sMatcher;
				}
				return this.waitFor({
					viewName: options.hasOwnProperty("viewName") ? options.viewName : this.viewName,
					viewNamespace: options.hasOwnProperty("viewNamespace") ? options.viewNamespace : this.viewNamespace,
					controlType: options.controlType,
					matchers: options.matchers || [],
					success: function(aControl) {
						Opa5.assert.ok(true, "Found the control " + sSelector);
					},
					errorMessage: "Was not able to find the control with " + sSelector
				});
			}
		},

		/**
		 * Verify that the passed value is contained in the control, that is identified by its ID
		 * @public
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.ui.core.Control control
		 * @param {string}      			[oOptions.value]			Expected value of the control
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		iShouldSeeValueInControlByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["id", "value"])) {
				options.attributeName = "value";
				options.attributeValue = options.value;
				options.fGetAttribute = function(oControl) {
					return oControl.getValue();
				};
				return this.iShouldSeeAttributeInControlByID(options);
			}
		},

		/**
		 * Verify that the passed text is contained in the control, that is identified by its ID
		 * @public
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.ui.core.Control control
		 * @param {string}      			[oOptions.text]				Expected text of the control
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		iShouldSeeTextInControlByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "text"])) {
				options.attributeName = "text";
				options.attributeValue = options.text;
				options.fGetAttribute = function(oControl) {
					return oControl.getText();
				};
				return this.iShouldSeeAttributeInControlByID(options);
			}
		},

		/**
		 * Verify that a Control is visible, that is identified by the passed attribute
		 * @public
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.attributeName]	Name of the attribute that identifies the control
		 * @param {string}      			[oOptions.attributeValue]   Value of the attribute that identifies the control
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		iShouldSeeControlByAttribute: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["attributeName", "attributeValue"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				CommonUtil.addMatchers(options, [new PropertyStrictEquals({
					name: options.attributeName,
					value: options.attributeValue
				})]);
				return this.iShouldSeeControlByControlType(options);
			}
		},

		/**
		 * Verify that a Control is visible, that is identified by the passed text
		 * @public
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.text]				Text that identifies the control
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		iShouldSeeControlByText: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["text"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				CommonUtil.addMatchers(options, [new PropertyStrictEquals({
					name: "text",
					value: options.text
				})]);
				return this.iShouldSeeControlByControlType(options);
			}
		},

		/**
		 * Verify that a Control is visible, that is identified by the passed i18n-key
		 * @public
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.propertyName]		Name of the property that contains the i18n-text, e.g. "text"
		 * @param {string}      			[oOptions.key]				Expected i18n-key of the control
		 * @param {string}      			[oOptions.modelName]		Model Name, default: i18n
		 * @param {string}      			[oOptions.parameters]		any additional parameters
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		iShouldSeeControlByI18nKey: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["key"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				var properties = {
					key: options.key
				};
				CommonUtil.addOption(properties, {
					propertyName: options.propertyName || "text", //use "text" as default propertyName
					modelName: options.modelName,
					parameters: options.parameters
				});
				CommonUtil.addMatchers(options, new I18NText(properties));
				return this.iShouldSeeControlByControlType(options);
			}
		},

		/**
		 * Verify that a Control is visible, that is identified by the passed i18n-key
		 * @public
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.ui.core.Control control
		 * @param {string}      			[oOptions.propertyName]		Name of the property that contains the i18n-text, e.g. "text"
		 * @param {string}      			[oOptions.key]				Expected i18n-key of the control
		 * @param {string}      			[oOptions.modelName]		Model Name, default: i18n
		 * @param {string}      			[oOptions.parameters]		any additional parameters
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		/*iShouldSeeControlByIDThatContainsI18nKey: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["id", "key"])) {
				var properties = {
					key: options.key
				};
				CommonUtil.addOption(properties, {
					propertyName: options.propertyName || "text", //use "text" as default propertyName
					modelName: options.modelName,
					parameters: options.parameters
				});
				CommonUtil.addMatchers(options, new I18NText(properties));
				return this.iShouldSeeControlByID(options);
			}
		},*/

		/**
		 * Verify that the passed attribute is contained in the control, that is identified by its ID
		 * @public
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.ui.core.Control control
		 * @param {string}      			[oOptions.attributeName]	Name of the passed attribute
		 * @param {string}      			[oOptions.attributeValue]	Expected value of the passed attribute
		 * @callback		    			[oOptions.fGetAttribute]	Callback to resolve the value of the passed attribute
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		iShouldSeeAttributeInControlByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["attributeName", "attributeValue", "fGetAttribute", "id"])) {
				// Initialize optional options
				var sSelector = "with the id '" + options.id + "'";
				var sValue = " contains attribute '" + options.attributeName + "' with value = '" + options.attributeValue + "'";
				return this.waitFor({
					id: options.id,
					viewName: options.hasOwnProperty("viewName") ? options.viewName : this.viewName,
					viewNamespace: options.hasOwnProperty("viewNamespace") ? options.viewNamespace : this.viewNamespace,
					matchers: options.matchers || [],
					success: function(oControl) {
						if ($.isArray(options.fGetAttribute(oControl)) || $.isArray(options.attributeValue)) {
							Opa5.assert.deepEqual(options.fGetAttribute(oControl), options.attributeValue, "The control " + sSelector + sValue);	
						} else {
							Opa5.assert.strictEqual(options.fGetAttribute(oControl), options.attributeValue, "The control " + sSelector + sValue);	
						}
					},
					errorMessage: "Was not able to find the control " + sSelector
				});
			}
		},

		/**
		 * Verify that the passed attribute is contained in the control, that is identified by type 
		 * @public
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.controlType]		Type of the control
		 * @param {string}      			[oOptions.attributeName]	Name of the passed attribute
		 * @param {string}      			[oOptions.attributeValue]	Expected value of the passed attribute
		 * @callback		    			[oOptions.fGetAttribute]	Callback to resolve the value of the passed attribute
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonControl
		 */
		iShouldSeeAttributeInControl: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["controlType", "attributeName", "attributeValue", "fGetAttribute"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				// Initialize optional options
				if ($.isEmptyObject(options.matchers)) {
					options.matchers = [];
				}
				var sSelector = "with the controlType '" + options.controlType + "'";
				var sMatcher = CommonUtil.matchersToString(options.matchers);
				if (sMatcher.length > 0) {
					sSelector += " and " + sMatcher;
				}
				var sValue = " contains attributeName '" + options.attributeName + "' with value = '" + options.attributeValue + "'";
				return this.waitFor({
					controlType: options.controlType,
					viewName: options.hasOwnProperty("viewName") ? options.viewName : this.viewName,
					viewNamespace: options.hasOwnProperty("viewNamespace") ? options.viewNamespace : this.viewNamespace,
					matchers: options.matchers || [],
					success: function(aControl) {
						var oControl = aControl[0];
						Opa5.assert.strictEqual(options.fGetAttribute(oControl), options.attributeValue, "The control " + sSelector + sValue);
					},
					errorMessage: "Was not able to find the control " + sSelector
				});
			}
		}
	});

	return CommonControl;
});