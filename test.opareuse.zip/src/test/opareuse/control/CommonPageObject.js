/**
 * OPA Common Page Object
 * @class CommonPageObject
 */
function getFrameUrl(sResourcePath, mParameters) {
	var mParams = mParameters || {},
		sSemanticObject = mParams.semanticObject && mParams.action ? ("#" + mParams.semanticObject) : "",
		sAction = mParams.action && mParams.semanticObject ? ("-" + mParams.action) : "",
		sHash = mParams.hash ? "&" + (mParams.hash.indexOf("/") === 0 ? mParams.hash.substring(1) : mParams.hash) : "",
		sParameter = mParams.URLParameters ? ("?" + mParams.URLParameters) : "",
		sURL = jQuery.sap.getResourcePath(sResourcePath, ".html");
	if (sSemanticObject || sAction || sHash || sParameter) {
		sURL = sURL + "?" + sSemanticObject + sAction + sHash + sParameter;
	}
	return sURL.trim();
}

/**
 * Enriches the given Container Object with the OPA Helper Methods of the given Opa Helper Libraries.
 * The functions of the given sOpaOperationType injected on root level of the container object. 
 * Functions of the other types are injected in a subobject with the type name (e.g. an action Container gets an assertions subobject and vice versa)
 
 * @private 
 * @param {string}         			sOpaOperationType      		OPA5 operation type. Either "actions" or "assertions"
 * @param {Object}         			oContainerObject			Container Object for the functions
 * @param {Object[]}				aOpaHelperLibraries         Array of Opa Libraries
 */
function retrieveOpaHelperFunctions(sOpaOperationType, oContainerObject, aOpaHelperLibraries) {
	var aAllowedOpaOperationType = {
		actions: "actions",
		assertions: "assertions"
	};

	if (!aAllowedOpaOperationType[sOpaOperationType]) {
		throw new Error("Action Not Supported");
	}

	for (var i in aOpaHelperLibraries) {
		for (var sOperationType in aAllowedOpaOperationType) {
			for (var methodName in aOpaHelperLibraries[i][sOperationType]) {
				if (sOperationType === sOpaOperationType) {
					if (!oContainerObject[methodName]) {
						oContainerObject[methodName] = aOpaHelperLibraries[i][sOperationType][methodName];
					}
				}
				/*else {
					if(!oContainerObject[sOperationType]) {
						oContainerObject[sOperationType] = {};
					} 
					if(!oContainerObject[sOperationType][methodName]) {
						oContainerObject[sOperationType][methodName] = 	aOpaHelperLibraries[i][sOperationType][methodName];
					} 
				}*/
			}
		}
	}

	return oContainerObject;

}

sap.ui.define([
	"sap/ui/test/Opa5",
	"./CommonButton",
	"./CommonComboBox",
	"./CommonControl",
	"./CommonDialog",
	"./CommonInputBase",
	"./CommonInput",
	"./CommonLabel",
	"./CommonLink",
	"./CommonListBase",
	"./CommonMultiComboBox",
	"./CommonNavigation",
	"./CommonPage",
	"./CommonSearchField",
	"./CommonSelect",
	"./CommonShellAppTitle",
	"./CommonShellHeadItem",
	"./CommonSmartField",
	"./CommonSmartFilterBar",
	"./CommonSmartTable",
	"./CommonTable",
	"./CommonText",
	"./CommonTitle"
], function (Opa5, CommonButton, CommonComboBox, CommonControl, CommonDialog, CommonInputBase, CommonInput, CommonLabel, CommonLink,
	CommonListBase, CommonMultiComboBox, CommonNavigation, CommonPage, CommonSearchField, CommonSelect, CommonShellAppTitle,
	CommonShellHeadItem, CommonSmartField, CommonSmartFilterBar, CommonSmartTable, CommonTable, CommonText, CommonTitle
) {
	"use strict";

	// *****************************************************************
	// private functions
	// *****************************************************************
	/*global*/
	var oActions = null;
	var oAssertions = null;
	var aLibraries = [
		CommonControl,
		CommonButton,
		CommonInputBase,
		CommonInput,
		CommonComboBox,
		CommonLabel,
		CommonLink,
		CommonDialog,
		CommonPage,
		CommonListBase,
		CommonNavigation,
		CommonMultiComboBox,
		CommonSearchField,
		CommonSelect,
		CommonSmartFilterBar,
		CommonSmartTable,
		CommonSmartField,
		CommonTable,
		CommonText,
		CommonShellAppTitle,
		CommonShellHeadItem,
		CommonTitle
	];

	var CommonOpa = Opa5.extend("sap.ui.test.Opa5.CommonPageObject", {

		_oOptions: {},

		constructor: function () {},

		/**
		 * Starts the Application in a Frame
		 * @public
		 * @param {string}		 sResourcePath			    Resource Path to access the application
		 * @param {map}          oOptions    				Parameter map containing any of the following properties:
		 * @param {string}       [oOptions.semanticObject]	Semantic object as defined in an app launcher tile.
		 * @param {string}       [oOptions.action]			Action as defined in an app launcher tile.
		 * @param {string}       [oOptions.hash]			URL Hash
		 * @param {string}       [oOptions.URLParameters]	URL Parameters
		 * @memberof CommonPageObject
		 */
		iStartMyApp: function (sResourcePath, oOptions) {
			// Start the app with a minimal delay to make tests run fast but still async to discover basic timing issues
			//var iDelay = oOptions.delay || 50;
			this.iStartMyAppInAFrame(getFrameUrl(sResourcePath, oOptions));
			this._iIncreaseAppLogLevelToGetInfoMessagesFromActions();
		},

		_iIncreaseAppLogLevelToGetInfoMessagesFromActions: function () {
			return this.waitFor({
				success: function () {
					var jQueryInFrame = sap.ui.test.Opa5.getJQuery();
					jQueryInFrame.sap.log.setLevel(jQueryInFrame.sap.log.LogLevel.DEBUG);
					jQuery.sap.log.setLevel(jQuery.sap.log.Level.DEBUG);
				}
			});
		}

	});

	return {
		getOpaLibraries: function () {
			return aLibraries;
		},

		/**
		 * Returns a PageObject for a given View
		 * @param {String} sViewName - Name of the view
		 * @return {sap.ui.test.Opa5.CommonPageObject} 	OPA Reuse Page Object
		 * @static
		 * @memberof CommonPageObject
		 */
		createBaseClassForPageObject: function (sViewName) {
			CommonOpa.viewName = sViewName;
			/*			CommonOpa.actions = this.getCommonActions();
						CommonOpa.assertions = this.getCommonAssertions();*/

			return CommonOpa;
		},
		/**
		 * Returns an OPA5 object containing the actions functions of the OPA reuse library.
		 * Additionally the returned OPA5 object contains all assertions in an sub object called "assertions"
		 * @return {sap.ui.test.Opa5}	OPA object containing all OPA action functions
		 * @static
		 * @memberof CommonPageObject
		 */
		getCommonActions: function () {
			if (!oActions) {
				oActions = retrieveOpaHelperFunctions("actions", new Opa5(), this.getOpaLibraries());
			}
			return oActions;
		},
		/**
		 * Returns an OPA5 object containing the assertions functions of the OPA reuse library.
		 * Additionally the returned OPA5 object contains all assertions in an sub object called "actions"
		 * @return {sap.ui.test.Opa5}	 OPA object containing all OPA assertion functions
		 * @static
		 * @memberof CommonPageObject
		 */
		getCommonAssertions: function () {
			if (!oAssertions) {
				oAssertions = retrieveOpaHelperFunctions("assertions", new Opa5(), this.getOpaLibraries());
			}
			return oAssertions;
		},

		/**
		 * Returns the arrangement of the OPA5 page object
		 * @return {sap.ui.test.Opa5.CommonPageObject} 	OPA Reuse Page Object
		 * @static
		 * @memberof CommonPageObject
		 */
		getArrangement: function () {
			var oArrangement = new CommonOpa();
			return oArrangement;
		}

	};

});