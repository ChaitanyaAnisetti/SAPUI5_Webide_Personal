/**
 * OPA Common Utils
 * @class CommonUtil
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationContainsPropertyEqual",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/Ancestor",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/I18NText",
	"sap/ui/test/matchers/Interactable",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(Opa5, PropertyStrictEquals, AggregationFilled, AggregationContainsPropertyEqual, AggregationLengthEquals, Ancestor,
	BindingPath, I18NText, Interactable, sinon) {
	"use strict";

	return {

		/**
		 * Validates the passed options of a test method with an array of expected mandatory options
		 * @param {String[]} aPassedOptionKeys array of passed option keys of the testmethod
		 * @param {String[]} aMandatoryOptionKeys expected array of mandatory option keys
		 * @return {Boolean} true if all expected mandatory options are passed to test method, otherwise false
		 * @memberof CommonUtil
		 */
		validateOptions: function(aPassedOptionKeys, aMandatoryOptionKeys) {
			var isValid = true;
			if (!$.isEmptyObject(aMandatoryOptionKeys)) {
				aMandatoryOptionKeys.forEach(function(option) {
					if (aPassedOptionKeys.indexOf(option) === -1) {
						isValid = false;
						QUnit.assert.ok(isValid, "Missing option " + option + " in test method.");
					}
				});
			}
			return isValid;
		},

		/**
		 * Adds new options to an options object or initializes it
		 * @param {Object}	oOptions Existing object of options or empty
		 * @param {Object}	oNewOptions Object with new options
		 * @param {Boolean} bOverwrite true if the option should be overwritten in case that it already exists
		 * @return {Object} Extended options object with passed new options
		 * @memberof CommonUtil
		 */
		addOption: function(oOptions, oNewOptions, bOverwrite) {
			var options = oOptions;
			if ($.isEmptyObject(options)) {
				options = {};
			}
			for (var property in oNewOptions) {
				if (bOverwrite || !(options.hasOwnProperty(property))) {
					options[property] = oNewOptions[property];
				}
			}
			return options;
		},

		/**
		 * Resolves the passed matchers in a textual way that can be used for message output
		 * @param {Object[]} aMatchers array of passed OPA5 matchers
		 * @return {String} Textual representation of the passed matchers
		 * @memberof CommonUtil
		 */
		matchersToString: function(aMatchers) {
			var strParts = [];
			if (!$.isEmptyObject(aMatchers)) {
				if (!$.isArray(aMatchers)) {
					aMatchers = [aMatchers];					
				}
				aMatchers.forEach(function(matcher) {
					if (matcher instanceof AggregationFilled) {
						strParts.push("aggregation '" + matcher.getName() + "' is filled");
					} else if (matcher instanceof AggregationContainsPropertyEqual) {
						strParts.push("aggregation '" + matcher.getAggregationName() + "' contains property '" + matcher.getPropertyName() + "' = '" +
							matcher.getPropertyValue() + "'");
					} else if (matcher instanceof AggregationLengthEquals) {
						strParts.push("aggregation '" + matcher.getName() + "' of length " + matcher.getLength());
					} else if (sap.ui.test.matchers.Ancestor.toString().replace(" ", "").indexOf(matcher.toString().replace(" ", "")) > -1) {
						strParts.push("matcher of type Ancestor");
					} else if (matcher instanceof BindingPath) {
						strParts.push("binding path '" + matcher.getPath() + "' of model '" + matcher.getModelName() + "'");
					} else if (matcher instanceof I18NText) {
						strParts.push("propertyName '" + matcher.getPropertyName() + "' and key '" + matcher.getKey() + "'");
						if (matcher.getModelName()) {
							strParts.push("modelName = '" + matcher.getModelName() + "'");
						}
					} else if (matcher instanceof Interactable) {
						strParts.push("is interactable");
					} else if (matcher instanceof PropertyStrictEquals) {
						strParts.push(matcher.getName() + " = '" + matcher.getValue() + "'");
					} else {
						strParts.push("a custom matcher");
					}
				});
			}
			var str = "";
			if (strParts.length > 0) {
				str = strParts.join(" and ");
			}
			return str;
		},

		/**
		 * Resolves the passed object or string to a new options object with the passed attribute name
		 * @param {string}      			oOptionsOrString			Either an options object or a string
		 * @param {string}      			sAttr						Attribute name of the option
		 * @return {Object} New Options object
		 * @public
		 * @memberof CommonUtil
		 */
		resolveStringOrAttribute: function(oOptionsOrString, sAttr) {
			var oOptions = {};
			if (typeof oOptionsOrString === "object") {
				oOptions = oOptionsOrString;
			} else {
				oOptions = {};
				oOptions[sAttr] = oOptionsOrString;
			}
			return oOptions;
		},

		/**
		 * Add additional matchers to the options object
		 * @param {Object} oOptions Options object
		 * @param {Object[]} aMatcher array of passed OPA5 matchers
		 * @return {Object} Options object with new matchers
		 * @memberof CommonUtil
		 */
		addMatchers: function(oOptions, aMatcher) {
			if ($.isEmptyObject(oOptions.matchers)) {
				oOptions.matchers = [];
			}
			oOptions.matchers = oOptions.matchers.concat(aMatcher);
			return oOptions;
		},

		/**
		 * This function checks if the given object is a UI5 object of the given type
		 * A Ui5 object should have metadata information, which can be retrieved with the getMetadata() method. 
		 * @param {Object} oObject - Object to test
		 * @param {String} sUI5Type - type of the UI5 method
		 * @return {Boolean} TRUE, if oObject is a SAPUI5 element; FALSE if oObject is null, undefined or not and SAPUI5 view
		 * @public
		 * @memberof CommonUtil
		 */
		isTypeOfUI5: function(oObject, sUI5Type) {
			// default false
			var bReturn = false,
				bFindParent = true,
				oMetadata = {};

			// 0 - check input parameters
			if (jQuery.isEmptyObject(oObject) || jQuery.type(sUI5Type) !== "string") {
				QUnit.assert.ok(false, "Import Parameters are not supplied correctly.");
			}

			// 1 - check if the oObject has ui5 metadata 
			try {
				// get the metadata object of the ui5 type
				oMetadata = oObject.getMetadata();
				// type is empty so return false and skip the processing
				// a type is set check if the type matches the required one
				bFindParent = true;
				// a type name exists
				do {
					// test if a metadata object exists
					if (!oMetadata) {
						bFindParent = false; // stop processing
						QUnit.assert.ok(false, "oObject is not an SAPUi5 object or has no metadata object");
					} else if (oMetadata.getName() === "sap.ui.base.Object") {
						bFindParent = false; // stop processing
						if (sUI5Type === "sap.ui.base.Object") {
							// special case base object is requested
							bReturn = true;
						}
					}
					// test if the type name matches to the requested one
					else if (oMetadata.getName() === sUI5Type) {
						// we found the requested type --> set return value to TRUE. 
						bReturn = true;
						bFindParent = false; // stop processing
					} else {
						// the type is not the requested check the parent
						oMetadata = oMetadata.getParent();
					}

					// base object = sap.ui.base.Object
				} while (bFindParent);

			} catch (err) {
				//	oObject has not method named getMetadata, hence it might not be SAPUI5 Object 
				QUnit.assert.ok(false, "oObject is not an SAPUi5 object or has no metadata object");
				bReturn = false; // explicit
			}

			// return the result
			return bReturn;
		}
	};

});