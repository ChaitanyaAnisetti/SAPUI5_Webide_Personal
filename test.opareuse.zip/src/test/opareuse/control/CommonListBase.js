/**
 * OPA Actions & Assertions for control sap.m.ListBase
 * @class CommonListBase
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/BindingPath",
	"./CommonUtil"
], function(Opa5, Press, AggregationFilled, AggregationLengthEquals, BindingPath, CommonUtil) {
	"use strict";

	var mControlType = "sap.m.ListBase";

	var CommonListBase = {};
	CommonListBase.actions = new Opa5({
		/** Actions **/

		/**
		 * Press on a specific row in a List Base control, that is identified by its ID.
		 * @public 
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the sap.m.ListBase
		 * @param {string}       [oOptions.row]						List row to be pressed
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonListBase
		 */
		iPressOnRowInListBaseByID: function(oOptions) {
			var options = oOptions;
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "row"])) {
				options.actions = function(oListBase) {
					oListBase.getItems()[options.row - 1].$().tap();
				};
				return this.iDoActionByID(options);
			}
		},

		/**
		 * Press on a specific row in a List Base control.
		 * @public 
		 * @param {map/string}   oOptionsOrRow         				Row of the List Base control or option map containing any of the following properties:
		 * @param {string}       [oOptionsOrRow.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptionsOrRow.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}       [oOptionsOrRow.row]				List row to be pressed
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonListBase
		 */
		iPressOnRowInListBase: function(oOptionsOrRow) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrRow, "row");
			if (CommonUtil.validateOptions(Object.keys(options), ["row"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				options.actions = function(aListBase) {
					var oListBase = $.isArray(aListBase) ? aListBase[0] : aListBase;
					oListBase.getItems()[options.row - 1].$().tap();
				};
				return this.iDoActionByControlType(options);
			}
		},

		/**
		 * Press on the more data button in a List Base control, that is identified by its ID.
		 * @public 
		 * @param {map/string}   oOptionsOrID         				ID of the List Base control or option map containing any of the following properties:
		 * @param {string}       [oOptionsOrID.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptionsOrID.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}       [oOptionsOrID.id]					ID of the sap.m.ListBase
		 * @param {string}       [oOptionsOrID.row]					List row to be pressed
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonListBase
		 */
		iPressMoreDataButtonInListBaseByID: function(oOptionsOrID) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			if (CommonUtil.validateOptions(Object.keys(options), ["id"])) {
				options.actions = new Press();
				options.errorMessage = "Was not able to find list with id " + options.id + " and more data button";
				return this.iDoActionByID(options);
			}
		},

		/**
		 * Press on the more data button in a List Base control.
		 * @public 
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.row]						List row to be pressed
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonListBase
		 */
		iPressMoreDataButtonInListBase: function(oOptions) {
			var options = CommonUtil.addOption(oOptions, {
				controlType: mControlType
			}, false);
			options.actions = new Press();
			options.errorMessage = "Was not able to find list with more data button";
			CommonUtil.addMatchers(options, [
				function(oListBase) {
					return !!oListBase.$("trigger").length;
				}
			]);
			return this.iDoActionByControlType(options);
		}
	});
	CommonListBase.assertions = new Opa5({
		/** Assertions **/

		/**
		 * Verify that a ListBase control is visible, that is identified by its ID.
		 * @public 
		 * @param {map/string}       		oOptionsOrID         			Option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrID.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.id]				ID of the sap.m.ListBase control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonListBase
		 */
		iShouldSeeListBaseByID: function(oOptionsOrID) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id"])) {
				return this.iShouldSeeControlByID(options);
			}
		},

		/**
		 * Verify that at least one item is contained in a ListBase control, that is identified by its ID.
		 * @public 
		 * @param {map}         			oOptionsOrID         			Option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrID.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.id]				ID of the sap.m.ListBase control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonListBase
		 */
		iShouldSeeItemsInListBaseByID: function(oOptionsOrID) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id"])) {
				CommonUtil.addMatchers(options, [new AggregationFilled({
					name: "items"
				})]);
				return this.iShouldSeeControlByID(options);
			}
		},

		/**
		 * Verify that at a specific number of items is contained in a ListBase control, that is identified by its ID.
		 * @public 
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.viewNamespace]Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.m.ListBase control
		 * @param {number}      			[oOptions.length]			Expected number of items in the list
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonListBase
		 */
		iShouldSeeLengthOfListBaseByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "length"])) {
				CommonUtil.addMatchers(oOptions, [new AggregationLengthEquals({
					name: "items",
					length: options.length
				})]);
				return this.iShouldSeeControlByID(options);
			}
		},

		/**
		 * Verify that at a specific number of items is contained in a ListBase control.
		 * @public 
		 * @param {map/string}         		oOptionsOrLength         		Length of the List Base control or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrLength.viewName]		Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {number}      			[oOptionsOrLength.length]		Expected number of items in the list
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonListBase
		 */
		iShouldSeeLengthOfListBase: function(oOptionsOrLength) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrLength, "length");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["length"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				CommonUtil.addMatchers(options, [new AggregationLengthEquals({
					name: "items",
					length: options.length
				})]);
				return this.iShouldSeeControlByControlType(options);
			}
		}
	});

	return CommonListBase;
});