/* OPA Actions & Assertions for control sap.m.InputBase
 * @class CommonInputBase
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press",
	"sap/ui/test/actions/EnterText",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"./CommonUtil"
], function(Opa5, Press, EnterText, PropertyStrictEquals, CommonUtil) {
	"use strict";

	var mControlType = "sap.m.InputBase";

	var CommonInputBase = {};
	CommonInputBase.actions = new Opa5({

		/** Actions **/

		/**
		 * Enters a value in an Input Base control, that is identified by its ID.
		 * @public 
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the sap.m.InputBase
		 * @param {string}       [oOptions.value]					Value to be entered
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonInputBase
		 */
		iEnterValueInInputBaseByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "value"])) {
				options.actions = new EnterText({
					text: options.value
				});
				return this.iDoActionByID(options);
			}
		},

		/**
		 * Enters a new value in an Input Base control, that is identified by its current value.
		 * @public 
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the sap.m.InputBase
		 * @param {string}       [oOptions.value]					Current Value of the sap.m.InputBase
		 * @param {string}       [oOptions.newValue]				New Value to be entered 
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonInputBase
		 */
		iEnterValueInInputBaseByValue: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["value", "newValue"])) {
				options = CommonUtil.addOption(oOptions, {
					controlType: mControlType
				}, false);
				CommonUtil.addMatchers(oOptions, [new PropertyStrictEquals({
					name: "value",
					value: options.value
				})]);
				options.actions = new EnterText({text: options.newValue});
				return this.iDoActionByControlType(options);
			}
		}
	});
	CommonInputBase.assertions = new Opa5({
		/** Assertions **/

		/**
		 * Verify that an InputBase control is visible, that is identified by its ID.
		 * @public 
		 * @param {map/string}     			oOptionsOrID         			ID of the InputBase or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrID.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.id]				ID of the sap.m.InputBase control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonInputBase
		 */
		iShouldSeeInputBaseByID: function(oOptionsOrID) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id"])) {
				return this.iShouldSeeControlByID(options);
			}
		},

		/**
		 * Verify that an InputBase control is visible, that is identified by its value.
		 * @public 
		 * @param {map/string}     			oOptionsOrValue         		Value of the InputBase or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrValue.viewName]		Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrValue.value]			Value of the sap.m.InputBase control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonInputBase
		 */
		iShouldSeeInputBaseByValue: function(oOptionsOrValue) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrValue, "value");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["value"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				CommonUtil.addMatchers(options, [new PropertyStrictEquals({
					name: "value",
					value: options.value
				})]);
				return this.iShouldSeeControlByControlType(options);
			}
		},

		/**
		 * Verify that a passed value is contained in an InputBase control, that is identified by its ID.
		 * @public 
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]			ID of the sap.m.InputBase control
		 * @param {string}      			[oOptions.value]			Value of the sap.m.InputBase control
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonInputBase
		 */
		iShouldSeeValueInInputBaseByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "value"])) {
				return this.iShouldSeeValueInControlByID(options);
			}
		}
	});
	return CommonInputBase;
});