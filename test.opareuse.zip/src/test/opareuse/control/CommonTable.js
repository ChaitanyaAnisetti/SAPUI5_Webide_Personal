/**
 * OPA Actions & Assertions for control sap.m.Table
 * @class CommonTable
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/matchers/Ancestor",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationEmpty",
	"./CommonUtil"
], function (Opa5, Ancestor, BindingPath, PropertyStrictEquals, AggregationEmpty, CommonUtil) {
	"use strict";

	var mControlType = "sap.m.Table";

	var CommonTable = {};
	CommonTable.actions = new Opa5({

		/** Actions **/

		/**
		 * Press on a specific row in a Table control, that is identified by its ID.
		 * @public
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the sap.m.Table
		 * @param {string}       [oOptions.row]						Table row to be pressed
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonTable
		 */
		iPressOnRowInTableByID: function (oOptions) {
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["id", "row"])) {
				return this.iPressOnRowInListBaseByID(oOptions);
			}
		},

		/**
		 * Press on a specific row in a Table control.
		 * @public
		 * @param {map}          oOptionsOrRow       				Option map containing any of the following properties:
		 * @param {string}       [oOptionsOrRow.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptionsOrRow.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}       [oOptionsOrRow.row]				Table row to be pressed
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonTable
		 */
		iPressOnRowInTable: function (oOptionsOrRow) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrRow, "row");
			CommonUtil.addOption(options, {
				controlType: mControlType
			}, false);
			return this.iPressOnRowInListBase(options);
		},

		/**
		 * Press on the more data button in a Table control, that is identified by its ID.
		 * @public
		 * @param {map}          oOptionsOrID         					Option map containing any of the following properties:
		 * @param {string}       [oOptionsOrID.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptionsOrID.viewNamespace]		    Namespace of the surrounding view (optional)
		 * @param {string}       [oOptionsOrID.id]						ID of the sap.m.Table
		 * @param {string}       [oOptionsOrID.row]						Table row to be pressed
		 * @return {jQuery.promise}										A promise that gets resolved on success* 
		 * @memberof CommonTable
		 */
		iPressMoreDataButtonInTableByID: function (oOptionsOrID) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id"])) {
				return this.iPressMoreDataButtonInListBaseByID(options);
			}
		},

		/**
		 * Press on the more data button in a Table control.
		 * @public
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.row]						Table row to be pressed
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonTable
		 */
		iPressMoreDataButtonInTable: function (oOptions) {
			var options = CommonUtil.addOption(oOptions, {
				controlType: mControlType
			}, false);
			return this.iPressMoreDataButtonInListBase(options);
		},

		/**
		 * Press on a specific row in a Table control, that is identified by a textual content.
		 * @public
		 * @param {map}          oOptionsOrText         				Option map containing any of the following properties:
		 * @param {string}       [oOptionsOrText.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptionsOrText.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptionsOrText.text]					Text that identifies the row to be pressed
		 * @return {jQuery.promise}										A promise that gets resolved on success* 
		 * @memberof CommonTable
		 */
		iPressOnRowInTableByTextContent: function (oOptionsOrText) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrText, "text");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["text"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				options = CommonUtil.addOption(options, {
					nestedControlType: "sap.m.Text"
				}, false);
				options = CommonUtil.addOption(options, {
					nestedAttributeName: "text"
				}, false);
				options = CommonUtil.addOption(options, {
					nestedAttributeValue: options.text
				}, false);
				options = CommonUtil.addOption(options, {
					nestedActions: function (oControl) {
						oControl.getParent().$().trigger("tap");
					}
				});
				options.actions = function (aTable) {
					var oTable = $.isArray(aTable[0]) ? aTable[0] : aTable;
					var sId = oTable.getId();
					options.id = sId;
					return this.iDoActionOnNestedControlByID(options);
				}.bind(this);
				return this.iDoActionByControlType(options);
			}
		},

		/**
		 * Toggle the selection of a specific row in a Table control, that is identified by a textual content.
		 * @public
		 * @param {map}          oOptionsOrText         				Option map containing any of the following properties:
		 * @param {string}       [oOptionsOrText.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptionsOrText.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptionsOrText.text]					Text that identifies the row to be selected
		 * @return {jQuery.promise}										A promise that gets resolved on success* 
		 * @memberof CommonTable
		 */
		iToggleRowSelectionInTableByTextContent: function (oOptionsOrText) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrText, "text");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["text"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				options.actions = function (aTable) {
					var oTable = $.isArray(aTable) ? aTable[0] : aTable;
					var sId = oTable.getId();
					options.id = sId;
					// Set viewName to "" full qualified id is resolved before
					options.viewName = "";
					options = CommonUtil.addOption(options, {
						nestedControlType: "sap.m.Text"
					}, false);
					options = CommonUtil.addOption(options, {
						nestedAttributeName: "text"
					}, false);
					options = CommonUtil.addOption(options, {
						nestedAttributeValue: options.text
					}, false);
					options = CommonUtil.addOption(options, {
						nestedActions: function (oText) {
							var oListItemBase = oText.getParent();
							while (!jQuery.isEmptyObject(oListItemBase) && !CommonUtil.isTypeOfUI5(oListItemBase, "sap.m.ListItemBase")) {
								oListItemBase = oListItemBase.getParent();
							}
							if (!jQuery.isEmptyObject(oListItemBase)) {
								var table = oListItemBase.getParent();
								table.setSelectedItem(oListItemBase, true, true);
							}
						}.bind(this)
					});
					return this.iDoActionOnNestedControlByID(options);
				}.bind(this);
				return this.iDoActionByControlType(options);
			}
		},

		/**
		 * Toggle the selection of a specific row in a Table control, that is identified by id.
		 * @public
		 * @param {map}          oOptions         				Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.id]					ID of the sap.m.Table control
		 * @param {string}       [oOptions.row]					Row to be selected
		 * @return {jQuery.promise}								A promise that gets resolved on success* 
		 * @memberof CommonTable
		 */
		iToggleRowSelectionInTableByRowAndID: function (oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["row", "id"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				options.actions = function (oTable) {
					var table;
					if (CommonUtil.isTypeOfUI5(oTable, "sap.ui.comp.smarttable.SmartTable")) {
						table = oTable.getTable();
					} else {
						table = oTable;
					}
					var aItems = table.getItems();
					table.setSelectedItem(aItems[options.row - 1], true, true);
				}.bind(this);
				return this.iDoActionByID(options);
			}
		}

	});
	CommonTable.assertions = new Opa5({

		/** Assertions **/

		/**
		 * Verify that a Table is visible, that is identified by its ID.
		 * @public
		 * @param {map/string}         		oOptionsOrID         			ID of Table or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrID.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.id]				ID of the sap.m.Table control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonTable
		 */
		iShouldSeeTableByID: function (oOptionsOrID) {
			var oOptions = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["id"])) {
				return this.iShouldSeeControlByID(oOptions);
			}
		},

		/**
		 * Verify that at least one item is contained in a Table control, that is identified by its ID.
		 * @public
		 * @param {map/string}         		oOptionsOrID         			ID of Table or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrID.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.id]				ID of the sap.m.Table control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonTable
		 */
		iShouldSeeItemsInTableByID: function (oOptionsOrID) {
			var oOptions = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["id"])) {
				return this.iShouldSeeItemsInListBaseByID(oOptions);
			}
		},

		/**
		 * Verify that at a specific number of items is contained in a Table control, that is identified by its ID.
		 * @public
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.m.Table control
		 * @param {number}      			[oOptions.length]			Expected number of items in the table
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonTable
		 */
		iShouldSeeLengthOfTableByID: function (oOptions) {
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["id", "length"])) {
				return this.iShouldSeeLengthOfListBaseByID(oOptions);
			}
		},

		/**
		 * Verify that at a specific number of items is contained in a Table control.
		 * @public
		 * @param {map}         			oOptionsOrLength         		Option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrLength.viewName]		Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {number}      			[oOptionsOrLength.length]		Expected number of items in the table
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonTable
		 */
		iShouldSeeLengthOfTable: function (oOptionsOrLength) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrLength, "length");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["length"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				return this.iShouldSeeLengthOfListBase(options);
			}
		},

		/**
		 * Verify that a Table is visible, that is identified by a textual content in the table.
		 * @public
		 * @param {map/string}     			oOptionsOrText         			Text of Table or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrText.viewName]		Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrText.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrText.text]			Text that is contained in the sap.m.Table control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonTable
		 */
		iShouldSeeTableByTextContent: function (oOptionsOrText) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrText, "text");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["text"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				options = CommonUtil.addOption(options, {
					nestedControlType: "sap.m.Text"
				}, false);
				options = CommonUtil.addOption(options, {
					nestedAttributeName: "text"
				}, false);
				options = CommonUtil.addOption(options, {
					nestedAttributeValue: options.text
				}, false);
				options = CommonUtil.addOption(options, {
					nestedSuccess: function (oControl) {
						Opa5.assert.ok(true, "Found table with text content '" + options.text + "'");
					}
				});
				options.success = function (aTable) {
					var oTable = aTable[0];
					var sId = oTable.getId();
					options.id = sId;
					return this.iShouldSeeSuccessOnNestedControlByID(options);
				}.bind(this);
				return this.iShouldSeeSuccessByControlType(options);
			}
		},

		/**
		 * Verify that a passed text content is contained in a Table, that is identified by its ID.
		 * @public
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.m.Table control
		 * @param {string}      			[oOptions.text]				Text that is contained in the sap.m.Table control
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonTable
		 */
		iShouldSeeTextContentInTableByID: function (oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["text", "id"])) {
				options = CommonUtil.addOption(options, {
					nestedControlType: "sap.m.Text"
				}, false);
				options = CommonUtil.addOption(options, {
					nestedAttributeName: "text"
				}, false);
				options = CommonUtil.addOption(options, {
					nestedAttributeValue: options.text
				}, false);
				options = CommonUtil.addOption(options, {
					nestedSuccess: function () {
						Opa5.assert.ok(true, "Found table with id '" + options.id + "' and text content '" + options.text + "'");
					}
				});
				return this.iShouldSeeSuccessOnNestedControlByID(options);
			}
		},

		/**
		 * Verify that the table with the given id is empty 
		 * @public
		 * @param {string}      	  [sTableId]	ID of the sap.m.Table control
		 * @return {jQuery.promise}	  A promise that gets resolved on success
		 * @memberof CommonTable
		 */
		iShouldSeeAnEmptyResponsiveTable: function (sTableId) {
			return this.waitFor({
				// controlType: "sap.m.Table",
				id: sTableId,
				matchers: new AggregationEmpty({
					name: "items"
				}),
				success: function (oTableOrArrayOfTables) {

					var oResponsiveTable = oTableOrArrayOfTables;
					// if the table id was given by a regex, we get an array of tables with the desired control on position 0
					if (Array.isArray(oResponsiveTable)) {
						oResponsiveTable = oResponsiveTable[0];
					}

					Opa5.assert.strictEqual(oResponsiveTable.getItems().length, 0,
						"The table " + sTableId + " is empty.");
				},
				errorMessage: "Did not find table with id " + sTableId + "."
			});
		}

	});

	return CommonTable;
});