/**
 * OPA Actions & Assertions for control sap.m.SearchField
 * @class CommonSearchField
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/EnterText",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"./CommonUtil"
], function(Opa5, EnterText, PropertyStrictEquals, CommonUtil) {
	"use strict";

	var mControlType = "sap.m.SearchField";

	var CommonSearchField = {};
	CommonSearchField.actions = new Opa5({
		/** Actions **/

		/**
		 * Enters a value in a Search Field control, that is identified by its ID.
		 * @public 
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the sap.m.SearchField
		 * @param {string}       [oOptions.value]					Value to be entered
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonSearchField
		 */
		iEnterValueInSearchFieldByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "value"])) {
				oOptions.actions = new EnterText({
					text: options.value
				});
				return this.iDoActionByID(options);
			}
		},

		/**
		 * Enters a value in a Search Field control, that is identified by an attribute.
		 * @public 
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.attributeName]			Name of the attribute of the sap.m.SearchField
		 * @param {string}       [oOptions.attributeValue]			Value of the attribute of the sap.m.SearchField 
		 * @param {string}       [oOptions.value]					Value to be entered
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonSearchField
		 */
		iEnterValueInSearchFieldByAttribute: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["value", "attributeName", "attributeValue"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				options.actions = new EnterText({
					text: options.value
				});
				CommonUtil.addMatchers(options, [new PropertyStrictEquals({
					name: options.attributeName,
					value: options.attributeValue
				})]);
				return this.iDoActionByControlType(options);
			}
		},

		/**
		 * Enters a value in a Search Field control.
		 * @public 
		 * @param {map/string}   oOptionsOrValue         				Value to be entered in a Search Field or option map containing any of the following properties:
		 * @param {string}       [oOptionsOrValue.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptionsOrValue.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}       [oOptionsOrValue.value]				Value to be entered
		 * @return {jQuery.promise}										A promise that gets resolved on success* 
		 * @memberof CommonSearchField
		 */
		iEnterValueInSearchField: function(oOptionsOrValue) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrValue, "value");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["value"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				options.actions = new EnterText({
					text: options.value
				});
				return this.iDoActionByControlType(options);
			}
		}
	});
	CommonSearchField.assertions = new Opa5({ 

		/** Assertions **/

		/**
		 * Verify that a SearchField is visible, that is identified by its ID.
		 * @public 
		 * @param {map/string}        		oOptionsOrID         			Option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrID.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}                  [oOptionsOrID.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.id]				ID of the sap.m.SearchField control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonSearchField
		 */
		iShouldSeeSearchFieldByID: function(oOptionsOrID) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id"])) {
				return this.iShouldSeeControlByID(options);
			}
		},
		
		/**
		 * Verify that the passed value is contained in a sap.m.SearchField control, that is identified by its ID
		 * @public 
		 * @param {map/string}        		oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}                  [oOptions.viewNamespace]Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.m.SearchField control
		 * @param {string}      			[oOptions.value]				Expected value of the sap.m.SearchField control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonSearchField
		 */
		iShouldSeeValueInSearchFieldByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "value"])) {
				options.attributeName = "text";
				options.attributeValue = options.value;
				options.fGetAttribute = function(oControl) {
					return oControl.getValue();
				};
				return this.iShouldSeeAttributeInControlByID(options);
			}
		},
		
		/**
		 * Verify that the passed value is contained in a sap.m.SearchField control
		 * @public 
		 * @param {map/string}        		oOptionsOrValue         		Option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrValue.viewName]		Name (id) of the surrounding view (optional)
		 * @param {string}                  [oOptionsOrValue.viewNamespace]    Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrValue.value]			Expected value of the sap.m.SearchField control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonSearchField
		 */
		iShouldSeeValueInSearchField: function(oOptionsOrValue) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrValue, "value");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["value"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				options.attributeName = "text";
				options.attributeValue = options.value;
				options.fGetAttribute = function(oControl) {
					return oControl.getValue();
				};
				return this.iShouldSeeAttributeInControl(options);
			}
		},
		
		/**
		 * Verify that the passed value is contained in a sap.m.SearchField control by an attribute.
		 * @public 
		 * @param {map/string}        		oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}                  [oOptions.viewNamespace]Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.attributeName]	Name of the attribute of the sap.m.SearchField
		 * @param {string}      			[oOptions.attributeValue]	Value of the attribute of the sap.m.SearchField 
		 * @param {string}      			[oOptions.value]			Expected value of the sap.m.SearchField control
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonSearchField
		 */
		iShouldSeeValueInSearchFieldByAttribute: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["attributeName", "attributeValue", "value"])) {
				return this.iShouldSeeControlByAttribute(oOptions);
			}	
		}
	});

	return CommonSearchField;
});