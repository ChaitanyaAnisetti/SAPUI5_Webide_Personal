/**
 * OPA Actions & Assertions for control sap.ui.comp.smartfield.SmartField
 * @class CommonSmartField
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/EnterText",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"./CommonUtil"
], function(Opa5, EnterText, PropertyStrictEquals, CommonUtil) {
	"use strict";

	var mControlType = "sap.ui.comp.smartfield.SmartField";

	var CommonSmartField = {};
	CommonSmartField.actions = new Opa5({

		/** Actions **/

		/**
		 * Enters a value in SmartField control, that is identified by its ID.
		 * @public 
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.id]						ID of the sap.ui.comp.smartfield.SmartField
		 * @param {string}       [oOptions.value]					Value to be entered
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonSmartField
		 */
		iEnterValueInSmartFieldByID: function(oOptions) {
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["id", "value"])) {
				oOptions.actions = new EnterText({
					text: oOptions.value
				});
				return this.iDoActionByID(oOptions);
			}
		},

		/**
		 * Enters a value in SmartField control, that is identified by its text label.
		 * @public 
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]		    Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.textLabel]				Text Label of the sap.ui.comp.smartfield.SmartField
		 * @param {string}       [oOptions.value]					Value to be entered
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonSmartField
		 */
		iEnterValueInSmartFieldByTextLabel: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["textLabel", "value"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				CommonUtil.addMatchers(options, [new PropertyStrictEquals({
					name: "textLabel",
					value: options.textLabel
				})]);
				options.actions = new EnterText({
					text: options.value
				});
				return this.iDoActionByControlType(options);
			}
		},

		/**
		 * Selects an key of a Combo Box in a Smart Field, that is identified by its text label.
		 * @public 
		 * @param {map}          oOptions         					Option map containing any of the following properties:
		 * @param {string}       [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptions.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}       [oOptions.textLabel]				Text Label of the combobox
		 * @param {string}       [oOptions.key]						Key of the item to be selected
		 * @return {jQuery.promise}									A promise that gets resolved on success* 
		 * @memberof CommonSmartField
		 */
		iSelectKeyInSmartFieldAsComboBoxByTextLabel: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["textLabel", "key"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				CommonUtil.addMatchers(options, [new PropertyStrictEquals({
					name: "textLabel",
					value: options.textLabel
				})]);
				options.actions = function(aTable) {
					var oTable = $.isArray(aTable) ? aTable[0] : aTable;
					var sId = oTable.getId();
					options.id = sId;
					options = CommonUtil.addOption(options, {
						nestedControlType: "sap.m.ComboBox"
					}, false);
					options = CommonUtil.addOption(options, {
						nestedActions: function(oCombobox) {
							oCombobox.setSelectedKey(options.key);
							oCombobox.fireSelectionChange(null);
						}
					});
					return this.iDoActionOnNestedControlByID(options);
				}.bind(this);
				return this.iDoActionByControlType(options);
			}
		}
	});
	CommonSmartField.assertions = new Opa5({ 
		/** Assertions **/

		/**
		 * Verify that a SmartField is visible, that is identified by its ID.
		 * @public 
		 * @param {map/string}     			oOptionsOrID         			ID of the Smart Field or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrID.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.id]				ID of the sap.ui.comp.smartfield.SmartField
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonSmartField
		 */
		iShouldSeeSmartFieldByID: function(oOptionsOrID) {
			var options = CommonUtil.resolveStringOrAttribute((oOptionsOrID), "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id"])) {
				return this.iShouldSeeControlByID(options);
			}
		},

		/**
		 * Verify that a SmartField is visible, that is identified by its text label.
		 * @public 
		 * @param {map}         			oOptionsOrTextLabel         			Option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrTextLabel.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.viewNamespace]			Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrTextLabel.textLabel]			Text Label of the sap.ui.comp.smartfield.SmartField
		 * @return {jQuery.promise}													A promise that gets resolved on success
		 * @memberof CommonSmartField
		 */
		iShouldSeeSmartFieldByTextLabel: function(oOptionsOrTextLabel) {
			var oOptions = CommonUtil.resolveStringOrAttribute((oOptionsOrTextLabel), "textLabel");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["textLabel"])) {
				oOptions = CommonUtil.addOption(oOptions, {
					controlType: mControlType
				}, false);
				CommonUtil.addMatchers(oOptions, [new PropertyStrictEquals({
					name: "textLabel",
					value: oOptions.textLabel
				})]);
				return this.iShouldSeeControlByControlType(oOptions);
			}
		},

		/**
		 * Verify that a passed value is contained in a Smart Field control, that is identified by its ID
		 * @public 
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.ui.comp.smartfield.SmartField control
		 * @param {string}      			[oOptions.value]			Expected Value of the sap.ui.comp.smartfield.SmartField control
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonSmartField
		 */
		iShouldSeeValueInSmartFieldByID: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id", "value"])) {
				options.attributeName = "value";
				options.attributeValue = options.value;
				options.fGetAttribute = function(oControl) {
					return oControl.getValue();
				};
				return this.iShouldSeeAttributeInControlByID(options);
			}
		},

		/**
		 * Verify that a passed value is contained in a Smart Field control, that is identified by its text label
		 * @public 
		 * @param {map}         			oOptions         			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.viewNamespace]Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.textLabel]		Text Label of the sap.ui.comp.smartfield.SmartField control
		 * @param {string}      			[oOptions.value]			Expected Value of the sap.ui.comp.smartfield.SmartField control
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonSmartField
		 */
		iShouldSeeValueInSmartFieldByTextLabel: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["textLabel", "value"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				CommonUtil.addMatchers(options, [new PropertyStrictEquals({
					name: "textLabel",
					value: options.textLabel
				})]);
				options.attributeName = "value";
				options.attributeValue = options.value;
				options.fGetAttribute = function(oControl) {
					return oControl.getValue();
				};
				return this.iShouldSeeAttributeInControl(options);
			}
		}

	});

	return CommonSmartField;
});