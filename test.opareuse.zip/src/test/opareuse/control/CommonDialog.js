/**
 * OPA Actions & Assertions for control sap.m.Dialog
 * @class CommonDialog
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"./CommonUtil"
], function (Opa5, PropertyStrictEquals, CommonUtil) {
	"use strict";

	var mControlType = "sap.m.Dialog";

	var CommonDialog = {};
	CommonDialog.actions = {}; // no actions defined
	CommonDialog.assertions = new Opa5({
		/** Assertions **/

		/**
		 * Verify that a Dialog is visible, that is identified by its ID.
		 * @public 
		 * @param {map/string}    			oOptionsOrID        		ID of the dialog or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrID.viewName]		Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.id]			ID of the sap.m.Dialog control
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonDialog
		 */
		iShouldSeeDialogByID: function (oOptionsOrID) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrID, "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["id"])) {
				// Skip viewName for dialog
				options = CommonUtil.addOption(options, {
					viewName: ""
				}, false);
				return this.iShouldSeeControlByID(options);
			}
		},

		/**
		 * Verify that a dialog is visible, that is identified by its title.
		 * @public 
		 * @param {map/string}     			oOptionsOrTitle         		Title of the dialog or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrTitle.viewName]		Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrTitle.title]			Title of the dialog
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonDialog
		 */
		iShouldSeeDialogByTitle: function (oOptionsOrTitle) {
			var options = CommonUtil.resolveStringOrAttribute((oOptionsOrTitle), "title");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["title"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				CommonUtil.addMatchers(options, [new PropertyStrictEquals({
					name: "title",
					value: options.title
				})]);
				options.viewName = "";
				return this.iShouldSeeControlByControlType(options);
			}
		},

		/**
		 * Verify that a dialog is visible, that is identified by its i18n-key.
		 * @public
		 * @param {map}         			oOptionsOrKey        		Option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrKey.viewName]	Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrKey.key]			I18n-key of the dialog
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonDialog
		 */
		iShouldSeeDialogByI18nKey: function (oOptionsOrKey) {
			var options = CommonUtil.resolveStringOrAttribute((oOptionsOrKey), "key");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["key"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType,
					propertyName: "title"
				}, false);
				return this.iShouldSeeControlByI18nKey(options);
			}
		},

		/**
		 * Verify that a message toast is shown
		 * @public
		 * @return {jQuery.promise}	a promise that gets resolved on success
		 * @memberof CommonDialog
		 */
		iShouldSeeMessageToast: function () {
			return this.waitFor({
				// Turn off autoWait    
				autoWait: false,
				check: function () {
					// Locate the message toast in the DOM using its class name
					// since the Opa tests are running in an iFrame, we use the jQuery object in the iFrame    
					return Opa5.getJQuery()(".sapMMessageToast").length > 0;
				},
				success: function () {
					Opa5.assert.ok(true, "The message toast was shown");
				},
				errorMessage: "The message toast did not show up"
			});
		}
	});

	return CommonDialog;
});