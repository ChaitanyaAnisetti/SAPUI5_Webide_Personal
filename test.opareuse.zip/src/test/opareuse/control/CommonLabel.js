/**
 * OPA Actions & Assertions for control sap.m.Label
 * @class CommonLabel
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"./CommonUtil"
], function(Opa5, PropertyStrictEquals, CommonUtil) {
	"use strict";

	var mControlType = "sap.m.Label";

	var CommonLabel = {};
	CommonLabel.actions = {};
	CommonLabel.assertions = new Opa5({

		/** Assertions **/

		/**
		 * Verify that a label is visible, that is identified by its ID.
		 * @public
		 * @param {map/string}     			oOptionsOrID         			ID of the Label or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrID.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrID.id]				ID of the sap.m.Label control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonLabel
		 */
		iShouldSeeLabelByID: function(oOptionsOrID) {
			var oOptions = CommonUtil.resolveStringOrAttribute((oOptionsOrID), "id");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["id"])) {
				return this.iShouldSeeControlByID(oOptions);
			}
		},

		/**
		 * Verify that a label is visible, that is identified by its text.
		 * @public
		 * @param {map/string}     			oOptionsOrText         			Text of the Label or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrText.viewName]		Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrText.text]			Text of the sap.m.Label control
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonLabel
		 */
		iShouldSeeLabelByText: function(oOptionsOrText) {
			var oOptions = CommonUtil.resolveStringOrAttribute((oOptionsOrText), "text");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["text"])) {
				oOptions = CommonUtil.addOption(oOptions, {
					controlType: mControlType
				}, false);
				CommonUtil.addMatchers(oOptions, [new PropertyStrictEquals({
					name: "text",
					value: oOptions.text
				})]);
				return this.iShouldSeeControlByControlType(oOptions);
			}
		},

		/**
		 * Verify that passed text is contained in a sap.m.Label control, that is identified by its ID
		 * @public 
		 * @param {map}         			oOptions        			Option map containing any of the following properties:
		 * @param {string}      			[oOptions.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptions.id]				ID of the sap.m.Label control
		 * @param {string}      			[oOptions.text]				Expected Text of the sap.m.Text control
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonLabel
		 */
		iShouldSeeTextInLabelByID: function(oOptions) {
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(oOptions), ["id", "text"])) {
				return this.iShouldSeeTextInControlByID(oOptions);
			}
		},

		/**
		 * Verify that a label is visible, that is identified by its i18n-key.
		 * @public
		 * @param {map}         			oOptionsOrKey         		Option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrKey.viewName]	Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptions.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrKey.key]			I18n-key of the sap.m.Label control
		 * @return {jQuery.promise}										A promise that gets resolved on success
		 * @memberof CommonLabel
		 */
		iShouldSeeLabelByI18nKey: function(oOptionsOrKey) {
			var options = CommonUtil.resolveStringOrAttribute((oOptionsOrKey), "key");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["key"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				return this.iShouldSeeControlByI18nKey(options);
			}
		}
	});

	return CommonLabel;
});