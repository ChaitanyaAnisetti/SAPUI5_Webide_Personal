/**
 * OPA Actions & Assertions for control sap.ui.comp.smartfilterbar.SmartFilterBar
 * @class CommonSmartFilterBar
 */
sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/EnterText",
	"sap/ui/test/actions/Press",
	"./CommonUtil"
], function(Opa5, EnterText, Press, CommonUtil) {
	"use strict";

	var mControlType = "sap.ui.comp.smartfilterbar.SmartFilterBar";

	/*function createIdForFilterItem(sFilterBarId, sEntityPropertyName) {
		return sFilterBarId + "-filterItem-___INTERNAL_-" + sEntityPropertyName;
	}*/

	var CommonSmartFilterBar = {};
	CommonSmartFilterBar.actions = new Opa5({
		/** Actions **/

		/**
		 * Enters a value in the Basic Search of a Smart Filter Bar control.
		 * @public 
		 * @param {map/string}   oOptionsOrValue         				Value to be entered in Basic Search of Smart Filter Bar or option map containing any of the following properties:
		 * @param {string}       [oOptionsOrValue.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}       [oOptionsOrValue.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}       [oOptionsOrValue.value]				Value to be entered
		 * @return {jQuery.promise}										A promise that gets resolved on success* 
		 * @memberof CommonSmartFilterBar
		 */
		iEnterValueInBasicSearchOfSmartFilterBar: function(oOptionsOrValue) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrValue, "value");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["value"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				options.actions = function(aFilterBar) {
					var oFilterBar = $.isArray(aFilterBar) ? aFilterBar[0] : aFilterBar;
					var sId = oFilterBar.getId();
					return this.iDoActionByID({
						id: sId + "-btnBasicSearch",
						actions: new EnterText({
							text: options.value
						})
					});
				}.bind(this);
				return this.iDoActionByControlType(options);
			}
		},

		/**
		 * Enters a value in a filter of a Smart Filter Bar control.
		 * @public 
		 * @param {map} 		oOptions         				Option map containing any of the following properties:
		 * @param {string}      [oOptions.viewName]				Name (id) of the surrounding view (optional)
		 * @param {string}      [oOptions.viewNamespace]		Namespace of the surrounding view (optional)
		 * @param {string}      [oOptions.entityType]			Entity Type of filter
		 * @param {string}      [oOptions.value]				Value to be entered in filter of Smart Filter Bar
		 * @return {jQuery.promise}								A promise that gets resolved on success* 
		 * @memberof CommonSmartFilterBar
		 */
		/*iEnterValueInFilterByEntityTypeInSmartFilterBar: function(oOptions) {
			var options = oOptions;
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["value", "entityType"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				options.success = function(aFilterBar) {
					var oFilterBar = aFilterBar[0] || aFilterBar;
					var sId = oFilterBar.getId();
					return this.iDoActionByID({
						id: createIdForFilterItem(sId, options.entityType),
						actions: new EnterText({
							text: oOptions.value
						})
					});
				}.bind(this);
				return this.iDoSuccessByControlType(options);
			}
		},*/

		/**
		 * Presses the Filter button in a Smart FilterBar
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonSmartFilterBar
		 */
		iPressFilterButtonInSmartFilterBar: function() {
			var options = {
				controlType: mControlType
			};
			options.actions = function(aFilterBar) {
				var oFilterBar = aFilterBar[0] || aFilterBar;
				var sId = oFilterBar.getId();
				return this.iDoActionByID({
					id: sId + "-btnFilters",
					actions: new Press()
				});
			}.bind(this);
			return this.iDoActionByControlType(options);
			//return this.iPressButtonByIDInControlOfType({buttonID: "btnFilters", controlType: mControlType}); 
		},

		/**
		 * Presses the Go button in a Smart FilterBar
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonSmartFilterBar
		 */
		iPressGoButtonInSmartFilterBar: function() {
			var options = {
				controlType: mControlType
			};
			options.actions = function(aFilterBar) {
				var oFilterBar = aFilterBar[0] || aFilterBar;
				var sId = oFilterBar.getId();
				return this.iDoActionByID({
					id: sId + "-btnGo",
					actions: new Press()
				});
			}.bind(this);
			return this.iDoActionByControlType(options);
		},

		/**
		 * Presses the Restore button in a Smart FilterBar
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonSmartFilterBar
		 */
		iPressRestoreButtonInSmartFilterBar: function() {
			var options = {
				controlType: mControlType
			};
			options.actions = function(aFilterBar) {
				var oFilterBar = aFilterBar[0] || aFilterBar;
				var sId = oFilterBar.getId();
				return this.iDoActionByID({
					id: sId + "-btnRestore",
					actions: new Press()
				});
			}.bind(this);
			return this.iDoActionByControlType(options);
		},

		/**
		 * Presses the Clear button in a Smart FilterBar
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonSmartFilterBar
		 */
		iPressClearButtonInSmartFilterBar: function() {
			var options = {
				controlType: mControlType
			};
			options.actions = function(aFilterBar) {
				var oFilterBar = aFilterBar[0] || aFilterBar;
				var sId = oFilterBar.getId();
				return this.iDoActionByID({
					id: sId + "-btnClear",
					actions: new Press()
				});
			}.bind(this);
			return this.iDoActionByControlType(options);
		},

		/**
		 * Presses the Go button in the Smart FilterBar Dialog
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonSmartFilterBar
		 */
		iPressGoButtonInSmartFilterDialog: function() {
			return this.iPressButtonByID("smartFilterBar-btnGoFilterDialog");
		},

		/**
		 * Presses the Restore button in the Smart FilterBar Dialog
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonSmartFilterBar
		 */
		iPressRestoreButtonInSmartFilterDialog: function() {
			return this.iPressButtonByID("smartFilterBar-btnRestoreFilterDialog");
		},
		
		/**
		 * * abhängig von iPressfilterbuttoninsmallfilterbar
		 * Presses the Cancel button in the Smart FilterBar Dialog
		 * @return {jQuery.promise}											A promise that gets resolved on success
		 * @memberof CommonSmartFilterBar
		 */
		iPressCancelButtonInSmartFilterDialog: function() {
			return this.iPressButtonByID("smartFilterBar-btnCancelFilterDialog");
		}
	});
	CommonSmartFilterBar.assertions = new Opa5({
		/** Assertions **/
		/**
		 * Verify that a SmartFilterBar is visible, that is identified by its ID.
		 * @public 
		 * @param {map/string}     			oOptionsOrEntityPropertyName         			ID of the Smart Filter Bar or option map containing any of the following properties:
		 * @param {string}      			[oOptionsOrEntityPropertyName.viewName]			Name (id) of the surrounding view (optional)
		 * @param {string}      			[oOptionsOrEntityPropertyName.viewNamespace]	Namespace of the surrounding view (optional)
		 * @param {string}  				[oOptions.entityType]							Entity Type of filter
		 * @return {jQuery.promise}															A promise that gets resolved on success
		 * @memberof CommonSmartFilterBar
		 */
		/*iShouldSeeFilterByEntityTypeInSmartFilterBar: function(oOptionsOrEntityPropertyName) {
			var options = CommonUtil.resolveStringOrAttribute(oOptionsOrEntityPropertyName, "entityType");
			// Validate passed options with list of mandatory options
			if (CommonUtil.validateOptions(Object.keys(options), ["entityType"])) {
				options = CommonUtil.addOption(options, {
					controlType: mControlType
				}, false);
				options.success = function(aFilterBar) {
					var oFilterBar = aFilterBar[0];
					var sId = oFilterBar.getId();
					return this.iShouldSeeControlByID(createIdForFilterItem(sId, options.entityPropertyName));
				}.bind(this);
				return this.iDoSuccessByControlType(options);
			}
		}*/
	});

	return CommonSmartFilterBar;
});