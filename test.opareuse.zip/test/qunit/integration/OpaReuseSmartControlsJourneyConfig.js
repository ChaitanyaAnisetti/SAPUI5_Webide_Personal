jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"sap/ui/test/opaQunit",
	"test/opareuse/control/CommonPageObject",
	"opa5test/pageObjects/OpaReuse" // the page object
], function (Opa5, opaQunit, CommonPageObject, OpaReuse) {
	"use strict";

	Opa5.extendConfig({
		autoWait: true,
		arrangements: CommonPageObject.getArrangement(),
		viewNamespace: ""
	});

	sap.ui.require([
		"opa5test/OpaReuseSmartControlsJourney"
	], function () {
		QUnit.config.testTimeout = 7000 * 1000;
		QUnit.start();
	});
});