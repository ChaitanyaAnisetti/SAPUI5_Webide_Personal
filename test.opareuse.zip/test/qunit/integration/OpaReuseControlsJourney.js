sap.ui.define([
	"sap/ui/test/opaQunit",
	"sap/ui/test/Opa5"
], function (opaTest, Opa5) {
	"use strict";

	var sResourcePath = "testapp/app/index";

	// Semantic object
	var sSemanticObject = "opareuselib";

	// Action names
	var sActionDisplay = "controls";

	module("OPA5 Reuse Asserts Journey");

	Opa5.extendConfig({
		timeout: 21
	});

	/** Checks on sap.ui.core.Control **/
	/* Because of performance problems this Journey has to have only one teardown and one startup
	src: https://sapui5.hana.ondemand.com/1.32.11/docs/guide/10592affce3e4f1ba73c3125ee06e0b7.html*/
	// Assertions
	opaTest("I should see sap.ui.core.Control by its id", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay,
			timeout: 30
		});
		Then.onMyPageUnderTest.iShouldSeeControlByID({
			id: "__xmlview0--lblOne"
		});
	});

	opaTest("I should see sap.ui.core.Control by its id and an additional matcher", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeControlByID({
			id: "__xmlview0--inputOne",
			matchers: [
				new sap.ui.test.matchers.PropertyStrictEquals({
					name: "placeholder",
					value: "Enter Text"
				})
			]
		});
	});

	opaTest("I should see sap.ui.core.Control by its text", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeControlByText({
			text: "Foo Label"
		});
	});

	opaTest("I should see sap.ui.core.Control by its i18n-key", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeControlByI18nKey({
			key: "fooText"
		});
	});

	opaTest("I should see sap.ui.core.Control by given attribute", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeControlByAttribute({
			attributeName: "maxLines",
			attributeValue: 2
		});
	});

	/** Checks on sap.m.Button **/
	// Assertions
	opaTest("I should see button by its ID", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeButtonByID({
			id: "__xmlview0--btnOne"
		});
	});
	opaTest("I should see button by its icon", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeButtonByIcon({
			icon: "sap-icon://home"
		});
	});

	opaTest("I should see button by its i18n-key", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeButtonByI18nKey({
			key: "fooButton"
		});
	});
	/**ToggleButton Action**/
	opaTest("I press toggle button by its icon", function (Given, When, Then) {
		When.onMyPageUnderTest.iPressButtonByIcon({
			icon: "sap-icon://home"
		});
		Then.onMyPageUnderTest.iShouldSeeLabelByText({
			id: "__xmlview0--lblToggleButton",
			text: "ToggleButton Pressed: 1"
		});
		Then.onMyPageUnderTest.iShouldSeeAttributeInControlByID({
			id: "__xmlview0--toggleOne",
			fGetAttribute: function (oControl) {
				return oControl.getPressed();
			},
			attributeName: "pressed",
			attributeValue: true,
			value: true
		});
		When.onMyPageUnderTest.iPressButtonByIcon({ //press toggle button again to return to pristine main view for further tests
			icon: "sap-icon://home"
		});
	});

	/** Checks on sap.m.ComboBox **/
	// Assertions
	opaTest("I should see sap.m.ComboBox by its ID", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeComboBoxByID({
			id: "__xmlview0--cbOne"
		});
	});

	// Actions
	opaTest("I select item in sap.m.ComboBox by item and id", function (Given, When, Then) {
		When.onMyPageUnderTest.iSelectItemInComboBoxByID({
			id: "__xmlview0--cbOne",
			item: "Flat Medium"
		});
		Then.onMyPageUnderTest.iShouldSeeValueInInputByID({
			id: "__xmlview0--cbOne",
			value: "Flat Medium"
		});
	});

	opaTest("I select item in sap.m.ComboBox by key and id", function (Given, When, Then) {
		When.onMyPageUnderTest.iSelectKeyInComboBoxByID({
			id: "__xmlview0--cbOne",
			key: "214-121-828"
		});
		Then.onMyPageUnderTest.iShouldSeeValueInInputByID({
			id: "__xmlview0--cbOne",
			value: "Laptop Case"
		});
	});

	/** Checks on sap.m.MultiComboBox **/
	// Assertions
	opaTest("I should see sap.m.MultiComboBox by its ID", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeMultiComboBoxByID({
			id: "__xmlview0--mcbOne"
		});
	});

	opaTest("I should see given keys in sap.m.MultiComboBox by keys (array) and id", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeKeysInMultiComboBoxByID({
			id: "__xmlview0--mcbOne",
			keys: ["1239102", "P1239823"]
		});
	});

	opaTest("I should see given keys in sap.m.MultiComboBox by keys (string) and id", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeKeysInMultiComboBoxByID({
			id: "__xmlview0--mcbOne",
			keys: "1239102,P1239823"
		});
	});

	/** Checks on sap.m.Select **/
	// Assertions
	opaTest("I should see sap.m.Select by its ID", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeSelectByID({
			id: "__xmlview0--selOne"
		});
	});

	// Actions
	opaTest("I select item in sap.m.Select by item and id", function (Given, When, Then) {
		When.onMyPageUnderTest.iSelectItemInSelectByID({
			id: "__xmlview0--selOne",
			item: "Flat Medium"
		});
		Then.onMyPageUnderTest.iShouldSeeKeyInSelectByID({
			id: "__xmlview0--selOne",
			key: "870394932"
		});
		Then.onMyPageUnderTest.iShouldSeeValueInSelectByID({
			id: "__xmlview0--selOne",
			value: "Flat Medium"
		});

	});

	opaTest("I select item in sap.m.Select by key and id", function (Given, When, Then) {
		When.onMyPageUnderTest.iSelectKeyInSelectByID({
			id: "__xmlview0--selOne",
			key: "214-121-828"
		});
		Then.onMyPageUnderTest.iShouldSeeKeyInSelectByID({
			id: "__xmlview0--selOne",
			key: "214-121-828"
		});
		Then.onMyPageUnderTest.iShouldSeeValueInSelectByID({
			id: "__xmlview0--selOne",
			value: "Laptop Case"
		});
	});

	/** Checks on sap.m.Text **/
	// Assertions
	opaTest("I should see sap.m.Text by ID", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeTextByID({
			id: "__xmlview0--txtOne"
		});
	});

	opaTest("I should see sap.m.Text", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeText({
			text: "Foo Text"
		});
	});

	opaTest("I should see sap.m.Text by its i18n-key", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeTextByI18nKey({
			key: "fooText"
		});
	});

	opaTest("I should see text in sap.m.Text", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeTextInTextByID({
			id: "__xmlview0--txtOne",
			text: "Foo Text"
		});
	});

	/** Checks on sap.m.Title **/
	// Assertions
	opaTest("I should see sap.m.Title by ID", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeTitleByID({
			id: "__xmlview0--pageOne"
		});
	});

	opaTest("I should see sap.m.Title by text", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeTitleByText({
			text: "Foo Title"
		});
	});

	opaTest("I should see sap.m.Title by its i18n-key", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeTitleByI18nKey({
			key: "fooTitle"
		});
	});

	// /** Checks on sap.m.Input / InputBase **/
	// Assertions
	opaTest("I should see sap.m.Input by ID", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeInputByID({
			id: "__xmlview0--inputOne"
		});
	});

	opaTest("I should see sap.m.Input by value", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeInputByValue({
			value: "Input Text"
		});
	});

	opaTest("I should see value in sap.m.Input", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeValueInInputByID({
			id: "__xmlview0--inputOne",
			value: "Input Text"
		});
	});

	/** Checks on sap.m.Label **/
	// Assertions
	opaTest("I should see sap.m.Label by its ID", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeLabelByID({
			id: "__xmlview0--lblOne"
		});
	});

	opaTest("I should see sap.m.Label by its text", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeLabelByText({
			text: "Foo Label"
		});
	});

	opaTest("I should see sap.m.Label by its i18n-key", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeLabelByI18nKey({
			key: "fooLabel"
		});
	});

	opaTest("I should see given text in sap.m.Label by its ID", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeTextInLabelByID({
			id: "__xmlview0--lblOne",
			text: "Foo Label"
		});
	});

	/** Checks on sap.m.Link **/
	// Assertions
	opaTest("I should see sap.m.Link by its id", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeLinkByID({
			id: "__xmlview0--lnkOne"
		});
	});

	opaTest("I should see sap.m.Link by its text", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeLinkByText({
			text: "Foo Link"
		});
	});

	opaTest("I should see sap.m.Link by its i18n-key", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeLinkByI18nKey({
			key: "fooLink"
		});
	});

	/** Check on sap.m.ListBase**/
	// Assertions
	opaTest("I should see sap.m.ListBase by its id", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeListBaseByID({
			id: "__xmlview0--tblOne"
		});
	});

	/** Checks on sap.m.Page **/
	// Assertions
	opaTest("I should see page by ID", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeePageByID({
			id: "__xmlview0--pageOne"
		});
	});

	opaTest("I should see page by title", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeePageByTitle({
			title: "Foo Title"
		});
	});

	opaTest("I should see page by i18n-key", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeePageByI18nKey({
			key: "fooTitle"
		});
	});

	opaTest("I should see title in page by ID", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeTitleInPageByID({
			id: "__xmlview0--pageOne",
			title: "Foo Title"
		});
	});

	/** Checks on sap.m.SearchField **/
	// Assertions
	opaTest("I should see sap.m.SearchField by ID", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeSearchFieldByID({
			id: "fooSearchField"
		});
	});

	/** Checks on sap.m.Table **/
	// Assertions
	opaTest("I should see table by ID", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeTableByID({
			id: "__xmlview0--tblOne"
		});
	});

	opaTest("I should see table with at least one item", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeItemsInTableByID({
			id: "__xmlview0--tblOne"
		});
	});

	opaTest("I should see table with number of items by ID", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeLengthOfTableByID({
			id: "__xmlview0--tblOne",
			length: 5
		});
	});

	opaTest("I should see table with number of items", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeLengthOfTable({
			length: 5
		});
	});

	opaTest("I should see table by text content", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeTableByTextContent("Flat S");
	});

	opaTest("I should see text content in table by id", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeTextContentInTableByID({
			id: "__xmlview0--tblOne",
			text: "Flat X-large II"
		});
	});

	/** Checks on sap.ushell.ui.shell.ShellAppTitle **/
	// Assertions
	opaTest("I should see shell app title by text", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeAppTitleByText("Foo App Title");
	});

	opaTest("I press user button in unified shell", function (Given, When, Then) {
		When.onMyPageUnderTest.iPressMeButton();
		Then.onMyPageUnderTest.iShouldSeeTitleByText({
			viewName: "",
			text: "Default User"
		});
		When.onMyPageUnderTest.iPressMeButton(); //press me button again to return to main view for further tests
		//the last test of the journey should also do a teardown
		When.onMyPageUnderTest.iTeardownMyAppFrame();
	});

	module("OPA5 Reuse Actions Journey");

	Opa5.extendConfig({
		timeout: 50
	});

	/** Checks on sap.m.Button **/
	// Actions
	opaTest("I press button by its i18n-key", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPressButtonByI18nKey({
			key: "fooButton"
		});
		Then.onMyPageUnderTest.iShouldSeeButtonByText({
			text: "Button Pressed: 1"
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I press button by its text", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPressButtonByText({
			text: "Foo Button"
		});
		Then.onMyPageUnderTest.iShouldSeeButtonByText({
			text: "Button Pressed: 1"
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I press button by its ID", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPressButtonByID({
			id: "__xmlview0--btnOne"
		});
		Then.onMyPageUnderTest.iShouldSeeButtonByText({
			id: "__xmlview0--btnOne",
			text: "Button Pressed: 1"
		}).and.iTeardownMyAppFrame();
	});

	/*opaTest("I press button within parent control", function(Given, When, Then) {
		When.onMyPageUnderTest.iPressButtonByIDInControlOfType({
			controlType: "sap.m.Page",
			buttonID: "btnOne"
		});
		Then.onMyPageUnderTest.iShouldSeeLabelByText({
			id: "__xmlview0--lblToggleButton",
			text: "Button Pressed: 2"
		});
	});*/

	/** Checks on sap.m.MultiComboBox **/
	// Actions
	opaTest("I select items in sap.m.MultiComboBox by keys (array) and id", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iSelectKeysInMultiComboBoxByID({
			id: "__xmlview0--mcbOne",
			keys: ["22134T", "1239102"]
		});
		Then.onMyPageUnderTest.iShouldSeeKeysInMultiComboBoxByID({
			id: "__xmlview0--mcbOne",
			keys: ["22134T", "1239102"]
		});
		Then.onMyPageUnderTest.iShouldSeeKeysInMultiComboBoxByID({
			id: "__xmlview0--mcbOne",
			keys: ["1239102", "22134T"]
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I select items in sap.m.MultiComboBox by keys (string) and id", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iSelectKeysInMultiComboBoxByID({
			id: "__xmlview0--mcbOne",
			keys: "K47322.1,2212-121-828"
		});
		Then.onMyPageUnderTest.iShouldSeeKeysInMultiComboBoxByID({
			id: "__xmlview0--mcbOne",
			keys: "K47322.1,2212-121-828"
		}).and.iTeardownMyAppFrame();
	});

	/** Checks on sap.m.Text **/
	// Actions
	opaTest("I enter text in input by ID", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iEnterValueInInputByID({
			id: "__xmlview0--inputOne",
			value: "Entered Value"
		});
		Then.onMyPageUnderTest.iShouldSeeValueInInputByID({
			id: "__xmlview0--inputOne",
			value: "Entered Value"
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I enter text in input by current value", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iEnterValueInInputByID({
			id: "__xmlview0--inputOne",
			value: "Entered Value"
		});
		When.onMyPageUnderTest.iEnterValueInInputByValue({
			newValue: "Changed Value",
			value: "Entered Value"
		});
		Then.onMyPageUnderTest.iShouldSeeValueInInputByID({
			id: "__xmlview0--inputOne",
			value: "Changed Value"
		}).and.iTeardownMyAppFrame();
	});

	/** Checks on sap.m.Link **/
	// Actions
	opaTest("I press link by its i18n-key", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPressLinkByI18nKey({
			key: "fooLink"
		});
		Then.onMyPageUnderTest.iShouldSeeLinkByText({
			text: "Link Pressed: 1"
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I press link by its text", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPressLinkByI18nKey({
			key: "fooLink"
		});
		When.onMyPageUnderTest.iPressLinkByText({
			text: "Link Pressed: 1"
		});
		Then.onMyPageUnderTest.iShouldSeeLinkByText({
			text: "Link Pressed: 2"
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I press link by ID", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPressLinkByI18nKey({
			key: "fooLink"
		});
		When.onMyPageUnderTest.iPressLinkByText({
			text: "Link Pressed: 1"
		});
		When.onMyPageUnderTest.iPressLinkByID({
			id: "__xmlview0--lnkOne"
		});

		Then.onMyPageUnderTest.iShouldSeeLinkByText({
			text: "Link Pressed: 3"
		}).and.iTeardownMyAppFrame();
	});

	/** Checks on sap.m.SearchField **/
	// Actions
	opaTest("I enter value in sap.m.SearchField", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iEnterValueInSearchField({
			id: "fooSearchField",
			value: "fooSearchField Value"
		});
		Then.onMyPageUnderTest.iShouldSeeValueInSearchField({
			id: "fooSearchField",
			value: "fooSearchField Value"
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I enter value in sap.m.SearchField by ID", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iEnterValueInSearchFieldByID({
			id: "fooSearchField",
			value: "fooSearchField Value by ID"
		});
		Then.onMyPageUnderTest.iShouldSeeValueInSearchFieldByID({
			id: "fooSearchField",
			value: "fooSearchField Value by ID"
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I enter value in sap.m.SearchField by attribute", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iEnterValueInSearchFieldByID({
			id: "fooSearchField",
			value: "fooSearchField Value by ID"
		});
		When.onMyPageUnderTest.iEnterValueInSearchFieldByAttribute({
			attributeName: "value",
			attributeValue: "fooSearchField Value by ID",
			value: "fooSearchField Value by attribute"
		});
		Then.onMyPageUnderTest.iShouldSeeValueInSearchFieldByAttribute({
			attributeName: "placeholder",
			attributeValue: "fooPlaceholder",
			value: "fooSearchField Value by attribute"
		}).and.iTeardownMyAppFrame();
	});

	/** Checks on sap.m.Table **/
	// Actions
	opaTest("I press on row in table by id", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPressOnRowInTableByID({
			id: "__xmlview0--tblOne",
			row: 3
		});
		Then.onMyPageUnderTest.iShouldSeeLabelByText({
			text: "Table - Navigation Pressed: 1"
		});
		Then.onMyPageUnderTest.iShouldSeeTextInLabelByID({
			id: "__xmlview0--lblTableNavPressItem",
			text: "Table - Pressed Item: Flat S"
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I press on row in table", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPressOnRowInTableByID({
			id: "__xmlview0--tblOne",
			row: 3
		});
		When.onMyPageUnderTest.iPressOnRowInTable(4);
		Then.onMyPageUnderTest.iShouldSeeLabelByText({
			text: "Table - Navigation Pressed: 2"
		});
		Then.onMyPageUnderTest.iShouldSeeTextInLabelByID({
			id: "__xmlview0--lblTableNavPressItem",
			text: "Table - Pressed Item: Flat X-large II"
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I press on row in table by text content", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPressOnRowInTableByID({
			id: "__xmlview0--tblOne",
			row: 3
		});
		When.onMyPageUnderTest.iPressOnRowInTable(4);
		Then.onMyPageUnderTest.iShouldSeeLabelByText({
			text: "Table - Navigation Pressed: 2"
		});
		When.onMyPageUnderTest.iPressOnRowInTableByTextContent("Gladiator MX");
		Then.onMyPageUnderTest.iShouldSeeLabelByText({
			text: "Table - Navigation Pressed: 3"
		});
		Then.onMyPageUnderTest.iShouldSeeTextInLabelByID({
			id: "__xmlview0--lblTableNavPressItem",
			text: "Table - Pressed Item: Gladiator MX"
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I press more data button in table", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPressMoreDataButtonInTable();
		Then.onMyPageUnderTest.iShouldSeeLengthOfTable(10).and.iTeardownMyAppFrame();
	});

	opaTest("I press more data button in table by id", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPressMoreDataButtonInTable();
		When.onMyPageUnderTest.iPressMoreDataButtonInTableByID("__xmlview0--tblOne");
		Then.onMyPageUnderTest.iShouldSeeLengthOfTableByID({
			id: "__xmlview0--tblOne",
			length: 14
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I toggle row selection in table by row and id", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iToggleRowSelectionInTableByRowAndID({
			id: "__xmlview0--tblOne",
			row: 2
		});
		Then.onMyPageUnderTest.iShouldSeeLabelByText({
			id: "__xmlview0--btnOne",
			text: "Table - Selection Changed: 1"
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I toggle row selection in table by text content", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iToggleRowSelectionInTableByRowAndID({
			id: "__xmlview0--tblOne",
			row: 2
		});
		When.onMyPageUnderTest.iToggleRowSelectionInTableByTextContent("Flat S");
		Then.onMyPageUnderTest.iShouldSeeLabelByText({
			id: "__xmlview0--btnOne",
			text: "Table - Selection Changed: 2"
		}).and.iTeardownMyAppFrame();
	});

	/** Checks on sap.ushell.ui.shell.ShellHeadItem **/
	// Actions
	opaTest("I press search button in unified shell", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay,
			timeout: 30
		});
		When.onMyPageUnderTest.iPressSearchButton();
		Then.onMyPageUnderTest.iShouldSeeSearchFieldByID({
			viewName: "",
			id: "searchFieldInShell"
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I press back button in unified shell", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay,
			timeout: 30
		});
		When.onMyPageUnderTest.iPressBackButton();
		//warning if you run this test with German as default language in browser settings, it will fail.
		//In that case try "Startseite" instead of "Home".
		Then.onMyPageUnderTest.iShouldSeeAppTitleByText("Home" || "Startseite").and.iTeardownMyAppFrame();
	});

});