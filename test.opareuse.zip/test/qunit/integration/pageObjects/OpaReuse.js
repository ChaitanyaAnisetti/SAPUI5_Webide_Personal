sap.ui.define([
	"sap/ui/test/Opa5",
	"test/opareuse/control/CommonPageObject"
], function(Opa5, CommonPageObject) {
	"use strict";
    // object page boot strap 
	var sViewName = "opa5reuselib.view.View1";

    // create a new page object
	Opa5.createPageObjects({
		onMyPageUnderTest: {
			baseClass: CommonPageObject.createBaseClassForPageObject(sViewName),
			actions: jQuery.extend(CommonPageObject.getCommonActions(), {
				// define here app specific actions
				viewName: sViewName
			}),
			assertions: jQuery.extend(CommonPageObject.getCommonAssertions(), {
				// define here app specific assertions
				viewName: sViewName
			})
		}
	});
});