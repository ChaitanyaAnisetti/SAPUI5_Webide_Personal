sap.ui.define([
	"sap/ui/test/opaQunit"
], function (opaTest) {
	"use strict";

	module("OPA5 Reuse Smart Controls 2 Journey");

	var sResourcePath = "testapp/app/index";

	// Semantic object
	var sSemanticObject = "opareuselib";

	// Action names
	var sActionDisplay = "smartcontrols2";

	/** Checks on sap.ui.comp.smarttable.SmartTable **/
	// Assertions

	// Actions

	opaTest("I press on icon in SmartTable by text content in row and entityset", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPressIconInSmartTableByTextContentInRowAndEntitySet({
			icon: "cloud",
			text: "Gladiator MX",
			entitySet: "Products"
		});
		Then.onMyPageUnderTest.iShouldSeeLabelByText("SmartTable - Selected Product by icon: 2212-121-828").and.iTeardownMyAppFrame();
	});

});