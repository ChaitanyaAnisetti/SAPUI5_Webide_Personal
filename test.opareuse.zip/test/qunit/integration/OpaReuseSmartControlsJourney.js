sap.ui.define([
	"sap/ui/test/opaQunit",
	"sap/ui/test/Opa5"
], function (opaTest, Opa5) {
	"use strict";

	var sResourcePath = "testapp/app/index";

	// Semantic object
	var sSemanticObject = "opareuselib";

	// Action names
	var sActionDisplay = "smartcontrols";

	module("OPA5 Reuse Smart Controls Assertions");

	Opa5.extendConfig({
		timeout: 21
	});
	/** Checks on sap.ui.comp.smartfilterbar.SmartFilterBar **/
	// Assertions
	opaTest("I should see SmartField by its id", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		Then.onMyPageUnderTest.iShouldSeeSmartFieldByID("__xmlview0--nameField");
	});

	opaTest("I should see SmartField by its text label", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeSmartFieldByTextLabel("Category");
	});

	opaTest("I should see value in SmartField by its id", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeValueInSmartFieldByID({
			id: "__xmlview0--nameField",
			value: "Power Projector 4713"
		});
	});

	opaTest("I should see value in SmartField by its text label", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeValueInSmartFieldByTextLabel({
			textLabel: "Category",
			value: "Projector"
		});
	});

	/** Checks on sap.ui.comp.smarttable.SmartTable **/
	// Assertions
	opaTest("I should see SmartTable by its ID", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeSmartTableByID({
			id: "__xmlview0--smartTable_ResponsiveTable"
		});
	});

	opaTest("I should see SmartTable by its header text", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeSmartTableByHeader({
			header: "Products"
		});
	});

	opaTest("I should see SmartTable with text by its entity set", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeTextContentInSmartTableByEntitySet({
			text: "Flat Medium",
			entitySet: "Products"
		});
	});

	opaTest("I should see SmartTable by its entity set", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeSmartTableByEntitySet({
			entitySet: "Products"
		});
	});

	opaTest("I should see SmartTable with given length by its entity set", function (Given, When, Then) {
		Then.onMyPageUnderTest.iShouldSeeLengthOfSmartTableByEntitySet({
			length: 14,
			entitySet: "Products"
		}).and.iTeardownMyAppFrame();
	});
	//caution! last opatest in this journey should always contain the one and only teardown() call of the journey.

	module("OPA5 Reuse Smart Controls Actions");

	Opa5.extendConfig({
		timeout: 50
	});

	/** Checks on sap.ui.comp.smartfilterbar.SmartField **/
	// Actions
	opaTest("I enter value in SmartField by its id", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});

		When.onMyPageUnderTest.iEnterValueInSmartFieldByID({
			id: "__xmlview0--nameField",
			value: "Laptop Case"
		});
		Then.onMyPageUnderTest.iShouldSeeValueInSmartFieldByID({
			id: "__xmlview0--nameField",
			value: "Laptop Case"
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I enter value in SmartField by its text label", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});

		When.onMyPageUnderTest.iEnterValueInSmartFieldByTextLabel({
			textLabel: "Category",
			value: "Printer"
		});
		Then.onMyPageUnderTest.iShouldSeeValueInSmartFieldByTextLabel({
			textLabel: "Category",
			value: "Printer"
		}).and.iTeardownMyAppFrame();
	});
	
	/** Checks on sap.ui.comp.smartfilterbar.SmartFilterBar **/
	// Actions
	opaTest("I enter value in basic search of a Smart Filter Bar", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});

		When.onMyPageUnderTest.iEnterValueInBasicSearchOfSmartFilterBar("USB Stick");
		Then.onMyPageUnderTest.iShouldSeeSearchFieldByID({
			id: "__xmlview0--smartFilterBar-btnBasicSearch",
			value: "USB Stick"
		});
		Then.onMyPageUnderTest.iShouldSeeLabelByText({
			id: "__xmlview0--lblSmartFilterBarGoBtn",
			text: "SmartFilterBar - Go Button Pressed: 2"
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I press go button in Smart Filter Bar", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});

		When.onMyPageUnderTest.iPressGoButtonInSmartFilterBar();
		Then.onMyPageUnderTest.iShouldSeeLabelByText({
			id: "__xmlview0--lblSmartFilterBarGoBtn",
			text: "SmartFilterBar - Go Button Pressed: 2"
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I press filter button in Smart Filter Bar", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPressFilterButtonInSmartFilterBar();
		//depending on whether this is running with English (the former) or German language settings (the latter) Dialog Title differs
		Then.onMyPageUnderTest.iShouldSeeDialogByTitle("Filters" || "Filter").and.iTeardownMyAppFrame();
	});

	opaTest("I press cancel button in Smart Filter Dialog", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPressFilterButtonInSmartFilterBar();
		When.onMyPageUnderTest.iPressCancelButtonInSmartFilterDialog();
		Then.onMyPageUnderTest.iShouldSeePageByTitle("Foo Title").and.iTeardownMyAppFrame();
	});

	opaTest("I press go button in Smart Filter Dialog", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPressFilterButtonInSmartFilterBar();
		When.onMyPageUnderTest.iPressGoButtonInSmartFilterDialog();
		Then.onMyPageUnderTest.iShouldSeeLabelByText({
			id: "__xmlview0--lblSmartFilterBarFilterBtn",
			text: "SmartFilterBar - Go Button Pressed: 2"
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I press clear button in Smart Filter Bar", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});

		When.onMyPageUnderTest.iPressClearButtonInSmartFilterBar();
		Then.onMyPageUnderTest.iShouldSeeLabelByText({
			id: "__xmlview0--lblSmartFilterBarClearBtn",
			text: "SmartFilterBar - Clear Button Pressed: 1"
		});
		// Press go to avoid that smart table remains in busy mode
		When.onMyPageUnderTest.iPressGoButtonInSmartFilterBar().and.iTeardownMyAppFrame();
	});

	opaTest("I press restore button in Smart Filter Bar", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});

		When.onMyPageUnderTest.iPressRestoreButtonInSmartFilterBar();
		Then.onMyPageUnderTest.iShouldSeeLabelByText({
			id: "__xmlview0--lblSmartFilterBarRestoreBtn",
			text: "SmartFilterBar - Restore Button Pressed: 1"
		});
		// Press go to avoid that smart table remains in busy mode
		When.onMyPageUnderTest.iPressGoButtonInSmartFilterBar().and.iTeardownMyAppFrame();
	});
	
	/** Checks on sap.ui.comp.smartfilterbar.SmartTable **/
	// Actions
	opaTest("I open personalization dialog of SmartTable", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPersonalizeSmartTable();
		Then.onMyPageUnderTest.iShouldSeeDialogByTitle("View Settings" || "Anzeigeeinstellungen").and.iTeardownMyAppFrame();
	});

	opaTest("I press row of SmartTable by row and id", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPressOnRowInSmartTableByID({
			row: 3,
			id: "__xmlview0--smartTable_ResponsiveTable"
		});
		Then.onMyPageUnderTest.iShouldSeeAppByIntentAndParameters({
			semanticObject: "opareuselib",
			action: "dummyapp",
			params: {
				PassedID: "K47322.1",
				PassedCategory: "Graphics%20Card"
			}
		}).and.iTeardownMyAppFrame();
	});

	opaTest("I press row of SmartTable by row and entityset", function (Given, When, Then) {
		Given.iStartMyApp(sResourcePath, {
			semanticObject: sSemanticObject,
			action: sActionDisplay
		});
		When.onMyPageUnderTest.iPressOnRowInSmartTableByEntitySet({
			row: 5,
			entitySet: "Products"
		});
		Then.onMyPageUnderTest.iShouldSeeAppByIntentAndParameters({
			semanticObject: "opareuselib",
			action: "dummyapp",
			params: {
				PassedID: "P1239823",
				PassedCategory: "Accessory"
			}
		}).and.iTeardownMyAppFrame();
	});

});