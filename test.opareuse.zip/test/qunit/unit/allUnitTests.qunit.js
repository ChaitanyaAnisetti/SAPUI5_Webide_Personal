// test alias, relative path from testsuite.qunit.js to the test resources
jQuery.sap.registerModulePath("unitTest", "test-files");
jQuery.sap.registerModulePath("testData", "../../testData");

// tests to run
jQuery.sap.require("unitTest.CommonPageObjectTest");
jQuery.sap.require("unitTest.CommonButtonTest");
jQuery.sap.require("unitTest.CommonControlTest");
jQuery.sap.require("unitTest.CommonInputTest");
jQuery.sap.require("unitTest.CommonInputBaseTest");
jQuery.sap.require("unitTest.CommonComboBoxTest");
jQuery.sap.require("unitTest.CommonSelectTest");

jQuery.sap.require("unitTest.CommonDialogTest");
jQuery.sap.require("unitTest.CommonLabelTest");
jQuery.sap.require("unitTest.CommonLinkTest");
jQuery.sap.require("unitTest.CommonListBaseTest");
jQuery.sap.require("unitTest.CommonMultiComboBoxTest");
jQuery.sap.require("unitTest.CommonNavigationTest");
jQuery.sap.require("unitTest.CommonPageTest");

jQuery.sap.require("unitTest.CommonTableTest");
jQuery.sap.require("unitTest.CommonTitleTest");
jQuery.sap.require("unitTest.CommonTextTest");
jQuery.sap.require("unitTest.CommonUtilTest");
jQuery.sap.require("unitTest.CommonSmartTableTest");
jQuery.sap.require("unitTest.CommonSmartFieldTest");
jQuery.sap.require("unitTest.CommonSmartFilterBarTest");
jQuery.sap.require("unitTest.CommonSearchFieldTest");
// causes issues on Jenkinks
// check why this is not working
//jQuery.sap.require("unitTest.CommonShellAppTitleTest");
//jQuery.sap.require("unitTest.CommonShellHeadItemTest");

/*// separation of actions and assertions
//
///
*/