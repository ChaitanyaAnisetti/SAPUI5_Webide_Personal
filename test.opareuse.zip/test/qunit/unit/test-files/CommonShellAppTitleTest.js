/*global retrieveOpaHelperFunctions */
sap.ui.define([
	"sap/ui/test/Opa",
	"sap/ui/test/Opa5",
	"sap/ui/test/opaQunit",
	"test/opareuse/control/CommonPageObject",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationContainsPropertyEqual",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/Interactable",
	"test/opareuse/control/CommonControl",
	"jquery.sap.global",
	"sap/m/Button",
	"sap/m/SearchField",
	"sap/ui/comp/smartfilterbar/SmartFilterBar",
	"sap/m/NavContainer",
	"sap/m/App",
	"sap/ushell/ui/shell/ShellAppTitle",
	"sap/ushell/services/Container",	
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/base/Object",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(Opa, Opa5, opaTest, CommonPageObject, Press, Properties, PropertyStrictEquals, AggregationFilled, AggregationContainsPropertyEqual,
	AggregationLengthEquals,
	BindingPath, Interactable, CommonControl, $, Button, SearchField, SmartFilterBar, NavContainer, App,
	ShellAppTitle, Container, ResourceModel) {

	var baseClass = CommonPageObject.createBaseClassForPageObject(),
		arrangement = new baseClass();
		
    retrieveOpaHelperFunctions("actions", arrangement, CommonPageObject.getOpaLibraries() );
	retrieveOpaHelperFunctions("assertions", arrangement, CommonPageObject.getOpaLibraries() );

	function createXmlView(sViewName) {
		var sView = [
			'<core:View xmlns:core="sap.ui.core" xmlns="sap.m" xmlns:mvc="sap.ui.core.mvc">',
			'</core:View>'
		].join('');
		var oView;
		oView = sap.ui.xmlview({
			id: sViewName,
			viewContent: sView
		});
		oView.setViewName(sViewName);
		return oView;
	}

	var assertOkOriginal = QUnit.assert.ok,
		assertOkStub,
		waitForOriginal = arrangement.waitFor,
		waitForStub;

	[NavContainer, App].forEach(function(fnConstructor) {

		QUnit.module("Matching in a :" + fnConstructor.getMetadata().getName(), {

			beforeEach: function() {
				this.oOpa5 = new Opa5({autoWait: true});
				this.oView = createXmlView("view0");
				
				jQuery.sap.require("sap.ushell.resources");
        		var text = "fooAppTitle";
        		var shellAppTitle = new sap.ushell.ui.shell.ShellAppTitle({text: text});
				shellAppTitle.placeAt("qunit-fixture");
				this.oView.placeAt("qunit-fixture");
				sap.ui.getCore().applyChanges();
			},
			afterEach: function() {

				this.oView.destroy();
				Opa5.resetConfig();
				sap.ui.getCore().applyChanges();
				arrangement.waitFor = waitForOriginal;
				waitForStub = null;
				QUnit.assert.ok = assertOkOriginal;
				assertOkStub = null;
			}
		});

		opaTest("Test reuse functions of CommonShellAppTitleTest", function() {
			Opa5.assert.ok(arrangement.iShouldSeeAppTitleByText({
				text: "fooAppTitle"
			}), "Should find app title by text as object");
			Opa5.assert.ok(arrangement.iShouldSeeAppTitleByText("fooAppTitle"), "Should find app title by text");
		});

		QUnit.test("Test mandatory options of CommonShellAppTitleTest", function(assert) {	
			var done = assert.async();
			if ($.isEmptyObject(waitForStub)) {
				waitForStub = sinon.stub(arrangement, "waitFor").returns(true);
			}
			if ($.isEmptyObject(assertOkStub)) {
				assertOkStub = sinon.stub(QUnit.assert, "ok");
			}
			//negative cases - mandatory options are missing
			assert.notOk(arrangement.iShouldSeeAppTitleByText({
			}, assertOkStub), "iShouldSeeAppTitleByText should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			//positive cases - all mandatory options passed
			QUnit.assert.ok = assertOkOriginal;

			assert.ok(arrangement.iShouldSeeAppTitleByText({
				text: "fooAppTitle"
			}, waitForStub), "iShouldSeeAppTitleByText should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			done();
		});
	});
});