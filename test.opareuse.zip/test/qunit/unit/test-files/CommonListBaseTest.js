/*global retrieveOpaHelperFunctions */
sap.ui.define([
	"sap/ui/test/Opa",
	"sap/ui/test/Opa5",
	"sap/ui/test/opaQunit",
	"test/opareuse/control/CommonPageObject",
	"sap/m/App",	
	"sap/m/Button",
	"sap/m/ColumnListItem",	
	"sap/m/ComboBox",
	"sap/m/ComboBoxBase",	
	"sap/m/Dialog",	
	"sap/m/Input",	
	"sap/m/InputBase",		
	"sap/m/Label",
	"sap/m/Link",
	"sap/m/ListBase",		
	"sap/m/NavContainer",
	"sap/m/Page",
    "sap/m/SearchField",
	"sap/m/StandardListItem",    
	"sap/m/Table",
	"sap/m/Text",	
	"sap/ui/comp/smartfield/SmartField",
	"sap/ui/comp/smarttable/SmartTable",	
	"sap/ui/core/Control",
	"sap/ui/core/Item",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/base/Object",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationContainsPropertyEqual",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/Interactable",	
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(Opa, Opa5, opaTest, CommonPageObject,
    App, Button, ColumnListItem, ComboBox, ComboBoxBase, Dialog, Input, InputBase, Label, Link, ListBase, NavContainer, Page, SearchField, StandardListItem, Table, Text,
    SmartField, SmartTable, Control, Item, ResourceModel,	Object,
    Press, Properties, PropertyStrictEquals, AggregationFilled, AggregationContainsPropertyEqual, AggregationLengthEquals, BindingPath, Interactable,
	sinon) {
		
	var baseClass = CommonPageObject.createBaseClassForPageObject(),
		arrangement = new baseClass();
		
	retrieveOpaHelperFunctions("actions", arrangement, CommonPageObject.getOpaLibraries() );
	retrieveOpaHelperFunctions("assertions", arrangement, CommonPageObject.getOpaLibraries() );

	function createXmlView(sViewName) {
		var sView = [
			'<core:View xmlns:core="sap.ui.core" xmlns="sap.m">',
			'</core:View>'
		].join('');
		var oView;
		oView = sap.ui.xmlview({
			viewContent: sView
		});
		oView.setViewName(sViewName);
		return oView;
	}

	var assertOkOriginal = QUnit.assert.ok,
		assertOkStub,
		waitForOriginal = arrangement.waitFor,
		waitForStub;

	[NavContainer, App].forEach(function(fnConstructor) {

		QUnit.module("Matching in a :" + fnConstructor.getMetadata().getName(), {

			setup: function() {
				this.oOpa5 = new Opa5({autoWait: true});
				//assertOkStub = sinon.stub(QUnit.assert, "ok");
				this.oView = createXmlView("my.namespace.View");
				// set i18n model on view
				var i18nModel = new ResourceModel({
					bundleUrl: "testapp/i18n/i18n.properties"
				});
				this.oView.setModel(i18nModel, "i18n");
				this.oListBase = new ListBase("fooListBase");
				var oListItem1 = new ColumnListItem("fooListItem1");
				oListItem1.addCell(new Text({id: "fooText11", text: "Foo List Item 1.1"}));
				oListItem1.addCell(new Text({id: "fooText12", text: "Foo List Item 1.2"}));
				var oListItem2 = new ColumnListItem("fooListItem2");
				oListItem2.addCell(new Text({id: "fooText21", text: "Foo List Item 2.1"}));
				oListItem2.addCell(new Text({id: "fooText22", text: "Foo List Item 2.2"}));
				var oListItem3 = new ColumnListItem("fooListItem3");
				oListItem3.addCell(new Text({id: "fooText31", text: "Foo List Item 3.1"}));
				oListItem3.addCell(new Text({id: "fooText32", text: "Foo List Item 3.2"}));
				this.oListBase.addItem(oListItem1);
				this.oListBase.addItem(oListItem2);
				this.oListBase.addItem(oListItem3);
				this.oListBase.setGrowing(true);
				this.oListBase.setGrowingThreshold(2);
				this.oListBase.placeAt("qunit-fixture");
				this.oView.placeAt("qunit-fixture");
				sap.ui.getCore().applyChanges();
			},
			teardown: function() {
				this.oView.destroy();
				this.oListBase.destroy();
				Opa5.resetConfig();
				sap.ui.getCore().applyChanges();
				arrangement.waitFor = waitForOriginal;
				waitForStub = null;
				QUnit.assert.ok = assertOkOriginal;
				assertOkStub = null;
			}
		});

		opaTest("Test reuse functions of CommonListBase", function() {
			Opa5.assert.ok(arrangement.iPressOnRowInListBaseByID({
				id: "fooListBase",
				row: 2
			}), "Should press on passed row in ListBase by id as object");
			
			Opa5.assert.ok(arrangement.iPressOnRowInListBase({
				row: 2
			}), "Should press on passed row in first ListBase of the view by object");
			Opa5.assert.ok(arrangement.iPressOnRowInListBase(2), "Should press on passed row in first ListBase of the view");
			
			Opa5.assert.ok(arrangement.iPressMoreDataButtonInListBaseByID({
				id: "fooListBase"
			}), "Should press on more data button of ListBase by id as object");
			Opa5.assert.ok(arrangement.iPressMoreDataButtonInListBaseByID("fooListBase"), "Should press on more data button of ListBase by id");
			
			Opa5.assert.ok(arrangement.iPressMoreDataButtonInListBase({
			}), "Should press on more data button of ListBase as object");
			Opa5.assert.ok(arrangement.iPressMoreDataButtonInListBase(), "Should press on more data button of ListBase");
			
			Opa5.assert.ok(arrangement.iShouldSeeListBaseByID({
				id: "fooListBase"
			}), "Should find CommonListBase by id as object");
			Opa5.assert.ok(arrangement.iShouldSeeListBaseByID("fooListBase"), "Should find CommonListBase by id");

			Opa5.assert.ok(arrangement.iShouldSeeItemsInListBaseByID({
				id: "fooListBase"
			}), "Should find ListBase with at least one item by id as object");
			Opa5.assert.ok(arrangement.iShouldSeeItemsInListBaseByID("fooListBase"), "Should find CommonListBase with at least one item by id");
			
			Opa5.assert.ok(arrangement.iShouldSeeLengthOfListBaseByID({
				id: "fooListBase",
				length: 3
			}), "Should find ListBase with passed length by id as object");
			
			Opa5.assert.ok(arrangement.iShouldSeeLengthOfListBase({
				length: 3
			}), "Should find ListBase by length as object");
			Opa5.assert.ok(arrangement.iShouldSeeLengthOfListBase(3), "Should find CommonListBase by length");
		});

		QUnit.test("Test mandatory options of CommonListBase", function(assert) {
			var done = assert.async();
			if ($.isEmptyObject(waitForStub)) {
				waitForStub = sinon.stub(arrangement, "waitFor").returns(true);
			}
			if ($.isEmptyObject(assertOkStub)) {
				assertOkStub = sinon.stub(QUnit.assert, "ok");
			}
			//negative cases - mandatory options are missing
			assert.notOk(arrangement.iShouldSeeListBaseByID({
			}, assertOkStub), "iShouldSeeListBaseByID should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeItemsInListBaseByID({
			}, assertOkStub), "iShouldSeeItemsInListBaseByID should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeLengthOfListBaseByID({
			}, assertOkStub), "iShouldSeeLengthOfListBaseByID should fail due to missing id and length by object");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeLengthOfListBase({
			}, assertOkStub), "iShouldSeeLengthOfListBase should fail due to missing length by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iPressOnRowInListBaseByID({
			}, assertOkStub), "iPressOnRowInListBaseByID should fail due to missing id by object");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iPressMoreDataButtonInListBaseByID({
			}, assertOkStub), "iPressMoreDataButtonInListBaseByID should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();

			//positive cases - all mandatory options passed
			QUnit.assert.ok = assertOkOriginal;

			assert.ok(arrangement.iShouldSeeListBaseByID({
				id: "fooListBase"
			}, waitForStub), "iShouldSeeListBaseByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeItemsInListBaseByID({
				id: "fooListBase"
			}, waitForStub), "iShouldSeeItemsInListBaseByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeLengthOfListBaseByID({
				id: "fooListBase",
				length: 3
			}, waitForStub), "iShouldSeeLengthOfListBaseByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeLengthOfListBase({
				length: 3
			}, waitForStub), "iShouldSeeLengthOfListBase should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iPressOnRowInListBaseByID({
				id: "fooListBase",
				row: 3
			}, waitForStub), "iPressOnRowInListBaseByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iPressMoreDataButtonInListBase({
			}, waitForStub), "iPressMoreDataButtonInListBase should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			done();
		});

	});
});