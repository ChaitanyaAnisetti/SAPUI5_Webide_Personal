/*global retrieveOpaHelperFunctions */
sap.ui.define([
	"sap/ui/test/Opa",
	"sap/ui/test/Opa5",
	"sap/ui/test/opaQunit",
	"test/opareuse/control/CommonPageObject",
	"sap/m/App",	
	"sap/m/Button",
	"sap/m/Dialog",	
	"sap/m/Input",	
	"sap/m/InputBase",		
	"sap/m/Label",
	"sap/m/Link",	
	"sap/m/NavContainer",
	"sap/m/Page",
    "sap/m/SearchField",	
	"sap/m/Table",
	"sap/m/Text",	
	"sap/ui/comp/smartfield/SmartField",
	"sap/ui/comp/smarttable/SmartTable",	
	"sap/ui/core/Control",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/base/Object",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationContainsPropertyEqual",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/Interactable",	
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(Opa, Opa5, opaTest, CommonPageObject,
    App, Button, Dialog, Input, InputBase, Label, Link, NavContainer, Page, SearchField, Table, Text, SmartField, SmartTable,
    Control, ResourceModel,	Object,
    Press, Properties, PropertyStrictEquals, AggregationFilled, AggregationContainsPropertyEqual, AggregationLengthEquals, BindingPath, Interactable,
	sinon) {
		
	var baseClass = CommonPageObject.createBaseClassForPageObject(),
		arrangement = new baseClass();
		
	retrieveOpaHelperFunctions("actions", arrangement, CommonPageObject.getOpaLibraries() );
	retrieveOpaHelperFunctions("assertions", arrangement, CommonPageObject.getOpaLibraries() );

	function createXmlView(sViewName) {
		var sView = [
			'<core:View xmlns:core="sap.ui.core" xmlns="sap.m">',
			'</core:View>'
		].join('');
		var oView;
		oView = sap.ui.xmlview({
			viewContent: sView
		});
		oView.setViewName(sViewName);
		return oView;
	}

	var assertOkOriginal = QUnit.assert.ok,
		assertOkStub,
		waitForOriginal = arrangement.waitFor,
		waitForStub;

	[NavContainer, App].forEach(function(fnConstructor) {

		QUnit.module("Matching in a :" + fnConstructor.getMetadata().getName(), {

			setup: function() {
				this.oOpa5 = new Opa5({autoWait: true});
				//assertOkStub = sinon.stub(QUnit.assert, "ok");
				this.oView = createXmlView("view0");
				this.i18nBundleUrl = jQuery.sap.getModulePath("testapp") + "/i18n/i18n.properties";
				var i18nModel = new ResourceModel({
					bundleUrl: this.i18nBundleUrl
				});
				this.oDialog = new Dialog({id: "fooDialog", title: "{i18n>fooDialog}"});
				this.oDialog.setModel(i18nModel, "i18n");
				this.oDialog.placeAt("qunit-fixture");
				//Make sure that the control is rendered
				sap.ui.getCore().applyChanges();
			},
			teardown: function() {
				this.oView.destroy();
				this.oDialog.destroy();
				Opa5.resetConfig();
				//Make sure that the control is rendered
				sap.ui.getCore().applyChanges();
				arrangement.waitFor = waitForOriginal;
				waitForStub = null;
				QUnit.assert.ok = assertOkOriginal;
				assertOkStub = null;
			}
		});

		opaTest("Test reuse functions of CommonDialog", function() {
			
			Opa5.assert.ok(arrangement.iShouldSeeDialogByID({
				id: "fooDialog"
			}), "Should find Dialog by id as object");
			Opa5.assert.ok(arrangement.iShouldSeeDialogByID("fooDialog"), "Should find Dialog by id");
			
			Opa5.assert.ok(arrangement.iShouldSeeDialogByTitle({
				title: "Foo Dialog"
			}), "Should find Dialog by title as Object");
			Opa5.assert.ok(arrangement.iShouldSeeDialogByTitle("Foo Dialog"), "Should find Dialog by title");
		
			Opa5.assert.ok(arrangement.iShouldSeeDialogByI18nKey({
				key: "fooDialog"
			}), "Should find Dialog by i18n-key as Object");
			Opa5.assert.ok(arrangement.iShouldSeeDialogByI18nKey("fooDialog"), "Should find Dialog by i18n-key");
		});

		QUnit.test("Test mandatory options of CommonDialog", function(assert) {
			var done = assert.async();
			if ($.isEmptyObject(waitForStub)) {
				waitForStub = sinon.stub(arrangement, "waitFor").returns(true);
			}
			if ($.isEmptyObject(assertOkStub)) {
				assertOkStub = sinon.stub(QUnit.assert, "ok");
			}
			//negative cases - mandatory options are missing
			assert.notOk(arrangement.iShouldSeeDialogByID({
			}, assertOkStub), "iShouldSeeDialogByID should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeDialogByTitle({
			}, assertOkStub), "iShouldSeeDialogByTitle should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeDialogByI18nKey({
			}, assertOkStub), "iShouldSeeDialogByI18nKey should fail due to missing key by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();

			//positive cases - all mandatory options passed
			QUnit.assert.ok = assertOkOriginal;

			assert.ok(arrangement.iShouldSeeDialogByID({
				id: "fooDialog"
			}, waitForStub), "iShouldSeeDialogByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeDialogByTitle({
				title: "Foo Dialog"
			}, waitForStub), "iShouldSeeDialogByTitle should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeDialogByI18nKey({
				key: "fooDialog"
			}, waitForStub), "iShouldSeeDialogByI18nKey should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			done();
		});

	});
});