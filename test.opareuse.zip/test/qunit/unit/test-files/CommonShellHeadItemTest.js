/*global retrieveOpaHelperFunctions */
sap.ui.define([
	"sap/ui/test/Opa",
	"sap/ui/test/Opa5",
	"sap/ui/test/opaQunit",
	"test/opareuse/control/CommonPageObject",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationContainsPropertyEqual",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/Interactable",
	"test/opareuse/control/CommonControl",
	"sap/ushell/renderers/fiori2/Renderer",
	"sap/ushell/renderers/fiori2/History",
	"sap/ushell/resources",
	"sap/ushell/services/Container",
	"sap/ushell/ui/shell/ShellHeader",
	"sap/ushell/ui/shell/ShellHeadItem",
	"sap/m/NavContainer",
	"sap/m/App",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/base/Object",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function (Opa, Opa5, opaTest, CommonPageObject, Press, Properties, PropertyStrictEquals, AggregationFilled,
	AggregationContainsPropertyEqual,
	AggregationLengthEquals,
	BindingPath, Interactable, CommonControl, Renderer, History, resources, Container, ShellHeader, ShellHeadItem, NavContainer, App,
	ResourceModel) {

	var baseClass = CommonPageObject.createBaseClassForPageObject(),
		arrangement = new baseClass();

	retrieveOpaHelperFunctions("actions", arrangement, CommonPageObject.getOpaLibraries());
	retrieveOpaHelperFunctions("assertions", arrangement, CommonPageObject.getOpaLibraries());

	function createXmlView(sViewName) {
		var sView = [
			'<core:View xmlns:core="sap.ui.core" xmlns="sap.m" id="content">',
			'</core:View>'
		].join('');
		var oView;
		oView = sap.ui.xmlview({
			viewContent: sView
		});
		oView.setViewName(sViewName);
		return oView;
	}

	jQuery.sap.require("sap.ushell.ui.shell.ShellLayout");
	jQuery.sap.require("sap.ushell.resources");
	jQuery.sap.require("jquery.sap.storage");

	sap.ui.core.Control.extend("MyTest", {
		renderer: function (rm, ctrl) {
			rm.write("<div style='width:10px;height:10px;background-color:gray;'");
			rm.writeControlData(ctrl);
			rm.write("></div>");
		}
	});

	var assertOkOriginal = QUnit.assert.ok,
		assertOkStub,
		waitForOriginal = arrangement.waitFor,
		waitForStub,
		oShell,
		oBackButton,
		oHomeButton,
		oMeButton,
		oSearchButton,
		oShellFloatingContainer;

	[NavContainer, App].forEach(function (fnConstructor) {

		QUnit.module("Matching in a :" + fnConstructor.getMetadata().getName(), {
			setup: function () {
				this.oOpa5 = new Opa5({
					autoWait: true
				});
				//assertOkStub = sinon.stub(QUnit.assert, "ok");
				this.oView = createXmlView("my.namespace.View");

				jQuery('<div id="canvas"></div>').appendTo('body');
				jQuery.sap.storage.clear();
				var oShellToolArea,
					oShellHeaderTitle,
					oShellHeader,
					oShellFloatingActions,

					oShellSplitContainer = new sap.ushell.ui.shell.SplitContainer({
						id: 'shell-split',
						secondaryContent: ["_pane_ctnt"],
						content: ["_ctnt"],
						subHeader: ["_subheader_ctnt"]
					});
				oShellToolArea = new sap.ushell.ui.shell.ToolArea({
					id: 'shell-toolArea',
					toolAreaItems: [new sap.ushell.ui.shell.ToolAreaItem("_toolarea_itm")]
				});

				oShellHeaderTitle = new sap.ushell.ui.shell.ShellTitle("shellTitle", {
					text: ""
				});

				oBackButton = new sap.ushell.ui.shell.ShellHeadItem("backBtn");
				oHomeButton = new sap.ushell.ui.shell.ShellHeadItem("homeBtn");
				oMeButton = new sap.ushell.ui.shell.ShellHeadItem("meAreaHeaderButton");
				oSearchButton = new sap.ushell.ui.shell.ShellHeadItem("sf");

				oShellHeader = new sap.ushell.ui.shell.ShellHeader({
					id: 'shell-header',
					headItems: [new sap.ushell.ui.shell.ShellHeadItem("_itm"), oBackButton, oHomeButton, oMeButton, oSearchButton],
					headEndItems: [new sap.ushell.ui.shell.ShellHeadItem("_end_itm")],
					user: new sap.ushell.ui.shell.ShellHeadUserItem("_useritm", {
						username: "name",
						image: "sap-icon://person-placeholder"
					}),
					title: oShellHeaderTitle,
					search: "search"
				});

				oShell = new sap.ushell.ui.shell.ShellLayout({
					id: "shell",
					header: oShellHeader,
					toolArea: oShellToolArea,
					canvasSplitContainer: oShellSplitContainer,
					floatingContainer: oShellFloatingContainer,
					floatingActionsContainer: oShellFloatingActions
				});

				oShell.placeAt('canvas');
				//oShell.placeAt("qunit-fixture");
				//this.oView.placeAt("qunit-fixture");
				sap.ui.getCore().applyChanges();
			},
			teardown: function () {
				oShell.destroy();
				oSearchButton.destroy();
				jQuery("#canvas").remove();
				jQuery("link[id='sap-ui-theme-sap.ushell']")[0].disabled = true;
				this.oView.destroy();
				Opa5.resetConfig();
				sap.ui.getCore().applyChanges();
				arrangement.waitFor = waitForOriginal;
				waitForStub = null;
				QUnit.assert.ok = assertOkOriginal;
				assertOkStub = null;
			}
		});

		opaTest("Test reuse functions of CommonShellHeadItem", function () {
			Opa5.assert.ok(arrangement.iPressBackButton(), "Should press back button of shell header");

			Opa5.assert.ok(arrangement.iPressHomeButton(), "Should press home button of shell header");

			Opa5.assert.ok(arrangement.iPressMeButton(), "Should press 'me' button of shell header");

			Opa5.assert.ok(arrangement.iPressSearchButton(), "Should press search button of shell header");
		});

	});
});