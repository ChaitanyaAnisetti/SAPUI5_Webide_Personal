/*global retrieveOpaHelperFunctions */
sap.ui.define([
	"sap/ui/test/Opa",
	"sap/ui/test/Opa5",
	"sap/ui/test/opaQunit",
	"test/opareuse/control/CommonPageObject",
	"sap/m/App",	
	"sap/m/Button",
	"sap/m/ComboBox",
	"sap/m/ComboBoxBase",	
	"sap/m/Dialog",	
	"sap/m/Input",	
	"sap/m/InputBase",		
	"sap/m/Label",
	"sap/m/Link",
	"sap/m/ListBase",		
	"sap/m/NavContainer",
	"sap/m/Page",
    "sap/m/SearchField",	
	"sap/m/Table",
	"sap/m/Text",
	"sap/m/Title",	
	"sap/ui/comp/smartfield/SmartField",
	"sap/ui/comp/smarttable/SmartTable",	
	"sap/ui/core/Control",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/base/Object",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationContainsPropertyEqual",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/Interactable",	
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(Opa, Opa5, opaTest, CommonPageObject,
    App, Button, ComboBox, ComboBoxBase, Dialog, Input, InputBase, Label, Link, ListBase, NavContainer, Page, SearchField, Table, Text, Title, SmartField, SmartTable,
    Control, ResourceModel,	Object,
    Press, Properties, PropertyStrictEquals, AggregationFilled, AggregationContainsPropertyEqual, AggregationLengthEquals, BindingPath, Interactable,
	sinon) {

	var baseClass = CommonPageObject.createBaseClassForPageObject(),
		arrangement = new baseClass();
		
	retrieveOpaHelperFunctions("actions", arrangement, CommonPageObject.getOpaLibraries() );
	retrieveOpaHelperFunctions("assertions", arrangement, CommonPageObject.getOpaLibraries() );

	function createXmlView(sViewName) {
		var sView = [
			'<core:View xmlns:core="sap.ui.core" xmlns="sap.m">',
			'</core:View>'
		].join('');
		var oView;
		oView = sap.ui.xmlview({
			viewContent: sView
		});
		oView.setViewName(sViewName);
		return oView;
	}

	var assertOkOriginal = QUnit.assert.ok,
		assertOkStub,
		waitForOriginal = arrangement.waitFor,
		waitForStub;

	[NavContainer, App].forEach(function(fnConstructor) {

		QUnit.module("Matching in a :" + fnConstructor.getMetadata().getName(), {

			setup: function() {
				this.oOpa5 = new Opa5({autoWait: true});
				//assertOkStub = sinon.stub(QUnit.assert, "ok");
				this.oView = createXmlView("view0");
				this.i18nBundleUrl = jQuery.sap.getModulePath("testapp") + "/i18n/i18n.properties";
				var i18nModel = new ResourceModel({
					bundleUrl: this.i18nBundleUrl
				});
				this.oTitle = new Title({id: "fooTitle", text: "{i18n>fooTitle}"});
				this.oTitle.setModel(i18nModel, "i18n");
				this.oTitle.placeAt("qunit-fixture");
				this.oView.placeAt("qunit-fixture");
				sap.ui.getCore().applyChanges();
			},
			teardown: function() {
				this.oView.destroy();
				this.oTitle.destroy();
				Opa5.resetConfig();
				sap.ui.getCore().applyChanges();
				arrangement.waitFor = waitForOriginal;
				waitForStub = null;
				QUnit.assert.ok = assertOkOriginal;
				assertOkStub = null;
			}
		});

		opaTest("Test reuse functions of CommonTitle", function() {
			
			Opa5.assert.ok(arrangement.iShouldSeeTitleByID({
				id: "fooTitle"
			}), "Should find Title by id as object");
			Opa5.assert.ok(arrangement.iShouldSeeTitleByID("fooTitle"), "Should find Title by id");

			Opa5.assert.ok(arrangement.iShouldSeeTitleByText({
				text: "Foo Title"
			}), "Should find Title by text as object");
			Opa5.assert.ok(arrangement.iShouldSeeTitleByText("Foo Title"), "Should find Title by text");
	
			Opa5.assert.ok(arrangement.iShouldSeeTitleByI18nKey({
				key: "fooTitle"
			}), "Should find Title by i18n-key as object");
			Opa5.assert.ok(arrangement.iShouldSeeTitleByI18nKey("fooTitle"), "Should find Title by i18n-key");
		});

		QUnit.test("Test mandatory options of CommonTitle", function(assert) {
			var done = assert.async();
			if ($.isEmptyObject(waitForStub)) {
				waitForStub = sinon.stub(arrangement, "waitFor").returns(true);
			}
			if ($.isEmptyObject(assertOkStub)) {
				assertOkStub = sinon.stub(QUnit.assert, "ok");
			}
			//negative cases - mandatory options are missing
			assert.notOk(arrangement.iShouldSeeTitleByID({
			}, assertOkStub), "iShouldSeeTitleByID should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeTitleByText({
			}, assertOkStub), "iShouldSeeTitleByText should fail due to missing text by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeTitleByI18nKey({
			}, assertOkStub), "iShouldSeeTitleByI18nKey should fail due to missing key by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();

			//positive cases - all mandatory options passed
			QUnit.assert.ok = assertOkOriginal;

			assert.ok(arrangement.iShouldSeeTitleByID({
				id: "fooTitle"
			}, waitForStub), "iShouldSeeTitleByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeTitleByText({
				text: "Foo Title"
			}, waitForStub), "iShouldSeeTitleByText should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeTitleByI18nKey({
				key: "fooTitle"
			}, waitForStub), "iShouldSeeTitleByI18nKey should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			done();
		});

	});
});