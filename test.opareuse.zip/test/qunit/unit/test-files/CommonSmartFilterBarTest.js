/*global retrieveOpaHelperFunctions */
sap.ui.define([
	"sap/ui/test/Opa",
	"sap/ui/test/Opa5",
	"sap/ui/test/opaQunit",
	"sap/ui/qunit/qunit-css",
	"sap/ui/qunit/qunit-junit",
	"test/opareuse/control/CommonPageObject",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationContainsPropertyEqual",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/Interactable",
	"test/opareuse/control/CommonControl",
	"jquery.sap.global",
	"sap/m/Button",
	"sap/m/SearchField",
	"sap/ui/comp/smartfilterbar/SmartFilterBar",
	"sap/m/NavContainer",
	"sap/m/App",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/base/Object",
	"sap/ui/thirdparty/qunit",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(Opa, Opa5, opaTest, qunitcss, qunitjunit, CommonPageObject, Press, Properties, PropertyStrictEquals, AggregationFilled,
	AggregationContainsPropertyEqual,
	AggregationLengthEquals,
	BindingPath, Interactable, CommonControl, $, Button, SearchField, SmartFilterBar, NavContainer, App, ResourceModel, Object, qunit, sinon,
	sinonqunit) {

	var baseClass = CommonPageObject.createBaseClassForPageObject(),
		arrangement = new baseClass();

    retrieveOpaHelperFunctions("actions", arrangement, CommonPageObject.getOpaLibraries() );
	retrieveOpaHelperFunctions("assertions", arrangement, CommonPageObject.getOpaLibraries() );

	function createXmlView(sViewName) {
		var sView = [
			'<core:View xmlns:core="sap.ui.core" xmlns="sap.m" xmlns:mvc="sap.ui.core.mvc">',

			'</core:View>'
		].join('');
		var oView;
		oView = sap.ui.xmlview({
			id: sViewName,
			viewContent: sView
		});
		oView.setViewName(sViewName);
		return oView;
	}

	function _createFilterGroupItem(sName, sTitle, sItemName, sItemLabel) {
		var oFilterGroupItem = new sap.ui.comp.filterbar.FilterGroupItem();
		oFilterGroupItem.setGroupName(sName);
		oFilterGroupItem.setGroupTitle(sTitle);
		var oCtrl = new sap.ui.core.Control();
		oFilterGroupItem.setControl(oCtrl);
		oFilterGroupItem.setName(sItemName);
		oFilterGroupItem.setLabel(sItemLabel);
		return oFilterGroupItem;
	}

	function _createFilterItem(sName, sLabel) {
		var oFilterItem = new sap.ui.comp.filterbar.FilterItem();
		var oCtrl = new sap.ui.core.Control();
		oFilterItem.setControl(oCtrl);
		oFilterItem.setName(sName);
		oFilterItem.setLabel(sLabel);
		return oFilterItem;
	}

	function _createFieldInBasicArea(oFilterBar, oField) {
		oField.factory = function() {
			var oFilterItem = new sap.ui.comp.filterbar.FilterItem({
				labelTooltip: oField.quickInfo,
				label: oField.label,
				name: oField.name,
				visible: oField.visible,
				control: oField.control
			});
			if (oField.isCustomFilterField) {
				oFilterItem.data("isCustomField", true);
			}
			oFilterBar.addFilterItem(oFilterItem);
		}.bind(this);

		// FilterBar needs this information
		oField.groupName = sap.ui.comp.filterbar.FilterBar.INTERNAL_GROUP;

		return oField;
	}

	var assertOkOriginal = QUnit.assert.ok,
		assertOkStub,
		waitForOriginal = arrangement.waitFor,
		waitForStub;

	[NavContainer, App].forEach(function(fnConstructor) {

		QUnit.module("Matching in a :" + fnConstructor.getMetadata().getName(), {

			beforeEach: function() {
				this.oOpa5 = new Opa5({
					autoWait: true
				});
				//assertOkStub = sinon.stub(QUnit.assert, "ok");
				this.oView = createXmlView("view0");
				this.oSmartFilterBar = new sap.ui.comp.smartfilterbar.SmartFilterBar("fooSmartFilterBar");
				this.oSmartFilterBar.setEntitySet("foo");
				this.oSmartFilterBar.setResourceUri("foo");
				var aVisibleFields = ["Company", "foo", "bar"];
				var fVisibleFieldStub = sinon.stub(this.oSmartFilterBar, "_getVisibleFieldNames");
				fVisibleFieldStub.returns(aVisibleFields);
				sinon.stub(this.oSmartFilterBar, "_initializeVariantManagement");
				sinon.stub(this.oSmartFilterBar, "getModel");
				sinon.stub(this.oSmartFilterBar, "getConditionTypeByKey").returns(null);
				sinon.stub(this.oSmartFilterBar, "_resetFilterBarSearch");
				this.oSmartFilterBar.getModel.returns(sinon.createStubInstance(sap.ui.model.odata.ODataModel));
				this.oSmartFilterBar._oFilterProvider = {
					getFilters: sinon.stub(),
					_validateConditionTypeFields: sinon.stub(),
					_updateConditionTypeFields: sinon.stub(),
					getFilledFilterData: sinon.stub(),
					reset: sinon.stub(),
					clear: sinon.stub()
				};
				this.oSmartFilterBar.setBasicSearchFieldName("foo");
				this.oSearchField = new sap.m.SearchField("fooSmartFilterBar-btnBasicSearch");
				sinon.stub(this.oSmartFilterBar, "search");
				this.oSmartFilterBar._attachToBasicSearch(this.oSearchField);

				sap.ui.getCore().byId("fooSmartFilterBar-btnRestore").setEnabled(true);
				sap.ui.getCore().byId("fooSmartFilterBar-btnRestore").setVisible(true);
				sap.ui.getCore().byId("fooSmartFilterBar-btnClear").setEnabled(true);
				sap.ui.getCore().byId("fooSmartFilterBar-btnClear").setVisible(true);
				sap.ui.getCore().byId("fooSmartFilterBar-btnFilters").setEnabled(true);
				sap.ui.getCore().byId("fooSmartFilterBar-btnFilters").setVisible(true);
				this.oSearchField.placeAt("fooSmartFilterBar");
				//this.oView.placeAt("qunit-fixture");
				this.oSmartFilterBar.placeAt("qunit-fixture");
				//Make sure that the control is rendered
				sap.ui.getCore().applyChanges();
			},
			afterEach: function() {
				sap.ui.getCore().byId("fooSmartFilterBar-variant").destroy();
				this.oSearchField.destroy();
				this.oSmartFilterBar.destroy();
				this.oView.destroy();
				Opa5.resetConfig();
				sap.ui.getCore().applyChanges();
				arrangement.waitFor = waitForOriginal;
				waitForStub = null;
				QUnit.assert.ok = assertOkOriginal;
				assertOkStub = null;
			}
		});

		opaTest("Test reuse functions of CommonSmartFilterBar", function() {
			var oFilterItem = _createFilterItem("ITEM1", "Item 1");
			this.oSmartFilterBar.addFilterItem(oFilterItem);
			_createFieldInBasicArea(this.oSmartFilterBar, oFilterItem);
			
			Opa5.assert.ok(arrangement.iEnterValueInBasicSearchOfSmartFilterBar("Foo Search"), "Should enter value in basic search");
			/*Opa5.assert.ok(arrangement.iEnterValueInFilterInSmartFilterBar({
				value: "true",
				entityPropertyName: "ITEM1"
			}), "Should enter value in filter item");*/
			Opa5.assert.ok(arrangement.iPressGoButtonInSmartFilterBar(), "Should press go button");
			Opa5.assert.ok(arrangement.iPressRestoreButtonInSmartFilterBar(), "Should press restore button");
			Opa5.assert.ok(arrangement.iPressClearButtonInSmartFilterBar(), "Should press clear button");
			Opa5.assert.ok(arrangement.iPressFilterButtonInSmartFilterBar(), "Should press filter button");
		});

		/*opaTest("Test reuse functions of CommonSmartFilterBar - Filter Dialog", function() {
			var oFilterItem = _createFilterItem("ITEM1", "Item 1");
			this.oSmartFilterBar.addFilterItem(oFilterItem);
			this.oSmartFilterBar._showFilterDialog();

			Opa5.assert.ok(arrangement.iPressRestoreButtonInSmartFilterDialog(), "Should press restore button in filter dialog");
			Opa5.assert.ok(arrangement.iPressGoButtonInSmartFilterDialog(), "Should press go button in filter dialog");
			Opa5.assert.ok(arrangement.iPressCancelButtonInSmartFilterDialog(), "Should press cancel button in filter dialog");
		});*/
		
		QUnit.test("Test mandatory options of CommonSmartFilterBar", function(assert) {
			var done = assert.async();
			if ($.isEmptyObject(waitForStub)) {
				waitForStub = sinon.stub(arrangement, "waitFor").returns(true);
			}
			if ($.isEmptyObject(assertOkStub)) {
				assertOkStub = sinon.stub(QUnit.assert, "ok");
			}
			//negative cases - mandatory options are missing
			assert.notOk(arrangement.iEnterValueInBasicSearchOfSmartFilterBar({
			}, assertOkStub), "iEnterValueInBasicSearchOfSmartFilterBar should fail due to missing value as object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			/*assert.notOk(arrangement.iEnterValueInFilterInSmartFilterBar({
			}, assertOkStub), "iEnterValueInFilterInSmartFilterBar should fail due to missing value and entityPropertyName as object");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();*/
			
			//positive cases - all mandatory options passed
			QUnit.assert.ok = assertOkOriginal;
			assert.ok(arrangement.iEnterValueInBasicSearchOfSmartFilterBar({
				value: "Foo Search"
			}, waitForStub), "iEnterValueInBasicSearchOfSmartFilterBar should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			/*assert.ok(arrangement.iEnterValueInFilterInSmartFilterBar({
				value: "true",
				entityPropertyName: "ITEM1"
			}, waitForStub), "iEnterValueInFilterInSmartFilterBar should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();*/
			
			assert.ok(arrangement.iPressGoButtonInSmartFilterBar({
			}, waitForStub), "iPressGoButtonInSmartFilterBar should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iPressRestoreButtonInSmartFilterBar({
			}, waitForStub), "iPressRestoreButtonInSmartFilterBar should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();
			
			assert.ok(arrangement.iPressClearButtonInSmartFilterBar({
			}, waitForStub), "iPressClearButtonInSmartFilterBar should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();
			
			assert.ok(arrangement.iPressFilterButtonInSmartFilterBar({
			}, waitForStub), "iPressFilterButtonInSmartFilterBar should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();
			
			assert.ok(arrangement.iPressRestoreButtonInSmartFilterDialog({
			}, waitForStub), "iPressRestoreButtonInSmartFilterDialog should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();
			
			assert.ok(arrangement.iPressGoButtonInSmartFilterDialog({
			}, waitForStub), "iPressGoButtonInSmartFilterDialog should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();
			
			assert.ok(arrangement.iPressCancelButtonInSmartFilterDialog({
			}, waitForStub), "iPressCancelButtonInSmartFilterDialog should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();

			done();
		});

	});
});