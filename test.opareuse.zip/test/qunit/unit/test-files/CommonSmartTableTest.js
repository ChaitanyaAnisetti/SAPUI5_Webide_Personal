/*global retrieveOpaHelperFunctions */
sap.ui.define([
	"sap/ui/test/Opa",
	"sap/ui/test/Opa5",
	"sap/ui/test/opaQunit",
	"test/opareuse/control/CommonPageObject",
	"sap/m/App",
	"sap/m/Button",
	"sap/m/Column",
	"sap/m/ColumnListItem",
	"sap/m/Input",
	"sap/m/InputBase",
	"sap/m/Label",
	"sap/m/Link",
	"sap/m/NavContainer",
	"sap/m/Page",
	"sap/m/Table",
	"sap/m/Text",
	"sap/ui/comp/smartfield/SmartField",
	"sap/ui/comp/smarttable/SmartTable",
	"sap/ui/core/Control",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/base/Object",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationContainsPropertyEqual",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/Interactable",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit",
	"sap/ui/core/util/MockServer"
], function (Opa, Opa5, opaTest, CommonPageObject,
	App, Button, Column, ColumnListItem, Input, InputBase, Label, Link, NavContainer, Page, Table, Text, SmartField, SmartTable,
	Control, ResourceModel, Object,
	Press, Properties, PropertyStrictEquals, AggregationFilled, AggregationContainsPropertyEqual, AggregationLengthEquals, BindingPath,
	Interactable,
	sinon, qunit, MockServer) {
	var baseClass = CommonPageObject.createBaseClassForPageObject(),
		arrangement = new baseClass();

	retrieveOpaHelperFunctions("actions", arrangement, CommonPageObject.getOpaLibraries());
	retrieveOpaHelperFunctions("assertions", arrangement, CommonPageObject.getOpaLibraries());

	function createXmlView(sViewName) {
		var sView = [
			'<core:View xmlns:core="sap.ui.core" xmlns="sap.m" xmlns:mvc="sap.ui.core.mvc"',
			' xmlns:smartFilterBar="sap.ui.comp.smartfilterbar"',
			' xmlns:smartTable="sap.ui.comp.smarttable">',

			'<smartTable:SmartTable id="fooSmartTable" smartFilterId="smartFilterBar" tableType="ResponsiveTable" editable="false"',
			' entitySet="Products" useVariantManagement="false" useTablePersonalisation="false" header="Foo Header" showRowCount="true"',
			' useExportToExcel="false" enableAutoBinding="true">',
			'<Table mode="MultiSelect"></Table>',
			'<OverflowToolbar id="fooToolBar">',
			'<Title text="Foo Title"/>',
			'<OverflowToolbarButton id="listReport-addEntry" icon="sap-icon://add"/>',
			'<OverflowToolbarButton id="listReport-btnPersonalisation" icon="sap-icon://action-settings"/>',
			'</OverflowToolbar>',
			'</smartTable:SmartTable>',
			'</core:View>'
		].join('');
		var oView;
		oView = sap.ui.xmlview({
			id: sViewName,
			viewContent: sView
		});
		oView.setViewName(sViewName);
		return oView;
	}

	var assertOkOriginal = QUnit.assert.ok,
		assertOkStub,
		waitForOriginal = arrangement.waitFor,
		waitForStub;

	[NavContainer, App].forEach(function (fnConstructor) {

		QUnit.module("Matching in a :" + fnConstructor.getMetadata().getName(), {

			setup: function () {
				this.oOpa5 = new Opa5({
					autoWait: true
				});
				//assertOkStub = sinon.stub(QUnit.assert, "ok");
				this.oView = createXmlView("view0");
				// set i18n model on view
				var i18nModel = new ResourceModel({
					bundleUrl: "../../app/i18n/i18n.properties"
				});
				this.oView.setModel(i18nModel, "i18n");
				this.oView.placeAt("qunit-fixture");
				// set explored app's demo model on this sample
				var oMockServer = new MockServer({
					rootUri: "sapuicompsmarttable/"
				});
				this._oMockServer = oMockServer;
				oMockServer.simulate("../../app/localService/metadata.xml", "../../app/localService/mockdata/");
				oMockServer.start();
				var oModel = new sap.ui.model.odata.ODataModel("sapuicompsmarttable", true);
				oModel.setCountSupported(false);
				//var oModel = new JSONModel(jQuery.sap.getModulePath("opa5reuselib.mock", "/Products.json"));
				this.oView.setModel(oModel, "foo");
				this.counterButtonPressed = 0;
				this.counterLinkPressed = 0;
				this.oView.byId("fooSmartTable").setModel(oModel);
				this.oView.byId("fooSmartTable").getTable().setMode(sap.m.ListMode.MultiSelect);

				//Make sure that the control is rendered
				sap.ui.getCore().applyChanges();
			},
			teardown: function () {
				this.oView.destroy();
				Opa5.resetConfig();
				sap.ui.getCore().applyChanges();
				arrangement.waitFor = waitForOriginal;
				waitForStub = null;
				QUnit.assert.ok = assertOkOriginal;
				assertOkStub = null;
			}
		});

		opaTest("Test reuse functions of CommonSmartTable", function () {
			Opa5.assert.ok(arrangement.iPressOnRowInSmartTableByID({
				id: "view0--fooSmartTable",
				row: 2
			}), "Should press on passed row in SmartTable by id as object");

			Opa5.assert.ok(arrangement.iPressOnRowInSmartTable({
				row: 2
			}), "Should press on passed row in first SmartTable of the view as object");
			Opa5.assert.ok(arrangement.iPressOnRowInSmartTable(2), "Should press on passed row in first SmartTable of the view");

			Opa5.assert.ok(arrangement.iPressOnRowInSmartTableByID({
				row: 2,
				id: "view0--fooSmartTable"
			}), "Should press on passed row in SmartTable by id as object");

			Opa5.assert.ok(arrangement.iPressOnRowInSmartTableByEntitySet({
				row: 2,
				entitySet: "Products"
			}), "Should press on passed row in SmartTable by id as object");

			/*Opa5.assert.ok(arrangement.iPressOnButtonInSmartTableByButtonTextAndEntitySet({
				entitySet: "Products",
				text: "Settings"
			}), "Should press on button in Smart Table by button text and entity set as  object");*/

			/*	iPressOnButtonInSmartTableByEntitySetAndButtonText
				
				iPressIconInSmartTableByEntitySetAndTextContent
				
				iPressControlInSmartTableByEntitySetAndTextContent
				
				iPressIconInSmartTableByTextContentInRowAndEntitySet
				*/

			Opa5.assert.ok(arrangement.iPersonalizeSmartTable({}),
				"Should press on personalization settings in first SmartTable of the view by object");
			Opa5.assert.ok(arrangement.iPersonalizeSmartTable(), "Should press on personalization settings in first SmartTable of the view");

			Opa5.assert.ok(arrangement.iToggleRowSelectionInSmartTableByRowAndID({
				id: "view0--fooSmartTable",
				row: 2
			}), "Should toggle row selection in SmartTable by passed id and row as object");

			Opa5.assert.ok(arrangement.iToggleRowSelectionInSmartTableByTextContentAndEntitySet({
				text: "Flat Medium",
				entitySet: "Products"
			}), "Should find SmartTable by entity set as object");

			Opa5.assert.ok(arrangement.iShouldSeeSmartTableByID({
				id: "view0--fooSmartTable"
			}), "Should find SmartTable by id as object");
			Opa5.assert.ok(arrangement.iShouldSeeSmartTableByID("view0--fooSmartTable"), "Should find SmartTable by id");

			Opa5.assert.ok(arrangement.iShouldSeeSmartTableByHeader({
				header: "Foo Header"
			}), "Should find SmartTable by header as object");
			Opa5.assert.ok(arrangement.iShouldSeeSmartTableByHeader("Foo Header"), "Should find SmartTable by header");

			Opa5.assert.ok(arrangement.iShouldSeeSmartTableByEntitySet({
				entitySet: "Products"
			}), "Should find SmartTable by entity set as object");
			Opa5.assert.ok(arrangement.iShouldSeeSmartTableByEntitySet("Products"), "Should find SmartTable by entity set");

			Opa5.assert.ok(arrangement.iShouldSeeTextContentInSmartTableByEntitySet({
				text: "Flat Medium",
				entitySet: "Products"
			}), "Should find SmartTable by text content and entity set as object");

			Opa5.assert.ok(arrangement.iShouldSeeLengthOfSmartTableByEntitySet({
				length: 14,
				entitySet: "Products"
			}), "Should find SmartTable with length by entity set as object");

		});

		QUnit.test("Test mandatory options of CommonSmartTable", function (assert) {
			var done = assert.async();
			if (jQuery.isEmptyObject(waitForStub)) {
				waitForStub = sinon.stub(arrangement, "waitFor").returns(true);
			}
			if (jQuery.isEmptyObject(assertOkStub)) {
				assertOkStub = sinon.stub(QUnit.assert, "ok");
			}
			//negative cases - mandatory options are missing
			assert.notOk(arrangement.iPressOnRowInSmartTableByID({}, assertOkStub),
				"iPressOnRowInSmartTableByID should fail due to missing row and id by object");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iPressOnRowInSmartTableByEntitySet({}, assertOkStub),
				"iPressOnRowInSmartTableByEntitySet should fail due to missing row and entitySet by object");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();

			/*assert.notOk(arrangement.iPressOnButtonInSmartTableByButtonTextAndEntitySet({
			}, assertOkStub), "iPressOnButtonInSmartTableByButtonTextAndEntitySet should fail due to missing text and entity set by object");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();*/

			assert.notOk(arrangement.iToggleRowSelectionInSmartTableByRowAndID({}, assertOkStub),
				"iToggleRowSelectionInSmartTableByRowAndID should fail due to missing id and row by object");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iToggleRowSelectionInSmartTableByTextContentAndEntitySet({}, assertOkStub),
				"iToggleRowSelectionInSmartTableByTextContentAndEntitySet should fail due to missing text and entitySet");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iShouldSeeSmartTableByID({}, assertOkStub),
				"iShouldSeeSmartTableByID should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iShouldSeeSmartTableByHeader({}, assertOkStub),
				"iShouldSeeSmartTableByHeader should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iShouldSeeSmartTableByEntitySet({}, assertOkStub),
				"iShouldSeeSmartTableByEntitySet should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iShouldSeeTextContentInSmartTableByEntitySet({}, assertOkStub),
				"iShouldSeeTextContentInSmartTableByEntitySet should fail due to missing text and entitySet");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iShouldSeeLengthOfSmartTableByEntitySet({}, assertOkStub),
				"iShouldSeeLengthOfSmartTableByEntitySet should fail due to missing length and entitySet");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();

			//positive cases - all mandatory options passed
			QUnit.assert.ok = assertOkOriginal;

			assert.ok(arrangement.iPressOnRowInSmartTable({
				row: 2
			}, waitForStub), "iPressOnRowInSmartTable should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iPressOnRowInSmartTableByID({
				row: 2,
				id: "view0--fooSmartTable"
			}, waitForStub), "iPressOnRowInSmartTableByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iPressOnRowInSmartTableByEntitySet({
				row: 2,
				entitySet: "Products"
			}, waitForStub), "iPressOnRowInSmartTableByEntitySet should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			/*assert.ok(arrangement.iPressOnButtonInSmartTableByButtonTextAndEntitySet({
				entitySet: "Products",
				text: "Settings"
			}, waitForStub), "iPressOnButtonInSmartTableByButtonTextAndEntitySet should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();*/

			assert.ok(arrangement.iPersonalizeSmartTable({}, waitForStub),
				"iPersonalizeSmartTable should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iToggleRowSelectionInSmartTableByRowAndID({
				id: "view0--fooSmartTable",
				row: 2
			}, waitForStub), "iToggleRowSelectionInSmartTableByRowAndID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iShouldSeeSmartTableByID({
				id: "view0--fooSmartTable"
			}, waitForStub), "iShouldSeeSmartTableByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iShouldSeeSmartTableByHeader({
				header: "Foo Header"
			}, waitForStub), "iShouldSeeSmartTableByHeader should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iShouldSeeSmartTableByEntitySet({
				entitySet: "Products"
			}, waitForStub), "iShouldSeeSmartTableByEntitySet should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iShouldSeeTextContentInSmartTableByEntitySet({
				text: "Flat Medium",
				entitySet: "Products"
			}, waitForStub), "iShouldSeeTextContentInSmartTableByEntitySet should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iShouldSeeLengthOfSmartTableByEntitySet({
				length: 14,
				entitySet: "Products"
			}, waitForStub), "iShouldSeeLengthOfSmartTableByEntitySet should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			done();
		});

	});
});