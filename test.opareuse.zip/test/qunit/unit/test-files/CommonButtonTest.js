/*global retrieveOpaHelperFunctions */
sap.ui.define([
	"sap/ui/test/Opa",
	"sap/ui/test/Opa5",
	"sap/ui/test/opaQunit",
	"test/opareuse/control/CommonPageObject",
	"sap/m/App",	
	"sap/m/Button",
	"sap/m/Input",	
	"sap/m/InputBase",		
	"sap/m/Label",
	"sap/m/Link",	
	"sap/m/NavContainer",
	"sap/m/Page",	
	"sap/m/Table",
	"sap/m/Text",	
	"sap/ui/core/Control",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/base/Object",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationContainsPropertyEqual",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/Interactable",	
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(Opa, Opa5, opaTest, CommonPageObject, App, Button, Input, InputBase, Label, Link, NavContainer, Page, Table, Text, Control, ResourceModel,
	Object, Press, Properties, PropertyStrictEquals, AggregationFilled, AggregationContainsPropertyEqual, AggregationLengthEquals, BindingPath, Interactable,
	sinon) {

	var baseClass = CommonPageObject.createBaseClassForPageObject(),
		arrangement = new baseClass();

    retrieveOpaHelperFunctions("actions", arrangement, CommonPageObject.getOpaLibraries() );
	retrieveOpaHelperFunctions("assertions", arrangement, CommonPageObject.getOpaLibraries() );

	function createXmlView(sViewName) {
		var sView = [
			'<core:View xmlns:core="sap.ui.core" xmlns="sap.m">',
			'</core:View>'
		].join('');
		var oView;
		oView = sap.ui.xmlview({
			viewContent: sView
		});
		oView.setViewName(sViewName);
		return oView;
	}

	var assertOkOriginal = QUnit.assert.ok,
		assertOkStub,
		waitForOriginal = arrangement.waitFor,
		waitForStub;

	[NavContainer, App].forEach(function(fnConstructor) {

		QUnit.module("Matching in a :" + fnConstructor.getMetadata().getName(), {

			beforeEach: function() {
				this.oOpa5 = new Opa5({autoWait: true});
				this.oView = createXmlView("view0");
				// set i18n model on view
				this.i18nBundleUrl = jQuery.sap.getModulePath("testapp") + "/i18n/i18n.properties";
				var i18nModel = new ResourceModel({
					bundleUrl: this.i18nBundleUrl
				});
				this.oButton = new Button({id: "fooButton", text: "{i18n>fooButton}", icon: "sap-icon://home"});
				this.oButton.setModel(i18nModel, "i18n");
				this.oButton.placeAt("qunit-fixture");
				//Make sure that the control is rendered
				sap.ui.getCore().applyChanges();
			},
			afterEach: function() {
				this.oView.destroy();
				this.oButton.destroy();
				Opa5.resetConfig();
				//Make sure that the control is rendered
				sap.ui.getCore().applyChanges();
				arrangement.waitFor = waitForOriginal;
				waitForStub = null;
				QUnit.assert.ok = assertOkOriginal;
				assertOkStub = null;
			}
		});

		opaTest("Test reuse functions of CommonButton", function() {
			Opa5.assert.ok(arrangement.iPressButtonByID({
				id: "fooButton"
			}), "Should press button by id as object");
			Opa5.assert.ok(arrangement.iShouldSeeButtonByID("fooButton"), "Should press button by id");	
			
			Opa5.assert.ok(arrangement.iPressButtonByText({
				text: "Foo Button"
			}), "Should press button by text as iPressButtonByText");
			Opa5.assert.ok(arrangement.iPressButtonByText("Foo Button"), "Should press button by text");	
			
			Opa5.assert.ok(arrangement.iPressButtonByI18nKey({
				key: "fooButton"
			}), "Should press button by text as iPressButtonByText");
			
			Opa5.assert.ok(arrangement.iPressButtonByIcon({
				icon: "sap-icon://home"
			}), "Should press button by icon as object");
			Opa5.assert.ok(arrangement.iPressButtonByIcon("sap-icon://home"), "Should press icon by text");
			
			Opa5.assert.ok(arrangement.iShouldSeeButtonByID({
				id: "fooButton"
			}), "Should find button by id as object");
			Opa5.assert.ok(arrangement.iShouldSeeButtonByID("fooButton"), "Should find button by id");
			
			Opa5.assert.ok(arrangement.iShouldSeeButtonByText({
				text: "Foo Button"
			}), "Should find button by text as object");
			Opa5.assert.ok(arrangement.iShouldSeeButtonByText("Foo Button"), "Should find button by text");

			Opa5.assert.ok(arrangement.iShouldSeeButtonByI18nKey({
				key: "fooButton"
			}), "Should find button by i18n-key as object");
			Opa5.assert.ok(arrangement.iShouldSeeButtonByI18nKey("fooButton"), "Should find button by i18n-key");
				
			Opa5.assert.ok(arrangement.iShouldSeeButtonByIcon({
				icon: "sap-icon://home"
			}), "Should find button by icon as object");
			Opa5.assert.ok(arrangement.iShouldSeeButtonByIcon("sap-icon://home"), "Should find button by icon");
		});

		QUnit.test("Test mandatory options of CommonButton", function(assert) {
			var done = assert.async();
			if ($.isEmptyObject(waitForStub)) {
				waitForStub = sinon.stub(arrangement, "waitFor").returns(true);
			}
			if ($.isEmptyObject(assertOkStub)) {
				assertOkStub = sinon.stub(QUnit.assert, "ok");
			}
			//negative cases - mandatory options are missing
			assert.notOk(arrangement.iPressButtonByID({
			}, assertOkStub), "iPressButtonByID should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iPressButtonByText({
			}, assertOkStub), "iPressButtonByText should fail due to missing text");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iPressButtonByI18nKey({
			}, assertOkStub), "iPressButtonByText should fail due to missing text");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();			

			assert.notOk(arrangement.iPressButtonByIcon({
			}, assertOkStub), "iPressButtonByIcon should fail due to missing icon");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeButtonByID({
			}, assertOkStub), "iShouldSeeButtonByID should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iShouldSeeButtonByText({
			}, assertOkStub), "iShouldSeeButtonByText should fail due to missing text");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeButtonByI18nKey({
			}, assertOkStub), "iShouldSeeButtonByI18nKey should fail due to missing text");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iShouldSeeButtonByIcon({
			}, assertOkStub), "iShouldSeeButtonByIcon should fail due to missing icon");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();

			//positive cases - all mandatory options passed
			QUnit.assert.ok = assertOkOriginal;

			assert.ok(arrangement.iPressButtonByID({
				id: "testID"
			}, waitForStub), "iPressButtonByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iPressButtonByText({
				text: "Foo Button"
			}, waitForStub), "iPressButtonByText should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();
			
			assert.ok(arrangement.iPressButtonByI18nKey({
				key: "fooButton"
			}, waitForStub), "iPressButtonByText should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();
			
			assert.ok(arrangement.iPressButtonByIcon({
				icon: "sap-icon://home"
			}, waitForStub), "iPressButtonByIcon should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();

			assert.ok(arrangement.iShouldSeeButtonByID({
				id: "testID"
			}, waitForStub), "iShouldSeeButtonByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iShouldSeeButtonByText({
				text: "Foo Button"
			}, waitForStub), "iShouldSeeButtonByText should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeButtonByIcon({
				icon: "sap-icon://home"
			}, waitForStub), "iShouldSeeButtonByIcon should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();

			done();
		});

	});
});