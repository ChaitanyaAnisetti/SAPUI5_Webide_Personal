//global getFrameUrlS
sap.ui.define([
	"jquery.sap.global",
	"sap/ui/test/Opa5",
	"test/opareuse/control/CommonPageObject",
	"sap/ui/test/launchers/iFrameLauncher"
], function(jQuery, Opa5, CommonPageObject, IFrameLauncher) {
	"use strict";

	QUnit.module("Test common functions for OPA 5 reuse", {

		setup: function() {
		},

		teardown: function() {
		}
	});

	QUnit.test("Test Common Page Object - Create Base Class", function(assert) {
		var oBaseClass =  CommonPageObject.createBaseClassForPageObject("fooView");
		assert.ok(oBaseClass, "Should return the base class of the OPA5 page object");
	});
	
	QUnit.test("Test Common Page Object - Get Arrangement", function(assert) {
		var oCommonOpa = CommonPageObject.getArrangement();
		assert.ok(oCommonOpa, "Should return the arrangement of the OPA5 page object");
	});
	
	QUnit.test("Test Common Page Object - Get Common Actions", function(assert) {
		var oCommonActions = CommonPageObject.getCommonActions();
		assert.ok(oCommonActions, "Should return an OPA action object");
	});
	
	QUnit.test("Test Common Page Object - Get Common Assertions", function(assert) {
		var oCommonAssertions = CommonPageObject.getCommonAssertions();
		assert.ok(oCommonAssertions, "Should return an OPA action object");
	});

	/*QUnit.test("Test Common Page Object", function(assert) {
		var oCommonOpa = CommonPageObject.getArrangement();
		var done = assert.async();
		assert.strictEqual(Opa5.getUtils(), null, "Initially null is returned");
		// Act
		oCommonOpa.iStartMyApp("testdata/emptySite", {semanticObject: "#FOO_SEMANTIC_OBJECT", action: "fooAction"});
		oCommonOpa.waitFor({
			success: function () {
				assert.ok(Opa5.getUtils, "IFrame utils are available");
			}
		});
		oCommonOpa.iTeardownMyAppFrame();
		oCommonOpa.waitFor({
			success: function () {
				assert.strictEqual(Opa5.getUtils(), null, "After tearing everything down null is returned again");
			}
		});
		Opa5.emptyQueue().done(done);
	});*/
});