/*global retrieveOpaHelperFunctions */
sap.ui.define([
	"sap/ui/test/Opa",
	"sap/ui/test/Opa5",
	"sap/ui/test/opaQunit",
	"test/opareuse/control/CommonPageObject",
	"sap/m/App",	
	"sap/m/Button",
	"sap/m/Input",	
	"sap/m/InputBase",		
	"sap/m/Label",
	"sap/m/Link",	
	"sap/m/NavContainer",
	"sap/m/Page",	
	"sap/m/Table",
	"sap/m/Text",	
	"sap/ui/comp/smartfield/SmartField",	
	"sap/ui/core/Control",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/base/Object",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationContainsPropertyEqual",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/Interactable",	
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(Opa, Opa5, opaTest, CommonPageObject, App, Button, Input, InputBase, Label, Link, NavContainer, Page, Table, Text, SmartField, Control, ResourceModel,
	Object, Press, Properties, PropertyStrictEquals, AggregationFilled, AggregationContainsPropertyEqual, AggregationLengthEquals, BindingPath, Interactable,
	sinon) {

	var baseClass = CommonPageObject.createBaseClassForPageObject(),
		arrangement = new baseClass();
		
    retrieveOpaHelperFunctions("actions", arrangement, CommonPageObject.getOpaLibraries() );
	retrieveOpaHelperFunctions("assertions", arrangement, CommonPageObject.getOpaLibraries() );

	function createXmlView(sViewName) {
		var sView = [
			'<core:View xmlns:core="sap.ui.core" xmlns="sap.m">',
			'</core:View>'
		].join('');
		var oView;
		oView = sap.ui.xmlview({
			viewContent: sView
		});
		oView.setViewName(sViewName);
		return oView;
	}

	var assertOkOriginal = QUnit.assert.ok,
		assertOkStub,
		waitForOriginal = arrangement.waitFor,
		waitForStub;

	[NavContainer, App].forEach(function(fnConstructor) {

		QUnit.module("Matching in a :" + fnConstructor.getMetadata().getName(), {

			beforeEach: function() {
				this.oOpa5 = new Opa5({autoWait: true});
				//assertOkStub = sinon.stub(QUnit.assert, "ok");
				this.oView = createXmlView("my.namespace.View");
				// set i18n model on view
				var i18nModel = new ResourceModel({
					bundleUrl: "testapp/i18n/i18n.properties"
				});
				this.oView.setModel(i18nModel, "i18n");
				this.oSmartField = new SmartField("fooSmartField");
				this.oSmartField.setTextLabel("Foo TextLabel");
				this.oSmartField.setValue("Foo Value");
				this.oSmartField.placeAt("qunit-fixture");
				
				this.oView.placeAt("qunit-fixture");
				sap.ui.getCore().applyChanges();
			},
			afterEach: function() {
				this.oView.destroy();
				this.oSmartField.destroy();
				Opa5.resetConfig();
				sap.ui.getCore().applyChanges();
				arrangement.waitFor = waitForOriginal;
				waitForStub = null;
				QUnit.assert.ok = assertOkOriginal;
				assertOkStub = null;
			}
		});

		opaTest("Test reuse functions of CommonSmartField", function() {
			Opa5.assert.ok(arrangement.iEnterValueInSmartFieldByID({
				id: "fooSmartField",
				value: "New Value"
			}), "Should enter value in smart field by id");
			
			Opa5.assert.ok(arrangement.iEnterValueInSmartFieldByTextLabel({
				textLabel: "Foo TextLabel",
				value: "New Value"
			}), "Should enter smart field by text label");
			
			/*Opa5.assert.ok(arrangement.iSelectKeyInSmartFieldAsComboBoxByTextLabel({
				textLabel: "Foo TextLabel",
				key: "key1"
			}), "Should select key in smart field by text label");*/
			
			Opa5.assert.ok(arrangement.iShouldSeeLabelByID({
				id: "fooSmartField"
			}), "Should find smart field by id as object");
			Opa5.assert.ok(arrangement.iShouldSeeLabelByID("fooSmartField"), "Should find smart field by id");
			
			Opa5.assert.ok(arrangement.iShouldSeeSmartFieldByTextLabel({
				textLabel: "Foo TextLabel"
			}), "Should find smart field as object");
			Opa5.assert.ok(arrangement.iShouldSeeSmartFieldByTextLabel("Foo TextLabel"), "Should find smart field by text");
			
			Opa5.assert.ok(arrangement.iShouldSeeValueInSmartFieldByID({
				id: "fooSmartField",
				value: "Foo Value"
			}), "Should find smart field by id with passed value");
			
			Opa5.assert.ok(arrangement.iShouldSeeValueInSmartFieldByTextLabel({
				textLabel: "Foo TextLabel",
				value: "Foo Value"
			}), "Should find smart field by text label with passed value");
		});

		QUnit.test("Test mandatory options of CommonSmartField", function(assert) {
			var done = assert.async();
			if ($.isEmptyObject(waitForStub)) {
				waitForStub = sinon.stub(arrangement, "waitFor").returns(true);
			}
			if ($.isEmptyObject(assertOkStub)) {
				assertOkStub = sinon.stub(QUnit.assert, "ok");
			}
			//negative cases - mandatory options are missing
			assert.notOk(arrangement.iEnterValueInSmartFieldByID({
			}, assertOkStub), "iEnterValueInSmartFieldByID should fail due to missing id");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iEnterValueInSmartFieldByTextLabel({
			}, assertOkStub), "iEnterValueInSmartFieldByTextLabel should fail due to text label");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeSmartFieldByID({
			}, assertOkStub), "iShouldSeeSmartFieldByID should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iShouldSeeSmartFieldByTextLabel({
			}, assertOkStub), "iShouldSeeSmartFieldByTextLabel should fail due to missing text");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iShouldSeeValueInSmartFieldByID({
			}, assertOkStub), "iShouldSeeValueInSmartFieldByID should fail due to missing id and text");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeValueInSmartFieldByTextLabel({
			}, assertOkStub), "iShouldSeeValueInSmartFieldByID should fail due to missing id and text");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();

			//positive cases - all mandatory options passed
			QUnit.assert.ok = assertOkOriginal;
			assert.ok(arrangement.iEnterValueInSmartFieldByID({
				id: "fooSmartField",
				value: "New Value"
			}, waitForStub), "iEnterValueInSmartFieldByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iEnterValueInSmartFieldByTextLabel({
				textLabel: "Foo TextLabel",
				value: "New Value"
			}, waitForStub), "iEnterValueInSmartFieldByTextLabel should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iSelectKeyInSmartFieldAsComboBoxByTextLabel({
				textLabel: "Foo TextLabel",
				key: "key1"
			}, waitForStub), "iSelectKeyInSmartFieldAsComboBoxByTextLabel should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iShouldSeeSmartFieldByID({
				id: "testID"
			}, waitForStub), "iShouldSeeSmartFieldByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iShouldSeeSmartFieldByTextLabel({
				textLabel: "Foo TextLabel"
			}, waitForStub), "iShouldSeeSmartFieldByTextLabel should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeValueInSmartFieldByID({
				id: "fooSmartField",
				value: "Foo Value"
			}, waitForStub), "iShouldSeeValueInSmartFieldByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeValueInSmartFieldByTextLabel({
				textLabel: "foo TextLabel",
				value: "Foo Value"
			}, waitForStub), "iShouldSeeValueInSmartFieldByTextLabel should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();

			done();
		});

	});
});