sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationContainsPropertyEqual",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/Ancestor",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/I18NText",
	"sap/ui/test/matchers/Interactable",
	"test/opareuse/control/CommonUtil",
	"sap/ui/base/Object",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(Opa5, PropertyStrictEquals, AggregationFilled, AggregationContainsPropertyEqual, AggregationLengthEquals,
	Ancestor, BindingPath, I18NText, Interactable, CommonUtil) {
	"use strict";

	var assertOkOriginal;
	var assertOkStub;
		
	QUnit.module("Test common functions of CommonUtil class", {

		setup: function() {
			assertOkOriginal = QUnit.assert.ok;
    		assertOkStub = sinon.stub(QUnit.assert, "ok");
		},

		teardown: function() {
			  QUnit.assert.ok = assertOkOriginal;
		}
	});

	QUnit.test("Test mandatory options", function(assert) {
		//use equal to avoid counting of QUnit.asssert.ok
		assert.equal(CommonUtil.validateOptions(["key1", "key2", "key3"], ["key3"]), true, assertOkStub);
		sinon.assert.notCalled(assertOkStub);
		assertOkStub.reset();
		
		assert.notOk(CommonUtil.validateOptions(["key1", "key2"], ["key3"]), assertOkStub);
		sinon.assert.calledOnce(assertOkStub);
		assertOkStub.reset();
		
		assert.notOk(CommonUtil.validateOptions(["key1", "key2"], ["key3", "key4"]), assertOkStub);
		sinon.assert.calledTwice(assertOkStub);
		assertOkStub.reset();
		
	});
	
	QUnit.test("Test matchersToString", function(assert) {
		assert.equal(CommonUtil.matchersToString([new AggregationFilled({name: "items"})]),
			"aggregation 'items' is filled", "AggregationFilled matcher");
		assert.equal(CommonUtil.matchersToString([new AggregationContainsPropertyEqual({aggregationName: "items", propertyName: "productId", propertyValue: "PROD-123"})]),
			"aggregation 'items' contains property 'productId' = 'PROD-123'", "AggregationContainsPropertyEqual matcher");
		assert.equal(CommonUtil.matchersToString([new AggregationLengthEquals({name: "items", length: 5})]),
			"aggregation 'items' of length 5", "AggregationLengthEquals matcher");
		assert.equal(CommonUtil.matchersToString([new BindingPath({path: "/Product", modelName: "default"})]),
			"binding path '/Product' of model 'default'", "BindingPath matcher");
		assert.equal(CommonUtil.matchersToString([new Interactable()]),
			"is interactable", "Interactable matcher");
		/*assert.equal(CommonUtil.matchersToString([new Ancestor(new Object({id: "fooObject"}))]),
			"is ancestor", "Ancestor matcher");	*/
		assert.equal(CommonUtil.matchersToString([new PropertyStrictEquals({name: "text", value: "value"})]),
			"text = 'value'", "PropertyStrictEquals matcher");
		assert.equal(CommonUtil.matchersToString([new I18NText({propertyName: "fooName", key: "fooKey", model: "fooModel"}), new Interactable()]),
			"propertyName 'fooName' and key 'fooKey' and modelName = 'i18n' and is interactable", "I18NText matcher");					
		assert.equal(CommonUtil.matchersToString([new AggregationFilled({name: "items"}), new Interactable()]),
			"aggregation 'items' is filled and is interactable", "Concatenation of matchers");	
		assert.equal(CommonUtil.matchersToString([function() {return true;}]), "a custom matcher",
			"not supported matchers");		
		assert.equal(CommonUtil.matchersToString([]), "",
			"empty matchers");	
	});
	
	QUnit.test("Test isTypeOfUI5", function(assert) {
		assert.ok(CommonUtil.isTypeOfUI5(new sap.m.Table("fooTable"), "sap.m.Table"), "Passed object is of passed UI5 type");
		assert.ok(CommonUtil.isTypeOfUI5(new sap.m.Table("fooTable2"), "sap.m.ListTable"), "Passed object is subclass of passed UI5 type");
		assert.notOk(CommonUtil.isTypeOfUI5(new sap.m.Table("fooTable3"), "sap.m.Control"), "Passed object is neither of type nor subclass of passed UI5 type");
		assert.ok(CommonUtil.isTypeOfUI5(new sap.ui.base.Object("baseObject"), "sap.ui.base.Object"), "Passed object is of type sap.ui.base.Object");
		assert.ok(CommonUtil.isTypeOfUI5(new sap.ui.base.Object("baseObject2"), "sap.m.Control"), "Passed object is subclass of type sap.ui.base.Object");
		assert.notOk(CommonUtil.isTypeOfUI5(new jQuery(), "jQuery"), "Passed object is no UIT5 object");
		assert.notOk(CommonUtil.isTypeOfUI5({getMetadata: function() {return null;}}, "Object"), "Passed object is no UIT5 object (2)");
		assert.notOk(CommonUtil.isTypeOfUI5({}, "sap.m.Control"), "Passed object is empty should return an error");
		assert.notOk(CommonUtil.isTypeOfUI5(null, "sap.m.Control"), "Passed object is null should return an error");
		assert.notOk(CommonUtil.isTypeOfUI5(new sap.m.Table("fooTable4"), ""), "Passed UI5 type is empty should return an error");
		assert.notOk(CommonUtil.isTypeOfUI5(new sap.m.Table("fooTable5"), null), "Passed UI5 type is null should return an error");
	});	

});