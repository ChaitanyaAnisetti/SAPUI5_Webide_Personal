/*global retrieveOpaHelperFunctions */
sap.ui.define([
	"sap/ui/test/Opa",
	"sap/ui/test/Opa5",
	"sap/ui/test/opaQunit",
	"test/opareuse/control/CommonPageObject",
	"sap/m/App",
	"sap/m/Bar",
	"sap/m/Button",
	"sap/m/Column",
	"sap/m/ColumnListItem",	
	"sap/m/ComboBox",
	"sap/m/ComboBoxBase",	
	"sap/m/Dialog",	
	"sap/m/Input",	
	"sap/m/InputBase",		
	"sap/m/Label",
	"sap/m/Link",
	"sap/m/ListBase",		
	"sap/m/NavContainer",
	"sap/m/Page",
    "sap/m/SearchField",
	"sap/m/StandardListItem",    
	"sap/m/Table",
	"sap/m/Text",	
	"sap/ui/comp/smartfield/SmartField",
	"sap/ui/comp/smarttable/SmartTable",	
	"sap/ui/core/Control",
	"sap/ui/core/Item",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/base/Object",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationContainsPropertyEqual",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/Interactable",	
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(Opa, Opa5, opaTest, CommonPageObject,
    App, Bar, Button, Column, ColumnListItem, ComboBox, ComboBoxBase, Dialog, Input, InputBase, Label, Link, ListBase, NavContainer, Page, SearchField, StandardListItem, Table, Text,
    SmartField, SmartTable, Control, Item, ResourceModel,	Object,
    Press, Properties, PropertyStrictEquals, AggregationFilled, AggregationContainsPropertyEqual, AggregationLengthEquals, BindingPath, Interactable,
	sinon) {

	var baseClass = CommonPageObject.createBaseClassForPageObject(),
		arrangement = new baseClass();

	retrieveOpaHelperFunctions("actions", arrangement, CommonPageObject.getOpaLibraries() );
	retrieveOpaHelperFunctions("assertions", arrangement, CommonPageObject.getOpaLibraries() );

	function createXmlView(sViewName) {
		var sView = [
			'<core:View xmlns:core="sap.ui.core" xmlns="sap.m">',
			'</core:View>'
		].join('');
		var oView;
		oView = sap.ui.xmlview({
			viewContent: sView
		});
		oView.setViewName(sViewName);
		return oView;
	}

	var assertOkOriginal = QUnit.assert.ok,
		assertOkStub,
		waitForOriginal = arrangement.waitFor,
		waitForStub;

	[NavContainer, App].forEach(function(fnConstructor) {

		QUnit.module("Matching in a :" + fnConstructor.getMetadata().getName(), {
			setup: function() {
				this.oOpa5 = new Opa5({autoWait: true});
				this.oView = createXmlView("my.namespace.View");
				// set i18n model on view
				this.i18nBundleUrl = jQuery.sap.getModulePath("testapp") + "/i18n/i18n.properties";
				var i18nModel = new ResourceModel({
					bundleUrl: this.i18nBundleUrl
				});
				this.oView.setModel(i18nModel, "i18n");
				this.oButton = new Button("fooButton");
				this.oButton.setText("Foo Button");
				this.oButton.setIcon("sap-icon://home");
				this.oButton.placeAt("qunit-fixture");
				this.oText = new Text({id: "fooText", text: i18nModel.getResourceBundle().getText("testText"), maxLines: 2});
				this.oText.setModel(i18nModel, "i18n");
				this.oText.placeAt("qunit-fixture");
				this.oTextWithDifferentI18NModel = new Text({id: "fooTextWithDifferentI18NModel", text: "{i18nFoo>testTextWithDifferentI18NModel}", maxLines: 2});
				this.oTextWithDifferentI18NModel.setModel(i18nModel, "i18nFoo");
				this.oTextWithDifferentI18NModel.placeAt("qunit-fixture");
				this.oInput = new Input("fooInput");
				this.oInput.setValue("Input value");
				this.oInput.placeAt("qunit-fixture");
				this.oBar = new Bar("fooBar");
				this.oBar.addContentLeft(this.oButton);
				this.oBar.placeAt("qunit-fixture");
				this.oView.placeAt("qunit-fixture");
				//Make sure that the control is rendered
				sap.ui.getCore().applyChanges();
			},
			teardown: function() {
				this.oView.destroy();
				this.oButton.destroy();
				this.oBar.destroy();
				this.oText.destroy();
				this.oTextWithDifferentI18NModel.destroy();
				this.oInput.destroy();
				Opa5.resetConfig();
				//Make sure that the control is rendered
				sap.ui.getCore().applyChanges();
				arrangement.waitFor = waitForOriginal;
				waitForStub = null;
				QUnit.assert.ok = assertOkOriginal;
				assertOkStub = null;
			}
		});

		opaTest("Test reuse functions of CommonControl", function(oOpa) {
			Opa5.assert.ok(arrangement.iDoActionByID({
				id: "fooButton",
				actions: new Press()
			}), "Should do action by control type");
			
			Opa5.assert.ok(arrangement.iDoActionByControlType({
				controlType: "sap.m.Button",
				actions: new Press()
			}), "Should do action by control type");
			
			Opa5.assert.ok(arrangement.iShouldSeeControlByID({
				id: "fooText"
			}), "Should find control by ID as object");
			Opa5.assert.ok(arrangement.iShouldSeeControlByID("fooButton", "Should find control by ID as string"));
			
			Opa5.assert.ok(arrangement.iShouldSeeControlByControlType({
				controlType: "sap.m.Button"
			}), "Should find control by control type (1)");
			
			Opa5.assert.ok(arrangement.iShouldSeeControlByControlType({
				controlType: "sap.m.Text"
			}), "Should find control by control type (2)");
			
			Opa5.assert.ok(arrangement.iShouldSeeControlByText({
				text: "Foo Button"
			}), "Should find control by matcher on its text");
			
			Opa5.assert.ok(arrangement.iShouldSeeControlByI18nKey({
				propertyName: "text",
				key: "testText"
			}), "Should find control by matcher on its i18n-key");
			
			Opa5.assert.ok(arrangement.iShouldSeeControlByI18nKey({
				key: "testTextWithDifferentI18NModel",
				modelName: "i18nFoo"
			}), "Should find control by matcher on its i18n-key");
			
			Opa5.assert.ok(arrangement.iShouldSeeControlByAttribute({
				attributeName: "maxLines",
				attributeValue : 2 
			}), "Should find control by matcher on specific attribute");
			
			Opa5.assert.ok(arrangement.iShouldSeeValueInControlByID({
				id: "fooInput",
				value: "Input value"
			}), "Should find expected value in control");
			
			Opa5.assert.ok(arrangement.iShouldSeeTextInControlByID({
				id: "fooText",
				text: "Foo Text"
			}), "Should find expected text in control");
			
			/*Opa5.assert.ok(arrangement.iDoSuccessByID({
				id: "fooText",
				matchers: new Interactable(),
				success: function(oControl) {
					return 	Opa5.assert.strictEqual(oControl.getText(), "Foo Text", "Passed test");
				}
			}), "Should do success by control type");
			
			Opa5.assert.ok(arrangement.iDoSuccessByControlType({
				controlType: "sap.m.Button",
				success: function(aControl) {
					return Opa5.assert.strictEqual(aControl[0].getText(), "Foo Button", "Passed test");
				}
			}), "Should do success by control type");
			
			Opa5.assert.ok(arrangement.iDoSuccessOnNestedControlByID({
				id: "fooBar",
				nestedControlType: "sap.m.Button",
				nestedAttributeName: "text",
				nestedAttributeValue: "Foo Button",
				nestedSuccess: function() {
					return 	Opa5.assert.ok(true, "Passed test");
				}
			}), "Should do success on nested control by id of ancestor control");
			
			Opa5.assert.ok(arrangement.iDoSuccessOnNestedControlByID({
				id: "fooBar",
				nestedControlType: "sap.m.Button",
				nestedAttributeName: "text",
				nestedAttributeValue: "Foo Button",
				nestedSuccess: function() {
					return 	Opa5.assert.ok(true, "Passed test");
				}
			}), "Should do success action on nested control by id of ancestor control");*/
			

			/*Opa5.assert.ok(arrangement.iShouldSeeControlByIDThatContainsI18nKey({
				id: "fooText",
				propertyName: "text",
				key: "testText"
			}), "Should find control by id and expected i18n key");*/
		});

		QUnit.test("Test mandatory options of CommonControl", function(assert) {
			var done = assert.async();
			if (jQuery.isEmptyObject(waitForStub)) {
				waitForStub = sinon.stub(arrangement, "waitFor").returns(true);
			}
			if (jQuery.isEmptyObject(assertOkStub)) {
				assertOkStub = sinon.stub(QUnit.assert, "ok");
			}
			//negative cases - mandatory options are missing
			assert.notOk(arrangement.iShouldSeeControlByID({
			}, assertOkStub), "iShouldSeeControlByID should fail due to missing id");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iShouldSeeControlByControlType({
			}, assertOkStub), "iShouldSeeControlByControlType should fail due to missing controlType");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeControlByText({
			}, assertOkStub), "iShouldSeeControlByText should fail due to missing text");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeControlByI18nKey({
			}, assertOkStub), "iShouldSeeControlByI18nKey should fail due to missing propertyName and key");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeControlByAttribute({
			}, assertOkStub), "iShouldSeeControlByText should fail due to missing attribute");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iShouldSeeValueInControlByID({}, assertOkStub),
				"iShouldSeeValueInControlByID should fail due to missing id and value");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iShouldSeeTextInControlByID({}, assertOkStub),
				"iShouldSeeTextInControl should fail due to missing id and text");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();

			/*assert.notOk(arrangement.iShouldSeeAttributeInControlByID({}, assertOkStub),
				"iShouldSeeAttributeInControl should fail due to missing id, attribute and value");
			sinon.assert.calledThrice(assertOkStub);
			assertOkStub.reset();*/
			
			/*assert.notOk(arrangement.iDoSuccessByID({}, assertOkStub),
				"iDoSuccessByID should fail due to missing id and success");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iDoSuccessByControlType({}, assertOkStub),
				"iDoSuccessByControlType should fail due to missing controlType and success");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();*/
			
			assert.notOk(arrangement.iDoActionByID({}, assertOkStub),
				"iDoActionByID should fail due to missing id and actions");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iDoActionByControlType({}, assertOkStub),
				"iDoActionByControlType should fail due to missing controlType and actions");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();

			//positive cases - all mandatory options passed
			QUnit.assert.ok = assertOkOriginal;

			assert.ok(arrangement.iShouldSeeControlByID({
				id: "testID"
			}, waitForStub), "iShouldSeeControlByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iShouldSeeControlByControlType({
				controlType: "sap.m.Button"
			}, waitForStub), "iShouldSeeControlByControlType should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeControlByText({
				text: "Foo Button"
			}, waitForStub), "iShouldSeeControlByText should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeControlByI18nKey({
				key: "testText"
			}, waitForStub), "iShouldSeeControlByI18nKey should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeControlByAttribute({
				attributeName: "maxLines",
				attributeValue: 2
			}, waitForStub), "iShouldSeeControlByAttribute should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();

			assert.ok(arrangement.iShouldSeeValueInControlByID({
				id: "testID",
				value: "testvalue"
			}, waitForStub), "iShouldSeeValueInControlByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iShouldSeeTextInControlByID({
				id: "testID",
				text: "Foo Text"
			}, waitForStub), "iShouldSeeTextInControlByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iShouldSeeAttributeInControlByID({
				id: "id",
				attributeName: "attribute",
				attributeValue: "testvalue",
				fGetAttribute: function(oControl) {
					return oControl.getValue();
				}
			}, waitForStub), "iShouldSeeAttributeInControlByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeAttributeInControl({
				controlType: "sap.m.Button",
				attributeName: "icon",
				attributeValue: "sap-icon://home",
				fGetAttribute: function(oControl) {
					return oControl.getValue();
				}
			}, waitForStub), "iShouldSeeAttributeInControl should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeAttributeInControl({
				controlType: "sap.m.Button",
				attributeName: "icon",
				attributeValue: "sap-icon://home",
				matchers: [new PropertyStrictEquals({
					name: "text",
					value: "Foo Button"
				})],
				fGetAttribute: function(oControl) {
					return oControl.getValue();
				}
			}, waitForStub), "iShouldSeeAttributeOfControl with matcher should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iDoActionByID({
				id: "fooButton",
				actions: new Press()
			}, waitForStub), "iDoActionByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iDoActionByControlType({
				controlType: "sap.m.Button",
				matchers: [new PropertyStrictEquals({
					name: "text",
					value: "Foo Button"
				})],
				actions: new Press()
			}, waitForStub), "iDoActionByControlType should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			/*assert.ok(arrangement.iDoSuccessByID({
				id: "fooButton",
				success: function() {
					return true;
				}
			}, waitForStub), "iDoSuccessByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iDoSuccessByControlType({
				controlType: "sap.m.Button",
				success: function() {
					return true;
				}
			}, waitForStub), "iDoSuccessByControlType should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iDoSuccessByControlType({
				controlType: "sap.m.Button",
				matchers: [new PropertyStrictEquals({
					name: "text",
					value: "Foo Button"
				})],
				success: function() {
					return true;
				}
			}, waitForStub), "iDoSuccessByControlType should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();*/

			done();
		});

	});
});