/*global retrieveOpaHelperFunctions */
sap.ui.define([
	"sap/ui/test/Opa",
	"sap/ui/test/Opa5",
	"sap/ui/test/opaQunit",
	"test/opareuse/control/CommonPageObject",
	"sap/m/App",	
	"sap/m/Button",
	"sap/m/ComboBox",
	"sap/m/ComboBoxBase",	
	"sap/m/Dialog",	
	"sap/m/Input",	
	"sap/m/InputBase",		
	"sap/m/Label",
	"sap/m/Link",
	"sap/m/ListBase",		
	"sap/m/NavContainer",
	"sap/m/Page",
    "sap/m/SearchField",	
	"sap/m/Table",
	"sap/m/Text",	
	"sap/ui/comp/smartfield/SmartField",
	"sap/ui/comp/smarttable/SmartTable",	
	"sap/ui/core/Control",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/base/Object",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationContainsPropertyEqual",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/Interactable",	
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(Opa, Opa5, opaTest, CommonPageObject,
    App, Button, ComboBox, ComboBoxBase, Dialog, Input, InputBase, Label, Link, ListBase, NavContainer, Page, SearchField, Table, Text, SmartField, SmartTable,
    Control, ResourceModel,	Object,
    Press, Properties, PropertyStrictEquals, AggregationFilled, AggregationContainsPropertyEqual, AggregationLengthEquals, BindingPath, Interactable,
	sinon) {
		
	var baseClass = CommonPageObject.createBaseClassForPageObject(),
		arrangement = new baseClass();
		
    retrieveOpaHelperFunctions("actions", arrangement, CommonPageObject.getOpaLibraries() );
	retrieveOpaHelperFunctions("assertions", arrangement, CommonPageObject.getOpaLibraries() );

	function createXmlView(sViewName) {
		var sView = [
			'<core:View xmlns:core="sap.ui.core" xmlns="sap.m">',
			'</core:View>'
		].join('');
		var oView;
		oView = sap.ui.xmlview({
			viewContent: sView
		});
		oView.setViewName(sViewName);
		return oView;
	}

	var assertOkOriginal = QUnit.assert.ok,
		assertOkStub,
		waitForOriginal = arrangement.waitFor,
		waitForStub;

	[NavContainer, App].forEach(function(fnConstructor) {

		QUnit.module("Matching in a :" + fnConstructor.getMetadata().getName(), {

			setup: function() {
				this.oOpa5 = new Opa5({autoWait: true});
				//assertOkStub = sinon.stub(QUnit.assert, "ok");
				this.oView = createXmlView("my.namespace.View");
				// set i18n model on view
				var i18nModel = new ResourceModel({
					bundleUrl: "testapp/i18n/i18n.properties"
				});
				this.oView.setModel(i18nModel, "i18n");
				this.oInput = new Input("fooInput");
				this.oInput.setValue("Foo Input");
				this.oInput.placeAt("qunit-fixture");
				this.oView.placeAt("qunit-fixture");
				//Make sure that the control is rendered
				sap.ui.getCore().applyChanges();
			},
			teardown: function() {
				this.oView.destroy();
				this.oInput.destroy();
				Opa5.resetConfig();
				//Make sure that the control is rendered
				sap.ui.getCore().applyChanges();
				arrangement.waitFor = waitForOriginal;
				waitForStub = null;
				QUnit.assert.ok = assertOkOriginal;
				assertOkStub = null;
			}
		});

		opaTest("Test reuse functions of CommonInput", function() {
			
			Opa5.assert.ok(arrangement.iShouldSeeInputByID({
				id: "fooInput"
			}), "Should find Input by id as object");
			Opa5.assert.ok(arrangement.iShouldSeeInputByID("fooInput"), "Should find Input by id");

			Opa5.assert.ok(arrangement.iShouldSeeInputByValue({
				value: "Foo Input"
			}), "Should find Input by value as object");
			Opa5.assert.ok(arrangement.iShouldSeeInputByValue("Foo Input"), "Should find Input by value");
			
			Opa5.assert.ok(arrangement.iShouldSeeValueInInputByID({
				id: "fooInput",
				value: "Foo Input"
			}), "Should find passed value in Input by id as object");
			
			Opa5.assert.ok(arrangement.iEnterValueInInputByID({
				id: "fooInput",
				value: "Foo Input"
			}), "Should enter passed value in Input by id as object");
			
			Opa5.assert.ok(arrangement.iEnterValueInInputByValue({
				value: "Foo Input",
				newValue: "Foo Input Changed"
			}), "Should enter passed value in Input by value as object");
		});

		QUnit.test("Test mandatory options of CommonInput", function(assert) {
			var done = assert.async();
			if ($.isEmptyObject(waitForStub)) {
				waitForStub = sinon.stub(arrangement, "waitFor").returns(true);
			}
			if ($.isEmptyObject(assertOkStub)) {
				assertOkStub = sinon.stub(QUnit.assert, "ok");
			}
			//negative cases - mandatory options are missing
			assert.notOk(arrangement.iShouldSeeInputByID({
			}, assertOkStub), "iShouldSeeInputByID should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeInputByValue({
			}, assertOkStub), "iShouldSeeInputByValue should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeValueInInputByID({
			}, assertOkStub), "iShouldSeeValueInInputByID should fail due to missing id and value");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iEnterValueInInputByID({
			}, assertOkStub), "iEnterValueInInputByID should fail due to missing id and value");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iEnterValueInInputByValue({
			}, assertOkStub), "iEnterValueInInputByValue should fail due to missing value and newValue");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();

			//positive cases - all mandatory options passed
			QUnit.assert.ok = assertOkOriginal;

			assert.ok(arrangement.iShouldSeeInputByID({
				id: "fooInput"
			}, waitForStub), "iShouldSeeInputByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeInputByValue({
				value: "Foo Input"
			}, waitForStub), "iShouldSeeInputByValue should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeValueInInputByID({
				id: "fooInput",
				value: "Foo Input"
			}, waitForStub), "iShouldSeeValueInInputByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iEnterValueInInputByID({
				id: "fooInput",
				value: "Foo Input"
			}, waitForStub), "iEnterValueInInputByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iEnterValueInInputByValue({
				value: "Foo Input",
				newValue: "Foo Input Changed"
			}, waitForStub), "iEnterValueInInputByValue should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			done();
		});

	});
});