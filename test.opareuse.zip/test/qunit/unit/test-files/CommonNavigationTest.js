/*global retrieveOpaHelperFunctions */
sap.ui.define([
	"sap/ui/test/Opa",
	"sap/ui/test/Opa5",
	"sap/ui/test/opaQunit",
	"test/opareuse/control/CommonPageObject",
	"sap/m/App",
	"sap/m/Button",
	"sap/m/Input",
	"sap/m/InputBase",
	"sap/m/Label",
	"sap/m/Link",
	"sap/m/NavContainer",
	"sap/m/Page",
	"sap/m/Table",
	"sap/m/Text",
	"sap/ui/comp/smartfield/SmartField",
	"sap/ui/comp/smarttable/SmartTable",
	"sap/ui/core/Control",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/base/Object",
	"sap/ui/generic/app/navigation/service/NavigationHandler",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationContainsPropertyEqual",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/Interactable",
	//"unitTest/CrossAppNavigationServiceMock",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(Opa, Opa5, opaTest, CommonPageObject,
	App, Button, Input, InputBase, Label, Link, NavContainer, Page, Table, Text, SmartField, SmartTable,
	Control, ResourceModel, Object, NavigationHandler,
	Press, Properties, PropertyStrictEquals, AggregationFilled, AggregationContainsPropertyEqual, AggregationLengthEquals, BindingPath,
	Interactable, //CrossAppNavigationServiceMock,
	sinon) {

	var baseClass = CommonPageObject.createBaseClassForPageObject(),
		arrangement = new baseClass();

	retrieveOpaHelperFunctions("actions", arrangement, CommonPageObject.getOpaLibraries());
	retrieveOpaHelperFunctions("assertions", arrangement, CommonPageObject.getOpaLibraries());

	function createXmlView(sViewName) {
		var sView = [
			'<core:View xmlns:core="sap.ui.core" xmlns="sap.m">',
			'</core:View>'
		].join('');
		var oView;
		oView = sap.ui.xmlview({
			viewContent: sView
		});
		oView.setViewName(sViewName);
		return oView;
	}

	var assertOkOriginal = QUnit.assert.ok,
		assertOkStub,
		waitForOriginal = arrangement.waitFor,
		waitForStub;

	[NavContainer, App].forEach(function(fnConstructor) {

		QUnit.module("Matching in a :" + fnConstructor.getMetadata().getName(), {

			setup: function() {
				this.oOpa5 = new Opa5({
					autoWait: true
				});
				this.oView = createXmlView("view0");
				this.i18nBundleUrl = jQuery.sap.getModulePath("testapp") + "/i18n/i18n.properties";
				var i18nModel = new ResourceModel({
					bundleUrl: this.i18nBundleUrl
				});
				this.oPage = new Page({
					id: "fooPage",
					title: "{i18n>fooTitle}"
				});
				this.oPage.setModel(i18nModel, "i18n");
				this.oPage.placeAt("qunit-fixture");
				this.oView.placeAt("qunit-fixture");
				sap.ui.getCore().applyChanges();
			},
			teardown: function() {
				this.oView.destroy();
				this.oPage.destroy();
				Opa5.resetConfig();
				sap.ui.getCore().applyChanges();
				arrangement.waitFor = waitForOriginal;
				waitForStub = null;
				QUnit.assert.ok = assertOkOriginal;
				assertOkStub = null;
			}
		});
		
		QUnit.test("Test mandatory options of CommonNavigation", function(assert) {
			var done = assert.async();
			if ($.isEmptyObject(waitForStub)) {
				waitForStub = sinon.stub(arrangement, "waitFor").returns(true);
			}
			if ($.isEmptyObject(assertOkStub)) {
				assertOkStub = sinon.stub(QUnit.assert, "ok");
			}
			//negative cases - mandatory options are missing
			assert.notOk(arrangement.iShouldSeeAppByIntentAndParameters({}, assertOkStub),
				"iShouldSeeAppByIntentAndParameters should fail due to missing semanticObject and action");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();

			//positive cases - all mandatory options passed
			QUnit.assert.ok = assertOkOriginal;

			assert.ok(arrangement.iShouldSeeAppByIntentAndParameters({
				semanticObject: "fooSemanticObject",
				action: "fooAction"
			}, waitForStub), "iShouldSeeAppByIntentAndParameters should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			done();
		});

	});
});