/*global retrieveOpaHelperFunctions */
sap.ui.define([
	"sap/ui/test/Opa",
	"sap/ui/test/Opa5",
	"sap/ui/test/opaQunit",
	"test/opareuse/control/CommonPageObject",
	"sap/m/App",	
	"sap/m/Button",
	"sap/m/Input",	
	"sap/m/InputBase",		
	"sap/m/Label",
	"sap/m/Link",	
	"sap/m/NavContainer",
	"sap/m/Page",	
	"sap/m/Table",
	"sap/m/Text",	
	"sap/ui/core/Control",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/base/Object",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationContainsPropertyEqual",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/Interactable",	
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(Opa, Opa5, opaTest, CommonPageObject, App, Button, Input, InputBase, Label, Link, NavContainer, Page, Table, Text, Control, ResourceModel,
	Object, Press, Properties, PropertyStrictEquals, AggregationFilled, AggregationContainsPropertyEqual, AggregationLengthEquals, BindingPath, Interactable,
	sinon) {

	var baseClass = CommonPageObject.createBaseClassForPageObject(),
		arrangement = new baseClass();

	retrieveOpaHelperFunctions("actions", arrangement, CommonPageObject.getOpaLibraries() );
	retrieveOpaHelperFunctions("assertions", arrangement, CommonPageObject.getOpaLibraries() );

	function createXmlView(sViewName) {
		var sView = [
			'<core:View xmlns:core="sap.ui.core" xmlns="sap.m">',
			'</core:View>'
		].join('');
		var oView;
		oView = sap.ui.xmlview({
			viewContent: sView
		});
		oView.setViewName(sViewName);
		return oView;
	}

	var assertOkOriginal = QUnit.assert.ok,
		assertOkStub,
		waitForOriginal = arrangement.waitFor,
		waitForStub;

	[NavContainer, App].forEach(function(fnConstructor) {

		QUnit.module("Matching in a :" + fnConstructor.getMetadata().getName(), {

			beforeEach: function() {
				this.oOpa5 = new Opa5({autoWait: true});
				this.oView = createXmlView("view0");
				this.i18nBundleUrl = jQuery.sap.getModulePath("testapp") + "/i18n/i18n.properties";
				var i18nModel = new ResourceModel({
					bundleUrl: this.i18nBundleUrl
				});
				this.oLink = new Link({id: "fooLink", text: "{i18n>fooLink}"});
				this.oLink.setModel(i18nModel, "i18n");
				this.oLink.placeAt("qunit-fixture");
				this.oView.placeAt("qunit-fixture");
				sap.ui.getCore().applyChanges();
			},
			afterEach: function() {
				this.oView.destroy();
				this.oLink.destroy();
				Opa5.resetConfig();
				sap.ui.getCore().applyChanges();
				arrangement.waitFor = waitForOriginal;
				waitForStub = null;
				QUnit.assert.ok = assertOkOriginal;
				assertOkStub = null;
			}
		});

		opaTest("Test reuse functions of CommonLink", function() {
			Opa5.assert.ok(arrangement.iShouldSeeLinkByID({
				id: "fooLink"
			}), "Should find Link by id as object");
			Opa5.assert.ok(arrangement.iShouldSeeLinkByID("fooLink"), "Should find Link by id");
			
			Opa5.assert.ok(arrangement.iShouldSeeLinkByText({
				text: "Foo Link"
			}), "Should find Link by text as object");
				Opa5.assert.ok(arrangement.iShouldSeeLinkByText("Foo Link"), "Should find Link by text");
				
			Opa5.assert.ok(arrangement.iShouldSeeLinkByI18nKey({
				key: "fooLink"
			}), "Should find Link by i18n-key as object");
				Opa5.assert.ok(arrangement.iShouldSeeLinkByI18nKey("fooLink"), "Should find Link by i18n-key");	
				
			Opa5.assert.ok(arrangement.iPressLinkByID({
				id: "fooLink"
			}), "Should press Link by id as object");
			Opa5.assert.ok(arrangement.iShouldSeeLinkByID("fooLink"), "Should press Link by id");	
			
			Opa5.assert.ok(arrangement.iPressLinkByText({
				text: "Foo Link"
			}), "Should press Link by text as object");
			Opa5.assert.ok(arrangement.iPressLinkByText("Foo Link"), "Should press Link by text");
			
			Opa5.assert.ok(arrangement.iPressLinkByI18nKey({
				key: "fooLink"
			}), "Should press Link by i18n-key as object");
			Opa5.assert.ok(arrangement.iPressLinkByI18nKey("fooLink"), "Should press Link by i18n-key");	
		});

		QUnit.test("Test mandatory options of CommonLink", function(assert) {
			var done = assert.async();
			if ($.isEmptyObject(waitForStub)) {
				waitForStub = sinon.stub(arrangement, "waitFor").returns(true);
			}
			if ($.isEmptyObject(assertOkStub)) {
				assertOkStub = sinon.stub(QUnit.assert, "ok");
			}
			//negative cases - mandatory options are missing
			assert.notOk(arrangement.iShouldSeeLinkByID({
			}, assertOkStub), "iShouldSeeLinkByID should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iShouldSeeLinkByText({
			}, assertOkStub), "iShouldSeeLinkByText should fail due to missing text");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeLinkByI18nKey({
			}, assertOkStub), "iShouldSeeLinkByI18nKey should fail due to missing key");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iPressLinkByID({
			}, assertOkStub), "iPressLinkByID should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();

			assert.notOk(arrangement.iPressLinkByText({
			}, assertOkStub), "iPressLinkByText should fail due to missing text");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iPressLinkByI18nKey({
			}, assertOkStub), "iPressLinkByI18nKey should fail due to missing key");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();

			//positive cases - all mandatory options passed
			QUnit.assert.ok = assertOkOriginal;

			assert.ok(arrangement.iShouldSeeLinkByID({
				id: "testID"
			}, waitForStub), "iShouldSeeLinkByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iShouldSeeLinkByText({
				text: "Foo Link"
			}, waitForStub), "iShouldSeeLinkByText should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeLinkByI18nKey({
				key: "fooLink"
			}, waitForStub), "iShouldSeeLinkByI18nKey should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();
			
			assert.ok(arrangement.iPressLinkByID({
				id: "fooLink"
			}, waitForStub), "iPressLinkByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();

			assert.ok(arrangement.iPressLinkByText({
				text: "Foo Link"
			}, waitForStub), "iPressLinkByText should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();
			
			assert.ok(arrangement.iPressLinkByI18nKey({
				key: "fooLink"
			}, waitForStub), "iPressLinkByI18nKey should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			assertOkStub.reset();
			waitForStub.reset();

			done();
		});

	});
});