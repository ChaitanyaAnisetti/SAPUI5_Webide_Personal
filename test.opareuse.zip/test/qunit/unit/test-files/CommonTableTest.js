/*global retrieveOpaHelperFunctions */
sap.ui.define([
	"sap/ui/test/Opa",
	"sap/ui/test/Opa5",
	"sap/ui/test/opaQunit",
	"test/opareuse/control/CommonPageObject",
	"sap/m/App",	
	"sap/m/Button",
	"sap/m/CheckBox",
	"sap/m/Column",	
	"sap/m/ColumnListItem",	
	"sap/m/ComboBox",
	"sap/m/ComboBoxBase",	
	"sap/m/Dialog",	
	"sap/m/Input",	
	"sap/m/InputBase",		
	"sap/m/Label",
	"sap/m/Link",
	"sap/m/ListBase",		
	"sap/m/NavContainer",
	"sap/m/Page",
    "sap/m/SearchField",
	"sap/m/StandardListItem",    
	"sap/m/Table",
	"sap/m/Text",	
	"sap/ui/comp/smartfield/SmartField",
	"sap/ui/comp/smarttable/SmartTable",	
	"sap/ui/core/Control",
	"sap/ui/core/Item",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/base/Object",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/AggregationContainsPropertyEqual",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/Interactable",	
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(Opa, Opa5, opaTest, CommonPageObject,
    App, Button, CheckBox, Column, ColumnListItem, ComboBox, ComboBoxBase, Dialog, Input, InputBase, Label, Link, ListBase, NavContainer, Page, SearchField, StandardListItem, Table, Text,
    SmartField, SmartTable, Control, Item, ResourceModel,	Object,
    Press, Properties, PropertyStrictEquals, AggregationFilled, AggregationContainsPropertyEqual, AggregationLengthEquals, BindingPath, Interactable,
	sinon) {
		
	var baseClass = CommonPageObject.createBaseClassForPageObject(),
		arrangement = new baseClass();
		
	retrieveOpaHelperFunctions("actions", arrangement, CommonPageObject.getOpaLibraries() );
	retrieveOpaHelperFunctions("assertions", arrangement, CommonPageObject.getOpaLibraries() );

	function createXmlView(sViewName) {
		var sView = [
			'<core:View xmlns:core="sap.ui.core" xmlns="sap.m">',
			'</core:View>'
		].join('');
		var oView;
		oView = sap.ui.xmlview({
			viewContent: sView
		});
		oView.setViewName(sViewName);
		return oView;
	}

	var assertOkOriginal = QUnit.assert.ok,
		assertOkStub,
		waitForOriginal = arrangement.waitFor,
		waitForStub;

	[NavContainer, App].forEach(function(fnConstructor) {

		QUnit.module("Matching in a :" + fnConstructor.getMetadata().getName(), {

			setup: function() {
				this.oOpa5 = new Opa5({autoWait: true});
				//assertOkStub = sinon.stub(QUnit.assert, "ok");
				this.oView = createXmlView("my.namespace.View");
				// set i18n model on view
				var i18nModel = new ResourceModel({
					bundleUrl: "testapp/i18n/i18n.properties"
				});
				this.oView.setModel(i18nModel, "i18n");
				this.oTable = new Table("fooTable");
				this.oTable.setMode(sap.m.ListMode.MultiSelect);
				this.oTable.addColumn(new sap.m.Column({id: "fooColumn2", header: new sap.m.Label({text : "Column 1"})}));
				this.oTable.addColumn(new sap.m.Column({id: "fooColumn3", header: new sap.m.Label({text : "Column 2"})}));
				var oListItem1 = new ColumnListItem("fooListItem1");
				oListItem1.addCell(new Text({id: "fooText11", text: "Foo List Item 1.1"}));
				oListItem1.addCell(new Text({id: "fooText12", text: "Foo List Item 1.2"}));
				var oListItem2 = new ColumnListItem("fooListItem2");
				oListItem2.addCell(new Text({id: "fooText21", text: "Foo List Item 2.1"}));
				oListItem2.addCell(new Text({id: "fooText22", text: "Foo List Item 2.2"}));
				var oListItem3 = new ColumnListItem("fooListItem3");
				var oToolBar31 = new sap.m.Toolbar({id: "fooToolBar31"});
				oToolBar31.addContent(new Text({id: "fooText31", text: "Foo List Item 3.1"}));
				oListItem3.addCell(oToolBar31);
				oListItem3.addCell(new Text({id: "fooText32", text: "Foo List Item 3.2"}));
				this.oTable.addItem(oListItem1);
				this.oTable.addItem(oListItem2);
				this.oTable.addItem(oListItem3);
				this.oTable.setGrowing(true);
				this.oTable.setGrowingThreshold(2);
				this.oTable.placeAt("qunit-fixture");
				this.oView.placeAt("qunit-fixture");
				sap.ui.getCore().applyChanges();
			},
			teardown: function() {
				this.oTable.destroy();
				this.oView.destroy();
				Opa5.resetConfig();
				sap.ui.getCore().applyChanges();
				arrangement.waitFor = waitForOriginal;
				waitForStub = null;
				QUnit.assert.ok = assertOkOriginal;
				assertOkStub = null;
			}
		});

		opaTest("Test reuse functions of CommonTable", function() {
			Opa5.assert.ok(arrangement.iPressOnRowInTableByID({
				id: "fooTable",
				row: 2
			}), "Should press on passed row in Table by id as object");
			
			Opa5.assert.ok(arrangement.iPressOnRowInTable({
				row: 2
			}), "Should press on passed row in first Table of the view by object");
			Opa5.assert.ok(arrangement.iPressOnRowInTable(2), "Should press on passed row in first Table of the view");
			
			Opa5.assert.ok(arrangement.iPressMoreDataButtonInTableByID({
				id: "fooTable"
			}), "Should press on more data button of Table by id as object");
			Opa5.assert.ok(arrangement.iPressMoreDataButtonInTableByID("fooTable"), "Should press on more data button of Table by id");
			
			Opa5.assert.ok(arrangement.iPressMoreDataButtonInTable(), "Should press on more data button in first Table of the view");
			
			Opa5.assert.ok(arrangement.iToggleRowSelectionInTableByRowAndID({
				id: "fooTable",
				row: 2
			}), "Should toggle row selection in Table by passed id and row as object");
			
			Opa5.assert.ok(arrangement.iPressOnRowInTableByTextContent({
				text: "Foo List Item 2.2" 
			}), "Should press on row in Table by passed text content as object");
			
			Opa5.assert.ok(arrangement.iPressOnRowInTableByTextContent({
				text: "Foo List Item 2.2" 
			}), "Should press on row in Table by passed text content as object");
			
			Opa5.assert.ok(arrangement.iToggleRowSelectionInTableByTextContent({
				text: "Foo List Item 2.2" 
			}), "Should toggle selection in Table by related passed text content as object");
			
			Opa5.assert.ok(arrangement.iToggleRowSelectionInTableByTextContent({
				text: "Foo List Item 3.1"
			}), "Should toggle selection in Table by related passed text content as object");
			
			Opa5.assert.ok(arrangement.iShouldSeeTableByID({
				id: "fooTable"
			}), "Should find Table by id as object");
			Opa5.assert.ok(arrangement.iShouldSeeTableByID("fooTable"), "Should find Table by id");
			
			Opa5.assert.ok(arrangement.iShouldSeeItemsInTableByID({
				id: "fooTable"
			}), "Should find Table with at least one item by id as object");
			Opa5.assert.ok(arrangement.iShouldSeeItemsInTableByID("fooTable"), "Should find Table with at least one item by id");
			
			Opa5.assert.ok(arrangement.iShouldSeeLengthOfTableByID({
				id: "fooTable",
				length: 3
			}), "Should find Table with passed length by id as object");

			Opa5.assert.ok(arrangement.iShouldSeeLengthOfTable({
				length: 3
			}), "Should find Table with passed length as object");
			Opa5.assert.ok(arrangement.iShouldSeeLengthOfTable(3), "Should find Table with passed length");
			
			Opa5.assert.ok(arrangement.iShouldSeeTableByTextContent({
				text: "Foo List Item 3.1"
			}), "Should find Table by passed text as object");
			Opa5.assert.ok(arrangement.iShouldSeeTableByTextContent("Foo List Item 3.2"), "Should find Table by passed text");
			
			Opa5.assert.ok(arrangement.iShouldSeeTextContentInTableByID({
				id: "fooTable",
				text: "Foo List Item 3.1"
			}), "Should find Table with passed text by id as object");
		});

		QUnit.test("Test mandatory options of CommonTable", function(assert) {
			var done = assert.async();
			if ($.isEmptyObject(waitForStub)) {
				waitForStub = sinon.stub(arrangement, "waitFor").returns(true);
			}
			if ($.isEmptyObject(assertOkStub)) {
				assertOkStub = sinon.stub(QUnit.assert, "ok");
			}
			//negative cases - mandatory options are missing
			assert.notOk(arrangement.iPressOnRowInTableByID({
			}, assertOkStub), "iPressOnRowInTableByID should fail due to missing id by object");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iPressOnRowInTable({
			}, assertOkStub), "iPressOnRowInTable should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iPressOnRowInTable({
			}, assertOkStub), "iPressOnRowInTable should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iPressMoreDataButtonInTableByID({
			}, assertOkStub), "iPressMoreDataButtonInTableByID should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iToggleRowSelectionInTableByRowAndID({
			}, assertOkStub), "iToggleRowSelectionInTableByRowAndID should fail due to missing id and row by object");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iToggleRowSelectionInTableByTextContent({
			}, assertOkStub), "iToggleRowSelectionInTableByTextContent should fail due to missing text content by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeTableByID({
			}, assertOkStub), "iShouldSeeTableByID should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeItemsInTableByID({
			}, assertOkStub), "iShouldSeeItemsInTableByID should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeLengthOfTableByID({
			}, assertOkStub), "iShouldSeeLengthOfTableByID should fail due to missing id by object");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeLengthOfTable({
			}, assertOkStub), "iShouldSeeLengthOfTable should fail due to missing id by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeTableByTextContent({
			}, assertOkStub), "iShouldSeeTableByTextContent should fail due to missing text by object");
			sinon.assert.calledOnce(assertOkStub);
			assertOkStub.reset();
			
			assert.notOk(arrangement.iShouldSeeTextContentInTableByID({
			}, assertOkStub), "iShouldSeeTextContentInTableByID should fail due to missing id by object");
			sinon.assert.calledTwice(assertOkStub);
			assertOkStub.reset();

			//positive cases - all mandatory options passed
			QUnit.assert.ok = assertOkOriginal;
			
			assert.ok(arrangement.iPressOnRowInTableByID({
				id: "fooTable",
				row: 3
			}, waitForStub), "iPressOnRowInTableByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iPressOnRowInTable({
				row: 3
			}, waitForStub), "iPressOnRowInTable should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iPressMoreDataButtonInTableByID({
				id: "fooTable",
				row: 3
			}, waitForStub), "iPressMoreDataButtonInTableByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iPressMoreDataButtonInTable({
			}, waitForStub), "iPressMoreDataButtonInTable should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iToggleRowSelectionInTableByRowAndID({
				id: "fooTable",
				row: 2
			}, waitForStub), "iToggleRowSelectionInTableByRowAndID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iToggleRowSelectionInTableByTextContent({
				text: "Foo List Item 2.2"
			}, waitForStub), "iToggleRowSelectionInTableByTextContent should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();

			assert.ok(arrangement.iShouldSeeTableByID({
				id: "fooTable"
			}, waitForStub), "iShouldSeeTableByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeItemsInTableByID({
				id: "fooTable"
			}, waitForStub), "iShouldSeeItemsInTableByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeLengthOfTableByID({
				id: "fooTable",
				length: 3
			}, waitForStub), "iShouldSeeLengthOfTableByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeLengthOfTable({
				length: 3
			}, waitForStub), "iShouldSeeLengthOfTable should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeTableByTextContent({
				text: "Foo List Item 2.2"
			}, waitForStub), "iShouldSeeTableByTextContent should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			assert.ok(arrangement.iShouldSeeTextContentInTableByID({
				id: "fooTable",
				text: "Foo List Item 2.2"
			}, waitForStub), "iShouldSeeTextContentInTableByID should succeed as all mandatory options are passed");
			sinon.assert.calledOnce(waitForStub);
			waitForStub.reset();
			
			done();
		});

	});
});