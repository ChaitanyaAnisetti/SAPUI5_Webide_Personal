sap.ui.define([
		'sap/m/Button',
		'sap/m/Dialog',
		'sap/m/List',
		'sap/m/MessageToast',
		'sap/m/StandardListItem',
		'sap/ui/core/mvc/Controller',
		'sap/ui/model/json/JSONModel',
		'sap/ui/core/util/MockServer',
		"sap/ui/model/resource/ResourceModel",
		'sap/ui/generic/app/navigation/service/NavigationHandler'
	],

	function (Button, Dialog, List, MessageToast, StandardListItem, Controller, JSONModel, MockServer, ResourceModel, NavigationHandler) {
		"use strict";

		return Controller.extend("opa5reuselib.controller.View1", {
			onInit: function () {
				var view = this.getView();
				// set explored app's demo model on this sample
				var oMockServer = new MockServer({
					rootUri: "sapuicompsmarttable/"
				});
				this._oMockServer = oMockServer;
				oMockServer.simulate("localService/metadata.xml", "localService/mockdata/");
				oMockServer.start();
				var oModel = new sap.ui.model.odata.ODataModel("sapuicompsmarttable", true);
				oModel.setCountSupported(false);
				view.setModel(oModel, "foo");

				var oFilterBar = sap.ui.getCore().byId(view.getId() + "--smartFilterBar");
				if (oFilterBar) {
					//var that = this;
					oFilterBar.attachFilterChange(function (oEvent) {

					});
					oFilterBar.setBasicSearch(new sap.m.SearchField());
				}

				this.counterButtonPressed = 0;
				this.counterToggleButtonPressed = 0;
				this.counterLinkPressed = 0;
				this.counterSmartTablePressed = 0;
				this.counterSmartFilterBarGoBtnPressed = 0;
				this.counterSmartFilterBarClearBtnPressed = 0;
				this.counterSmartFilterBarRestoreBtnPressed = 0;
				this.counterTableSelChanged = 0;
				this.counterTableNavPressed = 0;
				oModel.setCountSupported(false);
				view.setModel(oModel);
				//view.byId("smartTable_ResponsiveTable").setModel(oModel);
				//view.byId("smartFilterBar").setModel(oModel);
				view.byId("smartFormOne").bindElement("/Products('1239102')");
				view.byId("mcbOne").addSelectedKeys(["1239102", "P1239823"]);
				view.byId("cbOne").setModel(oModel);
				view.byId("tblOne").setModel(oModel);
				view.byId("controls").setVisible(window.location.hash.toLowerCase() === "#opareuselib-controls");
				view.byId("smartcontrols").setVisible(window.location.hash.toLowerCase() === "#opareuselib-smartcontrols");
				view.byId("smartcontrols2").setVisible(window.location.hash.toLowerCase() === "#opareuselib-smartcontrols2");
			},

			onAfterVariantLoad: function (oEvent) {
				var oSmartFilterbar = this.getView().byId("smartFilterBar");

				if (oSmartFilterbar) {

					var oData = oSmartFilterbar.getFilterData();
					var oCustomFieldData = oData["_CUSTOM"];
					if (oCustomFieldData) {

						var oCtrl = oSmartFilterbar.determineControlByName("MyOwnFilterField");

						if (oCtrl) {
							oCtrl.setSelectedKey(oCustomFieldData.MyOwnFilterField);
						}
					}
				}
			},

			onBeforeVariantSave: function (oEvent) {
				if (oEvent.getParameter("context") === "STANDARD") {
					this._updateCustomFilter();
				}
			},

			onBeforeVariantFetch: function (oEvent) {
				this._updateCustomFilter();
			},

			_updateCustomFilter: function () {
				var oSmartFilterbar = this.getView().byId("smartFilterBar");

				if (oSmartFilterbar) {

					var oCtrl = oSmartFilterbar.determineControlByName("MyOwnFilterField");

					if (oCtrl) {
						oSmartFilterbar.setFilterData({
							_CUSTOM: {
								MyOwnFilterField: oCtrl.getSelectedKey()
							}
						});
					}
				}
			},

			onExit: function () {
				this._oMockServer.stop();
			},

			onPressButton: function (oEvent) {
				var oButton = oEvent.getSource();
				this.counterButtonPressed += 1;
				oButton.setText("Button Pressed: " + this.counterButtonPressed);
			},

			onPressToggleButton: function () {
				//var oButton = oEvent.getSource();
				//oButton.setIcon("sap-icon://cloud");
				var oToggleButtonLabel = this.getView().byId("lblToggleButton");
				this.counterToggleButtonPressed += 1;
				oToggleButtonLabel.setText("ToggleButton Pressed: " + this.counterToggleButtonPressed);
			},

			onPressLink: function (oEvent) {
				var oLink = oEvent.getSource();
				this.counterLinkPressed += 1;
				oLink.setText("Link Pressed: " + this.counterLinkPressed);
			},

			onTableNavigationPress: function (oEvent) {
				var oTableLabelNavPressed = this.getView().byId("lblTableNavPressed");
				var oNavPressItem = this.getView().byId("lblTableNavPressItem");
				oNavPressItem.setText("Table - Pressed Item: " + oEvent.getSource().getCells()[0].getTitle());
				this.counterTableNavPressed += 1;
				oTableLabelNavPressed.setText("Table - Navigation Pressed: " + this.counterTableNavPressed);
			},

			onTableSelectionChange: function (oEvent) {
				var oTableLabel = this.getView().byId("lblTableSelChanged");
				this.counterTableSelChanged += 1;
				oTableLabel.setText("Table - Selection Changed: " + this.counterTableSelChanged);
			},

			onPressGoButtonInSmartFilterBar: function (oEvent) {
				var oSmartFilterBarGoBtnLabel = this.getView().byId("lblSmartFilterBarGoBtn");
				this.counterSmartFilterBarGoBtnPressed += 1;
				oSmartFilterBarGoBtnLabel.setText("SmartFilterBar - Go Button Pressed: " + this.counterSmartFilterBarGoBtnPressed);
			},

			onPressClearButtonInSmartFilterBar: function (oEvent) {
				var oSmartFilterBarClearBtnLabel = this.getView().byId("lblSmartFilterBarClearBtn");
				this.counterSmartFilterBarClearBtnPressed += 1;
				oSmartFilterBarClearBtnLabel.setText("SmartFilterBar - Clear Button Pressed: " + this.counterSmartFilterBarClearBtnPressed);
			},

			onPressRestoreButtonInSmartFilterBar: function (oEvent) {
				var oSmartFilterBarRestoreBtnLabel = this.getView().byId("lblSmartFilterBarRestoreBtn");
				this.counterSmartFilterBarRestoreBtnPressed += 1;
				oSmartFilterBarRestoreBtnLabel.setText("SmartFilterBar - Restore Button Pressed: " + this.counterSmartFilterBarRestoreBtnPressed);
			},

			onOpenDialog: function (oEvent) {
				if (!this.pressDialog) {
					this.pressDialog = new Dialog({
						id: "dlgOne",
						title: '{i18n>fooDialogTitle}',
						content: new Button({
							text: 'Close',
							press: function () {
								this.pressDialog.close();
							}.bind(this)
						})
					});
					//to get access to the global model
					this.getView().addDependent(this.pressDialog);
				}
				this.pressDialog.open();
			},

			onItemPressInSmartTable: function (oEvent) {
				var lblSmartTableSelectedProduct = this.getView().byId("lblSmartTableSelectedProduct");
				lblSmartTableSelectedProduct.setText("SmartTable - Selected Product: " + oEvent.getSource().getBindingContext().getObject().ProductId);
				var oSelectedRecord = oEvent.getSource().getBindingContext().getObject();

				var oController = this;
				//var sApphash = "#opareuselib-dummyapp?PassedID=22134T&PassedCategory=Accessory";

				var stubGetRouter = sinon.stub(sap.ui.generic.app.navigation.service.NavigationHandler.prototype, "_getRouter", function () {
					return {
						oHashChanger: {
							getHash: function () {
								return "";
							},
							replaceHash: function (sHash) {
								oController.sReplacedHash = sHash;
							}
						}
					};
				});
				var oNavigationHandler = new NavigationHandler(oController);

				// Define the semantic object based on the pattern
				var sSemanticObject = "opareuselib";

				//Define the action based on the processing level
				var sAction = "dummyapp";

				//This would be needed according to the SAPUI5 API reference for sap.ui.generic.app.navigation.service.NavigationHandler but it doesn't work
				//app state for back navigation
				var oInnerAppData = {};

				// Define the error callback
				var fnOnError = function (oError) {
					switch (oError.getErrorCode()) {
					case "NavigationHandler.isIntentSupported.notSupported":
						sap.m.MessageToast.show("Intent-based navigation is not supported");
						break;
					default:
						sap.m.MessageToast.show(oError.getErrorCode());
					}
				};

				// Navigate using the determined parameters
				oNavigationHandler.navigate(
					// Semantic object
					sSemanticObject,
					// Action
					sAction,
					// Navigation parameters
					{
						PassedID: oSelectedRecord.ProductId,
						PassedCategory: oSelectedRecord.Category
					},
					// Current app state
					oInnerAppData,
					// Error callback
					fnOnError
				);

				stubGetRouter.restore();

				// return true is necessary to prevent further default navigation to Object Page
				return true;
			},

			onPressIconInSmartTable: function (oEvent) {
				var lblSmartTable2SelectedProductByIcon = this.getView().byId("lblSmartTable2SelectedProductByIcon");
				lblSmartTable2SelectedProductByIcon.setText("SmartTable - Selected Product by icon: " + oEvent.getSource().getBindingContext().getObject()
					.ProductId);
			},

			onPressButtonInSmartTable: function (oEvent) {
				var lblSmartTable2SelectedProductByButton = this.getView().byId("lblSmartTable2SelectedProductByButton");
				lblSmartTable2SelectedProductByButton.setText("SmartTable - Selected Product by button: " + oEvent.getSource().getBindingContext().getObject()
					.ProductId);
			}

		});

	});