/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"YMM_PROVP_Cust/YMM_PROVP_Cust/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});