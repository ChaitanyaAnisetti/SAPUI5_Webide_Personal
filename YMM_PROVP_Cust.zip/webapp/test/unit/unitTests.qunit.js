/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"YMM_PROVP_Cust/YMM_PROVP_Cust/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});