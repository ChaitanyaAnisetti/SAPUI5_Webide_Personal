sap.ui.define([
	"YMM_PROVP_Cust/YMM_PROVP_Cust/test/unit/controller/View1.controller"
], function () {
	"use strict";
});