/*sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("YMM_PROVP_Cust.YMM_PROVP_Cust.controller.View1", {
		onInit: function () {

		}
	});
});*/

sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("YMM_PROVP_Cust.YMM_PROVP_Cust.controller.View1", {
		onInit: function () {
			
			this.oBindyear();
			this.oDelegateFun();
			//this.oDelegateFunPO();
			

		},
		oBindyear: function () {

  			var d = new Date();
  			var Monthdata = [{
  				"month": "January",
  				"key": 0
  			}, {
  				"month": "February",
  				"key": 1
  			}, {
  				"month": "March",
  				"key": 2
  			}, {
  				"month": "April",
  				"key": 3
  			}, {
  				"month": "May",
  				"key": 4
  			}, {
  				"month": "June",
  				"key": 5
  			}, {
  				"month": "July",
  				"key": 6
  			}, {
  				"month": "August",
  				"key": 7
  			}, {
  				"month": "September",
  				"key": 8
  			}, {
  				"month": "October",
  				"key": 9
  			}, {
  				"month": "November",
  				"key": 10
  			}, {
  				"month": "December",
  				"key": 11
  			}];

  			if (d.getMonth() >= 3) {
				var yeararray = [];
				var n = (d.getFullYear());
				for (var i = 0; i < 3; i++) {
					var obj = {};
					obj.year = n - i;
					yeararray.push(obj);
				}
				var yearmodel = new sap.ui.model.json.JSONModel();
				yearmodel.setData(yeararray);
				this.getView().byId("MoyearCombo").setModel(yearmodel);
				this.getView().byId("MoyearCombo").setSelectedKey(d.getFullYear());
				this.getView().byId("MoyearCombo").setSelectedItem(d.getFullYear());

			} else {
				var yeararray = [];
				var n = (d.getFullYear());
				for (var i = 0; i < 3; i++) {
					var obj = {};
					obj.year = n - i;
					yeararray.push(obj);
				}
				var yearmodel = new sap.ui.model.json.JSONModel();
				yearmodel.setData(yeararray);
				this.getView().byId("MoyearCombo").setModel(yearmodel);
				this.getView().byId("MoyearCombo").setSelectedKey(d.getFullYear() - 1);
				this.getView().byId("MoyearCombo").setSelectedItem(d.getFullYear() - 1);

			}

  		},


		oDelegateFun: function () {
			this.oBusyDialog = new sap.m.BusyDialog();
			this.oBusyDialog.open(3000);
			this.url = "/sap/opu/odata/sap/YMM_PR_STATUS_DATA_CDS";
			var that = this;

		     that.oYear = that.getView().byId("MoyearCombo")._getSelectedItemText();
			that.oDataModel = new sap.ui.model.odata.ODataModel(that.url, true);
			var path = "/ymm_PR_STATUS_DATA(p_fiscalyear='" + that.oYear + "')/Set";
			that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

				var oObjemodel = oData.results;
				that.oModel = new sap.ui.model.json.JSONModel(oObjemodel);
				that.oBusyDialog.close();
				//	that.onYearChange();
			});

			var oChart = that.getView().byId("oidVizframe");

			that.getView().setModel(that.oModel, "oPRModel");
			oChart.setVizProperties({
				plotArea: {
					dataLabel: {
						visible: true,
						type: 'value',
						drawingEffect: 'glossy'
					}
				},
				legend: {
					title: {
						visible: false
					}
				},
				title: {
					visible: true,
					text: 'PR Status Overview'
				}
			});

			var oPopOver = that.getView().byId("idPopOver");
			oPopOver.connect(oChart.getVizUid());

		},

		onYearChange: function () {

			

			this.oDelegateFun();

		

		},
	
		onSelect: function (oEvent) {
				
				var aSelections = oEvent.getParameter("data");
				//	var oModel = this.getView().byId("oidVizframe").getModel();
				// get a handle on the global XAppNav service
				var oCrossAppNavigator = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService && sap.ushell.Container.getService(
					"CrossApplicationNavigation");
				oCrossAppNavigator.isIntentSupported(["P2P_Status-display"])
					.done(function (aResponses) {

					})
					.fail(function () {
						new sap.m.MessageToast("Provide corresponding intent to navigate");
					});
				// generate the Hash to display P2P_Status
				var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
					target: {
						semanticObject: "PRStatusList",
						/*	semanticObject: "P2P_Status"*/
						action: "display"
					},
					params: {
						"COUNTflag": aSelections[0].data.COUNTflag,
						"PRstatus": aSelections[0].data.PRstatus,
						"p_fiscalyear":this.oYear
					}
				})) || "";
				//Generate a  URL for the second application
				var url = window.location.href.split('#')[0] + hash;
				//Navigate to second app
				sap.m.URLHelper.redirect(url, true);

			}
			//	var	oFilter = new sap.ui.model.Filter("Requisitiondate", sap.ui.model.FilterOperator.BT, this.FromDate, this.ToDate);
			//	var	oFilter = new sap.ui.model.Filter("PRstatus", sap.ui.model.FilterOperator.Contains, "Release Completed");
			//	var oFilter = new sap.ui.model.Filter("reqdate", sap.ui.model.FilterOperator.BT, this.FromDate, this.ToDate);

	});
});