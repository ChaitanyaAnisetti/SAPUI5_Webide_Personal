/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"reprintlabel/SIE_ASP_WM_ReprintLabel/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});