sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"gitoio/SIE_ASP_WM_GI_TO_IO/model/formatter",
	"sap/m/MessageBox",
	"sap/ui/core/routing/History"
], function (Controller, JSONModel, Filter, FilterOperator, formatter, MessageBox, History) {
	"use strict";

	return Controller.extend("gitoio.SIE_ASP_WM_GI_TO_IO.controller.PostGI", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gitoio.SIE_ASP_WM_GI_TO_IO.view.PostGI
		 */
		formatter: formatter,
		onInit: function () {
			this._mainService = this.getOwnerComponent().getModel();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var oViewModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oViewModel, "pickingitemdetailView");
			oRouter.getRoute("PostGI").attachPatternMatched(this._onRouteMatched, this);
		},
		onNavBack: function (oEvent) {
			/*var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				}*/
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Items", {

				resNo: this.Pickno,

				WarehouseNo: this.sWarehouseNo

			});

		},
		_onRouteMatched: function (oEvent) {
			//	WarehouseNo  Pickitem Pickno 
			
			if (oEvent.getParameter("arguments").Pickno && oEvent.getParameter("arguments").Pickitem) {
				var sID = oEvent.getParameter("arguments").sId;
				this.Pickno = oEvent.getParameter("arguments").Pickno;
				this.Pickitem = oEvent.getParameter("arguments").Pickitem;
				this.sWarehouseNo = oEvent.getParameter("arguments").WarehouseNo;

				this.getView().getModel("pickingitemdetailView").setProperty("/pickingtemNo", sID);
				this.getView().getModel("pickingitemdetailView").setProperty("/totalItemNo", this.getView().getModel("localModel").getProperty(
					"/PckingUpDataItemList").length);
				this.getView().getModel("pickingitemdetailView").setProperty("/currentIndex", parseInt(sID, 10) + 1);
				this.getView().getModel("pickingitemdetailView").setProperty("/orginalIndex", parseInt(sID, 10));

				this.getView().byId("btnNext").setEnabled(true);
				this.getView().byId("btnPrev").setEnabled(true);
				var oTotalNumber = this.getView().getModel("localModel").getProperty("/PckingUpDataItemList").length;
				var oCurrentIndex = parseInt(sID, 10) + 1;
				if (oTotalNumber === 1) {
					this.getView().byId("btnNext").setEnabled(false);
					this.getView().byId("btnPrev").setEnabled(false);
				} else if (oCurrentIndex < oTotalNumber && oTotalNumber > 1) {
					if (oCurrentIndex > 1 && oCurrentIndex < oTotalNumber) {
						this.getView().byId("btnPrev").setEnabled(true);
						this.getView().byId("btnNext").setEnabled(true);
					} else if (oCurrentIndex === oTotalNumber - 1 && oTotalNumber > 2) {
						this.getView().byId("btnNext").setEnabled(false);
						this.getView().byId("btnPrev").setEnabled(true);
					} else if (oCurrentIndex === oTotalNumber - 1 && oTotalNumber === 2) {
						this.getView().byId("btnNext").setEnabled(true);
						this.getView().byId("btnPrev").setEnabled(false);
					} else if (oCurrentIndex === 1) {
						this.getView().byId("btnPrev").setEnabled(false);
					}

				} else if (oCurrentIndex === oTotalNumber && oTotalNumber > 1) {
					this.getView().byId("btnPrev").setEnabled(true);
					this.getView().byId("btnNext").setEnabled(false);

				}
				var oData = this.getView().getModel("localModel").getProperty("/PckingUpDataItemList")[sID];
				if (oData) {
					if (oData.indicator === "") {
						this.getView().byId("btnConf").setVisible(false);
						this.getView().byId("btnMaintSerno").setVisible(false);
					} else {
						this.getView().byId("btnConf").setVisible(true);
						this.getView().byId("btnMaintSerno").setVisible(true);
					}
				} else {
					this.getView().byId("btnConf").setVisible(false);
					this.getView().byId("btnMaintSerno").setVisible(false);
				}
				this._getGoodsIssueDetSet(this.Pickno, this.Pickitem, this.sWarehouseNo);
				/*	this.getOwnerComponent().getService("ShellUIService").then(function(oShellService) {
					    oShellService.setBackNavigation(function() {
					        	that.onPressbackButtonFromPickingItemDetailPage();
					    });
					});
		
						
						*/

				//////////////////////////////////////////////////////////////////////////////////

			}
			/*if (this.getModel("localModel").getProperty("/PckingUpData")) {
				if(this.getModel("localModel").getProperty("/PckingUpData").length==(0 || 1)){
					this.getView().byId("btnPrev").setEnable(false);
				this.getView().byId("btnNext").setEnable(false);
				}
				else if(this.getModel("localModel").getProperty("/PckingUpData").length>1){
					
				}

			} else {
				this.getView().byId("btnPrev").setEnable(false);
				this.getView().byId("btnNext").setEnable(false);

			}*/

		},
		_getGoodsIssueDetSet: function (Pickno, Pickitem, sWarehouseNo) {
			var that = this;
			var pageId = this.getView().byId("postGIPage");
			pageId.setBusy(true);
			var oGIDetModel = new sap.ui.model.json.JSONModel();
			//	var oGIDetSerNoModel = new sap.ui.model.json.JSONModel();
			//	(WarehouseNo='A04',Pickno='0000004021',Pickitem='0005')/?$expand=ITEM_SERIAL_NAV
			this._mainService.read("/Goodissue_detSet(WarehouseNo='" + sWarehouseNo + "',Pickno='" + Pickno + "',Pickitem='" + Pickitem + "')", {
				//	this._mainService.read("/Goodissue_detSet(WarehouseNo='A04',Pickno='0000004021',Pickitem='0005')", {
				urlParameters: {
					"$expand": "ITEM_SERIAL_NAV"
				},
				success: function (data) {
					pageId.setBusy(false);

					if (data.MsgType === "S") {

						oGIDetModel.setData(data);
						that.getView().setModel(oGIDetModel, "oGIDetModel");
						/*	var sLine = {
								"WarehouseNo": "",
								"Serialno": "",
								"Pickno": ""
							};*/
						/*			data.ITEM_SERIAL_NAV.results.push({
										"WarehouseNo": sWarehouseNo,
										"Serialno": "",
										"Pickno": sResNo
									});
									data.ITEM_SERIAL_NAV.results.push({
										"WarehouseNo": sWarehouseNo,
										"Serialno": "",
										"Pickno": sResNo
									});
									oGIDetSerNoModel.setData(data.ITEM_SERIAL_NAV);
									that.getView().setModel(oGIDetSerNoModel, "oGIDetSerNoModel");*/

					} else {
						sap.m.MessageBox.error(data.MsgDesc);
					}

				},
				error: function (Error) {
					pageId.setBusy(false);
					sap.m.MessageBox.error(that.getView().getModel("i18n").getResourceBundle().getText("noDataFoundError"));
				}
			});

		},
		onSerialNumberClick: function () {
			this.count = 0;
			var oGIDetSerNoModel = new sap.ui.model.json.JSONModel([]);
			/*	var sGIDetModelData = new sap.ui.model.json.JSONModel([]);
        	this.getView().setModel(sGIDetModelData, "sGIDetModelData");*/
			var sGIDetModelData = this.getView().getModel("oGIDetModel").getData();
			if (sGIDetModelData.ITEM_SERIAL_NAV && sGIDetModelData.ITEM_SERIAL_NAV.results) {

			} else {

			}
			sGIDetModelData.ITEM_SERIAL_NAV.results = [];
			var sConfQty = parseInt(sGIDetModelData.ConfQty, 10);
			if (sConfQty > 0) {
				if (sGIDetModelData.ITEM_SERIAL_NAV.results.length === 0) {
					for (var i = 0; i < sConfQty; i++) {
						sGIDetModelData.ITEM_SERIAL_NAV.results.push({
							"WarehouseNo": this.sWarehouseNo,
							"Serialno": "",
							"Pickno": this.Pickno
						});
					}
					oGIDetSerNoModel.setData(sGIDetModelData.ITEM_SERIAL_NAV);
					this.getView().setModel(oGIDetSerNoModel, "oGIDetSerNoModel");
				}

				if (!this._serialNumberPopup) {
					this._serialNumberPopup = sap.ui.xmlfragment(
						"gitoio.SIE_ASP_WM_GI_TO_IO.fragment.serialNo",
						this
					);
				}
				this.getView().addDependent(this._serialNumberPopup);
				this._serialNumberPopup.open();
			} else

			{
				sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("mandatoryConfQtyErr"));
			}
		},
		onConfPGI: function (oEvent) {
			var that = this;
			var pageId = this.getView().byId("postGIPage");
			pageId.setBusy(true);
			var aGIDetData = this.getView().getModel("oGIDetModel").getData();
			var SERIAL_NAV = [];
			if (aGIDetData.ITEM_SERIAL_NAV && aGIDetData.ITEM_SERIAL_NAV.results) {
				SERIAL_NAV = aGIDetData.ITEM_SERIAL_NAV.results.filter(function (x) {
					return x.Serialno != "";
				});
			}
			if (aGIDetData.indicator === "X" && SERIAL_NAV.length == 0) {
					pageId.setBusy(false);
				sap.m.MessageBox.warning(this.getView().getModel("i18n").getResourceBundle().getText("MandetorySerialNum"));
				return;
			}

			var aGIDetDetData = {
				"Action": aGIDetData.Action,
				"ConfBatch": aGIDetData.ConfBatch,
				"ConfBatchInd": aGIDetData.ConfBatchInd,
				"ConfBin": aGIDetData.CHARG_SOURCE,
				"ConfQty": aGIDetData.ConfQty,
				"ConfQtyUOM": aGIDetData.ConfQtyUOM,
				"Intorder": aGIDetData.Intorder,
				"MatDesc": aGIDetData.MatDesc,
				"Material": aGIDetData.Material,
				"MsgDesc": aGIDetData.MsgDesc,
				"MsgType": aGIDetData.MsgType,
				"PickQty": aGIDetData.PickQty,
				"Pickitem": aGIDetData.Pickitem,
				"Pickno": aGIDetData.Pickno,
				"Plant": aGIDetData.Plant,
				"Serialno": aGIDetData.Serialno,
				"Sloc": aGIDetData.Sloc,
				"WarehouseNo": aGIDetData.WarehouseNo,
				"batch": aGIDetData.batch,
				"indicator": aGIDetData.indicator,
				"ITEM_SERIAL_NAV": SERIAL_NAV
			};
var that=this;
			this._mainService.create("/Goodissue_detSet", aGIDetDetData, {
				success: function (data) {

					pageId.setBusy(false);
					if (data.MsgType === "S") {
						//	sap.m.MessageBox.success(data.MsgDesc);
						sap.m.MessageBox.success(data.MsgDesc, {

							actions: ["OK"],
							title: "Success",
							onClose: function (oAction) {
								if (oAction === "OK") {
										that.OnUpdateDataRow();
								}

							}

						});
					} else {
						sap.m.MessageBox.error(data.MsgDesc);
					}
				},
				error: function () {
					pageId.setBusy(false);
				}
			});
		},
		OnUpdateDataRow: function () {
			var ID = this.getView().getModel("pickingitemdetailView").getProperty("/pickingtemNo");
			this.getView().getModel("localModel").getProperty("/PckingUpDataItemList")[ID].indicator = "";
			this.getView().byId("btnConf").setVisible(false);
			this.getView().byId("btnMaintSerno").setVisible(false);
			var TotalCompletedData=this.getView().getModel("localModel").getProperty("/PckingUpDataItemList").filter(function(x){return x.indicator=="";});
			var oTotalItemNo = this.getView().getModel("pickingitemdetailView").getProperty("/totalItemNo"),
				oCurrentIndex = this.getView().getModel("pickingitemdetailView").getProperty("/currentIndex");

			if (oTotalItemNo === TotalCompletedData.length) {
				this.onNavBack(); 
			}
			else{
					this.onNext(); 
			}
			
		/*	else {
			var TotalInCompletedData=this.getView().getModel("localModel").getProperty("/PckingUpDataItemList").filter(function(x){return x.indicator==="X";});
				for(var i=0; i<TotalInCompletedData.length;i++){
							TotalInCompletedData[i].ID=i;
						}
	this.getView().getModel("localModel").setProperty("/PckingUpDataItemList",[]);
	this.getView().getModel("localModel").setProperty("/PckingUpDataItemList", TotalInCompletedData);
		this.getView().getModel("pickingitemdetailView").setProperty("/totalItemNo", this.getView().getModel("localModel").getProperty(
					"/PckingUpDataItemList").length);
					if(this.getView().getModel("pickingitemdetailView").getProperty("/totalItemNo")>1){
				this.getView().getModel("pickingitemdetailView").setProperty("/currentIndex", parseInt(TotalInCompletedData[0].ID, 10));
				this.onNext(); 
					}
					else{
					this.getView().getModel("pickingitemdetailView").setProperty("/currentIndex", 0);	
						this.onNext(); 
					}
			}*/

		},
		fnClearSrNo: function () {
			var aData = this.getView().getModel("oGIDetSerNoModel").getData();
			for (var i = 0; i < aData.results.length; i++) {
				aData.results[i].Serialno = "";
			}
			this.getView().getModel("oGIDetSerNoModel").setData(aData);
		},
		
		fnSaveSrNo: function () {
			var sGIDetModelData = this.getView().getModel("oGIDetModel").getData();
			if (sGIDetModelData.ITEM_SERIAL_NAV && sGIDetModelData.ITEM_SERIAL_NAV.results) {
				var emptySerialNumData = sGIDetModelData.ITEM_SERIAL_NAV.results.filter(function (x) {
					return x.Serialno == "";
				});
				if (emptySerialNumData.length) {
					sap.m.MessageBox.warning(this.getView().getModel("i18n").getResourceBundle().getText("MandetorySerialNum"));
				} else {
					if (this._serialNumberPopup) {
						this._serialNumberPopup.close();
						this._serialNumberPopup.destroy();
						this._serialNumberPopup = null;
					}
				}

			}
		},
		fnCloseSrNo: function (oEvent) {
			if (this._serialNumberPopup) {
				this._serialNumberPopup.close();
				this._serialNumberPopup.destroy();
				this._serialNumberPopup = null;
			}
		},
		onNumberPadClick: function (oEvent) {
			if (!this._numberPadFrag) {
				this._numberPadFrag = sap.ui.xmlfragment(
					"gitoio.SIE_ASP_WM_GI_TO_IO.fragment.numberPad",
					this
				);
			}
			this.getView().addDependent(this._numberPadFrag);
			this._numberPadFrag.open();
		},
		fnCloseNumberPad: function () {
			if (this._numberPadFrag) {
				this._numberPadFrag.close();
				this._numberPadFrag.destroy();
				this._numberPadFrag = null;
			}
		},
		onNumberClick: function (oEvent) {
			var sBtnValue = oEvent.getSource().getId().charAt(oEvent.getSource().getId().length - 1);
			var sQtyValue = this.getView().byId("idConfQty").getValue();
			if (parseInt(sQtyValue) === 0) {
				sQtyValue = sBtnValue;
				this.getView().byId("idConfQty").setValue(sQtyValue);
			} else {
				sQtyValue = sQtyValue.concat(sBtnValue);
				this.getView().byId("idConfQty").setValue(sQtyValue);
			}
		},
		onClearNumberPad: function () {
			this.getView().byId("idConfQty").setValue("");
		},
		onBarCodeScan: function () {

			if (cordova.plugins && cordova.plugins.barcodeScanner) {
				cordova.plugins.barcodeScanner.scan(
					this.onSuccess.bind(this),
					this.onError.bind(this)
				);
			} else {

				sap.ndc.BarcodeScanner.scan(
					this.onSuccess.bind(this),
					this.onError.bind(this)
				);
			}
		},
		onError: function (error) {
			sap.m.MessageToast.show(error, "Error");
		},
		onSuccess: function (result) {
			this.getView().byId("idConfBin").setValue(result.text);
		},
		routeToMainPage: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Main");

		},
		onNext: function (oEvent) {
			var oCurrentIndex = this.getView().getModel("pickingitemdetailView").getProperty("/currentIndex");
			var ototalnumber = this.getView().getModel("pickingitemdetailView").getProperty("/totalItemNo");

			if (oCurrentIndex <= ototalnumber) {
				var oId = this.getView().getModel("localModel").getProperty("/PckingUpDataItemList")[oCurrentIndex].ID;
				var Pickitem = this.getView().getModel("localModel").getProperty("/PckingUpDataItemList")[oCurrentIndex].Pickitem;
				var Pickno = this.getView().getModel("localModel").getProperty("/PckingUpDataItemList")[oCurrentIndex].Pickno;

				if (oCurrentIndex === 0&&oEvent) {
					oEvent.getSource().getEnabled(false);
				}
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("PostGI", {
					WarehouseNo: this.sWarehouseNo,
					Pickitem: Pickitem,
					Pickno: Pickno,
					sId: oId
				});
			}

		},

		onPrev: function (oEvent) {
			var oCurrentIndex = this.getView().getModel("pickingitemdetailView").getProperty("/orginalIndex") - 1;
			var ototalnumber = this.getView().getModel("pickingitemdetailView").getProperty("/totalItemNo");

			if (oCurrentIndex <= ototalnumber && oCurrentIndex !== -1) {

				var oId = this.getView().getModel("localModel").getProperty("/PckingUpDataItemList")[oCurrentIndex].ID;
				var Pickitem = this.getView().getModel("localModel").getProperty("/PckingUpDataItemList")[oCurrentIndex].Pickitem;
				var Pickno = this.getView().getModel("localModel").getProperty("/PckingUpDataItemList")[oCurrentIndex].Pickno;

				if (oCurrentIndex === 0) {
					oEvent.getSource().getEnabled(false);
				}
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

				oRouter.navTo("PostGI", {
					WarehouseNo: this.sWarehouseNo,
					Pickitem: Pickitem,
					Pickno: Pickno,
					sId: oId
				});

			}

		},
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf gitoio.SIE_ASP_WM_GI_TO_IO.view.PostGI
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf gitoio.SIE_ASP_WM_GI_TO_IO.view.PostGI
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf gitoio.SIE_ASP_WM_GI_TO_IO.view.PostGI
		 */
		//	onExit: function() {
		//
		//	}

	});

});