sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"gitoio/SIE_ASP_WM_GI_TO_IO/model/formatter",
	"sap/ui/model/json/JSONModel"
], function (Controller, formatter, JSONModel) {
	"use strict";

	return Controller.extend("gitoio.SIE_ASP_WM_GI_TO_IO.controller.Items", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gitoio.SIE_ASP_WM_GI_TO_IO.view.Items
		 */
		formatter: formatter,
		onInit: function () {
			this._mainService = this.getOwnerComponent().getModel();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("Items").attachPatternMatched(this._onRouteMatched, this);
			this.oBusyDialog = new sap.m.BusyDialog();
		},
		_onRouteMatched: function (oEvent) {
			this.WH = oEvent.getParameter("arguments").WarehouseNo || "";
			var Pickno = oEvent.getParameter("arguments").resNo || "";
			this.getView().byId("oResNum").setText(Pickno);
			//	sTr = Plant eq '9CB3' and Sloc eq '0300' and (SpecialStockI eq 'E' or SpecialStockI eq 'Q') and (SpecialStockNoI eq '3000000193000100') and (BatchNoI eq '0000000008' or BatchNoI eq '0000000010') and (PostDate ge '20180801' and PostDate le '20180931') and (MatDocNoI eq '4900000324' or MatDocNoI eq '4900000325') and (MaterialI eq '000000000100003099' or MaterialI eq '000000000100003239')	
			var sTr = "WarehouseNo eq '" + this.WH + "' and Pickno eq '" + Pickno + "'";

			this.oBusyDialog.open();
			var oBindingInfo = {
				filters: null,
				urlParameters: {
					"$filter": sTr,
					"$format": 'json'
				},
				success: function (oData, oResponse) {
					this.oBusyDialog.close();
					if (oData.results && oData.results[0].MsgType === "E") {
						var oPickItemModel = new sap.ui.model.json.JSONModel([]);
						this.getView().setModel(oPickItemModel, "oPickItemModel");
						sap.m.MessageBox.error(
							oData.results[0].MsgDesc, {
								icon: sap.m.MessageBox.Icon.ERROR,
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);
					} else {
						var oPickItemModel = new sap.ui.model.json.JSONModel(oData.results);
						oPickItemModel.setSizeLimit(oData.results.length);
						this.getView().setModel(oPickItemModel, "oPickItemModel");
					}
				}.bind(this),
				error: function (oError) {
					this.oBusyDialog.close();
					var sMsg;
					if (oError.responseText && JSON.parse(oError.responseText).error && JSON.parse(oError.responseText).error.message) {
						sMsg = JSON.parse(oError.responseText).error.message.value;
					} else {
						sMsg = "Error";
					}
					var oPickItemModel = new sap.ui.model.json.JSONModel([]);
					this.getView().setModel(oPickItemModel, "oPickItemModel");
					sap.m.MessageBox.error(
						sMsg, {
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.CLOSE],
							onClose: function (oAction) {}

						}
					);

				}.bind(this)
			};

			this._mainService.read("/Goodissue_itemSet", oBindingInfo);

		},
		onConfirmPress: function (oEvent) {
			var Selobj = oEvent.getSource().getParent().getBindingContext("oPickItemModel").getObject();
			var PckingData = this.getView().byId("idtblPckingno").getModel("oPickItemModel").getData().filter(function (x) {
				return x.indicator === "X";
			});
				for(var i=0; i<PckingData.length;i++){
							PckingData[i].ID=i;
						}
	this.getView().getModel("localModel").setProperty("/PckingUpDataItemList",[]);
						
						if(PckingData){
						this.getView().getModel("localModel").setProperty("/PckingUpDataItemList", PckingData);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			
			oRouter.navTo("PostGI", {
				WarehouseNo: this.WH,
				Pickitem: Selobj.Pickitem,
				Pickno: Selobj.Pickno,
				sId:Selobj.ID
			});
							
						}
		

		},
		onNavBack: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Main", {});
		},
		onNext: function (oEvent) {
			var oCurrentIndex = this.getModel("worklistView").getProperty("/currentIndex");
			var ototalnumber = this.getModel("worklistView").getProperty("/totalItemNo");

			if (oCurrentIndex <= ototalnumber) {
				var oId = this.getModel("localModel").getProperty("/ItemList")[oCurrentIndex].ID;
				if (oCurrentIndex === ototalnumber) {
					oEvent.getSource().getEnabled(false);
				}
				//this.onCreateFormContent(oId);
				this.onCreateNavContent(oId);
			}
		},

		onPrev: function (oEvent) {
			var oCurrentIndex = this.getModel("worklistView").getProperty("/orginalIndex") - 1;
			var ototalnumber = this.getModel("worklistView").getProperty("/totalItemNo");
			if (oCurrentIndex <= ototalnumber && oCurrentIndex !== -1) {
				var oId = this.getModel("localModel").getProperty("/ItemList")[oCurrentIndex].ID;
				if (oCurrentIndex === 0) {
					oEvent.getSource().getEnabled(false);
				}
				//this.onCreateFormContent(oId);
				this.onCreateNavContent(oId);
			}

		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf gitoio.SIE_ASP_WM_GI_TO_IO.view.Items
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf gitoio.SIE_ASP_WM_GI_TO_IO.view.Items
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf gitoio.SIE_ASP_WM_GI_TO_IO.view.Items
		 */
		//	onExit: function() {
		//
		//	}

	});

});