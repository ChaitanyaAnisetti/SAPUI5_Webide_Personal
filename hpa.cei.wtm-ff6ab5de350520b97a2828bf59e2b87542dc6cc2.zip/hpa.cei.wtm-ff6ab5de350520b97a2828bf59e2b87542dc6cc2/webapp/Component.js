jQuery.sap.declare("hpa.cei.wtm.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("hpa.cei.wtm.Component", {
	metadata: {
		"manifest": "json"
	}
});