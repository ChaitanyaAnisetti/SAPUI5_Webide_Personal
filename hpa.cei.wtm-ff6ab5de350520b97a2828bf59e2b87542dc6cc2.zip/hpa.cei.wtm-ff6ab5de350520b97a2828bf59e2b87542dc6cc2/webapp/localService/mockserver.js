sap.ui.define([
	"sap/ui/core/util/MockServer",
	"./mockHelper",
	"./mockRequestsCQFaD",
	"./mockRequestsInteractionFields",
	"./mockRequestsQueries",
	"./mockRequestsGeneralButtons"
], function (MockServer, MockHelper, MockRequestsCQFaD, MockRequestsInteractionFields, MockRequestsQueries, MockRequestsGeneralButtons) {
	"use strict";
	var oMockServer,
		_sAppModulePath = "hpa/cei/wtm/",
		_sJsonFilesModulePath = _sAppModulePath + "localService/mockdata",
		//this here retrieves how many interaction fields there were
		/* eslint-disable no-unused-vars */
		resultInteractionFields = MockRequestsInteractionFields.getInteractionFields(),
		//this here retries how many main queries are there for the object
		mainQueries = MockRequestsQueries.getMainQueries(),
		//this here retrieves how many product queries are there for the object
		productQueries = MockRequestsQueries.getProductQueries(),
		//this here retrieves how many tag queries are there for the object
		tagQueries = MockRequestsQueries.getTagQueries(),
		commonFilters = MockRequestsCQFaD.getCommonFilters(),
		commonDimensions = MockRequestsCQFaD.getCommonDimensions(),
		//usually the system sends an empty object through xhr to indicate it is adding an object to its list
		toAdd = false,
		//want to know when the request for edit is made if we remove the draft entity when the edit config is done
		isEdit = false,
		//this is the part that intercepts when a draft is created and we are returning on the ListObject page.
		isDraft = false,
		//this will intercept the copy action to change the values in the array before sending it to the backend
		isCopy = false,
		//counter giving new UUIDs to the next objects
		counter = 100,
		//copied object
		copiedObject = null;
		/* eslint-enable no-unused-vars */

	return {

		/**
		 * Initializes the mock server.
		 * You can configure the delay with the URL parameter "serverDelay".
		 * The local mock data in this folder is returned instead of the real data for testing.
		 * @public
		 */

		init: function () {
			var oUriParameters = jQuery.sap.getUriParameters(),
				sJsonFilesUrl = jQuery.sap.getModulePath(_sJsonFilesModulePath),
				sManifestUrl = jQuery.sap.getModulePath(_sAppModulePath + "manifest", ".json"),
				sEntity = "C_MKT_WebTrackingMappingTP",
				sErrorParam = oUriParameters.get("errorType"),
				iErrorCode = sErrorParam === "badRequest" ? 400 : 500,
				oManifest = jQuery.sap.syncGetJSON(sManifestUrl).data,
				oDataSource = oManifest["sap.app"].dataSources,
				oMainDataSource = oDataSource.mainService,
				sMetadataUrl = jQuery.sap.getModulePath(_sAppModulePath + oMainDataSource.settings.localUri.replace(".xml", ""), ".xml"),
				// ensure there is a trailing slash
				sMockServerUrl = /.*\/$/.test(oMainDataSource.uri) ? oMainDataSource.uri : oMainDataSource.uri + "/",
				aAnnotations = oMainDataSource.settings.annotations,
				globalUUID = "0";

			oMockServer = new MockServer({
				rootUri: sMockServerUrl,
				recordRequests: true
			});

			// configure mock server with a delay of 1s
			MockServer.config({
				autoRespond: true,
				autoRespondAfter: (oUriParameters.get("serverDelay") || 1000)
			});

			// load local mock data
			oMockServer.simulate(sMetadataUrl, {
				sMockdataBaseUrl: sJsonFilesUrl,
				bGenerateMissingMockData: false,
				aEntitySetsNames: [
					"C_MKT_WebTrackingMappingTP"
				]
			});

			var aRequests = oMockServer.getRequests(),
				fnResponse = function (iErrCode, sMessage, aRequest) {
					aRequest.response = function (oXhr) {
						oXhr.respond(iErrCode, {
							"Content-Type": "text/plain;charset=utf-8"
						}, sMessage);
					};
				};

			//this will be used to know which object is concerned
			function findByUUID(uuid) { // eslint-disable-line no-unused-vars
				var aEntitySetData = oMockServer.getEntitySetData("C_MKT_WebTrackingMappingTP");

				for (var i = 0; i < aEntitySetData.length; i++) {
					if (aEntitySetData[i].WebTrackingMappingUUID == (uuid)) { // eslint-disable-line eqeqeq
						return aEntitySetData[i];
					}
				}
				return false;
			}

			function findIndexByUUID(uuid) {
				var aEntitySetData = oMockServer.getEntitySetData("C_MKT_WebTrackingMappingTP");

				for (var i = 0; i < aEntitySetData.length; i++) {
					if (aEntitySetData[i].WebTrackingMappingUUID == (uuid)) { // eslint-disable-line eqeqeq
						return i;
					}
				}
				return false;
			}

			//-------------------------------------------------------------------------------------------------------------------------------------
			//																Mgmt of List Objects
			//-------------------------------------------------------------------------------------------------------------------------------------

			//figured this would go with Object Page General Buttons section, because many boolean variables are shared.	

			//-------------------------------------------------------------------------------------------------------------------------------------
			//																Object Page General Buttons
			//-------------------------------------------------------------------------------------------------------------------------------------
			MockRequestsGeneralButtons.addGeneralButtonsRequests(oMockServer, aRequests);

			//---------------------------------------------------------------------------------------------------------------------------------------
			//										All GET/POST requests. Sent here before sent to the handled request
			//---------------------------------------------------------------------------------------------------------------------------------------

			//all GET
			aRequests.push({
				method: "GET",
				path: "(.*)",
				response: function (oXhr, sUrlParams) {}
			});
			//all POST
			aRequests.push({
				method: "POST",
				path: "(.*)",
				response: function (oXhr, sUrlParams) {}
			});

			//all DELETE
			aRequests.push({
				method: "DELETE",
				path: "(.*)",
				response: function (oXhr, sUrlParams) {}
			});

			//---------------------------------------------------------------------------------------------------------------------------------------
			//											Some Constant Requests (Bigger Constant Responses in MockHelper)
			//---------------------------------------------------------------------------------------------------------------------------------------

			aRequests.push({
				method: "GET",
				path: "I_MKT_WebTrckgMappgDataSrce?.*select=WebTrackingMappingDataSource.*",
				response: function (oXhr, sUrlParams) {
					var oNewEntityData = {
						"__count": "2",
						"results": [{
							"__metadata": {
								"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDataSrce('A')",
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDataSrce('A')",
								"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDataSrceType"
							},
							"WebTrackingMappingDataSource": "A",
							"WebTrackingMappingDataSource_Text": "Google Analytics"
						}, {
							"__metadata": {
								"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDataSrce('B')",
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDataSrce('B')",
								"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDataSrceType"
							},
							"WebTrackingMappingDataSource": "B",
							"WebTrackingMappingDataSource_Text": "Google BigQuery"
						}]
					};

					oXhr.respond(200, {
						"Content-Type": "application/json"
					}, JSON.stringify({
						"d": oNewEntityData
					}));

					return true;
				}
			});

			aRequests.push({
				method: "GET",
				path: "I_MKT_WebTrckgMappgStatus?.*select=WebTrackingMappingStatus.*",
				response: function (oXhr, sUrlParams) {
					var oNewEntityData = {
						"__count": "3",
						"results": [{
							"__metadata": {
								"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgStatus('A')",
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgStatus('A')",
								"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgStatusType"
							},
							"WebTrackingMappingStatus": "A",
							"WebTrackingMappingStatus_Text": "Active"
						}, {
							"__metadata": {
								"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgStatus('')",
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgStatus('')",
								"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgStatusType"
							},
							"WebTrackingMappingStatus": "",
							"WebTrackingMappingStatus_Text": "Inactive"
						}, {
							"__metadata": {
								"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgStatus('V')",
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgStatus('V')",
								"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgStatusType"
							},
							"WebTrackingMappingStatus": "V",
							"WebTrackingMappingStatus_Text": "Validated"
						}]
					};

					oXhr.respond(200, {
						"Content-Type": "application/json"
					}, JSON.stringify({
						"d": oNewEntityData
					}));

					return true;
				}
			});

			//Shows up the first time the Object Page is reached. Nothing done really...
			aRequests.push({
				method: "GET",
				path: "ExtensionFieldSet.*",
				response: function (oXhr, sUrlParams) {
					var oNewEntityData = {
						"results": []
					};

					oXhr.respond(200, {
						"Content-Type": "application/json"
					}, JSON.stringify({
						"d": oNewEntityData
					}));

					return true;
				}
			});

			//---------------------------------------------------------------------------------------------------------------------------------------
			//															All Interaction Fields Requests
			//---------------------------------------------------------------------------------------------------------------------------------------
			MockRequestsInteractionFields.addInteractionFieldsRequests(oMockServer, aRequests);

			//---------------------------------------------------------------------------------------------------------------------------------------
			//												Common Query Filters and Dimensions
			//---------------------------------------------------------------------------------------------------------------------------------------
			MockRequestsCQFaD.addCQFaDRequests(oMockServer, aRequests);

			//---------------------------------------------------------------------------------------------------------------------------------------
			//															Queries
			//---------------------------------------------------------------------------------------------------------------------------------------
			MockRequestsQueries.addQueriesRequests(oMockServer, aRequests);

			//retrieval of common dimensions from the Query tab when button + is clicked on
			//this request was kept in this document to avoid too much confusion as to where the commonDimensions array comes from (and probably future
			//complications)
			aRequests.push({
				method: "GET",
				path: new RegExp("C_MKT_WebTrckgIntactnHdrTP.*\/to_WebTrckgComMappingTP.*"),
				response: function (oXhr, sUrlParams) {
					var oNewEntityData = commonDimensions;

					oXhr.respond(200, {
						"Content-Type": "application/json"
					}, JSON.stringify({
						"d": oNewEntityData
					}));

					return true;
				}
			});

			//---------------------------------------------------------------------------------------------------------------------------------------
			//															Validation Results
			//---------------------------------------------------------------------------------------------------------------------------------------

			//Validation results NOT FLEXIBLE
			aRequests.push({
				method: "GET",
				path: new RegExp("C_MKT_WebTrackingMappingTP.*\/to_WebTrckgMappingLog.*"),
				response: function (oXhr, sUrlParams) {
					var oNewEntityData = {
						"__count": "3",
						"results": [{
							"__metadata": {
								"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappingLogTP(WebTrckgMappingLogUUID=guid'" +
									globalUUID + "',IsActiveEntity=true)",
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappingLogTP(WebTrckgMappingLogUUID=guid'" +
									globalUUID + "',IsActiveEntity=true)",
								"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgMappingLogTPType"
							},
							"WebTrckgMappingLogUUID": globalUUID,
							"WebTrckgRtrvlHeaderName": "Main query",
							"ValidityDate": 23,
							"ExecutionDateTime": "\/Date(1537968952000+0000)\/",
							"WebTrckgMappgLgSts": "F",
							"WebTrckgMappgLgStsCriticality": 1,
							"WebTrckgMappgLogText": "Unknown metric(s): ga:dimension4, ga:dimension3\n",
							"HasDraftEntity": false,
							"HasActiveEntity": false,
							"IsActiveEntity": true,
							"to_WebTrckgMappgLgSts": {
								"__metadata": {
									"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgLgSts('F')",
									"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgLgSts('F')",
									"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgLgStsType"
								},
								"WebTrckgMappgLgSts_Text": "Failed"
							}
						}, {
							"__metadata": {
								"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappingLogTP(WebTrckgMappingLogUUID=guid'" +
									globalUUID + "',IsActiveEntity=true)",
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappingLogTP(WebTrckgMappingLogUUID=guid'" +
									globalUUID + "',IsActiveEntity=true)",
								"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgMappingLogTPType"
							},
							"WebTrckgMappingLogUUID": globalUUID,
							"WebTrckgRtrvlHeaderName": "Main query",
							"ValidityDate": 1,
							"ExecutionDateTime": "\/Date(1537968810000+0000)\/",
							"WebTrckgMappgLgSts": "F",
							"WebTrckgMappgLgStsCriticality": 1,
							"WebTrckgMappgLogText": "Unknown metric(s): ga:dimension4, ga:dimension3\n",
							"HasDraftEntity": false,
							"HasActiveEntity": false,
							"IsActiveEntity": true,
							"to_WebTrckgMappgLgSts": {
								"__metadata": {
									"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgLgSts('F')",
									"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgLgSts('F')",
									"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgLgStsType"
								},
								"WebTrckgMappgLgSts_Text": "Failed"
							}
						}, {
							"__metadata": {
								"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappingLogTP(WebTrckgMappingLogUUID=guid'" +
									globalUUID + "',IsActiveEntity=true)",
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappingLogTP(WebTrckgMappingLogUUID=guid'" +
									globalUUID + "',IsActiveEntity=true)",
								"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgMappingLogTPType"
							},
							"WebTrckgMappingLogUUID": globalUUID,
							"WebTrckgRtrvlHeaderName": "Main query",
							"ValidityDate": 1,
							"ExecutionDateTime": "\/Date(1537968795000+0000)\/",
							"WebTrckgMappgLgSts": "F",
							"WebTrckgMappgLgStsCriticality": 1,
							"WebTrckgMappgLogText": "Unknown metric(s): ga:dimension4, ga:dimension3\n",
							"HasDraftEntity": false,
							"HasActiveEntity": false,
							"IsActiveEntity": true,
							"to_WebTrckgMappgLgSts": {
								"__metadata": {
									"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgLgSts('F')",
									"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgLgSts('F')",
									"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgLgStsType"
								},
								"WebTrckgMappgLgSts_Text": "Failed"
							}
						}]
					};

					oXhr.respond(200, {
						"Content-Type": "application/json"
					}, JSON.stringify({
						"d": oNewEntityData
					}));

					return true;
				}
			});

			//---------------------------------------------------------------------------------------------------------------------------------------
			//															Display Active Version
			//---------------------------------------------------------------------------------------------------------------------------------------

			//Sibling entity request. Called when you want to display the active version AND when you want to continue editing. The behavior
			//of this method is a "toggle". NOTE: It works when clicking on "Display Active Version", but not "Continue Editing"
			aRequests.push({
				method: "GET",
				path: new RegExp("C_MKT_WebTrackingMappingTP.*\/SiblingEntity.*"),
				response: function (oXhr) {

					//this gets the json file
					var aEntitySetData = oMockServer.getEntitySetData("C_MKT_WebTrackingMappingTP");

					//first extract the UUID from the URL
					var urlSplit = oXhr.url.split("\'");
					//taking the guid, which is inside of the ''
					var uuid = urlSplit[1];
					//do not take that value, because generated by backend.
					var intGuid = findIndexByUUID(uuid);
					//instead
					//only if the variable has been set
					if (MockRequestsGeneralButtons.getCapturedUUIDIndex() !== -1) {
						intGuid = MockRequestsGeneralButtons.getCapturedUUIDIndex();
						aEntitySetData[intGuid].WebTrackingMappingUUID = uuid;
						//sets it back to -1
						MockRequestsGeneralButtons.setCapturedUUIDIndex();
					}

					var oNewEntityData = {
						"__metadata": {
							"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
								"',IsActiveEntity=true)",
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
								"',IsActiveEntity=true)",
							"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrackingMappingTPType"
						},
						"Activate_ac": false,
						"Activation_ac": false,
						"Clear_filter_ac": true,
						"Copy_ac": true,
						"Deactivate_ac": false,
						"Edit_ac": true,
						"Preparation_ac": false,
						"Validate_ac": true,
						"Validation_ac": false,
						"WebTrackingMappingDataSource_fc": 1,
						"WebTrackingMappingDataTable_fc": 1,
						"WebTrackingMappingName_fc": 1,
						"WebTrackingMappingProject_fc": 1,
						"WebTrackingMappingProperty_fc": 1,
						"WebTrackingMappingView_fc": 1,
						"Delete_mc": true,
						"Update_mc": true,
						"WebTrackingMappingUUID": "" + uuid + "",
						"WebTrackingMappingName": aEntitySetData[intGuid].WebTrackingMappingName,
						"WebTrackingMappingStatus": "",
						"WebTrckgMappgStatusCriticality": 0,
						"WebTrackingMappingProject": "",
						"WebTrackingMappingDataTable": "",
						"WebTrackingMappingProperty": "UA-116478339-3",
						"WebTrackingMappingView": "179257477",
						"WebTrackingMappingType": "I",
						"WebTrackingMappingDataSource": "A",
						"WebTrackingMappingRetrievalStr": "",
						"WebTrackingMappingFilterString": "",
						"WebTrckgComMappgCreateIsEnbld": true,
						"HasDraftEntity": true,
						"ActiveUUID": "00000000-0000-0000-0000-000000000000",
						"DraftEntityCreationDateTime": null,
						"DraftEntityLastChangeDateTime": null,
						"HasActiveEntity": false,
						"IsActiveEntity": true,
						"DraftAdministrativeData": {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
									"',IsActiveEntity=true)/DraftAdministrativeData"
							}
						},
						"SiblingEntity": {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
									"',IsActiveEntity=true)/SiblingEntity"
							}
						},
						"to_WebTrackingMappgType": {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
									"',IsActiveEntity=true)/to_WebTrackingMappgType"
							}
						},
						"to_WebTrackingMappgView": {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
									"',IsActiveEntity=true)/to_WebTrackingMappgView"
							}
						},
						"to_WebTrckgComMapping": {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
									"',IsActiveEntity=true)/to_WebTrckgComMapping"
							}
						},
						"to_WebTrckgMappgDataSrce": {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
									"',IsActiveEntity=true)/to_WebTrckgMappgDataSrce"
							}
						},
						"to_WebTrckgMappgDataTable": {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
									"',IsActiveEntity=true)/to_WebTrckgMappgDataTable"
							}
						},
						"to_WebTrckgMappgFltr": {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
									"',IsActiveEntity=true)/to_WebTrckgMappgFltr"
							}
						},
						"to_WebTrckgMappgProject": {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
									"',IsActiveEntity=true)/to_WebTrckgMappgProject"
							}
						},
						"to_WebTrckgMappgProperty": {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
									"',IsActiveEntity=true)/to_WebTrckgMappgProperty"
							}
						},
						"to_WebTrckgMappgStatus": {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
									"',IsActiveEntity=true)/to_WebTrckgMappgStatus"
							}
						},
						"to_WebTrckgMappingLog": {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
									"',IsActiveEntity=true)/to_WebTrckgMappingLog"
							}
						},
						"to_WebTrckgRtrvlIaHdr": {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
									"',IsActiveEntity=true)/to_WebTrckgRtrvlIaHdr"
							}
						},
						"to_WebTrckgRtrvlProdHdr": {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
									"',IsActiveEntity=true)/to_WebTrckgRtrvlProdHdr"
							}
						},
						"to_WebTrckgRtrvlTagHdr": {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
									"',IsActiveEntity=true)/to_WebTrckgRtrvlTagHdr"
							}
						},
						"to_WebTrckgValMapping": {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + uuid +
									"',IsActiveEntity=true)/to_WebTrckgValMapping"
							}
						}
					};
					//}

					aEntitySetData[intGuid] = oNewEntityData;

					//updating the draftAdministrativeData because of errors of every object
					for (var i = 0; i < aEntitySetData.length; i++) {
						aEntitySetData[i].DraftAdministrativeData = {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + i.toString() +
									"',IsActiveEntity=true)/DraftAdministrativeData"
							}
						};
					}
					oMockServer.setEntitySetData("C_MKT_WebTrackingMappingTP", aEntitySetData);

					oXhr.respond(200, {
						"Content-Type": "application/json"
					}, JSON.stringify({
						"d": oNewEntityData
					}));

					return true;

				}
			});

			// handling the metadata error test
			if (oUriParameters.get("metadataError")) {
				aRequests.forEach(function (aEntry) {
					if (aEntry.path.toString().indexOf("$metadata") > -1) {
						fnResponse(500, "metadata Error", aEntry);
					}
				});
			}

			// Handling request errors
			if (sErrorParam) {
				aRequests.forEach(function (aEntry) {
					if (aEntry.path.toString().indexOf(sEntity) > -1) {
						fnResponse(iErrorCode, sErrorParam, aEntry);
					}
				});
			}

			oMockServer.setRequests(aRequests);
			oMockServer.start();

			jQuery.sap.log.info("Running the app with mock data");

			if (aAnnotations && aAnnotations.length > 0) {
				aAnnotations.forEach(function (sAnnotationName) {
					var oAnnotation = oDataSource[sAnnotationName],
						sUri = oAnnotation.uri,
						sLocalUri = jQuery.sap.getModulePath(_sAppModulePath + oAnnotation.settings.localUri.replace(".xml", ""), ".xml");
					///annotations
					new MockServer({
						rootUri: sUri,
						requests: [{
							method: "GET",
							path: new RegExp(".*"),
							response: function (oXhr) {
								jQuery.sap.require("jquery.sap.xml");

								var oAnnotations = jQuery.sap.sjax({
									url: sLocalUri,
									dataType: "xml"
								}).data;

								oXhr.respondXML(200, {}, jQuery.sap.serializeXML(oAnnotations));
								return true;
							}
						}]

					}).start();

				});
			}

		},

		/**
		 * @public returns the mockserver of the app, should be used in integration tests
		 * @returns {sap.ui.core.util.MockServer}
		 */
		getMockServer: function () {
			return oMockServer;
		}
	};

});