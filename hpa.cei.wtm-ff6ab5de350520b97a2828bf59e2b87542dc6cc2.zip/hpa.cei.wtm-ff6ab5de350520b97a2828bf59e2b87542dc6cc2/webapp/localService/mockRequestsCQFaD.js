sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/util/MockServer",
	"./mockHelper"

], function (jQuery, MockServer, MockHelper) {
	//Common Query Filters and Dimensions (CQFaD)
	
	var globalUUID="0";
	//list containing the different common filters for the different objects
	//this here retrieves the common filters of the object
	var commonFilters = {
		"__count": "2",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappgFltrTP(WebTrckgMappgFilterUUID=guid'" +
					globalUUID + "',IsActiveEntity=true)",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappgFltrTP(WebTrckgMappgFilterUUID=guid'" +
					globalUUID + "',IsActiveEntity=true)",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgMappgFltrTPType"
			},
			"WebTrckgMappgFilterUUID": globalUUID,
			"WebTrckgMappingFilterOption": "EX",
			"WebTrckgMappingFilterSign": "I",
			"WebTrackingMappingField": "ga:eventCategory",
			"WebTrckgMappingFieldValue": "Ecommerce",
			"WebTrackingMappingProperty": "UA-116478339-3",
			"HasDraftEntity": false,
			"HasActiveEntity": false,
			"IsActiveEntity": true,
			"to_WebTrckgFilterOption": {
				"__metadata": {
					"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgFilterOption('EX')",
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgFilterOption('EX')",
					"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgFilterOptionType"
				},
				"WebTrckgMappingFilterOption_Text": "Exact"
			},
			"to_WebTrckgFilterSign": {
				"__metadata": {
					"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgFilterSign('I')",
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgFilterSign('I')",
					"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgFilterSignType"
				},
				"WebTrckgMappingFilterSign_Text": "Include"
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappgFltrTP(WebTrckgMappgFilterUUID=guid'" +
					globalUUID + "',IsActiveEntity=true)",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappgFltrTP(WebTrckgMappgFilterUUID=guid'" +
					globalUUID + "',IsActiveEntity=true)",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgMappgFltrTPType"
			},
			"WebTrckgMappgFilterUUID": globalUUID,
			"WebTrckgMappingFilterOption": "EX",
			"WebTrckgMappingFilterSign": "I",
			"WebTrackingMappingField": "ga:eventAction",
			"WebTrckgMappingFieldValue": "Add to Cart",
			"WebTrackingMappingProperty": "UA-116478339-3",
			"HasDraftEntity": false,
			"HasActiveEntity": false,
			"IsActiveEntity": true,
			"to_WebTrckgFilterOption": {
				"__metadata": {
					"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgFilterOption('EX')",
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgFilterOption('EX')",
					"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgFilterOptionType"
				},
				"WebTrckgMappingFilterOption_Text": "Exact"
			},
			"to_WebTrckgFilterSign": {
				"__metadata": {
					"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgFilterSign('I')",
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgFilterSign('I')",
					"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgFilterSignType"
				},
				"WebTrckgMappingFilterSign_Text": "Include"
			}
		}]
	};
	
	//this here retrieves the common dimensions of the object
	var commonDimensions = {
		"__count": "2",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgComMappingTP(WebTrckgComMappgUUID=guid'" +
					globalUUID + "',IsActiveEntity=true)",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgComMappingTP(WebTrckgComMappgUUID=guid'" +
					globalUUID + "',IsActiveEntity=true)",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgComMappingTPType"
			},
			"WebTrckgComMappgUUID": globalUUID,
			"WebTrckgMappgExternalField": "ga:dimension4",
			"WebTrckgMappingInternalField": "InteractionContactId",
			"WebTrackingMappingProperty": "UA-116478339-3",
			"HasDraftEntity": false,
			"HasActiveEntity": false,
			"IsActiveEntity": true,
			"to_WebTrckgIntactnField": {
				"__metadata": {
					"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionContactId')",
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionContactId')",
					"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
				},
				"WebTrackingMappingField_Text": ""
			},
			"to_WebTrckgMappingDimn": {
				"__metadata": {
					"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Adimension4',WebTrackingMappingProperty='UA-116478339-3')",
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Adimension4',WebTrackingMappingProperty='UA-116478339-3')",
					"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
				},
				"WebTrckgMappingExtFieldLabel": "yUserID"
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgComMappingTP(WebTrckgComMappgUUID=guid'" +
					globalUUID + "',IsActiveEntity=true)",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgComMappingTP(WebTrckgComMappgUUID=guid'" +
					globalUUID + "',IsActiveEntity=true)",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgComMappingTPType"
			},
			"WebTrckgComMappgUUID": globalUUID,
			"WebTrckgMappgExternalField": "ga:dimension3",
			"WebTrckgMappingInternalField": "InteractionTimeStampUTC",
			"WebTrackingMappingProperty": "UA-116478339-3",
			"HasDraftEntity": false,
			"HasActiveEntity": false,
			"IsActiveEntity": true,
			"to_WebTrckgIntactnField": {
				"__metadata": {
					"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionTimeStampUTC')",
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionTimeStampUTC')",
					"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
				},
				"WebTrackingMappingField_Text": ""
			},
			"to_WebTrckgMappingDimn": {
				"__metadata": {
					"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Adimension3',WebTrackingMappingProperty='UA-116478339-3')",
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Adimension3',WebTrackingMappingProperty='UA-116478339-3')",
					"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
				},
				"WebTrckgMappingExtFieldLabel": "yHitTimestamp"
			}
		}]
	};
	
	function _addCQFaDRequests(oMockServer, aRequests){
		
		//---------------------------------------------------------------------------------------------------------------------------------------
		//												Common Query Filters and Dimensions
		//---------------------------------------------------------------------------------------------------------------------------------------
		aRequests.push({
			method: "POST",
			path: /.*\/C_MKT_WebTrackingMappingTPClear_filter.*/,
			response: function(oXhr, sUrlParams) {
				oXhr.respond(500, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					IsInvalid: true
				}));
			}
		});

		//these below are the common filters of the object
		aRequests.push({
			method: "GET",
			path: /C_MKT_WebTrackingMappingTP.*\/to_WebTrckgMappgFltr(?!\/\$count).*/,
			response: function (oXhr, sUrlParams) {
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": commonFilters
				}));

				return true;
			}
		});
		aRequests.push({
			method: "GET",
			path: /C_MKT_WebTrackingMappingTP.*\/to_WebTrckgMappgFltr\/\$count/,
			response: function(oXhr, sUrlParams) {
				oXhr.respond(200, {
					"Content-Type" : "text/plain; charset=utf-8"
				}, "2");
				return true;
			}
		});

		//these below are the common dimensions of the object
		aRequests.push({
			method: "GET",
			path: new RegExp("C_MKT_WebTrackingMappingTP.*\/to_WebTrckgComMapping.*"),
			response: function (oXhr, sUrlParams) {

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": commonDimensions
				}));

				return true;
			}
		});

		//grab all the possible Dimension/Metric from the Common Query Filter and Dimensions section by clicking at the little squares in the dimension field
		aRequests.push({
			method: "GET",
			path: new RegExp("I_MKT_WebTrckgMappgDimnMsr.*"),
			response: function (oXhr, sUrlParams) {
				var oNewEntityData = MockHelper.getI_MKT_WebTrckgMappgDimnMsr();

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;

			}
		});

		//possible operations on the Common Filters section in the Common Query Filter and Dimensions
		aRequests.push({
			method: "GET",
			path: "I_MKT_WebTrckgFilterOption.*",
			response: function (oXhr, sUrlParams) {
				var oNewEntityData = {
					"__count": "2",
					"results": [{
						"__metadata": {
							"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgFilterOption('EX')",
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgFilterOption('EX')",
							"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgFilterOptionType"
						},
						"WebTrckgMappingFilterOption": "EX",
						"WebTrckgMappingFilterOption_Text": "Exact"
					}, {
						"__metadata": {
							"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgFilterOption('RX')",
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgFilterOption('RX')",
							"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgFilterOptionType"
						},
						"WebTrckgMappingFilterOption": "RX",
						"WebTrckgMappingFilterOption_Text": "Regex"
					}]
				};

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});

		//possible operators on the Common Filters section in the Common Query Filter and Dimensions
		aRequests.push({
			method: "GET",
			path: "I_MKT_WebTrckgFilterSign.*",
			response: function (oXhr, sUrlParams) {
				var oNewEntityData = {
					"__count": "2",
					"results": [{
						"__metadata": {
							"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgFilterSign('E')",
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgFilterSign('E')",
							"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgFilterSignType"
						},
						"WebTrckgMappingFilterSign": "E",
						"WebTrckgMappingFilterSign_Text": "Exclude"
					}, {
						"__metadata": {
							"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgFilterSign('I')",
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgFilterSign('I')",
							"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgFilterSignType"
						},
						"WebTrckgMappingFilterSign": "I",
						"WebTrckgMappingFilterSign_Text": "Include"
					}]
				};

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});

		//possible Google Analytics Dimensions in the Common Dimensions section on the Common Query Filter and Dimensions tab on Edit Mode
		aRequests.push({
			method: "GET",
			path: new RegExp("I_MKT_WebTrckgMappingDimn.*"),
			response: function (oXhr, sUrlParams) {
				var oNewEntityData = MockHelper.getI_MKT_WebTrckgMappingDimn();

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});

		//Possible Interaction Fields from the Google Analytics Dimensions in the Common Dimensions section on the Common Query Filter and Dimensions tab on Edit Mode
		aRequests.push({
			method: "GET",
			path: new RegExp("I_MKT_WebTrckgIntactnField.*"),
			response: function (oXhr, sUrlParams) {
				var oNewEntityData = MockHelper.getI_MKT_WebTrckgIntactnField();

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});

		//removing a common filter. MUST RELY ON UUID!
		aRequests.push({
			method: "DELETE",
			path: new RegExp("C_MKT_WebTrckgMappgFltrTP.*"),
			response: function (oXhr) {
				//removing the first object in the list
				if (commonFilters.results.length > 0) {
					commonFilters.results.splice(0, 1);
					//decreasing the count if it happened
					commonFilters.count--;
				}

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": commonFilters
				}));

				return true;
			}
		});

		//removing a common dimension. MUST RELY ON UUID!
		aRequests.push({
			method: "DELETE",
			path: new RegExp("C_MKT_WebTrckgComMappingTP.*"),
			response: function (oXhr) {
				//removing the first object in the list
				if (commonDimensions.results.length > 0) {
					commonDimensions.results.splice(0, 1);
					//decreasing the count if it happened
					commonDimensions.count--;
				}

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": commonDimensions
				}));

				return true;
			}
		});

		//adding a common filter.
		aRequests.push({
			method: "POST",
			path: new RegExp("C_MKT_WebTrackingMappingTP.*\/to_WebTrckgMappgFltr.*"),
			response: function (oXhr) {
				var oNewEntityData = {
					"__metadata": {
						"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappgFltrTP(WebTrckgMappgFilterUUID=guid'" + globalUUID +
							"',IsActiveEntity=false)",
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappgFltrTP(WebTrckgMappgFilterUUID=guid'" +
							globalUUID + "',IsActiveEntity=false)",
						"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgMappgFltrTPType"
					},
					"Preparation_ac": true,
					"Validation_ac": true,
					"WebTrckgMappgFilterUUID": "" + globalUUID + "",
					"WebTrackingMappingUUID": "" + globalUUID + "",
					"WebTrckgMappingFilterOption": "",
					"WebTrckgMappingFilterSign": "",
					"WebTrackingMappingField": "",
					"WebTrckgMappingFieldValue": "",
					"WebTrackingMappingProperty": "UA-116478339-2",
					"HasDraftEntity": false,
					"ActiveUUID": "00000000-0000-0000-0000-000000000000",
					"DraftEntityCreationDateTime": "\/Date(1549375059632+0000)\/",
					"DraftEntityLastChangeDateTime": "\/Date(1549375059632+0000)\/",
					"HasActiveEntity": false,
					"IsActiveEntity": false,
					"to_WebTrackingMapping": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappgFltrTP(WebTrckgMappgFilterUUID=guid'" +
								globalUUID + "',IsActiveEntity=false)/to_WebTrackingMapping"
						}
					},
					"DraftAdministrativeData": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappgFltrTP(WebTrckgMappgFilterUUID=guid'" +
								globalUUID + "',IsActiveEntity=false)/DraftAdministrativeData"
						}
					},
					"SiblingEntity": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappgFltrTP(WebTrckgMappgFilterUUID=guid'" +
								globalUUID + "',IsActiveEntity=false)/SiblingEntity"
						}
					},
					"to_WebTrckgFilterOption": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappgFltrTP(WebTrckgMappgFilterUUID=guid'" +
								globalUUID + "',IsActiveEntity=false)/to_WebTrckgFilterOption"
						}
					},
					"to_WebTrckgFilterSign": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappgFltrTP(WebTrckgMappgFilterUUID=guid'" +
								globalUUID + "',IsActiveEntity=false)/to_WebTrckgFilterSign"
						}
					},
					"to_WebTrckgMappgDimnMsr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgMappgFltrTP(WebTrckgMappgFilterUUID=guid'" +
								globalUUID + "',IsActiveEntity=false)/to_WebTrckgMappgDimnMsr"
						}
					}
				};

				//getting the common filters
				commonFilters.results.push(oNewEntityData);

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});

		//adding a common dimension
		aRequests.push({
			method: "POST",
			path: new RegExp("C_MKT_WebTrackingMappingTP.*\/to_WebTrckgComMapping.*"),
			response: function (oXhr) {
				var oNewEntityData = {
					"__metadata": {
						"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgComMappingTP(WebTrckgComMappgUUID=guid'" + globalUUID +
							"',IsActiveEntity=false)",
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgComMappingTP(WebTrckgComMappgUUID=guid'" + globalUUID +
							"',IsActiveEntity=false)",
						"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgComMappingTPType"
					},
					"Preparation_ac": true,
					"Validation_ac": true,
					"WebTrckgComMappgUUID": "" + globalUUID + "",
					"WebTrackingMappingUUID": "" + globalUUID + "",
					"WebTrckgMappgExternalField": "",
					"WebTrckgMappingInternalField": "",
					"WebTrackingMappingProperty": "UA-116478339-2",
					"HasDraftEntity": false,
					"ActiveUUID": "00000000-0000-0000-0000-000000000000",
					"DraftEntityCreationDateTime": "\/Date(1549375567198+0000)\/",
					"DraftEntityLastChangeDateTime": "\/Date(1549375567198+0000)\/",
					"HasActiveEntity": false,
					"IsActiveEntity": false,
					"to_WebTrackingMapping": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgComMappingTP(WebTrckgComMappgUUID=guid'" + globalUUID +
								"',IsActiveEntity=false)/to_WebTrackingMapping"
						}
					},
					"DraftAdministrativeData": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgComMappingTP(WebTrckgComMappgUUID=guid'" + globalUUID +
								"',IsActiveEntity=false)/DraftAdministrativeData"
						}
					},
					"SiblingEntity": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgComMappingTP(WebTrckgComMappgUUID=guid'" + globalUUID +
								"',IsActiveEntity=false)/SiblingEntity"
						}
					},
					"to_WebTrckgIntactnField": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgComMappingTP(WebTrckgComMappgUUID=guid'" + globalUUID +
								"',IsActiveEntity=false)/to_WebTrckgIntactnField"
						}
					},
					"to_WebTrckgMappingDimn": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgComMappingTP(WebTrckgComMappgUUID=guid'" + globalUUID +
								"',IsActiveEntity=false)/to_WebTrckgMappingDimn"
						}
					}
				};

				//getting common dimensions
				commonDimensions.results.push(oNewEntityData);

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});
		
	}
	
	function _getCommonDimensions(){
		return commonDimensions;
	}
	
	function _setCommonDimensions(index, value){
		commonDimensions[index] = value;
	}
	
	function _getCommonFilters(){
		return commonDimensions;
	}
	
	function _setCommonFilters(index, value){
		commonDimensions[index] = value;
	}
	
	
	return {
		addCQFaDRequests: _addCQFaDRequests,
		getCommonDimensions: _getCommonDimensions,
		setCommonDimensions: _setCommonDimensions,
		getCommonFilters: _getCommonFilters,
		setCommonFilters: _setCommonFilters              
	};
});