sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/util/MockServer",
	"./mockHelper"
], function (jQuery, MockServer, MockHelper) {
	//identifies uniquely each interaction field parameter. This will be their UUID.
	var counter= 1000010;
	//array of interaction fields
	//new variable added: "uuid" to associate each one to an object.
	var resultInteractionFields = {
		"__count": "4",
		"uuid":"0",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'1000000',IsActiveEntity=true)",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" + "1000000" +
					"',IsActiveEntity=true)",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgValMappingTPType"
			},
			"WebTrackingMappingField_fc": 1,
			"Delete_mc": true,
			"WebTrckgValueMappgUUID": "1000000",
			"WebTrackingMappingField": "InteractionType",
			"WebTrckgMappingFieldLabel": "",
			"WebTrckgMappingFieldValue": "SHOP_ITEM_ADD",
			"WebTrckgMappgValFldSortPos": 0,
			"HasDraftEntity": false,
			"HasActiveEntity": false,
			"IsActiveEntity": true
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" + "1000001" +
					"',IsActiveEntity=true)",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" + "1000001" +
					"',IsActiveEntity=true)",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgValMappingTPType"
			},
			"WebTrackingMappingField_fc": 1,
			"Delete_mc": true,
			"WebTrckgValueMappgUUID": "1000001",
			"WebTrackingMappingField": "CommunicationMedium",
			"WebTrckgMappingFieldLabel": "",
			"WebTrckgMappingFieldValue": "ONLINE_SHOP",
			"WebTrckgMappgValFldSortPos": 1,
			"HasDraftEntity": false,
			"HasActiveEntity": false,
			"IsActiveEntity": true
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" + "1000002" +
					"',IsActiveEntity=true)",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" + "1000002" +
					"',IsActiveEntity=true)",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgValMappingTPType"
			},
			"WebTrackingMappingField_fc": 1,
			"Delete_mc": true,
			"WebTrckgValueMappgUUID": "1000002",
			"WebTrackingMappingField": "InteractionContactOrigin",
			"WebTrckgMappingFieldLabel": "",
			"WebTrckgMappingFieldValue": "SAP_HYBRIS_CONSUMER",
			"WebTrckgMappgValFldSortPos": 2,
			"HasDraftEntity": false,
			"HasActiveEntity": false,
			"IsActiveEntity": true
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" + "1000003" +
					"',IsActiveEntity=true)",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" + "1000003" +
					"',IsActiveEntity=true)",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgValMappingTPType"
			},
			"WebTrackingMappingField_fc": 1,
			"Delete_mc": true,
			"WebTrckgValueMappgUUID": "1000003",
			"WebTrackingMappingField": "CampaignContentLinkURL",
			"WebTrckgMappingFieldLabel": "",
			"WebTrckgMappingFieldValue": "cxcxzcxz",
			"WebTrckgMappgValFldSortPos": 3,
			"HasDraftEntity": false,
			"HasActiveEntity": false,
			"IsActiveEntity": true
		}]
	};
	/*,{
		"__count": "1",
		"uuid":"1",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'1000004',IsActiveEntity=true)",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" + "1000004" +
					"',IsActiveEntity=true)",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgValMappingTPType"
			},
			"WebTrackingMappingField_fc": 1,
			"Delete_mc": true,
			"WebTrckgValueMappgUUID": "1000004",
			"WebTrackingMappingField": "InteractionType",
			"WebTrckgMappingFieldLabel": "",
			"WebTrckgMappingFieldValue": "SHOP_ITEM_ADD",
			"WebTrckgMappgValFldSortPos": 0,
			"HasDraftEntity": false,
			"HasActiveEntity": false,
			"IsActiveEntity": true
		}]
	},{
		"__count": "2",
		"uuid":"2",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" + "1000005" +
					"',IsActiveEntity=true)",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" + "1000005" +
					"',IsActiveEntity=true)",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgValMappingTPType"
			},
			"WebTrackingMappingField_fc": 1,
			"Delete_mc": true,
			"WebTrckgValueMappgUUID": "1000005",
			"WebTrackingMappingField": "InteractionContactOrigin",
			"WebTrckgMappingFieldLabel": "",
			"WebTrckgMappingFieldValue": "SAP_HYBRIS_CONSUMER",
			"WebTrckgMappgValFldSortPos": 2,
			"HasDraftEntity": false,
			"HasActiveEntity": false,
			"IsActiveEntity": true
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" + "1000006" +
					"',IsActiveEntity=true)",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" + "1000006" +
					"',IsActiveEntity=true)",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgValMappingTPType"
			},
			"WebTrackingMappingField_fc": 1,
			"Delete_mc": true,
			"WebTrckgValueMappgUUID": "1000006",
			"WebTrackingMappingField": "CampaignContentLinkURL",
			"WebTrckgMappingFieldLabel": "",
			"WebTrckgMappingFieldValue": "cxcxzcxz",
			"WebTrckgMappgValFldSortPos": 3,
			"HasDraftEntity": false,
			"HasActiveEntity": false,
			"IsActiveEntity": true
		}]
	}];*/
	
	//first time a request is made for loading this tab, no content is added. all the other times, content is added.
	var isAdded = false;
	
	function _addInteractionFieldsRequests(oMockServer, aRequests){
		
		//---------------------------------------------------------------------------------------------------------------------------------------
		//															All Interaction Fields Requests
		//---------------------------------------------------------------------------------------------------------------------------------------
		
		//empty object being sent for adding an interaction field
		aRequests.push({
			method: "GET",
			path: new RegExp("C_MKT_WebTrackingMappingTP.*to_WebTrckgValMapping"),
			response: function (oXhr, sUrlParams) {
				//until there are no parameters for each object, then this will not be used.
				var urlSplit = oXhr.url.split("\'");
				//taking the guid, which is inside of the ''
				var guid = urlSplit[1];
				var oNewEntityData = {
					"__metadata": {
						"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" + guid +
							"',IsActiveEntity=false)",
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" +
							guid + "',IsActiveEntity=false)",
						"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgValMappingTPType"
					},
					"Preparation_ac": true,
					"Validation_ac": true,
					"WebTrackingMappingField_fc": 3,
					"Delete_mc": true,
					"WebTrckgValueMappgUUID": guid,
					"WebTrackingMappingUUID": guid,
					"WebTrckgValMappgObj": "",
					"WebTrackingMappingField": "",
					"WebTrckgMappingFieldLabel": "Amount",
					"WebTrckgMappingFieldValue": "",
					"WebTrckgMappgValFldSortPos": 0,
					"HasDraftEntity": false,
					"ActiveUUID": "00000000-0000-0000-0000-000000000000",
					"DraftEntityCreationDateTime": "\/Date(1549029797114+0000)\/",
					"DraftEntityLastChangeDateTime": "\/Date(1549029797114+0000)\/",
					"HasActiveEntity": false,
					"IsActiveEntity": false,
					"to_WebTrackingMapping": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" +
								guid + "',IsActiveEntity=false)/to_WebTrackingMapping"
						}
					},
					"DraftAdministrativeData": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" +
								guid + "',IsActiveEntity=false)/DraftAdministrativeData"
						}
					},
					"SiblingEntity": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" +
								guid + "',IsActiveEntity=false)/SiblingEntity"
						}
					},
					"to_WebTrckgIntactnField": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" +
								guid + "',IsActiveEntity=false)/to_WebTrckgIntactnField"
						}
					},
					"to_WebTrckgIntactnFldVH": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" +
								guid + "',IsActiveEntity=false)/to_WebTrckgIntactnFldVH"
						}
					},
					"to_WebTrckgValMappgObj": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" +
								guid + "',IsActiveEntity=false)/to_WebTrckgValMappgObj"
						}
					}
				};
				
				
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});

		//deletes object 0 for now of the interaction fields. NEED TO RELY ON UUID!
		aRequests.push({
			method: "DELETE",
			path: new RegExp("C_MKT_WebTrckgValMappingTP.*"),
			response: function (oXhr, sUrlParams) {
				//NOT USED
				var urlSplit = oXhr.url.split("\'");
				//taking the guid, which is inside of the ''
				var guid = urlSplit[1];

				//removing the selected object from the list
				//capturing modified list
				for(var i =0;i<resultInteractionFields.results.length;i++){
					if(resultInteractionFields.results[i].WebTrckgValueMappgUUID === guid){
						resultInteractionFields.count--;
						resultInteractionFields.results.splice(i,i+1);
						//resultInteractionFields.results.splice(resultInteractionFields.results.length-1, resultInteractionFields.results.length);
						break;
					}
				}
				//for some reason shows a new interaction field. we dont want that
				isAdded=false;

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": resultInteractionFields
				}));

				return true;
			}
		});

		//makes the interaction fields appear correctly. NEED TO RELY ON UUID!
		aRequests.push({
			method: "GET",
			path: new RegExp("C_MKT_WebTrckgValMappingTP.*"),
			response: function (oXhr) {
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": resultInteractionFields
				}));
			}
		});

		//Visualizing Interaction Fields
		aRequests.push({
			method: "GET",
			path: new RegExp("C_MKT_WebTrackingMappingTP\(WebTrackingMappingUUID=guid'.*',IsActiveEntity=true\)\/to_WebTrckgValMapping\?.*"),
			response: function (oXhr, sUrlParams) {
				var oNewEntityData = resultInteractionFields;

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});

		//Opening Interaction Fields in Edit mode
		aRequests.push({
			method: "GET",
			path: new RegExp(
				"C_MKT_WebTrackingMappingTP.*IsActiveEntity=false.*\/to_WebTrckgValMapping\?.*skip=0.*top=.*"),
			response: function (oXhr, sUrlParams) {
				var oNewEntityData = resultInteractionFields;

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});

		//In Edit mode, when the mock server realizes there are only X results (does one request without knowing the result, then a second when
		//it knows how many interaction fields there are)
		aRequests.push({
			method: "GET",
			path: new RegExp(
				"C_MKT_WebTrackingMappingTP.*IsActiveEntity=false.*\/to_WebTrckgValMapping\?.*skip=0.*top=.*orderby=WebTrckgMappgValFldSortPos.*Delete_mc"
			),
			response: function (oXhr, sUrlParams) {
				var oNewEntityData = resultInteractionFields;

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});

		//In Edit mode, in the interaction fields section, clicking on +
		aRequests.push({
			method: "GET",
			path: new RegExp(
				"C_MKT_WebTrackingMappingTP.*IsActiveEntity=false.*\/to_WebTrckgValMapping\?.*skip=0.*top=.*orderby=WebTrckgMappgValFldSortPos.*inlinecount=allpages"
			),
			response: function (oXhr, sUrlParams) {
				//------------------------------------------------------------------------------------------------------------------------
				//Here, the URL with get mixed between the case where user directly selects Interaction Fields and clicks on Edit, and 
				//the case where the user starts from a different tab, clicks on Edit, and then clicks on + in the Interaction Fields section
				//------------------------------------------------------------------------------------------------------------------------
				var stringify = JSON.stringify(resultInteractionFields);
				var oNewEntityData = JSON.parse(stringify);
				
				if(isAdded){
					oNewEntityData['results'].push({
						"__metadata": {
							"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" +
								counter.toString(10) + "',IsActiveEntity=true)",
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" +
								counter.toString(10) + "',IsActiveEntity=true)",
							"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgValMappingTPType"
						},
						"WebTrackingMappingField_fc": 3,
						"Delete_mc": true,
						"WebTrckgValueMappgUUID": counter.toString(10),
						"WebTrackingMappingField": "",
						"WebTrckgMappingFieldLabel": "",
						"WebTrckgMappingFieldValue": "",
						"WebTrckgMappgValFldSortPos": 0,
						"HasDraftEntity": false,
						"HasActiveEntity": false,
						"IsActiveEntity": true
					});
					
					//increasing counter for unique UUID
					counter++;
					
					resultInteractionFields = oNewEntityData;
				}
				isAdded=true;
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});

		//Gives the possible selections of the types of variables in InteractionFields on Edit mode
		aRequests.push({
			method: "GET",
			path: new RegExp("I_MKT_WebTrckgIntactnFldVH.*"),
			response: function (oXhr, sUrlParams) {
				var oNewEntityData = MockHelper.getI_MKT_WebTrckgIntactnFldVH();

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});
		
		//all of the requests below are constant. These are associated to F4 Help of the interaction section.
		aRequests.push({
			method: "GET",
			path: new RegExp("I_MKT_InteractionType.*"),
			response: function(oXhr){
				
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": MockHelper.getI_MKT_InteractionType()
				}));
				
				return true;
			}
		});
		
		aRequests.push({
			method: "GET",
			path: new RegExp("I_MKT_InteractionProductStatus.*"),
			response: function(oXhr){
				
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": MockHelper.getI_MKT_InteractionProductStatus()
				}));
				
				return true;
			}
		});
		
		aRequests.push({
			method: "GET",
			path: new RegExp("I_UnitOfMeasure.*"),
			response: function(oXhr){
				
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": MockHelper.getI_UnitOfMeasure()
				}));
				
				return true;
			}
		});
		
		aRequests.push({
			method: "GET",
			path: new RegExp("I_MKT_LocationOrigin.*"),
			response: function(oXhr){
				
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": MockHelper.getI_MKT_LocationOrigin()
				}));
				
				return true;
			}
		});
		
		aRequests.push({
			method: "GET",
			path: new RegExp("I_MKT_InteractionStatus.*"),
			response: function(oXhr){
				
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": MockHelper.getI_MKT_InteractionStatus()
				}));
				
				return true;
			}
		});
		
		aRequests.push({
			method: "GET",
			path: new RegExp("I_MKT_InteractionSentiment.*"),
			response: function(oXhr){
				
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": MockHelper.getI_MKT_InteractionSentiment()
				}));
				
				return true;
			}
		});
		
		aRequests.push({
			method: "GET",
			path: new RegExp("I_MKT_DigitalAccountType.*"),
			response: function(oXhr){
				
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": MockHelper.getI_MKT_DigitalAccountType()
				}));
				
				return true;
			}
		});
		
		aRequests.push({
			method: "GET",
			path: new RegExp("I_MKT_AgreementOrigin.*"),
			response: function(oXhr){
				
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": MockHelper.getI_MKT_AgreementOrigin()
				}));
				
				return true;
			}
		});
		
		//Interaction Language not showing??
		aRequests.push({
			method: "GET",
			path: new RegExp("I_Language.*"),
			response: function(oXhr){
				
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": MockHelper.getI_Language()
				}));
				
				return true;
			}
		});
		
		//Interaction Currency not showing??
		aRequests.push({
			method: "GET",
			path: new RegExp("I_Currency.*"),
			response: function(oXhr){
				
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": MockHelper.getI_Currency()
				}));
				
				return true;
			}
		});
		
		//sends data, but not showing it???
		aRequests.push({
			method: "GET",
			path: new RegExp("I_MKT_DeviceType.*"),
			response: function(oXhr){
				
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": MockHelper.getI_MKT_DeviceType()
				}));
				
				return true;
			}
		});
		
		aRequests.push({
			method: "GET",
			path: new RegExp("I_MKT_ProductOrigin.*"),
			response: function(oXhr){
				
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": MockHelper.getI_MKT_ProductOrigin()
				}));
				
				return true;
			}
		});
		
		aRequests.push({
			method: "GET",
			path: new RegExp("I_MKT_ActiveMarketingArea.*"),
			response: function(oXhr){
				
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": MockHelper.getI_MKT_ActiveMarketingArea()
				}));
				
				return true;
			}
		});
		
		aRequests.push({
			method: "GET",
			path: new RegExp("I_MKT_Contactorigin.*"),
			response: function(oXhr){
				
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": MockHelper.getI_MKT_Contactorigin()
				}));
				
				return true;
			}
		});
		
		aRequests.push({
			method: "GET",
			path: new RegExp("I_MKT_CommMedium.*"),
			response: function(oXhr){
				
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": MockHelper.getI_MKT_CommMedium()
				}));
				
				return true;
			}
		});
	}
	
	function _getInteractionFields(){
		return resultInteractionFields;
	}
	
	function _setInteractionFields(update){
		resultInteractionFields = update;
	}
	
	function _addSetOfInteractionFields(add){
		resultInteractionFields.results.push(add);
	}
	
	function _resetIsAdded(){
		isAdded = false;
	}
	
	return {
		addInteractionFieldsRequests: _addInteractionFieldsRequests,
		getInteractionFields: _getInteractionFields,
		setInteractionFields: _setInteractionFields,
		addSetOfInteractionFields: _addSetOfInteractionFields,
		resetIsAdded: _resetIsAdded
	};
});