sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/util/MockServer"

], function (jQuery, MockServer) {

	var I_MKT_InteractionType = {
		"__count": "112",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('APPOINTMENT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('APPOINTMENT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "APPOINTMENT",
			"InteractionType_Text": "Appointment",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('APPOINTMENT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('APPOINTMENT_CANCELLD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('APPOINTMENT_CANCELLD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "APPOINTMENT_CANCELLD",
			"InteractionType_Text": "Appointment Cancelled",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('APPOINTMENT_CANCELLD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('C4C_OPPORTUNITY')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('C4C_OPPORTUNITY')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "C4C_OPPORTUNITY",
			"InteractionType_Text": "C4C Opportunity",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('C4C_OPPORTUNITY')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('C4C_SALES_LEAD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('C4C_SALES_LEAD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "C4C_SALES_LEAD",
			"InteractionType_Text": "C4C Sales Lead",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('C4C_SALES_LEAD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CALL_CENTRE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CALL_CENTRE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "CALL_CENTRE",
			"InteractionType_Text": "Call Center",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CALL_CENTRE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CEI_INITIATIVE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CEI_INITIATIVE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "CEI_INITIATIVE",
			"InteractionType_Text": "Campaign",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CEI_INITIATIVE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CLICK_THROUGH')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CLICK_THROUGH')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "CLICK_THROUGH",
			"InteractionType_Text": "Click Through",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CLICK_THROUGH')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('COUPON_VIEWED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('COUPON_VIEWED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "COUPON_VIEWED",
			"InteractionType_Text": "Coupon Viewed",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('COUPON_VIEWED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CRM_ACTIVITY')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CRM_ACTIVITY')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "CRM_ACTIVITY",
			"InteractionType_Text": "CRM Activity",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CRM_ACTIVITY')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CRM_LEAD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CRM_LEAD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "CRM_LEAD",
			"InteractionType_Text": "CRM Lead",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CRM_LEAD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CRM_OPPORTUNITY')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CRM_OPPORTUNITY')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "CRM_OPPORTUNITY",
			"InteractionType_Text": "CRM Opportunity",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CRM_OPPORTUNITY')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CRM_SLS_ORDER')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CRM_SLS_ORDER')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "CRM_SLS_ORDER",
			"InteractionType_Text": "CRM Sales Order",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('CRM_SLS_ORDER')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DEVICE_SHAKE_NEARBY')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DEVICE_SHAKE_NEARBY')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "DEVICE_SHAKE_NEARBY",
			"InteractionType_Text": "Shake Device Nearby",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DEVICE_SHAKE_NEARBY')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_BROADCAST')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_BROADCAST')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "DIG_ACC_BROADCAST",
			"InteractionType_Text": "Broadcast Message from Digital Account",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_BROADCAST')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_INBOUND')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_INBOUND')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "DIG_ACC_INBOUND",
			"InteractionType_Text": "Inbound Message to Digital Account",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_INBOUND')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_OUTBOUND')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_OUTBOUND')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "DIG_ACC_OUTBOUND",
			"InteractionType_Text": "Outbound Message from Digital Account",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_OUTBOUND')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_SUBSCR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_SUBSCR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "DIG_ACC_SUBSCR",
			"InteractionType_Text": "Subscribe to Digital Account",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_SUBSCR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_TMP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_TMP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "DIG_ACC_TMP",
			"InteractionType_Text": "test IA type for wechat template respons",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_TMP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_UNSUBSCR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_UNSUBSCR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "DIG_ACC_UNSUBSCR",
			"InteractionType_Text": "Unsubscribe from Digital Account",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('DIG_ACC_UNSUBSCR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_BLOCKED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_BLOCKED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "EMAIL_BLOCKED",
			"InteractionType_Text": "Email Blocked",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_BLOCKED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_BOUNCE_HARD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_BOUNCE_HARD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "EMAIL_BOUNCE_HARD",
			"InteractionType_Text": "Hard Bounce",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_BOUNCE_HARD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_BOUNCE_SOFT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_BOUNCE_SOFT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "EMAIL_BOUNCE_SOFT",
			"InteractionType_Text": "Soft Bounce",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_BOUNCE_SOFT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_COMPLAINT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_COMPLAINT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "EMAIL_COMPLAINT",
			"InteractionType_Text": "Emails Classified as Complaint (Spam)",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_COMPLAINT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_FAILED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_FAILED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "EMAIL_FAILED",
			"InteractionType_Text": "Email Failed",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_FAILED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_INBOUND')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_INBOUND')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "EMAIL_INBOUND",
			"InteractionType_Text": "Inbound Email",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_INBOUND')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_OPENED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_OPENED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "EMAIL_OPENED",
			"InteractionType_Text": "Email Opened",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_OPENED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_OUTBOUND')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_OUTBOUND')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "EMAIL_OUTBOUND",
			"InteractionType_Text": "Outbound Email",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EMAIL_OUTBOUND')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EVENT_ATTENDED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EVENT_ATTENDED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "EVENT_ATTENDED",
			"InteractionType_Text": "Event Attended",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EVENT_ATTENDED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EVENT_REGISTERED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EVENT_REGISTERED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "EVENT_REGISTERED",
			"InteractionType_Text": "Registered for Event",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('EVENT_REGISTERED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('GAME_LOST')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('GAME_LOST')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "GAME_LOST",
			"InteractionType_Text": "",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('GAME_LOST')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('GAME_UNATTENDED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('GAME_UNATTENDED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "GAME_UNATTENDED",
			"InteractionType_Text": "",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('GAME_UNATTENDED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('GAME_WON')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('GAME_WON')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "GAME_WON",
			"InteractionType_Text": "",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('GAME_WON')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('IAT_AUNIT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('IAT_AUNIT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "IAT_AUNIT",
			"InteractionType_Text": "",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('IAT_AUNIT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('LOGIN_SUCCESS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('LOGIN_SUCCESS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "LOGIN_SUCCESS",
			"InteractionType_Text": "Successfully login",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('LOGIN_SUCCESS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('LOGOUT_SUCCESS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('LOGOUT_SUCCESS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "LOGOUT_SUCCESS",
			"InteractionType_Text": "Successfully logged out",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('LOGOUT_SUCCESS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('LOY_POINT_ACCRUAL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('LOY_POINT_ACCRUAL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "LOY_POINT_ACCRUAL",
			"InteractionType_Text": "Loyalty Points Accrued",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('LOY_POINT_ACCRUAL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('LOY_POINT_REDEMPTION')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('LOY_POINT_REDEMPTION')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "LOY_POINT_REDEMPTION",
			"InteractionType_Text": "Loyalty Points Redeemed",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('LOY_POINT_REDEMPTION')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('LOY_REGISTRATION')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('LOY_REGISTRATION')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "LOY_REGISTRATION",
			"InteractionType_Text": "Loyalty Program Registration",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('LOY_REGISTRATION')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MARKETING_LEAD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MARKETING_LEAD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "MARKETING_LEAD",
			"InteractionType_Text": "Lead",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MARKETING_LEAD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MARKETING_LEAD2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MARKETING_LEAD2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "MARKETING_LEAD2",
			"InteractionType_Text": "Lead",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MARKETING_LEAD2')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MARKETING_LEAD_RAW')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MARKETING_LEAD_RAW')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "MARKETING_LEAD_RAW",
			"InteractionType_Text": "Raw Lead",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MARKETING_LEAD_RAW')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MKT_PERM_OPTIN')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MKT_PERM_OPTIN')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "MKT_PERM_OPTIN",
			"InteractionType_Text": "Opt-In for Marketing Permission",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MKT_PERM_OPTIN')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MKT_PERM_OPTIN_PRE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MKT_PERM_OPTIN_PRE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "MKT_PERM_OPTIN_PRE",
			"InteractionType_Text": "Pre Opt-In for Marketing Permission",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MKT_PERM_OPTIN_PRE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MKT_PERM_OPTOUT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MKT_PERM_OPTOUT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "MKT_PERM_OPTOUT",
			"InteractionType_Text": "Opt-Out for Marketing Permission",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MKT_PERM_OPTOUT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MKT_PERM_OPTOUT_PRE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MKT_PERM_OPTOUT_PRE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "MKT_PERM_OPTOUT_PRE",
			"InteractionType_Text": "Pre Opt-Out for Marketing Permission",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MKT_PERM_OPTOUT_PRE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MOB_APP_INSTALLED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MOB_APP_INSTALLED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "MOB_APP_INSTALLED",
			"InteractionType_Text": "Mobile Application Installed",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MOB_APP_INSTALLED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MOB_APP_NOTIF_SENT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MOB_APP_NOTIF_SENT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "MOB_APP_NOTIF_SENT",
			"InteractionType_Text": "Mobile Notification Sent",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MOB_APP_NOTIF_SENT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MOB_APP_NOTIF_VIEWED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MOB_APP_NOTIF_VIEWED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "MOB_APP_NOTIF_VIEWED",
			"InteractionType_Text": "Mobile Notification Viewed",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MOB_APP_NOTIF_VIEWED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MOB_APP_UNINSTALLED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MOB_APP_UNINSTALLED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "MOB_APP_UNINSTALLED",
			"InteractionType_Text": "Mobile Application Uninstalled",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('MOB_APP_UNINSTALLED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('NEWSLETTER_SUBSCR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('NEWSLETTER_SUBSCR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "NEWSLETTER_SUBSCR",
			"InteractionType_Text": "Subscribe to Newsletter",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('NEWSLETTER_SUBSCR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('NEWSLETTER_UNSUBSCR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('NEWSLETTER_UNSUBSCR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "NEWSLETTER_UNSUBSCR",
			"InteractionType_Text": "Unsubscribe from Newsletter",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('NEWSLETTER_UNSUBSCR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('NEWSL_SUBSCR_PRE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('NEWSL_SUBSCR_PRE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "NEWSL_SUBSCR_PRE",
			"InteractionType_Text": "Pre-subscribe to Newsletter",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('NEWSL_SUBSCR_PRE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('NEWSL_UNSUBSCR_PRE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('NEWSL_UNSUBSCR_PRE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "NEWSL_UNSUBSCR_PRE",
			"InteractionType_Text": "Pre-unsubscribe from Newsletter",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('NEWSL_UNSUBSCR_PRE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OFFER_CLICK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OFFER_CLICK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "OFFER_CLICK",
			"InteractionType_Text": "Offer Clicked",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OFFER_CLICK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OFFER_DISPLAY')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OFFER_DISPLAY')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "OFFER_DISPLAY",
			"InteractionType_Text": "Offer Displayed",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OFFER_DISPLAY')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OFFER_REDEMPTION')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OFFER_REDEMPTION')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "OFFER_REDEMPTION",
			"InteractionType_Text": "Offer Redeemed",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OFFER_REDEMPTION')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OFFER_REJECTION')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OFFER_REJECTION')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "OFFER_REJECTION",
			"InteractionType_Text": "Offer Rejected",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OFFER_REJECTION')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OPPORTUNITY')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OPPORTUNITY')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "OPPORTUNITY",
			"InteractionType_Text": "Opportunity",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OPPORTUNITY')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OUTBOUND_CHCK_FAILED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OUTBOUND_CHCK_FAILED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "OUTBOUND_CHCK_FAILED",
			"InteractionType_Text": "Outbound Check Failed",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OUTBOUND_CHCK_FAILED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OUTBOUND_FAILED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OUTBOUND_FAILED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "OUTBOUND_FAILED",
			"InteractionType_Text": "Outbound Failed",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('OUTBOUND_FAILED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('PROD_REVIEW_CREATED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('PROD_REVIEW_CREATED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "PROD_REVIEW_CREATED",
			"InteractionType_Text": "Product Review Written",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": true,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('PROD_REVIEW_CREATED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('PROD_REVIEW_VIEW')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('PROD_REVIEW_VIEW')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "PROD_REVIEW_VIEW",
			"InteractionType_Text": "Product Review Read",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('PROD_REVIEW_VIEW')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('PROD_SHARED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('PROD_SHARED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "PROD_SHARED",
			"InteractionType_Text": "Product Shared",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('PROD_SHARED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SALES_ORDER')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SALES_ORDER')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SALES_ORDER",
			"InteractionType_Text": "Sales Order",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SALES_ORDER')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SALES_QUOTE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SALES_QUOTE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SALES_QUOTE",
			"InteractionType_Text": "Sales Quote",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SALES_QUOTE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SALES_RETURN')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SALES_RETURN')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SALES_RETURN",
			"InteractionType_Text": "Sales Return",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SALES_RETURN')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CART_ABANDONED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CART_ABANDONED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SHOP_CART_ABANDONED",
			"InteractionType_Text": "Shopping Cart Abandoned",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CART_ABANDONED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CART_SAVED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CART_SAVED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SHOP_CART_SAVED",
			"InteractionType_Text": "Saved Shopping Cart",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CART_SAVED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CART_VIEW')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CART_VIEW')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SHOP_CART_VIEW",
			"InteractionType_Text": "View Shopping Cart",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CART_VIEW')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CHECKOUT_ABNDND')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CHECKOUT_ABNDND')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SHOP_CHECKOUT_ABNDND",
			"InteractionType_Text": "Checkout Abandoned",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CHECKOUT_ABNDND')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CHECKOUT_START')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CHECKOUT_START')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SHOP_CHECKOUT_START",
			"InteractionType_Text": "Proceeded to Checkout",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CHECKOUT_START')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CHECKOUT_SUCCES')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CHECKOUT_SUCCES')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SHOP_CHECKOUT_SUCCES",
			"InteractionType_Text": "Checkout Successful",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_CHECKOUT_SUCCES')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_ITEM_ADD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_ITEM_ADD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SHOP_ITEM_ADD",
			"InteractionType_Text": "Product Added to Shopping Cart",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_ITEM_ADD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_ITEM_REMOVE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_ITEM_REMOVE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SHOP_ITEM_REMOVE",
			"InteractionType_Text": "Product Removed from Shopping Cart",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_ITEM_REMOVE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_ITEM_VIEW')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_ITEM_VIEW')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SHOP_ITEM_VIEW",
			"InteractionType_Text": "Product Viewed",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SHOP_ITEM_VIEW')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SMS_BOUNCE_HARD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SMS_BOUNCE_HARD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SMS_BOUNCE_HARD",
			"InteractionType_Text": "Hard Bounce",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SMS_BOUNCE_HARD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SMS_BOUNCE_SOFT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SMS_BOUNCE_SOFT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SMS_BOUNCE_SOFT",
			"InteractionType_Text": "Soft Bounce",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SMS_BOUNCE_SOFT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SMS_DELIVERED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SMS_DELIVERED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SMS_DELIVERED",
			"InteractionType_Text": "Outbound Text Message Delivered",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SMS_DELIVERED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SMS_FAILED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SMS_FAILED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SMS_FAILED",
			"InteractionType_Text": "Text Message Delivery Error",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SMS_FAILED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SMS_OUTBOUND')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SMS_OUTBOUND')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SMS_OUTBOUND",
			"InteractionType_Text": "Outbound Text Message",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SMS_OUTBOUND')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SOCIAL_POSTING')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SOCIAL_POSTING')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SOCIAL_POSTING",
			"InteractionType_Text": "Post in Social Media",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": true,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SOCIAL_POSTING')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SS_TRIGGER')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SS_TRIGGER')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SS_TRIGGER",
			"InteractionType_Text": "SS Trigger",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SS_TRIGGER')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SURVEY_RESPONSE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SURVEY_RESPONSE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "SURVEY_RESPONSE",
			"InteractionType_Text": "Survey Response",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": true,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('SURVEY_RESPONSE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('TASK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('TASK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "TASK",
			"InteractionType_Text": "Task",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('TASK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('TELEPHONE_INBOUND')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('TELEPHONE_INBOUND')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "TELEPHONE_INBOUND",
			"InteractionType_Text": "Incoming Telephone Call",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('TELEPHONE_INBOUND')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('TELEPHONE_OUTBOUND')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('TELEPHONE_OUTBOUND')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "TELEPHONE_OUTBOUND",
			"InteractionType_Text": "Outgoing Telephone Call",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('TELEPHONE_OUTBOUND')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('TELEPHONE_UNSUCESSFL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('TELEPHONE_UNSUCESSFL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "TELEPHONE_UNSUCESSFL",
			"InteractionType_Text": "Outgoing Telephone Call Failed",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('TELEPHONE_UNSUCESSFL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('TM_IA_TYPE_TEST')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('TM_IA_TYPE_TEST')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "TM_IA_TYPE_TEST",
			"InteractionType_Text": "Test retrieval of only active IA-Types",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": true,
			"IsTechnicalInteractionType": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('TM_IA_TYPE_TEST')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBINAR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBINAR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "WEBINAR",
			"InteractionType_Text": "Webinar",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBINAR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBSITE_DOWNLOAD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBSITE_DOWNLOAD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "WEBSITE_DOWNLOAD",
			"InteractionType_Text": "Website Download",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBSITE_DOWNLOAD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBSITE_REGISTRATION')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBSITE_REGISTRATION')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "WEBSITE_REGISTRATION",
			"InteractionType_Text": "Website Registration",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBSITE_REGISTRATION')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBSITE_SEARCH')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBSITE_SEARCH')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "WEBSITE_SEARCH",
			"InteractionType_Text": "Website Search",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBSITE_SEARCH')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBSITE_VIDEO')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBSITE_VIDEO')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "WEBSITE_VIDEO",
			"InteractionType_Text": "Website Video",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBSITE_VIDEO')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBSITE_VISIT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBSITE_VISIT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "WEBSITE_VISIT",
			"InteractionType_Text": "Website Visit",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('WEBSITE_VISIT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZPERF_TEST')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZPERF_TEST')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "ZPERF_TEST",
			"InteractionType_Text": "Performance Test",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZPERF_TEST')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZSWEIBO_COMMENT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZSWEIBO_COMMENT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "ZSWEIBO_COMMENT",
			"InteractionType_Text": "Sina Weibo Comment",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": true,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZSWEIBO_COMMENT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZSWEIBO_MENTION')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZSWEIBO_MENTION')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "ZSWEIBO_MENTION",
			"InteractionType_Text": "Sina Weibo Mention",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": true,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZSWEIBO_MENTION')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTDAILY_WEB_VISIT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTDAILY_WEB_VISIT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "ZTDAILY_WEB_VISIT",
			"InteractionType_Text": "Daily Web Visits",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTDAILY_WEB_VISIT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST1')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST1')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "ZTEST1",
			"InteractionType_Text": "Test interaction type",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST1')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST10')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST10')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "ZTEST10",
			"InteractionType_Text": "Test interaction type",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST10')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST11')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST11')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "ZTEST11",
			"InteractionType_Text": "Test interaction type",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST11')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST12')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST12')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "ZTEST12",
			"InteractionType_Text": "Test interaction type",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST12')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "ZTEST2",
			"InteractionType_Text": "Test interaction type",
			"InteractionDirection": "",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST2')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST3')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST3')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "ZTEST3",
			"InteractionType_Text": "Test interaction type",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST3')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST4')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST4')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "ZTEST4",
			"InteractionType_Text": "Test interaction type",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST4')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST5')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST5')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "ZTEST5",
			"InteractionType_Text": "Test interaction type",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST5')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST6')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST6')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "ZTEST6",
			"InteractionType_Text": "Test interaction type",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST6')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST7')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST7')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "ZTEST7",
			"InteractionType_Text": "Test interaction type",
			"InteractionDirection": "0",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST7')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "ZTEST8",
			"InteractionType_Text": "Test interaction type",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST8')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST9')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST9')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionTypeType"
			},
			"InteractionType": "ZTEST9",
			"InteractionType_Text": "Test interaction type",
			"InteractionDirection": "1",
			"IsTextAnalysisEnabled": false,
			"IsTechnicalInteractionType": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionType('ZTEST9')/to_Text"
				}
			}
		}]
	};

	var I_MKT_InteractionProductStatus = {
		"__count": "8",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('00')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('00')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionProductStatusType"
			},
			"InteractionProductStatus": "00",
			"InteractionProductStatus_Text": "New",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('00')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('01')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('01')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionProductStatusType"
			},
			"InteractionProductStatus": "01",
			"InteractionProductStatus_Text": "In Process",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('01')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('02')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('02')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionProductStatusType"
			},
			"InteractionProductStatus": "02",
			"InteractionProductStatus_Text": "Released",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('02')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('03')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('03')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionProductStatusType"
			},
			"InteractionProductStatus": "03",
			"InteractionProductStatus_Text": "Completed",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('03')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('04')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('04')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionProductStatusType"
			},
			"InteractionProductStatus": "04",
			"InteractionProductStatus_Text": "Cancelled",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('04')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('05')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('05')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionProductStatusType"
			},
			"InteractionProductStatus": "05",
			"InteractionProductStatus_Text": "Converted",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('05')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('06')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('06')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionProductStatusType"
			},
			"InteractionProductStatus": "06",
			"InteractionProductStatus_Text": "Successful",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('06')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('07')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('07')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionProductStatusType"
			},
			"InteractionProductStatus": "07",
			"InteractionProductStatus_Text": "Unsuccessful",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionProductStatus('07')/to_Text"
				}
			}
		}]
	};

	var I_UnitOfMeasure = {
		"__count": "266",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%25')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%25')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "%",
			"UnitOfMeasure_Text": "Percentage",
			"UnitOfMeasureDimension": "PROPOR",
			"UnitOfMeasureISOCode": "P1",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%25')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%25')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%25')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%25O')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%25O')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "%O",
			"UnitOfMeasure_Text": "Per mille",
			"UnitOfMeasureDimension": "PROPOR",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%25O')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%25O')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%25O')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('ONE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('ONE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "ONE",
			"UnitOfMeasure_Text": "One",
			"UnitOfMeasureDimension": "PROPOR",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('ONE')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('ONE')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('ONE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('D')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('D')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "D",
			"UnitOfMeasure_Text": "Days",
			"UnitOfMeasureDimension": "TIME",
			"UnitOfMeasureISOCode": "DAY",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('D')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('D')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('D')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('22S')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('22S')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "22S",
			"UnitOfMeasure_Text": "Square millimeter/second",
			"UnitOfMeasureDimension": "VISKIN",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('22S')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('22S')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('22S')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CMS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CMS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "CMS",
			"UnitOfMeasure_Text": "Centimeter/second",
			"UnitOfMeasureDimension": "SPEED",
			"UnitOfMeasureISOCode": "2M",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CMS')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CMS')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CMS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('000')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('000')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "000",
			"UnitOfMeasure_Text": "Meter/Minute",
			"UnitOfMeasureDimension": "SPEED",
			"UnitOfMeasureISOCode": "2X",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('000')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('000')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('000')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5L')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5L')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "ml",
			"UnitOfMeasure_Text": "Microliter",
			"UnitOfMeasureDimension": "VOLUME",
			"UnitOfMeasureISOCode": "4G",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5L')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5L')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5L')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5F')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5F')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "mF",
			"UnitOfMeasure_Text": "Microfarad",
			"UnitOfMeasureDimension": "CAPACI",
			"UnitOfMeasureISOCode": "4O",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5F')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5F')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5F')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('PF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('PF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "PF",
			"UnitOfMeasure_Text": "Pikofarad",
			"UnitOfMeasureDimension": "CAPACI",
			"UnitOfMeasureISOCode": "4T",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('PF')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('PF')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('PF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('A')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('A')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "A",
			"UnitOfMeasure_Text": "Ampere",
			"UnitOfMeasureDimension": "ECURR",
			"UnitOfMeasureISOCode": "AMP",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('A')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('A')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('A')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GOH')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GOH')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "GOH",
			"UnitOfMeasure_Text": "Gigaohm",
			"UnitOfMeasureDimension": "RESIST",
			"UnitOfMeasureISOCode": "A87",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GOH')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GOH')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GOH')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GM3')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GM3')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "GM3",
			"UnitOfMeasure_Text": "Gram/Cubic meter",
			"UnitOfMeasureDimension": "DENSI",
			"UnitOfMeasureISOCode": "A93",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GM3')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GM3')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GM3')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('ACR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('ACR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "ACR",
			"UnitOfMeasure_Text": "Acre",
			"UnitOfMeasureDimension": "SURFAC",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('ACR')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('ACR')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('ACR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KD3')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KD3')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "KD3",
			"UnitOfMeasure_Text": "Kilogram/cubic decimeter",
			"UnitOfMeasureDimension": "DENSI",
			"UnitOfMeasureISOCode": "B34",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KD3')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KD3')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KD3')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KML')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KML')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "KML",
			"UnitOfMeasure_Text": "Kilomol",
			"UnitOfMeasureDimension": "MOLQU",
			"UnitOfMeasureISOCode": "B45",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KML')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KML')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KML')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('NI')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('NI')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "NI",
			"UnitOfMeasure_Text": "Kilonewton",
			"UnitOfMeasureDimension": "FORCE",
			"UnitOfMeasureISOCode": "B47",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('NI')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('NI')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('NI')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('MN')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('MN')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "MN",
			"UnitOfMeasure_Text": "Meganewton",
			"UnitOfMeasureDimension": "FORCE",
			"UnitOfMeasureISOCode": "B73",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('MN')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('MN')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('MN')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('MGO')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('MGO')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "MGO",
			"UnitOfMeasure_Text": "Megohm",
			"UnitOfMeasureDimension": "RESIST",
			"UnitOfMeasureISOCode": "B75",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('MGO')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('MGO')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('MGO')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('MHV')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('MHV')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "MHV",
			"UnitOfMeasure_Text": "Megavolt",
			"UnitOfMeasureDimension": "VOLTAG",
			"UnitOfMeasureISOCode": "B78",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('MHV')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('MHV')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('MHV')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5A')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5A')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "mA",
			"UnitOfMeasure_Text": "Microampere",
			"UnitOfMeasureDimension": "ECURR",
			"UnitOfMeasureISOCode": "B84",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5A')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5A')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5A')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BAG')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BAG')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "BAG",
			"UnitOfMeasure_Text": "Bag",
			"UnitOfMeasureDimension": "AAAADL",
			"UnitOfMeasureISOCode": "BG",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BAG')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BAG')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BAG')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BAR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BAR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "BAR",
			"UnitOfMeasure_Text": "bar",
			"UnitOfMeasureDimension": "PRESS",
			"UnitOfMeasureISOCode": "BAR",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BAR')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BAR')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BAR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('bbl')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('bbl')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "bbl",
			"UnitOfMeasure_Text": "British Thermal Unit/US Barrel",
			"UnitOfMeasureDimension": "PRESS",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('bbl')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('bbl')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('bbl')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('bft')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('bft')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "bft",
			"UnitOfMeasure_Text": "British Thermal Unit/Cubic Ft",
			"UnitOfMeasureDimension": "PRESS",
			"UnitOfMeasureISOCode": "B0",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('bft')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('bft')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('bft')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('bgl')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('bgl')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "bgl",
			"UnitOfMeasure_Text": "British Thermal Unit/US Gallon",
			"UnitOfMeasureDimension": "PRESS",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('bgl')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('bgl')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('bgl')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "BT",
			"UnitOfMeasure_Text": "Bottle",
			"UnitOfMeasureDimension": "AAAADL",
			"UnitOfMeasureISOCode": "BO",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BT')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BT')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BQK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BQK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "BQK",
			"UnitOfMeasure_Text": "Becquerel/kilogram",
			"UnitOfMeasureDimension": "SPARAD",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BQK')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BQK')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('BQK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('btl')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('btl')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "btl",
			"UnitOfMeasure_Text": "British Thermal Unit/US Pound",
			"UnitOfMeasureDimension": "SPENER",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('btl')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('btl')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('btl')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('RF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('RF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "RF",
			"UnitOfMeasure_Text": "Millifarad",
			"UnitOfMeasureDimension": "CAPACI",
			"UnitOfMeasureISOCode": "C10",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('RF')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('RF')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('RF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('M%2FM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('M%2FM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "M/M",
			"UnitOfMeasure_Text": "Mole per Cubic Meter",
			"UnitOfMeasureDimension": "ACBAC",
			"UnitOfMeasureISOCode": "C36",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 3,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('M%2FM')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('M%2FM')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('M%2FM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('M%2FL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('M%2FL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "M/L",
			"UnitOfMeasure_Text": "Mole per Liter",
			"UnitOfMeasureDimension": "ACBAC",
			"UnitOfMeasureISOCode": "C38",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 3,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('M%2FL')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('M%2FL')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('M%2FL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('NA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('NA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "NA",
			"UnitOfMeasure_Text": "Nanoampere",
			"UnitOfMeasureDimension": "ECURR",
			"UnitOfMeasureISOCode": "C39",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('NA')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('NA')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('NA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('C3S')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('C3S')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "C3S",
			"UnitOfMeasure_Text": "Cubic centimeter/second",
			"UnitOfMeasureDimension": "VOLFLO",
			"UnitOfMeasureISOCode": "2J",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('C3S')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('C3S')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('C3S')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('R-U')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('R-U')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "R-U",
			"UnitOfMeasure_Text": "Nanofarad",
			"UnitOfMeasureDimension": "CAPACI",
			"UnitOfMeasureISOCode": "C41",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('R-U')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('R-U')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('R-U')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('NMM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('NMM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "NMM",
			"UnitOfMeasure_Text": "Newton/Square millimeter",
			"UnitOfMeasureDimension": "PRESS",
			"UnitOfMeasureISOCode": "C56",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('NMM')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('NMM')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('NMM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CCM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CCM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "CCM",
			"UnitOfMeasure_Text": "Cubic centimeter",
			"UnitOfMeasureDimension": "VOLUME",
			"UnitOfMeasureISOCode": "CMQ",
			"UnitOfMeasureNumberOfDecimals": 3,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CCM')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CCM')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CCM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "CD",
			"UnitOfMeasure_Text": "Candela",
			"UnitOfMeasureDimension": "LIGHT",
			"UnitOfMeasureISOCode": "CDL",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CD')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CD')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CD3')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CD3')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "CD3",
			"UnitOfMeasure_Text": "Cubic decimeter",
			"UnitOfMeasureDimension": "VOLUME",
			"UnitOfMeasureISOCode": "DMQ",
			"UnitOfMeasureNumberOfDecimals": 3,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CD3')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CD3')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CD3')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "CM",
			"UnitOfMeasure_Text": "Centimeter",
			"UnitOfMeasureDimension": "LENGTH",
			"UnitOfMeasureISOCode": "CMT",
			"UnitOfMeasureNumberOfDecimals": 3,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CM')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CM')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CM2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CM2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "CM2",
			"UnitOfMeasure_Text": "Square centimeter",
			"UnitOfMeasureDimension": "SURFAC",
			"UnitOfMeasureISOCode": "CMK",
			"UnitOfMeasureNumberOfDecimals": 3,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CM2')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CM2')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CM2')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CMH')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CMH')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "CMH",
			"UnitOfMeasure_Text": "Centimeter/hour",
			"UnitOfMeasureDimension": "SPEED",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CMH')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CMH')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CMH')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CV')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CV')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "CV",
			"UnitOfMeasure_Text": "Case",
			"UnitOfMeasureDimension": "AAAADL",
			"UnitOfMeasureISOCode": "CS",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CV')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CV')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CV')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "CL",
			"UnitOfMeasure_Text": "Centiliter",
			"UnitOfMeasureDimension": "VOLUME",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CL')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CL')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('S%2FM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('S%2FM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "S/M",
			"UnitOfMeasure_Text": "Siemens per meter",
			"UnitOfMeasureDimension": "CONDUC",
			"UnitOfMeasureISOCode": "D10",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 3,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('S%2FM')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('S%2FM')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('S%2FM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('TOM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('TOM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "TOM",
			"UnitOfMeasure_Text": "Ton/Cubic meter",
			"UnitOfMeasureDimension": "DENSI",
			"UnitOfMeasureISOCode": "D41",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('TOM')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('TOM')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('TOM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('VAM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('VAM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "VAM",
			"UnitOfMeasure_Text": "Voltampere",
			"UnitOfMeasureDimension": "POWER",
			"UnitOfMeasureISOCode": "D46",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('VAM')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('VAM')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('VAM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DEG')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DEG')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "DEG",
			"UnitOfMeasure_Text": "Degree",
			"UnitOfMeasureDimension": "AAAADL",
			"UnitOfMeasureISOCode": "DD",
			"UnitOfMeasureNumberOfDecimals": 99,
			"UnitOfMeasureDspNmbrOfDcmls": 1,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DEG')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DEG')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DEG')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "DM",
			"UnitOfMeasure_Text": "Decimeter",
			"UnitOfMeasureDimension": "LENGTH",
			"UnitOfMeasureISOCode": "DMT",
			"UnitOfMeasureNumberOfDecimals": 3,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DM')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DM')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "DR",
			"UnitOfMeasure_Text": "Drum",
			"UnitOfMeasureDimension": "AAAADL",
			"UnitOfMeasureISOCode": "DR",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DR')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DR')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DZ')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DZ')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "DZ",
			"UnitOfMeasure_Text": "Dozen",
			"UnitOfMeasureDimension": "AAAADL",
			"UnitOfMeasureISOCode": "DZN",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DZ')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DZ')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('DZ')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('EA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('EA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "EA",
			"UnitOfMeasure_Text": "each",
			"UnitOfMeasureDimension": "AAAADL",
			"UnitOfMeasureISOCode": "EA",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('EA')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('EA')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('EA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('EU')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('EU')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "EU",
			"UnitOfMeasure_Text": "Enzyme Units",
			"UnitOfMeasureDimension": "AAAADL",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('EU')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('EU')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('EU')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('EML')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('EML')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "EML",
			"UnitOfMeasure_Text": "Enzyme Units/Milliliter",
			"UnitOfMeasureDimension": "AAAADL",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('EML')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('EML')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('EML')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('F')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('F')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "F",
			"UnitOfMeasure_Text": "Farad",
			"UnitOfMeasureDimension": "CAPACI",
			"UnitOfMeasureISOCode": "FAR",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('F')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('F')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('F')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B0F')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B0F')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "F",
			"UnitOfMeasure_Text": "Fahrenheit",
			"UnitOfMeasureDimension": "TEMP",
			"UnitOfMeasureISOCode": "FAH",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B0F')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B0F')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B0F')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('FT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('FT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "FT",
			"UnitOfMeasure_Text": "Foot",
			"UnitOfMeasureDimension": "LENGTH",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('FT')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('FT')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('FT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('FT2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('FT2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "FT2",
			"UnitOfMeasure_Text": "Square foot",
			"UnitOfMeasureDimension": "SURFAC",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('FT2')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('FT2')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('FT2')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('FT3')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('FT3')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "FT3",
			"UnitOfMeasure_Text": "Cubic foot",
			"UnitOfMeasureDimension": "VOLUME",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('FT3')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('FT3')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('FT3')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('G')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('G')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "G",
			"UnitOfMeasure_Text": "Gram",
			"UnitOfMeasureDimension": "MASS",
			"UnitOfMeasureISOCode": "GRM",
			"UnitOfMeasureNumberOfDecimals": 3,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('G')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('G')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('G')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('G%2FL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('G%2FL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "G/L",
			"UnitOfMeasure_Text": "Gram Active Ingredient/Liter",
			"UnitOfMeasureDimension": "AAAADL",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('G%2FL')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('G%2FL')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('G%2FL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GAU')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GAU')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "GAU",
			"UnitOfMeasure_Text": "Gram Gold",
			"UnitOfMeasureDimension": "AAAADL",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 99,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GAU')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GAU')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GAU')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B0C')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B0C')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "C",
			"UnitOfMeasure_Text": "Degrees Celsius",
			"UnitOfMeasureDimension": "TEMP",
			"UnitOfMeasureISOCode": "CEL",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B0C')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B0C')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B0C')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GHG')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GHG')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "GHG",
			"UnitOfMeasure_Text": "Gram/hectogram",
			"UnitOfMeasureDimension": "MPROPO",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GHG')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GHG')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GHG')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GJ')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GJ')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "GJ",
			"UnitOfMeasure_Text": "Gigajoule",
			"UnitOfMeasureDimension": "ENERGY",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GJ')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GJ')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GJ')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('gj3')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('gj3')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "gj3",
			"UnitOfMeasure_Text": "Gigajoule/1000 Cubic Meters",
			"UnitOfMeasureDimension": "PRESS",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('gj3')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('gj3')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('gj3')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('gjm')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('gjm')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "gjm",
			"UnitOfMeasure_Text": "Gigajoule/Cubic Meter",
			"UnitOfMeasureDimension": "PRESS",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('gjm')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('gjm')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('gjm')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('gjt')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('gjt')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "gjt",
			"UnitOfMeasure_Text": "Gigajoule/US Ton",
			"UnitOfMeasureDimension": "SPENER",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('gjt')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('gjt')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('gjt')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GKG')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GKG')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "GKG",
			"UnitOfMeasure_Text": "Gram/kilogram",
			"UnitOfMeasureDimension": "MPROPO",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GKG')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GKG')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GKG')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GLI')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GLI')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "GLI",
			"UnitOfMeasure_Text": "Gram/liter",
			"UnitOfMeasureDimension": "DENSI",
			"UnitOfMeasureISOCode": "GL",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GLI')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GLI')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GLI')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GAL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GAL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "GAL",
			"UnitOfMeasure_Text": "US gallon",
			"UnitOfMeasureDimension": "VOLUME",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GAL')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GAL')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GAL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GPM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GPM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "GPM",
			"UnitOfMeasure_Text": "Gallons per mile (US)",
			"UnitOfMeasureDimension": "SURFAC",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 3,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GPM')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GPM')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GPM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "GM",
			"UnitOfMeasure_Text": "Gram/Mole",
			"UnitOfMeasureDimension": "MOLMAS",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GM')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GM')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GM2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GM2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "GM2",
			"UnitOfMeasure_Text": "Gram/square meter",
			"UnitOfMeasureDimension": "MASSBD",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GM2')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GM2')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GM2')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GPH')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GPH')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "GPH",
			"UnitOfMeasure_Text": "Gallons per hour (US)",
			"UnitOfMeasureDimension": "VOLFLO",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 3,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GPH')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GPH')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GPH')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5GQ')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5GQ')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "mGQ",
			"UnitOfMeasure_Text": "Microgram/cubic meter",
			"UnitOfMeasureDimension": "DENSI",
			"UnitOfMeasureISOCode": "GQ",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5GQ')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5GQ')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%C2%B5GQ')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GRO')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GRO')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "GRO",
			"UnitOfMeasure_Text": "Gross",
			"UnitOfMeasureDimension": "AAAADL",
			"UnitOfMeasureISOCode": "GRO",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GRO')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GRO')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GRO')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GAI')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GAI')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "GAI",
			"UnitOfMeasure_Text": "Gram Active Ingredient",
			"UnitOfMeasureDimension": "AAAADL",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GAI')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GAI')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('GAI')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('H')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('H')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "H",
			"UnitOfMeasure_Text": "Hour",
			"UnitOfMeasureDimension": "TIME",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 3,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('H')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('H')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('H')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "HA",
			"UnitOfMeasure_Text": "Hectare",
			"UnitOfMeasureDimension": "SURFAC",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HA')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HA')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "HL",
			"UnitOfMeasure_Text": "Hectoliter",
			"UnitOfMeasureDimension": "VOLUME",
			"UnitOfMeasureISOCode": "HLT",
			"UnitOfMeasureNumberOfDecimals": 3,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HL')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HL')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HPA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HPA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "HPA",
			"UnitOfMeasure_Text": "Hectopascal",
			"UnitOfMeasureDimension": "PRESS",
			"UnitOfMeasureISOCode": "A97",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HPA')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HPA')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HPA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HZ')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HZ')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "HZ",
			"UnitOfMeasure_Text": "Hertz (1/second)",
			"UnitOfMeasureDimension": "FREQU",
			"UnitOfMeasureISOCode": "HTZ",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HZ')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HZ')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('HZ')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%22')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%22')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "\"",
			"UnitOfMeasure_Text": "Inch",
			"UnitOfMeasureDimension": "LENGTH",
			"UnitOfMeasureISOCode": "INH",
			"UnitOfMeasureNumberOfDecimals": 3,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%22')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%22')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%22')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%222')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%222')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "\"2",
			"UnitOfMeasure_Text": "Square inch",
			"UnitOfMeasureDimension": "SURFAC",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%222')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%222')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%222')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%223')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%223')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "\"3",
			"UnitOfMeasure_Text": "Cubic inch",
			"UnitOfMeasureDimension": "VOLUME",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%223')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%223')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('%223')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('J')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('J')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "J",
			"UnitOfMeasure_Text": "Joule",
			"UnitOfMeasureDimension": "ENERGY",
			"UnitOfMeasureISOCode": "JOU",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('J')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('J')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('J')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('YR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('YR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "YR",
			"UnitOfMeasure_Text": "Years",
			"UnitOfMeasureDimension": "TIME",
			"UnitOfMeasureISOCode": "ANN",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('YR')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('YR')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('YR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('JKG')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('JKG')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "JKG",
			"UnitOfMeasure_Text": "Joule/Kilogram",
			"UnitOfMeasureDimension": "SPENER",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('JKG')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('JKG')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('JKG')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('JKK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('JKK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "JKK",
			"UnitOfMeasure_Text": "Spec. Heat Capacity",
			"UnitOfMeasureDimension": "SPHCAP",
			"UnitOfMeasureISOCode": "B11",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('JKK')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('JKK')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('JKK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('jm3')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('jm3')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "jm3",
			"UnitOfMeasure_Text": "Joule/Cubic Meter",
			"UnitOfMeasureDimension": "PRESS",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('jm3')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('jm3')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('jm3')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('JMO')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('JMO')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "JMO",
			"UnitOfMeasure_Text": "Joule/Mole",
			"UnitOfMeasureDimension": "MOENER",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('JMO')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('JMO')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('JMO')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('K')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('K')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "K",
			"UnitOfMeasure_Text": "Kelvin",
			"UnitOfMeasureDimension": "TEMP",
			"UnitOfMeasureISOCode": "KEL",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('K')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('K')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('K')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "KA",
			"UnitOfMeasure_Text": "Kiloampere",
			"UnitOfMeasureDimension": "ECURR",
			"UnitOfMeasureISOCode": "B22",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KA')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KA')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CAN')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CAN')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "CAN",
			"UnitOfMeasure_Text": "Canister",
			"UnitOfMeasureDimension": "AAAADL",
			"UnitOfMeasureISOCode": "CA",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CAN')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CAN')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CAN')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CAR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CAR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "CAR",
			"UnitOfMeasure_Text": "Carton",
			"UnitOfMeasureDimension": "AAAADL",
			"UnitOfMeasureISOCode": "CT",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CAR')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CAR')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('CAR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KBK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KBK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "KBK",
			"UnitOfMeasure_Text": "Kilobecquerel/Kilogram",
			"UnitOfMeasureDimension": "SPARAD",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KBK')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KBK')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KBK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KG')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KG')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "KG",
			"UnitOfMeasure_Text": "Kilogram",
			"UnitOfMeasureDimension": "MASS",
			"UnitOfMeasureISOCode": "KGM",
			"UnitOfMeasureNumberOfDecimals": 3,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KG')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KG')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KG')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgb')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgb')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "kgb",
			"UnitOfMeasure_Text": "Kilogram/US Barrel",
			"UnitOfMeasureDimension": "DENSI",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgb')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgb')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgb')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "KGF",
			"UnitOfMeasure_Text": "Kilogram/Square meter",
			"UnitOfMeasureDimension": "MASSBD",
			"UnitOfMeasureISOCode": "28",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGF')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGF')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgj')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgj')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "kgj",
			"UnitOfMeasure_Text": "Kilogram/Joule",
			"UnitOfMeasureDimension": "MAPER",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgj')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgj')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgj')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "KGK",
			"UnitOfMeasure_Text": "Kilogram/Kilogram",
			"UnitOfMeasureDimension": "MPROPO",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGK')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGK')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "KGM",
			"UnitOfMeasure_Text": "Kilogram/Mole",
			"UnitOfMeasureDimension": "MOLMAS",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGM')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGM')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgm')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgm')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "kgm",
			"UnitOfMeasure_Text": "Kilogram/Million BTU",
			"UnitOfMeasureDimension": "MAPER",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgm')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgm')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgm')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "KGS",
			"UnitOfMeasure_Text": "Kilogram/second",
			"UnitOfMeasureDimension": "MASFLO",
			"UnitOfMeasureISOCode": "KGS",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGS')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGS')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgs')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgs')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "kgs",
			"UnitOfMeasure_Text": "Kilogram/Standard Cubic Foot",
			"UnitOfMeasureDimension": "DENSI",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgs')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgs')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgs')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgt')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgt')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "kgt",
			"UnitOfMeasure_Text": "Kilogram/US Ton",
			"UnitOfMeasureDimension": "MPROPO",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgt')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgt')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('kgt')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGV')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGV')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "KGV",
			"UnitOfMeasure_Text": "Kilogram/cubic meter",
			"UnitOfMeasureDimension": "DENSI",
			"UnitOfMeasureISOCode": "KMQ",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGV')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGV')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KGV')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KAI')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KAI')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "KAI",
			"UnitOfMeasure_Text": "Kilogram Active Ingredient",
			"UnitOfMeasureDimension": "AAAADL",
			"UnitOfMeasureISOCode": "",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KAI')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KAI')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KAI')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KHZ')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KHZ')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_UnitOfMeasureType"
			},
			"UnitOfMeasure": "KHZ",
			"UnitOfMeasure_Text": "Kilohertz",
			"UnitOfMeasureDimension": "FREQU",
			"UnitOfMeasureISOCode": "KHZ",
			"UnitOfMeasureNumberOfDecimals": 0,
			"UnitOfMeasureDspNmbrOfDcmls": 0,
			"to_Dimension": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KHZ')/to_Dimension"
				}
			},
			"to_DimensionText": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KHZ')/to_DimensionText"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_UnitOfMeasure('KHZ')/to_Text"
				}
			}
		}]
	};

	var I_MKT_LocationOrigin = {
		"__count": "9",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('QI5CLNT800')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('QI5CLNT800')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_LocationOriginType"
			},
			"MarketingLocationOrigin": "QI5CLNT800",
			"MarketingLocationOrigin_Text": "QI5CLNT800",
			"IsDisabled": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('QI5CLNT800')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('QI5CLNT805')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('QI5CLNT805')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_LocationOriginType"
			},
			"MarketingLocationOrigin": "QI5CLNT805",
			"MarketingLocationOrigin_Text": "QI5CLNT805",
			"IsDisabled": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('QI5CLNT805')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('RD1CLNT800')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('RD1CLNT800')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_LocationOriginType"
			},
			"MarketingLocationOrigin": "RD1CLNT800",
			"MarketingLocationOrigin_Text": "RD1CLNT800",
			"IsDisabled": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('RD1CLNT800')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('RD2CLNT405')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('RD2CLNT405')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_LocationOriginType"
			},
			"MarketingLocationOrigin": "RD2CLNT405",
			"MarketingLocationOrigin_Text": "RD2CLNT405",
			"IsDisabled": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('RD2CLNT405')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('SAP_ERP_PLANT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('SAP_ERP_PLANT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_LocationOriginType"
			},
			"MarketingLocationOrigin": "SAP_ERP_PLANT",
			"MarketingLocationOrigin_Text": "SAP ERP Plant",
			"IsDisabled": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('SAP_ERP_PLANT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('SAP_HYBRIS_COMMERCE_POS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('SAP_HYBRIS_COMMERCE_POS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_LocationOriginType"
			},
			"MarketingLocationOrigin": "SAP_HYBRIS_COMMERCE_POS",
			"MarketingLocationOrigin_Text": "SAP Commerce Cloud Point of Service",
			"IsDisabled": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('SAP_HYBRIS_COMMERCE_POS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('SAP_MANUAL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('SAP_MANUAL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_LocationOriginType"
			},
			"MarketingLocationOrigin": "SAP_MANUAL",
			"MarketingLocationOrigin_Text": "SAP Manually Created Marketing Location",
			"IsDisabled": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('SAP_MANUAL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('SAP_RETAIL_STORE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('SAP_RETAIL_STORE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_LocationOriginType"
			},
			"MarketingLocationOrigin": "SAP_RETAIL_STORE",
			"MarketingLocationOrigin_Text": "SAP Retail Store",
			"IsDisabled": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('SAP_RETAIL_STORE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('WECHAT_POI')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('WECHAT_POI')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_LocationOriginType"
			},
			"MarketingLocationOrigin": "WECHAT_POI",
			"MarketingLocationOrigin_Text": "WeChat Point of Interest",
			"IsDisabled": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_LocationOrigin('WECHAT_POI')/to_Text"
				}
			}
		}]
	};

	var I_MKT_InteractionStatus = {
		"__count": "8",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('00')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('00')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionStatusType"
			},
			"InteractionStatus": "00",
			"InteractionStatus_Text": "New",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('00')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('01')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('01')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionStatusType"
			},
			"InteractionStatus": "01",
			"InteractionStatus_Text": "In Process",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('01')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('02')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('02')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionStatusType"
			},
			"InteractionStatus": "02",
			"InteractionStatus_Text": "Released",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('02')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('03')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('03')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionStatusType"
			},
			"InteractionStatus": "03",
			"InteractionStatus_Text": "Completed",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('03')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('04')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('04')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionStatusType"
			},
			"InteractionStatus": "04",
			"InteractionStatus_Text": "Cancelled",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('04')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('05')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('05')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionStatusType"
			},
			"InteractionStatus": "05",
			"InteractionStatus_Text": "Converted",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('05')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('06')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('06')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionStatusType"
			},
			"InteractionStatus": "06",
			"InteractionStatus_Text": "Successful",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('06')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('07')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('07')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionStatusType"
			},
			"InteractionStatus": "07",
			"InteractionStatus_Text": "Unsuccessful",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionStatus('07')/to_Text"
				}
			}
		}]
	};

	var I_MKT_InteractionSentiment = {
		"__count": "6",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('0')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('0')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionSentimentType"
			},
			"InteractionSentiment": "0",
			"InteractionSentiment_Text": "No Valuation",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('0')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('1')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('1')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionSentimentType"
			},
			"InteractionSentiment": "1",
			"InteractionSentiment_Text": "Strong Negative",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('1')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionSentimentType"
			},
			"InteractionSentiment": "2",
			"InteractionSentiment_Text": "Weak Negative",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('2')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('3')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('3')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionSentimentType"
			},
			"InteractionSentiment": "3",
			"InteractionSentiment_Text": "Neutral",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('3')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('4')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('4')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionSentimentType"
			},
			"InteractionSentiment": "4",
			"InteractionSentiment_Text": "Weak Positive",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('4')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('5')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('5')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_InteractionSentimentType"
			},
			"InteractionSentiment": "5",
			"InteractionSentiment_Text": "Strong Positive",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_InteractionSentiment('5')/to_Text"
				}
			}
		}]
	};

	//no interactionReason. Not working correctly

	var I_MKT_DigitalAccountType = {
		"__count": "7",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_DigitalAccountTypeType"
			},
			"DigitalAccountType": "",
			"DigitalAccountType_Text": "",
			"CommunicationMedium": "",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('LINE_BOT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('LINE_BOT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_DigitalAccountTypeType"
			},
			"DigitalAccountType": "LINE_BOT",
			"DigitalAccountType_Text": "LINE@ Account",
			"CommunicationMedium": "LINE",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('LINE_BOT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('LINE_OFC')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('LINE_OFC')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_DigitalAccountTypeType"
			},
			"DigitalAccountType": "LINE_OFC",
			"DigitalAccountType_Text": "LINE Official Account",
			"CommunicationMedium": "LINE",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('LINE_OFC')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('TW')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('TW')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_DigitalAccountTypeType"
			},
			"DigitalAccountType": "TW",
			"DigitalAccountType_Text": "tw",
			"CommunicationMedium": "TW",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('TW')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('WEC_SERACC')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('WEC_SERACC')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_DigitalAccountTypeType"
			},
			"DigitalAccountType": "WEC_SERACC",
			"DigitalAccountType_Text": "WeChat Service Account",
			"CommunicationMedium": "WEC",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('WEC_SERACC')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('WEC_SUBACC')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('WEC_SUBACC')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_DigitalAccountTypeType"
			},
			"DigitalAccountType": "WEC_SUBACC",
			"DigitalAccountType_Text": "WeChat Subscription Account",
			"CommunicationMedium": "WEC",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('WEC_SUBACC')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('ZSWEIBO')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('ZSWEIBO')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_DigitalAccountTypeType"
			},
			"DigitalAccountType": "ZSWEIBO",
			"DigitalAccountType_Text": "Sina Weibo Account",
			"CommunicationMedium": "ZSWEIBO",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_DigitalAccountType('ZSWEIBO')/to_Text"
				}
			}
		}]
	};

	var I_MKT_AgreementOrigin = {
		"__count": "4",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_AgreementOrigin('1')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_AgreementOrigin('1')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_AgreementOriginType"
			},
			"MKT_AgreementOrigin": "1",
			"MKT_AgreementOrigin_Text": "Contract System",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_AgreementOrigin('1')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_AgreementOrigin('2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_AgreementOrigin('2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_AgreementOriginType"
			},
			"MKT_AgreementOrigin": "2",
			"MKT_AgreementOrigin_Text": "Agreements: CRM system; customer interactions",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_AgreementOrigin('2')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_AgreementOrigin('JMETERCRU')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_AgreementOrigin('JMETERCRU')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_AgreementOriginType"
			},
			"MKT_AgreementOrigin": "JMETERCRU",
			"MKT_AgreementOrigin_Text": "Agreements created by jMeter tests",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_AgreementOrigin('JMETERCRU')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_AgreementOrigin('JMETERCRU_ADDL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_AgreementOrigin('JMETERCRU_ADDL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_AgreementOriginType"
			},
			"MKT_AgreementOrigin": "JMETERCRU_ADDL",
			"MKT_AgreementOrigin_Text": "Agreements created by jMeter tests",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_AgreementOrigin('JMETERCRU_ADDL')/to_Text"
				}
			}
		}]
	};

	var I_Language = {
		"__count": "47",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('SR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('SR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "SR",
			"Language_Text": "Serbian",
			"LanguageISOCode": "SR",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('SR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('ZH')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('ZH')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "ZH",
			"Language_Text": "Chinese",
			"LanguageISOCode": "ZH",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('ZH')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('TH')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('TH')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "TH",
			"Language_Text": "Thai",
			"LanguageISOCode": "TH",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('TH')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('KO')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('KO')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "KO",
			"Language_Text": "Korean",
			"LanguageISOCode": "KO",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('KO')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('RO')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('RO')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "RO",
			"Language_Text": "Romanian",
			"LanguageISOCode": "RO",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('RO')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('SL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('SL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "SL",
			"Language_Text": "Slovenian",
			"LanguageISOCode": "SL",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('SL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('HR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('HR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "HR",
			"Language_Text": "Croatian",
			"LanguageISOCode": "HR",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('HR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('MS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('MS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "MS",
			"Language_Text": "Malay",
			"LanguageISOCode": "MS",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('MS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('UK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('UK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "UK",
			"Language_Text": "Ukrainian",
			"LanguageISOCode": "UK",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('UK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('ET')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('ET')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "ET",
			"Language_Text": "Estonian",
			"LanguageISOCode": "ET",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('ET')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('AR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('AR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "AR",
			"Language_Text": "Arabic",
			"LanguageISOCode": "AR",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('AR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('AF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('AF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "AF",
			"Language_Text": "Afrikaans",
			"LanguageISOCode": "AF",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('AF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('HE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('HE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "HE",
			"Language_Text": "Hebrew",
			"LanguageISOCode": "HE",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('HE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('IS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('IS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "IS",
			"Language_Text": "Icelandic",
			"LanguageISOCode": "IS",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('IS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('CS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('CS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "CS",
			"Language_Text": "Czech",
			"LanguageISOCode": "CS",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('CS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('CA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('CA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "CA",
			"Language_Text": "Catalan",
			"LanguageISOCode": "CA",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('CA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('DE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('DE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "DE",
			"Language_Text": "German",
			"LanguageISOCode": "DE",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('DE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('SH')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('SH')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "SH",
			"Language_Text": "Serbian (Latin)",
			"LanguageISOCode": "SH",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('SH')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('EN')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('EN')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "EN",
			"Language_Text": "English",
			"LanguageISOCode": "EN",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('EN')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('FR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('FR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "FR",
			"Language_Text": "French",
			"LanguageISOCode": "FR",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('FR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('EL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('EL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "EL",
			"Language_Text": "Greek",
			"LanguageISOCode": "EL",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('EL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('HU')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('HU')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "HU",
			"Language_Text": "Hungarian",
			"LanguageISOCode": "HU",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('HU')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('IT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('IT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "IT",
			"Language_Text": "Italian",
			"LanguageISOCode": "IT",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('IT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('ID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('ID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "ID",
			"Language_Text": "Indonesian",
			"LanguageISOCode": "ID",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('ID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('JA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('JA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "JA",
			"Language_Text": "Japanese",
			"LanguageISOCode": "JA",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('JA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('DA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('DA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "DA",
			"Language_Text": "Danish",
			"LanguageISOCode": "DA",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('DA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('PL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('PL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "PL",
			"Language_Text": "Polish",
			"LanguageISOCode": "PL",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('PL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('ZF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('ZF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "ZF",
			"Language_Text": "Chinese trad.",
			"LanguageISOCode": "ZF",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('ZF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('NL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('NL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "NL",
			"Language_Text": "Dutch",
			"LanguageISOCode": "NL",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('NL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('NO')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('NO')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "NO",
			"Language_Text": "Norwegian",
			"LanguageISOCode": "NO",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('NO')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('PT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('PT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "PT",
			"Language_Text": "Portuguese",
			"LanguageISOCode": "PT",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('PT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('SK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('SK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "SK",
			"Language_Text": "Slovak",
			"LanguageISOCode": "SK",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('SK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('RU')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('RU')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "RU",
			"Language_Text": "Russian",
			"LanguageISOCode": "RU",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('RU')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('ES')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('ES')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "ES",
			"Language_Text": "Spanish",
			"LanguageISOCode": "ES",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('ES')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('TR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('TR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "TR",
			"Language_Text": "Turkish",
			"LanguageISOCode": "TR",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('TR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('FI')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('FI')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "FI",
			"Language_Text": "Finnish",
			"LanguageISOCode": "FI",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('FI')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('SV')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('SV')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "SV",
			"Language_Text": "Swedish",
			"LanguageISOCode": "SV",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('SV')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('BG')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('BG')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "BG",
			"Language_Text": "Bulgarian",
			"LanguageISOCode": "BG",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('BG')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('LT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('LT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "LT",
			"Language_Text": "Lithuanian",
			"LanguageISOCode": "LT",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('LT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('LV')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('LV')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "LV",
			"Language_Text": "Latvian",
			"LanguageISOCode": "LV",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('LV')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('Z1')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('Z1')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "Z1",
			"Language_Text": "Customer reserve",
			"LanguageISOCode": "Z1",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('Z1')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('1Q')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('1Q')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "1Q",
			"Language_Text": "Technical code 1",
			"LanguageISOCode": "1Q",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('1Q')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('2Q')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('2Q')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "2Q",
			"Language_Text": "Technical code 2",
			"LanguageISOCode": "2Q",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('2Q')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('AB')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('AB')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "AB",
			"Language_Text": "Abkhazian",
			"LanguageISOCode": "AB",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('AB')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('HI')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('HI')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "HI",
			"Language_Text": "Hindi",
			"LanguageISOCode": "HI",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('HI')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('KK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('KK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "KK",
			"Language_Text": "Kazakh",
			"LanguageISOCode": "KK",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('KK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('VI')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('VI')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_LanguageType"
			},
			"Language": "VI",
			"Language_Text": "Vietnamese",
			"LanguageISOCode": "VI",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Language('VI')/to_Text"
				}
			}
		}]
	};

	var I_Currency = {
		"__count": "210",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ADP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ADP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "ADP",
			"Currency_Text": "Andorran Peseta --> (Old --> EUR)",
			"Decimals": 0,
			"CurrencyISOCode": "ADP",
			"AlternativeCurrencyKey": "020",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ADP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AED')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AED')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "AED",
			"Currency_Text": "United Arab Emirates Dirham",
			"Decimals": 2,
			"CurrencyISOCode": "AED",
			"AlternativeCurrencyKey": "784",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AED')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AFA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AFA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "AFA",
			"Currency_Text": "Afghani (Old)",
			"Decimals": 0,
			"CurrencyISOCode": "AFA",
			"AlternativeCurrencyKey": "004",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AFA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AFN')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AFN')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "AFN",
			"Currency_Text": "Afghani",
			"Decimals": 2,
			"CurrencyISOCode": "AFN",
			"AlternativeCurrencyKey": "971",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AFN')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ALL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ALL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "ALL",
			"Currency_Text": "Albanian Lek",
			"Decimals": 2,
			"CurrencyISOCode": "ALL",
			"AlternativeCurrencyKey": "008",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ALL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AMD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AMD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "AMD",
			"Currency_Text": "Armenian Dram",
			"Decimals": 2,
			"CurrencyISOCode": "AMD",
			"AlternativeCurrencyKey": "051",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AMD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ANG')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ANG')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "ANG",
			"Currency_Text": "West Indian Guilder",
			"Decimals": 2,
			"CurrencyISOCode": "ANG",
			"AlternativeCurrencyKey": "532",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ANG')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AOA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AOA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "AOA",
			"Currency_Text": "Angolanische Kwanza",
			"Decimals": 2,
			"CurrencyISOCode": "AOA",
			"AlternativeCurrencyKey": "973",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AOA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AON')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AON')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "AON",
			"Currency_Text": "Angolan New Kwanza (Old)",
			"Decimals": 2,
			"CurrencyISOCode": "AON",
			"AlternativeCurrencyKey": "024",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AON')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AOR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AOR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "AOR",
			"Currency_Text": "Angolan Kwanza Reajustado (Old)",
			"Decimals": 2,
			"CurrencyISOCode": "AOR",
			"AlternativeCurrencyKey": "982",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AOR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ARS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ARS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "ARS",
			"Currency_Text": "Argentine Peso",
			"Decimals": 2,
			"CurrencyISOCode": "ARS",
			"AlternativeCurrencyKey": "032",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ARS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ATS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ATS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "ATS",
			"Currency_Text": "Austrian Schilling (Old --> EUR)",
			"Decimals": 2,
			"CurrencyISOCode": "ATS",
			"AlternativeCurrencyKey": "040",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ATS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AUD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AUD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "AUD",
			"Currency_Text": "Australian Dollar",
			"Decimals": 2,
			"CurrencyISOCode": "AUD",
			"AlternativeCurrencyKey": "036",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AUD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AWG')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AWG')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "AWG",
			"Currency_Text": "Aruban Florin",
			"Decimals": 2,
			"CurrencyISOCode": "AWG",
			"AlternativeCurrencyKey": "533",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AWG')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AZM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AZM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "AZM",
			"Currency_Text": "Azerbaijani Manat (Old)",
			"Decimals": 2,
			"CurrencyISOCode": "AZM",
			"AlternativeCurrencyKey": "031",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AZM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AZN')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AZN')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "AZN",
			"Currency_Text": "Azerbaijani Manat",
			"Decimals": 2,
			"CurrencyISOCode": "AZN",
			"AlternativeCurrencyKey": "944",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('AZN')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BAM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BAM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BAM",
			"Currency_Text": "Bosnia and Herzegovina Convertible Mark",
			"Decimals": 2,
			"CurrencyISOCode": "BAM",
			"AlternativeCurrencyKey": "977",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BAM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BBD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BBD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BBD",
			"Currency_Text": "Barbados Dollar",
			"Decimals": 2,
			"CurrencyISOCode": "BBD",
			"AlternativeCurrencyKey": "052",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BBD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BDT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BDT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BDT",
			"Currency_Text": "Bangladesh Taka",
			"Decimals": 2,
			"CurrencyISOCode": "BDT",
			"AlternativeCurrencyKey": "050",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BDT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BEF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BEF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BEF",
			"Currency_Text": "Belgian Franc (Old --> EUR)",
			"Decimals": 0,
			"CurrencyISOCode": "BEF",
			"AlternativeCurrencyKey": "056",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BEF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BGN')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BGN')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BGN",
			"Currency_Text": "Bulgarian Lev",
			"Decimals": 2,
			"CurrencyISOCode": "BGN",
			"AlternativeCurrencyKey": "975",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BGN')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BHD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BHD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BHD",
			"Currency_Text": "Bahraini Dinar",
			"Decimals": 4,
			"CurrencyISOCode": "BHD",
			"AlternativeCurrencyKey": "048",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BHD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BIF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BIF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BIF",
			"Currency_Text": "Burundi Franc",
			"Decimals": 0,
			"CurrencyISOCode": "BIF",
			"AlternativeCurrencyKey": "108",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BIF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BMD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BMD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BMD",
			"Currency_Text": "Bermudan Dollar",
			"Decimals": 2,
			"CurrencyISOCode": "BMD",
			"AlternativeCurrencyKey": "060",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BMD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BND')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BND')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BND",
			"Currency_Text": "Brunei Dollar",
			"Decimals": 2,
			"CurrencyISOCode": "BND",
			"AlternativeCurrencyKey": "096",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BND')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BOB')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BOB')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BOB",
			"Currency_Text": "Boliviano",
			"Decimals": 2,
			"CurrencyISOCode": "BOB",
			"AlternativeCurrencyKey": "068",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BOB')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BRL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BRL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BRL",
			"Currency_Text": "Brazilian Real",
			"Decimals": 2,
			"CurrencyISOCode": "BRL",
			"AlternativeCurrencyKey": "986",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BRL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BSD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BSD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BSD",
			"Currency_Text": "Bahaman Dollar",
			"Decimals": 2,
			"CurrencyISOCode": "BSD",
			"AlternativeCurrencyKey": "044",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BSD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BTN')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BTN')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BTN",
			"Currency_Text": "Bhutan Ngultrum",
			"Decimals": 2,
			"CurrencyISOCode": "BTN",
			"AlternativeCurrencyKey": "064",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BTN')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BWP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BWP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BWP",
			"Currency_Text": "Botswana Pula",
			"Decimals": 2,
			"CurrencyISOCode": "BWP",
			"AlternativeCurrencyKey": "072",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BWP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BYB')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BYB')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BYB",
			"Currency_Text": "Belarusian Ruble (Old)",
			"Decimals": 0,
			"CurrencyISOCode": "BYB",
			"AlternativeCurrencyKey": "112",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BYB')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BYN')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BYN')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BYN",
			"Currency_Text": "Belarusian Ruble (New)",
			"Decimals": 2,
			"CurrencyISOCode": "BYN",
			"AlternativeCurrencyKey": "933",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BYN')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BYR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BYR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BYR",
			"Currency_Text": "Belarusian Ruble",
			"Decimals": 0,
			"CurrencyISOCode": "BYR",
			"AlternativeCurrencyKey": "974",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BYR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BZD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BZD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "BZD",
			"Currency_Text": "Belize Dollar",
			"Decimals": 2,
			"CurrencyISOCode": "BZD",
			"AlternativeCurrencyKey": "084",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('BZD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CAD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CAD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "CAD",
			"Currency_Text": "Canadian Dollar",
			"Decimals": 2,
			"CurrencyISOCode": "CAD",
			"AlternativeCurrencyKey": "124",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CAD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CDF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CDF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "CDF",
			"Currency_Text": "Congolese Franc",
			"Decimals": 2,
			"CurrencyISOCode": "CDF",
			"AlternativeCurrencyKey": "976",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CDF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('XPF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('XPF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "XPF",
			"Currency_Text": "French Franc (Pacific Islands)",
			"Decimals": 2,
			"CurrencyISOCode": "XPF",
			"AlternativeCurrencyKey": "953",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('XPF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CHF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CHF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "CHF",
			"Currency_Text": "Swiss Franc",
			"Decimals": 2,
			"CurrencyISOCode": "CHF",
			"AlternativeCurrencyKey": "756",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CHF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CLP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CLP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "CLP",
			"Currency_Text": "Chilean Peso",
			"Decimals": 0,
			"CurrencyISOCode": "CLP",
			"AlternativeCurrencyKey": "152",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CLP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CNY')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CNY')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "CNY",
			"Currency_Text": "Chinese Renminbi",
			"Decimals": 2,
			"CurrencyISOCode": "CNY",
			"AlternativeCurrencyKey": "156",
			"IsPrimaryCurrencyForISOCrcy": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CNY')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('COP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('COP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "COP",
			"Currency_Text": "Colombian Peso",
			"Decimals": 0,
			"CurrencyISOCode": "COP",
			"AlternativeCurrencyKey": "170",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('COP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CRC')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CRC')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "CRC",
			"Currency_Text": "Costa Rica Colon",
			"Decimals": 2,
			"CurrencyISOCode": "CRC",
			"AlternativeCurrencyKey": "188",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CRC')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CSD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CSD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "CSD",
			"Currency_Text": "Serbian Dinar (Old)",
			"Decimals": 2,
			"CurrencyISOCode": "CSD",
			"AlternativeCurrencyKey": "891",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CSD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CUC')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CUC')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "CUC",
			"Currency_Text": "Peso Convertible",
			"Decimals": 2,
			"CurrencyISOCode": "CUC",
			"AlternativeCurrencyKey": "931",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CUC')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CUP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CUP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "CUP",
			"Currency_Text": "Cuban Peso",
			"Decimals": 2,
			"CurrencyISOCode": "CUP",
			"AlternativeCurrencyKey": "192",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CUP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CVE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CVE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "CVE",
			"Currency_Text": "Cape Verde Escudo",
			"Decimals": 2,
			"CurrencyISOCode": "CVE",
			"AlternativeCurrencyKey": "132",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CVE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CYP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CYP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "CYP",
			"Currency_Text": "Cyprus Pound  (Old --> EUR)",
			"Decimals": 2,
			"CurrencyISOCode": "CYP",
			"AlternativeCurrencyKey": "196",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CYP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CZK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CZK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "CZK",
			"Currency_Text": "Czech Krona",
			"Decimals": 2,
			"CurrencyISOCode": "CZK",
			"AlternativeCurrencyKey": "203",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('CZK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DEM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DEM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "DEM",
			"Currency_Text": "German Mark    (Old --> EUR)",
			"Decimals": 2,
			"CurrencyISOCode": "DEM",
			"AlternativeCurrencyKey": "280",
			"IsPrimaryCurrencyForISOCrcy": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DEM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DEM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DEM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "DEM",
			"Currency_Text": "(Internal) German Mark (3 dec.places)",
			"Decimals": 3,
			"CurrencyISOCode": "DEM",
			"AlternativeCurrencyKey": "280",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DEM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DJF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DJF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "DJF",
			"Currency_Text": "Djibouti Franc",
			"Decimals": 0,
			"CurrencyISOCode": "DJF",
			"AlternativeCurrencyKey": "262",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DJF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DKK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DKK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "DKK",
			"Currency_Text": "Danish Krone",
			"Decimals": 2,
			"CurrencyISOCode": "DKK",
			"AlternativeCurrencyKey": "208",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DKK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DOP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DOP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "DOP",
			"Currency_Text": "Dominican Peso",
			"Decimals": 2,
			"CurrencyISOCode": "DOP",
			"AlternativeCurrencyKey": "214",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DOP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DZD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DZD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "DZD",
			"Currency_Text": "Algerian Dinar",
			"Decimals": 2,
			"CurrencyISOCode": "DZD",
			"AlternativeCurrencyKey": "012",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('DZD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ECS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ECS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "ECS",
			"Currency_Text": "Ecuadorian Sucre (Old --> USD)",
			"Decimals": 0,
			"CurrencyISOCode": "ECS",
			"AlternativeCurrencyKey": "218",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ECS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('EEK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('EEK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "EEK",
			"Currency_Text": "Estonian Krone (Old --> EUR)",
			"Decimals": 2,
			"CurrencyISOCode": "EEK",
			"AlternativeCurrencyKey": "233",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('EEK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('EGP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('EGP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "EGP",
			"Currency_Text": "Egyptian Pound",
			"Decimals": 2,
			"CurrencyISOCode": "EGP",
			"AlternativeCurrencyKey": "818",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('EGP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ERN')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ERN')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "ERN",
			"Currency_Text": "Eritrean Nafka",
			"Decimals": 2,
			"CurrencyISOCode": "ERN",
			"AlternativeCurrencyKey": "232",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ERN')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ESP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ESP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "ESP",
			"Currency_Text": "Spanish Peseta (Old --> EUR)",
			"Decimals": 0,
			"CurrencyISOCode": "ESP",
			"AlternativeCurrencyKey": "724",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ESP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ETB')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ETB')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "ETB",
			"Currency_Text": "Ethiopian Birr",
			"Decimals": 2,
			"CurrencyISOCode": "ETB",
			"AlternativeCurrencyKey": "230",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ETB')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('EUR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('EUR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "EUR",
			"Currency_Text": "European Euro",
			"Decimals": 2,
			"CurrencyISOCode": "EUR",
			"AlternativeCurrencyKey": "978",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('EUR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('FIM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('FIM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "FIM",
			"Currency_Text": "Finnish Markka (Old --> EUR)",
			"Decimals": 2,
			"CurrencyISOCode": "FIM",
			"AlternativeCurrencyKey": "246",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('FIM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('FJD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('FJD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "FJD",
			"Currency_Text": "Fiji Dollar",
			"Decimals": 2,
			"CurrencyISOCode": "FJD",
			"AlternativeCurrencyKey": "242",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('FJD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('FKP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('FKP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "FKP",
			"Currency_Text": "Falkland Pound",
			"Decimals": 2,
			"CurrencyISOCode": "FKP",
			"AlternativeCurrencyKey": "238",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('FKP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('FRF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('FRF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "FRF",
			"Currency_Text": "French Franc (Old --> EUR)",
			"Decimals": 2,
			"CurrencyISOCode": "FRF",
			"AlternativeCurrencyKey": "250",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('FRF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GBP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GBP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "GBP",
			"Currency_Text": "British Pound",
			"Decimals": 2,
			"CurrencyISOCode": "GBP",
			"AlternativeCurrencyKey": "826",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GBP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GEL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GEL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "GEL",
			"Currency_Text": "Georgian Lari",
			"Decimals": 2,
			"CurrencyISOCode": "GEL",
			"AlternativeCurrencyKey": "981",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GEL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GHC')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GHC')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "GHC",
			"Currency_Text": "Ghanaian Cedi (Old)",
			"Decimals": 2,
			"CurrencyISOCode": "GHC",
			"AlternativeCurrencyKey": "288",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GHC')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GHS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GHS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "GHS",
			"Currency_Text": "Ghanian Cedi",
			"Decimals": 2,
			"CurrencyISOCode": "GHS",
			"AlternativeCurrencyKey": "936",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GHS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GIP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GIP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "GIP",
			"Currency_Text": "Gibraltar Pound",
			"Decimals": 2,
			"CurrencyISOCode": "GIP",
			"AlternativeCurrencyKey": "292",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GIP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GMD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GMD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "GMD",
			"Currency_Text": "Gambian Dalasi",
			"Decimals": 2,
			"CurrencyISOCode": "GMD",
			"AlternativeCurrencyKey": "270",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GMD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GNF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GNF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "GNF",
			"Currency_Text": "Guinean Franc",
			"Decimals": 0,
			"CurrencyISOCode": "GNF",
			"AlternativeCurrencyKey": "324",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GNF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GRD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GRD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "GRD",
			"Currency_Text": "Greek Drachma (Old --> EUR)",
			"Decimals": 0,
			"CurrencyISOCode": "GRD",
			"AlternativeCurrencyKey": "300",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GRD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GTQ')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GTQ')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "GTQ",
			"Currency_Text": "Guatemalan Quetzal",
			"Decimals": 2,
			"CurrencyISOCode": "GTQ",
			"AlternativeCurrencyKey": "320",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GTQ')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GWP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GWP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "GWP",
			"Currency_Text": "Guinea Peso (Old --> SHP)",
			"Decimals": 2,
			"CurrencyISOCode": "GWP",
			"AlternativeCurrencyKey": "624",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GWP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GYD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GYD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "GYD",
			"Currency_Text": "Guyana Dollar",
			"Decimals": 2,
			"CurrencyISOCode": "GYD",
			"AlternativeCurrencyKey": "328",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('GYD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('HKD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('HKD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "HKD",
			"Currency_Text": "Hong Kong Dollar",
			"Decimals": 2,
			"CurrencyISOCode": "HKD",
			"AlternativeCurrencyKey": "344",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('HKD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('HNL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('HNL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "HNL",
			"Currency_Text": "Honduran Lempira",
			"Decimals": 2,
			"CurrencyISOCode": "HNL",
			"AlternativeCurrencyKey": "340",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('HNL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('HRK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('HRK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "HRK",
			"Currency_Text": "Croatian Kuna",
			"Decimals": 2,
			"CurrencyISOCode": "HRK",
			"AlternativeCurrencyKey": "191",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('HRK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('HTG')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('HTG')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "HTG",
			"Currency_Text": "Haitian Gourde",
			"Decimals": 2,
			"CurrencyISOCode": "HTG",
			"AlternativeCurrencyKey": "332",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('HTG')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('HUF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('HUF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "HUF",
			"Currency_Text": "Hungarian Forint",
			"Decimals": 0,
			"CurrencyISOCode": "HUF",
			"AlternativeCurrencyKey": "348",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('HUF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('IDR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('IDR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "IDR",
			"Currency_Text": "Indonesian Rupiah",
			"Decimals": 0,
			"CurrencyISOCode": "IDR",
			"AlternativeCurrencyKey": "360",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('IDR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('IEP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('IEP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "IEP",
			"Currency_Text": "Irish Punt (Old --> EUR)",
			"Decimals": 2,
			"CurrencyISOCode": "IEP",
			"AlternativeCurrencyKey": "372",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('IEP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ILS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ILS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "ILS",
			"Currency_Text": "Israeli Scheckel",
			"Decimals": 2,
			"CurrencyISOCode": "ILS",
			"AlternativeCurrencyKey": "376",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ILS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('INR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('INR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "INR",
			"Currency_Text": "Indian Rupee",
			"Decimals": 2,
			"CurrencyISOCode": "INR",
			"AlternativeCurrencyKey": "356",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('INR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('IQD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('IQD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "IQD",
			"Currency_Text": "Iraqui Dinar",
			"Decimals": 3,
			"CurrencyISOCode": "IQD",
			"AlternativeCurrencyKey": "368",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('IQD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('IRR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('IRR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "IRR",
			"Currency_Text": "Iranian Rial",
			"Decimals": 2,
			"CurrencyISOCode": "IRR",
			"AlternativeCurrencyKey": "364",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('IRR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ISK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ISK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "ISK",
			"Currency_Text": "Iceland Krona",
			"Decimals": 0,
			"CurrencyISOCode": "ISK",
			"AlternativeCurrencyKey": "352",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ISK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ITL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ITL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "ITL",
			"Currency_Text": "Italian Lira (Old --> EUR)",
			"Decimals": 0,
			"CurrencyISOCode": "ITL",
			"AlternativeCurrencyKey": "380",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('ITL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('JMD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('JMD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "JMD",
			"Currency_Text": "Jamaican Dollar",
			"Decimals": 2,
			"CurrencyISOCode": "JMD",
			"AlternativeCurrencyKey": "388",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('JMD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('JOD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('JOD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "JOD",
			"Currency_Text": "Jordanian Dinar",
			"Decimals": 3,
			"CurrencyISOCode": "JOD",
			"AlternativeCurrencyKey": "400",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('JOD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('JPY')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('JPY')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "JPY",
			"Currency_Text": "Japanese Yen",
			"Decimals": 0,
			"CurrencyISOCode": "JPY",
			"AlternativeCurrencyKey": "392",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('JPY')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KES')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KES')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "KES",
			"Currency_Text": "Kenyan Shilling",
			"Decimals": 2,
			"CurrencyISOCode": "KES",
			"AlternativeCurrencyKey": "404",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KES')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KGS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KGS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "KGS",
			"Currency_Text": "Kyrgyzstan Som",
			"Decimals": 2,
			"CurrencyISOCode": "KGS",
			"AlternativeCurrencyKey": "417",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KGS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KHR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KHR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "KHR",
			"Currency_Text": "Cambodian Riel",
			"Decimals": 2,
			"CurrencyISOCode": "KHR",
			"AlternativeCurrencyKey": "116",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KHR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KMF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KMF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "KMF",
			"Currency_Text": "Comoros Franc",
			"Decimals": 0,
			"CurrencyISOCode": "KMF",
			"AlternativeCurrencyKey": "174",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KMF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KPW')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KPW')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "KPW",
			"Currency_Text": "North Korean Won",
			"Decimals": 2,
			"CurrencyISOCode": "KPW",
			"AlternativeCurrencyKey": "408",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KPW')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KRW')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KRW')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "KRW",
			"Currency_Text": "South Korean Won",
			"Decimals": 0,
			"CurrencyISOCode": "KRW",
			"AlternativeCurrencyKey": "410",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KRW')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KWD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KWD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "KWD",
			"Currency_Text": "Kuwaiti Dinar",
			"Decimals": 3,
			"CurrencyISOCode": "KWD",
			"AlternativeCurrencyKey": "414",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KWD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KYD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KYD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "KYD",
			"Currency_Text": "Cayman Dollar",
			"Decimals": 2,
			"CurrencyISOCode": "KYD",
			"AlternativeCurrencyKey": "136",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KYD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KZT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KZT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "KZT",
			"Currency_Text": "Kazakstanian Tenge",
			"Decimals": 2,
			"CurrencyISOCode": "KZT",
			"AlternativeCurrencyKey": "398",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('KZT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LAK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LAK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "LAK",
			"Currency_Text": "Laotian Kip",
			"Decimals": 0,
			"CurrencyISOCode": "LAK",
			"AlternativeCurrencyKey": "418",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LAK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LBP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LBP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "LBP",
			"Currency_Text": "Lebanese Pound",
			"Decimals": 2,
			"CurrencyISOCode": "LBP",
			"AlternativeCurrencyKey": "422",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LBP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LKR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LKR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "LKR",
			"Currency_Text": "Sri Lankan Rupee",
			"Decimals": 2,
			"CurrencyISOCode": "LKR",
			"AlternativeCurrencyKey": "144",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LKR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LRD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LRD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "LRD",
			"Currency_Text": "Liberian Dollar",
			"Decimals": 2,
			"CurrencyISOCode": "LRD",
			"AlternativeCurrencyKey": "430",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LRD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LSL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LSL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "LSL",
			"Currency_Text": "Lesotho Loti",
			"Decimals": 2,
			"CurrencyISOCode": "LSL",
			"AlternativeCurrencyKey": "426",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LSL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LTL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LTL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "LTL",
			"Currency_Text": "Lithuanian Lita",
			"Decimals": 2,
			"CurrencyISOCode": "LTL",
			"AlternativeCurrencyKey": "440",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LTL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LUF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LUF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "LUF",
			"Currency_Text": "Luxembourg Franc (Old --> EUR)",
			"Decimals": 0,
			"CurrencyISOCode": "LUF",
			"AlternativeCurrencyKey": "442",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LUF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LVL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LVL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "LVL",
			"Currency_Text": "Latvian Lat",
			"Decimals": 2,
			"CurrencyISOCode": "LVL",
			"AlternativeCurrencyKey": "428",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LVL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LYD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LYD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_CurrencyType"
			},
			"Currency": "LYD",
			"Currency_Text": "Libyan Dinar",
			"Decimals": 3,
			"CurrencyISOCode": "LYD",
			"AlternativeCurrencyKey": "434",
			"IsPrimaryCurrencyForISOCrcy": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_Currency('LYD')/to_Text"
				}
			}
		}]
	};

	var I_MKT_DeviceType = {
		"__count": "13",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('AY_TEST')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('AY_TEST')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "AY_TEST",
			"ProductOrigin_Text": "AY test",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('AY_TEST')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('EXTERNAL_01')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('EXTERNAL_01')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "EXTERNAL_01",
			"ProductOrigin_Text": "External Product",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('EXTERNAL_01')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('KA_TEST')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('KA_TEST')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "KA_TEST",
			"ProductOrigin_Text": "KA Test",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('KA_TEST')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('QI5CLNT800')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('QI5CLNT800')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "QI5CLNT800",
			"ProductOrigin_Text": "QI5CLNT800",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('QI5CLNT800')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('QI5CLNT805')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('QI5CLNT805')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "QI5CLNT805",
			"ProductOrigin_Text": "QI5CLNT805",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('QI5CLNT805')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('RD2CLNT405')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('RD2CLNT405')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "RD2CLNT405",
			"ProductOrigin_Text": "RD2CLNT405",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('RD2CLNT405')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_C4C_PRODUCT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_C4C_PRODUCT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "SAP_C4C_PRODUCT",
			"ProductOrigin_Text": "Product (SAP Cloud for Customer)",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_C4C_PRODUCT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_CRM_PRODUCT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_CRM_PRODUCT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "SAP_CRM_PRODUCT",
			"ProductOrigin_Text": "Product (SAP CRM)",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_CRM_PRODUCT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_ERP_MATNR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_ERP_MATNR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "SAP_ERP_MATNR",
			"ProductOrigin_Text": "Material (SAP ERP)",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_ERP_MATNR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_HYBRIS_PRODUCT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_HYBRIS_PRODUCT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "SAP_HYBRIS_PRODUCT",
			"ProductOrigin_Text": "Product (SAP Commerce Cloud)",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_HYBRIS_PRODUCT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_S4H_PRODUCT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_S4H_PRODUCT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "SAP_S4H_PRODUCT",
			"ProductOrigin_Text": "Product (S4 Hana Cloud)",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_S4H_PRODUCT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('ZPRODRECO_PRODUCT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('ZPRODRECO_PRODUCT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "ZPRODRECO_PRODUCT",
			"ProductOrigin_Text": "Z Product Desc",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('ZPRODRECO_PRODUCT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('ZPRODRECO_PRODUCT1')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('ZPRODRECO_PRODUCT1')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "ZPRODRECO_PRODUCT1",
			"ProductOrigin_Text": "ZPRODRECO_PRODUCT1 Desc",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('ZPRODRECO_PRODUCT1')/to_Text"
				}
			}
		}]
	};

	var I_MKT_ProductOrigin = {
		"__count": "13",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('AY_TEST')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('AY_TEST')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "AY_TEST",
			"ProductOrigin_Text": "AY test",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('AY_TEST')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('EXTERNAL_01')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('EXTERNAL_01')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "EXTERNAL_01",
			"ProductOrigin_Text": "External Product",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('EXTERNAL_01')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('KA_TEST')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('KA_TEST')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "KA_TEST",
			"ProductOrigin_Text": "KA Test",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('KA_TEST')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('QI5CLNT800')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('QI5CLNT800')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "QI5CLNT800",
			"ProductOrigin_Text": "QI5CLNT800",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('QI5CLNT800')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('QI5CLNT805')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('QI5CLNT805')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "QI5CLNT805",
			"ProductOrigin_Text": "QI5CLNT805",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('QI5CLNT805')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('RD2CLNT405')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('RD2CLNT405')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "RD2CLNT405",
			"ProductOrigin_Text": "RD2CLNT405",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('RD2CLNT405')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_C4C_PRODUCT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_C4C_PRODUCT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "SAP_C4C_PRODUCT",
			"ProductOrigin_Text": "Product (SAP Cloud for Customer)",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_C4C_PRODUCT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_CRM_PRODUCT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_CRM_PRODUCT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "SAP_CRM_PRODUCT",
			"ProductOrigin_Text": "Product (SAP CRM)",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_CRM_PRODUCT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_ERP_MATNR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_ERP_MATNR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "SAP_ERP_MATNR",
			"ProductOrigin_Text": "Material (SAP ERP)",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_ERP_MATNR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_HYBRIS_PRODUCT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_HYBRIS_PRODUCT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "SAP_HYBRIS_PRODUCT",
			"ProductOrigin_Text": "Product (SAP Commerce Cloud)",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_HYBRIS_PRODUCT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_S4H_PRODUCT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_S4H_PRODUCT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "SAP_S4H_PRODUCT",
			"ProductOrigin_Text": "Product (S4 Hana Cloud)",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('SAP_S4H_PRODUCT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('ZPRODRECO_PRODUCT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('ZPRODRECO_PRODUCT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "ZPRODRECO_PRODUCT",
			"ProductOrigin_Text": "Z Product Desc",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('ZPRODRECO_PRODUCT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('ZPRODRECO_PRODUCT1')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('ZPRODRECO_PRODUCT1')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ProductOriginType"
			},
			"ProductOrigin": "ZPRODRECO_PRODUCT1",
			"ProductOrigin_Text": "ZPRODRECO_PRODUCT1 Desc",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ProductOrigin('ZPRODRECO_PRODUCT1')/to_Text"
				}
			}
		}]
	};

	var I_MKT_ActiveMarketingArea = {
		"__count": "140",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ALEXWALD''S')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ALEXWALD''S')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ALEXWALD'S",
			"MarketingArea_Text": "ALE X WALD's area",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ALEXWALD''S')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('DAAN%20MARKETING%20AREA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('DAAN%20MARKETING%20AREA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "DAAN MARKETING AREA",
			"MarketingArea_Text": "Daria's Marketing Area",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('DAAN%20MARKETING%20AREA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('DK_AREA_A')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('DK_AREA_A')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "DK_AREA_A",
			"MarketingArea_Text": "DK Area A",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('DK_AREA_A')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('DK_AREA_B')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('DK_AREA_B')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "DK_AREA_B",
			"MarketingArea_Text": "DK Area B",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('DK_AREA_B')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GERMANY')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GERMANY')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "GERMANY",
			"MarketingArea_Text": "Germany",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GERMANY')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "GLOBAL",
			"MarketingArea_Text": "Global",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_AUD_LEAF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_AUD_LEAF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "GLOBAL_MT_AUD_LEAF",
			"MarketingArea_Text": "Model with Audience dimension as leaf and media type enabled",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_AUD_LEAF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_AUD_ROOT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_AUD_ROOT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "GLOBAL_MT_AUD_ROOT",
			"MarketingArea_Text": "Model with Audience dimension as root and media type enabled",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_AUD_ROOT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_CDIM_LEAF')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_CDIM_LEAF')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "GLOBAL_MT_CDIM_LEAF",
			"MarketingArea_Text": "Model with custom dimension as leaf and media type enabled",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_CDIM_LEAF')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_CDIM_ROOT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_CDIM_ROOT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "GLOBAL_MT_CDIM_ROOT",
			"MarketingArea_Text": "Model with custom dimension as root and media type enabled",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_CDIM_ROOT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_MA1')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_MA1')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "GLOBAL_MT_MA1",
			"MarketingArea_Text": "Standard model with media type enabled",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_MA1')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_MA2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_MA2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "GLOBAL_MT_MA2",
			"MarketingArea_Text": "Standard model with media type enabled and Market is root",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_MA2')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_STAR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_STAR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "GLOBAL_MT_STAR",
			"MarketingArea_Text": "Standard model with media type enabled and star in MA and Validity",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('GLOBAL_MT_STAR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ICMA_DRINK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ICMA_DRINK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ICMA_DRINK",
			"MarketingArea_Text": "Interaction Contact Marketing Area: Drink",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ICMA_DRINK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ICMA_FOOD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ICMA_FOOD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ICMA_FOOD",
			"MarketingArea_Text": "Interaction Contact Marketing Area: Food",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ICMA_FOOD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('IGB02')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('IGB02')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "IGB02",
			"MarketingArea_Text": "IGB02",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('IGB02')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('LD_MKT_AREA_ACTIVE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('LD_MKT_AREA_ACTIVE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "LD_MKT_AREA_ACTIVE",
			"MarketingArea_Text": "LD: Active Marketing Area",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('LD_MKT_AREA_ACTIVE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('LD_MKT_AREA_INACTIVE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('LD_MKT_AREA_INACTIVE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "LD_MKT_AREA_INACTIVE",
			"MarketingArea_Text": "LD: Inactive Marketing Area",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('LD_MKT_AREA_INACTIVE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MA01')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MA01')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "MA01",
			"MarketingArea_Text": "MA01",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MA01')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MA02')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MA02')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "MA02",
			"MarketingArea_Text": "MA02",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MA02')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MA03')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MA03')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "MA03",
			"MarketingArea_Text": "MA03",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MA03')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MA04')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MA04')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "MA04",
			"MarketingArea_Text": "MA04",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MA04')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MA05')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MA05')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "MA05",
			"MarketingArea_Text": "MA05",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MA05')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MASP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MASP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "MASP",
			"MarketingArea_Text": "Test 2",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MASP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MASP-1')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MASP-1')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "MASP-1",
			"MarketingArea_Text": "MASP Marketing Area",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MASP-1')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MASP-INACTIVE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MASP-INACTIVE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "MASP-INACTIVE",
			"MarketingArea_Text": "MASP Area",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('MASP-INACTIVE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('SCE_TEST_MKD_ID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('SCE_TEST_MKD_ID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "SCE_TEST_MKD_ID",
			"MarketingArea_Text": "unit test marketing area id",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('SCE_TEST_MKD_ID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('SS_AREA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('SS_AREA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "SS_AREA",
			"MarketingArea_Text": "Premium Area",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('SS_AREA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('TEST_MULTI_APPROVERS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('TEST_MULTI_APPROVERS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "TEST_MULTI_APPROVERS",
			"MarketingArea_Text": "Test workflow with multi approvers",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('TEST_MULTI_APPROVERS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('TEST_MULTI_APPROVERS_B')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('TEST_MULTI_APPROVERS_B')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "TEST_MULTI_APPROVERS_B",
			"MarketingArea_Text": "Test workflow with multi approvers (Brigitte tests)",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('TEST_MULTI_APPROVERS_B')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('TEST_WORKFLOW')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('TEST_WORKFLOW')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "TEST_WORKFLOW",
			"MarketingArea_Text": "To Test Workflow",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('TEST_WORKFLOW')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZBC_WORKFLOW_DEMO')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZBC_WORKFLOW_DEMO')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZBC_WORKFLOW_DEMO",
			"MarketingArea_Text": "Marketing Area for Workflow Demo (Bernard)",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZBC_WORKFLOW_DEMO')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB01')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB01')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB01",
			"MarketingArea_Text": "ZKB01",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB01')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB02')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB02')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB02",
			"MarketingArea_Text": "ZKB02",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB02')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB03')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB03')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB03",
			"MarketingArea_Text": "ZKB03",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB03')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB04')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB04')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB04",
			"MarketingArea_Text": "ZKB04",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB04')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB05')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB05')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB05",
			"MarketingArea_Text": "ZKB05",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB05')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB06')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB06')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB06",
			"MarketingArea_Text": "ZKB06",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB06')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB07')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB07')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB07",
			"MarketingArea_Text": "ZKB07",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB07')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB08')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB08')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB08",
			"MarketingArea_Text": "ZKB08",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB08')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB09')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB09')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB09",
			"MarketingArea_Text": "ZKB09",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB09')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB10')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB10')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB10",
			"MarketingArea_Text": "ZKB10",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB10')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB100')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB100')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB100",
			"MarketingArea_Text": "ZKB100",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB100')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB101')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB101')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB101",
			"MarketingArea_Text": "ZKB101",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB101')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB102')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB102')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB102",
			"MarketingArea_Text": "ZKB102",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB102')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB103')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB103')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB103",
			"MarketingArea_Text": "ZKB103",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB103')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB11')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB11')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB11",
			"MarketingArea_Text": "ZKB11",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB11')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB12')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB12')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB12",
			"MarketingArea_Text": "ZKB12",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB12')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB13')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB13')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB13",
			"MarketingArea_Text": "ZKB13",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB13')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB14')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB14')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB14",
			"MarketingArea_Text": "ZKB14",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB14')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB15')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB15')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB15",
			"MarketingArea_Text": "ZKB15",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB15')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB16')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB16')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB16",
			"MarketingArea_Text": "ZKB16",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB16')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB17')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB17')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB17",
			"MarketingArea_Text": "ZKB17",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB17')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB18')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB18')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB18",
			"MarketingArea_Text": "ZKB18",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB18')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB19')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB19')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB19",
			"MarketingArea_Text": "ZKB19",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB19')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB20')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB20')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB20",
			"MarketingArea_Text": "ZKB20",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB20')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB21')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB21')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB21",
			"MarketingArea_Text": "ZKB21",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB21')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB22')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB22')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB22",
			"MarketingArea_Text": "ZKB22",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB22')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB23')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB23')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB23",
			"MarketingArea_Text": "ZKB23",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB23')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB24')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB24')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB24",
			"MarketingArea_Text": "ZKB24",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB24')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB25')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB25')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB25",
			"MarketingArea_Text": "ZKB25",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB25')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB26')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB26')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB26",
			"MarketingArea_Text": "ZKB26",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB26')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB27')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB27')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB27",
			"MarketingArea_Text": "ZKB27",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB27')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB28')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB28')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB28",
			"MarketingArea_Text": "ZKB28",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB28')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB29')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB29')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB29",
			"MarketingArea_Text": "ZKB29",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB29')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB30')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB30')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB30",
			"MarketingArea_Text": "ZKB30",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB30')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB31')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB31')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB31",
			"MarketingArea_Text": "ZKB31",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB31')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB32')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB32')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB32",
			"MarketingArea_Text": "ZKB32",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB32')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB33')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB33')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB33",
			"MarketingArea_Text": "ZKB33",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB33')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB34')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB34')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB34",
			"MarketingArea_Text": "ZKB34",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB34')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB35')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB35')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB35",
			"MarketingArea_Text": "ZKB35",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB35')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB36')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB36')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB36",
			"MarketingArea_Text": "ZKB36",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB36')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB37')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB37')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB37",
			"MarketingArea_Text": "ZKB37",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB37')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB38')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB38')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB38",
			"MarketingArea_Text": "ZKB38",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB38')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB39')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB39')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB39",
			"MarketingArea_Text": "ZKB39",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB39')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB40')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB40')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB40",
			"MarketingArea_Text": "ZKB40",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB40')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB41')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB41')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB41",
			"MarketingArea_Text": "ZKB41",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB41')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB42')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB42')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB42",
			"MarketingArea_Text": "ZKB42",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB42')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB43')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB43')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB43",
			"MarketingArea_Text": "ZKB43",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB43')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB44')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB44')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB44",
			"MarketingArea_Text": "ZKB44",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB44')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB45')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB45')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB45",
			"MarketingArea_Text": "ZKB45",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB45')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB46')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB46')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB46",
			"MarketingArea_Text": "ZKB46",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB46')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB47')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB47')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB47",
			"MarketingArea_Text": "ZKB47",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB47')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB48')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB48')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB48",
			"MarketingArea_Text": "ZKB48",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB48')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB49')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB49')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB49",
			"MarketingArea_Text": "ZKB49",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB49')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB50')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB50')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB50",
			"MarketingArea_Text": "ZKB50",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB50')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB51')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB51')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB51",
			"MarketingArea_Text": "ZKB51",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB51')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB52')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB52')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB52",
			"MarketingArea_Text": "ZKB52",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB52')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB53')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB53')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB53",
			"MarketingArea_Text": "ZKB53",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB53')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB54')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB54')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB54",
			"MarketingArea_Text": "ZKB54",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB54')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB55')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB55')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB55",
			"MarketingArea_Text": "ZKB55",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB55')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB56')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB56')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB56",
			"MarketingArea_Text": "ZKB56",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB56')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB57')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB57')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB57",
			"MarketingArea_Text": "ZKB57",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB57')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB58')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB58')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB58",
			"MarketingArea_Text": "ZKB58",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB58')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB59')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB59')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB59",
			"MarketingArea_Text": "ZKB59",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB59')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB60')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB60')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB60",
			"MarketingArea_Text": "ZKB60",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB60')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB61')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB61')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB61",
			"MarketingArea_Text": "ZKB61",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB61')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB62')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB62')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB62",
			"MarketingArea_Text": "ZKB62",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB62')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB63')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB63')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB63",
			"MarketingArea_Text": "ZKB63",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB63')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB64')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB64')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB64",
			"MarketingArea_Text": "ZKB64",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB64')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB65')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB65')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB65",
			"MarketingArea_Text": "ZKB65",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB65')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB66')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB66')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB66",
			"MarketingArea_Text": "ZKB66",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB66')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB67')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB67')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB67",
			"MarketingArea_Text": "ZKB67",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB67')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB68')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB68')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB68",
			"MarketingArea_Text": "ZKB68",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB68')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB69')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB69')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB69",
			"MarketingArea_Text": "ZKB69",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB69')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB70')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB70')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB70",
			"MarketingArea_Text": "ZKB70",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB70')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB71')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB71')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB71",
			"MarketingArea_Text": "ZKB71",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB71')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB72')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB72')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB72",
			"MarketingArea_Text": "ZKB72",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB72')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB73')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB73')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB73",
			"MarketingArea_Text": "ZKB73",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB73')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB74')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB74')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ActiveMarketingAreaType"
			},
			"MarketingArea": "ZKB74",
			"MarketingArea_Text": "ZKB74",
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_ActiveMarketingArea('ZKB74')/to_Text"
				}
			}
		}]
	};

	var I_MKT_Contactorigin = {
		"__count": "74",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('AAID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('AAID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "AAID",
			"InteractionContactOrigin_Text": "Advertising ID for Android Devices",
			"PriorityCode": "84",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('AAID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ADFORM_ID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ADFORM_ID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "ADFORM_ID",
			"InteractionContactOrigin_Text": "Adform ID",
			"PriorityCode": "80",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ADFORM_ID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('AJM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('AJM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "AJM",
			"InteractionContactOrigin_Text": "AJM Test",
			"PriorityCode": "50",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('AJM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ANONYMOUS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ANONYMOUS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "ANONYMOUS",
			"InteractionContactOrigin_Text": "Anonymous Contact",
			"PriorityCode": "00",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ANONYMOUS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('COOKIE_ID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('COOKIE_ID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "COOKIE_ID",
			"InteractionContactOrigin_Text": "Cookie ID",
			"PriorityCode": "90",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('COOKIE_ID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('DEMANDBASE_ID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('DEMANDBASE_ID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "DEMANDBASE_ID",
			"InteractionContactOrigin_Text": "Demandbase",
			"PriorityCode": "77",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('DEMANDBASE_ID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('DUNS_ID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('DUNS_ID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "DUNS_ID",
			"InteractionContactOrigin_Text": "Data Universal Numbering System",
			"PriorityCode": "77",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('DUNS_ID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('EMAIL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('EMAIL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "EMAIL",
			"InteractionContactOrigin_Text": "Email",
			"PriorityCode": "60",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('EMAIL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('FAX')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('FAX')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "FAX",
			"InteractionContactOrigin_Text": "Fax",
			"PriorityCode": "70",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('FAX')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('FB')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('FB')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "FB",
			"InteractionContactOrigin_Text": "",
			"PriorityCode": "00",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('FB')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('GEODATA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('GEODATA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "GEODATA",
			"InteractionContactOrigin_Text": "Geodata from Geo Service",
			"PriorityCode": "99",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('GEODATA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('GIGYA_ID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('GIGYA_ID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "GIGYA_ID",
			"InteractionContactOrigin_Text": "Gigya",
			"PriorityCode": "76",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('GIGYA_ID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('GLOBAL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('GLOBAL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "GLOBAL",
			"InteractionContactOrigin_Text": "Global",
			"PriorityCode": "00",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('GLOBAL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('HEALTHCHECK_TEST')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('HEALTHCHECK_TEST')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "HEALTHCHECK_TEST",
			"InteractionContactOrigin_Text": "Test Data for the Healthcheck",
			"PriorityCode": "00",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('HEALTHCHECK_TEST')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('IDFA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('IDFA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "IDFA",
			"InteractionContactOrigin_Text": "Advertising ID for iOS Devices",
			"PriorityCode": "83",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('IDFA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('IP_ADDRESS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('IP_ADDRESS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "IP_ADDRESS",
			"InteractionContactOrigin_Text": "IP Address",
			"PriorityCode": "00",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('IP_ADDRESS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('LANDING_PAGE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('LANDING_PAGE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "LANDING_PAGE",
			"InteractionContactOrigin_Text": "Landing Page",
			"PriorityCode": "13",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('LANDING_PAGE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('LINE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('LINE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "LINE",
			"InteractionContactOrigin_Text": "LINE Social Network",
			"PriorityCode": "83",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('LINE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ML_SHARKS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ML_SHARKS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "ML_SHARKS",
			"InteractionContactOrigin_Text": "ML Sharks",
			"PriorityCode": "00",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ML_SHARKS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('MOBILE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('MOBILE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "MOBILE",
			"InteractionContactOrigin_Text": "Mobile",
			"PriorityCode": "65",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('MOBILE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('MOBILE_APP_TOKEN')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('MOBILE_APP_TOKEN')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "MOBILE_APP_TOKEN",
			"InteractionContactOrigin_Text": "Mobile App Token",
			"PriorityCode": "65",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('MOBILE_APP_TOKEN')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ON24_ID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ON24_ID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "ON24_ID",
			"InteractionContactOrigin_Text": "ON24 Webinar Platform",
			"PriorityCode": "85",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ON24_ID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('PHONE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('PHONE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "PHONE",
			"InteractionContactOrigin_Text": "Phone",
			"PriorityCode": "66",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('PHONE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('QUALTRICS_ID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('QUALTRICS_ID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "QUALTRICS_ID",
			"InteractionContactOrigin_Text": "Qualtrics",
			"PriorityCode": "84",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('QUALTRICS_ID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_C4C_BUPA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_C4C_BUPA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_C4C_BUPA",
			"InteractionContactOrigin_Text": "SAP C4C - Business Partner",
			"PriorityCode": "25",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_C4C_BUPA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_CRM_BUPA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_CRM_BUPA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_CRM_BUPA",
			"InteractionContactOrigin_Text": "SAP CRM - Business Partner",
			"PriorityCode": "05",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_CRM_BUPA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_CRM_MKT_PROSPECT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_CRM_MKT_PROSPECT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_CRM_MKT_PROSPECT",
			"InteractionContactOrigin_Text": "SAP CRM - Marketing Prospect ID",
			"PriorityCode": "35",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_CRM_MKT_PROSPECT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_CRM_MKT_PRO_GUID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_CRM_MKT_PRO_GUID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_CRM_MKT_PRO_GUID",
			"InteractionContactOrigin_Text": "SAP CRM - Marketing Prospect Guid",
			"PriorityCode": "35",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_CRM_MKT_PRO_GUID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_ERP_BUPA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_ERP_BUPA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_ERP_BUPA",
			"InteractionContactOrigin_Text": "SAP ERP - Business Partner",
			"PriorityCode": "10",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_ERP_BUPA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_ERP_COMPANY')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_ERP_COMPANY')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_ERP_COMPANY",
			"InteractionContactOrigin_Text": "OBSOLETE - use 'SAP_ERP_CUSTOMER'",
			"PriorityCode": "04",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_ERP_COMPANY')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_ERP_CONTACT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_ERP_CONTACT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_ERP_CONTACT",
			"InteractionContactOrigin_Text": "SAP ERP - Corporate Contact",
			"PriorityCode": "15",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_ERP_CONTACT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_ERP_CUSTOMER')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_ERP_CUSTOMER')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_ERP_CUSTOMER",
			"InteractionContactOrigin_Text": "SAP ERP - Customer/Consumer",
			"PriorityCode": "20",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_ERP_CUSTOMER')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_FILE_IMPORT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_FILE_IMPORT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_FILE_IMPORT",
			"InteractionContactOrigin_Text": "SAP File Import Contact",
			"PriorityCode": "50",
			"IsDisabled": true,
			"IntactnCntctOriginIsTechnical": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_FILE_IMPORT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_HYBRIS_COMPANY')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_HYBRIS_COMPANY')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_HYBRIS_COMPANY",
			"InteractionContactOrigin_Text": "SAP Commerce - Company",
			"PriorityCode": "21",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_HYBRIS_COMPANY')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_HYBRIS_CONSUMER')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_HYBRIS_CONSUMER')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_HYBRIS_CONSUMER",
			"InteractionContactOrigin_Text": "SAP Commerce - Consumer",
			"PriorityCode": "22",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_HYBRIS_CONSUMER')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_HYBRIS_MKT_IC')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_HYBRIS_MKT_IC')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_HYBRIS_MKT_IC",
			"InteractionContactOrigin_Text": "Internal origin - not allowed for usage",
			"PriorityCode": "99",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_HYBRIS_MKT_IC')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_HYBRIS_PROFILE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_HYBRIS_PROFILE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_HYBRIS_PROFILE",
			"InteractionContactOrigin_Text": "Hybris Profile ID",
			"PriorityCode": "21",
			"IsDisabled": true,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_HYBRIS_PROFILE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_JAM_COMM_MEMBER')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_JAM_COMM_MEMBER')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_JAM_COMM_MEMBER",
			"InteractionContactOrigin_Text": "SAP Jam Community Member",
			"PriorityCode": "42",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_JAM_COMM_MEMBER')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_LOY_PROGRAM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_LOY_PROGRAM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_LOY_PROGRAM",
			"InteractionContactOrigin_Text": "Loyalty Program",
			"PriorityCode": "33",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_LOY_PROGRAM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_MANUAL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_MANUAL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_MANUAL",
			"InteractionContactOrigin_Text": "Locally Edited Data",
			"PriorityCode": "03",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_MANUAL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_MKT_BUPA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_MKT_BUPA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_MKT_BUPA",
			"InteractionContactOrigin_Text": "SAP Marketing - Business Partner",
			"PriorityCode": "10",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_MKT_BUPA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_MKT_BUPA_REL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_MKT_BUPA_REL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_MKT_BUPA_REL",
			"InteractionContactOrigin_Text": "SAP Marketing - BuPa Relationship (POC)",
			"PriorityCode": "10",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_MKT_BUPA_REL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_ODATA_IMPORT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_ODATA_IMPORT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_ODATA_IMPORT",
			"InteractionContactOrigin_Text": "SAP OData Import Contact",
			"PriorityCode": "45",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_ODATA_IMPORT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_S4_BUPA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_S4_BUPA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_S4_BUPA",
			"InteractionContactOrigin_Text": "SAP S4 - Business Partner",
			"PriorityCode": "11",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_S4_BUPA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_S4_CONTACT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_S4_CONTACT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_S4_CONTACT",
			"InteractionContactOrigin_Text": "SAP S4 - Corporate Contact",
			"PriorityCode": "16",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_S4_CONTACT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_S4_CUSTOMER')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_S4_CUSTOMER')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SAP_S4_CUSTOMER",
			"InteractionContactOrigin_Text": "SAP S4 - Customer/Consumer",
			"PriorityCode": "21",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SAP_S4_CUSTOMER')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SPRINKLR_ID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SPRINKLR_ID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SPRINKLR_ID",
			"InteractionContactOrigin_Text": "Sprinklr",
			"PriorityCode": "78",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SPRINKLR_ID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SURVEYMONKEY_ID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SURVEYMONKEY_ID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "SURVEYMONKEY_ID",
			"InteractionContactOrigin_Text": "SurveyMonkey",
			"PriorityCode": "84",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('SURVEYMONKEY_ID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TE1')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TE1')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "TE1",
			"InteractionContactOrigin_Text": "",
			"PriorityCode": "90",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TE1')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TE2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TE2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "TE2",
			"InteractionContactOrigin_Text": "",
			"PriorityCode": "90",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TE2')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TE3')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TE3')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "TE3",
			"InteractionContactOrigin_Text": "",
			"PriorityCode": "90",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TE3')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TES')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TES')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "TES",
			"InteractionContactOrigin_Text": "",
			"PriorityCode": "90",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TES')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TEST_B')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TEST_B')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "TEST_B",
			"InteractionContactOrigin_Text": "TEST_B",
			"PriorityCode": "00",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TEST_B')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TEST_CRM_BUPA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TEST_CRM_BUPA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "TEST_CRM_BUPA",
			"InteractionContactOrigin_Text": "Please don't touche. Used for ABAP Unit",
			"PriorityCode": "05",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TEST_CRM_BUPA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TEST_EMAIL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TEST_EMAIL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "TEST_EMAIL",
			"InteractionContactOrigin_Text": "",
			"PriorityCode": "05",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TEST_EMAIL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TEST_ERP_BUPA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TEST_ERP_BUPA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "TEST_ERP_BUPA",
			"InteractionContactOrigin_Text": "Please Don't touch. Used for ABAP Unit",
			"PriorityCode": "10",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TEST_ERP_BUPA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TEST_HYBRIS_COMMERCE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TEST_HYBRIS_COMMERCE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "TEST_HYBRIS_COMMERCE",
			"InteractionContactOrigin_Text": "",
			"PriorityCode": "10",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TEST_HYBRIS_COMMERCE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TURN_ID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TURN_ID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "TURN_ID",
			"InteractionContactOrigin_Text": "Turn Identifier",
			"PriorityCode": "80",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('TURN_ID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('WEB_SESSION_ID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('WEB_SESSION_ID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "WEB_SESSION_ID",
			"InteractionContactOrigin_Text": "Web Browser Session-ID",
			"PriorityCode": "00",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('WEB_SESSION_ID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('WECHAT_OPEN_ID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('WECHAT_OPEN_ID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "WECHAT_OPEN_ID",
			"InteractionContactOrigin_Text": "WeChat Open ID",
			"PriorityCode": "81",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('WECHAT_OPEN_ID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('WECHAT_UNION_ID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('WECHAT_UNION_ID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "WECHAT_UNION_ID",
			"InteractionContactOrigin_Text": "WeChat Union ID",
			"PriorityCode": "82",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('WECHAT_UNION_ID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('YTEST')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('YTEST')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "YTEST",
			"InteractionContactOrigin_Text": "Y Test",
			"PriorityCode": "00",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('YTEST')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZAJ_SAP_FILE_IMPORT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZAJ_SAP_FILE_IMPORT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "ZAJ_SAP_FILE_IMPORT",
			"InteractionContactOrigin_Text": "AJ: Test File Import",
			"PriorityCode": "00",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZAJ_SAP_FILE_IMPORT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZLE_CUSTOM_ID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZLE_CUSTOM_ID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "ZLE_CUSTOM_ID",
			"InteractionContactOrigin_Text": "ZLE_CUSTOM_ID",
			"PriorityCode": "99",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZLE_CUSTOM_ID')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZSTD_BPEXT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZSTD_BPEXT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "ZSTD_BPEXT",
			"InteractionContactOrigin_Text": "ZSTD_BPEXT",
			"PriorityCode": "00",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZSTD_BPEXT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZSWEIBO')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZSWEIBO')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "ZSWEIBO",
			"InteractionContactOrigin_Text": "Sina Weibo User ID",
			"PriorityCode": "00",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZSWEIBO')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZTEST')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZTEST')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "ZTEST",
			"InteractionContactOrigin_Text": "Ztest",
			"PriorityCode": "00",
			"IsDisabled": true,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZTEST')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZTEST1')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZTEST1')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "ZTEST1",
			"InteractionContactOrigin_Text": "ZTEST1",
			"PriorityCode": "00",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZTEST1')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZUNBOUNCE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZUNBOUNCE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "ZUNBOUNCE",
			"InteractionContactOrigin_Text": "Z Unbounce",
			"PriorityCode": "00",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": false,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('ZUNBOUNCE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('Z_GEODATA')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('Z_GEODATA')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "Z_GEODATA",
			"InteractionContactOrigin_Text": "Geoservice data",
			"PriorityCode": "99",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('Z_GEODATA')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('Z_HOME_EMAIL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('Z_HOME_EMAIL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "Z_HOME_EMAIL",
			"InteractionContactOrigin_Text": "Email - Home",
			"PriorityCode": "97",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('Z_HOME_EMAIL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('Z_LANDING_PAGE_IC')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('Z_LANDING_PAGE_IC')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "Z_LANDING_PAGE_IC",
			"InteractionContactOrigin_Text": "Landing Page IC",
			"PriorityCode": "13",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('Z_LANDING_PAGE_IC')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('Z_WORK_EMAIL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('Z_WORK_EMAIL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "Z_WORK_EMAIL",
			"InteractionContactOrigin_Text": "Email - Work",
			"PriorityCode": "99",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": null,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('Z_WORK_EMAIL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('Z_ZOOMINFO')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('Z_ZOOMINFO')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_ContactoriginType"
			},
			"InteractionContactOrigin": "Z_ZOOMINFO",
			"InteractionContactOrigin_Text": "Zoom Info Data Provider",
			"PriorityCode": "98",
			"IsDisabled": false,
			"IntactnCntctOriginIsTechnical": true,
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_Contactorigin('Z_ZOOMINFO')/to_Text"
				}
			}
		}]
	};

	var I_MKT_CommMedium = {
		"__count": "53",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('ARD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('ARD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "ARD",
			"CommunicationMedium_Text": "ARD",
			"MediaType": "TV",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('ARD')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('ARD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('BAIDU_ADS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('BAIDU_ADS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "BAIDU_ADS",
			"CommunicationMedium_Text": "Baidu Ads",
			"MediaType": "PAID_SEARCH",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('BAIDU_ADS')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('BAIDU_ADS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('BAV')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('BAV')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "BAV",
			"CommunicationMedium_Text": "BazaarVoice",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('BAV')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('BAV')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('BING_ADS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('BING_ADS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "BING_ADS",
			"CommunicationMedium_Text": "Bing Ads",
			"MediaType": "PAID_SEARCH",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('BING_ADS')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('BING_ADS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('BUSINESS_DOCUMENT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('BUSINESS_DOCUMENT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "BUSINESS_DOCUMENT",
			"CommunicationMedium_Text": "Business Document",
			"MediaType": "",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('BUSINESS_DOCUMENT')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('BUSINESS_DOCUMENT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('CB')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('CB')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "CB",
			"CommunicationMedium_Text": "Clarabridge",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('CB')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('CB')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('DEMANDBASE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('DEMANDBASE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "DEMANDBASE",
			"CommunicationMedium_Text": "Demandbase",
			"MediaType": "",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('DEMANDBASE')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('DEMANDBASE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('DISPLAY_ADS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('DISPLAY_ADS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "DISPLAY_ADS",
			"CommunicationMedium_Text": "Display Ads",
			"MediaType": "DISPLAY_ADS",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('DISPLAY_ADS')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('DISPLAY_ADS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('EMAIL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('EMAIL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "EMAIL",
			"CommunicationMedium_Text": "Email",
			"MediaType": "EMAIL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('EMAIL')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('EMAIL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('FAX')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('FAX')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "FAX",
			"CommunicationMedium_Text": "Fax",
			"MediaType": "PRINT",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('FAX')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('FAX')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('FB')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('FB')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "FB",
			"CommunicationMedium_Text": "Facebook",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('FB')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('FB')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('FLCK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('FLCK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "FLCK",
			"CommunicationMedium_Text": "Flickr",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('FLCK')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('FLCK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('FSQ')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('FSQ')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "FSQ",
			"CommunicationMedium_Text": "Foursquare",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('FSQ')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('FSQ')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('GOOGLE_ADS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('GOOGLE_ADS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "GOOGLE_ADS",
			"CommunicationMedium_Text": "Google Ads",
			"MediaType": "PAID_SEARCH",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('GOOGLE_ADS')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('GOOGLE_ADS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('GP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('GP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "GP",
			"CommunicationMedium_Text": "Google+",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('GP')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('GP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('GS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('GS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "GS",
			"CommunicationMedium_Text": "GetSatisfaction",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('GS')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('GS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('INST')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('INST')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "INST",
			"CommunicationMedium_Text": "Instagram",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('INST')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('INST')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('IN_PERSON')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('IN_PERSON')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "IN_PERSON",
			"CommunicationMedium_Text": "In person",
			"MediaType": "",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('IN_PERSON')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('IN_PERSON')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('JSP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('JSP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "JSP",
			"CommunicationMedium_Text": "Jive Space",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('JSP')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('JSP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('LC')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('LC')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "LC",
			"CommunicationMedium_Text": "LiveChat",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('LC')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('LC')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('LINE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('LINE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "LINE",
			"CommunicationMedium_Text": "LINE",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('LINE')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('LINE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('LITH')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('LITH')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "LITH",
			"CommunicationMedium_Text": "Lithium",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('LITH')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('LITH')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('LNKD')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('LNKD')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "LNKD",
			"CommunicationMedium_Text": "LinkedIn",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('LNKD')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('LNKD')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('MOBILE_ADS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('MOBILE_ADS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "MOBILE_ADS",
			"CommunicationMedium_Text": "Mobile Ads",
			"MediaType": "MOBILE_ADS",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('MOBILE_ADS')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('MOBILE_ADS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('MOBILE_APP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('MOBILE_APP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "MOBILE_APP",
			"CommunicationMedium_Text": "Mobile Application",
			"MediaType": "MOBILE_APP",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('MOBILE_APP')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('MOBILE_APP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('ONLINE_SHOP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('ONLINE_SHOP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "ONLINE_SHOP",
			"CommunicationMedium_Text": "Online-Shop",
			"MediaType": "",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('ONLINE_SHOP')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('ONLINE_SHOP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('PAPER')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('PAPER')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "PAPER",
			"CommunicationMedium_Text": "Paper",
			"MediaType": "DIRECT_MAIL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('PAPER')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('PAPER')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('PHONE')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('PHONE')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "PHONE",
			"CommunicationMedium_Text": "Phone",
			"MediaType": "CALL_CENTER",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('PHONE')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('PHONE')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('PINT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('PINT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "PINT",
			"CommunicationMedium_Text": "Pinterest",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('PINT')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('PINT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('PLCK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('PLCK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "PLCK",
			"CommunicationMedium_Text": "Pluck",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('PLCK')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('PLCK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('RR')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('RR')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "RR",
			"CommunicationMedium_Text": "RenRen",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('RR')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('RR')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('RSS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('RSS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "RSS",
			"CommunicationMedium_Text": "RSS Feed",
			"MediaType": "",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('RSS')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('RSS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('SAP_JAM_COMM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('SAP_JAM_COMM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "SAP_JAM_COMM",
			"CommunicationMedium_Text": "SAP Jam Communities",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('SAP_JAM_COMM')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('SAP_JAM_COMM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('SMS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('SMS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "SMS",
			"CommunicationMedium_Text": "Text Message",
			"MediaType": "TEXT_MESSAGE",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('SMS')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('SMS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('SOCIAL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('SOCIAL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "SOCIAL",
			"CommunicationMedium_Text": "Social Media",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('SOCIAL')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('SOCIAL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('SYSTEM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('SYSTEM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "SYSTEM",
			"CommunicationMedium_Text": "System",
			"MediaType": "",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('SYSTEM')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('SYSTEM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TE1')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TE1')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "TE1",
			"CommunicationMedium_Text": "TE1",
			"MediaType": "",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TE1')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TE1')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TE2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TE2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "TE2",
			"CommunicationMedium_Text": "TE2",
			"MediaType": "",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TE2')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TE2')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TE3')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TE3')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "TE3",
			"CommunicationMedium_Text": "TE3",
			"MediaType": "",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TE3')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TE3')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TES')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TES')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "TES",
			"CommunicationMedium_Text": "TES",
			"MediaType": "",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TES')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TES')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TMBL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TMBL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "TMBL",
			"CommunicationMedium_Text": "Tumblr",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TMBL')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TMBL')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TW')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TW')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "TW",
			"CommunicationMedium_Text": "Twitter",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TW')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TW')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TWEI')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TWEI')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "TWEI",
			"CommunicationMedium_Text": "Tencent Weibo",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TWEI')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('TWEI')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('VK')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('VK')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "VK",
			"CommunicationMedium_Text": "VK",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('VK')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('VK')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('WEB')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('WEB')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "WEB",
			"CommunicationMedium_Text": "Web",
			"MediaType": "",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('WEB')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('WEB')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('WEC')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('WEC')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "WEC",
			"CommunicationMedium_Text": "WeChat",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('WEC')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('WEC')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('WP')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('WP')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "WP",
			"CommunicationMedium_Text": "Wordpress",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('WP')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('WP')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('XING')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('XING')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "XING",
			"CommunicationMedium_Text": "Xing",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('XING')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('XING')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('ZAJ_SYSTEM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('ZAJ_SYSTEM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "ZAJ_SYSTEM",
			"CommunicationMedium_Text": "AJ: Test System",
			"MediaType": "",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('ZAJ_SYSTEM')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('ZAJ_SYSTEM')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('ZSWEIBO')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('ZSWEIBO')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "ZSWEIBO",
			"CommunicationMedium_Text": "Sina Weibo",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('ZSWEIBO')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('ZSWEIBO')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('_YAHOO_ADS')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('_YAHOO_ADS')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "_YAHOO_ADS",
			"CommunicationMedium_Text": "Yahoo! Ads",
			"MediaType": "PAID_SEARCH",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('_YAHOO_ADS')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('_YAHOO_ADS')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('_YT')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('_YT')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "_YT",
			"CommunicationMedium_Text": "YouTube",
			"MediaType": "VIDEO",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('_YT')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('_YT')/to_Text"
				}
			}
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('_ZIM')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('_ZIM')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_CommMediumType"
			},
			"CommunicationMedium": "_ZIM",
			"CommunicationMedium_Text": "Zimbra",
			"MediaType": "SOCIAL",
			"to_MKT_MediaType": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('_ZIM')/to_MKT_MediaType"
				}
			},
			"to_Text": {
				"__deferred": {
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_CommMedium('_ZIM')/to_Text"
				}
			}
		}]
	};

	var I_MKT_WebTrckgIntactnFldVH = {
		"__count": "52",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('CampaignContent')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('CampaignContent')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "CampaignContent",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('CampaignContentLinkName')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('CampaignContentLinkName')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "CampaignContentLinkName",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('CampaignContentLinkURL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('CampaignContentLinkURL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "CampaignContentLinkURL",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('CampaignID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('CampaignID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "CampaignID",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('DeviceType')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('DeviceType')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "DeviceType",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('DigitalAccount')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('DigitalAccount')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "DigitalAccount",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('DigitalAccountType')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('DigitalAccountType')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "DigitalAccountType",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionAmount')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionAmount')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionAmount",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionContactId')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionContactId')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionContactId",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionContent')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionContent')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionContent",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionContentSubject')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionContentSubject')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionContentSubject",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionCurrency')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionCurrency')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionCurrency",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionDeviceName')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionDeviceName')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionDeviceName",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionIsAnonymous')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionIsAnonymous')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionIsAnonymous",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionLanguage')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionLanguage')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionLanguage",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionLatitude')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionLatitude')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionLatitude",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionLongitude')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionLongitude')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionLongitude",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionProductAmount')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionProductAmount')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionProductAmount",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionProductQuantity')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionProductQuantity')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionProductQuantity",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionProductReason')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionProductReason')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionProductReason",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionProductSentimentVal')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionProductSentimentVal')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionProductSentimentVal",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionProductStatus')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionProductStatus')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionProductStatus",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionProductUnit')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionProductUnit')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionProductUnit",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionProdWeightingFactor')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionProdWeightingFactor')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionProdWeightingFactor",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionReason')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionReason')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionReason",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionSentimentValue')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionSentimentValue')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionSentimentValue",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionSourceDataURL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionSourceDataURL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionSourceDataURL",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionSourceItemNumber')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionSourceItemNumber')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionSourceItemNumber",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionSourceObject')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionSourceObject')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionSourceObject",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionSourceObjectAddlID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionSourceObjectAddlID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionSourceObjectAddlID",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionSourceObjectStatus')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionSourceObjectStatus')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionSourceObjectStatus",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionSourceObjectType')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionSourceObjectType')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionSourceObjectType",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionSourceTimeStampUTC')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionSourceTimeStampUTC')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionSourceTimeStampUTC",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionStatus')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionStatus')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionStatus",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionTimeStampUTC')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionTimeStampUTC')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionTimeStampUTC",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionWeightingFactor')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('InteractionWeightingFactor')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "InteractionWeightingFactor",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('MarketingArea')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('MarketingArea')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "MarketingArea",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('MarketingLocation')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('MarketingLocation')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "MarketingLocation",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('MarketingLocationOrigin')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('MarketingLocationOrigin')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "MarketingLocationOrigin",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('MKT_AgreementExternalID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('MKT_AgreementExternalID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "MKT_AgreementExternalID",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('MKT_AgreementOrigin')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('MKT_AgreementOrigin')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "MKT_AgreementOrigin",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('Product')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('Product')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "Product",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('ProductOrigin')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('ProductOrigin')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "ProductOrigin",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('ProductRecommendationModelType')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('ProductRecommendationModelType')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "ProductRecommendationModelType",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('ProductRecommendationScenario')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('ProductRecommendationScenario')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "ProductRecommendationScenario",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('ReferralSource')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('ReferralSource')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "ReferralSource",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('ReferralSourceCategory')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('ReferralSourceCategory')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "ReferralSourceCategory",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('SourceSystem')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('SourceSystem')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "SourceSystem",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('SpatialReferenceSystem')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('SpatialReferenceSystem')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "SpatialReferenceSystem",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('TagName')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('TagName')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "TagName",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('TagOrigin')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('TagOrigin')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "TagOrigin",
			"WebTrckgMappingFieldLabel": ""

		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('TagType')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnFldVH('TagType')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFldVHType"

			},
			"WebTrackingMappingField": "TagType",
			"WebTrckgMappingFieldLabel": ""

		}]

	};

	var I_MKT_WebTrckgMappgDimnMsr = {
		"__count": "513",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3A14dayUsers',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3A14dayUsers',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:14dayUsers",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "14 Day Active Users"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3A1dayUsers',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3A1dayUsers',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:1dayUsers",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "1 Day Active Users"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3A28dayUsers',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3A28dayUsers',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:28dayUsers",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "28 Day Active Users"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3A30dayUsers',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3A30dayUsers',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:30dayUsers",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "30 Day Active Users"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3A7dayUsers',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3A7dayUsers',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:7dayUsers",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "7 Day Active Users"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AacquisitionCampaign',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AacquisitionCampaign',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:acquisitionCampaign",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Acquisition Campaign"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AacquisitionMedium',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AacquisitionMedium',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:acquisitionMedium",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Acquisition Medium"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AacquisitionSource',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AacquisitionSource',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:acquisitionSource",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Acquisition Source"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AacquisitionSourceMedium',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AacquisitionSourceMedium',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:acquisitionSourceMedium",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Acquisition Source / Medium"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AacquisitionTrafficChannel',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AacquisitionTrafficChannel',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:acquisitionTrafficChannel",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Acquisition Channel"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadClicks',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadClicks',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adClicks",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Clicks"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadContent',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadContent',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adContent",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Ad Content"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadCost',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadCost',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adCost",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Cost"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadDestinationUrl',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadDestinationUrl',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adDestinationUrl",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Destination URL"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadDisplayUrl',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadDisplayUrl',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adDisplayUrl",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Display URL"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadDistributionNetwork',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadDistributionNetwork',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adDistributionNetwork",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Ad Distribution Network"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadFormat',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadFormat',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adFormat",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Ad Format"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadGroup',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadGroup',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adGroup",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Google Ads: Ad Group"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadKeywordMatchType',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadKeywordMatchType',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adKeywordMatchType",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Keyword Match Type"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadMatchedQuery',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadMatchedQuery',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adMatchedQuery",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Search Query"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadMatchType',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadMatchType',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adMatchType",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Query Match Type"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadPlacementDomain',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadPlacementDomain',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adPlacementDomain",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Placement Domain"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadPlacementUrl',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadPlacementUrl',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adPlacementUrl",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Placement URL"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadQueryWordCount',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadQueryWordCount',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adQueryWordCount",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Query Word Count"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseAdsClicks',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseAdsClicks',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adsenseAdsClicks",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdSense Ads Clicked"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseAdsViewed',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseAdsViewed',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adsenseAdsViewed",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdSense Impressions"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseAdUnitsViewed',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseAdUnitsViewed',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adsenseAdUnitsViewed",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdSense Ad Units Viewed"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseCoverage',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseCoverage',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adsenseCoverage",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdSense Coverage"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseCTR',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseCTR',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adsenseCTR",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdSense CTR"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseECPM',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseECPM',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adsenseECPM",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdSense eCPM"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseExits',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseExits',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adsenseExits",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdSense Exits"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsensePageImpressions',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsensePageImpressions',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adsensePageImpressions",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdSense Page Impressions"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseRevenue',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseRevenue',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adsenseRevenue",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdSense Revenue"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseViewableImpressionPercent',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadsenseViewableImpressionPercent',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adsenseViewableImpressionPercent",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdSense Viewable Impression %"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadSlot',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadSlot',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adSlot",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Google Ads: Ad Slot"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadTargetingOption',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadTargetingOption',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adTargetingOption",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Placement Type"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadTargetingType',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadTargetingType',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adTargetingType",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Targeting Type"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadwordsAdGroupID',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadwordsAdGroupID',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adwordsAdGroupID",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Google Ads Ad Group ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadwordsCampaignID',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadwordsCampaignID',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adwordsCampaignID",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Google Ads Campaign ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadwordsCreativeID',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadwordsCreativeID',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adwordsCreativeID",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Google Ads Creative ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadwordsCriteriaID',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadwordsCriteriaID',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adwordsCriteriaID",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Google Ads Criteria ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadwordsCustomerID',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadwordsCustomerID',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adwordsCustomerID",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Google Ads Customer ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxClicks',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxClicks',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adxClicks",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdX Clicks"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxCoverage',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxCoverage',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adxCoverage",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdX Coverage"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxCTR',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxCTR',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adxCTR",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdX CTR"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxECPM',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxECPM',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adxECPM",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdX eCPM"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxImpressions',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxImpressions',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adxImpressions",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdX Impressions"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxImpressionsPerSession',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxImpressionsPerSession',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adxImpressionsPerSession",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdX Impressions / Session"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxMonetizedPageviews',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxMonetizedPageviews',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adxMonetizedPageviews",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdX Monetized Pageviews"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxRevenue',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxRevenue',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adxRevenue",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdX Revenue"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxRevenuePer1000Sessions',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxRevenuePer1000Sessions',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adxRevenuePer1000Sessions",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdX Revenue / 1000 Sessions"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxViewableImpressionsPercent',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AadxViewableImpressionsPercent',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:adxViewableImpressionsPercent",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "AdX Viewable Impressions %"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Aaffiliation',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Aaffiliation',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:affiliation",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Affiliation"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AappId',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AappId',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:appId",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "App ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AappInstallerId',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AappInstallerId',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:appInstallerId",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "App Installer ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AappName',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AappName',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:appName",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "App Name"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AappVersion',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AappVersion',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:appVersion",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "App Version"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgDomainLookupTime',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgDomainLookupTime',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:avgDomainLookupTime",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Avg. Domain Lookup Time (sec)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgDomContentLoadedTime',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgDomContentLoadedTime',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:avgDomContentLoadedTime",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Avg. Document Content Loaded Time (sec)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgDomInteractiveTime',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgDomInteractiveTime',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:avgDomInteractiveTime",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Avg. Document Interactive Time (sec)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgEventValue',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgEventValue',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:avgEventValue",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Avg. Value"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgPageDownloadTime',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgPageDownloadTime',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:avgPageDownloadTime",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Avg. Page Download Time (sec)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgPageLoadTime',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgPageLoadTime',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:avgPageLoadTime",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Avg. Page Load Time (sec)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgRedirectionTime',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgRedirectionTime',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:avgRedirectionTime",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Avg. Redirection Time (sec)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgScreenviewDuration',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgScreenviewDuration',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:avgScreenviewDuration",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Avg. Time on Screen"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgSearchDepth',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgSearchDepth',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:avgSearchDepth",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Avg. Search Depth"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgSearchDuration',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgSearchDuration',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:avgSearchDuration",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Time after Search"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgSearchResultViews',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgSearchResultViews',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:avgSearchResultViews",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Results Pageviews / Search"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgServerConnectionTime',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgServerConnectionTime',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:avgServerConnectionTime",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Avg. Server Connection Time (sec)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgServerResponseTime',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgServerResponseTime',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:avgServerResponseTime",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Avg. Server Response Time (sec)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgSessionDuration',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgSessionDuration',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:avgSessionDuration",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Avg. Session Duration"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgTimeOnPage',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgTimeOnPage',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:avgTimeOnPage",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Avg. Time on Page"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgUserTimingValue',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AavgUserTimingValue',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:avgUserTimingValue",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Avg. User Timing (sec)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillClicks',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillClicks',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:backfillClicks",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "GAM Backfill Clicks"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillCoverage',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillCoverage',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:backfillCoverage",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "GAM Backfill Coverage"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillCTR',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillCTR',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:backfillCTR",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "GAM Backfill CTR"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillECPM',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillECPM',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:backfillECPM",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "GAM Backfill eCPM"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillImpressions',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillImpressions',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:backfillImpressions",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "GAM Backfill Impressions"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillImpressionsPerSession',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillImpressionsPerSession',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:backfillImpressionsPerSession",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "GAM Backfill Impressions / Session"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillMonetizedPageviews',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillMonetizedPageviews',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:backfillMonetizedPageviews",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "GAM Backfill Monetized Pageviews"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillRevenue',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillRevenue',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:backfillRevenue",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "GAM Backfill Revenue"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillRevenuePer1000Sessions',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillRevenuePer1000Sessions',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:backfillRevenuePer1000Sessions",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "GAM Backfill Revenue / 1000 Sessions"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillViewableImpressionsPercent',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbackfillViewableImpressionsPercent',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:backfillViewableImpressionsPercent",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "GAM Backfill Viewable Impressions %"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbounceRate',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbounceRate',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:bounceRate",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Bounce Rate"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Abounces',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Abounces',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:bounces",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Bounces"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Abrowser',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Abrowser',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:browser",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Browser"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbrowserSize',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbrowserSize',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:browserSize",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Browser Size"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbrowserVersion',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbrowserVersion',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:browserVersion",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Browser Version"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbuyToDetailRate',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AbuyToDetailRate',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:buyToDetailRate",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Buy-to-Detail Rate"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcalcMetric_%3CNAME%3E',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcalcMetric_%3CNAME%3E',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:calcMetric_<NAME>",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Calculated Metric"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Acampaign',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Acampaign',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:campaign",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Campaign"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcampaignCode',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcampaignCode',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:campaignCode",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Campaign Code"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcartToDetailRate',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcartToDetailRate',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cartToDetailRate",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Cart-to-Detail Rate"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AchannelGrouping',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AchannelGrouping',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:channelGrouping",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Default Channel Grouping"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcheckoutOptions',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcheckoutOptions',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:checkoutOptions",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Checkout Options"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Acity',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Acity',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:city",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "City"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcityId',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcityId',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cityId",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "City ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Acohort',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Acohort',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohort",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Cohort"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortActiveUsers',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortActiveUsers',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortActiveUsers",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Users"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortAppviewsPerUser',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortAppviewsPerUser',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortAppviewsPerUser",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Appviews per User"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortAppviewsPerUserWithLifetimeCriteria',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortAppviewsPerUserWithLifetimeCriteria',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortAppviewsPerUserWithLifetimeCriteria",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Appviews Per User (LTV)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortGoalCompletionsPerUser',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortGoalCompletionsPerUser',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortGoalCompletionsPerUser",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Goal Completions per User"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortGoalCompletionsPerUserWithLifetimeCriteria',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortGoalCompletionsPerUserWithLifetimeCriteria',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortGoalCompletionsPerUserWithLifetimeCriteria",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Goal Completions Per User (LTV)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortNthDay',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortNthDay',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortNthDay",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Day"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortNthMonth',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortNthMonth',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortNthMonth",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Month"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortNthWeek',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortNthWeek',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortNthWeek",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Week"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortPageviewsPerUser',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortPageviewsPerUser',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortPageviewsPerUser",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Pageviews per User"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortPageviewsPerUserWithLifetimeCriteria',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortPageviewsPerUserWithLifetimeCriteria',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortPageviewsPerUserWithLifetimeCriteria",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Pageviews Per User (LTV)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortRetentionRate',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortRetentionRate',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortRetentionRate",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "User Retention"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortRevenuePerUser',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortRevenuePerUser',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortRevenuePerUser",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Revenue per User"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortRevenuePerUserWithLifetimeCriteria',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortRevenuePerUserWithLifetimeCriteria',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortRevenuePerUserWithLifetimeCriteria",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Revenue Per User (LTV)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortSessionDurationPerUser',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortSessionDurationPerUser',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortSessionDurationPerUser",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Session Duration per User"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortSessionDurationPerUserWithLifetimeCriteria',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortSessionDurationPerUserWithLifetimeCriteria',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortSessionDurationPerUserWithLifetimeCriteria",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Session Duration Per User (LTV)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortSessionsPerUser',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortSessionsPerUser',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortSessionsPerUser",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Sessions per User"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortSessionsPerUserWithLifetimeCriteria',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortSessionsPerUserWithLifetimeCriteria',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortSessionsPerUserWithLifetimeCriteria",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Sessions Per User (LTV)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortTotalUsers',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortTotalUsers',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortTotalUsers",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Total Users"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortTotalUsersWithLifetimeCriteria',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcohortTotalUsersWithLifetimeCriteria',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:cohortTotalUsersWithLifetimeCriteria",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Users"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcontentGroupUniqueViewsXX',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcontentGroupUniqueViewsXX',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:contentGroupUniqueViewsXX",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Unique Views XX"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcontentGroupXX',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcontentGroupXX',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:contentGroupXX",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Page Group XX"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Acontinent',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Acontinent',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:continent",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Continent"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcontinentId',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcontinentId',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:continentId",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Continent ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcostPerConversion',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcostPerConversion',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:costPerConversion",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Cost per Conversion"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcostPerGoalConversion',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcostPerGoalConversion',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:costPerGoalConversion",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Cost per Goal Conversion"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcostPerTransaction',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcostPerTransaction',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:costPerTransaction",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Cost per Transaction"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Acountry',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Acountry',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:country",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Country"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcountryIsoCode',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcountryIsoCode',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:countryIsoCode",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Country ISO Code"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3ACPC',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3ACPC',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:CPC",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "CPC"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3ACPM',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3ACPM',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:CPM",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "CPM"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3ACTR',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3ACTR',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:CTR",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "CTR"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcurrencyCode',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcurrencyCode',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:currencyCode",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Currency Code"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcustomVarNameXX',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcustomVarNameXX',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:customVarNameXX",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Custom Variable (Key XX)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcustomVarValueXX',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AcustomVarValueXX',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:customVarValueXX",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Custom Variable (Value XX)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdataSource',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdataSource',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:dataSource",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Data Source"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Adate',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Adate',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:date",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Date"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdateHour',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdateHour',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:dateHour",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Hour of Day"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdateHourMinute',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdateHourMinute',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:dateHourMinute",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Date Hour and Minute"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Aday',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3Aday',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:day",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Day of the month"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdayOfWeek',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdayOfWeek',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:dayOfWeek",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Day of Week"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdayOfWeekName',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdayOfWeekName',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:dayOfWeekName",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Day of Week Name"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdaysSinceLastSession',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdaysSinceLastSession',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:daysSinceLastSession",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Days Since Last Session"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdaysToTransaction',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdaysToTransaction',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:daysToTransaction",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "Days to Transaction"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdbmClickAdvertiser',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdbmClickAdvertiser',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:dbmClickAdvertiser",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "DV360 Advertiser (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdbmClickAdvertiserId',WebTrackingMappingProperty='UA-116478339-8')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappgDimnMsr(WebTrckgMappgExternalField='ga%3AdbmClickAdvertiserId',WebTrackingMappingProperty='UA-116478339-8')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappgDimnMsrType"
			},
			"WebTrckgMappgExternalField": "ga:dbmClickAdvertiserId",
			"WebTrackingMappingProperty": "UA-116478339-8",
			"WebTrckgMappingExtFieldLabel": "DV360 Advertiser ID (GA Model)"
		}]
	};

	var I_MKT_WebTrckgIntactnField = {
		"__count": "37",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('MKT_AgreementExternalID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('MKT_AgreementExternalID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "MKT_AgreementExternalID",
			"WebTrackingMappingField_Text": "Agreement External ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('MKT_AgreementOrigin')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('MKT_AgreementOrigin')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "MKT_AgreementOrigin",
			"WebTrackingMappingField_Text": "Agreement Origin"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionAmount')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionAmount')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionAmount",
			"WebTrackingMappingField_Text": "Amount"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionSourceObjectStatus')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionSourceObjectStatus')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionSourceObjectStatus",
			"WebTrackingMappingField_Text": "Business Document Status Code"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('CampaignID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('CampaignID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "CampaignID",
			"WebTrackingMappingField_Text": "Campaign ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('ReferralSourceCategory')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('ReferralSourceCategory')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "ReferralSourceCategory",
			"WebTrackingMappingField_Text": "Category of a Referral Source"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionCurrency')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionCurrency')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionCurrency",
			"WebTrackingMappingField_Text": "Currency"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionDeviceName')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionDeviceName')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionDeviceName",
			"WebTrackingMappingField_Text": "Device"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('DeviceType')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('DeviceType')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "DeviceType",
			"WebTrackingMappingField_Text": "Device Type"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('DigitalAccount')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('DigitalAccount')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "DigitalAccount",
			"WebTrackingMappingField_Text": "Digital Account ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('DigitalAccountType')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('DigitalAccountType')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "DigitalAccountType",
			"WebTrackingMappingField_Text": "Digital Account Type"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionContactId')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionContactId')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionContactId",
			"WebTrackingMappingField_Text": "Ext. Interaction Contact ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionSourceObject')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionSourceObject')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionSourceObject",
			"WebTrackingMappingField_Text": "Generic Object ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionSourceObjectAddlID')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionSourceObjectAddlID')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionSourceObjectAddlID",
			"WebTrackingMappingField_Text": "Generic Object ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionSourceObjectType')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionSourceObjectType')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionSourceObjectType",
			"WebTrackingMappingField_Text": "Generic Object Type"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionContent')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionContent')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionContent",
			"WebTrackingMappingField_Text": "Interaction Content"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionContentSubject')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionContentSubject')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionContentSubject",
			"WebTrackingMappingField_Text": "Interaction Content Subject"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionReason')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionReason')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionReason",
			"WebTrackingMappingField_Text": "Interaction Reason"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionSentimentValue')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionSentimentValue')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionSentimentValue",
			"WebTrackingMappingField_Text": "Interaction Sentiment"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionStatus')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionStatus')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionStatus",
			"WebTrackingMappingField_Text": "Interaction Status"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionLanguage')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionLanguage')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionLanguage",
			"WebTrackingMappingField_Text": "Language Key"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionLatitude')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionLatitude')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionLatitude",
			"WebTrackingMappingField_Text": "Latitude"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('MarketingLocation')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('MarketingLocation')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "MarketingLocation",
			"WebTrackingMappingField_Text": "Location ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionLongitude')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionLongitude')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionLongitude",
			"WebTrackingMappingField_Text": "Longitude"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('MarketingArea')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('MarketingArea')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "MarketingArea",
			"WebTrackingMappingField_Text": "Marketing Area ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('CampaignContent')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('CampaignContent')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "CampaignContent",
			"WebTrackingMappingField_Text": "Message ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('CampaignContentLinkName')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('CampaignContentLinkName')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "CampaignContentLinkName",
			"WebTrackingMappingField_Text": "Message Link Name"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('MarketingLocationOrigin')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('MarketingLocationOrigin')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "MarketingLocationOrigin",
			"WebTrackingMappingField_Text": "Origin of Marketing Location"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionWeightingFactor')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionWeightingFactor')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionWeightingFactor",
			"WebTrackingMappingField_Text": "Quantifier"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('ReferralSource')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('ReferralSource')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "ReferralSource",
			"WebTrackingMappingField_Text": "Referral Source"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('SourceSystem')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('SourceSystem')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "SourceSystem",
			"WebTrackingMappingField_Text": "Source System ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('SpatialReferenceSystem')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('SpatialReferenceSystem')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "SpatialReferenceSystem",
			"WebTrackingMappingField_Text": "Spatial Reference Identifier"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionSourceTimeStampUTC')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionSourceTimeStampUTC')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionSourceTimeStampUTC",
			"WebTrackingMappingField_Text": "Time Stamp"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionTimeStampUTC')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionTimeStampUTC')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionTimeStampUTC",
			"WebTrackingMappingField_Text": "Time Stamp"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionIsAnonymous')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionIsAnonymous')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionIsAnonymous",
			"WebTrackingMappingField_Text": "TRUE"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('CampaignContentLinkURL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('CampaignContentLinkURL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "CampaignContentLinkURL",
			"WebTrackingMappingField_Text": "Uniform Resource Identifier"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionSourceDataURL')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgIntactnField('InteractionSourceDataURL')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgIntactnFieldType"
			},
			"WebTrackingMappingField": "InteractionSourceDataURL",
			"WebTrackingMappingField_Text": "Uniform Resource Identifier"
		}]
	};

	var I_MKT_WebTrckgMappingDimn = {
		"__count": "270",
		"results": [{
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AacquisitionCampaign',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AacquisitionCampaign',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:acquisitionCampaign",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Acquisition Campaign"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AacquisitionMedium',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AacquisitionMedium',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:acquisitionMedium",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Acquisition Medium"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AacquisitionSource',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AacquisitionSource',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:acquisitionSource",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Acquisition Source"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AacquisitionSourceMedium',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AacquisitionSourceMedium',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:acquisitionSourceMedium",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Acquisition Source / Medium"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AacquisitionTrafficChannel',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AacquisitionTrafficChannel',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:acquisitionTrafficChannel",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Acquisition Channel"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadContent',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadContent',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adContent",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Ad Content"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadDestinationUrl',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadDestinationUrl',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adDestinationUrl",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Destination URL"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadDisplayUrl',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadDisplayUrl',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adDisplayUrl",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Display URL"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadDistributionNetwork',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadDistributionNetwork',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adDistributionNetwork",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Ad Distribution Network"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadFormat',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadFormat',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adFormat",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Ad Format"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadGroup',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadGroup',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adGroup",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Google Ads: Ad Group"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadKeywordMatchType',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadKeywordMatchType',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adKeywordMatchType",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Keyword Match Type"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadMatchedQuery',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadMatchedQuery',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adMatchedQuery",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Search Query"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadMatchType',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadMatchType',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adMatchType",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Query Match Type"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadPlacementDomain',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadPlacementDomain',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adPlacementDomain",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Placement Domain"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadPlacementUrl',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadPlacementUrl',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adPlacementUrl",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Placement URL"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadQueryWordCount',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadQueryWordCount',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adQueryWordCount",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Query Word Count"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadSlot',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadSlot',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adSlot",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Google Ads: Ad Slot"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadTargetingOption',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadTargetingOption',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adTargetingOption",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Placement Type"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadTargetingType',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadTargetingType',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adTargetingType",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Targeting Type"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadwordsAdGroupID',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadwordsAdGroupID',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adwordsAdGroupID",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Google Ads Ad Group ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadwordsCampaignID',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadwordsCampaignID',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adwordsCampaignID",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Google Ads Campaign ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadwordsCreativeID',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadwordsCreativeID',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adwordsCreativeID",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Google Ads Creative ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadwordsCriteriaID',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadwordsCriteriaID',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adwordsCriteriaID",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Google Ads Criteria ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadwordsCustomerID',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AadwordsCustomerID',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:adwordsCustomerID",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Google Ads Customer ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Aaffiliation',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Aaffiliation',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:affiliation",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Affiliation"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AappId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AappId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:appId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "App ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AappInstallerId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AappInstallerId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:appInstallerId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "App Installer ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AappName',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AappName',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:appName",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "App Name"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AappVersion',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AappVersion',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:appVersion",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "App Version"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Abrowser',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Abrowser',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:browser",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Browser"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AbrowserSize',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AbrowserSize',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:browserSize",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Browser Size"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AbrowserVersion',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AbrowserVersion',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:browserVersion",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Browser Version"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Acampaign',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Acampaign',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:campaign",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Campaign"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcampaignCode',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcampaignCode',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:campaignCode",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Campaign Code"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AchannelGrouping',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AchannelGrouping',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:channelGrouping",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Default Channel Grouping"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcheckoutOptions',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcheckoutOptions',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:checkoutOptions",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Checkout Options"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Acity',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Acity',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:city",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "City"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcityId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcityId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:cityId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "City ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Acohort',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Acohort',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:cohort",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Cohort"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcohortNthDay',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcohortNthDay',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:cohortNthDay",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Day"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcohortNthMonth',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcohortNthMonth',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:cohortNthMonth",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Month"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcohortNthWeek',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcohortNthWeek',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:cohortNthWeek",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Week"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcontentGroupXX',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcontentGroupXX',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:contentGroupXX",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Page Group XX"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Acontinent',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Acontinent',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:continent",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Continent"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcontinentId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcontinentId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:continentId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Continent ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Acountry',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Acountry',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:country",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Country"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcountryIsoCode',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcountryIsoCode',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:countryIsoCode",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Country ISO Code"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcurrencyCode',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcurrencyCode',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:currencyCode",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Currency Code"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcustomVarNameXX',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcustomVarNameXX',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:customVarNameXX",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Custom Variable (Key XX)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcustomVarValueXX',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AcustomVarValueXX',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:customVarValueXX",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Custom Variable (Value XX)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdataSource',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdataSource',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dataSource",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Data Source"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Adate',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Adate',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:date",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Date"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdateHour',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdateHour',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dateHour",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Hour of Day"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdateHourMinute',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdateHourMinute',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dateHourMinute",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Date Hour and Minute"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Aday',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Aday',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:day",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Day of the month"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdayOfWeek',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdayOfWeek',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dayOfWeek",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Day of Week"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdayOfWeekName',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdayOfWeekName',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dayOfWeekName",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Day of Week Name"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdaysSinceLastSession',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdaysSinceLastSession',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:daysSinceLastSession",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Days Since Last Session"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdaysToTransaction',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdaysToTransaction',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:daysToTransaction",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Days to Transaction"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickAdvertiser',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickAdvertiser',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmClickAdvertiser",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Advertiser (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickAdvertiserId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickAdvertiserId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmClickAdvertiserId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Advertiser ID (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickCreativeId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickCreativeId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmClickCreativeId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Creative ID (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickExchange',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickExchange',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmClickExchange",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Exchange (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickExchangeId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickExchangeId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmClickExchangeId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Exchange ID (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickInsertionOrder',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickInsertionOrder',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmClickInsertionOrder",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Insertion Order (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickInsertionOrderId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickInsertionOrderId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmClickInsertionOrderId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Insertion Order ID (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickLineItem',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickLineItem',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmClickLineItem",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Line Item NAME (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickLineItemId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickLineItemId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmClickLineItemId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Line Item ID (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickSite',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickSite',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmClickSite",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Site (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickSiteId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmClickSiteId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmClickSiteId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Site ID (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventAdvertiser',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventAdvertiser',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmLastEventAdvertiser",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Advertiser (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventAdvertiserId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventAdvertiserId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmLastEventAdvertiserId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Advertiser ID (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventCreativeId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventCreativeId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmLastEventCreativeId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Creative ID (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventExchange',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventExchange',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmLastEventExchange",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Exchange (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventExchangeId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventExchangeId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmLastEventExchangeId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Exchange ID (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventInsertionOrder',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventInsertionOrder',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmLastEventInsertionOrder",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Insertion Order (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventInsertionOrderId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventInsertionOrderId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmLastEventInsertionOrderId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Insertion Order ID (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventLineItem',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventLineItem',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmLastEventLineItem",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Line Item (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventLineItemId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventLineItemId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmLastEventLineItemId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Line Item ID (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventSite',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventSite',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmLastEventSite",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Site (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventSiteId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdbmLastEventSiteId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dbmLastEventSiteId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "DV360 Site ID (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickAd',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickAd',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickAd",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Ad (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickAdId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickAdId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickAdId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Ad ID (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickAdType',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickAdType',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickAdType",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Ad Type (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickAdTypeId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickAdTypeId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickAdTypeId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Ad Type ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickAdvertiser',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickAdvertiser',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickAdvertiser",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Advertiser (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickAdvertiserId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickAdvertiserId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickAdvertiserId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Advertiser ID (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickCampaign',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickCampaign',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickCampaign",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Campaign (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickCampaignId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickCampaignId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickCampaignId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Campaign ID (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickCreative',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickCreative',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickCreative",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Creative (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickCreativeId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickCreativeId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickCreativeId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Creative ID (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickCreativeType',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickCreativeType',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickCreativeType",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Creative Type (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickCreativeTypeId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickCreativeTypeId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickCreativeTypeId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Creative Type ID (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickCreativeVersion',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickCreativeVersion',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickCreativeVersion",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Creative Version (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickRenderingId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickRenderingId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickRenderingId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Rendering ID (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickSite',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickSite',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickSite",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Site (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickSiteId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickSiteId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickSiteId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Site ID (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickSitePlacement',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickSitePlacement',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickSitePlacement",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Placement (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickSitePlacementId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickSitePlacementId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickSitePlacementId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Placement ID (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickSpotId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmClickSpotId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmClickSpotId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Floodlight Configuration ID (GA Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmFloodlightActivity',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmFloodlightActivity',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmFloodlightActivity",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Activity"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmFloodlightActivityAndGroup',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmFloodlightActivityAndGroup',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmFloodlightActivityAndGroup",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Activity and Group"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmFloodlightActivityGroup',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmFloodlightActivityGroup',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmFloodlightActivityGroup",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Activity Group"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmFloodlightActivityGroupId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmFloodlightActivityGroupId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmFloodlightActivityGroupId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Activity Group ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmFloodlightActivityId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmFloodlightActivityId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmFloodlightActivityId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Activity ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmFloodlightAdvertiserId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmFloodlightAdvertiserId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmFloodlightAdvertiserId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Advertiser ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmFloodlightSpotId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmFloodlightSpotId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmFloodlightSpotId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Floodlight Configuration ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventAd',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventAd',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventAd",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Ad"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventAdId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventAdId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventAdId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Ad ID (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventAdType',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventAdType',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventAdType",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Ad Type (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventAdTypeId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventAdTypeId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventAdTypeId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Ad Type ID (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventAdvertiser',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventAdvertiser',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventAdvertiser",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Advertiser (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventAdvertiserId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventAdvertiserId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventAdvertiserId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Advertiser ID (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventAttributionType',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventAttributionType',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventAttributionType",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Attribution Type (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventCampaign',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventCampaign',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventCampaign",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Campaign (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventCampaignId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventCampaignId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventCampaignId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Campaign ID (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventCreative',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventCreative',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventCreative",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Creative (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventCreativeId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventCreativeId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventCreativeId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Creative ID (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventCreativeType',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventCreativeType',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventCreativeType",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Creative Type (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventCreativeTypeId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventCreativeTypeId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventCreativeTypeId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Creative Type ID (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventCreativeVersion',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventCreativeVersion',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventCreativeVersion",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Creative Version (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventRenderingId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventRenderingId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventRenderingId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Rendering ID (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventSite',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventSite',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventSite",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Site (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventSiteId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventSiteId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventSiteId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Site ID (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventSitePlacement',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventSitePlacement',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventSitePlacement",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Placement (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventSitePlacementId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventSitePlacementId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventSitePlacementId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Placement ID (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventSpotId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdcmLastEventSpotId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dcmLastEventSpotId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "CM Floodlight Configuration ID (CM Model)"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdeviceCategory',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdeviceCategory',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:deviceCategory",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Device Category"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdfpLineItemId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdfpLineItemId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dfpLineItemId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "GAM Line Item Id"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdfpLineItemName',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdfpLineItemName',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dfpLineItemName",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "GAM Line Item Name"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Adimension1',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Adimension1',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dimension1",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "yClientID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Adimension2',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Adimension2',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dimension2",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "ySessionID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Adimension3',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Adimension3',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dimension3",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "yHitTimestamp"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Adimension4',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Adimension4',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dimension4",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "yUserID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Adimension5',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3Adimension5',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dimension5",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "rd Custom Dimension Test"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdimensionXX',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdimensionXX',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dimensionXX",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "Custom Dimension XX"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdsAdGroup',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdsAdGroup',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dsAdGroup",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "SA360 Ad Group"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdsAdGroupId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdsAdGroupId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dsAdGroupId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "SA360 Ad Group ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdsAdvertiser',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdsAdvertiser',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dsAdvertiser",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "SA360 Advertiser"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdsAdvertiserId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdsAdvertiserId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dsAdvertiserId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "SA360 Advertiser ID"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdsAgency',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdsAgency',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dsAgency",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "SA360 Agency"
		}, {
			"__metadata": {
				"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdsAgencyId',WebTrackingMappingProperty='UA-116478339-2')",
				"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/I_MKT_WebTrckgMappingDimn(WebTrckgMappgExternalField='ga%3AdsAgencyId',WebTrackingMappingProperty='UA-116478339-2')",
				"type": "CUAN_WEB_TRACKING_MAPPING_SRV.I_MKT_WebTrckgMappingDimnType"
			},
			"WebTrckgMappgExternalField": "ga:dsAgencyId",
			"WebTrackingMappingProperty": "UA-116478339-2",
			"WebTrckgMappingExtFieldLabel": "SA360 Agency ID"
		}]
	};

	function _getI_MKT_WebTrckgIntactnFldVH() {
		return I_MKT_WebTrckgIntactnFldVH;
	}

	function _getI_MKT_WebTrckgMappgDimnMsr() {
		return I_MKT_WebTrckgMappgDimnMsr;
	}

	function _getI_MKT_WebTrckgIntactnField() {
		return I_MKT_WebTrckgIntactnField;
	}

	function _getI_MKT_WebTrckgMappingDimn() {
		return I_MKT_WebTrckgMappingDimn;
	}
	///////
	function _getI_MKT_InteractionProductStatus() {
		return I_MKT_InteractionProductStatus;
	}

	function _getI_UnitOfMeasure() {
		return I_UnitOfMeasure;
	}

	function _getI_MKT_LocationOrigin() {
		return I_MKT_LocationOrigin;
	}

	function _getI_MKT_InteractionStatus() {
		return I_MKT_InteractionStatus;
	}

	function _getI_MKT_InteractionSentiment() {
		return I_MKT_InteractionSentiment;
	}

	function _getI_MKT_DigitalAccountType() {
		return I_MKT_DigitalAccountType;
	}

	function _getI_MKT_AgreementOrigin() {
		return I_MKT_AgreementOrigin;
	}

	function _getI_Language() {
		return I_Language;
	}

	function _getI_Currency() {
		return I_Currency;
	}

	function _getI_MKT_DeviceType() {
		return I_MKT_DeviceType;
	}

	function _getI_MKT_ProductOrigin() {
		return I_MKT_ProductOrigin;
	}

	function _getI_MKT_ActiveMarketingArea() {
		return I_MKT_ActiveMarketingArea;
	}

	function _getI_MKT_Contactorigin() {
		return I_MKT_Contactorigin;
	}

	function _getI_MKT_CommMedium() {
		return I_MKT_CommMedium;
	}

	function _getI_MKT_InteractionType() {
		return I_MKT_InteractionType;
	}

	return {
		getI_MKT_WebTrckgIntactnFldVH: _getI_MKT_WebTrckgIntactnFldVH,
		getI_MKT_WebTrckgMappgDimnMsr: _getI_MKT_WebTrckgMappgDimnMsr,
		getI_MKT_WebTrckgIntactnField: _getI_MKT_WebTrckgIntactnField,
		getI_MKT_WebTrckgMappingDimn: _getI_MKT_WebTrckgMappingDimn,
		getI_MKT_InteractionProductStatus: _getI_MKT_InteractionProductStatus,
		getI_UnitOfMeasure: _getI_UnitOfMeasure,
		getI_MKT_LocationOrigin: _getI_MKT_LocationOrigin,
		getI_MKT_InteractionStatus: _getI_MKT_InteractionStatus,
		getI_MKT_InteractionSentiment: _getI_MKT_InteractionSentiment,
		getI_MKT_DigitalAccountType: _getI_MKT_DigitalAccountType,
		getI_MKT_AgreementOrigin: _getI_MKT_AgreementOrigin,
		getI_Language: _getI_Language,
		getI_Currency: _getI_Currency,
		getI_MKT_DeviceType: _getI_MKT_DeviceType,
		getI_MKT_ProductOrigin: _getI_MKT_ProductOrigin,
		getI_MKT_ActiveMarketingArea: _getI_MKT_ActiveMarketingArea,
		getI_MKT_Contactorigin: _getI_MKT_Contactorigin,
		getI_MKT_CommMedium: _getI_MKT_CommMedium,
		getI_MKT_InteractionType: _getI_MKT_InteractionType
	};

});