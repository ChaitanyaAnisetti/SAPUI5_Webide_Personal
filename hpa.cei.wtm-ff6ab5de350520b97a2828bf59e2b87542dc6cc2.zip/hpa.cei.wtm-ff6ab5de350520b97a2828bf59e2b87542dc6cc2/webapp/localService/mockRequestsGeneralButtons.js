sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/util/MockServer",
	"./mockHelper",
	"./mockRequestsInteractionFields"

], function (jQuery, MockServer, MockHelper, MockRequestsInteractionFields) {

	//this one is to know if the edit operation was completed (saved)
	var isEdit = false,
		//this is the part that intercepts when a draft is created and we are returning on the ListObject page.
		isDraft = false,
		//this will intercept the copy action to change the values in the array before sending it to the backend
		isCopy = false,
		//counter giving new UUIDs to the next objects
		counter = 100,
		//this variable is used for handling the weird GUID that the backend sends. This is because I have not handled myself all of the edit
		//button functionality
		capturedUUIDIndex = -1;

	//this will be used to know which object is concerned
	function findIndexByUUID(oMockServer, uuid) {
		var aEntitySetData = oMockServer.getEntitySetData("C_MKT_WebTrackingMappingTP");

		for (var i = 0; i < aEntitySetData.length; i++) {
			if (aEntitySetData[i].WebTrackingMappingUUID === (uuid)) {
				return i;
			}
		}
		return false;
	}

	//this will be used to know which object is concerned
	function findByUUID(oMockServer, uuid) {
		var aEntitySetData = oMockServer.getEntitySetData("C_MKT_WebTrackingMappingTP");

		for (var i = 0; i < aEntitySetData.length; i++) {
			if (aEntitySetData[i].WebTrackingMappingUUID === (uuid)) {
				return aEntitySetData[i];
			}
		}
		return false;
	}

	function _addGeneralButtonsRequests(oMockServer, aRequests) {

		//NOTE : This request is not handled. This is because before making an object appear, there
		//are certain object manipulations that must be made for the Edit button to see the proper
		//information.
		aRequests.push({
			method: "GET",
			path: new RegExp("C_MKT_WebTrackingMappingTP.*WebTrackingMappingUUID=guid.*expand=DraftAdministrativeData.*"),
			response: function (oXhr) {

				var urlSplit = oXhr.url.split("\'");
				//taking the guid, which is inside of the ''
				var guid = urlSplit[1];
				//note: the UUID in this case matches the index where the object is located for simplicity
				var aEntitySetData = oMockServer.getEntitySetData("C_MKT_WebTrackingMappingTP"),
					overwrittenObject;
				//the object has been saved, and this condition has been risen
				if (isEdit) {
					isEdit = false;

					//find the index of the updated object
					for (var i = 1; i < aEntitySetData.length; i++) {
						if (aEntitySetData[i].WebTrackingMappingName === aEntitySetData[0].WebTrackingMappingName) {
							aEntitySetData[i] = aEntitySetData[0];
							break;
						}
					}
					aEntitySetData.splice(0, 1);
					//kept on getting DraftAdministrativeData was missing: forced all of the objects to have that parameter reset.
					for (i = 0; i < aEntitySetData.length; i++) {
						aEntitySetData[i].DraftAdministrativeData = {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
									"',IsActiveEntity=true)/DraftAdministrativeData"
							}
						};
					}
					oMockServer.setEntitySetData("C_MKT_WebTrackingMappingTP", aEntitySetData);
				}

				//the object is in draft mode: it has not yet been saved.
				if (isDraft) {
					isDraft = false;

					//change the object's UUID, because the Edit function relies on the backend. Here, every parameters relative to the
					//object must change UUID.
					aEntitySetData[capturedUUIDIndex].WebTrackingMappingUUID = guid;
					/*var resultsInteractionFields = MockRequestsInteractionFields.getInteractionFields();
					resultsInteractionFields[capturedUUIDIndex].uuid = guid;
					MockRequestsInteractionFields.setInteractionFields(resultsInteractionFields);*/

					//swap draftObject position with position 0, as position 0 will get overwritten when pressing save
					overwrittenObject = aEntitySetData[0];
					aEntitySetData[0] = aEntitySetData[aEntitySetData.length - 1];
					aEntitySetData[aEntitySetData.length - 1] = overwrittenObject;

					//kept on getting DraftAdministrativeData was missing: forced all of the objects to have that parameter reset.
					for (i = 0; i < aEntitySetData.length; i++) {
						aEntitySetData[i].DraftAdministrativeData = {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
									"',IsActiveEntity=true)/DraftAdministrativeData"
							}
						};
					}
					oMockServer.setEntitySetData("C_MKT_WebTrackingMappingTP", aEntitySetData);
				}

				//the object is being copied
				if (isCopy) {
					isCopy = false;

					//aEntitySetData.push(copiedObject);
					//swap copy object position with position 0, as position 0 will get overwritten when pressing save
					overwrittenObject = aEntitySetData[0];
					aEntitySetData[0] = aEntitySetData[aEntitySetData.length - 1];
					aEntitySetData[aEntitySetData.length - 1] = overwrittenObject;

					//kept on getting DraftAdministrativeData was missing: forced all of the objects to have that parameter reset.
					for (i = 0; i < aEntitySetData.length; i++) {
						aEntitySetData[i].DraftAdministrativeData = {
							"__deferred": {
								"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
									"',IsActiveEntity=true)/DraftAdministrativeData"
							}
						};
					}
					oMockServer.setEntitySetData("C_MKT_WebTrackingMappingTP", aEntitySetData);

				}

				MockRequestsInteractionFields.resetIsAdded();

			}
		});

		//-------------------------------------------------------------------------------------------------------------------------------------
		//																Object Page General Buttons
		//-------------------------------------------------------------------------------------------------------------------------------------

		//to capture the copy action
		aRequests.push({
			method: "POST",
			path: "C_MKT_WebTrackingMappingTPCopy?.*",
			response: function (oXhr) {
				var urlSplit = oXhr.url.split("\'");
				//taking the guid, which is inside of the ''
				var guid = urlSplit[1];
				//get the element by UUID
				var object = findByUUID(oMockServer, guid);

				var oNewEntity = jQuery.extend(true, {}, object);
				oNewEntity.WebTrackingMappingName = "Copy of " + object.WebTrackingMappingName;
				oNewEntity.WebTrackingMappingUUID = counter.toString(10);
				//Then I need to change everything relating to the initial UUID.
				oNewEntity.__metadata.id =
					"/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + counter.toString(10) +
					"',IsActiveEntity=true)";
				oNewEntity.__metadata.uri =
					"/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + counter.toString(10) +
					"',IsActiveEntity=true)";
				oNewEntity.DraftAdministrativeData = {
					"__deferred": {
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + counter.toString(
							10) + "',IsActiveEntity=true)/DraftAdministrativeData"
					}
				};
				oNewEntity.SiblingEntity = {
					"__deferred": {
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + counter.toString(
							10) + "',IsActiveEntity=true)/SiblingEntity"
					}
				};
				oNewEntity.to_WebTrckgMappgProject = {
					"__deferred": {
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + counter.toString(
							10) + "',IsActiveEntity=true)/to_WebTrckgMappgProject"
					}
				};
				oNewEntity.to_WebTrckgMappgDataTable = {
					"__deferred": {
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + counter.toString(
							10) + "',IsActiveEntity=true)/to_WebTrckgMappgDataTable"
					}
				};
				oNewEntity.to_WebTrckgMappgStatus = {
					"__deferred": {
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + counter.toString(
							10) + "',IsActiveEntity=true)/to_WebTrckgMappgStatus"
					}
				};
				oNewEntity.IsActiveEntity = true;

				//MockHelper.addEntity(oMockServer, "C_MKT_WebTrackingMappingTP", oNewEntity);

				var aEntitySetData = oMockServer.getEntitySetData("C_MKT_WebTrackingMappingTP");
				//copiedObject = oNewEntity;
				aEntitySetData.push(oNewEntity);
				aEntitySetData[findIndexByUUID(oMockServer, guid)].IsActiveEntity = true;
				oMockServer.setEntitySetData("C_MKT_WebTrackingMappingTP", aEntitySetData);

				//create a new set of interaction fields. make sure uuid is OK
				var newInteractionFields = {
					"__count": "1",
					"uuid": counter.toString(10),
					"results": [{
						"__metadata": {
							"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'1000004',IsActiveEntity=true)",
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgValMappingTP(WebTrckgValueMappgUUID=guid'" +
								"1000004" +
								"',IsActiveEntity=true)",
							"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgValMappingTPType"
						},
						"WebTrackingMappingField_fc": 1,
						"Delete_mc": true,
						"WebTrckgValueMappgUUID": "1000004",
						"WebTrackingMappingField": "InteractionType",
						"WebTrckgMappingFieldLabel": "",
						"WebTrckgMappingFieldValue": "SHOP_ITEM_ADD",
						"WebTrckgMappgValFldSortPos": 0,
						"HasDraftEntity": false,
						"HasActiveEntity": false,
						"IsActiveEntity": true
					}]
				};

				MockRequestsInteractionFields.addSetOfInteractionFields(newInteractionFields);

				isCopy = true;
				counter++;

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntity
				}));
				return true;
			}
		});

		//to capture the deactivate action. NOT FLEXIBLE?
		aRequests.push({
			method: "POST",
			path: "C_MKT_WebTrackingMappingTPDeactivate?.*",
			response: function (oXhr) {
				var urlSplit = oXhr.url.split("\'");
				//taking the guid, which is inside of the ''
				var guid = urlSplit[1];
				var intGuid = findIndexByUUID(oMockServer, guid);

				//this gets the json file
				var aEntitySetData = oMockServer.getEntitySetData("C_MKT_WebTrackingMappingTP");
				//modifies it to the file.
				//aEntitySetData[1]=oNewEntityData;

				aEntitySetData[intGuid].Copy_ac = true;
				aEntitySetData[intGuid].Edit_ac = true;
				aEntitySetData[intGuid].Validate_ac = true;
				aEntitySetData[intGuid].Delete_mc = true;
				aEntitySetData[intGuid].Update_mc = true;
				aEntitySetData[intGuid].Deactivate_ac = false;
				aEntitySetData[intGuid].WebTrackingMappingStatus = "";
				aEntitySetData[intGuid].to_WebTrckgMappgStatus.WebTrackingMappingStatus = "";
				aEntitySetData[intGuid].to_WebTrckgMappgStatus.WebTrackingMappingStatus_Text = "Inactive";
				//kept on getting DraftAdministrativeData was missing: forced all of the objects to have that parameter reset.
				for (var i = 0; i < aEntitySetData.length; i++) {
					aEntitySetData[i].DraftAdministrativeData = {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/DraftAdministrativeData"
						}
					};
				}

				oMockServer.setEntitySetData("C_MKT_WebTrackingMappingTP", aEntitySetData);
				//oMockServer._enhanceWithMetadata(oMockServer._mEntitySets[sEntitySetName], oMockServer._oMockdata[sEntitySetName]);

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": aEntitySetData[0]
				}));

				//return true to indicate the request is processed
				return true;

			}
		});

		//to capture the activate action. NOT FLEXIBLE?
		aRequests.push({
			method: "POST",
			path: "C_MKT_WebTrackingMappingTPActivate?.*",
			response: function (oXhr, sUrlParams) {
				var urlSplit = oXhr.url.split("\'");
				//taking the guid, which is inside of the ''
				var guid = urlSplit[1];
				var intGuid = findIndexByUUID(oMockServer, guid);

				//this gets the json file
				var aEntitySetData = oMockServer.getEntitySetData("C_MKT_WebTrackingMappingTP");

				aEntitySetData[intGuid].Activate_ac = false;
				aEntitySetData[intGuid].Edit_ac = false;
				aEntitySetData[intGuid].Validate_ac = false;
				aEntitySetData[intGuid].Delete_mc = false;
				aEntitySetData[intGuid].Deactivate_ac = true;
				aEntitySetData[intGuid].WebTrackingMappingStatus = "A";
				aEntitySetData[intGuid].to_WebTrckgMappgStatus.WebTrackingMappingStatus = "A";
				aEntitySetData[intGuid].to_WebTrckgMappgStatus.WebTrackingMappingStatus_Text = "Active";
				//kept on getting DraftAdministrativeData was missing: forced all of the objects to have that parameter reset.
				for (var i = 0; i < aEntitySetData.length; i++) {
					aEntitySetData[i].DraftAdministrativeData = {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/DraftAdministrativeData"
						}
					};
				}

				oMockServer.setEntitySetData("C_MKT_WebTrackingMappingTP", aEntitySetData);

				oXhr.respond(200, {
					"Content-type": "application/json"
				}, JSON.stringify({
					"d": aEntitySetData[0]
				}));

				//return true to indicate the request is processed
				return true;

			}
		});

		//to capture the edit action on save.
		aRequests.push({
			method: "POST",
			path: "C_MKT_WebTrackingMappingTPPreparation.*",
			response: function (oXhr, sUrlParams) {

				var urlSplit = oXhr.url.split("\'");
				//taking the guid, which is inside of the ''
				var guid = urlSplit[1];
				var intGuid = findIndexByUUID(oMockServer, guid);

				//this gets the json file
				var aEntitySetData = oMockServer.getEntitySetData("C_MKT_WebTrackingMappingTP");

				var oNewEntityData = {
					"__metadata": {
						"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
							"',IsActiveEntity=false)",
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
							"',IsActiveEntity=false)",
						"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrackingMappingTPType"
					},
					"Activate_ac": false,
					"Activation_ac": true,
					"Clear_filter_ac": true,
					"Copy_ac": true,
					"Deactivate_ac": false,
					"Edit_ac": false,
					"Preparation_ac": true,
					"Validate_ac": true,
					"Validation_ac": true,
					"WebTrackingMappingDataSource_fc": 1,
					"WebTrackingMappingDataTable_fc": 1,
					"WebTrackingMappingName_fc": 1,
					"WebTrackingMappingProject_fc": 1,
					"WebTrackingMappingProperty_fc": 1,
					"WebTrackingMappingView_fc": 1,
					"Delete_mc": true,
					"Update_mc": true,
					"WebTrackingMappingUUID": "" + guid + "",
					"WebTrackingMappingName": aEntitySetData[intGuid].WebTrackingMappingName,
					"WebTrackingMappingStatus": "",
					"WebTrckgMappgStatusCriticality": 0,
					"WebTrackingMappingProject": "",
					"WebTrackingMappingDataTable": "",
					"WebTrackingMappingProperty": "UA-116478339-3",
					"WebTrackingMappingView": "179257477",
					"WebTrackingMappingType": "I",
					"WebTrackingMappingDataSource": "A",
					"WebTrackingMappingRetrievalStr": "",
					"WebTrackingMappingFilterString": "",
					"WebTrckgComMappgCreateIsEnbld": true,
					"HasDraftEntity": false,
					"ActiveUUID": "" + guid + "",
					"DraftEntityCreationDateTime": "\/Date(1549461711153+0000)\/",
					"DraftEntityLastChangeDateTime": "\/Date(1549461734565+0000)\/",
					"HasActiveEntity": true,
					"IsActiveEntity": false,
					"DraftAdministrativeData": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/DraftAdministrativeData"
						}
					},
					"SiblingEntity": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/SiblingEntity"
						}
					},
					"to_WebTrackingMappgType": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrackingMappgType"
						}
					},
					"to_WebTrackingMappgView": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrackingMappgView"
						}
					},
					"to_WebTrckgComMapping": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgComMapping"
						}
					},
					"to_WebTrckgMappgDataSrce": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgDataSrce"
						}
					},
					"to_WebTrckgMappgDataTable": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgDataTable"
						}
					},
					"to_WebTrckgMappgFltr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgFltr"
						}
					},
					"to_WebTrckgMappgProject": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgProject"
						}
					},
					"to_WebTrckgMappgProperty": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgProperty"
						}
					},
					"to_WebTrckgMappgStatus": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgStatus"
						}
					},
					"to_WebTrckgMappingLog": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappingLog"
						}
					},
					"to_WebTrckgRtrvlIaHdr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgRtrvlIaHdr"
						}
					},
					"to_WebTrckgRtrvlProdHdr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgRtrvlProdHdr"
						}
					},
					"to_WebTrckgRtrvlTagHdr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgRtrvlTagHdr"
						}
					},
					"to_WebTrckgValMapping": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgValMapping"
						}
					}
				};

				aEntitySetData[intGuid] = oNewEntityData;

				//set DraftAdministrativeData because it seems to disappear on every modification of the json...
				for (var i = 0; i < aEntitySetData.length; i++) {
					aEntitySetData[i].DraftAdministrativeData = {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + i.toString() +
								"',IsActiveEntity=true)/DraftAdministrativeData"
						}
					};
				}

				oMockServer.setEntitySetData("C_MKT_WebTrackingMappingTP", aEntitySetData);

				oXhr.respond(200, {
					"Content-type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});

		//to capture the edit action on save when gets activated again (right after preparation)
		aRequests.push({
			method: "POST",
			path: new RegExp("C_MKT_WebTrackingMappingTPActivation.*"),
			response: function (oXhr) {

				var urlSplit = oXhr.url.split("\'");
				//taking the guid, which is inside of the ''
				var guid = urlSplit[1];
				var intGuid = findIndexByUUID(oMockServer, guid);

				//this gets the json file
				var aEntitySetData = oMockServer.getEntitySetData("C_MKT_WebTrackingMappingTP");

				var oNewEntityData = {
					"__metadata": {
						"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
							"',IsActiveEntity=true)",
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
							"',IsActiveEntity=true)",
						"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrackingMappingTPType"
					},
					"Activate_ac": false,
					"Activation_ac": false,
					"Clear_filter_ac": true,
					"Copy_ac": true,
					"Deactivate_ac": false,
					"Edit_ac": true,
					"Preparation_ac": false,
					"Validate_ac": true,
					"Validation_ac": false,
					"WebTrackingMappingDataSource_fc": 1,
					"WebTrackingMappingDataTable_fc": 1,
					"WebTrackingMappingName_fc": 1,
					"WebTrackingMappingProject_fc": 1,
					"WebTrackingMappingProperty_fc": 1,
					"WebTrackingMappingView_fc": 1,
					"Delete_mc": true,
					"Update_mc": true,
					"WebTrackingMappingUUID": "" + guid + "",
					"WebTrackingMappingName": aEntitySetData[intGuid].WebTrackingMappingName,
					"WebTrackingMappingStatus": "",
					"WebTrckgMappgStatusCriticality": 0,
					"WebTrackingMappingProject": "",
					"WebTrackingMappingDataTable": "",
					"WebTrackingMappingProperty": "UA-116478339-3",
					"WebTrackingMappingView": "179257477",
					"WebTrackingMappingType": "I",
					"WebTrackingMappingDataSource": "A",
					"WebTrackingMappingRetrievalStr": "",
					"WebTrackingMappingFilterString": "",
					"WebTrckgComMappgCreateIsEnbld": true,
					"HasDraftEntity": false,
					"ActiveUUID": "00000000-0000-0000-0000-000000000000",
					"DraftEntityCreationDateTime": null,
					"DraftEntityLastChangeDateTime": null,
					"HasActiveEntity": false,
					"IsActiveEntity": true,
					"DraftAdministrativeData": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/DraftAdministrativeData"
						}
					},
					"SiblingEntity": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/SiblingEntity"
						}
					},
					"to_WebTrackingMappgType": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/to_WebTrackingMappgType"
						}
					},
					"to_WebTrackingMappgView": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/to_WebTrackingMappgView"
						}
					},
					"to_WebTrckgComMapping": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/to_WebTrckgComMapping"
						}
					},
					"to_WebTrckgMappgDataSrce": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/to_WebTrckgMappgDataSrce"
						}
					},
					"to_WebTrckgMappgDataTable": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/to_WebTrckgMappgDataTable"
						}
					},
					"to_WebTrckgMappgFltr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/to_WebTrckgMappgFltr"
						}
					},
					"to_WebTrckgMappgProject": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/to_WebTrckgMappgProject"
						}
					},
					"to_WebTrckgMappgProperty": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/to_WebTrckgMappgProperty"
						}
					},
					"to_WebTrckgMappgStatus": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/to_WebTrckgMappgStatus"
						}
					},
					"to_WebTrckgMappingLog": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/to_WebTrckgMappingLog"
						}
					},
					"to_WebTrckgRtrvlIaHdr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/to_WebTrckgRtrvlIaHdr"
						}
					},
					"to_WebTrckgRtrvlProdHdr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/to_WebTrckgRtrvlProdHdr"
						}
					},
					"to_WebTrckgRtrvlTagHdr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/to_WebTrckgRtrvlTagHdr"
						}
					},
					"to_WebTrckgValMapping": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/to_WebTrckgValMapping"
						}
					}
				};

				//showing it is currently handling the edit config
				isEdit = true;
				//this gets the json file
				aEntitySetData = oMockServer.getEntitySetData("C_MKT_WebTrackingMappingTP");
				aEntitySetData[intGuid] = oNewEntityData;

				//set DraftAdministrativeData because it seems to disappear on every modification of the json...
				for (var i = 0; i < aEntitySetData.length; i++) {
					aEntitySetData[i].DraftAdministrativeData = {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + i.toString() +
								"',IsActiveEntity=true)/DraftAdministrativeData"
						}
					};
				}

				oMockServer.setEntitySetData("C_MKT_WebTrackingMappingTP", aEntitySetData);

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});

		//to capture the validate action
		aRequests.push({
			method: "POST",
			path: new RegExp("C_MKT_WebTrackingMappingTPValidate.*"),
			response: function (oXhr) {
				var oUrlParams = jQuery.sap.getUriParameters(oXhr.url);
				var uuid = oUrlParams.get("WebTrackingMappingUUID").replace("guid'", "").replace("'", "");
				//this gets the json file
				var aEntitySetData = oMockServer.getEntitySetData("C_MKT_WebTrackingMappingTP");
				aEntitySetData.forEach(function (item) {
					if (item.WebTrackingMappingUUID === uuid) {
						oXhr.respond(200, {
							"Content-Type": "application/json"
						}, JSON.stringify({
							"d": item
						}));
					}
				});
				//return true to indicate the request is processed
				return true;
			}
		});

		//Action of the Edit button. does not work, better that way for now.
		aRequests.push({
			method: "POST",
			path: new RegExp("C_MKT_WebTrackingMappingTPEdit.*"),
			response: function (oXhr, sUrlParams) {
				var aEntitySetData = oMockServer.getEntitySetData("C_MKT_WebTrackingMappingTP");

				var urlSplit = oXhr.url.split("\'");
				//taking the guid, which is inside of the ''
				var guid = urlSplit[1];
				var intGuid = findIndexByUUID(oMockServer, guid);

				var oNewEntityData = {
					"__metadata": {
						"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
							"',IsActiveEntity=false)",
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
							"',IsActiveEntity=false)",
						"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrackingMappingTPType"
					},
					"Activate_ac": false,
					"Activation_ac": true,
					"Clear_filter_ac": true,
					"Copy_ac": true,
					"Deactivate_ac": false,
					"Edit_ac": false,
					"Preparation_ac": true,
					"Validate_ac": true,
					"Validation_ac": true,
					"WebTrackingMappingDataSource_fc": 1,
					"WebTrackingMappingDataTable_fc": 1,
					"WebTrackingMappingName_fc": 1,
					"WebTrackingMappingProject_fc": 1,
					"WebTrackingMappingProperty_fc": 1,
					"WebTrackingMappingView_fc": 1,
					"Delete_mc": true,
					"Update_mc": true,
					"WebTrackingMappingUUID": "" + guid + "",
					"WebTrackingMappingName": aEntitySetData[intGuid].WebTrackingMappingName,
					"WebTrackingMappingStatus": "",
					"WebTrckgMappgStatusCriticality": 0,
					"WebTrackingMappingProject": "",
					"WebTrackingMappingDataTable": "",
					"WebTrackingMappingProperty": "UA-116478339-3",
					"WebTrackingMappingView": "179257477",
					"WebTrackingMappingType": "I",
					"WebTrackingMappingDataSource": "A",
					"WebTrackingMappingRetrievalStr": "",
					"WebTrackingMappingFilterString": "",
					"WebTrckgComMappgCreateIsEnbld": true,
					"HasDraftEntity": false,
					"ActiveUUID": "6c0b84b7-5523-1ed8-b5c1-2b2073fd745d",
					"DraftEntityCreationDateTime": "\/Date(1549464589937+0000)\/",
					"DraftEntityLastChangeDateTime": "\/Date(1549464589937+0000)\/",
					"HasActiveEntity": true,
					"IsActiveEntity": true,
					"DraftAdministrativeData": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/DraftAdministrativeData"
						}
					},
					"SiblingEntity": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/SiblingEntity"
						}
					},
					"to_WebTrackingMappgType": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrackingMappgType"
						}
					},
					"to_WebTrackingMappgView": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrackingMappgView"
						}
					},
					"to_WebTrckgComMapping": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgComMapping"
						}
					},
					"to_WebTrckgMappgDataSrce": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgDataSrce"
						}
					},
					"to_WebTrckgMappgDataTable": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgDataTable"
						}
					},
					"to_WebTrckgMappgFltr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgFltr"
						}
					},
					"to_WebTrckgMappgProject": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgProject"
						}
					},
					"to_WebTrckgMappgProperty": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgProperty"
						}
					},
					"to_WebTrckgMappgStatus": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgStatus"
						}
					},
					"to_WebTrckgMappingLog": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappingLog"
						}
					},
					"to_WebTrckgRtrvlIaHdr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgRtrvlIaHdr"
						}
					},
					"to_WebTrckgRtrvlProdHdr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgRtrvlProdHdr"
						}
					},
					"to_WebTrckgRtrvlTagHdr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgRtrvlTagHdr"
						}
					},
					"to_WebTrckgValMapping": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgValMapping"
						}
					}
				};

				aEntitySetData[intGuid] = oNewEntityData;

				//kept on getting DraftAdministrativeData was missing: forced all of the objects to have that parameter reset.
				for (var i = 0; i < aEntitySetData.length; i++) {
					aEntitySetData[i].DraftAdministrativeData = {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/DraftAdministrativeData"
						}
					};
				}

				oMockServer.setEntitySetData("C_MKT_WebTrackingMappingTP", aEntitySetData);
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				//return true to indicate the request is processed
				return true;
			}
		});

		//Handling of a request sent by Edit sometimes
		aRequests.push({
			method: "GET",
			path: new RegExp("C_MKT_WebTrackingMappingTP.*filter=PreserveChanges eq true and WebTrackingMappingUUID.*"),
			response: function (oXhr) {
				var aEntitySetData = oMockServer.getEntitySetData("C_MKT_WebTrackingMappingTP");

				var urlSplit = oXhr.url.split("\'");
				//taking the guid, which is inside of the ''
				var guid = urlSplit[1];
				var intGuid = findIndexByUUID(oMockServer, guid);

				var oNewEntityData = {
					"__metadata": {
						"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
							"',IsActiveEntity=false)",
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
							"',IsActiveEntity=false)",
						"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrackingMappingTPType"
					},
					"Activate_ac": false,
					"Activation_ac": true,
					"Clear_filter_ac": true,
					"Copy_ac": true,
					"Deactivate_ac": false,
					"Edit_ac": false,
					"Preparation_ac": true,
					"Validate_ac": true,
					"Validation_ac": true,
					"WebTrackingMappingDataSource_fc": 1,
					"WebTrackingMappingDataTable_fc": 1,
					"WebTrackingMappingName_fc": 1,
					"WebTrackingMappingProject_fc": 1,
					"WebTrackingMappingProperty_fc": 1,
					"WebTrackingMappingView_fc": 1,
					"Delete_mc": true,
					"Update_mc": true,
					"WebTrackingMappingUUID": "" + guid + "",
					"WebTrackingMappingName": aEntitySetData[intGuid].WebTrackingMappingName,
					"WebTrackingMappingStatus": "",
					"WebTrckgMappgStatusCriticality": 0,
					"WebTrackingMappingProject": "",
					"WebTrackingMappingDataTable": "",
					"WebTrackingMappingProperty": "UA-116478339-3",
					"WebTrackingMappingView": "179257477",
					"WebTrackingMappingType": "I",
					"WebTrackingMappingDataSource": "A",
					"WebTrackingMappingRetrievalStr": "",
					"WebTrackingMappingFilterString": "",
					"WebTrckgComMappgCreateIsEnbld": true,
					"HasDraftEntity": false,
					"ActiveUUID": guid,
					"DraftEntityCreationDateTime": "\/Date(1549464589937+0000)\/",
					"DraftEntityLastChangeDateTime": "\/Date(1549464589937+0000)\/",
					"HasActiveEntity": true,
					"IsActiveEntity": true,
					"DraftAdministrativeData": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/DraftAdministrativeData"
						}
					},
					"SiblingEntity": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/SiblingEntity"
						}
					},
					"to_WebTrackingMappgType": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrackingMappgType"
						}
					},
					"to_WebTrackingMappgView": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrackingMappgView"
						}
					},
					"to_WebTrckgComMapping": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgComMapping"
						}
					},
					"to_WebTrckgMappgDataSrce": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgDataSrce"
						}
					},
					"to_WebTrckgMappgDataTable": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgDataTable"
						}
					},
					"to_WebTrckgMappgFltr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgFltr"
						}
					},
					"to_WebTrckgMappgProject": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgProject"
						}
					},
					"to_WebTrckgMappgProperty": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgProperty"
						}
					},
					"to_WebTrckgMappgStatus": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappgStatus"
						}
					},
					"to_WebTrckgMappingLog": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgMappingLog"
						}
					},
					"to_WebTrckgRtrvlIaHdr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgRtrvlIaHdr"
						}
					},
					"to_WebTrckgRtrvlProdHdr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgRtrvlProdHdr"
						}
					},
					"to_WebTrckgRtrvlTagHdr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgRtrvlTagHdr"
						}
					},
					"to_WebTrckgValMapping": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=false)/to_WebTrckgValMapping"
						}
					}
				};

				//to get the update of that variable on next XHR. (In C_MKT_WebTrackingMappingTP)
				isDraft = true;

				aEntitySetData[intGuid] = oNewEntityData;
				capturedUUIDIndex = intGuid;

				//kept on getting DraftAdministrativeData was missing: forced all of the objects to have that parameter reset.
				for (var i = 0; i < aEntitySetData.length; i++) {
					aEntitySetData[i].DraftAdministrativeData = {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + guid +
								"',IsActiveEntity=true)/DraftAdministrativeData"
						}
					};
				}

				oMockServer.setEntitySetData("C_MKT_WebTrackingMappingTP", aEntitySetData);
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": {
						"results": [oNewEntityData]
					}
				}));

				//return true to indicate the request is processed
				return true;
			}
		});

		aRequests.push({
			method: "POST",
			path: new RegExp("C_MKT_WebTrackingMappingTPClear_filter.*"),
			response: function (oXhr) {
				var oNewEntityData = {
					"C_MKT_WebTrackingMappingTPClear_filter": {
						"__metadata": {
							"type": "CUAN_WEB_TRACKING_MAPPING_SRV.DummyFunctionImportResult"
						},
						"IsInvalid": false
					}
				};

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				//return true to indicate the request is processed
				return true;
			}
		});
	}

	function _getCapturedUUIDIndex() {
		return capturedUUIDIndex;
	}

	function _setCapturedUUIDIndex() {
		capturedUUIDIndex = -1;
	}

	return {
		addGeneralButtonsRequests: _addGeneralButtonsRequests,
		getCapturedUUIDIndex: _getCapturedUUIDIndex,
		setCapturedUUIDIndex: _setCapturedUUIDIndex
	};
});