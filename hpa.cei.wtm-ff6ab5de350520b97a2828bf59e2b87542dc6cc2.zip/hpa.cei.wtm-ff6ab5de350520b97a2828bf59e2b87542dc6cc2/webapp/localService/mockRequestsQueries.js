sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/util/MockServer",
	"./mockHelper",
	"./mockRequestsCQFaD"

], function (jQuery, MockServer, MockHelper, MockRequestsCQFaD) {
	//Queries section

	var globalUUID = "0";
	var counterUUID = 1000000000;

	var mainQueries = {
			"__count": "1",
			"results": [{
				"__metadata": {
					"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" +
						globalUUID + "',IsActiveEntity=true)",
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" +
						globalUUID + "',IsActiveEntity=true)",
					"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgIntactnHdrTPType"
				},
				"WebTrckgRtrvlHeaderUUID": globalUUID,
				"WebTrckgRtrvlHeaderName": "query",
				"NmbrOfWebTrckgRtrvlMeasures": 0,
				"NmbrOfWebTrckgRtrvlDimn": 0,
				"WebTrackingRtrvlItmCrteIsEnbld": true,
				"HasDraftEntity": false,
				"HasActiveEntity": false,
				"IsActiveEntity": true,
				"to_WebTrackingMapping": {
					"__deferred": {
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" + globalUUID +
							"',IsActiveEntity=false)/to_WebTrackingMapping"
					}
				},
				"DraftAdministrativeData": {
					"__deferred": {
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" + globalUUID +
							"',IsActiveEntity=false)/DraftAdministrativeData"
					}
				},
				"SiblingEntity": {
					"__deferred": {
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" + globalUUID +
							"',IsActiveEntity=false)/SiblingEntity"
					}
				},
				"to_WebTrckgComMappingTP": {
					"__deferred": {
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" + globalUUID +
							"',IsActiveEntity=false)/to_WebTrckgComMappingTP"
					}
				},
				"to_WebTrckgRtrvlDimItem": {
					"__deferred": {
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" + globalUUID +
							"',IsActiveEntity=false)/to_WebTrckgRtrvlDimItem"
					}
				},
				"to_WebTrckgRtrvlHeaderType": {
					"__deferred": {
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" + globalUUID +
							"',IsActiveEntity=false)/to_WebTrckgRtrvlHeaderType"
					}
				},
				"to_WebTrckgRtrvlMsrItem": {
					"__deferred": {
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" + globalUUID +
							"',IsActiveEntity=false)/to_WebTrckgRtrvlMsrItem"
					}
				}
			}]
		},
		//this here retrieves how many product queries are there for the object
		productQueries = {
			"__count": "1",
			"results": [{
				"__metadata": {
					"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgProdHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
						globalUUID + "',IsActiveEntity=true)",
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgProdHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
						globalUUID + "',IsActiveEntity=true)",
					"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgProdHeaderTPType"
				},
				"WebTrckgRtrvlHeaderUUID": globalUUID,
				"WebTrckgRtrvlHeaderName": "Query1 20180924121903",
				"NmbrOfWebTrckgRtrvlDimn": 1,
				"NmbrOfWebTrckgRtrvlMeasures": 1,
				"WebTrackingRtrvlItmCrteIsEnbld": true,
				"HasDraftEntity": false,
				"HasActiveEntity": false,
				"IsActiveEntity": true
			}]
		},
		//this here retrieves how many tag queries are there for the object
		tagQueries = {
			"__count": "1",
			"results": [{
				"__metadata": {
					"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgProdHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
						globalUUID + "',IsActiveEntity=true)",
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgProdHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
						globalUUID + "',IsActiveEntity=true)",
					"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgProdHeaderTPType"
				},
				"WebTrckgRtrvlHeaderUUID": globalUUID,
				"WebTrckgRtrvlHeaderName": "Query1 20180924121903",
				"NmbrOfWebTrckgRtrvlDimn": 1,
				"NmbrOfWebTrckgRtrvlMeasures": 1,
				"WebTrackingRtrvlItmCrteIsEnbld": true,
				"HasDraftEntity": false,
				"HasActiveEntity": false,
				"IsActiveEntity": true
			}]
		};

	var dimensions = {
			"__count": "1",
			"results": [{
				"__metadata": {
					"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgProdItemTP(WebTrckgRtrvlItemUUID=guid'6c0b84b7-5523-1ed9-88e6-c8620c9e8b54',IsActiveEntity=false)",
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgProdItemTP(WebTrckgRtrvlItemUUID=guid'6c0b84b7-5523-1ed9-88e6-c8620c9e8b54',IsActiveEntity=false)",
					"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgProdItemTPType"
				},
				"WebTrckgRtrvlItemUUID": "6c0b84b7-5523-1ed9-88e6-c8620c9e8b54",
				"WebTrckgMappgExternalField": "ga:productSku",
				"WebTrckgMappingInternalField": "Product",
				"WebTrackingMappingProperty": "UA-116478339-8",
				"HasDraftEntity": false,
				"HasActiveEntity": true,
				"IsActiveEntity": false,
				"to_WebTrckgIntactnField": null
			}]
		},
		metrics = {
			"__count": "1",
			"results": [{
				"__metadata": {
					"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgProdMsrTP(WebTrckgRtrvlItemUUID=guid'6c0b84b7-5523-1ed9-88e6-c8620c9eab54',IsActiveEntity=false)",
					"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgProdMsrTP(WebTrckgRtrvlItemUUID=guid'6c0b84b7-5523-1ed9-88e6-c8620c9eab54',IsActiveEntity=false)",
					"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgProdMsrTPType"
				},
				"WebTrckgRtrvlItemUUID": "6c0b84b7-5523-1ed9-88e6-c8620c9eab54",
				"WebTrckgMappgExternalField": "ga:productAddsToCart",
				"WebTrckgMappingInternalField": "InteractionProductQuantity",
				"WebTrackingMappingProperty": "UA-116478339-8",
				"HasDraftEntity": false,
				"HasActiveEntity": true,
				"IsActiveEntity": false,
				"to_WebTrckgIntactnField": null
			}]
		};

	function findIndexByUUIDMainQ(uuid) {

		for (var i = 0; i < mainQueries.results.length; i++) {
			if (mainQueries.results[i].WebTrckgRtrvlHeaderUUID == uuid) { // eslint-disable-line eqeqeq
				return i;
			}
		}

		return false;
	}

	function findIndexByUUIDProductQ(uuid) {

		for (var i = 0; i < productQueries.results.length; i++) {
			if (productQueries.results[i].WebTrckgRtrvlHeaderUUID == uuid) { // eslint-disable-line eqeqeq
				return i;
			}
		}

		return false;
	}

	function findIndexByUUIDTagQ(uuid) {

		for (var i = 0; i < tagQueries.results.length; i++) {
			if (tagQueries.results[i].WebTrckgRtrvlHeaderUUID == uuid) { // eslint-disable-line eqeqeq
				return i;
			}
		}

		return false;
	}

	function _addQueriesRequests(oMockServer, aRequests) {

		//NOTE : For the retrieval of this data below, there are (for now) hardcoded, because I dont want an unsaved edit to affect the object.
		//Sending back the main queries from the Query tab
		aRequests.push({
			method: "GET",
			path: new RegExp("C_MKT_WebTrackingMappingTP.*\/to_WebTrckgRtrvlIaHdr\?.*"),
			response: function (oXhr, sUrlParams) {
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": mainQueries
				}));

				return true;
			}
		});

		//Sending back the product queries from the Query tab
		aRequests.push({
			method: "GET",
			path: new RegExp("C_MKT_WebTrackingMappingTP.*\/to_WebTrckgRtrvlProdHdr.*"),
			response: function (oXhr, sUrlParams) {
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": productQueries
				}));

				return true;
			}
		});

		//Sending back the tag queries from the Query tab
		aRequests.push({
			method: "GET",
			path: new RegExp("C_MKT_WebTrackingMappingTP.*\/to_WebTrckgRtrvlTagHdr.*"),
			response: function (oXhr, sUrlParams) {
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": tagQueries
				}));

				return true;
			}
		});

		//adding a new Query
		aRequests.push({
			method: "POST",
			path: new RegExp("C_MKT_WebTrackingMappingTP.*\/to_WebTrckgRtrvlIaHdr"),
			response: function (oXhr, sUrlParams) {
				var oNewEntityData = {
					"__metadata": {
						"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" +
							counterUUID + "',IsActiveEntity=false)",
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" +
							counterUUID + "',IsActiveEntity=false)",
						"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgIntactnHdrTPType"
					},
					"Update_mc": true,
					"Edit_ac": true,
					"Activation_ac": true,
					"Preparation_ac": true,
					"Validation_ac": true,
					"WebTrckgRtrvlHeaderUUID": counterUUID,
					"WebTrackingMappingUUID": counterUUID,
					"WebTrckgRtrvlHeaderName": "",
					"NmbrOfWebTrckgRtrvlMeasures": 0,
					"NmbrOfWebTrckgRtrvlDimn": 0,
					"WebTrackingRtrvlItmCrteIsEnbld": true,
					"HasDraftEntity": false,
					"ActiveUUID": "00000000-0000-0000-0000-000000000000",
					"DraftEntityCreationDateTime": "\/Date(1549051320830+0000)\/",
					"DraftEntityLastChangeDateTime": "\/Date(1549051320830+0000)\/",
					"HasActiveEntity": false,
					"IsActiveEntity": false,
					"to_WebTrackingMapping": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/to_WebTrackingMapping"
						}
					},
					"DraftAdministrativeData": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/DraftAdministrativeData"
						}
					},
					"SiblingEntity": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/SiblingEntity"
						}
					},
					"to_WebTrckgComMappingTP": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/to_WebTrckgComMappingTP"
						}
					},
					"to_WebTrckgRtrvlDimItem": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/to_WebTrckgRtrvlDimItem"
						}
					},
					"to_WebTrckgRtrvlHeaderType": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/to_WebTrckgRtrvlHeaderType"
						}
					},
					"to_WebTrckgRtrvlMsrItem": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnHdrTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/to_WebTrckgRtrvlMsrItem"
						}
					}
				};

				mainQueries.results.push(oNewEntityData);

				//adding value to UUID to make it unique for next time we are adding a query
				counterUUID++;
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});

		//adding a new Query -- Retrieval of Dimensions
		aRequests.push({
			method: "GET",
			path: new RegExp("C_MKT_WebTrckgIntactnHdrTP.*\/to_WebTrckgRtrvlDimItem.*"),
			response: function (oXhr, sUrlParams) {
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": dimensions
				}));

				return true;
			}
		});

		//adding a new Query -- Retrieval of Metrics?
		aRequests.push({
			method: "GET",
			path: new RegExp("C_MKT_WebTrckgIntactnHdrTP.*\/to_WebTrckgRtrvlMsrItem.*"),
			response: function (oXhr, sUrlParams) {
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": metrics
				}));

				return true;
			}
		});

		//adding dimensions for a query
		aRequests.push({
			method: "POST",
			path: new RegExp("C_MKT_WebTrckgIntactnHdrTP.*\/to_WebTrckgRtrvlDimItem.*"),
			response: function (oXhr) {

				var oNewEntityData = {
					"__metadata": {
						"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnItmTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
							"',IsActiveEntity=false)",
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnItmTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
							"',IsActiveEntity=false)",
						"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgIntactnItmTPType"
					},
					"Preparation_ac": true,
					"Validation_ac": true,
					"WebTrckgRtrvlItemUUID": "" + counterUUID + "",
					"WebTrackingMappingUUID": "" + counterUUID + "",
					"WebTrckgRtrvlHeaderUUID": "" + counterUUID + "",
					"WebTrckgMappgExternalField": "",
					"WebTrckgMappingInternalField": "",
					"WebTrackingMappingProperty": "UA-116478339-2",
					"HasDraftEntity": false,
					"ActiveUUID": "00000000-0000-0000-0000-000000000000",
					"DraftEntityCreationDateTime": "\/Date(1550499877658+0000)\/",
					"DraftEntityLastChangeDateTime": "\/Date(1550499877658+0000)\/",
					"HasActiveEntity": false,
					"IsActiveEntity": false,
					"to_WebTrckgIntactnHdr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnItmTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
								"',IsActiveEntity=false)/to_WebTrckgIntactnHdr"
						}
					},
					"DraftAdministrativeData": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnItmTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
								"',IsActiveEntity=false)/DraftAdministrativeData"
						}
					},
					"SiblingEntity": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnItmTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
								"',IsActiveEntity=false)/SiblingEntity"
						}
					},
					"to_WebTrackingMapping": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnItmTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
								"',IsActiveEntity=false)/to_WebTrackingMapping"
						}
					},
					"to_WebTrckgIntactnField": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnItmTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
								"',IsActiveEntity=false)/to_WebTrckgIntactnField"
						}
					},
					"to_WebTrckgMappgFldType": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnItmTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
								"',IsActiveEntity=false)/to_WebTrckgMappgFldType"
						}
					},
					"to_WebTrckgMappingDimn": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnItmTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
								"',IsActiveEntity=false)/to_WebTrckgMappingDimn"
						}
					}
				};

				dimensions.results.push(oNewEntityData);
				//adding value to UUID to make it unique for next time we are adding a query
				counterUUID++;

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});

		//adding a product query
		aRequests.push({
			method: "POST",
			path: new RegExp("C_MKT_WebTrackingMappingTP.*\/to_WebTrckgRtrvlProdHdr.*"),
			response: function (oXhr) {
				var oNewEntityData = {
					"__metadata": {
						"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgProdHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
							counterUUID + "',IsActiveEntity=false)",
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgProdHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
							counterUUID + "',IsActiveEntity=false)",
						"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgProdHeaderTPType"
					},
					"Update_mc": true,
					"Edit_ac": true,
					"Activation_ac": true,
					"Preparation_ac": true,
					"Validation_ac": true,
					"WebTrckgRtrvlHeaderUUID": "" + counterUUID + "",
					"WebTrackingMappingUUID": "" + counterUUID + "",
					"WebTrckgRtrvlHeaderName": "",
					"NmbrOfWebTrckgRtrvlDimn": 0,
					"NmbrOfWebTrckgRtrvlMeasures": 0,
					"WebTrackingRtrvlItmCrteIsEnbld": true,
					"HasDraftEntity": false,
					"ActiveUUID": "00000000-0000-0000-0000-000000000000",
					"DraftEntityCreationDateTime": "\/Date(1549380571917+0000)\/",
					"DraftEntityLastChangeDateTime": "\/Date(1549380571917+0000)\/",
					"HasActiveEntity": false,
					"IsActiveEntity": false,
					"to_WebTrackingMapping": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgProdHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/to_WebTrackingMapping"
						}
					},
					"DraftAdministrativeData": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgProdHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/DraftAdministrativeData"
						}
					},
					"SiblingEntity": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgProdHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/SiblingEntity"
						}
					},
					"to_WebTrckgComMappingTP": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgProdHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/to_WebTrckgComMappingTP"
						}
					},
					"to_WebTrckgRtrvlDimItem": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgProdHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/to_WebTrckgRtrvlDimItem"
						}
					},
					"to_WebTrckgRtrvlHeaderType": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgProdHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/to_WebTrckgRtrvlHeaderType"
						}
					},
					"to_WebTrckgRtrvlMsrItem": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgProdHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/to_WebTrckgRtrvlMsrItem"
						}
					}
				};

				productQueries.results.push(oNewEntityData);
				//adding value to UUID to make it unique for next time we are adding a query
				counterUUID++;

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});

		//adding a tag query
		aRequests.push({
			method: "POST",
			path: new RegExp("C_MKT_WebTrackingMappingTP.*\/to_WebTrckgRtrvlTagHdr.*"),
			response: function (oXhr) {
				var oNewEntityData = {
					"__metadata": {
						"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingTagHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
							counterUUID + "',IsActiveEntity=false)",
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingTagHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
							counterUUID + "',IsActiveEntity=false)",
						"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrackingTagHeaderTPType"
					},
					"Update_mc": true,
					"Edit_ac": true,
					"Activation_ac": true,
					"Preparation_ac": true,
					"Validation_ac": true,
					"WebTrckgRtrvlHeaderUUID": "" + counterUUID + "",
					"WebTrackingMappingUUID": "" + counterUUID + "",
					"WebTrckgRtrvlHeaderName": "",
					"NmbrOfWebTrckgRtrvlDimn": 0,
					"NmbrOfWebTrckgRtrvlMeasures": 0,
					"WebTrackingRtrvlItmCrteIsEnbld": true,
					"HasDraftEntity": false,
					"ActiveUUID": "00000000-0000-0000-0000-000000000000",
					"DraftEntityCreationDateTime": "\/Date(1549381224191+0000)\/",
					"DraftEntityLastChangeDateTime": "\/Date(1549381224191+0000)\/",
					"HasActiveEntity": false,
					"IsActiveEntity": false,
					"to_WebTrackingMapping": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingTagHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/to_WebTrackingMapping"
						}
					},
					"DraftAdministrativeData": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingTagHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/DraftAdministrativeData"
						}
					},
					"SiblingEntity": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingTagHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/SiblingEntity"
						}
					},
					"to_WebTrckgComMappingTP": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingTagHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/to_WebTrckgComMappingTP"
						}
					},
					"to_WebTrckgRtrvlDimItem": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingTagHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/to_WebTrckgRtrvlDimItem"
						}
					},
					"to_WebTrckgRtrvlHeaderType": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingTagHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/to_WebTrckgRtrvlHeaderType"
						}
					},
					"to_WebTrckgRtrvlMsrItem": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrackingTagHeaderTP(WebTrckgRtrvlHeaderUUID=guid'" +
								counterUUID + "',IsActiveEntity=false)/to_WebTrckgRtrvlMsrItem"
						}
					}
				};

				tagQueries.results.push(oNewEntityData);
				//adding value to UUID to make it unique for next time we are adding a query
				counterUUID++;

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewEntityData
				}));

				return true;
			}
		});

		//adding a dimension to a new query (which one? all the same?) (INCOMPLETE)
		aRequests.push({
			method: "POST",
			path: new RegExp("C_MKT_WebTrackingTagHeaderTP.*\/to_WebTrckgRtrvlDimItem.*"),
			response: function (oXhr) {

			}
		});

		//removing a main query. MUST RELY ON UUID!
		aRequests.push({
			method: "DELETE",
			path: new RegExp("C_MKT_WebTrckgIntactnHdrTP.*"),
			response: function (oXhr) {
				//removing the first object in the list
				if (mainQueries.results.length > 0) {
					mainQueries.results.splice(0, 1);
					//decreasing the count if it happened
					mainQueries.count--;
				}

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": mainQueries
				}));

				return true;
			}
		});

		//removing a product or tag query. MUST RELY ON UUID!
		aRequests.push({
			method: "DELETE",
			path: new RegExp("C_MKT_WebTrckgProdHeaderTP.*"),
			response: function (oXhr) {
				//removing the first object in the list
				if (productQueries.results.length > 0) {
					productQueries.results.splice(0, 1);
					//decreasing the count if it happened
					productQueries.count--;
				}

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": productQueries
				}));

				return true;
			}
		});

		//showing a main query info. Why does it only accept the whole list of main queries???
		aRequests.push({
			method: "GET",
			path: new RegExp("C_MKT_WebTrckgIntactnHdrTP\(.*\)$"),
			response: function (oXhr) {

				//NOT USED
				var urlSplit = oXhr.url.split("\'");
				//taking the guid, which is inside of the ''
				var guid = urlSplit[1];
				var intGuid = findIndexByUUIDMainQ(guid),
					i = 0;

				//have to mark as well if the entity is active or not (from the main queries list)
				urlSplit = oXhr.url.split("IsActiveEntity");
				urlSplit = urlSplit[1].split(")");
				var valueWithEquals = urlSplit[0]; //either "=true" or "=false"
				if (valueWithEquals === "=true") {
					mainQueries.results[intGuid].IsActiveEntity = true;
					for (i = 0; i < dimensions.results.length; i++) {
						dimensions.results[i].IsActiveEntity = true;
					}
					for (i = 0; i < metrics.results.length; i++) {
						metrics.results[i].IsActiveEntity = true;
					}
				} else {
					mainQueries.results[intGuid].IsActiveEntity = false;
					for (i = 0; i < dimensions.results.length; i++) {
						dimensions.results[i].IsActiveEntity = false;
					}
					for (i = 0; i < metrics.results.length; i++) {
						metrics.results[i].IsActiveEntity = false;
					}
				}

				if (oXhr.url.includes("to_WebTrckgRtrvlDimItem")) {
					oXhr.respond(200, {
						"Content-Type": "application/json"
					}, JSON.stringify({
						"d": dimensions
					}));

					return true;
				} else if (oXhr.url.includes("to_WebTrckgRtrvlMsrItem")) {
					oXhr.respond(200, {
						"Content-Type": "application/json"
					}, JSON.stringify({
						"d": metrics
					}));

					return true;
				}

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": mainQueries.results[1]
				}));

				return true;
			}
		});

		//showing a product query info
		aRequests.push({
			method: "GET",
			path: new RegExp("C_MKT_WebTrckgProdHeaderTP\(.*\)$"),
			response: function (oXhr) {

				//NOT USED
				var urlSplit = oXhr.url.split("\'");
				//taking the guid, which is inside of the ''
				var guid = urlSplit[1];
				var intGuid = findIndexByUUIDProductQ(guid),
					i = 0;

				//have to mark as well if the entity is active or not (from the main queries list)
				urlSplit = oXhr.url.split("IsActiveEntity");
				urlSplit = urlSplit[1].split(")");
				var valueWithEquals = urlSplit[0]; //either "=true" or "=false"
				if (valueWithEquals === "=true") {
					productQueries.results[intGuid].IsActiveEntity = true;
					for (i = 0; i < dimensions.results.length; i++) {
						dimensions.results[i].IsActiveEntity = true;
					}
					for (i = 0; i < metrics.results.length; i++) {
						metrics.results[i].IsActiveEntity = true;
					}
				} else {
					productQueries.results[intGuid].IsActiveEntity = false;
					for (i = 0; i < dimensions.results.length; i++) {
						dimensions.results[i].IsActiveEntity = false;
					}
					for (i = 0; i < metrics.results.length; i++) {
						metrics.results[i].IsActiveEntity = false;
					}
				}

				if (oXhr.url.includes("to_WebTrckgRtrvlDimItem")) {
					oXhr.respond(200, {
						"Content-Type": "application/json"
					}, JSON.stringify({
						"d": dimensions
					}));

					return true;
				} else if (oXhr.url.includes("to_WebTrckgRtrvlMsrItem")) {
					oXhr.respond(200, {
						"Content-Type": "application/json"
					}, JSON.stringify({
						"d": metrics
					}));

					return true;
				} else if (oXhr.url.includes("to_WebTrckgComMappingTP")) {
					oXhr.respond(200, {
						"Content-Type": "application/json"
					}, JSON.stringify({
						"d": MockRequestsCQFaD.getCommonDimensions()
					}));

					return true;
				}

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": productQueries.results[1]
				}));

				return true;
			}
		});

		//showing a tag query info
		aRequests.push({
			method: "GET",
			path: new RegExp("C_MKT_WebTrackingTagHeaderTP\(.*\)$"),
			response: function (oXhr) {

				//NOT USED
				var urlSplit = oXhr.url.split("\'");
				//taking the guid, which is inside of the ''
				var guid = urlSplit[1];
				var intGuid = findIndexByUUIDTagQ(guid),
					i = 0;

				//have to mark as well if the entity is active or not (from the main queries list)
				urlSplit = oXhr.url.split("IsActiveEntity");
				urlSplit = urlSplit[1].split(")");
				var valueWithEquals = urlSplit[0]; //either "=true" or "=false"
				if (valueWithEquals === "=true") {
					tagQueries.results[intGuid].IsActiveEntity = true;
					for (i = 0; i < dimensions.results.length; i++) {
						dimensions.results[i].IsActiveEntity = true;
					}
					for (i = 0; i < metrics.results.length; i++) {
						metrics.results[i].IsActiveEntity = true;
					}
				} else {
					tagQueries.results[intGuid].IsActiveEntity = false;
					for (i = 0; i < dimensions.results.length; i++) {
						dimensions.results[i].IsActiveEntity = false;
					}
					for (i = 0; i < metrics.results.length; i++) {
						metrics.results[i].IsActiveEntity = false;
					}
				}

				if (oXhr.url.includes("to_WebTrckgRtrvlDimItem")) {
					oXhr.respond(200, {
						"Content-Type": "application/json"
					}, JSON.stringify({
						"d": dimensions
					}));

					return true;
				} else if (oXhr.url.includes("to_WebTrckgRtrvlMsrItem")) {
					oXhr.respond(200, {
						"Content-Type": "application/json"
					}, JSON.stringify({
						"d": metrics
					}));

					return true;
				} else if (oXhr.url.includes("to_WebTrckgComMappingTP")) {
					oXhr.respond(200, {
						"Content-Type": "application/json"
					}, JSON.stringify({
						"d": MockRequestsCQFaD.getCommonDimensions()
					}));

					return true;
				}

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": tagQueries.results[1]
				}));

				return true;
			}
		});

		//retrieving the common dimensions??
		aRequests.push({
			method: "GET",
			path: new RegExp("C_MKT_WebTrckgIntactnHdrTP.*\/to_WebTrckgComMappingTP.*"),
			response: function (oXhr) {

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": MockRequestsCQFaD.getCommonDimensions()
				}));

				return true;
			}
		});

		//retrieving the dimensions??
		aRequests.push({
			method: "GET",
			path: new RegExp("C_MKT_WebTrckgComMappingTP.*\/to_WebTrckgRtrvlDimItem.*"),
			response: function (oXhr) {

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": dimensions
				}));

				return true;
			}
		});

		//retrieving the metrics??
		aRequests.push({
			method: "GET",
			path: new RegExp("C_MKT_WebTrckgComMappingTP.*\/to_WebTrckgRtrvlMsrItem.*"),
			response: function (oXhr) {
				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": metrics
				}));

				return true;
			}
		});

		//adding a metric
		aRequests.push({
			method: "POST",
			path: new RegExp("C_MKT_WebTrckgIntactnHdrTP.*\/to_WebTrckgRtrvlMsrItem.*"),
			response: function (oXhr, sUrlParams) {
				var oNewDataEntity = {
					"__metadata": {
						"id": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnMsrTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
							"',IsActiveEntity=false)",
						"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnMsrTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
							"',IsActiveEntity=false)",
						"type": "CUAN_WEB_TRACKING_MAPPING_SRV.C_MKT_WebTrckgIntactnMsrTPType"
					},
					"Preparation_ac": true,
					"Validation_ac": true,
					"WebTrckgRtrvlItemUUID": "" + counterUUID + "",
					"WebTrackingMappingUUID": "" + counterUUID + "",
					"WebTrckgRtrvlHeaderUUID": "" + counterUUID + "",
					"WebTrckgMappgExternalField": "",
					"WebTrckgMappingInternalField": "",
					"WebTrackingMappingProperty": "UA-116478339-8",
					"HasDraftEntity": false,
					"ActiveUUID": "00000000-0000-0000-0000-000000000000",
					"DraftEntityCreationDateTime": "\/Date(1550506415684+0000)\/",
					"DraftEntityLastChangeDateTime": "\/Date(1550506415684+0000)\/",
					"HasActiveEntity": false,
					"IsActiveEntity": false,
					"to_WebTrckgIntactnHdr": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnMsrTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
								"',IsActiveEntity=false)/to_WebTrckgIntactnHdr"
						}
					},
					"DraftAdministrativeData": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnMsrTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
								"',IsActiveEntity=false)/DraftAdministrativeData"
						}
					},
					"SiblingEntity": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnMsrTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
								"',IsActiveEntity=false)/SiblingEntity"
						}
					},
					"to_WebTrackingMapping": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnMsrTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
								"',IsActiveEntity=false)/to_WebTrackingMapping"
						}
					},
					"to_WebTrckgIntactnField": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnMsrTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
								"',IsActiveEntity=false)/to_WebTrckgIntactnField"
						}
					},
					"to_WebTrckgMappgFldType": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnMsrTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
								"',IsActiveEntity=false)/to_WebTrckgMappgFldType"
						}
					},
					"to_WebTrckgMappgMeasure": {
						"__deferred": {
							"uri": "/sap/opu/odata/sap/CUAN_WEB_TRACKING_MAPPING_SRV/C_MKT_WebTrckgIntactnMsrTP(WebTrckgRtrvlItemUUID=guid'" + counterUUID +
								"',IsActiveEntity=false)/to_WebTrckgMappgMeasure"
						}
					}
				};

				metrics.results.push(oNewDataEntity);
				counterUUID++;

				oXhr.respond(200, {
					"Content-Type": "application/json"
				}, JSON.stringify({
					"d": oNewDataEntity
				}));

				return true;
			}
		});

	}

	function _getMainQueries() {
		return mainQueries;
	}

	function _getProductQueries() {
		return productQueries;
	}

	function _getTagQueries() {
		return tagQueries;
	}

	return {
		addQueriesRequests: _addQueriesRequests,
		getMainQueries: _getMainQueries,
		getProductQueries: _getProductQueries,
		getTagQueries: _getTagQueries
	};
});