sap.ui.define([
	"sap/ui/core/Control",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"hpa/cei/wtm/ext/controller/BigQuery.controller",
	"sap/base/i18n/ResourceBundle",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function (Control, Controller, JSONModel, BigQueryController, ResourceBundle) {
	"use strict";

	QUnit.module("BigQuery Controller Tests", {

		beforeEach: function () {
			this.oCut = new BigQueryController(); //new sap.ui.core.mvc.Controller("hpa.cei.wtm.ext.controller.BigQuery");
			this.oViewMock = new sap.ui.core.mvc.View({
				viewName: "testView"
			});
			sinon.stub(this.oCut, "getView").returns(this.oViewMock);
		},

		afterEach: function () {}
	});

	QUnit.test("_getFieldsPopoverForFunction | Match and Merge contacts", function (assert) {
		var oPopover = this.oCut._getFieldsPopoverForFunction("C");
		assert.strictEqual("contactFieldsPopover", oPopover.getId());
	});
	QUnit.test("_getFieldsPopoverForFunction | Create Interactions", function (assert) {
		var oPopover = this.oCut._getFieldsPopoverForFunction("I");
		assert.strictEqual("interactionFieldsPopover", oPopover.getId());
	});
	QUnit.test("_getFieldsPopoverForFunction | Others", function (assert) {
		var oPopover = this.oCut._getFieldsPopoverForFunction("TEST");
		assert.strictEqual(null, oPopover);
	});

	QUnit.test("_getPlaceholderValueForFunction | Match and Merge contacts", function (assert) {
		sinon.stub(this.oCut, "_getCreateContactsBigQueryPlaceholder").returns("Test value");
		var sValue = this.oCut._getPlaceholderValueForFunction("C");
		assert.strictEqual("Test value", sValue);
		assert.strictEqual(this.oCut._getCreateContactsBigQueryPlaceholder.calledOnce,true);
	});
	QUnit.test("_getPlaceholderValueForFunction | Create Interactions", function (assert) {
		sinon.stub(this.oCut, "_getCreateInteractionsBigQueryPlaceholder").returns("Test value");
		var sValue = this.oCut._getPlaceholderValueForFunction("I");
		assert.strictEqual("Test value", sValue);
	});
	QUnit.test("_getPlaceholderValueForFunction | Others", function (assert) {
		sinon.stub(this.oCut, "_getCreateInteractionsBigQueryPlaceholder").returns("Test value");
		var sValue = this.oCut._getPlaceholderValueForFunction("TEST");
		assert.strictEqual("", sValue);
	});

	QUnit.test("_getCreateInteractionsBigQueryPlaceholder", function (assert) {
		sinon.stub(this.oCut, "_getText").withArgs("bigQueryEditorPlaceHolder1").returns("placeholder1");
		this.oCut._getText.withArgs("bigQueryEditorPlaceHolder2").returns("placeholder2");
		var sValue = this.oCut._getCreateInteractionsBigQueryPlaceholder();
		assert.strictEqual("#standardSQL\r\n/*placeholder1*/\r\n/*placeholder2*/", sValue);
	});

	QUnit.test("_getResourceBundle | with model name", function (assert) {
		// this.oMockResourceBundle = ResourceBundle.create({
		// 	url: "i18n/messagebundle.properties",
		// 	async: false
		// });
		var oMockModel = {
			getResourceBundle: function () {
				if (typeof (this._resourceBundle) === "undefined") {
					this._resourceBundle = ResourceBundle.create({
						url: "i18n/messagebundle.properties",
						async: false
					});
				}
				return this._resourceBundle;
			}
		};
		sinon.stub(this.oViewMock, "getModel").withArgs("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrackingMappingTP").returns(
			oMockModel);
		var oResourceBundle = this.oCut._getResourceBundle("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrackingMappingTP");
		assert.strictEqual(true, typeof (oResourceBundle) !== "undefined");
		assert.strictEqual(true, oResourceBundle === oMockModel.getResourceBundle());
	});
	QUnit.test("_getResourceBundle | no model name", function (assert) {
		// this.oMockResourceBundle = ResourceBundle.create({
		// 	url: "i18n/messagebundle.properties",
		// 	async: false
		// });
		var oMockModel = {
			getResourceBundle: function () {
				if (typeof (this._resourceBundle) === "undefined") {
					this._resourceBundle = ResourceBundle.create({
						url: "i18n/messagebundle.properties",
						async: false
					});
				}
				return this._resourceBundle;
			}
		};
		sinon.stub(this.oViewMock, "getModel").withArgs("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrackingMappingTP").returns(
			oMockModel);
		var oResourceBundle = this.oCut._getResourceBundle();
		assert.strictEqual(true, typeof (oResourceBundle) !== "undefined");
		assert.strictEqual(true, oResourceBundle === oMockModel.getResourceBundle());
	});

	QUnit.test("_getResourceBundle | no model name", function (assert) {
		// this.oMockResourceBundle = ResourceBundle.create({
		// 	url: "i18n/messagebundle.properties",
		// 	async: false
		// });
		var oMockModel = {
			getResourceBundle: function () {
				if (typeof (this._resourceBundle) === "undefined") {
					this._resourceBundle = ResourceBundle.create({
						url: "i18n/messagebundle.properties",
						async: false
					});
				}
				return this._resourceBundle;
			}
		};
		sinon.stub(oMockModel.getResourceBundle(), "getText").withArgs("test").returns("this is test");
		sinon.stub(this.oViewMock, "getModel").withArgs("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrackingMappingTP").returns(
			oMockModel);
		var sText = this.oCut._getText("test");
		assert.strictEqual("this is test", sText);
	});

});