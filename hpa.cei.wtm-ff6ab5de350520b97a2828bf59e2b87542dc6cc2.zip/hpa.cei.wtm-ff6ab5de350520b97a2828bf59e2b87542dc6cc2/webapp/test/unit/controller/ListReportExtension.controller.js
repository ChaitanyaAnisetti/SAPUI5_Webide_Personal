sap.ui.define([
	"sap/ui/core/Control",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit",
	"hpa/cei/wtm/ext/controller/ListReportExtension.controller"
], function (Control, Controller, JSONModel) {
	"use strict";

	QUnit.module("ListReportExtension Controller Tests", {

		beforeEach: function () {
			this.cut = new sap.ui.core.mvc.Controller("hpa.cei.wtm.ext.controller.ListReportExtension");
		},

		afterEach: function () {}
	});
});