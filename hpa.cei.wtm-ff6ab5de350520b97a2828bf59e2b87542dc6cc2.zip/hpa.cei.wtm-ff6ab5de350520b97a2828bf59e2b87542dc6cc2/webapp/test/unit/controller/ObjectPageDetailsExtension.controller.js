sap.ui.define([
	"sap/ui/core/Control",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/base/ManagedObject",
	"sap/uxap/ObjectPageLayout",
	"sap/ui/comp/smarttable/SmartTable",
	"sap/ui/comp/smartfield/SmartField",
	"sap/ui/model/resource/ResourceModel",
	"sap/base/i18n/ResourceBundle",
	"sap/ui/base/Event",
	"sap/ui/core/MessageType",
	"sap/ui/model/Model",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit",
	"hpa/cei/wtm/ext/controller/ObjectPageDetailsExtension.controller"
], function (Control, Controller, JSONModel, ManagedObject, ObjectPageLayout, SmartTable, SmartField, ResourceModel, ResourceBundle,
	Event, MessageType, Model) {
	"use strict";

	QUnit.module("ObjectPageDetailsExtension Controller Tests", {

		beforeEach: function () {
			this.clock = sinon.useFakeTimers();
			this.oViewMock = new ManagedObject();
			this.oObjectPageLayoutMock = new ObjectPageLayout();
			this.oOwnerComponentMock = {
				getEntitySet: function () {},
				getModel: function () {}
			};
			this.oOwnerComponentModelMock = {
				getResourceBundle: function () {}
			};
			this.oResourceBundleMock = {
				getText: function (sTextId) {}
			};
			this.oBindingContextMock = {
				sPath: "",
				getPath: function () {
					return this.sPath;
				}
			};

			// Instantiate Component Under Test
			this.oCut = new sap.ui.core.mvc.Controller("hpa.cei.wtm.ext.controller.ObjectPageDetailsExtension");

			this.oViewMock = this.oViewMock;
			this.oViewMock.byId = function (id) {};
			this.oViewMock.addDependent = function (oDependent) {};

			// Stub method getView to return mock
			sinon.stub(this.oCut, "getView").returns(this.oViewMock);
			sinon.stub(this.oViewMock, "getBindingContext").returns(this.oBindingContextMock);
			// Stub method byId
			var oStub = sinon.stub(this.oCut, "byId");
			// Stub method byId to return the ObjectPageLayout mock when called with "objectPage" as an argument
			oStub.withArgs("objectPage").returns(this.oObjectPageLayoutMock);

			// Stub method getOwnerComponent to return Component Mock.
			sinon.stub(this.oCut, "getOwnerComponent").returns(this.oOwnerComponentMock);
			sinon.stub(this.oOwnerComponentMock, "getEntitySet");
			sinon.stub(this.oOwnerComponentMock, "getModel").withArgs(
				"i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrackingMappingTP").returns(this.oOwnerComponentModelMock);
			this.oOwnerComponentMock.getModel.returns(this.oOwnerComponentModelMock);
			sinon.stub(this.oOwnerComponentModelMock, "getResourceBundle").returns(this.oResourceBundleMock);
		},

		afterEach: function () {}
	});

	QUnit.test("FilterType is \"Basic\" after controller initialization", function (assert) {
		// Stub OwnerComponent to return an empty string when getEntitySet is called
		this.oOwnerComponentMock.getEntitySet.returns("");

		this.oCut.onInit();
		assert.strictEqual(this.oCut.getView().getModel("filterType").getData().filterType, "B");
	});

	QUnit.test("Log Table Ignore From p13n", function (assert) {
		// Stub OwnerComponent to return an empty string when getEntitySet is called
		this.oOwnerComponentMock.getEntitySet.returns("C_MKT_WebTrackingMappingTP");
		this.oLogTableMock = new SmartTable();
		sinon.stub(this.oViewMock, "byId").returns(this.oLogTableMock);
		this.oCut.onInit();

		assert.strictEqual("ValidityEndDate,WebTrckgRtrvlHeaderName,ValidityDate", this.oLogTableMock.getIgnoreFromPersonalisation());
	});

	QUnit.test("GoogleAnalyticsProperty valuehelp autobinding enabled", function (assert) {
		this.oGoogleAnalyticsPropertySmartField = new SmartField();
		sinon.stub(this.oViewMock, "byId").withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--com.sap.vocabularies.UI.v1.FieldGroup::details_FG::WebTrackingMappingProperty::Field"
		).returns(this.oGoogleAnalyticsPropertySmartField);
		this.oCut._enableValuehelpAutobindingOnRootNode();
		assert.strictEqual(false, this.oGoogleAnalyticsPropertySmartField.getConfiguration().getPreventInitialDataFetchInValueHelpDialog());
	});

	QUnit.test("GoogleAnalyticsView valuehelp autobinding enabled", function (assert) {
		this.oGoogleAnalyticsPropertySmartField = new SmartField();
		sinon.stub(this.oViewMock, "byId").withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--com.sap.vocabularies.UI.v1.FieldGroup::details_FG::WebTrackingMappingView::Field"
		).returns(this.oGoogleAnalyticsPropertySmartField);
		this.oCut._enableValuehelpAutobindingOnRootNode();
		assert.strictEqual(false, this.oGoogleAnalyticsPropertySmartField.getConfiguration().getPreventInitialDataFetchInValueHelpDialog());
	});

	QUnit.test("BigQueryProject valuehelp autobinding enabled", function (assert) {
		this.oBigQueryProjectSmartField = new SmartField();
		sinon.stub(this.oViewMock, "byId")
			.withArgs(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--com.sap.vocabularies.UI.v1.FieldGroup::details_FG::WebTrackingMappingProject::Field"
			)
			.returns(this.oBigQueryProjectSmartField);
		this.oCut._enableValuehelpAutobindingOnRootNode();
		assert.strictEqual(false, this.oBigQueryProjectSmartField.getConfiguration().getPreventInitialDataFetchInValueHelpDialog());
	});

	QUnit.test("BigQueryDataset valuehelp autobinding enabled", function (assert) {
		this.oBigQueryDatatableSmartField = new SmartField();
		sinon.stub(this.oViewMock, "byId")
			.withArgs(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--com.sap.vocabularies.UI.v1.FieldGroup::details_FG::WebTrackingMappingDataTable::Field"
			)
			.returns(this.oBigQueryDatatableSmartField);
		this.oCut._enableValuehelpAutobindingOnRootNode();
		assert.strictEqual(false, this.oBigQueryDatatableSmartField.getConfiguration().getPreventInitialDataFetchInValueHelpDialog());
	});

	QUnit.test("BeforeDeleteExtension text is set correctly", function (assert) {
		this.oOwnerComponentMock.getEntitySet.returns(
			"C_MKT_WebTrackingMappingTP");
		this.oI18nModelMock = new ResourceModel({
			bundleName: "test"
		});
		this.oResourceBundleMock = ResourceBundle.create({
			url: "test.properties",
			locale: "en"
		});

		sinon.stub(this.oViewMock, "getModel");
		this.oViewMock.getModel.withArgs(
			"i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrackingMappingTP"
		).returns(this.oI18nModelMock);
		sinon.stub(this.oResourceBundleMock, "getText").withArgs("popupTitleText").returns("popupTitleText");
		this.oResourceBundleMock.getText.withArgs("popupDescriptionText").returns("popupDescriptionText");
		var sText = this.oCut.beforeDeleteExtension();
		assert.strictEqual(sText.title, "popupTitleText");
		assert.strictEqual(sText.text, "popupDescriptionText");

	});

	QUnit.test("onNavigateSection | Basic filter", function (assert) {
		var oModel = new JSONModel({
			filterType: ""
		});
		var oSection = new ManagedObject(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--common_filter_dimensions::Section"
		);
		var oEvent = new Event("test", "QUnit", {
			section: oSection
		});

		sinon.stub(this.oViewMock, "getModel").returns({
			getObject: function () {
				return {
					WebTrackingMappingFilterString: ""
				};
			}
		});

		this.oViewMock.getModel.withArgs("filterType").returns(oModel);
		this.oCut.onNavigateSection(oEvent);
		assert.strictEqual(oModel.getData().filterType, "B");
	});

	QUnit.test("onNavigateSection | Expert filter", function (assert) {

		var oModel = new JSONModel({
			filterType: ""
		});
		var oSection = new ManagedObject(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--common_filter_dimensions::Section"
		);
		var oEvent = new Event("test", "QUnit", {
			section: oSection
		});
		sinon.stub(this.oViewMock, "getModel").returns({
			getObject: function () {
				return {
					WebTrackingMappingFilterString: "Test filter string"
				};
			}
		});
		this.oViewMock.getModel.withArgs("filterType").returns(oModel);
		this.oCut.onNavigateSection(oEvent);
		assert.strictEqual(oModel.getData().filterType, "E");
	});

	QUnit.test("onAfterRendering", function (assert) {
		sinon.stub(this.oCut, "_onAfterRootNodeRendering");
		sinon.stub(this.oCut, "_onAfterMainQueryNodeRendering");
		sinon.stub(this.oCut, "_onAfterProductQueryNodeRendering");

		this.oCut.onAfterRendering();

		assert.strictEqual(this.oCut._onAfterRootNodeRendering.calledOnce, true);
		assert.strictEqual(this.oCut._onAfterMainQueryNodeRendering.calledOnce, true);
		assert.strictEqual(this.oCut._onAfterProductQueryNodeRendering.calledOnce, true);
	});

	QUnit.test("_onAfterRootNodeRendering | Entityset == C_MKT_WebTrackingMappingTP", function (assert) {
		var oFooterMock = new ManagedObject();
		var oSaveButtonMock = new sap.m.Button();
		var oCommonFiltersBasicMock = new ManagedObject();
		var oCommonFiltersExpertMock = new ManagedObject();
		var oModelMock = new Model();

		this.oOwnerComponentMock.getEntitySet.returns(
			"C_MKT_WebTrackingMappingTP");
		sinon.stub(oFooterMock, "getAggregation").withArgs("content").returns([new ManagedObject()]);
		sinon.stub(this.oCut, "_enableValuehelpAutobindingOnRootNode");
		sinon.stub(this.oCut, "_enableSideEffectsOnValueChangeForTable");
		sinon.stub(this.oCut, "_renderFilterModeSelector");
		sinon.stub(this.oViewMock, "byId").withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--template::ObjectPage::FooterToolbar"
		).returns(
			oFooterMock
		);
		sinon.stub(oModelMock, "attachPropertyChange");
		sinon.stub(this.oViewMock, "getModel").returns(oModelMock);
		this.oCut.byId.withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--activate"
		).returns(oSaveButtonMock);
		this.oViewMock.byId.withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--common_filters_basic::SubSection"
		).returns(oCommonFiltersBasicMock);
		this.oViewMock.byId.withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--common_filters_expert::SubSection"
		).returns(oCommonFiltersExpertMock);

		this.oCut._onAfterRootNodeRendering();

		assert.strictEqual(this.oCut._renderFilterModeSelector.calledWith(oCommonFiltersBasicMock), true);
		assert.strictEqual(this.oCut._renderFilterModeSelector.calledWith(oCommonFiltersExpertMock), true);
		assert.strictEqual(oModelMock.attachPropertyChange.calledOnce, true);
	});

	QUnit.test("_onAfterMainQueryNodeRendering | Entityset == C_MKT_WebTrckgIntactnHdrTP", function (assert) {
		sinon.stub(this.oCut, "_enableAutobindingQueryDimensionsTable");
		sinon.stub(this.oCut, "_enableAutobindingQueryMetricsTable");
		sinon.stub(this.oCut, "_enableSideEffectsOnValueChangeForTable");

		var oDimensionSmartTable = new sap.ui.comp.smarttable.SmartTable();
		var oMetricSmartTable = new sap.ui.comp.smarttable.SmartTable();
		var oDimensionResponsiveTable = new ManagedObject();
		var oMetricResponsiveTable = new ManagedObject();

		sinon.stub(oDimensionSmartTable, "getTable").returns(oDimensionResponsiveTable);
		sinon.stub(oMetricSmartTable, "getTable").returns(oMetricResponsiveTable);

		sinon.stub(this.oViewMock, "byId").withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrckgIntactnHdrTP--interactionRtrvlHdrDim::Table"
		).returns(oDimensionSmartTable);
		this.oViewMock.byId.withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrckgIntactnHdrTP--interactionRtrvlHdrMsr::Table"
		).returns(oMetricSmartTable);

		this.oOwnerComponentMock.getEntitySet.returns("C_MKT_WebTrckgIntactnHdrTP");

		this.oCut._onAfterMainQueryNodeRendering();

		assert.strictEqual(this.oCut._enableAutobindingQueryDimensionsTable.calledOnce, true);
		assert.strictEqual(this.oCut._enableAutobindingQueryDimensionsTable.calledWith(oDimensionResponsiveTable), true);
		assert.strictEqual(this.oCut._enableAutobindingQueryMetricsTable.calledOnce, true);
		assert.strictEqual(this.oCut._enableAutobindingQueryMetricsTable.calledWith(oMetricResponsiveTable), true);
	});

	QUnit.test("_onAfterMainQueryNodeRendering | Entityset != C_MKT_WebTrckgIntactnHdrTP", function (assert) {
		sinon.stub(this.oCut, "_enableAutobindingQueryDimensionsTable");
		sinon.stub(this.oCut, "_enableAutobindingQueryMetricsTable");

		this.oOwnerComponentMock.getEntitySet.returns("Some other value");

		this.oCut._onAfterMainQueryNodeRendering();

		assert.strictEqual(this.oCut._enableAutobindingQueryDimensionsTable.notCalled, true);
		assert.strictEqual(this.oCut._enableAutobindingQueryMetricsTable.notCalled, true);
	});

	QUnit.test("_onAfterProductQueryNodeRendering | Entityset == C_MKT_WebTrckgProdHeaderTP", function (assert) {
		sinon.stub(this.oCut, "_enableAutobindingQueryDimensionsTable");
		sinon.stub(this.oCut, "_enableAutobindingQueryMetricsTable");
		sinon.stub(this.oCut, "_enableSideEffectsOnValueChangeForTable");

		var oDimensionSmartTable = new sap.ui.comp.smarttable.SmartTable();
		var oMetricSmartTable = new sap.ui.comp.smarttable.SmartTable();
		var oDimensionResponsiveTable = new ManagedObject();
		var oMetricResponsiveTable = new ManagedObject();

		sinon.stub(oDimensionSmartTable, "getTable").returns(oDimensionResponsiveTable);
		sinon.stub(oMetricSmartTable, "getTable").returns(oMetricResponsiveTable);

		sinon.stub(this.oViewMock, "byId").withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrckgProdHeaderTP--productRtrvlHdrDim::Table"
		).returns(oDimensionSmartTable);
		this.oViewMock.byId.withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrckgProdHeaderTP--productRtrvlHdrMsr::Table"
		).returns(oMetricSmartTable);

		this.oOwnerComponentMock.getEntitySet.returns("C_MKT_WebTrckgProdHeaderTP");

		this.oCut._onAfterProductQueryNodeRendering();

		assert.strictEqual(this.oCut._enableAutobindingQueryDimensionsTable.calledOnce, true);
		assert.strictEqual(this.oCut._enableAutobindingQueryDimensionsTable.calledWith(oDimensionResponsiveTable), true);
		assert.strictEqual(this.oCut._enableAutobindingQueryMetricsTable.calledOnce, true);
		assert.strictEqual(this.oCut._enableAutobindingQueryMetricsTable.calledWith(oMetricResponsiveTable), true);

	});

	QUnit.test("_onAfterTagQueryNodeRendering | Entityset == C_MKT_WebTrackingTagHeaderTP", function (assert) {
		var oDimensionSmartTable = new sap.ui.comp.smarttable.SmartTable();
		var oMetricSmartTable = new sap.ui.comp.smarttable.SmartTable();
		var oDimensionResponsiveTable = new ManagedObject();
		var oMetricResponsiveTable = new ManagedObject();

		sinon.stub(oDimensionSmartTable, "getTable").returns(oDimensionResponsiveTable);
		sinon.stub(oMetricSmartTable, "getTable").returns(oMetricResponsiveTable);
		sinon.stub(this.oCut, "_enableAutobindingQueryDimensionsTable");
		sinon.stub(this.oCut, "_enableAutobindingQueryMetricsTable");

		sinon.stub(this.oViewMock, "byId").withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingTagHeaderTP--tagRtrvlHdrDim::Table"
		).returns(oDimensionSmartTable);
		this.oViewMock.byId.withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingTagHeaderTP--tagRtrvlHdrMsr::Table"
		).returns(oMetricSmartTable);

		this.oOwnerComponentMock.getEntitySet.returns("C_MKT_WebTrackingTagHeaderTP");

		this.oCut._onAfterTagQueryNodeRendering();

		assert.strictEqual(this.oCut._enableAutobindingQueryDimensionsTable.calledOnce, true);
		assert.strictEqual(this.oCut._enableAutobindingQueryDimensionsTable.calledWith(oDimensionResponsiveTable), true);
		assert.strictEqual(this.oCut._enableAutobindingQueryMetricsTable.calledOnce, true);
		assert.strictEqual(this.oCut._enableAutobindingQueryMetricsTable.calledWith(oMetricResponsiveTable), true);
	});

	QUnit.test("_onAfterTagQueryNodeRendering | Entityset == C_MKT_WebTrackingTagHeaderTP", function (assert) {
		var oDimensionSmartTable = new sap.ui.comp.smarttable.SmartTable();
		var oMetricSmartTable = new sap.ui.comp.smarttable.SmartTable();
		var oDimensionResponsiveTable = new ManagedObject();
		var oMetricResponsiveTable = new ManagedObject();

		sinon.stub(oDimensionSmartTable, "getTable").returns(oDimensionResponsiveTable);
		sinon.stub(oMetricSmartTable, "getTable").returns(oMetricResponsiveTable);
		sinon.stub(this.oCut, "_enableAutobindingQueryDimensionsTable");
		sinon.stub(this.oCut, "_enableAutobindingQueryMetricsTable");

		sinon.stub(this.oViewMock, "byId").withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingTagHeaderTP--tagRtrvlHdrDim::Table"
		).returns(oDimensionSmartTable);
		this.oViewMock.byId.withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingTagHeaderTP--tagRtrvlHdrMsr::Table"
		).returns(oMetricSmartTable);

		this.oOwnerComponentMock.getEntitySet.returns("C_MKT_WebTrackingTagHeaderTP");

		this.oCut._onAfterTagQueryNodeRendering();

		assert.strictEqual(this.oCut._enableAutobindingQueryDimensionsTable.calledOnce, true);
		assert.strictEqual(this.oCut._enableAutobindingQueryDimensionsTable.calledWith(oDimensionResponsiveTable), true);
		assert.strictEqual(this.oCut._enableAutobindingQueryMetricsTable.calledOnce, true);
		assert.strictEqual(this.oCut._enableAutobindingQueryMetricsTable.calledWith(oMetricResponsiveTable), true);
	});

	QUnit.test("_onAfterTagQueryNodeRendering | Entityset == C_MKT_WebTrackingTagHeaderTP", function (assert) {
		var oDimensionSmartTable = new sap.ui.comp.smarttable.SmartTable();
		var oMetricSmartTable = new sap.ui.comp.smarttable.SmartTable();
		var oDimensionResponsiveTable = new ManagedObject();
		var oMetricResponsiveTable = new ManagedObject();

		sinon.stub(oDimensionSmartTable, "getTable").returns(oDimensionResponsiveTable);
		sinon.stub(oMetricSmartTable, "getTable").returns(oMetricResponsiveTable);
		sinon.stub(this.oCut, "_enableAutobindingQueryDimensionsTable");
		sinon.stub(this.oCut, "_enableAutobindingQueryMetricsTable");

		sinon.stub(this.oViewMock, "byId").withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingTagHeaderTP--tagRtrvlHdrDim::Table"
		).returns(oDimensionSmartTable);
		this.oViewMock.byId.withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingTagHeaderTP--tagRtrvlHdrMsr::Table"
		).returns(oMetricSmartTable);

		this.oOwnerComponentMock.getEntitySet.returns("C_MKT_WebTrackingTagHeaderTP");

		this.oCut._onAfterTagQueryNodeRendering();

		assert.strictEqual(this.oCut._enableAutobindingQueryDimensionsTable.calledOnce, true);
		assert.strictEqual(this.oCut._enableAutobindingQueryDimensionsTable.calledWith(oDimensionResponsiveTable), true);
		assert.strictEqual(this.oCut._enableAutobindingQueryMetricsTable.calledOnce, true);
		assert.strictEqual(this.oCut._enableAutobindingQueryMetricsTable.calledWith(oMetricResponsiveTable), true);
	});

	QUnit.test("_onAfterTagQueryNodeRendering | Entityset == C_MKT_WebTrackingTagHeaderTP", function (assert) {
		var oDimensionSmartTable = new sap.ui.comp.smarttable.SmartTable();
		var oMetricSmartTable = new sap.ui.comp.smarttable.SmartTable();
		var oDimensionResponsiveTable = new ManagedObject();
		var oMetricResponsiveTable = new ManagedObject();

		sinon.stub(oDimensionSmartTable, "getTable").returns(oDimensionResponsiveTable);
		sinon.stub(oMetricSmartTable, "getTable").returns(oMetricResponsiveTable);
		sinon.stub(this.oCut, "_enableAutobindingQueryDimensionsTable");
		sinon.stub(this.oCut, "_enableAutobindingQueryMetricsTable");

		sinon.stub(this.oViewMock, "byId").withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingTagHeaderTP--tagRtrvlHdrDim::Table"
		).returns(oDimensionSmartTable);
		this.oViewMock.byId.withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingTagHeaderTP--tagRtrvlHdrMsr::Table"
		).returns(oMetricSmartTable);

		this.oOwnerComponentMock.getEntitySet.returns("C_MKT_WebTrackingTagHeaderTP");

		this.oCut._onAfterTagQueryNodeRendering();

		assert.strictEqual(this.oCut._enableAutobindingQueryDimensionsTable.calledOnce, true);
		assert.strictEqual(this.oCut._enableAutobindingQueryDimensionsTable.calledWith(oDimensionResponsiveTable), true);
		assert.strictEqual(this.oCut._enableAutobindingQueryMetricsTable.calledOnce, true);
		assert.strictEqual(this.oCut._enableAutobindingQueryMetricsTable.calledWith(oMetricResponsiveTable), true);
	});

	QUnit.test("_onAfterTagQueryNodeRendering | Entityset == C_MKT_WebTrackingTagHeaderTP", function (assert) {
		var oDimensionSmartTable = new sap.ui.comp.smarttable.SmartTable();
		var oMetricSmartTable = new sap.ui.comp.smarttable.SmartTable();
		var oDimensionResponsiveTable = new ManagedObject();
		var oMetricResponsiveTable = new ManagedObject();

		sinon.stub(oDimensionSmartTable, "getTable").returns(oDimensionResponsiveTable);
		sinon.stub(oMetricSmartTable, "getTable").returns(oMetricResponsiveTable);
		sinon.stub(this.oCut, "_enableAutobindingQueryDimensionsTable");
		sinon.stub(this.oCut, "_enableAutobindingQueryMetricsTable");

		sinon.stub(this.oViewMock, "byId").withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingTagHeaderTP--tagRtrvlHdrDim::Table"
		).returns(oDimensionSmartTable);
		this.oViewMock.byId.withArgs(
			"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingTagHeaderTP--tagRtrvlHdrMsr::Table"
		).returns(oMetricSmartTable);

		this.oOwnerComponentMock.getEntitySet.returns("C_MKT_WebTrackingTagHeaderTP");

		this.oCut._onAfterTagQueryNodeRendering();

		assert.strictEqual(this.oCut._enableAutobindingQueryDimensionsTable.calledOnce, true);
		assert.strictEqual(this.oCut._enableAutobindingQueryDimensionsTable.calledWith(oDimensionResponsiveTable), true);
		assert.strictEqual(this.oCut._enableAutobindingQueryMetricsTable.calledOnce, true);
		assert.strictEqual(this.oCut._enableAutobindingQueryMetricsTable.calledWith(oMetricResponsiveTable), true);
	});

	QUnit.test("_onAfterProductQueryNodeRendering | Entityset != C_MKT_WebTrckgProdHeaderTP", function (assert) {
		sinon.stub(this.oCut, "_enableAutobindingQueryDimensionsTable");
		sinon.stub(this.oCut, "_enableAutobindingQueryMetricsTable");

		this.oOwnerComponentMock.getEntitySet.returns("Some other value");

		this.oCut._onAfterProductQueryNodeRendering();

		assert.strictEqual(this.oCut._enableAutobindingQueryDimensionsTable.notCalled, true);
		assert.strictEqual(this.oCut._enableAutobindingQueryMetricsTable.notCalled, true);
	});

	QUnit.test("closeCopyAction", function (assert) {
		var oCopyPopoverMock = {
			close: function () {}
		};
		sinon.stub(oCopyPopoverMock, "close");
		this.oCut._oCopyPopover = oCopyPopoverMock;
		var promise = this.oCut.closeCopyAction();
		this.clock.tick(1000);
		return promise.then(function () {
			assert.strictEqual(oCopyPopoverMock.close.calledOnce, true);
		});
	});

	QUnit.test("_enableSideEffectsOnValueChangeForTable", function (assert) {
		var oTable = new sap.ui.comp.smarttable.SmartTable();
		sinon.stub(oTable, "attachFieldChange");
		sinon.stub(this.oViewMock, "byId").withArgs("tableId").returns(oTable);

		this.oCut._enableSideEffectsOnValueChangeForTable("tableId", "sourceEntity", "sourceProperty");
		assert.strictEqual(oTable.attachFieldChange.calledOnce, true);
	});

	QUnit.module("ObjectPageDetailsExtension Controller Tests | Interaction fields", {
		beforeEach: function () {
			this.oViewMock = new ManagedObject();
			this.oObjectPageLayoutMock = new ObjectPageLayout();
			this.oOwnerComponentMock = {
				getEntitySet: function () {},
				getModel: function () {}
			};
			this.oOwnerComponentModelMock = {
				getResourceBundle: function () {}
			};
			this.oResourceBundleMock = {
				getText: function (sTextId) {}
			};
			this.oBindingContextMock = {
				sPath: "",
				getPath: function () {
					return this.sPath;
				}
			};

			// Instantiate Component Under Test
			this.oCut = new sap.ui.core.mvc.Controller("hpa.cei.wtm.ext.controller.ObjectPageDetailsExtension");

			this.oViewMock = this.oViewMock;
			this.oViewMock.byId = function (id) {};
			this.oViewMock.addDependent = function (oDependent) {};

			// Stub method getView to return mock
			sinon.stub(this.oCut, "getView").returns(this.oViewMock);
			sinon.stub(this.oViewMock, "getBindingContext").returns(this.oBindingContextMock);
			// Stub method byId
			var oStub = sinon.stub(this.oCut, "byId");
			// Stub method byId to return the ObjectPageLayout mock when called with "objectPage" as an argument
			oStub.withArgs("objectPage").returns(this.oObjectPageLayoutMock);

			// Stub method getOwnerComponent to return Component Mock.
			sinon.stub(this.oCut, "getOwnerComponent").returns(this.oOwnerComponentMock);
			sinon.stub(this.oOwnerComponentMock, "getEntitySet");
			sinon.stub(this.oOwnerComponentMock, "getModel").withArgs(
				"i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrackingMappingTP").returns(this.oOwnerComponentModelMock);
			this.oOwnerComponentMock.getModel.returns(this.oOwnerComponentModelMock);
			sinon.stub(this.oOwnerComponentModelMock, "getResourceBundle").returns(this.oResourceBundleMock);
			this.oI18nModelMock = new ResourceModel({
				bundleName: "test"
			});
			this.oResourceBundleMock = ResourceBundle.create({
				url: "test.properties",
				locale: "en"
			});

			sinon.stub(this.oViewMock, "getModel");
			this.oViewMock.getModel.withArgs(
				"i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrackingMappingTP"
			).returns(this.oI18nModelMock);
			sinon.stub(this.oResourceBundleMock, "getText").withArgs("interactionF4ValueColumn").returns("interactionF4ValueColumn");
			this.oResourceBundleMock.getText.withArgs("interactionF4DescriptionColumn").returns("interactionF4DescriptionColumn");
		},

		afterEach: function () {}
	});
	QUnit.test("Test F4Help Binding Info | InteractionType", function (assert) {
		var oBindingInfo = this.oCut._getInteractionF4BindingInfo("InteractionType");
		assert.strictEqual(oBindingInfo.path, "/I_MKT_InteractionType");
		assert.strictEqual(oBindingInfo.key, "InteractionType");
		assert.strictEqual(oBindingInfo.text, "InteractionType_Text");
	});

	QUnit.test("Test F4Help Binding Info | CommunicationMedium", function (assert) {
		var oBindingInfo = this.oCut._getInteractionF4BindingInfo("CommunicationMedium");
		assert.strictEqual(oBindingInfo.path, "/I_MKT_CommMedium");
		assert.strictEqual(oBindingInfo.key, "CommunicationMedium");
		assert.strictEqual(oBindingInfo.text, "CommunicationMedium_Text");
	});

	QUnit.test("Test F4Help Binding Info | InteractionContactOrigin", function (assert) {
		var oBindingInfo = this.oCut._getInteractionF4BindingInfo("InteractionContactOrigin");
		assert.strictEqual(oBindingInfo.path, "/I_MKT_Contactorigin");
		assert.strictEqual(oBindingInfo.key, "InteractionContactOrigin");
		assert.strictEqual(oBindingInfo.text, "InteractionContactOrigin_Text");
	});

	QUnit.test("Test F4Help Binding Info | MarketingArea", function (assert) {
		var oBindingInfo = this.oCut._getInteractionF4BindingInfo("MarketingArea");
		assert.strictEqual(oBindingInfo.path, "/I_MKT_ActiveMarketingArea");
		assert.strictEqual(oBindingInfo.key, "MarketingArea");
		assert.strictEqual(oBindingInfo.text, "MarketingArea_Text");
	});

	QUnit.test("Test F4Help Binding Info | ProductOrigin", function (assert) {
		var oBindingInfo = this.oCut._getInteractionF4BindingInfo("ProductOrigin");
		assert.strictEqual(oBindingInfo.path, "/I_MKT_ProductOrigin");
		assert.strictEqual(oBindingInfo.key, "ProductOrigin");
		assert.strictEqual(oBindingInfo.text, "ProductOrigin_Text");
	});

	QUnit.test("Test F4Help Binding Info | DeviceType", function (assert) {
		var oBindingInfo = this.oCut._getInteractionF4BindingInfo("DeviceType");
		assert.strictEqual(oBindingInfo.path, "/I_MKT_DeviceType");
		assert.strictEqual(oBindingInfo.key, "DeviceType");
		assert.strictEqual(oBindingInfo.text, "DeviceType_Text");
	});

	QUnit.test("Test F4Help Binding Info | InteractionCurrency", function (assert) {
		var oBindingInfo = this.oCut._getInteractionF4BindingInfo("InteractionCurrency");
		assert.strictEqual(oBindingInfo.path, "/I_Currency");
		assert.strictEqual(oBindingInfo.key, "Currency");
		assert.strictEqual(oBindingInfo.text, "Currency_Text");
	});

	QUnit.test("Test F4Help Binding Info | InteractionLanguage", function (assert) {
		var oBindingInfo = this.oCut._getInteractionF4BindingInfo("InteractionLanguage");
		assert.strictEqual(oBindingInfo.path, "/I_Language");
		assert.strictEqual(oBindingInfo.key, "Language");
		assert.strictEqual(oBindingInfo.text, "Language_Text");
	});

	QUnit.test("Test F4Help Binding Info | MKT_AgreementOrigin", function (assert) {
		var oBindingInfo = this.oCut._getInteractionF4BindingInfo("MKT_AgreementOrigin");
		assert.strictEqual(oBindingInfo.path, "/I_MKT_AgreementOrigin");
		assert.strictEqual(oBindingInfo.key, "MKT_AgreementOrigin");
		assert.strictEqual(oBindingInfo.text, "MKT_AgreementOrigin_Text");
	});

	QUnit.test("Test F4Help Binding Info | DigitalAccountType", function (assert) {
		var oBindingInfo = this.oCut._getInteractionF4BindingInfo("DigitalAccountType");
		assert.strictEqual(oBindingInfo.path, "/I_MKT_DigitalAccountType");
		assert.strictEqual(oBindingInfo.key, "DigitalAccountType");
		assert.strictEqual(oBindingInfo.text, "DigitalAccountType_Text");
	});

	QUnit.test("Test F4Help Binding Info | InteractionReason", function (assert) {
		var oBindingInfo = this.oCut._getInteractionF4BindingInfo("InteractionReason");
		assert.strictEqual(oBindingInfo.path, "/I_MKT_InteractionReason");
		assert.strictEqual(oBindingInfo.key, "InteractionReason");
		assert.strictEqual(oBindingInfo.text, "InteractionReason_Text");
	});

	QUnit.test("Test F4Help Binding Info | InteractionSentimentValue", function (assert) {
		var oBindingInfo = this.oCut._getInteractionF4BindingInfo("InteractionSentimentValue");
		assert.strictEqual(oBindingInfo.path, "/I_MKT_InteractionSentiment");
		assert.strictEqual(oBindingInfo.key, "InteractionSentiment");
		assert.strictEqual(oBindingInfo.text, "InteractionSentiment_Text");
	});

	QUnit.test("Test F4Help Binding Info | InteractionStatus", function (assert) {
		var oBindingInfo = this.oCut._getInteractionF4BindingInfo("InteractionStatus");
		assert.strictEqual(oBindingInfo.path, "/I_MKT_InteractionStatus");
		assert.strictEqual(oBindingInfo.key, "InteractionStatus");
		assert.strictEqual(oBindingInfo.text, "InteractionStatus_Text");
	});

	QUnit.test("Test F4Help Binding Info | MarketingLocationOrigin", function (assert) {
		var oBindingInfo = this.oCut._getInteractionF4BindingInfo("MarketingLocationOrigin");
		assert.strictEqual(oBindingInfo.path, "/I_MKT_LocationOrigin");
		assert.strictEqual(oBindingInfo.key, "MarketingLocationOrigin");
		assert.strictEqual(oBindingInfo.text, "MarketingLocationOrigin_Text");
	});

	QUnit.test("Test F4Help Binding Info | InteractionProductUnit", function (assert) {
		var oBindingInfo = this.oCut._getInteractionF4BindingInfo("InteractionProductUnit");
		assert.strictEqual(oBindingInfo.path, "/I_UnitOfMeasure");
		assert.strictEqual(oBindingInfo.key, "UnitOfMeasure");
		assert.strictEqual(oBindingInfo.text, "UnitOfMeasure_Text");
	});

	QUnit.test("Test F4Help Binding Info | InteractionProductStatus", function (assert) {
		var oBindingInfo = this.oCut._getInteractionF4BindingInfo("InteractionProductStatus");
		assert.strictEqual(oBindingInfo.path, "/I_MKT_InteractionProductStatus");
		assert.strictEqual(oBindingInfo.key, "InteractionProductStatus");
		assert.strictEqual(oBindingInfo.text, "InteractionProductStatus_Text");
	});

	QUnit.test("Test F4Help Binding Info | InteractionIsAnonymous", function (assert) {
		var oBindingInfo = this.oCut._getInteractionF4BindingInfo("InteractionIsAnonymous");
		assert.strictEqual(oBindingInfo.path, "boolModel>/items");
		assert.strictEqual(oBindingInfo.key, "key");
		assert.strictEqual(oBindingInfo.text, "text");
	});

	QUnit.test("Test VH enabled| InteractionType", function (assert) {
		var bEnabled = this.oCut.enableInteractionVH("InteractionType");
		assert.strictEqual(bEnabled, true);
	});

	QUnit.test("Test VH enabled| CommunicationMedium", function (assert) {
		var bEnabled = this.oCut.enableInteractionVH("CommunicationMedium");
		assert.strictEqual(bEnabled, true);
	});

	QUnit.test("Test VH enabled| InteractionContactOrigin", function (assert) {
		var bEnabled = this.oCut.enableInteractionVH("InteractionContactOrigin");
		assert.strictEqual(bEnabled, true);
	});

	QUnit.test("Test VH enabled| MarketingArea", function (assert) {
		var bEnabled = this.oCut.enableInteractionVH("MarketingArea");
		assert.strictEqual(bEnabled, true);
	});

	QUnit.test("Test VH enabled| ProductOrigin", function (assert) {
		var bEnabled = this.oCut.enableInteractionVH("ProductOrigin");
		assert.strictEqual(bEnabled, true);
	});

	QUnit.test("Test VH enabled| DeviceType", function (assert) {
		var bEnabled = this.oCut.enableInteractionVH("DeviceType");
		assert.strictEqual(bEnabled, true);
	});

	QUnit.test("Test VH enabled| InteractionCurrency", function (assert) {
		var bEnabled = this.oCut.enableInteractionVH("InteractionCurrency");
		assert.strictEqual(bEnabled, true);
	});

	QUnit.test("Test VH enabled| InteractionLanguage", function (assert) {
		var bEnabled = this.oCut.enableInteractionVH("InteractionLanguage");
		assert.strictEqual(bEnabled, true);
	});

	QUnit.test("Test VH enabled| MKT_AgreementOrigin", function (assert) {
		var bEnabled = this.oCut.enableInteractionVH("MKT_AgreementOrigin");
		assert.strictEqual(bEnabled, true);
	});

	QUnit.test("Test VH enabled| DigitalAccountType", function (assert) {
		var bEnabled = this.oCut.enableInteractionVH("DigitalAccountType");
		assert.strictEqual(bEnabled, true);
	});

	QUnit.test("Test VH enabled| InteractionReason", function (assert) {
		var bEnabled = this.oCut.enableInteractionVH("InteractionReason");
		assert.strictEqual(bEnabled, true);
	});

	QUnit.test("Test VH enabled| InteractionSentimentValue", function (assert) {
		var bEnabled = this.oCut.enableInteractionVH("InteractionSentimentValue");
		assert.strictEqual(bEnabled, true);
	});

	QUnit.test("Test VH enabled| InteractionStatus", function (assert) {
		var bEnabled = this.oCut.enableInteractionVH("InteractionStatus");
		assert.strictEqual(bEnabled, true);
	});

	QUnit.test("Test VH enabled| MarketingLocationOrigin", function (assert) {
		var bEnabled = this.oCut.enableInteractionVH("MarketingLocationOrigin");
		assert.strictEqual(bEnabled, true);
	});

	QUnit.test("Test VH enabled| InteractionProductUnit", function (assert) {
		var bEnabled = this.oCut.enableInteractionVH("InteractionProductUnit");
		assert.strictEqual(bEnabled, true);
	});

	QUnit.test("Test VH enabled| InteractionProductStatus", function (assert) {
		var bEnabled = this.oCut.enableInteractionVH("InteractionProductStatus");
		assert.strictEqual(bEnabled, true);
	});

	QUnit.test(
		"beforeLineItemDeleteExtension | hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgValMapping::com.sap.vocabularies.UI.v1.LineItem::Table",
		function (assert) {
			this.oViewMock.getModel.withArgs("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrckgValMappingTP").returns({
				getResourceBundle: function () {
					return {
						getText: function (sKey) {
							switch (sKey) {
							case "popupTitleText":
								return "titleText";
							case "popupDescriptionText":
								return "descriptionText";
							default:
								return null;
							}
						}
					};
				}
			});
			var oMessages = this.oCut.beforeLineItemDeleteExtension({
				sUiElementId: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgValMapping::com.sap.vocabularies.UI.v1.LineItem::Table"
			});
			assert.strictEqual(oMessages.title, "titleText");
			assert.strictEqual(oMessages.text, "descriptionText");
		});

	QUnit.test(
		"beforeLineItemDeleteExtension | hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgRtrvlIntactnHdr::com.sap.vocabularies.UI.v1.LineItem::Table",
		function (assert) {
			this.oViewMock.getModel.withArgs("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrckgIntactnHdrTP").returns({
				getResourceBundle: function () {
					return {
						getText: function (sKey) {
							switch (sKey) {
							case "popupTitleText":
								return "titleText";
							case "popupDescriptionText":
								return "descriptionText";
							default:
								return null;
							}
						}
					};
				}
			});
			var oMessages = this.oCut.beforeLineItemDeleteExtension({
				sUiElementId: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgRtrvlIntactnHdr::com.sap.vocabularies.UI.v1.LineItem::Table"
			});
			assert.strictEqual(oMessages.title, "titleText");
			assert.strictEqual(oMessages.text, "descriptionText");
		});

	QUnit.test(
		"beforeLineItemDeleteExtension | hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgRtrvlProdHdr::com.sap.vocabularies.UI.v1.LineItem::Table",
		function (assert) {
			this.oViewMock.getModel.withArgs("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrckgProdHeaderTP").returns({
				getResourceBundle: function () {
					return {
						getText: function (sKey) {
							switch (sKey) {
							case "popupTitleText":
								return "titleText";
							case "popupDescriptionText":
								return "descriptionText";
							default:
								return null;
							}
						}
					};
				}
			});
			var oMessages = this.oCut.beforeLineItemDeleteExtension({
				sUiElementId: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgRtrvlProdHdr::com.sap.vocabularies.UI.v1.LineItem::Table"
			});
			assert.strictEqual(oMessages.title, "titleText");
			assert.strictEqual(oMessages.text, "descriptionText");
		});

	QUnit.test(
		"beforeLineItemDeleteExtension | hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgMappgFltr::com.sap.vocabularies.UI.v1.LineItem::Table",
		function (assert) {
			this.oViewMock.getModel.withArgs("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrckgMappgFltrTP").returns({
				getResourceBundle: function () {
					return {
						getText: function (sKey) {
							switch (sKey) {
							case "popupTitleText":
								return "titleText";
							case "popupDescriptionText":
								return "descriptionText";
							default:
								return null;
							}
						}
					};
				}
			});
			var oMessages = this.oCut.beforeLineItemDeleteExtension({
				sUiElementId: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgMappgFltr::com.sap.vocabularies.UI.v1.LineItem::Table"
			});
			assert.strictEqual(oMessages.title, "titleText");
			assert.strictEqual(oMessages.text, "descriptionText");
		});

	QUnit.test(
		"beforeLineItemDeleteExtension | hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgComMapping::com.sap.vocabularies.UI.v1.LineItem::Table",
		function (assert) {
			this.oViewMock.getModel.withArgs("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrckgComMappingTP").returns({
				getResourceBundle: function () {
					return {
						getText: function (sKey) {
							switch (sKey) {
							case "popupTitleText":
								return "titleText";
							case "popupDescriptionText":
								return "descriptionText";
							default:
								return null;
							}
						}
					};
				}
			});
			var oMessages = this.oCut.beforeLineItemDeleteExtension({
				sUiElementId: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgComMapping::com.sap.vocabularies.UI.v1.LineItem::Table"
			});
			assert.strictEqual(oMessages.title, "titleText");
			assert.strictEqual(oMessages.text, "descriptionText");
		});

	/*QUnit.test("Test VH enabled| InteractionIsAnonymous", function (assert) {
		var bEnabled = this.oCut.enableInteractionVH("InteractionIsAnonymous");
		assert.strictEqual(bEnabled, true);
	});

	QUnit.test("Test VH enabled| Other", function (assert) {
		sinon.stub(this.oViewMock, "getModel").returns({
			getObject: function(sPath) {
				return undefined;
			}
		});
		var bEnabled = this.oCut.enableInteractionVH("other");
		assert.strictEqual(bEnabled, false);
	});
	
	QUnit.test("Test VH enabled| Ext Field No Values", function (assert) {
		sinon.stub(this.oViewMock, "getModel").returns({
			getObject: function(sPath) {
				return {
					HasValues: false
				};
			}
		});
		var bEnabled = this.oCut.enableInteractionVH("other");
		assert.strictEqual(bEnabled, false);
	});
	
	QUnit.test("Test VH enabled| Ext Field with Values", function (assert) {
		sinon.stub(this.oViewMock, "getModel").returns({
			getObject: function(sPath) {
				return {
					HasValues: true
				};
			}
		});
		var bEnabled = this.oCut.enableInteractionVH("other");
		assert.strictEqual(bEnabled, true);
	});*/

});