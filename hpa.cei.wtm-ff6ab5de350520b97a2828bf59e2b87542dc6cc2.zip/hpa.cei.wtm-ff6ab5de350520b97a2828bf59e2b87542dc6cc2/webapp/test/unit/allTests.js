sap.ui.define([
	"test/unit/controller/ObjectPageDetailsExtension.controller",
	"test/unit/controller/ListReportExtension.controller",
	"test/unit/controller/BigQuery.controller"
], function () {
	"use strict";
});