sap.ui.define([
	"sap/ui/test/opaQunit",
	"hpa/cei/wtm/test/integration/pages/Common"
], function (opaTest) {
	"use strict";
	QUnit.module("ListReport Journey");

	/*opaTest("Filter BigQuery configurations", function (Given, When, Then) {
		Given.iStartTheApp();

		When.onTheListReportPage
			.iOpenTheFilterBar();

		When.onTheGenericListReport
			.iClickTheMultiComboBoxArrow("WebTrackingMappingDataSource")
			.and
			.iSelectItemsFromMultiComboBox("WebTrackingMappingDataSource", "Google BigQuery")
			.and
			.iExecuteTheSearch()
			.and
			.iLookAtTheScreen();
			
		Then.onTheGenericListReport
			.theResultListIsVisible();
		Then.onTheListReportPage
			.theResultListIsEmpty();
	});

	opaTest("Filter Analytics configurations", function (Given, When, Then) {

		When.onTheGenericListReport
			.iLookAtTheScreen()
			.and
			.iClickTheMultiComboBoxArrow("WebTrackingMappingDataSource");
		When.onTheListReportPage
			.iUnselectItemsFromMultiComboBox("WebTrackingMappingDataSource", "Google BigQuery");
		When.onTheGenericListReport
			.and
			.iSelectItemsFromMultiComboBox("WebTrackingMappingDataSource", "Google Analytics")
			.and
			.iExecuteTheSearch()
			.and
			.iLookAtTheScreen();

		Then.onTheListReportPage
			.theConfigIsLoadedInTheSmartTable();

		Then.onTheGenericListReport
			.theResultListIsVisible();
			
		Then.onTheGenericListReport
			.theResultListContainsTheCorrectNumberOfItems(3);
	});

	opaTest("Filter Active configurations", function (Given, When, Then) {
		When.onTheGenericListReport
			.iClickTheMultiComboBoxArrow("WebTrackingMappingStatus")
			.and
			.iSelectItemsFromMultiComboBox("WebTrackingMappingStatus", "Active")
			.and
			.iExecuteTheSearch();
		Then.onTheGenericListReport
			.theResultListIsVisible();
		Then.onTheGenericListReport
			.theResultListContainsTheCorrectNumberOfItems(1);
	});

	opaTest("Filter Inactive configurations", function (Given, When, Then) {
		When.onTheGenericListReport
			.iClickTheMultiComboBoxArrow("WebTrackingMappingStatus");
		When.onTheListReportPage
			.iUnselectItemsFromMultiComboBox("WebTrackingMappingStatus", "Active");
		When.onTheGenericListReport
			.iSelectItemsFromMultiComboBox("WebTrackingMappingStatus", "Inactive")
			.and
			.iExecuteTheSearch();
		Then.onTheGenericListReport
			.theResultListIsVisible();
			
		Then.onTheGenericListReport
			.theResultListContainsTheCorrectNumberOfItems(1);
			
		Then.iTeardownMyAppFrame();
	});*/
});