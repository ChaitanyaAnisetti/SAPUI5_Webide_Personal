sap.ui.define([
	"sap/ui/test/opaQunit"
], function(opaTest) {
		"use strict";
		QUnit.module("ObjectPage Journey");
		
		//Part 1
		opaTest("Load Object Page", function (Given, When, Then) {
			Given.iStartTheApp();
			
			//click on Go button before required
			When.onTheListReportPage
			.iClickOnGo();
			
			When.onTheGenericListReport
			.iNavigateFromListItemByFieldValue({Field: "WebTrackingMappingName", Value:"ac_gaTerm_parsingTest001"});
			
			Then.onTheObjectPage
			.iCheckTheObjectTitle("ac_gaTerm_parsingTest001");
			
		});
		
		opaTest("Open Copy Popup", function(Given, When, Then){
			When.onTheObjectPage
			.iClickOnCopyButton();
			
			When.onTheGenericObjectPage
			.iClickTheButtonOnTheDialog("Cancel");
			
			Then.onTheGenericObjectPage
			.theObjectPageHeaderTitleIsCorrect("ac_gaTerm_parsingTest001");
		});
		
		opaTest("Copy the Object", function(Given, When, Then){
			
			When.onTheObjectPage
			.iClickOnCopyButton()
			.and
			.iClickOnCreateInDialog();
			
			Then.onTheObjectPage
			.iCheckTheObjectTitle("Copy of ac_gaTerm_parsingTest001");
			
		});
		
		opaTest("Deactivate the object", function(Given, When, Then){
			
			When.onTheObjectPage
			.iClickOnDeactivateButton();
			
			Then.onTheObjectPage
			.iSeeValidateButton();

		});
		
		opaTest("When the date is invalid, the dialog should not allow to submit the action", function(Given, When, Then) {
			When.onTheObjectPage
			.iClickOnValidateButton();
			
			When.onTheObjectPage
			.iSetValidateInputField();
			
			Then.onTheObjectPage
			.theValidateDialogIsInState(sap.ui.core.ValueState.Error);
			
			Then.onTheObjectPage
			.theValidateDialogOkButtonIsEnabled(false);
			
			When.onTheObjectPage
			.iClickOnCancel();
		});
		
		opaTest("Validate Date With Input", function(Given, When, Then){
			
			When.onTheObjectPage
			.iClickOnValidateButton();
			
			When.onTheObjectPage
			.iClickOnCancel();
			
			Then.onTheObjectPage
			.iShouldSeeTheValidationResults(0);
			
			When.onTheObjectPage
			.iClickOnValidateButton();
			
			//change the destination of the function to "onTheObjectPage" because personalized function
			//defined in ObjectPage.js
			When.onTheObjectPage
			.iSetValidateInputField();    
			
			When.onTheObjectPage
			.iClickOnOK();
			
			Then.onTheObjectPage
			.iCheckTheObjectTitle("Copy of ac_gaTerm_parsingTest001");
			
			When.onTheObjectPage
			.iClickOnValidateButton();
			
			When.onTheObjectPage
			.iSetValidateInputFieldRight();
			
			When.onTheObjectPage
			.iClickOnOK();
			
			Then.onTheObjectPage
			.iShouldSeeTheValidationResults(1);
			
			When.onTheObjectPage
			.iClickTheBackBtn();
			
			When.onTheObjectPage
			.iClickTheBackBtn();
			
			When.onTheGenericListReport
			.iNavigateFromListItemByFieldValue({Field: "WebTrackingMappingName", Value:"BQ valid"});
			
			Then.onTheObjectPage
			.iCheckTheObjectTitle("BQ valid");
			
			When.onTheObjectPage
			.iClickOnBQValidateButton();
			
			When.onTheObjectPage
			.iClickOnOKBQ();
			
			When.onTheObjectPage
			.iClickOnBQValidateButton();
			
			When.onTheObjectPage
			.iSetValidateInputFieldBQ();
			
			When.onTheObjectPage
			.iClickOnOKBQ();
			
			//For now...
			Then.onTheObjectPage
			.iCheckTheObjectTitle("BQ valid");
			
			When.onTheObjectPage
			.iClickTheBackBtn();
			
			When.onTheListReportPage
			.iClickOnGo();

			Then.iTeardownMyAppFrame();

		});
	}
);