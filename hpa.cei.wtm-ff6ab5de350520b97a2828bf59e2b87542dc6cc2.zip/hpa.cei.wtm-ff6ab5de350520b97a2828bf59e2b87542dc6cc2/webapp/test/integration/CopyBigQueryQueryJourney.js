sap.ui.define([
	"sap/ui/test/opaQunit"
], function (opaTest) {
	"use strict";
	QUnit.module("Copy BigQuery Query");

	opaTest("When I go to a BigQuery configuration and navigate to the query tab, I should see the code editor.", function (Given, When,
		Then) {
		Given.iStartTheApp();

		//click on Go button before required
		When.onTheListReportPage
			.iClickOnGo();

		When.onTheGenericListReport
			.iNavigateFromListItemByFieldValue({
				Field: "WebTrackingMappingName",
				Value: "Big Query Contact Match ID"
			});

		When.onTheObjectPage
			.iSetSelectedSectionTo(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--AfterFacet::C_MKT_WebTrackingMappingTP::queries::Section"
			);

		Then.onTheObjectPage
			.iSeeTheBigQueryCodeEditorWithId(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--bqEditor--codeEditor"
			);
	});

	opaTest("When in the Query tab, I should see the Interaction Fields helper button", function (Given, When, Then) {
		When.onTheGenericListReport
			.iLookAtTheScreen();

		Then.onTheObjectPage
			.iSeeTheInteractionFieldsHelperDialogButton();
	});

	opaTest("When in the query tab, I should see the copy query button", function (Given, When, Then) {
		When.onTheGenericListReport
			.iLookAtTheScreen();

		Then.onTheObjectPage
			.iSeeTheCopyQueryButton();
	});

	opaTest("When the Query Configuration is in display mode, the code editor should be disabled", function (Given, When, Then) {
		When.onTheGenericListReport
			.iLookAtTheScreen();
		Then.onTheObjectPage
			.iSeeTheBigQueryCodeEditorWithIdIsEditable(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--bqEditor--codeEditor",
				false);
	});

	opaTest("When in the query tab and the copy query button is pressed, I see the copy query dialog", function (Given, When, Then) {
		When.onTheObjectPage
			.iPressTheCopyQueryButton();
		Then.onTheGenericObjectPage
			.iShouldSeeTheDialogWithTitle("Copy Query");
		Then.onTheObjectPage
			.iSeeAllTheTextIsSelected();
	});

	opaTest("When I press on the close button in the dialog, the copy dialog closes.", function (Given, When, Then) {
		When.onTheGenericListReport
			.iLookAtTheScreen();
		When.onTheObjectPage
			.iCloseTheCopyQueryDialog();
		Then.onTheObjectPage
			.iSeeTheBigQueryCodeEditorWithIdIsEditable(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--bqEditor--codeEditor",
				false);
	});
});