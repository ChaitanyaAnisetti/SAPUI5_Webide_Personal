sap.ui.define([
		"sap/ui/test/Opa5"
	], function(Opa5) {
		"use strict";

		function getFrameUrl (sHash, sUrlParameters) {
			var sUrl = jQuery.sap.getResourcePath("hpa/cei/wtm/app", ".html");
			sHash = sHash || "";
			sUrlParameters = sUrlParameters ? "?" + sUrlParameters : "";

			if (sHash) {
				sHash = "#C_MKT_WebTrackingMappingTP-display&/" + (sHash.indexOf("/") === 0 ? sHash.substring(1) : sHash);
			} else {
				sHash = "#C_MKT_WebTrackingMappingTP-display";
			}

			return sUrl + sUrlParameters + sHash;
		}
		
		return Opa5.extend("hpa.cei.wtm.test.integration.pages.Common", {

			iStartTheApp : function (oOptions) {
				oOptions = oOptions || {};
				// Start the app with a minimal delay to make tests run fast but still async to discover basic timing issues
				this.iStartMyAppInAFrame({
					source: getFrameUrl(oOptions.hash, "serverDelay=1000"),
					timeout: 150, 
					autoWait: true
				});
			},
			
			iLookAtTheScreen : function () {
				return this;
			},
			
			iUnselectItemsFromMultiCboBox: function(sFieldName, sItem) {
				var oCheckBox = null;
				return this.waitFor({
					controlType: "sap.m.CheckBox",
					check: function(aCheckBox) {
						for (var i=0; i < aCheckBox.length; i++ ){
							if (aCheckBox[i].getParent() && aCheckBox[i].getParent().getParent() && aCheckBox[i].getParent().getParent().getParent() && aCheckBox[i].getParent().getParent().getParent().getParent() && 
								(aCheckBox[i].getParent().getParent().getParent().getParent().getId().indexOf(sFieldName) > -1)) {
								
								var sTitle = aCheckBox[i].getParent().getTitle();
								if (sTitle === sItem) {
									oCheckBox = aCheckBox[i];
									return true;
								}
							}
							
						}
						return false;
					},
					success: function() {
						oCheckBox.fireSelect({
							selected: false
						});
						ok(true, "The list item with label '" + sItem + "' was unchecked");
					},
					errorMessage: "The list item with label "+sItem+" could not be rendered/checked"
				});

			}
		});
	}
);