sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"hpa/cei/wtm/test/integration/pages/Common",
	"sap/ui/test/actions/Press",
	"sap/ui/model/resource/ResourceModel"
], function(Opa5, PropertyStrictEquals, AggregationFilled, Common, Press, ResourceModel) {
		"use strict";

		Opa5.createPageObjects({
			onTheListReportPage : {
				baseClass : Common,

				actions : {
					iSelectAnObject: function(){
						return this.waitFor({
							controlType: "sap.m.RadioButton",
							success: function(oRadios){
								//this thing works. nice
								oRadios[0].$().trigger("tap");
							},
							errorMessage: "Could not find any radio buttons on the List Report page."
						});
					},
					
					iDeleteTheObject: function(){
						return this.waitFor({
							id: "hpa.cei.wtm::sap.suite.ui.generic.template.ListReport.view.ListReport::C_MKT_WebTrackingMappingTP--deleteEntry",
							success: function(oButton){
								oButton.firePress();
							},
							errorMessage: "Could not find the delete button on the List Report page."
						});
					},
					
					iConfirmDeletionOfObject: function(){
						return this.waitFor({
							controlType: "sap.m.Button",
							searchOpenDialogs: true,
							success: function(oButtons){
								oButtons[0].firePress();
							},
							errorMessage: "Could not find the delete button to confirm the deletion of an object on the List Report page."
						});
					},
					
					iClickOnGo: function(){
						//the go button will be pressed whether or not it appears.
						return this.waitFor({
									id: "hpa.cei.wtm::sap.suite.ui.generic.template.ListReport.view.ListReport::C_MKT_WebTrackingMappingTP--listReportFilter-btnGo",
									visible: false,
									success: function(oGo){
										//This is the arrow button in the List object view
										oGo.firePress();
									}
								});
					}
				},

				assertions : {
					theResultListIsEmpty: function() {
						return this.waitFor({
							controlType: "sap.ui.comp.smarttable.SmartTable",
							id: "hpa.cei.wtm::sap.suite.ui.generic.template.ListReport.view.ListReport::C_MKT_WebTrackingMappingTP--listReport",
							success: function(oControl) {
								QUnit.equal(oControl.getTable().getItems().length, 0, "The results table is empty.");
							}
						});
					},
					theConfigIsLoadedInTheSmartTable: function() {
						return this.waitFor({
							controlType: "sap.m.Table",
							matchers: [
								new AggregationFilled({
									name: "items"
								}), function(oTable) {
									var oContext;
									if (oTable.getItems()[0]) {
										oContext = oTable.getItems()[0].getBindingContext();
									}
									return !!oContext;
								}
							],
							success: function(oTable) {
								QUnit.notEqual(oTable[0].getItems().length, 0, "Config loaded in the Smart Table");
							},
							errorMessage: "Config was not loaded into the Smart Table"
						});
					}

				}
			}
		});
	}
);