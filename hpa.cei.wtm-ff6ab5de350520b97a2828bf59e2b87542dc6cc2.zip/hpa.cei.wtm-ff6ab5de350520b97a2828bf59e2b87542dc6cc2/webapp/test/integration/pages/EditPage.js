sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"hpa/cei/wtm/test/integration/pages/Common",
	"sap/ui/test/actions/Press",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/test/actions/EnterText",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/unified/DateRange"
], function (Opa5, PropertyStrictEquals, AggregationFilled, Common, Press, ResourceModel, EnterText, Properties, AggregationLengthEquals,
	DateRange) {
	"use strict";

	Opa5.createPageObjects({
		onTheEditPage: {
			baseClass: Common,

			//the IDs use are based on the HTML source code when inspecting the page
			actions: {
				iWriteTextInTheExpertFilter: function (sText) {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--com.sap.vocabularies.UI.v1.FieldGroup::expertFilter_FG::WebTrackingMappingFilterString::Field-textArea",
						success: function (oExpertFilterTextInput) {
							oExpertFilterTextInput.setValue(sText);
							oExpertFilterTextInput.fireChange({
								value: sText
							});
						}
					});
				},
				//tricky one: had to take ID of a div element and not a button id
				//
				iClickOnCommonQueryFilterButton: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--objectPage-anchBar-hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--common_filter_dimensions::Section-anchor-internalSplitBtn",
						success: function (oButton) {
							oButton.firePress();
						},
						errorMessage: "Could not find the Common Query Filter and Dimensions tab in the Object page."
					});
				},

				iChangeFilterModeTo: function (sFilterMode) {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--common_filters_expert::SubSection",
						visible: false,
						success: function (oExpertSubSection) {
							if (oExpertSubSection.getVisible()) {
								return this.waitFor({
									id: oExpertSubSection.getId() + "--filterTypeSegmentedButton",
									success: function (oSegmentedButton) {
										oSegmentedButton.getItems().forEach(function (oItem) {
											if (oItem.getKey() === sFilterMode) {
												oSegmentedButton.setSelectedKey(oItem.getKey());
												oSegmentedButton.fireSelectionChange({
													item: oItem
												});
											}
										});

										oSegmentedButton.setSelectedKey(sFilterMode);
									},
									errorMessage: "Segmented buttons not found"
								});
							} else {
								return this.waitFor({
									id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--common_filters_basic::SubSection",
									success: function (oBasicSubSection) {
										return this.waitFor({
											id: oBasicSubSection.getId() + "--filterTypeSegmentedButton",
											success: function (oSegmentedButton) {
												oSegmentedButton.getItems().forEach(function (oItem) {
													if (oItem.getKey() === sFilterMode) {
														oSegmentedButton.setSelectedKey(oItem.getKey());
														oSegmentedButton.fireSelectionChange({
															item: oItem
														});
													}
												});
											},
											errorMessage: "Segmented buttons not found"
										});
									}
								});
							}
						},
						errorMessage: "Could not find the BigQuery Query tab in the Object page"
					});
				},
				//
				iClickOnInteractionFieldsButton: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--objectPage-anchBar-hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgValMapping::com.sap.vocabularies.UI.v1.LineItem::Section-anchor",
						success: function (oButton) {
							oButton.firePress();
						},
						errorMessage: "Could not find the Interaction Fields tab in the Object page."
					});
				},

				//
				iClickOnQueriesButton: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--objectPage-anchBar-hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--queries::Section-anchor-internalSplitBtn",
						success: function (oButton) {
							oButton.firePress();
						},
						errorMessage: "Could not find the Queries tab in the Object page."
					});
				},

				//
				iAddAnInteractionField: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgValMapping::com.sap.vocabularies.UI.v1.LineItem::addEntry",
						success: function (oButton) {
							var length;
							//identify if the list has changed length
							this.waitFor({
								id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgValMapping::com.sap.vocabularies.UI.v1.LineItem::responsiveTable",
								success: function (list) {
									//capture length b4
									length = list.getItems().length;
									oButton.firePress();

								},
								errorMessage: "Could not find the list with the Interaction Fields results under the Interaction Fields tab on the Object page."
							});

							this.waitFor({
								id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgValMapping::com.sap.vocabularies.UI.v1.LineItem::responsiveTable",
								success: function (list) {
									//capture length b4
									if (length === list.getItems().length) {
										oButton.firePress();
									}

								},
								errorMessage: "Could not find the list with the Interaction Fields results under the Interaction Fields tab on the Object page."
							});
						},
						errorMessage: "Could not find the + button in the Interaction Fields tab while in Edit mode on the Object page."
					});
				},

				//
				iConfirmDeletion: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						matchers: function (oControl) {
							return oControl.getId().indexOf(
								"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--deleteConfirmationDialog-footer"
							) !== -1;
						},
						success: function (oFooter) {
							oFooter[0].getContent()[1].firePress();
						},
						errorMessage: "Could not find the delete confirmation button on the delete dialog."
					});
				},

				//
				iAddACommonFilter: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgMappgFltr::com.sap.vocabularies.UI.v1.LineItem::addEntry",
						success: function (oButton) {
							oButton.firePress();
						},
						errorMessage: "Could not find the + button in the Common Filter section in the Common Query Filter and Dimensions tab on the Object page in Edit mode."
					});
				},

				//
				iSelectACommonFilter: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgMappgFltr::com.sap.vocabularies.UI.v1.LineItem::responsiveTable",
						success: function (list) {
							var oItem = list.getItems()[0];
							list.setSelectedItem(oItem);
							list.fireSelectionChange({
								listItem: oItem,
								selected: true
							});
							/*this.waitFor({
								controlType: "sap.m.RadioButton",
								success: function (oRadios) {
									//this thing works. nice
									//Notice I start at index 2 here. This is because the first indexes belong to the dimensions

									oRadios[2].$().trigger("tap");
									return this.waitFor({
											id: oRadios[2].getId(),
											actions: new Press()
										})
										//distinguishes btw ugly qunit version and opa version
										//if(oRadios.length >= 7)
										//	oRadios[6].$().trigger("tap");
								},
								errorMessage: "Could not find any radio buttons in the Common Query Filter and Dimensions tab on the Object page in Edit mode."
							});*/

						},
						errorMessage: "Could not find any list in the common filter section in the Common Query Filter and Dimensions tab on the Object page in Edit mode."
					});
				},

				//
				iRemoveACommonFilter: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgMappgFltr::com.sap.vocabularies.UI.v1.LineItem::deleteEntry",
						success: function (oButton) {
							oButton.firePress();
						},
						errorMessage: "Could not find the Delete button to remove a common filter in the Common Query Filter and Dimensions tab on the Object page in Edit mode."
					});
				},
				////////////////////////////
				//
				iSelectANewOperationAndOperatorForThatCF: function () {
					return this.waitFor({
						controlType: "sap.m.ComboBox",
						success: function (oButtons) {
							//grabbing the ID of the right elements
							var elements = Opa5.getJQuery()("[id$='comboBoxEdit']");
							//to get the new element's combobox
							var ID1 = elements[2].id;
							var ID2 = elements[3].id;

							return this.waitFor({
								id: ID1,
								success: function (oButton) {
									oButton.setSelectedItem(oButton.getItems()[1]);

									return this.waitFor({
										id: ID2,
										success: function (oButton2) {
											oButton2.setSelectedItem(oButton2.getItems()[1]);
										},
										errorMessage: "Could not find the operator arrow button for that common filter in the common filter section in the Common Query Filter and Dimensions tab on the Object page in Edit mode."
									});
								},
								errorMessage: "Could not find the operation arrow button for that common filter in the common filter section in the Common Query Filter and Dimensions tab on the Object page in Edit mode."
							});
						},
						errorMessage: "Could not find the arrow button in the operation field in the common filter section in the Common Query Filter and Dimensions tab on the Object page in Edit mode."
					});
				},

				//
				/*iSelectANewOperatorForThatCF: function(){
					return this.waitFor({
						controlType: "sap.m.ComboBox",
						success: function(oButtons){
							
							//selects item in the list the dropdown offers next to the textfield
							oButtons[5].setSelectedItem(oButtons[5].getItems()[1]);
						},
						errorMessage: "Could not find the arrow button in the operator field in the common filter section in the Common Query Filter and Dimensions tab on the Object page in Edit mode."
					});
				},*/

				//
				iClickForADimensionForThatCF: function () {
					return this.waitFor({
						controlType: "sap.ui.core.Icon",
						success: function () {
							var elements = Opa5.getJQuery()("[id$='-input-vhi']");
							//select the second item in the list of common filters
							var ID = elements[1].id;

							return this.waitFor({
								id: ID,
								success: function (oButton) {
									oButton.firePress();
								},
								errorMessage: "Could not find the F4 Help button for the dimension field in the common filter section in the Common Query Filter and Dimensions tab on the Object page in Edit mode."
							});
						},
						errorMessage: "Could not find the F4 Help button for the dimension field in the common filter section in the Common Query Filter and Dimensions tab on the Object page in Edit mode."
					});
				},

				//
				iSelectANewDimensionForThatCF: function () {
					return this.waitFor({
						controlType: "sap.m.VBox",
						searchOpenDialogs: true,
						success: function (list) {
							//selects body of the VBox (which is the list), selects second item, aims the click at cell 0 of the table, and click
							list[1].getItems()[0].getItems()[1].getRows()[1].getCells()[0].$().trigger("click");

						},
						errorMessage: "Could not find a list of choices for a dimension in the dialog generated after clicking on a F4 Help button."
					});
				},

				//
				iSelectANewValueForThatCF: function () {
					return this.waitFor({
						controlType: "sap.m.InputBase",
						success: function () {
							var elements = Opa5.getJQuery()("[id$='-input']");
							//second element in the list
							//2 input fields by line.
							var ID = elements[3].id;

							return this.waitFor({
								id: ID,
								success: function (oInput) {
									oInput.setValue("Heyho");
								},
								errorMessage: "Could not find an input field in the common filter section in the Common Query Filter and Dimensions tab on the Object page in Edit mode."
							});
						},
						errorMessage: "Could not find an input field in the common filter section in the Common Query Filter and Dimensions tab on the Object page in Edit mode."
					});
				},

				//
				iSelectF4Help: function (intVal) {
					return this.waitFor({
						controlType: "sap.ui.core.Icon",
						success: function () {
							//debugger;
							//oButton[17].$().trigger("tap");
							//oButton[12].$().trigger("click");
							var elements = Opa5.getJQuery()("[id$='-vhi']");
							var ID = elements[intVal].id;

							return this.waitFor({
								id: ID,
								success: function (oButton) {
									oButton.$().trigger("click");
								},
								errorMessage: "Could not find an F4 Help button for the value field in the interaction fields table in the Interaction Fields tab on the Object page in Edit mode."
							});
						},
						errorMessage: "Could not find an F4 Help button for the value field in the interaction fields table in the Interaction Fields tab on the Object page in Edit mode."
					});
				},

				////////////////////////////////continue from here
				iSelectANewValue: function () {
					return this.waitFor({
						controlType: "sap.m.VBox",
						searchOpenDialogs: true,
						success: function (list) {

							//selects body of the VBox (which is the list), selects second item, aims the click at cell 0 of the table, and click
							list[1].getItems()[1].getRows()[1].getCells()[0].$().trigger("click");

						},
						errorMessage: "Could not find a list of choices for a value for an Interaction Field in the dialog."
					});
				},

				//
				iSearchInF4Help: function () {
					return this.waitFor({
						controlType: "sap.m.SearchField",
						searchOpenDialogs: true,
						success: function (oInputs) {
							//the only search field
							oInputs[0].setValue("aaaa");
							oInputs[0].fireSearch();
						},
						errorMessage: "Could not find any input fields"
					});
				},

				//
				iPressOnGo: function () {
					return this.waitFor({
						controlType: "sap.m.Button",
						searchOpenDialogs: true,
						success: function (oButtons) {
							//the only button
							oButtons[0].firePress();
						}
					});
				},
				////////////////////////////////////
				//
				iAddAMainQuery: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgRtrvlIaHdr::com.sap.vocabularies.UI.v1.LineItem::addEntry",
						success: function (oButton) {
							oButton.firePress();
						},
						errorMessage: "Could not find the + button in the Main Queries section."
					});
				},

				//
				iApplyTheNewMainQuery: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrckgIntactnHdrTP--footerObjectPageBackTo",
						success: function (oButton) {
							oButton.firePress();
						},
						errorMessage: "Could not find the Apply button in the + button generated page by the Main Queries section."
					});
				},

				//
				iClickTheBackBtn: function () {
					return this.waitFor({
						id: "backBtn",
						success: function (oBackBtn) {
							oBackBtn.firePress();
						},
						errorMessage: "Could not find the back button"
					});
				},

				//////////////////////////
				//
				iSelectF4HelpNewObject: function () {
					return this.waitFor({
						controlType: "sap.ui.core.Icon",
						success: function () {

							var elements = Opa5.getJQuery()("[id$='-vhi']");
							//taking the last icon of the interaction fields
							var ID = elements[3].id;

							return this.waitFor({
								id: ID,
								success: function (oButton) {
									oButton.$().trigger("click");
								},
								errorMessage: "Could not find the F4 Help button for the dimension field in the interaction fields section."
							});
						},
						errorMessage: "Could not find the F4 Help button for the dimension field in the interaction fields section."
					});
				},
				////////////////////
				//
				iSelectType: function (type) {
					return this.waitFor({
						controlType: "sap.m.ComboBox",
						success: function (oButtons) {
							//selects item in the list the dropdown offers next to the textfield
							//debugger;
							var index = -1;
							for (var i = 0; i < oButtons[0].getItems().length; i++) {
								if (type === oButtons[0].getItems()[i].getText()) {
									index = i;
									break;
								}
							}
							if (index !== -1) {
								oButtons[0].setSelectedItem(oButtons[0].getItems()[index]);
							}
							//oButtons[0].setSelectedItem(oButtons[0].getItems()[20]);
						},
						errorMessage: "Could not find the value button for the interaction field."
					});
				},

				//
				iAddAProductQuery: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgRtrvlProdHdr::com.sap.vocabularies.UI.v1.LineItem::addEntry",
						success: function (oButton) {
							oButton.firePress();
						},
						errorMessage: "Could not find the + button in the Product Queries section."
					});
				},

				//
				iApplyTheNewProductQuery: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrckgProdHeaderTP--footerObjectPageBackTo",
						success: function (oButton) {
							oButton.firePress();
						},
						errorMessage: "Could not find the Apply button in the + button generated page by the Product Queries section."
					});
				},

				//
				iAddATagQuery: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgRtrvlTagHdr::com.sap.vocabularies.UI.v1.LineItem::addEntry",
						success: function (oButton) {
							oButton.firePress();
						},
						errorMessage: "Could not find the + button in the Tag Queries section."
					});
				},

				//
				iApplyTheNewTagQuery: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingTagHeaderTP--footerObjectPageBackTo",
						success: function (oButton) {
							oButton.firePress();
						},
						errorMessage: "Could not find the Apply button in the + button generated page by the Tag Queries section."
					});
				},

				//NEED CHANGE
				iClickOnExpertFilter: function () {
					return this.waitFor({
						controlType: "sap.m.Button",
						success: function (oButtons) {
							for (var i = 0; i < oButtons.length; i++) {
								if (oButtons[i].getText() === "Expert") {
									oButtons[i].firePress();
									break;
								}
							}
							//oButtons[11].firePress();
							//debugger;
						},
						errorMessage: "Could not find the Expert button in the Common Filter tab."
					});
				},
				/////////////////
				//NEED CHANGE
				iClickOnBasicFilter: function () {
					return this.waitFor({
						controlType: "sap.m.Button",
						success: function (oButtons) {
							//debugger;
							for (var i = 0; i < oButtons.length; i++) {
								if (oButtons[i].getText() === "Basic") {
									oButtons[i].firePress();
									break;
								}
							}
							//oButtons[7].firePress();
						},
						errorMessage: "Could not find the Basic button in the Common Filter tab."
					});
				},
				/////////////////
				//
				iEnterTextInTextAreaExpertMode: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--com.sap.vocabularies.UI.v1.FieldGroup::expertFilter_FG::WebTrackingMappingFilterString::Field-textArea",
						actions: new EnterText({
							text: "blobloblob"
						}),
						errorMessage: "Could not find the text area generated by Expert mode."
					});
				},

				//
				iClickOnDelete: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--delete",
						success: function (oButton) {
							oButton.firePress();
						},
						errorMessage: "Could not find the delete button."
					});
				},
				/////////////////////
				//
				iClickOnYesToRemoveFilters: function () {
					return this.waitFor({
						controlType: "sap.m.Button",
						searchOpenDialogs: true,
						success: function (oButtons) {
							//debugger;
							oButtons[0].firePress();
							//oButton.firePress();
						},
						errorMessage: "Could not find the Yes button"
					});
				},

				//
				iSelectASuggestionOffered: function (index) {
					return this.waitFor({
						controlType: "sap.m.Input",
						success: function (oInputs) {
							var ID = oInputs[index].$().attr("id");
							return this.waitFor({
								id: ID,
								pollingInterval: 2500,
								check: function () {
									if (Opa5.getJQuery()("[id$='-popup-table']").length === 0) {
										oInputs[index].setShowSuggestion(true);
										oInputs[index].setShowTableSuggestionValueHelp(true);
										oInputs[index].fireSuggest();
										return false;
									} else {
										return true;
									}
								},
								success: function (oInput) {
									return this.waitFor({
										id: ID + "-popup-table",
										success: function (oTable) {
											//select object
											//oTable.setVisible(true);
											oTable.setSelectedItem(oTable.getItems()[2]);
											//debugger;
										},
										errorMessage: "Could not find the suggestions offered based on input in the input field with ID " + ID + "."
									});
								},
								errorMessage: "Could not find this specific input in the Interaction Fields tab on the Object page in Edit mode."

							});

						},
						errorMessage: "Could not find any input fields on the interaction fields tab."
					});
				},

				//
				iClickOnSave: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--activate",
						success: function (oButton) {
							oButton.firePress();
						},
						errorMessage: "Could not save the object after editing it."
					});
				},

				//NEED CHANGE
				iClickOnDeleteObject: function () {
					return this.waitFor({
						success: function () {
							var elements = Opa5.getJQuery()("[id$='-footer']");
							var ID = elements[0].id;

							return this.waitFor({
								searchOpenDialogs: true,
								matchers: function (oControl) {
									return oControl.getId().indexOf(ID) !== -1;
								},
								success: function (oFooter) {
									oFooter[0].getContent()[1].firePress();
								},
								errorMessage: "Could not delete the object."
							});
						},
						errorMessage: "Could not delete the object."
					});

				},

				//
				iClickOnCancelChangeFilter: function () {
					return this.waitFor({
						controlType: "sap.m.Button",
						searchOpenDialogs: true,
						success: function (oButtons) {
							//debugger;
							oButtons[1].firePress();
							//oButton.firePress();
						},
						errorMessage: "Could not find the Cancel button in the 'Warning' dialog."
					});

				}

			},

			assertions: {
				//
				iShouldSeeIFResults: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgValMapping::com.sap.vocabularies.UI.v1.LineItem::responsiveTable",
						success: function (list) {
							return this.waitFor({
								check: function () {
									return list.getItems().length > 0;
								},
								success: function () {
									if (list.getItems().length === 4) {
										ok(true, "The Interaction Fields results can be seen");
									} else {
										ok(false, "Could not find the right number of Interaction Fields.");
									}
								}
							});
						},
						errorMessage: "Could not find the right number/ any of the results for Interaction Fields."
					});
				},

				//
				iShouldSeeCQFResults: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgMappgFltr::com.sap.vocabularies.UI.v1.LineItem::responsiveTable",
						success: function (list) {
							//waiting until results get loaded
							return this.waitFor({
								check: function () {
									return list.getItems().length > 0;
								},
								success: function () {
									if (list.getItems().length === 2) {
										ok(true, "The CQF results can be seen");
									} else {
										ok(false, "Could not find the right number of CQFs.");
									}
								}
							});

						},
						errorMessage: "Could not find the right number/ any of the results for CQF."
					});
				},

				//
				iShouldSeeDimensionResults: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgComMapping::com.sap.vocabularies.UI.v1.LineItem::responsiveTable",
						success: function (list) {
							//waiting until results get loaded
							return this.waitFor({
								check: function () {
									return list.getItems().length > 0;
								},
								success: function () {
									if (list.getItems().length === 2) {
										ok(true, "The dimensions can be seen");
									} else {
										ok(false, "Could not find the right number of Dimensions.");
									}
								}
							});
						},
						errorMessage: "Could not find the right number/ any of the results for dimensions."
					});
				},

				iShouldSeeMainQueriesResults: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgRtrvlIaHdr::com.sap.vocabularies.UI.v1.LineItem::responsiveTable",
						success: function (list) {

							//waiting until results get loaded
							return this.waitFor({
								check: function () {
									return list.getItems().length > 0;
								},
								success: function () {
									if (list.getItems().length === 1) {
										ok(true, "The main queries can be seen.");
									} else {
										ok(false, "Could not find the right number of Main Queries.");
									}
								}
							});
						},
						errorMessage: "Could not find the right number/ any of the results for the main queries."
					});
				},

				iShouldSeeProductQueriesResults: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgRtrvlProdHdr::com.sap.vocabularies.UI.v1.LineItem::responsiveTable",
						success: function (list) {
							//waiting until results get loaded
							return this.waitFor({
								check: function () {
									return list.getItems().length > 0;
								},
								success: function () {
									if (list.getItems().length === 1) {
										ok(true, "The product queries can be seen.");
									} else {
										ok(false, "Could not find the right number of Product Queries.");
									}
								}
							});
						},
						errorMessage: "Could not find the right number/ any of the results for the product queries."
					});
				},

				iShouldSeeTagQueriesResults: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgRtrvlTagHdr::com.sap.vocabularies.UI.v1.LineItem::responsiveTable",
						success: function (list) {
							//waiting until results get loaded
							return this.waitFor({
								check: function () {
									return list.getItems().length > 0;
								},
								success: function () {
									if (list.getItems().length === 1) {
										ok(true, "The tag queries can be seen.");
									} else {
										ok(false, "Could not find the right number of Tag Queries.");
									}
								}
							});
						},
						errorMessage: "Could not find the right number/ any of the results for the tag queries."
					});
				},

				//
				theIFListLengthHasChanged: function (quantity) {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgValMapping::com.sap.vocabularies.UI.v1.LineItem::responsiveTable",
						success: function (list) {

							//waiting until results get loaded
							return this.waitFor({
								check: function () {
									return list.getItems().length > 0;
								},
								success: function () {
									if (list.getItems().length === quantity) {
										ok(true, "There is the right number of interaction fields.");
									} else {
										ok(false, "Could not find the right number of Interaction Fields.");
									}
								}
							});
						},
						errorMessage: "Could not find the right number/ any of the results for Interaction Fields."
					});
				},

				//
				theCFListLengthHasChanged: function (quantity) {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgMappgFltr::com.sap.vocabularies.UI.v1.LineItem::responsiveTable",
						success: function (list) {

							//waiting until results get loaded
							return this.waitFor({
								check: function () {
									return list.getItems().length > 0;
								},
								success: function () {
									if (list.getItems().length === quantity) {
										ok(true, "There is the right number of interaction fields.");
									} else {
										ok(false, "Could not find the right number of Interaction Fields.");
									}
								}
							});
						},
						errorMessage: "Could not find the right number/ any of the results for Interaction Fields."
					});
				},

				//
				theValueOfCFHasChanged: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgMappgFltr::com.sap.vocabularies.UI.v1.LineItem::responsiveTable",
						success: function (list) {
							var hasDropdownsRightValue = false;
							var hasInputRightValue = false;
							this.waitFor({
								controlType: "sap.m.ComboBox",
								success: function (oButtons) {
									//selects item in the list the dropdown offers next to the textfield
									if (oButtons[2].getSelectedItem() === oButtons[2].getItems()[1] &&
										oButtons[3].getSelectedItem() === oButtons[3].getItems()[1])
										hasDropdownsRightValue = true;

									this.waitFor({
										controlType: "sap.m.InputBase",
										success: function (oInput) {
											if (oInput[11].getValue() === "Heyho" && oInput[9].getValue() === "ga:1dayUsers")
												hasInputRightValue = true;

											//now that we have all the values, try to assert.
											if (hasDropdownsRightValue && hasInputRightValue)
												ok(true, "The new common filter has been defined with the proper values");
											else
												ok(false, "Something has not been set correctly in the new common filter.");
										}
									});
								},
								errorMessage: "Could not find the value button for the interaction field."
							});

						},
						errorMessage: "Could not find the right number/ any of the results for Interaction Fields."
					});
				},

				//
				theMainQueryListLengthHasChanged: function (quantity) {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgRtrvlIaHdr::com.sap.vocabularies.UI.v1.LineItem::responsiveTable",
						success: function (list) {

							if (list.getItems().length === quantity)
								ok(true, "There is the right number of main queries.");
							else
								ok(false, "Could not find the right number of main queries.");

						},
						errorMessage: "Could not find the right number/ any of the results for Main Queries."
					});
				},
				iSeeTheExpertFilterSection: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--common_filters_expert::SubSection",
						success: function (oObjectPageSubsection) {
							ok(oObjectPageSubsection.getVisible(), "The Expert Filter section is visible");
						}
					});
				},
				iSeeTheBasicFiltersSection: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--common_filters_basic::SubSection",
						success: function (oObjectPageSubsection) {
							ok(oObjectPageSubsection.getVisible(), "The Basic Filter section is visible");
						}
					});
				}
			}
		}
	});
});