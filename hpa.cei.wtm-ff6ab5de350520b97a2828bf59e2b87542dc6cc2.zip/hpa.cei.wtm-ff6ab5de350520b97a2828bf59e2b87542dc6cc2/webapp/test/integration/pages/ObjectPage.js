sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"hpa/cei/wtm/test/integration/pages/Common",
	"sap/ui/test/actions/Press",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/test/actions/EnterText",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/unified/DateRange"
], function (Opa5, PropertyStrictEquals, AggregationFilled, Common, Press, ResourceModel, EnterText, Properties, AggregationLengthEquals,
	DateRange) {
	"use strict";

	Opa5.createPageObjects({
		onTheObjectPage: {
			baseClass: Common,

			//the IDs use are based on the HTML source code when inspecting the page
			actions: {

				//
				iClickOnCopyButton: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--action::copyConfig",
						actions: new Press(),
						success: function (oButton) {
							ok(true, "The Copy Button was pressed.");
						},
						errorMessage: "Could not find the Copy button in the Object page."
					});
				},

				iCloseTheCopyQueryDialog: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Button",
						matchers: function (oControl) {
							return oControl.getId() === "copyBQQueryDialog--copyBQQueryDialog-ButtonClose";
						},
						actions: new Press(),
						success: function (oButtons) {
							ok(true, "The Close button was pressed.");
						}
					});
				},

				iClickOnValidateButton: function () {
					return this.waitFor({
						controlType: "sap.m.Button",
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--action::validate_action",
						actions: new Press(),
						success: function (oButtons) {
							ok(true, "The Validate Button was pressed.");
						},
						errorMessage: "Could not find the Validate button on the Object page."
					});
				},

				//
				iClickOnDeactivateButton: function () {
					return this.waitFor({
						controlType: "sap.m.Button",
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--action::deactivate_action",
						actions: new Press(),
						success: function (oButtons) {
							ok(true, "The Deactivate button was clicked.");
						},
						errorMessage: "Could not find the Deactivate button on the Object page."
					});
				},

				///////////////////////?? is this one really useful?
				//
				iClickOnBQValidateButton: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--action::validate_action",
						success: function (oButton) {
							//debugger;
							//oButtons[2].firePress();
							oButton.firePress();
							ok(true, "The Validate Button was pressed.");
						},
						errorMessage: "Could not find the Validate button in the Big Query object."
					});
				},
				///////////////////////
				//
				iSetValidateInputField: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						matchers: function (oControl) {
							return oControl.getId().indexOf("ValidationDialog--DateRangeSelection") !== -1;
						},
						actions: new EnterText({
							text: "January 6, 2019 - January 13, 2019"
						}),
						errorMessage: "Could not find the input field appearing after the Validate button is pressed!"
					});
				},

				//
				iSetValidateInputFieldRight: function () {
					return this.waitFor({
						id: "ValidationDialog--DateRangeSelection",
						searchOpenDialogs: true,
						actions: new EnterText({
							text: "January 10, 2019 - January 13, 2019"
						}),
						errorMessage: "Could not find the input field appearing after the Validate button is pressed!"
					});
				},

				//
				iClickOnOK: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						matchers: function (oControl) {
							return oControl.getId().indexOf("ValidationDialog--validateDialog-footer") !== -1;
						},
						success: function (oFooter) {
							oFooter[0].getContent()[1].firePress();
						},
						errorMessage: "Could not find the OK button in the validation dialog generated after clicking on the Validate button on the Object page."
					});
				},

				//
				iClickOnCancel: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						matchers: function (oControl) {
							return oControl.getId().indexOf("ValidationDialog--validateDialog-footer") !== -1;
						},
						success: function (oFooter) {
							oFooter[0].getContent()[2].firePress();
						},
						errorMessage: "Could not find the Cancel button in the validation dialog generated after clicking on the Validate button on the Object page."
					});
				},

				//
				iClickOnCreateInDialog: function () {
					return this.waitFor({
						success: function () {

							var oFooterCaptured = Opa5.getJQuery()("[id$='-footer']").children()[1];
							var ID = oFooterCaptured.id;

							return this.waitFor({
								searchOpenDialogs: true,
								matchers: function (oControl) {
									return oControl.getId().indexOf(ID) !== -1;
								},
								success: function (oButtons) {
									oButtons[0].firePress();
								},
								errorMessage: "Could not find the Create button in the Copy dialog generated after clicking on the Copy button on the Object page."
							});
						},
						errorMessage: "Could not find the Create button in the Copy dialog generated after clicking on the Copy button on the Object page."
					});
				},

				//////////////////////////////////////
				//
				iClickOnOKBQ: function () {
					return this.waitFor({
						id: "ValidationDialogBigQuery--validateDialogBigQuery-footer",
						success: function (oFooter) {
							oFooter.getContent()[1].firePress();
						},
						errorMessage: "Cannot find the footer of the dialog generated by a click on the Validate button on the Object page."
					});
				},

				//
				iClickTheBackBtn: function () {
					return this.waitFor({
						id: "backBtn",
						success: function (oBackBtn) {
							oBackBtn.firePress();
						},
						errorMessage: "Could not find the back button on the Object page."
					});
				},

				//
				iSetValidateInputFieldBQ: function () {
					return this.waitFor({
						id: "ValidationDialogBigQuery--DatePicker",
						searchOpenDialogs: true,
						actions: new EnterText({
							text: "January 13, 2019"
						}),
						errorMessage: "Could not find the input field appearing after the Validate button is pressed on a BigQuery object!"
					});
				},

				iSetSelectedSectionTo: function (sSelectedSectionId) {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--objectPage",
						success: function (oObjectPage) {
							oObjectPage.setSelectedSection(sSelectedSectionId);
						},
						errorMessage: "Could not find the ObjectPageLayout"
					});
				},

				iOpenTheFieldsHelperForBQ: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--bqEditor--fieldsHelperBtn",
						actions: new Press()
					});
				},

				iPressTheInteractionFieldsHelperDialogButton: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--bqEditor--fieldsHelperBtn",
						controlType: "sap.m.Button",
						actions: new Press(),
						success: function (oButton) {
							ok(true, "The Interaction Fields helper button was clicked.");
						}
					});
				},

				iPressTheCopyQueryButton: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--bqEditor--copyQueryBtn",
						controlType: "sap.m.Button",
						actions: new Press(),
						success: function (oButton) {
							ok(true, "The copy query button was pressed.");
						}
					});
				}

			},

			assertions: {
				//
				iSeeValidateButton: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--action::validate_action",
						success: function (oDialogs) {
							ok(true, "The Validate button can be seen on the Object page.");
						},
						errorMessage: "Could not find the Validate button on the Object page."
					});
				},

				//
				iCheckTheObjectTitle: function (titleCompared) {

					return this.waitFor({
						controlType: "sap.uxap.ObjectPageHeader",
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--objectPageHeader",
						success: function (oHeader) {
							var title = oHeader.getTitleText();

							if (title === titleCompared) {
								ok(true, "The title of the object appears correctly on the Object page.");
							} else {
								ok(false, "The title of the object does not appear correctly on the Object page.");
							}
						},
						errorMessage: "Object title was not found"

					});

				},

				iShouldSeeTheValidationResults: function (val) {
					//for normal behavior, set val to 1. Otherwise, set to 0 or anything else
					return this.waitFor({
						success: function () {
							if (Opa5.getJQuery()(
									"#hpa\\.cei\\.wtm\\:\\:sap\\.suite\\.ui\\.generic\\.template\\.ObjectPage\\.view\\.Details\\:\\:C_MKT_WebTrackingMappingTP--log_table\\:\\:responsiveTable-listUl"
								).length > 0) {
								if (val === 1) {
									ok(true, "The validation results are shown on the Object page under the Validation Results tab.");
								} else {
									ok(false, "The validation results are shown on the Object page under the Validation Results tab when they should not be.");
								}
							} else {
								if (val === 1) {
									ok(false, "The validation results are not shown on the Object page under the Validation Results tab.");
								} else {
									ok(true,
										"The validation results are not shown on the Object page under the Validation Results tab, just like they are supposed to."
									);
								}

							}
						},
						errorMessage: "Could not reach this waitFor."
					});
				},

				theValidateDialogIsInState: function (sState) {
					return this.waitFor({
						id: "ValidationDialog--DateRangeSelection",
						searchOpenDialogs: true,
						success: function (oDateRange) {
							ok(oDateRange.getValueState() === sState, "The validation dialog is in correct state");
						}
					});
				},

				theValidateDialogOkButtonIsEnabled: function (bEnabled) {
					return this.waitFor({
						id: "ValidationDialog--validateDialog",
						searchOpenDialogs: true,
						success: function (oDialog) {
							ok(oDialog.getButtons()[0].getEnabled() === bEnabled, "The validation dialog Ok button is in expected state");
						}
					});
				},

				iSeeTheBigQueryCodeEditorWithId: function (sId) {
					return this.waitFor({
						id: sId,
						controlType: "sap.ui.codeeditor.CodeEditor",
						enabled: false,
						success: function (oCodeEditor) {
							ok(oCodeEditor.getVisible(), "The code editor is visible");
						}
					});
				},

				iSeeTheBigQueryCodeEditorWithIdIsEditable: function (sId, bEditable) {
					return this.waitFor({
						id: sId,
						controlType: "sap.ui.codeeditor.CodeEditor",
						enabled: bEditable,
						success: function (oCodeEditor) {
							ok(oCodeEditor.getEditable() === bEditable, "The code editor is " + bEditable ? "editable." : "not editable.");
						}
					});
				},

				iSeeTheInteractionFieldsHelperDialogButton: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--bqEditor--fieldsHelperBtn",
						controlType: "sap.m.Button",
						success: function (oButton) {
							ok(oButton.getEnabled(), "The Interaction Fields helper button is visible and enabled.");
						}
					});
				},

				iSeeTheCopyQueryButton: function () {
					return this.waitFor({
						id: "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--bqEditor--copyQueryBtn",
						controlType: "sap.m.Button",
						success: function (oButton) {
							ok(oButton.getEnabled(), "The copy query button is visible and enabled.");
						}
					});
				},

				iSeeAllTheTextIsSelected: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.ui.codeeditor.CodeEditor",
						matchers: function (oControl) {
							return oControl.getId() === "copyBQQueryDialog--copyBQQueryDialog-vbox-codeEditor";
						},
						success: function (oCodeEditors) {
							var oCodeEditor = oCodeEditors[0];
							ok(oCodeEditor.getValue() === oCodeEditor._oEditor.getSelectedText(), "The text is selected in the code editor.");
						}
					});
				}

			}
		}
	});
});