sap.ui.define([
	"sap/ui/test/opaQunit"
], function(opaTest) {
		"use strict";
		QUnit.module("Edit Journey");
		
		opaTest("Go into Edit mode", function(Given, When, Then){
			Given.iStartTheApp();
			
			//click on Go button before required
			When.onTheListReportPage
			.iClickOnGo();
			
			When.onTheGenericListReport
			.iNavigateFromListItemByFieldValue({Field: "WebTrackingMappingName", Value:"Some 2018-09-05 10:13AM"});
			
			When.onTheGenericObjectPage
			.iClickTheEditButton();
			
			Then.onTheGenericObjectPage
			.theObjectPageHeaderTitleIsCorrect("Some 2018-09-05 10:13AM");
		});
		
		opaTest("Navigate in Object Tabs", function(Given, When, Then){
			When.onTheEditPage
			.iClickOnInteractionFieldsButton();
			
			Then.onTheEditPage
			.iShouldSeeIFResults();
			
			When.onTheEditPage
			.iClickOnCommonQueryFilterButton();
			
			Then.onTheEditPage
			.iShouldSeeCQFResults()
			.and
			.iShouldSeeDimensionResults();
			
			When.onTheEditPage
			.iClickOnQueriesButton();
			
			Then.onTheEditPage
			.iShouldSeeMainQueriesResults()
			.and
			.iShouldSeeProductQueriesResults()
			.and
			.iShouldSeeTagQueriesResults();
			
		});
		
		/*opaTest("Add an interaction field", function(Given, When, Then){
			When.onTheEditPage
			.iClickOnInteractionFieldsButton();
			
			Then.onTheEditPage
			.iShouldSeeIFResults();
			
			When.onTheEditPage
			.iAddAnInteractionField();
			
			Then.onTheEditPage
			.theIFListLengthHasChanged(5);
			
			When.onTheEditPage
			.iSelectF4Help(0);
			
			When.onTheEditPage
			.iSelectANewValue();

		});*/
		
		/*opaTest("Testing the different F4 help", function(Given, When, Then){
			
			//not permanent
			When.onTheEditPage
			.iClickOnInteractionFieldsButton();
			
			/*When.onTheEditPage
			.iSelectType("MarketingArea");
			
			When.onTheEditPage
			.iSelectF4HelpNewObject();
			
			When.onTheEditPage
			.iSelectANewValue();
			
			When.onTheEditPage
			.iSelectType("DigitalAccountType");
			
			When.onTheEditPage
			.iSelectF4HelpNewObject();
			
			When.onTheEditPage
			.iSelectANewValue();
			
			When.onTheEditPage
			.iSelectType("InteractionProductStatus");
			
			When.onTheEditPage
			.iSelectF4HelpNewObject();
			
			When.onTheEditPage
			.iSelectANewValue();
			
			When.onTheEditPage
			.iSelectType("MarketingLocationOrigin");
			
			When.onTheEditPage
			.iSelectF4HelpNewObject();
			
			When.onTheEditPage
			.iSelectANewValue();
			
			When.onTheEditPage
			.iSelectType("MKT_AgreementOrigin");
			
			When.onTheEditPage
			.iSelectF4HelpNewObject();
			
			When.onTheEditPage
			.iSelectANewValue();
			
			When.onTheEditPage
			.iSelectType("ProductOrigin");
			
			When.onTheEditPage
			.iSelectF4HelpNewObject();
			
			When.onTheEditPage
			.iSelectANewValue();
			
			When.onTheEditPage
			.iSelectF4Help(1);
			
			When.onTheEditPage
			.iSelectANewValue();*/
			
			// When.onTheEditPage
			// .iSelectF4Help(2);
			
			// When.onTheEditPage
			// .iSelectANewValue();
			
			//When.onTheEditPage
			//.iChangeValueOfInput(2);
			
			//When.onTheEditPage
			//.iFireSuggestions(2);
			
			// When.onTheEditPage
			// .iSelectASuggestionOffered(2);
			
			// Then.onTheGenericObjectPage
			// .theObjectPageHeaderTitleIsCorrect("Some 2018-09-05 10:13AM");
			
	/*	});*/
		
		opaTest("Add/Remove a Common Filter", function(Given, When, Then){
			
			When.onTheEditPage
			.iClickOnCommonQueryFilterButton();
			
			When.onTheEditPage
			.iAddACommonFilter();
			
			Then.onTheEditPage
			.theCFListLengthHasChanged(3);
			
			When.onTheEditPage
			.iSelectACommonFilter();
			
			When.onTheEditPage
			.iRemoveACommonFilter();
			
			When.onTheEditPage
			.iConfirmDeletion();
			
			Then.onTheEditPage
			.theCFListLengthHasChanged(2);
			
		});
		
		opaTest("Make a choice of the value of a common filter", function(Given, When, Then){
			
			When.onTheEditPage
			.iSelectANewOperationAndOperatorForThatCF();
			
			//When.onTheEditPage
			//.iSelectANewOperatorForThatCF();
			
			When.onTheEditPage
			.iClickForADimensionForThatCF();
			
			When.onTheEditPage
			.iSearchInF4Help();
			
			When.onTheEditPage
			.iPressOnGo();
			
			When.onTheEditPage
			.iSelectANewDimensionForThatCF();
			
			When.onTheEditPage
			.iSelectANewValueForThatCF();
			
			Then.onTheEditPage
			.theValueOfCFHasChanged();
		});
		
		opaTest("Create a new query", function(Given, When, Then){
			
			When.onTheEditPage
			.iClickOnQueriesButton();
			
			When.onTheEditPage
			.iAddAMainQuery();
			
			//changing page
			When.onTheGenericObjectPage
			.iNavigateBack();
			
			When.onTheEditPage
			.iAddAProductQuery();
			
			When.onTheGenericObjectPage
			.iNavigateBack();
			
			When.onTheEditPage
			.iAddATagQuery();
			
			When.onTheGenericObjectPage
			.iNavigateBack();
			
			//changing page
			Then.onTheEditPage
			.theMainQueryListLengthHasChanged(2);
			
			//Then.iTeardownMyAppFrame();
		});
		
		opaTest("When I change the filter type, I see the deletion warning popup", function(Given, When, Then) {
			When.onTheEditPage
			.iClickOnCommonQueryFilterButton();
			
			When.onTheEditPage
			.iChangeFilterModeTo("E");
			
			When.onTheGenericObjectPage
			.iClickTheButtonOnTheDialog("Yes");
			
			Then.onTheEditPage
			.iSeeTheExpertFilterSection();
		});
		opaTest("When I change the filter type, I see the deletion warning popup", function(Given, When, Then) {
			When.onTheEditPage
			.iWriteTextInTheExpertFilter("test text");
			
			When.onTheEditPage
			.iChangeFilterModeTo("B");
			
			When.onTheGenericObjectPage
			.iClickTheButtonOnTheDialog("Cancel");
			
			Then.onTheEditPage
			.iSeeTheExpertFilterSection();
		});
		opaTest("When I change the filter type, I see the deletion warning popup", function(Given, When, Then) {
			When.onTheEditPage
			.iChangeFilterModeTo("B");
			
			When.onTheGenericObjectPage
			.iClickTheButtonOnTheDialog("Yes");
			
			Then.iTeardownMyAppFrame();
		});
		
		
		
		/*QUnit.module("Other Journeys");
		
		opaTest("Trigger Expert Filter", function(Given, When, Then){
			
			//Given.iStartTheApp();
			
			//click on Go button before required
			/*When.onTheListReportPage
			.iClickOnGo();
			
			When.onTheGenericListReport
			.iNavigateFromListItemByFieldValue({Field: "WebTrackingMappingName", Value:"Some 2018-09-05 10:13AM"});
			
			When.onTheGenericObjectPage
			.iClickTheEditButton();
			
			Then.onTheGenericObjectPage
			.theObjectPageHeaderTitleIsCorrect("Some 2018-09-05 10:13AM");*
			
			//now that I am on the Edit mode...
			
			When.onTheEditPage
			.iClickOnCommonQueryFilterButton();
			
			When.onTheEditPage
			.iClickOnExpertFilter();
			
			When.onTheEditPage
			.iEnterTextInTextAreaExpertMode();
			
			When.onTheEditPage
			.iClickOnBasicFilter();

			When.onTheEditPage
			.iClickOnYesToRemoveFilters();    
			
			When.onTheEditPage
			.iClickOnExpertFilter();
			
			When.onTheEditPage
			.iEnterTextInTextAreaExpertMode();
			
			When.onTheEditPage
			.iClickOnBasicFilter();
			
			When.onTheEditPage
			.iClickOnCancelChangeFilter();
			
			When.onTheEditPage
			.iClickOnSave();
			
			//yes
			Then.onTheGenericObjectPage
			.theObjectPageHeaderTitleIsCorrect("Some 2018-09-05 10:13AM");
			
			/*When.onTheEditPage
			.iClickOnDelete();
			
			When.onTheEditPage
			.iClickOnDeleteObject();
			
			Then.onTheGenericListReport
			.theResultListContainsTheCorrectNumberOfItems(3);*
		});
		
		/*opaTest("Delete an object from the List Report page", function(Given, When, Then){
			
			//temporary
			When.onTheEditPage
			.iClickTheBackBtn();                         
			
			When.onTheListReportPage
			.iSelectAnObject();
			
			When.onTheEditPage
			.iClickTheBackBtn();
			
			When.onTheListReportPage
			.iDeleteTheObject();
			
			When.onTheListReportPage
			.iConfirmDeletionOfObject();
			
			//temporary. Should be two
			Then.onTheGenericListReport
			.theResultListContainsTheCorrectNumberOfItems(3);
		});*/
		
	}
);