jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
jQuery.sap.require("sap.ui.qunit.qunit-coverage");

if(window.blanket){
	window.blanket.options("sap-ui-cover-only", "sap/ui/test/Opa5.js");
}
		
QUnit.config.autostart = false;
QUnit.config.testTimeout = 120000;

sap.ui.require([
	"sap/ui/test/Opa5",
	"hpa/cei/wtm/test/integration/pages/Common",
	"hpa/cei/wtm/test/integration/pages/ListReport",
	"hpa/cei/wtm/test/integration/pages/ObjectPage",
	"hpa/cei/wtm/test/integration/pages/EditPage",
	"sap/ui/test/opaQunit",
	"sap/suite/ui/generic/template/integration/testLibrary/ListReport/pages/ListReport",
	"sap/suite/ui/generic/template/integration/testLibrary/ObjectPage/pages/ObjectPage"
], function (Opa5, Common, ListReport, ObjectPage, EditPage) {
	"use strict";

	Opa5.extendConfig({
		arrangements: new Common(),
	//	viewNamespace: "hpa.cei.wtm.view.",
		autoWait: true,
		timeout: 120,
		testLibs: {
			fioriElementsTestLibrary: {
				Common: {
					appId: 'hpa.cei.wtm',
					entitySet: 'C_MKT_WebTrackingMappingTP'
				}
			}
		}
	});

	sap.ui.require([
		"hpa/cei/wtm/test/integration/SystemUnderTest",
		"hpa/cei/wtm/test/integration/ListReportJourney",
		"hpa/cei/wtm/test/integration/ObjectPageJourney",
		"hpa/cei/wtm/test/integration/EditPageJourney",
		"hpa/cei/wtm/test/integration/ContactMatchJourney",
		"hpa/cei/wtm/test/integration/CopyBigQueryQueryJourney"
	], function () {
		QUnit.start();
	});
});