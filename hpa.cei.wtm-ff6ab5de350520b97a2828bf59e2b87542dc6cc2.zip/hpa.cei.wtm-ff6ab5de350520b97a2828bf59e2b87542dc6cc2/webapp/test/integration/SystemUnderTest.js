sap.ui.define([
	"sap/ui/test/opaQunit"
], function(opaTest) {
		"use strict";
		QUnit.module("System under Test Journey");



	}
);