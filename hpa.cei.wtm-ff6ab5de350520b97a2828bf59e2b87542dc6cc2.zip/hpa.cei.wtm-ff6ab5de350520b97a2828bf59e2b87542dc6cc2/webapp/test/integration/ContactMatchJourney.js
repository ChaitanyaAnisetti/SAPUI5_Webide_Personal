sap.ui.define([
	"sap/ui/test/opaQunit"
], function (opaTest) {
	"use strict";
	QUnit.module("Contact Match Journey");

	opaTest("When I navigate to a contact match configuration, the title is correctly displayed", function (Given, When, Then) {
		Given.iStartTheApp();

		When.onTheGenericListReport
			.iNavigateFromListItemByFieldValue({
				Field: "WebTrackingMappingName",
				Value: "Big Query Contact Match ID"
			});

		Then.onTheGenericObjectPage
			.theObjectPageHeaderTitleIsCorrect("Big Query Contact Match ID");
		Then.onTheGenericObjectPage
			.iShouldSeeTheButtonWithLabel("Details");
		Then.onTheGenericObjectPage
			.iShouldSeeTheButtonWithLabel("Contact Fields");
		Then.onTheGenericObjectPage
			.iShouldSeeTheButtonWithLabel("Query");
		Then.onTheGenericObjectPage
			.iShouldSeeTheButtonWithLabel("Validation Results");
		Then.onTheGenericObjectPage
			.theObjectPageDataFieldHasTheCorrectValue({
				Field: "WebTrackingMappingName",
				Value: "Big Query Contact Match ID"
			});

		Then.onTheGenericObjectPage
			.theObjectPageDataFieldHasTheCorrectValue({
				Field: "WebTrackingMappingType",
				Value: "C"
			});

		Then.onTheGenericObjectPage
			.theObjectPageDataFieldHasTheCorrectValue({
				Field: "WebTrackingMappingProject",
				Value: "isentropic-tape-187315"
			});

		Then.onTheGenericObjectPage
			.theObjectPageDataFieldHasTheCorrectValue({
				Field: "WebTrackingMappingDataTable",
				Value: "179257477"
			});

		Then.onTheGenericObjectPage
			.theObjectPageDataFieldHasTheCorrectValue({
				Field: "WebTrackingMappingDataSource",
				Value: "B"
			});
	});

	opaTest("When I navigate to the contact fields section, I should see the contact fields table", function (Given, When, Then) {
		When.onTheObjectPage
			.iSetSelectedSectionTo(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--contact_fields::Section"
			);

		Then.onTheGenericObjectPage
			.iSeeTheControlWithId(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--contact_fields::Table");
	});

	opaTest("When I navigate to the query section, I should see the code editor", function (Given, When, Then) {
		When.onTheObjectPage
			.iSetSelectedSectionTo(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--AfterFacet::C_MKT_WebTrackingMappingTP::queries::Section"
			);

		Then.onTheGenericObjectPage
			.iSeeTheControlWithId("hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--bqEditor--codeEditor");
	});
	
	opaTest("When I open the Contact Fields helper dialog, I should see a contact fields list", function(Given, When, Then) {
		When.onTheObjectPage
			.iOpenTheFieldsHelperForBQ();
		Then.onTheGenericObjectPage
			.iSeeTheControlWithId("contactFieldsPopover-popover");                         
	});

	opaTest("When I navigate to the validation results section, I should see the validation results table", function (Given, When, Then) {
		When.onTheObjectPage
			.iSetSelectedSectionTo(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--bq_log_table::Section"
			);
		Then.onTheGenericObjectPage
			.iSeeTheControlWithId(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--bq_log_table::Table");
	});

	opaTest("When I navigate to a Google Analytics configuration with function Match and Merge Contacts, I should see the correct fields",
		function (Given, When, Then) {
			When.onTheGenericObjectPage
				.iNavigateBack();
			When.onTheGenericListReport
				.iNavigateFromListItemByFieldValue({
					Field: "WebTrackingMappingName",
					Value: "Google Analytics Contact Match ID"
				});

			Then.onTheGenericObjectPage
				.theObjectPageHeaderTitleIsCorrect("Google Analytics Contact Match ID");
			Then.onTheGenericObjectPage
				.iShouldSeeTheButtonWithLabel("Details");
			Then.onTheGenericObjectPage
				.iShouldSeeTheButtonWithLabel("Contact Fields");
			Then.onTheGenericObjectPage
				.iShouldSeeTheButtonWithLabel("Query Filter");
			Then.onTheGenericObjectPage
				.iShouldSeeTheButtonWithLabel("Query");
			Then.onTheGenericObjectPage
				.iShouldSeeTheButtonWithLabel("Validation Results");
			Then.onTheGenericObjectPage
				.theObjectPageDataFieldHasTheCorrectValue({
					Field: "WebTrackingMappingName",
					Value: "Google Analytics Contact Match ID"
				});

			Then.onTheGenericObjectPage
				.theObjectPageDataFieldHasTheCorrectValue({
					Field: "WebTrackingMappingType",
					Value: "C"
				});

			Then.onTheGenericObjectPage
				.theObjectPageDataFieldHasTheCorrectValue({
					Field: "WebTrackingMappingProperty",
					Value: "UA-116478339-1"
				});

			Then.onTheGenericObjectPage
				.theObjectPageDataFieldHasTheCorrectValue({
					Field: "WebTrackingMappingView",
					Value: "172395359"
				});

			Then.onTheGenericObjectPage
				.theObjectPageDataFieldHasTheCorrectValue({
					Field: "WebTrackingMappingDataSource",
					Value: "A"
				});
		});

	opaTest("When I navigate to the contact fields section, I should see the contact fields table", function (Given, When, Then) {
		When.onTheObjectPage
			.iSetSelectedSectionTo(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--contact_fields::Section"
			);

		Then.onTheGenericObjectPage
			.iSeeTheControlWithId(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--contact_fields::Table");
	});

	opaTest("When I navigate to the Query Filter section, I should see the Basic Filters table", function (Given, When, Then) {
		When.onTheObjectPage
			.iSetSelectedSectionTo(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--contact_filters::Section"
			);

		Then.onTheGenericObjectPage
			.iSeeTheControlWithId(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--contact_filters_basic_filters::Table"
			);
	});

	opaTest("When I navigate to the query section, I should see the Main Queries table", function (Given, When, Then) {
		When.onTheObjectPage
			.iSetSelectedSectionTo(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--contact_query::Section"
			);
		Then.onTheGenericObjectPage
			.iSeeTheControlWithId(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--contact_main_queries_queries::Table");
	});

	opaTest("When I navigate to the validation results section, I should see the validation results table", function (Given, When, Then) {
		When.onTheObjectPage
			.iSetSelectedSectionTo(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--log_table::Section"
			);
		Then.onTheGenericObjectPage
			.iSeeTheControlWithId(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--log_table::Table");
				
		Then.iTeardownMyAppFrame();
	});

});