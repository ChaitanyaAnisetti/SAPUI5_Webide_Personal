sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"hpa/cei/wtm/ext/util/constants",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function (Controller, Constants, Fragment, JSONModel, MessageToast) {
	"use strict";
	return Controller.extend("hpa.cei.wtm.ext.controller.BigQuery", {
		onInit: function () {
			this._oCore = sap.ui.getCore();
			this._updateTheme(this._getCurrentTheme());
			this._oCore.attachThemeChanged(function (oEvent) {
				this._updateTheme(oEvent.getParameter("theme"));
			}, this);
		},
		_getCurrentTheme: function() {
			return this._oCore.getConfiguration().getTheme();
		},
		_updateTheme: function (sTheme) {
			var sNewTheme = Constants.editorThemes[sTheme] || Constants.editorThemes.default;
			var oCodeEditor = this.getView().byId("codeEditor");
			var oCopyQueryCodeEditor = Fragment.byId("copyBQQueryDialog", "copyBQQueryDialog-vbox-codeEditor");

			if (oCodeEditor) {
				oCodeEditor.setColorTheme(sNewTheme.theme);
			}
			if(oCopyQueryCodeEditor) {
				oCopyQueryCodeEditor.setColorTheme(sNewTheme.theme);
			}
		},
		onButtonPressed: function (oEvent) {
			var sWebTrackingMappingType = oEvent.getSource().getBindingContext().getProperty(Constants.components.root.fields.type);
			var oPopover = this._getFieldsPopoverForFunction(sWebTrackingMappingType);
			if (typeof (oPopover) !== "undefined") {
				oPopover.openBy(oEvent.getSource());
			}
		},
		onCopyQueryButtonPressed: function (oEvent) {
			this._getCopyQueryDialog().then(function (oDialog) {
				var oViewModel = oDialog.getModel("copyBQQueryDialogViewModel");
				oViewModel.setProperty("/value", this.getView().byId("codeEditor").getValue());
				oDialog.open();
			}.bind(this));
		},
		onDialogClosePress: function (oEvent) {
			oEvent.getSource().getParent().close();
		},
		_getCopyQueryDialog: function () {
			return new Promise(function (resolve, reject) {
				if (this.oCopyQueryDialog) {
					this._updateTheme(this._getCurrentTheme());
					resolve(this.oCopyQueryDialog);
				} else {
					Fragment.load({
						name: "hpa.cei.wtm.ext.fragment.CopyBigQueryDialog",
						type: "XML",
						id: "copyBQQueryDialog",
						controller: this
					}).then(function (oDialog) {
						this.oCopyQueryDialog = oDialog;
						this.oCopyQueryDialog.attachBeforeOpen(this._onBeforeCopyDialogOpen.bind(this));
						this.oCopyQueryDialog.attachAfterOpen(this._onAfterCopyDialogOpen.bind(this));
						this.getView().addDependent(this.oCopyQueryDialog);
						this.oCopyQueryDialog.setModel(new JSONModel({
							value: ""
						}), "copyBQQueryDialogViewModel");
						this._updateTheme(this._getCurrentTheme());
						resolve(this.oCopyQueryDialog);
					}.bind(this)).catch(reject);
				}
			}.bind(this));
		},
		_onAfterCopyDialogOpen: function (oEvent) {
			var oCodeEditor = Fragment.byId("copyBQQueryDialog", "copyBQQueryDialog-vbox-codeEditor");
			oCodeEditor._oEditor.selectAll();
			oCodeEditor._oEditor.focus();
		},
		_onBeforeCopyDialogOpen: function (oEvent) {
			var oCodeEditor = Fragment.byId("copyBQQueryDialog", "copyBQQueryDialog-vbox-codeEditor");
			oCodeEditor._oEditor.on("copy", this._onCodeEditorCopyEvent.bind(this));
			oCodeEditor._oEditor.selectAll();
		},
		_onCodeEditorCopyEvent: function (sCopiedText) {
			this._getCopyQueryDialog().then(function (oDialog) {
				var oCodeEditor = Fragment.byId("copyBQQueryDialog", "copyBQQueryDialog-vbox-codeEditor");
				MessageToast.show(this.getView().getModel("i18n").getResourceBundle().getText("copyBQQueryDialog.success.copiedToClipboard"));
				oCodeEditor._oEditor.removeAllListeners("copy");
				oDialog.close();
			}.bind(this));
		},
		_getFieldsPopoverForFunction: function (sfunction) {
			switch (sfunction) {
			case Constants.webTrackingMappingType.createInteractions:
				if (!this._oInteractionFieldPopover) {
					this._oInteractionFieldPopover = sap.ui.xmlfragment("hpa.cei.wtm.ext.fragment.InteractionFieldPopover", this);
					this.getView().addDependent(this._oInteractionFieldPopover);
				}
				return this._oInteractionFieldPopover;
			case Constants.webTrackingMappingType.matchAndMergeContacts:
				if (!this._oContactFieldPopover) {
					this._oContactFieldPopover = sap.ui.xmlfragment("hpa.cei.wtm.ext.fragment.ContactFieldPopover", this);
					this.getView().addDependent(this._oContactFieldPopover);
				}
				return this._oContactFieldPopover;
			}
			return null;
		},
		onAfterRendering: function () {
			var sWebTrackingMappingType = this.getView().getBindingContext().getProperty(Constants.components.root.fields.type);
			var oCodeEditor = this.getView().byId("codeEditor");
			if (oCodeEditor.getValue() === "" || oCodeEditor.getValue() === null) {
				oCodeEditor.setValue(this._getPlaceholderValueForFunction(sWebTrackingMappingType));
			}
		},
		_getPlaceholderValueForFunction: function (sFunction) {
			switch (sFunction) {
			case Constants.webTrackingMappingType.createInteractions:
				return this._getCreateInteractionsBigQueryPlaceholder();
			case Constants.webTrackingMappingType.matchAndMergeContacts:
				return this._getCreateContactsBigQueryPlaceholder();
			}
			return "";
		},
		_getCreateInteractionsBigQueryPlaceholder: function () {
			var sPlaceholder1 = this._getText("bigQueryEditorPlaceHolder1"),
				sPlaceholder2 = this._getText("bigQueryEditorPlaceHolder2");

			return "#standardSQL\r\n/*" + sPlaceholder1 + "*/\r\n/*" + sPlaceholder2 + "*/";
		},
		_getCreateContactsBigQueryPlaceholder: function () {
			var sPlaceholder1 = this._getText("bigQueryEditorPlaceHolder1"),
				sPlaceholder2 = this._getText("bigQueryEditorPlaceHolder2ContactMatch");

			return "#standardSQL\r\n/*" + sPlaceholder1 + "*/\r\n/*" + sPlaceholder2 + "*/";
		},
		_getText: function (sTextKey, sModel) {
			return this._getResourceBundle(sModel).getText(sTextKey);
		},
		_getResourceBundle: function (sModelName) {
			var sModel = sModelName;
			if (typeof (sModel) === "undefined") {
				sModel = "i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrackingMappingTP";
			}
			return this.getView().getModel(sModel).getResourceBundle();
		}
	});
});