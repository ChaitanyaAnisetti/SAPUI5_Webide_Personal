sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/m/Button",
	"sap/m/Dialog",
	"sap/m/Text",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"sap/ui/core/MessageType",
	"hpa/cei/wtm/ext/util/constants",
	"sap/ui/core/Fragment"
], function (JSONModel, Button, Dialog, Text, Filter, FilterOperator, MessageToast, MessageType, Constants, Fragment) {
	sap.ui.controller("hpa.cei.wtm.ext.controller.ObjectPageDetailsExtension", {
		_oCopyPopOver: null,
		_oValidationDialog: null,
		_oValidationDialogBigQuery: null,
		_sFrom: null,
		_sTo: null,
		_oMessages: {
			bDisplayed: false,
			aMessages: []
		},
		onInit: function () {
			this._initModels();
			this.byId("objectPage").attachNavigate(this.onNavigateSection, this);
			this._onAfterRootNodeInit();
		},
		_initModels: function () {
			var oResourceBundle = this.getOwnerComponent().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrackingMappingTP")
				.getResourceBundle();
			this.getView().setModel(new JSONModel({
				filterType: Constants.filterType.basic
			}), "filterType");
			this.getView().setModel(new JSONModel({
				"items": [{
					"text": oResourceBundle.getText("boolTrue"),
					"key": "TRUE"
				}, {
					"text": oResourceBundle.getText("boolFalse"),
					"key": "FALSE"
				}]
			}), "boolModel");
			this.getView().setModel(new JSONModel({
				"okButtonEnabled": true
			}), "validationDialogModel");
			this.getView().setModel(new JSONModel({
				"to_WebTrckgRtrvlContactHdr": 0
			}), "queryCount");
		},
		_findField: function (sPropertyname, sEntitySet) {
			var that = this;
			var oODataHelper = new sap.ui.comp.smartfield.ODataHelper(this.getView().getModel());
			var oFoundField;
			if (typeof (sEntitySet) !== "undefined") {
				$.each(oODataHelper.getAnalyzer(this.getView().getModel()).getFieldsByEntitySetName(sEntitySet), function (iFieldIndex, oField) {
					if (oField.name === sPropertyname) {
						oFoundField = oField;
					}
					return typeof (oFoundField) === "undefined";
				});
			} else {
				$.each(oODataHelper.oMeta.getODataEntityContainer().entitySet, function (iEntitySetIndex, oEntitySet) {
					var oFields = oODataHelper.getAnalyzer(that.getView().getModel()).getFieldsByEntitySetName(oEntitySet.name);
					$.each(oFields, function (iFieldIndex, oField) {
						if (oField.name === sPropertyname) {
							oFoundField = oField;
						}
						return typeof (oFoundField) === "undefined";
					});
					return typeof (oFoundField) === "undefined";
				});
			}
			return oFoundField;
		},
		//Object Page Navigation Event
		onNavigateSection: function (oEvent) {
			if (oEvent.getParameter("section").getId() ===
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--common_filter_dimensions::Section"
			) {
				if (this.getView().getModel().getObject(this.getView().getBindingContext().sPath).WebTrackingMappingFilterString) {
					this.getView().getModel("filterType").setData({
						filterType: Constants.filterType.expert
					});
				} else {
					this.getView().getModel("filterType").setData({
						filterType: Constants.filterType.basic
					});
				}
			}
		},
		onAfterRendering: function () {
			this._onAfterRootNodeRendering();
			this._onAfterMainQueryNodeRendering();
			this._onAfterProductQueryNodeRendering();
			this._onAfterTagQueryNodeRendering();
			this._onAfterContactQueryNodeRendering();

		},
		_onAfterRootNodeInit: function () {
			if (this.getOwnerComponent().getEntitySet() === Constants.components.root.name) {
				var oLogTable = this.getView().byId(
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--bq_log_table::Table");
				oLogTable.setIgnoreFromPersonalisation(["ValidityEndDate", "WebTrckgRtrvlHeaderName", "ValidityDate"]);

			}
		},
		_onAfterRootNodeRendering: function () {
			if (this.getOwnerComponent().getEntitySet() === Constants.components.root.name) {
				var sFooterToolbarId =
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--template::ObjectPage::FooterToolbar";
				var sCommonFiltersBasicSubsectionId =
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--common_filters_basic::SubSection";
				var sCommonFiltersExpertSubsectionId =
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--common_filters_expert::SubSection";
				var sContactFiltersBasicSubsectionId =
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--contact_filters_basic::SubSection";
				var sContactFiltersExpertSubsectionId =
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--contact_filters_expert::SubSection";
				var sCommonDimensionsTableId =
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgComMapping::com.sap.vocabularies.UI.v1.LineItem::Table";
				var sBasicFilterSegmentedButtonsId =
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--common_filters_basic::SubSection--filterTypeSegmentedButton";
				var sContactBasicFilterSegmentedButtonsId =
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--contact_filters_basic::SubSection--filterTypeSegmentedButton";
				this.getView().byId(sFooterToolbarId).getAggregation("content")[0] = this._oMessageButton;
				if (!this.byId(sBasicFilterSegmentedButtonsId)) {
					var oObjectPageSubsectionFilterBasic = this.getView().byId(sCommonFiltersBasicSubsectionId);
					var oObjectPageSubsectionFilterExpert = this.getView().byId(sCommonFiltersExpertSubsectionId);
					this._renderFilterModeSelector(oObjectPageSubsectionFilterBasic);
					this._renderFilterModeSelector(oObjectPageSubsectionFilterExpert);
				}
				if (!this.byId(sContactBasicFilterSegmentedButtonsId)) {
					var oObjectPageSubsectionContactFilterBasic = this.getView().byId(sContactFiltersBasicSubsectionId);
					var oObjectPageSubsectionContactFilterExpert = this.getView().byId(sContactFiltersExpertSubsectionId);
					this._renderFilterModeSelector(oObjectPageSubsectionContactFilterBasic);
					this._renderFilterModeSelector(oObjectPageSubsectionContactFilterExpert);
				}
				this._enableValuehelpAutobindingOnRootNode();
				this._enableSideEffectsOnValueChangeForTable(sCommonDimensionsTableId, "to_WebTrckgComMapping", "WebTrckgMappingInternalField");
				this.byId("hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--activate").attachPress(
					function (oEvent) {
						sap.ui.getCore().getMessageManager().removeAllMessages();
					}, this);
				this.getView().getModel().attachPropertyChange(function (oEvent) {
					var oModel = this.getView().getModel();
					var sChangedPropertyPath = oEvent.getParameter("path");
					var oBindingContext = oEvent.getParameter("context");
					var sOriginalValue = oModel.getOriginalProperty(sChangedPropertyPath, oBindingContext);
					if (sChangedPropertyPath === "WebTrackingMappingType" && sOriginalValue !== "" && sOriginalValue !== null) {
						this.getView().byId(
							"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--com.sap.vocabularies.UI.v1.FieldGroup::details_FG::WebTrackingMappingType::Field"
						).getInnerControls()[0].close();
						oModel.resetChanges([oBindingContext.getPath() + "/" + sChangedPropertyPath]);

						this.extensionAPI.getTransactionController().executeSideEffects();
					}
				}, this);
			}
		},
		_enableSideEffectsOnValueChangeForTable: function (sTableId, sSourceEntity, sSourceProperty) {
			var oSideEffect = {
				sourceProperties: [
					sSourceProperty
				],
				sourceEntities: [
					sSourceEntity
				]
			};
			var oTable = this.getView().byId(sTableId);
			if (typeof (oTable) !== "undefined" && typeof (oTable.attachFieldChange) !== "undefined") {
				oTable.attachFieldChange(function (oEvent) {
					this.extensionAPI.getTransactionController().executeSideEffects(oSideEffect).then(function () {
						oTable.rebindTable();
					});
				}, this);
			}
		},
		adaptTransientMessageExtension: function () {
			var oMessageManager = sap.ui.getCore().getMessageManager();
			var aMessages = oMessageManager.getMessageModel().getData();

			if (aMessages.length) {
				oMessageManager.removeAllMessages();
				aMessages.forEach(function (oSourceMessage) {
					var oNewMessage = new sap.ui.core.message.Message({
						id: oSourceMessage.id,
						message: oSourceMessage.message,
						description: oSourceMessage.description,
						descriptionUrl: oSourceMessage.descriptionUrl,
						additionalText: oSourceMessage.additionalText,
						code: oSourceMessage.code,
						processor: oSourceMessage.messageProcessor,
						type: oSourceMessage.type,
						target: this.getView().getBindingContext().getPath(),
						fullTarget: this.getView().getBindingContext().getPath(),
						persistent: false
					});
					oMessageManager.addMessages(oNewMessage);
				}, this);
			}
		},
		_enableValuehelpAutobindingOnRootNode: function () {
			var oSmartFieldConfigurationSettings = {
				preventInitialDataFetchInValueHelpDialog: false
			};
			var oGoogleAnalyticsPropertySmartField = this.getView().byId(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--com.sap.vocabularies.UI.v1.FieldGroup::details_FG::WebTrackingMappingProperty::Field"
			);
			var oGoogleAnalyticsViewSmartField = this.getView().byId(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--com.sap.vocabularies.UI.v1.FieldGroup::details_FG::WebTrackingMappingView::Field"
			);
			var oBigQueryProjectSmartField = this.getView().byId(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--com.sap.vocabularies.UI.v1.FieldGroup::details_FG::WebTrackingMappingProject::Field"
			);
			var oBigQueryDataTableSmartField = this.getView().byId(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--com.sap.vocabularies.UI.v1.FieldGroup::details_FG::WebTrackingMappingDataTable::Field"
			);
			var oFiltersTable = this.getView().byId(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgMappgFltr::com.sap.vocabularies.UI.v1.LineItem::responsiveTable"
			);
			var oCommonDimensionsTable = this.getView().byId(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgComMapping::com.sap.vocabularies.UI.v1.LineItem::responsiveTable"
			);
			var oInteractionFieldsTable = this.getView().byId(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgValMapping::com.sap.vocabularies.UI.v1.LineItem::responsiveTable"
			);
			if (typeof (oGoogleAnalyticsPropertySmartField) !== "undefined") {
				oGoogleAnalyticsPropertySmartField.setConfiguration(new sap.ui.comp.smartfield.Configuration(oSmartFieldConfigurationSettings));
			}
			if (typeof (oGoogleAnalyticsViewSmartField) !== "undefined") {
				oGoogleAnalyticsViewSmartField.setConfiguration(new sap.ui.comp.smartfield.Configuration(oSmartFieldConfigurationSettings));
			}
			if (typeof (oBigQueryProjectSmartField) !== "undefined") {
				oBigQueryProjectSmartField.setConfiguration(new sap.ui.comp.smartfield.Configuration(oSmartFieldConfigurationSettings));
			}
			if (typeof (oBigQueryDataTableSmartField) !== "undefined") {
				oBigQueryDataTableSmartField.setConfiguration(new sap.ui.comp.smartfield.Configuration(oSmartFieldConfigurationSettings));
			}
			if (typeof (oCommonDimensionsTable) !== "undefined") {
				this._enableAutobindingCommonDimensionsTable(oCommonDimensionsTable);
			}
			if (typeof (oInteractionFieldsTable) !== "undefined") {
				this._enableAutobindingInteractionFieldsTable(oInteractionFieldsTable);
			}
			if (typeof (oFiltersTable) !== "undefined") {
				this._enableAutobindingFiltersTable(oFiltersTable);
			}
		},
		_onAfterMainQueryNodeRendering: function () {
			if (this.getOwnerComponent().getEntitySet() === Constants.components.query.interaction.header.name) {
				var sDimensionsTableId =
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrckgIntactnHdrTP--interactionRtrvlHdrDim::Table";
				var sMetricsTableId =
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrckgIntactnHdrTP--interactionRtrvlHdrMsr::Table";
				var oDimensionsTable = this.getView().byId(sDimensionsTableId);
				var oMetricsTable = this.getView().byId(sMetricsTableId);
				this._enableAutobindingQueryDimensionsTable(oDimensionsTable.getTable());
				this._enableAutobindingQueryMetricsTable(oMetricsTable.getTable());
				/*this._enableSideEffectsOnValueChangeForTable(sDimensionsTableId, "to_WebTrckgRtrvlDimItem", Constants.components.query.interaction
					.header.fields.internalField);*/
			}
		},
		_onAfterProductQueryNodeRendering: function () {
			if (this.getOwnerComponent().getEntitySet() === Constants.components.query.product.header.name) {
				var sDimensionsTableId =
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrckgProdHeaderTP--productRtrvlHdrDim::Table";
				var sMetricsTableId =
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrckgProdHeaderTP--productRtrvlHdrMsr::Table";
				var oDimensionsTable = this.getView().byId(sDimensionsTableId);
				var oMetricsTable = this.getView().byId(sMetricsTableId);
				this._enableAutobindingQueryDimensionsTable(oDimensionsTable.getTable());
				this._enableAutobindingQueryMetricsTable(oMetricsTable.getTable());
			}
		},
		_onAfterTagQueryNodeRendering: function () {
			if (this.getOwnerComponent().getEntitySet() === Constants.components.query.tag.header.name) {
				var sDimensionsTableId =
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingTagHeaderTP--tagRtrvlHdrDim::Table";
				var sMetricsTableId =
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingTagHeaderTP--tagRtrvlHdrMsr::Table";
				var oDimensionsTable = this.getView().byId(sDimensionsTableId);
				var oMetricsTable = this.getView().byId(sMetricsTableId);
				this._enableAutobindingQueryDimensionsTable(oDimensionsTable.getTable());
				this._enableAutobindingQueryMetricsTable(oMetricsTable.getTable());
			}
		},
		_onAfterContactQueryNodeRendering: function () {
			if (this.getOwnerComponent().getEntitySet() === Constants.components.query.contact.header.name) {
				var sDimensionsTableId =
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrckgContactHeaderTP--contactRtrvlHdrDim::Table";
				var sMetricsTableId =
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrckgContactHeaderTP--contactRtrvlHdrMsr::Table";
				var oDimensionsTable = this.getView().byId(sDimensionsTableId);
				var oMetricsTable = this.getView().byId(sMetricsTableId);
				this._enableAutobindingQueryDimensionsTable(oDimensionsTable.getTable());
				this._enableAutobindingQueryMetricsTable(oMetricsTable.getTable());
			}
		},
		beforeDeleteExtension: function () {
			var oMessageText = {
				title: this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|" + this.getOwnerComponent().getEntitySet()).getResourceBundle()
					.getText("popupTitleText"),
				text: this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|" + this.getOwnerComponent().getEntitySet()).getResourceBundle()
					.getText("popupDescriptionText")
			};
			return oMessageText;
		},
		_renderFilterModeSelector: function (oObjectPageSubsection) {
			if (typeof (oObjectPageSubsection) !== "undefined") {
				sap.ui.core.Fragment.load({
					name: "hpa.cei.wtm.ext.fragment.FilterTypeSegmentedButton",
					id: oObjectPageSubsection.getId(),
					controller: this
				}).then(function (oSegmentedButtons) {
					var oVBox = new sap.m.VBox();
					oVBox.addItem(oSegmentedButtons);
					oObjectPageSubsection.getBlocks()[0].insertContent(oVBox, 0);
				});
			}
		},
		_onFilterTypeChanged: function (oEvent) {
			var that = this;
			var oModel = this.getView().getModel();
			var sBindingPath = this.getView().getBindingContext().getPath();
			var oTextBundle = that.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrckgMappgFltrTP").getResourceBundle();
			var oDialog = new Dialog({
				title: oTextBundle.getText("filtersDatalossDialogTitle"),
				type: "Message",
				state: "Warning",
				content: new Text({
					text: oTextBundle.getText("filtersDatalossDialogMsg")
				}),
				beginButton: new Button({
					text: oTextBundle.getText("filtersDatalossDialogYes"),
					press: function () {
						var bExpertMode = false;
						if (that.getView().getModel("filterType").getData().filterType === Constants.filterType.expert) {
							bExpertMode = true; //Delete basic filter nodes
						} else {
							//Clear expert filter
							bExpertMode = false;
						}
						var oConfig = oModel.getObject(sBindingPath);
						oModel.callFunction(Constants.functionImports.clearFilters, {
							method: "POST",
							urlParameters: {
								WebTrackingMappingUUID: oConfig.WebTrackingMappingUUID,
								Isexpert: bExpertMode,
								IsActiveEntity: oConfig.IsActiveEntity
							},
							success: function (context) {
								oModel.refresh();
							},
							error: function (e) {}
						});
						oDialog.close();
					}
				}),
				endButton: new Button({
					text: oTextBundle.getText("filtersDatalossDialogCancel"),
					press: function () {
						if (that.getView().getModel("filterType").getData().filterType === Constants.filterType.expert) {
							that.getView().getModel("filterType").setData({
								filterType: Constants.filterType.basic
							});
						} else {
							that.getView().getModel("filterType").setData({
								filterType: Constants.filterType.expert
							});
						}
						oDialog.close();
					}
				}),
				afterClose: function () {
					oDialog.destroy();
				}
			});
			if (this.getView().getModel("filterType").getData().filterType === Constants.filterType.expert) {
				oModel.read(sBindingPath + "/to_WebTrckgMappgFltr/$count", {
					success: function (filterCount) {
						if (filterCount > 0) {
							oDialog.open();
						}
					}
				});
			} else if (this.getView().getModel("filterType").getData().filterType === Constants.filterType.basic) {
				var sFilterString = oModel.getProperty(sBindingPath + "/" + Constants.components.root.fields.filterString);
				if (sFilterString !== null && sFilterString !== "") {
					oDialog.open();
				}
			}
		},
		_getCopyActionDialog: function () {
			return new Promise(function (resolve, reject) {
				if (this._oCopyPopover) {
					resolve(this._oCopyPopover);
				} else {
					Fragment.load({
						name: "hpa.cei.wtm.ext.fragment.CopyConfig",
						id: "copyActionFrag",
						type: "XML",
						controller: this
					}).then(function (oDialog) {
						this._oCopyPopover = oDialog;
						this.getView().addDependent(this._oCopyPopover);
						this._oCopyPopover.setModel(new JSONModel({
							configuration: {}
						}), "copyPopoverDataModel");
						this._oCopyPopover.setModel(new JSONModel({
							configuration: {
								WebTrackingMappingName: "",
								WebTrackingMappingDataSource_Text: "",
								WebTrackingMappingType_Text: ""
							},
							googleAnalytics: false,
							googleBigQuery: false
						}), "copyPopoverViewModel");
						resolve(this._oCopyPopover);
					}.bind(this));
				}
			}.bind(this));
		},
		onCopyAction: function (oEvent) {
			this._getCopyActionDialog().then(function (oDialog) {
				var oModel = this.getView().getModel();
				var oDataModel = oDialog.getModel("copyPopoverDataModel");
				var oViewModel = oDialog.getModel("copyPopoverViewModel");
				var oResourceBundle = this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrackingMappingTP").getResourceBundle();
				var oBindingContext = this.getView().getBindingContext();
				var oConfiguration = oModel.getObject(oBindingContext.getPath());
				
				var oWebTrackingMappingType = oModel.getProperty(oBindingContext.getPath("to_WebTrackingMappgType"));
				var oWebTrackingMappingDataSource = oModel.getProperty(oBindingContext.getPath("to_WebTrckgMappgDataSrce"));

				oDataModel.setProperty("/configuration", oConfiguration);
				oViewModel.setProperty("/configuration/WebTrackingMappingName", oResourceBundle.getText("copyOfPlaceholder", oConfiguration.WebTrackingMappingName));
				oViewModel.setProperty("/configuration/WebTrackingMappingType_Text", oWebTrackingMappingType.WebTrackingMappingType_Text);
				oViewModel.setProperty("/configuration/WebTrackingMappingDataSource_Text", oWebTrackingMappingDataSource.WebTrackingMappingDataSource_Text);

				oViewModel.setProperty("/googleAnalytics", oConfiguration.WebTrackingMappingDataSource === Constants.dataSource.googleAnalytics);
				oViewModel.setProperty("/googleBigQuery", oConfiguration.WebTrackingMappingDataSource === Constants.dataSource.googleBigQuery);

				oDialog.open();
			}.bind(this));
		},
		closeCopyAction: function () {
			return new Promise(function (resolve, reject) {
				this._getCopyActionDialog().then(function (oDialog) {
					oDialog.close();
					resolve();
				});
			}.bind(this));
		},
		createAction: function (oEvent) {
			this._getCopyActionDialog().then(function (oDialog) {
				var oDataModel = oDialog.getModel("copyPopoverDataModel");
				var oViewModel = oDialog.getModel("copyPopoverViewModel");
				var oConfiguration = oDataModel.getProperty("/configuration");
				this.getView().getModel().callFunction(Constants.functionImports.copy, {
					method: "POST",
					urlParameters: {
						WebTrackingMappingUUID: oConfiguration.WebTrackingMappingUUID,
						Name: oViewModel.getProperty("/configuration/WebTrackingMappingName"),
						IsActiveEntity: oConfiguration.IsActiveEntity
					},
					success: function (context) {
						oDialog.close();
						var newContext = new sap.ui.model.Context(this.getView().getModel(),
							"/C_MKT_WebTrackingMappingTP(WebTrackingMappingUUID=guid'" + context.WebTrackingMappingUUID + "',IsActiveEntity=" +
							context.IsActiveEntity +
							")");
						this.extensionAPI.getNavigationController().navigateInternal(newContext);
					}.bind(this),
					error: function (e) {
						var errorText = this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrackingMappingTP").getResourceBundle()
							.getText("copyError");
						sap.m.MessageToast.show(errorText + " : " + JSON.parse(e.responseText).error.message.value);
					}.bind(this)
				});

			}.bind(this));
		},
		onDeactivateAction: function () {
			var oView = this.getView();
			var oModel = oView.getModel();
			var oQuery = oModel.getObject(this.getView().getBindingContext().getPath());
			var oResourceBundle = oView.getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrackingMappingTP").getResourceBundle();
			oView.setBusy(true);
			oModel.callFunction(Constants.functionImports.deactivate, {
				method: "POST",
				urlParameters: {
					WebTrackingMappingUUID: oQuery.WebTrackingMappingUUID,
					IsActiveEntity: oQuery.IsActiveEntity
				},
				success: function () {
					oView.setBusy(false);
					var successText = oResourceBundle
						.getText("deactivateToastMessage");
					MessageToast.show(successText);
					oModel.refresh();
				},
				error: function (e) {
					oView.setBusy(false);
					var errorText = oResourceBundle.getText("deactivationError");
					MessageToast.show(errorText + " : " + JSON.parse(e.responseText).error.message.value);
				}
			});
		},
		adjustDates: function (oDateRange, dataSource) {
			var dateTo = new Date();
			dateTo.setHours(0, 0, 0, 0);
			var dateFrom = new Date();
			dateFrom.setHours(0, 0, 0, 0);
			var offset = 6;
			dateFrom.setDate(dateTo.getDate() - offset);
			oDateRange.setDateValue(dateFrom);
			oDateRange.setValueState(sap.ui.core.ValueState.None);
			oDateRange.setValueStateText("");
			if (dataSource === Constants.dataSource.googleAnalytics) {
				oDateRange.setSecondDateValue(dateTo);
				this._sFrom = dateFrom;
				this._sTo = dateTo;
			} else if (dataSource === Constants.dataSource.googleBigQuery) {
				this._sFrom = dateFrom;
				this._sTo = dateFrom;
			}
		},
		onValidateAction: function () {
			var dataSource = this.getView().getModel().getObject(this.getView().getBindingContext().getPath()).WebTrackingMappingDataSource;
			var dateRange;
			if (dataSource === Constants.dataSource.googleAnalytics) {
				if (!this._oValidationDialog) {
					this._oValidationDialog = sap.ui.xmlfragment(
						"ValidationDialog",
						"hpa.cei.wtm.ext.fragment.ValidateDialog",
						this
					);
				}
				dateRange = sap.ui.core.Fragment.byId("ValidationDialog", "DateRangeSelection");
				this.adjustDates(dateRange, dataSource);
				this._oValidationDialog.setModel(this.getView().getModel());
				this.getView().addDependent(this._oValidationDialog);
				this._oValidationDialog.open();
			} else if (dataSource === Constants.dataSource.googleBigQuery) {
				if (!this._oValidationDialogBigQuery) {
					this._oValidationDialogBigQuery = sap.ui.xmlfragment(
						"ValidationDialogBigQuery",
						"hpa.cei.wtm.ext.fragment.ValidateDialogBigQuery",
						this
					);
				}
				dateRange = sap.ui.core.Fragment.byId("ValidationDialogBigQuery", "DatePicker");
				this.adjustDates(dateRange, dataSource);
				this._oValidationDialogBigQuery.setModel(this.getView().getModel());
				this.getView().addDependent(this._oValidationDialogBigQuery);
				this._oValidationDialogBigQuery.open();
			}
		},
		onDialogCancelButton: function () {
			this.closeValidationDialog();
		},
		onDialogSubmitButton: function () {
			var that = this;
			var Query = this.getView().getModel().getObject(this.getView().getBindingContext().getPath());
			var oObjectPage = this.getView().byId(
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--objectPage");
			this.setValidationDialogBusy(true);
			this.extensionAPI.invokeActions(Constants.functionImports.validate, this.getView().getBindingContext(), {
				WebTrackingMappingUUID: Query.WebTrackingMappingUUID,
				StartTime: this._sFrom,
				EndTime: this._sTo,
				IsActiveEntity: Query.IsActiveEntity
			}).then(function (o) {
				oObjectPage.setSelectedSection(
					"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--log_table::Section");
			}).catch(function (e) {
				var errorText = that.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrackingMappingTP").getResourceBundle()
					.getText("validationError");
				sap.m.MessageToast.show(errorText + " : " + JSON.parse(e.responseText).error.message.value);
			}).finally(function () {
				that.extensionAPI.refresh();
				that.closeValidationDialog();
				that.setValidationDialogBusy(false);
			});
		},
		onDateChange: function (oEvent) {
			var Query = this.getView().getModel().getObject(this.getView().getBindingContext().getPath());
			var dataSource = Query.WebTrackingMappingDataSource;
			var bValid = oEvent.getParameter("valid");
			var oEventSource = oEvent.getSource();
			var oValidationDialogModel = this.getView().getModel("validationDialogModel");
			var oBindingContext = this.getView().getBindingContext();
			if (bValid) {
				if (dataSource === Constants.dataSource.googleAnalytics) {
					var iDaysBetween = (oEvent.getParameter("to") - oEvent.getParameter("from")) / 1000 / 3600 / 24;
					if (iDaysBetween > 7) {
						oEventSource.setValueState(sap.ui.core.ValueState.Error);
						oEventSource.setValueStateText(this.getView().getModel(
								"i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrackingMappingTP").getResourceBundle()
							.getText("validationPeriodError"));
						// Disable Ok button in dialog if date not valid.
						oValidationDialogModel.setProperty("/okButtonEnabled", false, oBindingContext);
					} else {
						oEventSource.setValueState(sap.ui.core.ValueState.None);
						oValidationDialogModel.setProperty("/okButtonEnabled", true, oBindingContext);
						this._sFrom = this.convertLocalDateToUTC(oEventSource.getFrom());
						this._sTo = this.convertLocalDateToUTC(oEventSource.getTo());
					}
				} else if (dataSource === Constants.dataSource.googleBigQuery) {
					oEventSource.setValueState(sap.ui.core.ValueState.None);
					this._sFrom = oEventSource.getDateValue();
					this._sTo = oEventSource.getDateValue();
				}
			} else {
				oEventSource.setValueState(sap.ui.core.ValueState.Error);
			}
		},
		convertLocalDateToUTC: function (oDate) {
			var oUTCDate = new Date();
			oUTCDate.setUTCFullYear(oDate.getFullYear());
			oUTCDate.setUTCMonth(oDate.getMonth());
			oUTCDate.setUTCDate(oDate.getDate());
			oUTCDate.setUTCHours(oDate.getHours());
			oUTCDate.setUTCMinutes(oDate.getMinutes());
			oUTCDate.setUTCSeconds(oDate.getSeconds());
			oUTCDate.setUTCMilliseconds(oDate.getMilliseconds());
			return oUTCDate;
		},
		closeValidationDialog: function () {
			var dataSource = this.getView().getModel().getObject(this.getView().getBindingContext().getPath()).WebTrackingMappingDataSource;
			if (dataSource === Constants.dataSource.googleAnalytics) {
				this._oValidationDialog.close();
			} else if (dataSource === Constants.dataSource.googleBigQuery) {
				this._oValidationDialogBigQuery.close();
			}
		},
		setValidationDialogBusy: function (bBusy) {
			var dataSource = this.getView().getModel().getObject(this.getView().getBindingContext().getPath()).WebTrackingMappingDataSource;
			if (dataSource === Constants.dataSource.googleAnalytics) {
				this._oValidationDialog.setBusy(bBusy);
			} else if (dataSource === Constants.dataSource.googleBigQuery) {
				this._oValidationDialogBigQuery.setBusy(bBusy);
			}
		},
		onInteractionVH: function (oEvent) {
			var oResourceBundle = this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrackingMappingTP").getResourceBundle();
			var sBindingPath = oEvent.getSource().getBindingContext().getPath();
			var oModel = this.getView().getModel();
			var sField = oModel.getProperty(sBindingPath + "/WebTrackingMappingField");
			var sFieldLabel = oModel.getProperty(sBindingPath + "/WebTrckgMappingFieldLabel") || sField;
			var oInput = oEvent.getSource();
			var oBindingInfo = this._getInteractionF4BindingInfo(sField);

			// prepare filter
			if (sField === "InteractionReason") {
				var oMappingTable = this.getView().byId("to_WebTrckgValMapping::com.sap.vocabularies.UI.v1.LineItem::Table").getTable();
				var sInteractionType = this._getInteractionType(oMappingTable);
				if (!sInteractionType) {
					//raise error message, user needs to select interaction type first
					sap.m.MessageToast.show(
						oResourceBundle.getText("interactionReasonF4Error")
					);
					return;
				} else {
					oBindingInfo.filters = oBindingInfo.filters || [];
					oBindingInfo.push(new Filter("InteractionType", FilterOperator.EQ, sInteractionType));
				}
			}
			// create value help dialog
			// every time a new dialog will be created, as different bindind is required depend on selected interaction field
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				title: sFieldLabel,
				supportMultiselect: false,
				supportRanges: false,
				supportRangesOnly: false,
				key: oBindingInfo.key,
				descriptionKey: oBindingInfo.text,
				ok: function (oControlEvent) {
					if (oControlEvent.getParameter("tokens").length > 0) {
						var sValue = oControlEvent.getParameter("tokens")[0].getProperty("key");
						oInput.setValue(sValue);
						oValueHelpDialog.close();
					}
				},
				cancel: function (oControlEvent) {
					oValueHelpDialog.close();
				},
				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});
			var oValueHelpDialogTable = oValueHelpDialog.getTable();
			// enable Search
			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				showFilterConfiguration: false,
				basicSearch: new sap.m.SearchField({
					showSearchButton: sap.ui.Device.system.phone,
					search: function (oControlEvent) {
						oValueHelpDialog.getFilterBar().search();
					}
				}),
				search: function (oControlEvent) {
					var sText = oControlEvent.getSource().getBasicSearchValue();
					if (sText !== "") {
						var oFilter = new Filter(oBindingInfo.text, FilterOperator.Contains, sText);
						oValueHelpDialogTable.getBinding("rows").filter([oFilter]);
					} else {
						// reset filter value
						oValueHelpDialogTable.getBinding("rows").filter([]);
					}
				}
			});
			oValueHelpDialog.setFilterBar(oFilterBar);
			// data binding
			oValueHelpDialog.setModel(oModel);
			oValueHelpDialog.setModel(this.getView().getModel("boolModel"), "boolModel");
			oValueHelpDialogTable.setNoData(oResourceBundle.getText("interactionF4NoData"));
			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: oBindingInfo.columns
			});
			oValueHelpDialogTable.setModel(oColModel, "columns");
			oValueHelpDialogTable.bindRows({
				filters: oBindingInfo.filters || [],
				path: oBindingInfo.path,
				parameters: {
					custom: {
						webtrackingmappingview: this._getGoogleAnalyticsViewID(),
						webtrakcingmappingfunction: this._getGoogleAnalyticsFuncionId()
					}
				}
			});
			oValueHelpDialog.open();
		},
		_getInteractionF4BindingInfo: function (sField) {
			var oResourceBundle = this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrackingMappingTP").getResourceBundle();
			var sGenericKeyLabel = oResourceBundle.getText("interactionF4ValueColumn");
			var sGenericDescriptionLabel = oResourceBundle.getText("interactionF4DescriptionColumn");
			var oBindingInfo;
			if (typeof (Constants.interactionF4BindingInfo[sField]) !== "undefined") {
				oBindingInfo = Constants.interactionF4BindingInfo[sField];
				if (oBindingInfo.columns) {
					oBindingInfo.columns[0].label = sGenericKeyLabel;
					oBindingInfo.columns[1].label = sGenericDescriptionLabel;
				} else {
					oBindingInfo.columns = [{
						label: sGenericKeyLabel,
						template: oBindingInfo.key
					}, {
						label: sGenericDescriptionLabel,
						template: oBindingInfo.text
					}];
				}
			} else {
				var oFieldMetadata = this._findField(sField);
				if (oFieldMetadata) {
					if (oFieldMetadata.type === "Edm.Boolean") {
						oBindingInfo = Constants.interactionF4BindingInfo.booleanModel;
						oBindingInfo.columns[0].label = sGenericKeyLabel;
						oBindingInfo.columns[1].label = sGenericDescriptionLabel;
						return oBindingInfo;
					} else if (typeof (oFieldMetadata["com.sap.vocabularies.Common.v1.ValueList"]) !== "undefined") {
						var oValueListSettings = oFieldMetadata["com.sap.vocabularies.Common.v1.ValueList"];
						oBindingInfo = {
							path: "/" + oValueListSettings.CollectionPath.String,
							key: "",
							text: "",
							columns: []
						};
						$.each.call(this, oValueListSettings.Parameters, function (index, oParameter) {
							var oParameterMetadata = this._findField(oParameter.ValueListProperty.String, oValueListSettings.CollectionPath.String);
							if (oParameter.RecordType === "com.sap.vocabularies.Common.v1.ValueListParameterInOut") {
								oBindingInfo.key = oParameter.ValueListProperty.String;
							} else if (oParameter.RecordType === "com.sap.vocabularies.Common.v1.ValueListParameterOut") {
								oBindingInfo.text = oParameter.ValueListProperty.String;
							}
							oBindingInfo.columns.push({
								label: oParameterMetadata.fieldLabel,
								template: oParameter.ValueListProperty.String
							});
						}.bind(this));
					}
				}
			}
			return oBindingInfo;
		},
		_getInteractionType: function (oTable) {
			var oModel = this.getView().getModel();
			for (var index = 0; index <= oTable.getItems().length; index++) {
				var sPath = oTable.getItems()[index].getBindingContextPath();
				if (oModel.getProperty(sPath + "/WebTrackingMappingField") === "InteractionType") {
					return oModel.getProperty(sPath + "/WebTrckgMappingFieldValue");
				}
			}
			return "";
		},
		_getGoogleAnalyticsViewID: function () {
			var oModel = this.getView().getModel();
			var oBindingContext = this.getView().getBindingContext();
			var sBindingContextPath = oBindingContext.getPath();
			var sWebTrackingMappingType = oModel.getProperty(sBindingContextPath + "/WebTrackingMappingDataSource");
			var sWebTrackingMappingViewProperty;

			switch (sWebTrackingMappingType) {
			case "A":
				sWebTrackingMappingViewProperty = Constants.components.root.fields.view;
				break;
			case "B":
				sWebTrackingMappingViewProperty = Constants.components.root.fields.dataTable;
				break;
			}

			return oModel.getProperty(oBindingContext.getPath() + "/" + sWebTrackingMappingViewProperty);
		},
		_getGoogleAnalyticsFuncionId: function () {
			var oModel = this.getView().getModel();
			var oBindingContext = this.getView().getBindingContext();
			return oModel.getProperty(oBindingContext.getPath() + "/" + "WebTrackingMappingType");
		},
		// update suggest item binding on the interaction mapping table
		onInteractionSuggest: function (oEvent) {
			var sPath = oEvent.getSource().getBindingContext().getPath();
			var sField = this.getView().getModel().getProperty(sPath + "/WebTrackingMappingField");
			var oBindingInfo = this._getInteractionF4BindingInfo(sField);
			var oInput = oEvent.getSource();
			if (!oInput.getBinding("suggestionRows") || oInput.getBinding("suggestionRows").getPath() !== oBindingInfo.path) {
				var oTemplate = new sap.m.ColumnListItem();
				var oValue = new sap.m.Text();
				oValue.bindProperty("text", oBindingInfo.key);
				oTemplate.addCell(oValue);
				oValue = new sap.m.Text();
				oValue.bindProperty("text", oBindingInfo.text);
				oTemplate.addCell(oValue);

				oInput.bindAggregation("suggestionRows", {
					path: oBindingInfo.path,
					template: oTemplate,
					parameters: {
						custom: {
							webtrackingmappingview: this._getGoogleAnalyticsViewID()
						}
					}
				});
			}
		},
		onInteractionSuggestionSelected: function (oEvent) {
			var oSelectedRow = oEvent.getParameter("selectedRow");
			if (oSelectedRow && oSelectedRow.getCells().length > 0) {
				var sValue = oSelectedRow.getCells()[0].getText();
				oEvent.getSource().setValue(sValue);
			}
		},
		/**
		 * Formatter
		 **/
		enableInteractionVH: function (sMappingField) {
			if (typeof (Constants.interactionF4BindingInfo[sMappingField]) !== "undefined") {
				return true;
			} else {
				var oFieldMetadata = this._findField(sMappingField);
				if (oFieldMetadata) {
					return oFieldMetadata.type === "Edm.Boolean" || typeof (oFieldMetadata["com.sap.vocabularies.Common.v1.ValueList"]) !==
						"undefined";
				}
			}
			return false;
		},
		onBeforeRebindTableExtension: function (oEvent) {
			var oID = oEvent.getSource().getId();
			var sInteractionFieldsTableId =
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgValMapping::com.sap.vocabularies.UI.v1.LineItem::Table";
			var sContactRetrievalHeaderTableId =
				"hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--contact_main_queries_queries::Table";
			switch (oID) {
			case sInteractionFieldsTableId:
				// Attach update finished event once to avoid recursive call
				oEvent.getSource().getTable().attachEventOnce("updateFinished", function (oUpdateEvent) {
					// Sort the items to keep mandatory interaction fields on top of list
					oUpdateEvent.getSource().getBinding("items").sort([
						new sap.ui.model.Sorter("WebTrckgMappgValFldSortPos", true)
					]);
				});
				break;
			case sContactRetrievalHeaderTableId:
				oEvent.getSource().getTable().attachEvent("updateFinished", function (oUpdateEvent) {
					var oBindingContext = oUpdateEvent.getSource().getBindingContext();
					var oCountModel = oUpdateEvent.getSource().getModel("queryCount");
					oCountModel.setProperty("/to_WebTrckgRtrvlContactHdr", oUpdateEvent.getParameter("total"), oBindingContext);
				});
				break;
			}
		},
		beforeLineItemDeleteExtension: function (oBeforeLineItemDeleteProperties) {
			var oMessageText = null;
			switch (oBeforeLineItemDeleteProperties.sUiElementId) {
			case "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgValMapping::com.sap.vocabularies.UI.v1.LineItem::Table":
				oMessageText = {
					title: this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrckgValMappingTP").getResourceBundle()
						.getText("popupTitleText"),
					text: this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrckgValMappingTP").getResourceBundle()
						.getText("popupDescriptionText")
				};
				break;
			case "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgRtrvlIntactnHdr::com.sap.vocabularies.UI.v1.LineItem::Table":
				oMessageText = {
					title: this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrckgIntactnHdrTP").getResourceBundle()
						.getText("popupTitleText"),
					text: this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrckgIntactnHdrTP").getResourceBundle()
						.getText("popupDescriptionText")
				};
				break;
			case "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgRtrvlProdHdr::com.sap.vocabularies.UI.v1.LineItem::Table":
				oMessageText = {
					title: this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrckgProdHeaderTP").getResourceBundle()
						.getText("popupTitleText"),
					text: this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrckgProdHeaderTP").getResourceBundle()
						.getText("popupDescriptionText")
				};
				break;
			case "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgMappgFltr::com.sap.vocabularies.UI.v1.LineItem::Table":
				oMessageText = {
					title: this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrckgMappgFltrTP").getResourceBundle()
						.getText("popupTitleText"),
					text: this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrckgMappgFltrTP").getResourceBundle()
						.getText("popupDescriptionText")
				};
				break;
			case "hpa.cei.wtm::sap.suite.ui.generic.template.ObjectPage.view.Details::C_MKT_WebTrackingMappingTP--to_WebTrckgComMapping::com.sap.vocabularies.UI.v1.LineItem::Table":
				oMessageText = {
					title: this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrckgComMappingTP").getResourceBundle()
						.getText("popupTitleText"),
					text: this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_MKT_WebTrckgComMappingTP").getResourceBundle()
						.getText("popupDescriptionText")
				};
				break;
			}
			return oMessageText;
		},
		_enableAutobindingQueryMetricsTable: function (oMetricsTable) {
			var that = this;
			oMetricsTable.attachUpdateFinished(function (oEvent) {
				var aMetricsTableItems = oEvent.getSource().getItems();
				aMetricsTableItems.forEach(function (oMetricItem) {
					if (oMetricItem.getCells().length > 0) {
						var oMetricItemCell = oMetricItem.getCells()[0];
						var oMetricItemCellEditControl = oMetricItemCell.getEdit();
						var oInteractionFieldCell = oMetricItem.getCells()[1];
						var oInteractionFieldCellEditControl = oInteractionFieldCell.getEdit();

						if (typeof (oMetricItemCellEditControl) !== "undefined") {
							if (oMetricItemCellEditControl.getInnerControls().length > 0) {
								var oMetricItemCellEditInnerControl = oMetricItemCellEditControl.getInnerControls()[0];
								if (typeof (oMetricItemCellEditInnerControl.attachValueHelpRequest) !== "undefined") {
									oMetricItemCellEditInnerControl.attachValueHelpRequest(that._onValueHelpRequest);
								}
							}
						}

						if (typeof (oInteractionFieldCellEditControl) !== "undefined") {
							if (oInteractionFieldCellEditControl.getInnerControls().length > 0) {
								var oInteractionFieldCellEditInnerControl = oInteractionFieldCellEditControl.getInnerControls()[0];
								if (typeof (oInteractionFieldCellEditInnerControl.attachValueHelpRequest) !== "undefined") {
									oInteractionFieldCellEditInnerControl.attachValueHelpRequest(that._onValueHelpRequest);
								}
							}
						}
					}
				});
			});
		},
		_enableAutobindingQueryDimensionsTable: function (oDimensionsTable) {
			var that = this;
			oDimensionsTable.attachUpdateFinished(function (oEvent) {
				var aDimensionsTableItems = oEvent.getSource().getItems();
				aDimensionsTableItems.forEach(function (oDimensionItem) {
					if (oDimensionItem.getCells().length > 0) {
						var oDimensionItemCell = oDimensionItem.getCells()[0];
						var oDimensionItemCellEditControl = oDimensionItemCell.getEdit();
						var oInteractionFieldCell = oDimensionItem.getCells()[1];
						var oInteractionFieldCellEditControl = oInteractionFieldCell.getEdit();

						if (typeof (oDimensionItemCellEditControl) !== "undefined") {
							if (oDimensionItemCellEditControl.getInnerControls().length > 0) {
								var oDimensionItemCellEditInnerControl = oDimensionItemCellEditControl.getInnerControls()[0];
								if (typeof (oDimensionItemCellEditInnerControl.attachValueHelpRequest) !== "undefined") {
									oDimensionItemCellEditInnerControl.attachValueHelpRequest(that._onValueHelpRequest);
								}
							}
						}

						if (typeof (oInteractionFieldCellEditControl) !== "undefined") {
							if (oInteractionFieldCellEditControl.getInnerControls().length > 0) {
								var oInteractionFieldCellEditInnerControl = oInteractionFieldCellEditControl.getInnerControls()[0];
								if (typeof (oInteractionFieldCellEditInnerControl.attachValueHelpRequest) !== "undefined") {
									oInteractionFieldCellEditInnerControl.attachValueHelpRequest(that._onValueHelpRequest);
								}
							}
						}
					}
				});
			});
		},
		_enableAutobindingFiltersTable: function (oFiltersTable) {
			var that = this;
			oFiltersTable.attachUpdateFinished(function (oEvent) {
				var aFilterItems = oEvent.getSource().getItems();
				aFilterItems.forEach(function (oFilterItem) {
					if (oFilterItem.getCells().length > 0) {
						var oFilterItemCell = oFilterItem.getCells()[1];
						var oFilterItemCellEditControl = oFilterItemCell.getEdit();
						if (typeof (oFilterItemCellEditControl) !== "undefined") {
							if (oFilterItemCellEditControl.getInnerControls().length > 0) {
								var oFilterItemCellEditInnerControl = oFilterItemCellEditControl.getInnerControls()[0];
								if (typeof (oFilterItemCellEditInnerControl.attachValueHelpRequest) !== "undefined") {
									oFilterItemCellEditInnerControl.attachValueHelpRequest(that._onValueHelpRequest);
								}
							}
						}
					}
				});
			});
		},
		_enableAutobindingCommonDimensionsTable: function (oCommonDimensionsTable) {
			var that = this;
			oCommonDimensionsTable.attachUpdateFinished(function (oEvent) {
				var aDimensionItems = oEvent.getSource().getItems();
				aDimensionItems.forEach(function (oDimensionItem) {
					if (oDimensionItem.getCells().length > 0) {
						var oDimensionItemCell = oDimensionItem.getCells()[0];
						var oDimensionItemCellEditControl = oDimensionItemCell.getEdit();
						var oInteractionFieldCell = oDimensionItem.getCells()[1];
						var oInteractionFieldCellEditControl = oInteractionFieldCell.getEdit();

						if (typeof (oDimensionItemCellEditControl) !== "undefined") {
							if (oDimensionItemCellEditControl.getInnerControls().length > 0) {
								var oDimensionItemCellEditInnerControl = oDimensionItemCellEditControl.getInnerControls()[0];
								if (typeof (oDimensionItemCellEditInnerControl.attachValueHelpRequest) !== "undefined") {
									oDimensionItemCellEditInnerControl.attachValueHelpRequest(that._onValueHelpRequest);
								}
							}
						}

						if (typeof (oInteractionFieldCellEditControl) !== "undefined") {
							if (oInteractionFieldCellEditControl.getInnerControls().length > 0) {
								var oInteractionFieldCellEditInnerControl = oInteractionFieldCellEditControl.getInnerControls()[0];
								if (typeof (oInteractionFieldCellEditInnerControl.attachValueHelpRequest) !== "undefined") {
									oInteractionFieldCellEditInnerControl.attachValueHelpRequest(that._onValueHelpRequest);
								}
							}
						}
					}
				});
			});
		},
		_enableAutobindingInteractionFieldsTable: function (oInteractionFieldsTable) {
			var that = this;
			oInteractionFieldsTable.attachUpdateFinished(function (oEvent) {
				var aInteractionFields = oEvent.getSource().getItems();
				aInteractionFields.forEach(function (oInteractionField) {
					if (oInteractionField.getCells().length > 0) {
						var oInteractionFieldCell = oInteractionField.getCells()[0];
						var oInteractionFieldCellEditControl = oInteractionFieldCell.getEdit();

						if (typeof (oInteractionFieldCellEditControl) !== "undefined") {
							if (oInteractionFieldCellEditControl.getInnerControls().length > 0) {
								var oInteractionFieldCellEditInnerControl = oInteractionFieldCellEditControl.getInnerControls()[0];
								if (typeof (oInteractionFieldCellEditInnerControl.attachValueHelpRequest) !== "undefined") {
									oInteractionFieldCellEditInnerControl.attachValueHelpRequest(that._onValueHelpRequest);
								}
							}
						}
					}
				});
			});
		},
		_onValueHelpRequest: function (oEvent) {
			var oInput = oEvent.getSource();
			var bValueHelpExists = false;
			oInput.getDependents().forEach(function (oDependent) {
				if (oDependent.getMetadata().getName() === "sap.ui.comp.valuehelpdialog.ValueHelpDialog") {
					bValueHelpExists = true;
					oDependent.attachEventOnce("afterOpen", function () {
						this.getFilterBar().fireSearch();
					});
				}
			});
			if (!bValueHelpExists) {
				setTimeout(function () {
					if (oInput.getDependents().length > 0) {
						oInput.getDependents().forEach(function (oDependent) {
							if (oDependent.getMetadata().getName() === "sap.ui.comp.valuehelpdialog.ValueHelpDialog") {
								oDependent.getFilterBar().fireSearch();
							}
						});
					}
				}, 500);
			}
		},
		getInteractionFieldInputType: function (sFieldName) {
			var oField = this._findField(sFieldName);
			if (oField) {
				switch (oField.type) {
				case "Edm.Decimal":
				case "Edm.Double":
				case "Edm.Int16":
				case "Edm.Int32":
				case "Edm.Int64":
					return sap.m.InputType.Number;
				}
			}
			return sap.m.InputType.Text;
		},
		isInteractionFieldTypeString: function (sFieldName) {
			var oField = this._findField(sFieldName);
			if (oField) {
				switch (oField.type) {
				case "Edm.DateTime":
				case "Edm.DateTimeOffset":
				case "Edm.Time":
					return false;
				}
			}
			return true;
		},
		isInteractionFieldTypeDateTime: function (sFieldName) {
			var oField = this._findField(sFieldName);
			if (oField) {
				return (oField.type === "Edm.DateTime" || oField.type === "Edm.DateTimeOffset") && typeof (oField["sap:display-format"]) ===
					"undefined";
			}
			return false;
		},
		isInteractionFieldTypeDate: function (sFieldName) {
			var oField = this._findField(sFieldName);
			if (oField) {
				return oField.type === "Edm.DateTime" && oField["sap:display-format"] === "Date";
			}
			return false;
		},
		isInteractionFieldTypeTime: function (sFieldName) {
			var oField = this._findField(sFieldName);
			if (oField) {
				return oField.type === "Edm.Time";
			}
			return false;
		}
	});
});