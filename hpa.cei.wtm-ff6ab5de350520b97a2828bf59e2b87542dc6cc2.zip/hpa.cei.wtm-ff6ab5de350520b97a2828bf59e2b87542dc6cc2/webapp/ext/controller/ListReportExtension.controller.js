sap.ui.define([
	"hpa/cei/wtm/ext/util/constants"
], function (Constants) {
	sap.ui.controller("hpa.cei.wtm.ext.controller.ListReportExtension", {
		beforeDeleteExtension: function (oBeforeDeleteProperties) {
			var oTextBundle = this.getView().getModel("i18n|sap.suite.ui.generic.template.ListReport|C_MKT_WebTrackingMappingTP").getResourceBundle();
			var oMessageText = {
				title: oTextBundle.getText("queryConfigurationDeleteDialogTitle"),
				text: oTextBundle.getText("queryConfigurationDeleteDialogMsg")
			};
			return oMessageText;
		},

		onAfterRendering: function () {
			var that = this;
			var oTextBundle = that.getView().getModel("i18n|sap.suite.ui.generic.template.ListReport|C_MKT_WebTrackingMappingTP").getResourceBundle();
			var sPageURL = window.location.search.substring(1);
			// call the import function if there is a URL parameter "SAP_MKT_CLEAR_GA_CACHE"
			if (sPageURL.indexOf("sap-mkt-clear-cache") !== -1) {
				this.getView().getModel().callFunction(Constants.functionImports.refreshMetadata, {
					method: "GET",
					urlParameters: {},
					success: function (context) {
						sap.m.MessageToast.show(oTextBundle.getText("clearCacheSuccess"));
					},
					error: function (e) {
						sap.m.MessageToast.show(oTextBundle.getText("clearCacheFailed"));

					}
				});
			}
		}
	});
});