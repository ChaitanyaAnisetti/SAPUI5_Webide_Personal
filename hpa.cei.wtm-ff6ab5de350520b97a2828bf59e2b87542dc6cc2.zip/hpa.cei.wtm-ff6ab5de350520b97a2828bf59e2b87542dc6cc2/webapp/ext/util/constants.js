sap.ui.define([],
	function () {
		"use strict";
		var _constants = {
			components: {
				root: {
					name: "C_MKT_WebTrackingMappingTP",
					fields: {
						UUID: "WebTrackingMappingUUID",
						name: "WebTrackingMappingName",
						status: "WebTrackingMappingStatus",
						statusCriticality: "WebTrckgMappgStatusCriticality",
						project: "WebTrackingMappingProject",
						dataTable: "WebTrackingMappingDataTable",
						property: "WebTrackingMappingProperty",
						view: "WebTrackingMappingView",
						type: "WebTrackingMappingType",
						dataSource: "WebTrackingMappingDataSource",
						retrievalString: "WebTrackingMappingRetrievalStr",
						filterString: "WebTrackingMappingFilterString",
						commonMappingCreateIsEnabled: "WebTrckgComMappgCreateIsEnbld"
					}
				},
				query: {
					interaction: {
						header: {
							name: "C_MKT_WebTrckgIntactnHdrTP",
							fields: {
								UUID: "WebTrckgRtrvlHeaderUUID",
								type: "WebTrckgRtrvlHeaderType",
								name: "WebTrckgRtrvlHeaderName",
								metricsCount: "NmbrOfWebTrckgRtrvlMeasures",
								dimensionsCount: "NmbrOfWebTrckgRtrvlDimn",
								itemCreateIsEnabled: "WebTrackingRtrvlItmCrteIsEnbld"
							}
						},
						dimensions: {
							name: "C_MKT_WebTrckgIntactnItmTP",
							fields: {
								UUID: "WebTrckgRtrvlItemUUID",
								type: "WebTrckgMappingFieldType",
								externalField: "WebTrckgMappgExternalField",
								internalField: "WebTrckgMappingInternalField",
								property: "WebTrackingMappingProperty"
							}
						},
						metrics: {
							name: "C_MKT_WebTrckgIntactnMsrTP",
							fields: {
								UUID: "WebTrckgRtrvlItemUUID",
								type: "WebTrckgMappingFieldType",
								externalField: "WebTrckgMappgExternalField",
								internalField: "WebTrckgMappingInternalField",
								property: "WebTrackingMappingProperty"
							}
						}
					},
					product: {
						header: {
							name: "C_MKT_WebTrckgProdHeaderTP",
							fields: {
								UUID: "WebTrckgRtrvlHeaderUUID",
								type: "WebTrckgRtrvlHeaderType",
								name: "WebTrckgRtrvlHeaderName",
								metricsCount: "NmbrOfWebTrckgRtrvlMeasures",
								dimensionsCount: "NmbrOfWebTrckgRtrvlDimn",
								itemCreateIsEnabled: "WebTrackingRtrvlItmCrteIsEnbld"
							}
						},
						dimensions: {
							name: "C_MKT_WebTrckgProdItemTP",
							fields: {
								UUID: "WebTrckgRtrvlItemUUID",
								type: "WebTrckgMappingFieldType",
								externalField: "WebTrckgMappgExternalField",
								internalField: "WebTrckgMappingInternalField",
								property: "WebTrackingMappingProperty"
							}
						},
						metrics: {
							name: "C_MKT_WebTrckgProdMsrTP",
							fields: {
								UUID: "WebTrckgRtrvlItemUUID",
								type: "WebTrckgMappingFieldType",
								externalField: "WebTrckgMappgExternalField",
								internalField: "WebTrckgMappingInternalField",
								property: "WebTrackingMappingProperty"
							}
						}
					},
					tag: {
						header: {
							name: "C_MKT_WebTrackingTagHeaderTP",
							fields: {
								UUID: "WebTrckgRtrvlHeaderUUID",
								type: "WebTrckgRtrvlHeaderType",
								name: "WebTrckgRtrvlHeaderName",
								metricsCount: "NmbrOfWebTrckgRtrvlMeasures",
								dimensionsCount: "NmbrOfWebTrckgRtrvlDimn",
								itemCreateIsEnabled: "WebTrackingRtrvlItmCrteIsEnbld"
							}
						},
						dimensions: {
							name: "C_MKT_WebTrackingTagItemTP",
							fields: {
								UUID: "WebTrckgRtrvlItemUUID",
								type: "WebTrckgMappingFieldType",
								externalField: "WebTrckgMappgExternalField",
								internalField: "WebTrckgMappingInternalField",
								property: "WebTrackingMappingProperty"
							}
						},
						metrics: {
							name: "C_MKT_WebTrackingTagMeasureTP",
							fields: {
								UUID: "WebTrckgRtrvlItemUUID",
								type: "WebTrckgMappingFieldType",
								externalField: "WebTrckgMappgExternalField",
								internalField: "WebTrckgMappingInternalField",
								property: "WebTrackingMappingProperty"
							}
						}
					},
					contact: {
						header: {
							name: "C_MKT_WebTrckgContactHeaderTP",
							fields: {
								UUID: "WebTrckgRtrvlItemUUID",
								type: "WebTrckgMappingFieldType",
								externalField: "WebTrckgMappgExternalField",
								internalField: "WebTrckgMappingInternalField",
								property: "WebTrackingMappingProperty"
							}
						},
						dimensions: {
							name: "C_MKT_WebTrckgContactItemTP",
							fields: {
								UUID: "WebTrckgRtrvlItemUUID",
								type: "WebTrckgMappingFieldType",
								externalField: "WebTrckgMappgExternalField",
								internalField: "WebTrckgMappingInternalField",
								property: "WebTrackingMappingProperty"
							}
						},
						metrics: {
							name: "C_MKT_WebTrckgContactMeasureTP",
							fields: {
								UUID: "WebTrckgRtrvlItemUUID",
								type: "WebTrckgMappingFieldType",
								externalField: "WebTrckgMappgExternalField",
								internalField: "WebTrckgMappingInternalField",
								property: "WebTrackingMappingProperty"
							}
						}
					}
				}
			},
			functionImports: {
				clearFilters: "/C_MKT_WebTrackingMappingTPClear_filter",
				copy: "/C_MKT_WebTrackingMappingTPCopy",
				deactivate: "/C_MKT_WebTrackingMappingTPDeactivate",
				validate: "/C_MKT_WebTrackingMappingTPValidate",
				refreshMetadata: "/C_MKT_WebTrackingMapping_RefreshGA"
			},
			fieldType: {
				dimension: "D",
				metric: "M"
			},
			dataSource: {
				googleAnalytics: "A",
				googleBigQuery: "B"
			},
			filterType: {
				basic: "B",
				expert: "E"
			},
			webTrackingMappingType: {
				createInteractions: "I",
				matchAndMergeContacts: "C"
			},
			editorThemes: {
				"sap_belize_hcb": {
					theme: "tomorrow_night_bright"
				},
				"sap_fiori_3_dark": {
					theme: "tomorrow_night"
				},
				"default": {
					theme: "default"
				}
			},
			interactionF4BindingInfo: {
				"InteractionType": {
					path: "/I_MKT_InteractionType",
					key: "InteractionType",
					text: "InteractionType_Text"
				},
				"CommunicationMedium": {
					path: "/I_MKT_CommMedium",
					key: "CommunicationMedium",
					text: "CommunicationMedium_Text"
				},
				"InteractionContactOrigin": {
					path: "/I_MKT_Contactorigin",
					key: "InteractionContactOrigin",
					text: "InteractionContactOrigin_Text"
				},
				"InteractionContactAdditionalOrigin": {
					path: "/I_MKT_Contactorigin",
					key: "InteractionContactOrigin",
					text: "InteractionContactOrigin_Text"
				},
				"MarketingArea": {
					path: "/I_MKT_ActiveMarketingArea",
					key: "MarketingArea",
					text: "MarketingArea_Text"
				},
				"ProductOrigin": {
					path: "/I_MKT_ProductOrigin",
					key: "ProductOrigin",
					text: "ProductOrigin_Text"
				},
				"DeviceType": {
					path: "/I_MKT_DeviceType",
					key: "DeviceType",
					text: "DeviceType_Text"
				},
				"InteractionCurrency": {
					path: "/I_Currency",
					key: "Currency",
					text: "Currency_Text"
				},
				"InteractionLanguage": {
					path: "/I_Language",
					key: "Language",
					text: "Language_Text"
				},
				"MKT_AgreementOrigin": {
					path: "/I_MKT_AgreementOrigin",
					key: "MKT_AgreementOrigin",
					text: "MKT_AgreementOrigin_Text"
				},
				"DigitalAccountType": {
					path: "/I_MKT_DigitalAccountType",
					key: "DigitalAccountType",
					text: "DigitalAccountType_Text"
				},
				"InteractionReason": {
					path: "/I_MKT_InteractionReason",
					key: "InteractionReason",
					text: "InteractionReason_Text"
				},
				"InteractionSentimentValue": {
					path: "/I_MKT_InteractionSentiment",
					key: "InteractionSentiment",
					text: "InteractionSentiment_Text"
				},
				"InteractionStatus": {
					path: "/I_MKT_InteractionStatus",
					key: "InteractionStatus",
					text: "InteractionStatus_Text"
				},
				"MarketingLocationOrigin": {
					path: "/I_MKT_LocationOrigin",
					key: "MarketingLocationOrigin",
					text: "MarketingLocationOrigin_Text"
				},
				"InteractionProductUnit": {
					path: "/I_UnitOfMeasure",
					key: "UnitOfMeasure",
					text: "UnitOfMeasure_Text"
				},
				"InteractionProductStatus": {
					path: "/I_MKT_InteractionProductStatus",
					key: "InteractionProductStatus",
					text: "InteractionProductStatus_Text"
				},
				"InteractionIsAnonymous": {
					path: "boolModel>/items",
					key: "key",
					text: "text",
					columns: [{
						template: "boolModel>key",
						label: ""
					}, {
						template: "boolModel>text",
						label: ""
					}]
				},
				booleanModel: {
					path: "boolModel>/items",
					key: "key",
					text: "text",
					columns: [{
						template: "boolModel>key",
						label: ""
					}, {
						template: "boolModel>text",
						label: ""
					}]
				}
			}
		};
		return _constants;
	});