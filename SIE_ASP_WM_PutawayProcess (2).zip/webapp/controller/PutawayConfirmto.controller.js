sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageBox',
	'sap/m/MessagePopover',
	'sap/m/MessageItem',
	"sap/ui/model/json/JSONModel"
], function (Controller, MessageBox, MessagePopover, MessageItem, JSONModel) {
	"use strict";

	return Controller.extend("putaway.SIE_ASP_WM_PutawayProcess.controller.PutawayConfirmto", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf putaway.SIE_ASP_WM_PutawayProcess.view.PutawayConfirmto
		 */
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oFioriClient = this.getOwnerComponent().getFioriClient();
			oRouter.getRoute("PutawayConfirmto").attachPatternMatched(this._onObjectMatched, this);
			this.oBusyDialog = new sap.m.BusyDialog();
		},
		_onObjectMatched: function (oEvent) {
			if (oEvent.getParameter("arguments").WarehouseNo && oEvent.getParameter("arguments").Matdoc) {
				var WarehouseNo = oEvent.getParameter("arguments").WarehouseNo || "";
				var Matdoc = oEvent.getParameter("arguments").Matdoc || "";
				var Matyear = oEvent.getParameter("arguments").Matyear || "";
				var Material = oEvent.getParameter("arguments").Material || "";
				var TOitem = oEvent.getParameter("arguments").TOitem || "";
				var TOno = oEvent.getParameter("arguments").TOno || "";
				this.oBusyDialog.open();
				var oBindingInfo = {
					success: function (oData, oResponse) {
						this.oBusyDialog.close();
						this.getOwnerComponent().getModel("localModel").setProperty("/PutawayMaterialProcess", oData);
					}.bind(this),
					error: function (oError) {
						this.oBusyDialog.close();
						this.getOwnerComponent().getModel("localModel").setProperty("/PutawayMaterialProcess", "");
					}.bind(this)
				};
 
				this.getOwnerComponent().getModel("ASP_WM_PUTAWAY").read("/Putaway_detailsSet(WarehouseNo='" + WarehouseNo +
					"',TOno='" + TOno + "',TOitem='" + TOitem + "')", oBindingInfo);

			}
		},
		onPressback: function () {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Putawaymain", {

			});
		},

		onConfirmTO: function () {

			var oPayload = {

				"UserGID": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/UserGID"),
				"MatDesc": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/MatDesc"),
				"Material": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/Material"),
				"MsgDesc": "",
				"MsgType1": "",
				"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/Plant"),
				"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/Sloc"),
				"Qty": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/Qty"),
				"QtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/QtyUOM"),
				"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/Stockcat"),
				"SpecialStoc": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/SpecialStoc"),
				"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/StorageBin"),
				"StorageBindes": this.getView().byId("oConfirmbin").getValue(),
				"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/WarehouseNo"),
				"TOno": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/TOno"),
				"TOitem": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/TOitem"),
				"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/Batchno")

			};
			this.oBusyDialog.open();
			var that = this;

			this.getOwnerComponent().getModel("ASP_WM_PUTAWAY").create("/Putaway_detailsSet", oPayload, {
				success: function (oData, oResponse) {

					if (oData.MsgType1 === "S" || oData.MsgType1 === "") {

						that.oBusyDialog.close();
						sap.m.MessageBox.success(oData.MsgDesc, {

							actions: ["Putaway Process", "Back to Main Menu"],
							title: "Putaway Process",
							onClose: function (oAction) {

								if (oAction === "Putaway Process") {

									that.onPressback();

								} else {
									that.onBackmainmenu();
								}

							}

						});
					} else {

						that.oBusyDialog.close();
						sap.m.MessageBox.show(
							oData.MsgDesc, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Error",
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);
					}
				},
				error: function (oError) {
					that.oBusyDialog.close();
				}
			});

		},

		onBackmainmenu: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Putawaymain", {

			});

		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf putaway.SIE_ASP_WM_PutawayProcess.view.PutawayConfirmto
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf putaway.SIE_ASP_WM_PutawayProcess.view.PutawayConfirmto
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf putaway.SIE_ASP_WM_PutawayProcess.view.PutawayConfirmto
		 */
		//	onExit: function() {
		//
		//	}

	});

});