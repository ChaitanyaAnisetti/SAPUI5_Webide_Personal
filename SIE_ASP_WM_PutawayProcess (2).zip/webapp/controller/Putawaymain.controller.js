sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageBox',
	'sap/m/MessagePopover',
	'sap/m/MessageItem',
	"sap/ui/model/json/JSONModel",
	"sap/ndc/BarcodeScanner"
], function (Controller, MessageBox, MessagePopover, MessageItem, JSONModel,BarcodeScanner) {
	"use strict";

	return Controller.extend("putaway.SIE_ASP_WM_PutawayProcess.controller.Putawaymain", {
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oFioriClient = this.getOwnerComponent().getFioriClient();
			oRouter.getRoute("Putawaymain").attachPatternMatched(this._onObjectMatched, this);
			this.oBusyDialog = new sap.m.BusyDialog();
			var Gid = sap.ushell.Container.getService("UserInfo").getId();
		//	var Gid = "Z004C4CT";
			var path1 = "/UserDefaultSet('" + Gid + "')";
			this.oBusyDialog.open();
			this.getOwnerComponent().getModel("ASP_WM_PUTAWAY").read(path1, {
				success: function (oData, oResponse) {
					
					if (oData.MsgType === "S") {
					    this.WarehouseNo = oData.WarehouseNo;
						this.getOwnerComponent().getModel("localModel").setProperty("/LoginUserInfo", oData);
						this.oBusyDialog.close();
					} else {
						this.oBusyDialog.close();
						sap.m.MessageBox.show(
							oData.MsgDesc, {
								icon: sap.m.MessageBox.Icon.ERROR,
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);
					}
				}.bind(this),
				error: function (err) {
					this.oBusyDialog.close();
					sap.m.MessageBox.show(
						"OData error in UserDefaultSet", {
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.CLOSE],
							onClose: function (oAction) {}
						}
					);

				}.bind(this)
			});
			
			
			
		},
		_onObjectMatched: function () {
			var Matyear = new Date().getFullYear();
			
			if (this.getOwnerComponent().getComponentData() && this.getOwnerComponent().getComponentData().startupParameters) {
				var startupParams = this.getOwnerComponent().getComponentData().startupParameters;
				//startupParams.Gid&&
				if (startupParams.MatYear && startupParams.MaterialNo && startupParams.WarehouseNo) {
					var WarehouseNo = startupParams.WarehouseNo[0];
					var Matyear = startupParams.MatYear[0];
					var oMatNo = startupParams.MaterialNo[0];
					var oMatItem = startupParams.MatItem[0];
					this.getView().byId("oMatenoinput").setValue(oMatNo);
					this.getView().byId("oMateIteminput").setValue(oMatItem);
					this._getMatDetail(WarehouseNo, Matyear, oMatNo, oMatItem);
				}
			}
		},
		onMatDetailChange: function () {
		//	var WarehouseNo = "A04";
		//		var WarehouseNo;
	
		var Matyear = new Date().getFullYear();
	
	        var WarehouseNo =  this.WarehouseNo; 
			var oMatNo = this.getView().byId("oMatenoinput").getValue();
			var oMatItem = this.getView().byId("oMateIteminput").getValue();
			this._getMatDetail(WarehouseNo, Matyear, oMatNo, oMatItem);
		},
		_getMatDetail: function (WarehouseNo, Matyear, oMatNo, oMatItem) {
			if (oMatNo === "" || oMatItem === "") {
				sap.m.MessageBox.show(
					"Please enter required values", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.CLOSE],
						onClose: function (oAction) {}

					}
				);
				var oPutawayMatModel = new JSONModel([]);
				this.getView().setModel(oPutawayMatModel, "oPutawayMatModel");
			} else {
				if (oMatNo && oMatItem) {
					this.oBusyDialog.open();
					
					var sTr = "WarehouseNo eq '" + WarehouseNo + "'and  Matdoc eq '" + oMatNo + "'and Matyear eq '" + Matyear +
						"'and Matitem eq '" + oMatItem + "'";
					var oBindingInfo = {
						filters: null,
						urlParameters: {
							"$filter": sTr
						},
						success: function (oData, oResponse) {
							this.oBusyDialog.close();

							if (oResponse.data.results[0].MsgType1 === "S" || oResponse.data.results[0].MsgType1 === "") {
								var oPutawayMatModel = new JSONModel(oData.results);
								this.getView().setModel(oPutawayMatModel, "oPutawayMatModel");
							} else {
								var oPutawayMatModel = new JSONModel([]);
								this.getView().setModel(oPutawayMatModel, "oPutawayMatModel");
								sap.m.MessageBox.show(
									oResponse.data.results[0].MsgDesc, {
										icon: sap.m.MessageBox.Icon.ERROR,
										actions: [sap.m.MessageBox.Action.CLOSE],
										onClose: function (oAction) {

										}

									}
								);
							}
						}.bind(this),
						error: function (oError) {
							
							this.oBusyDialog.close();
							sap.m.MessageBox.error("Error");
						}.bind(this)
					};

					this.getOwnerComponent().getModel("ASP_WM_PUTAWAY").read("/Putaway_listSet", oBindingInfo);
				}
			}
		},
		onBarCodeScan: function () {

			if (cordova&&cordova.plugins&&cordova.plugins.barcodeScanner) {
              var that=this;
				cordova.plugins.barcodeScanner.scan(function (format) {
					var data = format;
				var Matyear = data.text.split("|")[0];
					var Matdocno = data.text.split("|")[1];
					var Matitem = data.text.split("|")[2];
					//	var WarehouseNo = "A04";
					var WarehouseNo = that.WarehouseNo; 
				 that.getView().byId("oMatenoinput").setValue(Matdocno);
				 that.getView().byId("oMateIteminput").setValue(Matitem);
				that._getMatDetail(WarehouseNo, Matyear, Matdocno, Matitem);
				
				}, function (error) {
					var a = error;
				}, {
					formats: "QR_CODE,PDF_417"
				});
			}
				else{
			sap.ndc.BarcodeScanner.scan(
				this.onSuccess.bind(this),
				this.onError.bind(this),
				{
					formats: "QR_CODE,PDF_417"	
				}
			);
				}
		},
		// onSuccess Callback 
		onSuccess: function (result) {
			var bCancelled = result.cancelled;
			this.getView().byId("oMatenoinput").setValue("");
			this.getView().byId("oMateIteminput").setValue("");
			if (result.text && bCancelled == false) {
			//	var WarehouseNo = "A04";
				var WarehouseNo = this.WarehouseNo;
				 var Matyear = result.text.split("|")[0];
					var Matdocno = result.text.split("|")[1];
					var Matitem = result.text.split("|")[2];
				 this.getView().byId("oMatenoinput").setValue(Matdocno);
				 this.getView().byId("oMateIteminput").setValue(Matitem);
				this._getMatDetail(WarehouseNo, Matyear, Matdocno, Matitem);
			} else if (bCancelled) {
				sap.m.MessageToast.show("Scan Cancelled");
			}

		},

		// onError Callback
		onError: function (error) {
			sap.m.MessageToast.show(error, "Error");
		},
		onConfirmationActionPress: function (oEvent) {
			var oSelectedObject = oEvent.getSource().getParent().getBindingContext("oPutawayMatModel").getObject();

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("PutawayConfirmto", {
				Material: oSelectedObject.Material,
				WarehouseNo: oSelectedObject.WarehouseNo,
				Matdoc: oSelectedObject.Matdoc,
				Matyear: oSelectedObject.Matyear,
				TOitem: oSelectedObject.TOitem,
				TOno: oSelectedObject.TOno

			});

		}
	});
});