sap.ui.define(function () {

	var Formatter = {

		SubWbs: function (SubWbs) {

			if (SubWbs != undefined || SubWbs != null) {

				return ("Billed Hrs.exc. approval for WBS"+" "+SubWbs);

			} else {
				return "";
			}
		}

	};
	return Formatter;
}, true);