sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"KB31NApp/YKB31NApprovals/model/models"
], function (UIComponent, JSONModel, Device, models) {
	"use strict";

	return UIComponent.extend("KB31NApp.YKB31NApprovals.Component", {

		metadata: {
			manifest: "json"
		},
		

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
		    // call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();
			var oLocalSet = new JSONModel();
			oLocalSet.setSizeLimit(100000);
			this.setModel(oLocalSet, "localModel");

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		}
	});
});