sap.ui.define([
	"KB31NApp/YKB31NApprovals/test/unit/controller/View1.controller"
], function () {
	"use strict";
});