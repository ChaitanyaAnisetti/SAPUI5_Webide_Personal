sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"KB31NApp/YKB31NApprovals/Formatter/formatter",
	"sap/m/MessageBox",
	"sap/m/Dialog",
	"sap/ui/Device",
	"sap/ui/model/Filter",
	"sap/base/Log",
	"KB31NApp/YKB31NApprovals/model/models"
], function (Controller, JSONModel, formatter, MessageBox, Dialog, Device, Filter, Log, model) {
	"use strict";

	return Controller.extend("KB31NApp.YKB31NApprovals.controller.View1", {
		onInit: function () {

			var oDeviceModel = new JSONModel(Device);
			oDeviceModel.setDefaultBindingMode("OneWay");
			this.getView().setModel(oDeviceModel, "device");

			this._onItemsload();
		},

		handleRefresh: function () {

			setTimeout(function () {
				this.getView().byId("pullToRefresh").hide();
				this._onItemsload();
			}.bind(this), 100);

		},

		_onItemsload: function () {

			//	/KB31N_ApproveSet(YearId='2021',MonthId='04',SubWbs='CP-21-00035.2',Item='003')
			//    sap.ui.getCore().byId("oidex").setValue("");
			//  this.oBusyDialog = new sap.m.BusyDialog();
			//*************login user getting from Fiori lanchpad**************//
			/*	var Gid = sap.ushell.Container.getService("UserInfo").getId();*/
			var path1 = "/KB31N_ApproveSet";
			//  this.oBusyDialog.open();
		

			this.getOwnerComponent().getModel("ZPS_KB31N_APP").read(path1, {
				success: function (oData, oResponse) {

					var oWbsModel = oData.results;

					var oWbsModel = new sap.ui.model.json.JSONModel(oWbsModel);
					this.getView().byId("oWbsListItems").setModel(oWbsModel, "oWbsModel");
					//	this.getView().byId("oWbsListItems");
					var ootabl1 = this.getView().byId("oWbsListItems").getModel("oWbsModel").oData;
					this.getView().byId("ooid").setTitle("Items(" + "" + ootabl1.length + "" + ")");
					/*this.getOwnerComponent().getModel("localModel").setProperty("/YKB31Nlocalmodel", oData.results);*/
					//  this.oBusyDialog.close();

				}.bind(this),
				error: function (err) {
					//  this.oBusyDialog.close();
					sap.m.MessageBox.show(
						"OData error", {
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.CLOSE],
							onClose: function (oAction) {}
						}
					);

				}.bind(this)
			});

		},
		onSearch: function (oEvt) {

			var that = this;
			var ootabl1 = that.getView().byId("oWbsListItems").getModel("oWbsModel").oData;
			that.getView().byId("ooid").setTitle("Items(" + "" + ootabl1.length + "" + ")");

			var aFilters = [];
			var sQuery = oEvt.getSource().getValue();
			if (sQuery && sQuery.length > 0) {

				var filter = ([new sap.ui.model.Filter([
					new sap.ui.model.Filter("SubWbs", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("Item", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("MonthId", sap.ui.model.FilterOperator.Contains, sQuery)

					/*	new sap.ui.model.Filter("PrApprovedStatus", sap.ui.model.FilterOperator.Contains, sQuery)*/
				], false)]);
				aFilters.push(filter);

			}

			var list = this.getView().byId("oWbsListItems");
			var binding = list.getBinding("items");
			binding.filter(aFilters, "Application");

		},

		onPressGo: function (oEvt) {
			// sap.ui.getCore().byId("oidex").setValue("");
			var Type = model.createDeviceModel();
			if (Type.getProperty("/system/phone")) {
				this.getSplitContObj().toDetail(this.createId("detail"));
			}
			/*	else{
						this.getSplitContObj().setMode("ShowHideMode");
				}*/
			var oSubWbs = oEvt.getSource().getBindingContext("oWbsModel").getProperty("SubWbs");
			var oMonthid = oEvt.getSource().getBindingContext("oWbsModel").getProperty("MonthId");
			var oItem = oEvt.getSource().getBindingContext("oWbsModel").getProperty("Item");

			var oDatamodel2 = this.getView().byId("oWbsListItems").getModel("oWbsModel").getData();

			this.oMod = oDatamodel2.filter(function (x) {
				return x.SubWbs === oSubWbs && x.Item === oItem && x.MonthId === oMonthid;
			});

			this.getView().byId("oFinyear").setText(this.oMod[0].YearId);
			this.getView().byId("oActualHrs").setText(this.oMod[0].ActualHrs);
			this.getView().byId("oSbWbs").setText(this.oMod[0].SubWbs);
			//		this.getView().byId("oPeriod").setText(this.oMod[0].MonthId);

			if (this.oMod[0].MonthId == "01") {
				this.getView().byId("oPeriod").setText("01 (April)");
			} else if (this.oMod[0].MonthId == "02") {
				this.getView().byId("oPeriod").setText("02 (May)");
			} else if (this.oMod[0].MonthId == "03") {
				this.getView().byId("oPeriod").setText("03 (June)");
			} else if (this.oMod[0].MonthId == "04") {
				this.getView().byId("oPeriod").setText("04 (July)");
			} else if (this.oMod[0].MonthId == "05") {
				this.getView().byId("oPeriod").setText("05 (August)");
			} else if (this.oMod[0].MonthId == "06") {
				this.getView().byId("oPeriod").setText("06 (September)");
			} else if (this.oMod[0].MonthId == "07") {
				this.getView().byId("oPeriod").setText("07 (October)");
			} else if (this.oMod[0].MonthId == "08") {
				this.getView().byId("oPeriod").setText("08 (November)");
			} else if (this.oMod[0].MonthId == "09") {
				this.getView().byId("oPeriod").setText("09 (December)");
			} else if (this.oMod[0].MonthId == "10") {
				this.getView().byId("oPeriod").setText("10 (January)");
			} else if (this.oMod[0].MonthId == "11") {
				this.getView().byId("oPeriod").setText("11 (February)");
			} else if (this.oMod[0].MonthId == "12") {
				this.getView().byId("oPeriod").setText("12 (March)");
			}

			this.getView().byId("oTimsheet").setText(this.oMod[0].TsHrs);
			this.getView().byId("oProjectCode").setText(this.oMod[0].L2Wbs);
			this.getView().byId("oExceptioncode").setText(this.oMod[0].ExcCtgy);
			this.getView().byId("oReason").setText(this.oMod[0].Reason);
			this.getView().byId("oBillingWBS").setText(this.oMod[0].SubWbs);
			this.getView().byId("oCrtdon").setText(this.oMod[0].Erdat);
			this.getView().byId("oCrtdby").setText(this.oMod[0].Ernam);
			this.getView().byId("oProjdec").setText(this.oMod[0].L2Name);
			this.getView().byId("oSWbsitem").setText(this.oMod[0].Item);
			this.getView().byId("oCustomerGroup").setText(this.oMod[0].Bran1);

			this.getView().byId("oCumcode").setText(this.oMod[0].CumuHrs);

			this.Item = this.oMod[0].Item;
			this.L2Name = this.oMod[0].L2Name;
			this.CumuHrs = this.oMod[0].CumuHrs;
			this.AppBy = this.oMod[0].AppBy;
			this.AppComm = this.oMod[0].AppComm;
			this.AppName = this.oMod[0].AppName;
			this.AppStatus = this.oMod[0].AppStatus;
			this.AppTime = this.oMod[0].AppTime;
			this.Approver = this.oMod[0].Approver;
			this.Bran1 = this.oMod[0].Bran1;

			var oDateFormatA = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyy-MM-ddT00:00:00"
			});
			this.DatevalueAppDate = oDateFormatA.format(new Date());

			if (this.oMod[0].Erdat !== null) {
				var oDateFormatB = sap.ui.core.format.DateFormat.getDateTimeInstance({
					//	pattern: "yyyy-MM-ddT00:00:00"
					pattern: "dd-MM-yyyy"
				});
				this.DatevalueErDate = oDateFormatB.format(new Date(this.oMod[0].Erdat));
				this.getView().byId("oCrtdon").setText(this.DatevalueErDate);
				//	return DatevalueA;
			} else {

				var oDateFormatX = sap.ui.core.format.DateFormat.getDateTimeInstance({
					//pattern: "yyyy-MM-ddT00:00:00"
					pattern: "dd-MM-yyyy"
				});
				this.DatevalueErDate = oDateFormatX.format(new Date());

				this.getView().byId("oCrtdon").setText(this.DatevalueErDate);

			}

		},
		onPressApprove: function () {
			var that = this;
			var _odialog = new sap.m.Dialog({
				id: 'Oidd',
				title: 'Add comments',
				type: 'Message',

				state: 'Information',

				content: new sap.m.TextArea({
					value: '',
					id: 'oidex',
					width: '100%',
					height: '130%',
					maxLength: 100,

					liveChange: function (oEvent) {
						var oTextArea = oEvent.getSource(),
							iValueLength = oTextArea.getValue().length,
							iMaxLength = 100,
							sState = iValueLength > iMaxLength ? "Error" : "None";

						oTextArea.setValueState(sState);

					},

					valueLiveUpdate: true,
					showExceededText: true
				}),
				beginButton: new sap.m.Button({
					text: 'Submit',
					press: function (oEvt) {

						that._fnSubmit();
						_odialog.destroy(true);
						_odialog = undefined;

					}

				}),
				endButton: new sap.m.Button({
					text: 'Cancel',
					press: function () {
						_odialog.close();
						_odialog.destroy(true);
						_odialog = undefined;

					}
				})
			});
			_odialog.open();

		},
		_fnSubmit: function () {
			if (this.getView().byId("oSbWbs").getText() === "") {
				sap.m.MessageBox("Please select WBS item from the list");
			} else {

				//	var zErDate = this.getView().byId("oCrtdon").getText();
				var oDateFormatX = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyy-MM-ddT00:00:00"

				});
				this.oDatevalueErDate = oDateFormatX.format(new Date());

				this.getOwnerComponent().getModel("ZPS_KB31N_APP").setHeaders({
					"Content-Type": "application/json",
					"X-Requested-With": "XMLHttpRequest",
					"X-CSRF-Token": "Fetch",
					"DataServiceVersion": "2.0",
					"Accept": "application/json",
					"Method": "PUT"
				});

				var oPayload = {
					YearId: this.getView().byId("oFinyear").getText(),
					MonthId: this.getView().byId("oPeriod").getText().split(" ")[0],
					SubWbs: this.getView().byId("oBillingWBS").getText(),
					Item: this.Item,
					ActualHrs: this.getView().byId("oActualHrs").getText(),
					L2Wbs: this.getView().byId("oProjectCode").getText(),
					TsHrs: this.getView().byId("oTimsheet").getText(),
					CumuHrs: this.CumuHrs,
					ExcCtgy: this.getView().byId("oExceptioncode").getText(),
					Reason: this.getView().byId("oReason").getText(),
					Erdat: this.oDatevalueErDate,
					Ernam: this.getView().byId("oCrtdby").getText(),
					L2Name: this.getView().byId("oProjdec").getText(),
					Bran1: this.Bran1,
					AppStatus: this.AppStatus,
					Approver: this.Approver,
					AppName: this.AppName,
					AppComm: sap.ui.getCore().byId("oidex").getValue(),
					AppBy: this.AppBy,
					AppTime: this.AppTime,
					AppDate: this.DatevalueAppDate

				};

				//  this.oBusyDialog.open();
				var that = this;

				var YearId = that.getView().byId("oFinyear").getText();
				var MonthId = this.getView().byId("oPeriod").getText().split(" ")[0];
				this.SubWbs = this.getView().byId("oBillingWBS").getText();
				//	_ApproveSet(YearId='2021',MonthId='02',SubWbs='CP-20-08019.1AB326',Item='001')

				this.getOwnerComponent().getModel("ZPS_KB31N_APP").update("/KB31N_ApproveSet(YearId='" + YearId + "',MonthId='" + MonthId +
					"',SubWbs='" + this.SubWbs + "',Item='" + this.Item + "')",
					oPayload, {
						success: function (oData, oResponse) {

							//	that.oBusyDialog.close();

							/*	sap.m.MessageBox.success(that.getView().byId("oSbWbs").getText() + " " + "Updated successfully!");*/
							sap.m.MessageBox.success("WBS" + " " + that.getView().byId("oSbWbs").getText() + " " + "-" + " " + this.Item + " " +
								"Updated successfully!", {

									actions: ["OK"],
									title: "Success",
									onClose: function (oAction) {

										if (oAction === "OK") {
											that.getView().byId("oSbWbs").setText("");
											that.getView().byId("oProjdec").setText("");
											that.getView().byId("oCrtdon").setText("");
											that.getView().byId("oCrtdby").setText("");
											that.getView().byId("oFinyear").setText("");
											that.getView().byId("oPeriod").setText("");
											that.getView().byId("oBillingWBS").setText("");
											that.getView().byId("oActualHrs").setText("");
											that.getView().byId("oProjectCode").setText("");
											that.getView().byId("oCustomerGroup").setText("");
											that.getView().byId("oTimsheet").setText("");
											that.getView().byId("oCumcode").setText("");
											that.getView().byId("oExceptioncode").setText("");
											that.getView().byId("oReason").setText("");
											that.getView().byId("oProjdec").setText("");
											that.getView().byId("oSWbsitem").setText("");
											that.getView().byId("oCustomerGroup").setText("");
											//	this.getView().byId("oCumcode").setText("");

											//	that._onItemsload();
											var z = that.getView().byId("oWbsListItems").getModel("oWbsModel").getData();
											for (var i = z.length - 1; i >= 0; i--) {
												if (z[i].SubWbs === that.SubWbs && z[i].Item === that.Item) {
													z.splice(i, 1);
												}
											}
											var oModel = that.getView().byId("oWbsListItems").getModel("oWbsModel");

											oModel.refresh(true);
											that.getView().byId("ooid").setTitle("Items(" + "" + oModel.oData.length + "" + ")");

										} else {
											//
										}

									}

								});

						}.bind(this),
						error: function (error) {
							////	that.oBusyDialog.close();
							sap.m.MessageBox.error(error.message);

						}.bind(this)
					});

			}
		},
		onPressDetailBack: function () {
			this.getSplitContObj().backDetail();
		},
		getSplitContObj: function () {
			var result = this.byId("SplitContDemo");
			if (!result) {
				Log.error("SplitApp object can't be found");
			}
			return result;
		},
		onAfterRendering: function () {
			var oSplitCont = this.getSplitContObj(),
				ref = oSplitCont.getDomRef() && oSplitCont.getDomRef().parentNode;
			// set all parent elements to 100% height, this should be done by app developer, but just in case
			if (ref && !ref._sapUI5HeightFixed) {
				ref._sapUI5HeightFixed = true;
				while (ref && ref !== document.documentElement) {
					var $ref = jQuery(ref);
					if ($ref.attr("data-sap-ui-root-content")) { // Shell as parent does this already
						break;
					}
					if (!ref.style.height) {
						ref.style.height = "100%";
					}
					ref = ref.parentNode;
				}
			}
		},

	});
});