'use strict';

sap.ui.require([
  'test/unit/ODataModelPromise'
], function() {
});
