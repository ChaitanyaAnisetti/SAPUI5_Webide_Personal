# Code of Conduct

This project is governed by the [Contributor Covenant version 2.1](https://www.contributor-covenant.org/version/2/1/code_of_conduct/). All contributors and participants agree to abide by its terms.
