# openui5-model-odata-v2-odatamodelpromise

An OpenUI5 library which extends sap.ui.model.odata.v2.ODataModel to support Promises
