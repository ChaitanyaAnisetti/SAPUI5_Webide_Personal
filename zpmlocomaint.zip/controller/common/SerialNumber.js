/*&---------------------------------------------------------------------*    
 * Author         : SAP Custom Development                               *
 * Date           : 2017.12.29                                           *
 * Project        : Locomotive Maintenance                               *
 * Description    : Controller for the serial number dialog.             *
 *                  Hook methods of view life cycle can be implemented   *
 *                  for fragment life cycle.                             *
 *&----------------------------------------------------------------------*/
/*&---------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2020.09.08                                           *
 * Project        : EAM-ASR3415776                                       *
 * Description    : Revised logic for equipment hierarchy  .             *
 *&----------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 13-Oct-2021	                                       *
* Project             : LLM3.2 - Revison Number        					   *
* Description         : ERQ Serial Number and SW Revision number		   *
* Search Term         : LLM3.2	                                           *
/*&------------------------------------------------------------------------*/
/*&------------------------------------------------------------------------* 
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 25-Nov-2021	                                       *
* Project             : EAM-LLM 1.2 Serialization     					   *
* Description         : Serialization of material and equipment			   *
* Search Term         : LLM1.2	                                           *
/*&------------------------------------------------------------------------*/
// #DontDelete : Daya new controller class , dont delete any method inthis file

sap.ui.define([
		"com/sap/cp/lm/controller/common/FragmentBaseDelegate",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
		"com/sap/cp/lm/util/ErrorManager",
		'sap/m/MessageBox'
	], function (BaseDelegate, BusyIndicator, LocomotiveDataModel, ErrorManager, MessageBox) {
		"use strict";
		var _this;
		return BaseDelegate.extend("com.sap.cp.lm.controller.common.SerialNumber", {

			_sFragmentName: "com.sap.cp.lm.view.common.TaskSheet.SerialNumber",

			//--------------------------------------------------------------------
			// Life cycle functions
			//--------------------------------------------------------------------

			/**
			 * Fragment Initialization method
			 */
			onInit: function () {
				_this = this;
				var oModel = new sap.ui.model.json.JSONModel();
				this.getFragment().setModel(oModel);
				BusyIndicator.showBusyIndicator();
				this._initParameters();
			},

			//--------------------------------------------------------------------
			// Private functions
			//--------------------------------------------------------------------

			/**
			 *  Initialization
			 */
			_initParameters: function () {
				this.aDataFromSource = this.oParameters.oTaskHeader;
				var oModel = this.getFragment().getModel();

				oModel.setProperty("/SerialNbr", this.aDataFromSource.SerialNbr);
				oModel.setProperty("/MeasurementType", this.aDataFromSource.MeasurementType);
				// Start - SHE0272 - SHE0272 - LLM1.2 - Serialization
				oModel.setProperty("/GoodsIssueAndReturn", this.aDataFromSource.GoodsIssueAndReturn);
				oModel.setProperty("/MaterialNumber", "");
				oModel.setProperty("/StorageLocation", "");
				oModel.setProperty("/ManualEntry", false);
				oModel.setProperty("/SerialNumberPayload", {});
				if (this.aDataFromSource.SerialNbr) {
					oModel.setProperty("/SerialNumberEnable", false);
				} else {
					oModel.setProperty("/SerialNumberEnable", true);
				}
				LocomotiveDataModel.GetSerializationNumbers(this.aDataFromSource.Plant, _this.fnSuccessSerializationNumbers, " ", this);
				LocomotiveDataModel.GetMaterialList("", _this.fnSuccessMaterialList, " ", this);
				// End - SHE0272 - SHE0272 - LLM1.2 - Serialization
				//Start of EPA Information - Serialization 
			     if (this.aDataFromSource.MeasurementType === "6" && this.aDataFromSource.Measurement && this.aDataFromSource.SerialNbr === "" &&
					(this.aDataFromSource.InstallPosition === "ESNO" || this.aDataFromSource.InstallPosition === "EMOD" ||
						this.aDataFromSource.InstallPosition === "LFEL" || this.aDataFromSource.InstallPosition === "EFEL")) {
					oModel.setProperty("/SerialNbr", this.aDataFromSource.Measurement);
				} else {
					oModel.setProperty("/SerialNbr", this.aDataFromSource.SerialNbr);
				}
				
				oModel.setProperty("/Measurement", this.aDataFromSource.Measurement);
				oModel.setProperty("/InstallPosition", this.aDataFromSource.InstallPosition);
				oModel.setProperty("/MeasurementLength", oModel.getProperty("/Measurement").length);
				oModel.setProperty("/MaxDate", new Date());
		        //End of EPA Information - Serialization 
				BusyIndicator.hideBusyIndicator();
			},
			//Start of Change event for Manufacture Date 
				handleEngmanfdatechange: function (oEvent) {
				var sValue = oEvent.getSource().getValue();
				var bValid = oEvent.getParameter("valid");
				if (!bValid) {
					sap.m.MessageBox.warning(this.getFragment().getModel("i18n").getResourceBundle().getText("DATE_FORMAT_EPA"));
					oEvent.getSource().setValue("");
				} else {
					if (sValue.split("-")[0] > 12) {
						sap.m.MessageBox.warning(this.getFragment().getModel("i18n").getResourceBundle().getText("MONTH_FORMAT_EPA"));
						oEvent.getSource().setValue("");
					}
				}
			},
			//End of Change event for Manufacture Date 

			fnSuccessSerializationNumbers: function (oData) {
				var oModel = this.getFragment().getModel();
				if (oData) {
					oModel.setSizeLimit(oData.results.length);
					oModel.setProperty("/SerialNumberList", oData.results);
				}
			},
			
			fnSuccessMaterialList: function (oData) {
				var oModel = this.getFragment().getModel();
				if (oData) {
					oModel.setProperty("/MaterialList", oData.results);
				}
			},

			/**
			 * Save Serial number
			 */
			onSave: function () {
					var oModel = this.getFragment().getModel();
	//**********************EPA mask inputs data validation start********************************//
				if ((oModel.getProperty("/SerialNbr") === "DUMMY" || oModel.getProperty("/SerialNbr") === "") && oModel.getProperty(
						"/InstallPosition") === "EMAN") {
					sap.m.MessageBox.warning(this.getFragment().getModel("i18n").getResourceBundle().getText("ENGINE_MANF_WRN"));
					return;
				} else if (oModel.getProperty("/MeasurementType") === "6" && oModel.getProperty("/InstallPosition") === "EMDT") {
					if (oModel.getProperty("/SerialNbr") === "") {
						sap.m.MessageBox.warning(this.getFragment().getModel("i18n").getResourceBundle().getText("DATE_FORMAT_EPA"));
						return;
					} else if (oModel.getProperty("/SerialNbr").split("-")[0] && oModel.getProperty("/SerialNbr").split("-")[0] > 12) {
						sap.m.MessageBox.warning(this.getFragment().getModel("i18n").getResourceBundle().getText("MONTH_FORMAT_EPA"));
						return;
					}

				} else if (oModel.getProperty("/MeasurementType") === "6" && (oModel.getProperty("/InstallPosition") === "EMOD" || oModel.getProperty(
							"/InstallPosition") === "EMAN" || oModel.getProperty("/InstallPosition") === "EMDT" || oModel.getProperty("/InstallPosition") ===
						"ESNO" || oModel.getProperty("/InstallPosition") === "LFEL" || oModel.getProperty("/InstallPosition") === "EFEL")) {
					if (oModel.getProperty("/SerialNbr") === "" || oModel.getProperty("/SerialNbr").indexOf("_") != -1) {
						sap.m.MessageBox.warning(this.getFragment().getModel("i18n").getResourceBundle().getText("EPADATA_VALIDATION"));
						return;
					}

				}
				//**********************EPA mask inputs data validation end********************************//
				var oPayload = {};
				oPayload.OrderNbr = this.aDataFromSource.OrderNbr;
				oPayload.OperationNbr = this.aDataFromSource.OperationNbr;
				oPayload.SubOperNbr = this.aDataFromSource.SubOperNbr;
				oPayload.EquipNbr = this.aDataFromSource.EquipNbr;
				oPayload.PosNbr = this.aDataFromSource.InstallPosition;
				oPayload.SerialNbr = oModel.getProperty("/SerialNbr");
				//START - BAJ0018 - EAM-ASR3415776 		
				oPayload.ObjectType = this.aDataFromSource.ObjectType;
				oPayload.Room = this.aDataFromSource.Room;
				//END - BAJ0018 - EAM-ASR3415776 
				// Start - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
				oPayload.SoftwareCharacteristic = this.aDataFromSource.SoftwareCharacteristic;
				oPayload.SoftwareClass = this.aDataFromSource.SoftwareClass;
				// End - SHE0272 - LLM3.2 - ERQ Serial Number and SW Revision number
				LocomotiveDataModel.updateSerialNo(oPayload, _this.fnSuccessSave, " ", this);

			},

			/**
			 * Success call back
			 */
			fnSuccessSave: function (oData) {
				this.getFragment().close();
				if (this.aDataFromSource.oSourceViewController.fetchAndRefreshView) {
					this.aDataFromSource.oSourceViewController.fetchAndRefreshView();
				}
				//START - BAJ0018 - EAM-ASR3415776 	
				// if (oData.SubEquipNbr) {
				// 	var sMsg = oData.SubEqupDesc + " " + oData.Room + " " + "(" + oData.SubEquipNbr + ")" + " is updated and Order " + oData.OrderNbr +
				// 		" is updated";
				// 	sap.m.MessageBox.information(sMsg);
				// } else {
				// 	sMsg = "No Sub equipment found in hierarchy. Order " + oData.OrderNbr + " is updated";
				// 	sap.m.MessageBox.alert(sMsg);
				// }
				//END - BAJ0018 - EAM-ASR3415776 	
			},

			/**
			 * Close the dialog window
			 */
			onClose: function () {
				this.getFragment().close();
			},

			// Start - SHE0272 - SHE0272 - LLM1.2 - Serialization - Good Issue and Return Methods

			fnOnSerialNumberEntry: function (oEvent) {
				var oPayLoad = this.fnGetGoodIssuePayload(oEvent.getSource().getValue());
				var oModel = this.getFragment().getModel();
				if (oPayLoad.Sernr) {
					oModel.setProperty("/ManualEntry", false);
					var data = {
						"Vornr": this.aDataFromSource.OperationNbr,
						"Uvorn": this.aDataFromSource.SubOperNbr,
						"Eqart": this.aDataFromSource.ObjectType,
						"Matnr": oPayLoad.Matnr,
						"Werks": oPayLoad.Werks,
						"Lgort": oPayLoad.Lgort,
						"Sernr": oPayLoad.Sernr,
						"Charge": oPayLoad.Charge,
						"Aufnr": this.aDataFromSource.OrderNbr,
						"ManualSrno": ""
					};
					oModel.setProperty("/SerialNumberPayload", data);
				} else {
					oModel.setProperty("/ManualEntry", true);
				}
			},

			onGoodsIssueAndReturn: function () {
				var oModel = this.getFragment().getModel();
				var ManualEntry = oModel.getProperty("/ManualEntry");
				var SerialNumberPayload = oModel.getProperty("/SerialNumberPayload");
				if (!oModel.getProperty("/SerialNbr")) {
					oModel.setProperty("/ManualEntry", true);
				}
				if (ManualEntry) {
					SerialNumberPayload.Matnr = oModel.getProperty("/MaterialNumber");
					SerialNumberPayload.Charge = oModel.getProperty("/StorageLocation").split(" - ")[1];
					SerialNumberPayload.Lgort = oModel.getProperty("/StorageLocation").split(" - ")[0];
					SerialNumberPayload.Werks = oModel.getProperty("/StorageLocation").split(" - ")[2];
					SerialNumberPayload.Sernr = oModel.getProperty("/SerialNbr");
					SerialNumberPayload.Vornr = this.aDataFromSource.OperationNbr;
					SerialNumberPayload.Uvorn = this.aDataFromSource.SubOperNbr;
					SerialNumberPayload.Eqart = this.aDataFromSource.ObjectType;
					SerialNumberPayload.Aufnr = this.aDataFromSource.OrderNbr;
					SerialNumberPayload.ManualSrno = "X";
				}
				if (SerialNumberPayload.Matnr && SerialNumberPayload.Charge && SerialNumberPayload.Lgort) {
					LocomotiveDataModel.fnGoodIssue(SerialNumberPayload, _this.fnSuccessSave, " ", this);
				} else {
					MessageBox.show("Please select Material, Storage Location and Batch", {
					icon: MessageBox.Icon.ERROR,
					title: "Error",
					styleClass: "successMessage",
					actions: [MessageBox.Action.OK]
				});
				}
			},
			
			fnChangeMaterial: function () {
				var oModel = this.getFragment().getModel();
				oModel.setProperty("/StorageLocation", "");
				if (oModel.getProperty("/MaterialNumber")) {
					var filterParameter = "MatNo eq '" + oModel.getProperty("/MaterialNumber") + "' and Plant eq '" + this.aDataFromSource.Plant + "'";
					LocomotiveDataModel.fnGetStorageLocationDetails(filterParameter, _this.fnSuccessStorageLocationDetails, " ", this);
				}
			},
			
			fnSuccessStorageLocationDetails: function (oData) {
				var oModel = this.getFragment().getModel();
				if (oData) {
					oModel.setProperty("/StorageLocationList", oData.results);
				}
			},

			fnGetGoodIssuePayload: function (SerialNbr) {
				var oModel = this.getFragment().getModel();
				var SerialNumberList = oModel.getProperty("/SerialNumberList");
				var oPayLoad = {};
				for (var i = 0; i < SerialNumberList.length; i++) {
					if (SerialNumberList[i].Sernr === SerialNbr) {
						oPayLoad = SerialNumberList[i];
						break;
					}
				}
				return oPayLoad;
			}

			// End - SHE0272 - SHE0272 - LLM1.2 - Serialization - Good Issue and Return Methods

		});
	}

);