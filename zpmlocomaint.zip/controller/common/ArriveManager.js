/*&---------------------------------------------------------------------*    
 * Author         : SAP Custom Development                               *
 * Date           : 2017.12.21                                           *
 * Project        : Locomotive Maintenance                               *
 * Description    : This is the controller for the Work Order History    *
 *                  fragment view. This view is displayed on multiple    *
 *                  views (Shopped Locomotive, Craft worker).            *
 *&----------------------------------------------------------------------*/
/*&---------------------------------------------------------------------*    
 * Author         : Sandhya satavalekar                                  *
 * Date           : 04-March-2019                                          *
 * Project        : Locomotive Maintenance Phase 2                       *
 * Description    : LMP2-20: Remove all the madatory checks for the defects work list *
 * Search Term    : LMP2-20
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : KIR0084                                              *
 * Date           : 2019.04.10                                           *
 * Incidinet      : LMP2-28 - PM Loco Main phase 2              	     *
 * Description    : Do not go to track page if type is confirmInbound	 *
 * Search Term    : LMP2-28                                              *
 *&----------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
 * Author/Changed By   : Sandesh Shirode(SHI0087)	               		  *
 * Date                : 22-April-2019                                     *
 * Project             : Locomotive Maintenance Phase 2                    *
 * Description         : LMP2-43 : Add default date to STA on trackspot    *	
 *					    screen											  *		
 *&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
 * Author/Changed By   : Steve Palme (PAL0121)    	               		  *
 * Date                : 03-March-2020                                     *
 * Project             : ASR3414893						                  *
 * Description         : Remove select all checkbox from notifications tab *	
 *&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
 * Author/Changed By   : Vikram Bajaj (BAJ0018)    	               		  *
 * Date                : 25-May-2020                                      *
 * Project             : EAM-ASR3415323					                  *
 * Description         : Mandatory notification shopping                  *	
 *&------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
 * Author/Changed By   : Vikram Bajaj (BAJ0018)    	               		  *
 * Date                : 9-July-2020                                      *
 * Project             : EAM-ASR3415598					                  *
 * Description         : Mandatory notification shopping (QLMI)           *	
 *&------------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : SHE0272                                              *
 * Date           : 07.Jun.2021                                          *
 * Incidinet      : LLM2.29 - Road/Yard Repair			              	 *
 * Description    : new button press handler for - Road/Yard Repair		 *
 * Search Term    : LLM2.29                                              *
 *&----------------------------------------------------------------------*/
/*&---------------------------------------------------------------------*   
 * Author/Changed By   : SHE0272										*
 * Date                : 06 -Jul -2021									*
 * Project             : LLM2.23 - Primary Defect						*
 * Description         : Enable primary action checkbox					*
 * Search Term         : LLM2.23										*
 *&---------------------------------------------------------------------*/
jQuery.sap.declare("com.sap.cp.lm.controller.common.ArriveManager");

sap.ui.define([
		"com/sap/cp/lm/util/Constants",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
		"com/sap/cp/lm/model/main/TrackSpotModel",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/util/Formatter",
		"com/sap/cp/lm/controller/locomotives/LocomotiveManager",
		// "com/sap/cp/lm/controller/locomotives/WorkOrderManager",
		"com/sap/cp/lm/util/ErrorManager",
	],
	function (Constants, LocomotiveDataModel, TrackSpotModel, BusyIndicator, Formatter, LocomotiveManager, ErrorManager) {
		"use strict";
		var _this;

		return com.sap.cp.lm.controller.common.ArriveManager = {

			//----------------------------------------------------------------------
			// Life cycle functions
			//----------------------------------------------------------------------

			init: function (origin, type) {
				_this = this;

				_this.oModel = new sap.ui.model.json.JSONModel();
				_this.origin = origin;
				_this.type = type;

				LocomotiveDataModel.fetchDefectToOrderTypes(_this.defectToOrderTypesSuccess, null, _this);

				return _this;
			},

			/*
			 * adapt arrival type
			 */
			setType: function (type) {
				_this.type = type;
			},

			//----------------------------------------------------------------------
			// Private functions
			//----------------------------------------------------------------------

			/*
			 * pre load defect to order dropdown values
			 */
			defectToOrderTypesSuccess: function (oData) {
				var results = oData.results;
				if (results) {
					_this.oModel.setProperty("/DefectToOrderTypes", results);
				}
			},

			/**
			 * set dialog property
			 **/
			dialogSetProperty: function (sProperty, oData) {
				var oModel = _this._oArriveProcessDialog.getModel();
				oModel.setProperty(sProperty, oData);
				_this.oModel.setProperty(sProperty, oData);
			},

			/**
			 * adapt dialog to screen size
			 **/
			resizeDialog: function () {
				var frameHeight = $(window).height();
				var frameWidth = $(window).width();

				var oItem = sap.ui.getCore().byId("arriveProcessDialog");

				oItem.setContentHeight(frameHeight * 0.75 + "px");
				oItem.setContentWidth(frameWidth * 0.75 + "px");
			},

			/**
			 * if any defect doesn't have a work order move to "workorders" tab
			 * else move directly to "trackspot" tab
			 */
			checkMissingWorkOrders: function () {
				var aDefects = _this.oModel.getProperty("/Defects");

				for (var i = 0; i < aDefects.length; i++) {
					var oDefect = aDefects[i];

					if (!oDefect.WorkOrderNo || oDefect.WorkOrderNo.length === 0) {
						//extract defects missing WO
						_this.filterMissingWODefects(aDefects);
						return "workorders";
					}
				}

				return "trackspot";
			},

			/**
			 * prepare the defects list
			 */
			arriveDefectsListSetup: function (oData) {
				//reset

				var oWorkOrderSelect = sap.ui.getCore().byId('arriveDefectsListServiceWorkOrderSelect');
				oWorkOrderSelect.setSelectedItem(null);

				var oTable = sap.ui.getCore().byId('arriveDialogDefectsTable');

				var sShopId = _this.oModel.getProperty("/Shop").Id;
				var aDefects = _this.oModel.getProperty("/Defects");

				//select all checkboxes and defects by default
				//start:commented by Sandhya : LMP2-18 20
				//	oTable.selectAll();
				// end: commented by sandhya
				//added by sandhya
				var tableRows = oTable.getItems();
				if (aDefects && aDefects.length > 0) {
					for (var i = 0; i < aDefects.length; i++) {
						var oDefect = aDefects[i];
						//START KIR0084 - LMP2-28
						//START - BAJ0018 - MANDATORY
						oDefect.Selected = !!oDefect.OrderPlnd;
						var reqStartDate = new Date(oDefect.ReqStartTs.getYear(), oDefect.ReqStartTs.getMonth(), oDefect.ReqStartTs.getDate());
						var todayDate = new Date(new Date().getYear(), new Date().getMonth(), new Date().getDate());
						reqStartDate.setDate(reqStartDate.getDate() - 10);
						if (todayDate >= reqStartDate) {
							var mandatoryOrder = "X";
						} else {
							mandatoryOrder = null;
						}
						//START - QLMI
						if (oDefect.DefectDescr.includes("QUALIFIED LOCO MECHANICAL INSPECTION")) {
							mandatoryOrder = null;
						}
						//END - QLMI
						//END - BAJ0018 - MANDATORY
						if (tableRows[i]) {
							var primaryAction = false;
							// Start - LLM2.29 - Road/Yard Repair
							if (_this.oModel && _this.oModel.getProperty("/ArrivalType") && _this.oModel.getProperty("/ArrivalType") ===
								"roadYardRepair") {
								tableRows[i].setSelected(false);
							} else {
								tableRows[i].setSelected(oDefect.Selected);
								//START - BAJ0018 - MANDATORY
								if (mandatoryOrder) {
									tableRows[i].setSelected(true);
									oDefect.Selected = true;
									primaryAction = true;
								}
								//END - BAJ0018 - MANDATORY
								//-- Start SHE0272: LLM2.23 - Primary Defect - Enable primary action checkbox
								if (_this.oModel && _this.oModel.getProperty("/ArrivalType") && _this.oModel.getProperty("/ArrivalType") ===
									"shopped") {
									var rb = tableRows[i].getCells()[2];
									if (rb) {
										rb.setVisible(primaryAction);
										rb.setSelected(false);
									}
								}
							}
						}
						//END KIR0084 - LMP2-28
					}
				}
				//end:added by sandhya

				//setup
				// var header = oTable.$().find('thead');
				// var selectAllCb = header.find('.sapMCb');
				// var oSelectAllCb = sap.ui.getCore().byId(selectAllCb.attr('id'));

				//	add toggle action to each checkbox
				// oSelectAllCb.attachSelect(function(){
				// 	oTable.getItems().forEach(function(r) {
				// 		var cb = r.$().find('.sapMCb');
				// 		var oCb = sap.ui.getCore().byId(cb.attr('id'));
				// 		if(oCb.getEnabled() === false) {
				// 			oCb.setSelected(true);
				// 		}

				// 		//adapt row styling and apply deferral code value
				// 	//	_this.checkboxStatus(r,sShopId,true);
				//  	});
				//  });
				//start:commented by sandhya
				//initial row styling
				// oTable.getItems().forEach(function(r) {
				// 	_this.checkboxStatus(r,sShopId, false);
				// });
				//end:commented by sandhya				
			},

			/**
			 * refresh ui according to previous selections when navigating back in tabs
			 */
			refreshDefectsListSetup: function () {
				// var oTable = sap.ui.getCore().byId('arriveDialogDefectsTable');	
				// var sShopId = _this.oModel.getProperty("/Shop").Id;

				// //initial row styling
				// oTable.getItems().forEach(function(r) {
				// 	var oObject = r.getBindingContext().getObject();

				// 	_this.tmpDefectSet.forEach(function(d) {
				// 		if(oObject.DefectNo === d.DefectNo) {

				// 			var cb = r.$().find('.sapMCb');
				// 			var oCb = sap.ui.getCore().byId(cb.attr('id'));
				// 			oCb.setSelected(oObject.Selected);

				// 			var select = r.$().find('.arriveDialogDeferalCodesSelect');
				// 			var oSelect = sap.ui.getCore().byId(select.attr('id'));
				//start : commented by sandhya	
				// var isSelectVisible = _this.checkboxStatus(r,sShopId, false);

				// if(isSelectVisible === true) {
				// 	oSelect.setSelectedKey(oObject.DeferralCode);
				// }
				//end:commented by sandhya
				// 		}
				// 	});
				// });
			},

			/**
			 * row status helper
			 */
			checkboxStatus: function (r, sShopId, bApplyDefaultDeferalCode) {
				var oObject = r.getBindingContext().getObject();

				var plannedInAnotherShop = true;
				if (oObject.Shop === sShopId) {
					plannedInAnotherShop = false;
				}

				var hasWorkOrder = false;
				if (oObject.WorkOrderNo && oObject.WorkOrderNo !== "") {
					hasWorkOrder = true;
				}

				//checkbox
				var cb = r.$().find('.sapMCb');
				var oCb = sap.ui.getCore().byId(cb.attr('id'));

				//deferal codes select
				var select = r.$().find('.arriveDialogDeferalCodesSelect');
				var oSelect = sap.ui.getCore().byId(select.attr('id'));
				var enabled = oSelect.getEnabled();
				oSelect.setSelectedItem(null);

				var isSelectVisible = true;

				//no work order
				if (hasWorkOrder === false) {
					oCb.setEnabled(true);
				} else {
					//has work order
					if (plannedInAnotherShop) {
						oCb.setEnabled(true);
					} else {
						oCb.setEnabled(false);
					}
					isSelectVisible = false;
				}

				var checked = oCb.getSelected();

				if (!checked) {
					if (!hasWorkOrder) {
						enabled = true;
					}
				} else {
					enabled = hasWorkOrder;
				}

				oObject.Selected = checked;

				if (bApplyDefaultDeferalCode === true) {
					_this._defaultDeferalCodesSelect(oSelect, oObject, enabled, isSelectVisible);
				}

				_this.applyVisible(isSelectVisible, select);

				return isSelectVisible;
			},

			/**
			 * handle selection of default deferral code
			 */
			_defaultDeferalCodesSelect: function (oSelect, oObject, bEnabled, isSelectVisible) {

				oSelect.setEnabled(bEnabled);

				if (isSelectVisible && bEnabled && _this._defaultDeferalCodeValue) {
					oSelect.setSelectedKey(_this._defaultDeferalCodeValue);
					oObject.DeferralCode = _this._defaultDeferalCodeValue;
				} else {
					oSelect.setSelectedItem(null);
					oObject.DeferralCode = null;
				}
			},

			/* Start KIR0084 - LMP2-28: Return if this dialog is for an inbound loco */
			_isInbound: function () {
				return _this._isConfirmInbound() || _this._isChangeInbound();
			},

			_isConfirmInbound: function () {
				return _this.type === "confirmInbound";
			},

			_isChangeInbound: function () {
				return _this.type === "changeInbound";
			},

			_isShopped: function () {
				return _this.type === "shopped";
			},

			_isService: function () {
				return _this.type === "service";
			},

			_isRoadYardRepair: function () {
				return _this.type === "roadYardRepair";
			},
			/* Start KIR0084 - LMP2-28: Return if this dialog is for an inbound loco */

			/**
			 * ui visibility helper
			 */
			applyVisible: function (isVisible, oElement) {
				if (isVisible) {
					oElement.removeClass("lmHidden");
				} else {
					oElement.addClass("lmHidden");
				}
			},

			/**
			 * filter Defects with missing work orders
			 */
			filterMissingWODefects: function (aDefects) {
				var missingWODefects = [];

				for (var i = 0; i < aDefects.length; i++) {
					var oDefect = aDefects[i];
					if (oDefect.Selected) {
						if (!oDefect.WorkOrderNo || oDefect.WorkOrderNo.length === 0) {
							//add matching order types
							oDefect.WOTypes = _this.filterOrderTypes(oDefect);
							missingWODefects.push(oDefect);
						}
					}
				}

				_this.dialogSetProperty("/MissingWODefects", missingWODefects);
			},

			/**
			 * filter order Type according to defect type
			 */
			filterOrderTypes: function (oDefect) {
				var sDefectType = oDefect.DefectType;
				var aFiltered = [];
				var aDefectToOrderTypes = _this._oGlobalModel.getProperty("/DefectToOrderTypes");
				for (var i = 0; i < aDefectToOrderTypes.length; i++) {
					var defectToOrderType = aDefectToOrderTypes[i];
					if (defectToOrderType.Key === sDefectType) {
						aFiltered.push(defectToOrderType);

						if (defectToOrderType.DefaultSelection === true) {
							oDefect.OrderType = defectToOrderType.Value;
						}
					}
				}
				return aFiltered;
			},

			/**
			 * filter available Spots
			 */
			filterSpots: function (sKey) {
				var aTrackSet = _this.oModel.getProperty("/AvailableTrackSet");
				for (var i = 0; i < aTrackSet.length; i++) {
					var oTrack = aTrackSet[i];
					if (oTrack.Track === sKey) {
						return oTrack.AvailSpots.results;
					}
				}
				return [];
			},

			/**
			 * finalize Arrival process and submit
			 */
			finalizeArrival: function () {
				var oPayload = _this.createArrivePayload();
				if (_this._oGlobalModel.getProperty("/relLocoFirst")) {
					oPayload.ReleaseLocoFirst = _this._oGlobalModel.getProperty("/relLocoFirst");
					_this._oGlobalModel.setProperty("/relLocoFirst", false);
				}
				LocomotiveDataModel.arriveInboundLocomotive(oPayload, _this.onArriveInboundLocomotiveSuccess, _this.onArriveInboundLocomotiveFailure,
					_this);
			},

			/* Start KIR0084 LMP2-28 */
			/**
			 * finalize Arrival process and submit
			 */
			finalizeInbound: function () {
				var oPayload = _this.createArrivePayload();
				LocomotiveDataModel.arriveInboundLocomotive(oPayload, _this.onConfirmInboundLocomotiveSuccess, _this.onConfirmInboundLocomotiveFailure,
					_this);
			},
			/* End KIR0084 LMP2-28 */

			/**
			 * create Arrival payload for backend call
			 */
			createArrivePayload: function (oEvent) {
				var shop = _this.oModel.getProperty("/Shop");
				var loco = _this.oModel.getProperty("/Locomotive");

				var locoId = loco.LocomotiveId;
				_this.MainShopReason = "";

				var sEquipNo = loco.Equipment;
				if (!sEquipNo) {
					sEquipNo = loco.EquipNo;
				}
				var equipNbr = sEquipNo;

				var trackSelect = sap.ui.getCore().byId('arriveDialogFinishTrackSelect');
				var track = trackSelect.getSelectedKey();

				var spotSelect = sap.ui.getCore().byId('arriveDialogFinishSpotSelect');
				var spot = spotSelect.getSelectedKey();

				var directionSelect = sap.ui.getCore().byId('arriveDialogFinishDirectionSegmentedButton');
				var direction = directionSelect.getSelectedKey();

				var arriveDialogFinishSTA = sap.ui.getCore().byId('arriveDialogFinishSTA');
				var shoppedTimestamp = arriveDialogFinishSTA.getValue();

				var arriveDialogFinishETR = sap.ui.getCore().byId('arriveDialogFinishETR');
				var etrTimestamp = arriveDialogFinishETR.getValue();

				var shoppedTimezone = shop.TimeZone;
				var etrTimezone = shop.TimeZone;

				var isOutbound = _this._isInbound() && _this.oModel.getProperty("/Context/oLocomotive/IsOutbound");

				var serviceOrderNumber = _this.oModel.getProperty("/ServicingNotification/WorkOrder") || ""; // Do not pass "undefined as a string into odata service"
				var serviceOrderDefect = _this.oModel.getProperty("/ServicingNotification/Notification") || ""; // Do not pass "undefined as a string into odata service"

				var oPayload = {
					"ShopId": shop.Id,
					"LocoId": locoId,
					"EquipNbr": equipNbr,
					"ShoppedTimestamp": shoppedTimestamp,
					"ShoppedTimezone": shoppedTimezone,
					"Track": track,
					"Spot": spot,
					"Direction": direction,
					"ShGuid": "",
					"EtrTimestamp": etrTimestamp,
					"EtrTimezone": etrTimezone,
					"RelTimestamp": "",
					"RelTimezone": "",
					/* Start KIR0084 - LMP2: Set IsInbound property if type is confirmInbound */
					"IsInbound": _this._isInbound(),
					"IsOutbound": isOutbound
						/* End KIR0084 - LMP2-30: Service tasklist items */
				};

				// Start - SHE0272: LLM2.29 - Road/Yard Repair - Adding mandatory note field on creation of shopped loco set
				if (_this.oModel.getProperty("/ArrivalType") === "roadYardRepair") {
					oPayload["MandatoryNote"] = _this.oModel.getProperty("/MandatoryNote");
				}
				// End - SHE0272: LLM2.29 - Road/Yard Repair - Adding mandatory note field on creation of shopped loco set

				if (serviceOrderNumber) {
					oPayload["ServiceOrderNumber"] = serviceOrderNumber;
				}
				if (serviceOrderDefect) {
					oPayload["ServiceOrderDefect"] = serviceOrderDefect;
				}

				if (_this.type === "service") {
					var arriveDefectsListServiceWorkOrderSelect = sap.ui.getCore().byId('arriveDefectsListServiceWorkOrderSelect');
					var selectedSWOKey = arriveDefectsListServiceWorkOrderSelect.getSelectedKey();
					if (selectedSWOKey) {
						var oItem = arriveDefectsListServiceWorkOrderSelect.getSelectedItem();
						if (oItem) {
							var oContext = oItem.getBindingContext();
							var oObj = oContext.getObject();

							oPayload["TasklistType"] = oObj.TasklistType;
							oPayload["TasklistGroupKey"] = oObj.TasklistGroupKey;
							oPayload["TasklistCounter"] = oObj.TasklistCounter;
							oPayload["TasklistDescription"] = oObj.TasklistDescription;
							oPayload["DefectSet"] = [];
						}
					}
				} else {
					oPayload["DefectSet"] = _this.createDefectSet();
				}
				// Start SHE0272: LLM2.23 - Primary Defect - New paramenter to store the Main Shop Reason
				if (_this.type === "shopped" && _this.MainShopReason) {
					oPayload["MainShopReason"] = _this.MainShopReason;
				}
				// End SHE0272: LLM2.23 - Primary Defect - New paramenter to store the Main Shop Reason
				return oPayload;
			},

			/**
			 * create defect set payload for backend call
			 */
			createDefectSet: function () {

				var oModel = _this._oArriveProcessDialog.getModel();
				var aDefects = oModel.getProperty("/Defects");

				var defectSet = [];

				for (var i = 0; i < aDefects.length; i++) {
					var oDefect = aDefects[i];

					var oPayloadDefect = {
						"EquipNo": oDefect.EquipNo,
						"WorkOrderNo": oDefect.WorkOrderNo,
						"DeferralCode": oDefect.DeferralCode,
						"DefectNo": oDefect.DefectNo,
						"DefectType": oDefect.DefectType,
						"Shop": oDefect.Shop,
						"OrderType": oDefect.OrderType,
						"ObjectNo": oDefect.ObjectNo,
						"Selected": oDefect.Selected,
						"OrderPlnd": oDefect.OrderPlnd
					};

					defectSet.push(oPayloadDefect);
					// Start SHE0272: LLM2.23 - Primary Defect - New paramenter to store the Main Shop Reason
					if (oDefect.MainShopReason) {
						_this.MainShopReason = oDefect.DefectNo;
					}
					// End SHE0272: LLM2.23 - Primary Defect - New paramenter to store the Main Shop Reason
				}

				return defectSet;
			},

			//----------------------------------------------------------------------
			// Event handlers
			//----------------------------------------------------------------------

			/*
			 * Arrival process dialog process
			 */
			onArriveProcessDialogOpen: function (oDefects, oShop, oLocomotive, oContext) {
				var i18nModel = oContext.getOwnerComponent().getModel("i18n");
				_this._oGlobalModel = oContext.getOwnerComponent().getGlobalModel();
				_this._defaultDeferalCodeValue = _this._oGlobalModel.getProperty("/DefaultDeferalCodeValue");

				if (oShop) {
					_this.oModel.setProperty("/Shop", oShop);
				}

				_this.oModel.setProperty("/Locomotive", oLocomotive);
				if (oDefects) {
					_this.oModel.setProperty("/Defects", oDefects);
				}

				_this.oModel.setProperty("/Context", oContext);

				/* KIR0084 Clear Service notification */
				_this.oModel.setProperty("/ServicingNotification", {});

				/* KIR0084 Clear Service notification */

				var servicingTasklists = _this._oGlobalModel.getProperty("/ServicingTasklists");
				var deferalCodes = _this._oGlobalModel.getProperty("/DeferalCodes");
				var directions = _this._oGlobalModel.getProperty("/Directions");

				if (!_this._oArriveProcessDialog || _this._oArriveProcessDialog.bIsDestroyed) {
					_this._oArriveProcessDialog = sap.ui.xmlfragment(
						"com.sap.cp.lm.view.common.arrivalProcess.ArriveProcessDialog",
						_this
					);

					//adapt dialog to screen size
					_this._oArriveProcessDialog.afterOpen = _this.resizeDialog();
				}

				if (_this._oArriveProcessDialog) {
					/* Start KIR0084 - LMP2-28: Set title of dialog dynamically */
					if (_this._isConfirmInbound()) {
						_this._oArriveProcessDialog.setTitle(i18nModel.getProperty("CONFIRM_INBOUND"));
					} else if (_this._isChangeInbound()) {
						_this._oArriveProcessDialog.setTitle(i18nModel.getProperty("CHANGE_INBOUND"));
					} else if (_this._isService()) {
						_this._oArriveProcessDialog.setTitle(i18nModel.getProperty("SERVICE"));
					} else if (_this._isRoadYardRepair()) {
						_this._oArriveProcessDialog.setTitle(i18nModel.getProperty("OUTSIDE_POINT")); // SHE0272: LLM2.29 - Outside Point process
					} else {
						_this._oArriveProcessDialog.setTitle(i18nModel.getProperty("ARRIVE"));
					}
					/* End KIR0084 - LMP2-28: Set title of dialog dynamically */

					var oModel = _this.oModel;
					oModel.setProperty("/ServicingTasklists", servicingTasklists);
					oModel.setProperty("/ArrivalType", _this.type);
					if (oDefects) {
						oModel.setProperty("/Defects", oDefects);
						/////////////////////Begin of Changes for ASR3414893 by PAL0121/////////////////////
						var oTable = sap.ui.getCore().byId("arriveDialogDefectsTable");

						if (oTable) {
							//Remove select/deselect all checkbox
							oTable.addDelegate({
								onAfterRendering: function () {
									var header = this.$().find('thead');
									var selectAllCb = header.find('.sapMCb');
									selectAllCb.remove();
									//START - BAJ0018 - MANDATORY NOTIFICATION SHOPPING
									// select mandatory notification defects
									this.getItems().forEach(function (r) {
										var obj = r.getBindingContext().getObject();
										var reqStartDate = new Date(obj.ReqStartTs.getYear(), obj.ReqStartTs.getMonth(), obj.ReqStartTs.getDate());
										var todayDate = new Date(new Date().getYear(), new Date().getMonth(), new Date().getDate());
										reqStartDate.setDate(reqStartDate.getDate() - 10);
										if (todayDate >= reqStartDate) {
											var mandatoryOrder = "X";
										} else {
											mandatoryOrder = null;
										}
										//START - QLMI
										if (obj.DefectDescr.includes("QUALIFIED LOCO MECHANICAL INSPECTION")) {
											mandatoryOrder = null;
										}
										//END - QLMI
										var cb = r.$().find('.sapMCb');
										var rb = r.getCells()[2];
										var primaryAction = false;
										if (cb) {
											var oCb = sap.ui.getCore().byId(cb.attr('id'));
											if (oCb) {
												// Start - LLM2.29 - Road/Yard Repair
												if (_this.oModel && _this.oModel.getProperty("/ArrivalType") && _this.oModel.getProperty("/ArrivalType") ===
													"roadYardRepair") {
													oCb.setEnabled(true);
													r.setSelected(false);
												} else {
													if (mandatoryOrder) {
														oCb.setEnabled(false);
														r.setSelected(true);
														obj.Selected = true;
														primaryAction = true;
													} else {
														oCb.setEnabled(true);
													}
												}
												//-- Start SHE0272: LLM2.23 - Primary Defect - Enable primary action checkbox
												if (_this.oModel && _this.oModel.getProperty("/ArrivalType") && _this.oModel.getProperty("/ArrivalType") ===
													"shopped") {
													if (rb) {
														rb.setVisible(primaryAction);
														// rb.setSelected(false);
													}
												}
											}
										}
										//END - BAJ0018 - MANDATORY NOTIFICATION SHOPPING
									});
								}
							}, oTable);
						}
						//////////////////////End of Changes for ASR3414893 by PAL0121//////////////////////						
					}
					oModel.setProperty("/DeferalCodes", deferalCodes);
					if (oShop) {
						oModel.setProperty("/Shop", oShop);
					} else {
						var aShops = _this._oGlobalModel.getProperty("/Shops");
						oModel.setProperty("/Shops", aShops);

						if (_this._isInbound() && oLocomotive && oLocomotive.InboundShop) {
							oModel.setProperty("/Shop", oLocomotive.InboundShop);
						}
					}
					oModel.setProperty("/Directions", directions);
					_this._oArriveProcessDialog.setModel(oModel);

					var arriveDialogFinishSTA = sap.ui.getCore().byId('arriveDialogFinishSTA');
					//KIR0084 Add Null check
					if (arriveDialogFinishSTA) {
						arriveDialogFinishSTA.setValue(new Date());
					}

					var arriveDialogFinishETR = sap.ui.getCore().byId('arriveDialogFinishETR');
					//KIR0084 Add Null check
					if (arriveDialogFinishETR) {
						arriveDialogFinishETR.setValue(null);
					}
				}

				oContext.getView().addDependent(_this._oArriveProcessDialog);

				_this._oArriveProcessDialog.open();

				//reset dialog
				var oDialogContent = _this._oArriveProcessDialog.getContent();
				var oTabBar = oDialogContent[0];
				var aTabs = oTabBar.getItems();

				if (oShop) {
					oTabBar.setSelectedKey("defects");
					aTabs[0].setVisible(false);
					aTabs[0].setEnabled(false);
					aTabs[1].setEnabled(true);
					aTabs[2].setEnabled(false);
					aTabs[3].setEnabled(false);
					if (_this.type === "service") {
						setTimeout(function () {
							_this.arriveDefectsListSetup();
						}, 200);
					} else {
						var oWorkOrderSelect = sap.ui.getCore().byId('arriveDefectsListServiceWorkOrderSelect');
						oWorkOrderSelect.setSelectedItem(null);
					}
				} else {
					oTabBar.setSelectedKey("shops");
					aTabs[0].setVisible(true);
					aTabs[0].setEnabled(true);
					aTabs[1].setEnabled(false);
					aTabs[2].setEnabled(false);
					aTabs[3].setEnabled(false);
				}

				if (_this.type === "service") {
					oTabBar.getItems()[2].setVisible(false);
					oTabBar.getItems()[3].setVisible(true);
					oTabBar.getItems()[1].setText("Service Work Order");
				} else {
					oTabBar.getItems()[2].setVisible(true);
					oTabBar.getItems()[1].setText("Notifications");

					/* Start KIR0084 - LMP2-28: Refactor so Track is not displayed if train is inbound */
					if (_this._isInbound()) {
						// Hide Track Spot tab for confirm inbound type
						aTabs[2].setVisible(false);
						aTabs[3].setVisible(false);
					} else {
						aTabs[2].setVisible(true);
						aTabs[3].setVisible(true);
					}
					/* End KIR0084 - LMP2-28: Refactor so Track is not displayed if train is inbound */
				}

			},

			/**
			 * dialog navigation logic cancel
			 **/
			onArriveProcessDialogCancel: function (oEvent) {
				/* KIR0084 Clear Service notification */
				_this.oModel.setProperty("/ServicingNotification", {});
				/* KIR0084 Clear Service notification */

				_this._oArriveProcessDialog.close();
			},

			onSelectStep: function (oEvent) {
				var oDialogContent = _this._oArriveProcessDialog.getContent();
				var oTabBar = oDialogContent[0];
				var aTabs = oTabBar.getItems();

				var sKey = oEvent.getParameters().key;

				// Start - SHE0272: LLM2.29 - Road/Yard Repair - Adding a validation on mandatory note
				if (_this.oModel.getProperty("/ArrivalType") && _this.oModel.getProperty("/ArrivalType") === "roadYardRepair" && sKey !== "shops") {
					if (!_this.oModel.getProperty("/MandatoryNote")) {
						oTabBar.setSelectedKey("shops");
						return;
					} else if (_this.oModel.getProperty("/MandatoryNote") && !this.onValidateMandatoryNoteSelected()) {
						oTabBar.setSelectedKey("shops");
						return;
					}
				}
				// End - SHE0272: LLM2.29 - Road/Yard Repair - Adding a validation on mandatory note

				if (sKey === "defects") {
					aTabs[2].setEnabled(false);
					aTabs[3].setEnabled(false);
					if (_this.tmpDefectSet) {
						setTimeout(function () {
							_this.refreshDefectsListSetup();
						}, 20);
					}
				}
				if (sKey === "workorders") {
					aTabs[3].setEnabled(false);
				}
			},

			/**
			 * dialog navigation logic next step
			 **/
			onArriveProcessDialogNext: function (oEvent) {
				//dialog flow = shops -> defects -> workorders -> trackspot

				var oDialogContent = _this._oArriveProcessDialog.getContent();
				var oTabBar = oDialogContent[0];
				var selected = oTabBar.getSelectedKey();

				var nextStep = "";
				sap.ui.getCore().byId("arriveDialogFinishSTA").setDateValue(new Date()); // LMP2-UAT-186
				//step 0
				if (selected === "shops") {

					//validate the deferals
					var arriveShopsListDidPass = this.onValidateArriveShopsList();

					if (arriveShopsListDidPass) {
						var oShop = _this.oModel.getProperty("/Shop");

						TrackSpotModel.fetchServicingTasklists(oShop.Id,
							function (oData) {
								var servicingTasklists = oData.results;
								var oModel = _this._oArriveProcessDialog.getModel();
								oModel.setProperty("/ServicingTasklists", servicingTasklists);
								nextStep = "defects";
								oTabBar.getItems()[1].setEnabled(true);
								oTabBar.setSelectedKey(nextStep);

								setTimeout(function () {
									_this.arriveDefectsListSetup();
								}, 200);
							},
							null);
					}
					return;
				}

				//step 1
				else if (selected === "defects") {

					//validate the deferals
					var arriveDefectsListDidPass = this.onValidateArriveDefectsList();

					if (arriveDefectsListDidPass) {
						if (_this.type === "service") {
							nextStep = "trackspot";
						} else {
							// sap.ui.getCore().byId("arriveDialogFinishSTA").setDateValue(new Date()); // LMP2-UAT-186
							_this.tmpDefectSet = _this.createDefectSet();
							/* Start KIR0084 - LMP2-28: Skip trackspot page if type is confirmInbound */
							nextStep = _this.checkMissingWorkOrders();
							if (_this._isInbound()) {
								_this.checkMissingWorkOrders();
								return _this.finalizeInbound();
							}
							/* End KIR0084 - LMP2-28: Skip trackspot page if type is confirmInbound */
						}
					} else {
						return;
					}
				}

				//step 2
				else if (selected === "workorders") {

					//validate the work orders selections
					var arriveWorkOrdersDidPass = this.onValidateArriveWorkOrders();

					if (arriveWorkOrdersDidPass) {
						if (_this.type !== "service") {
							_this.tmpDefectSet = _this.createDefectSet();
						}

						nextStep = "trackspot";
						sap.ui.getCore().byId("arriveDialogFinishSTA").setDateValue(new Date()); // LPMP2-43
					} else {
						return;
					}
				}

				//step 3
				else if (selected === "trackspot") {
					//returns to cut UI update

					//validate track, spot dates selections 
					var arriveTrackSpotDidPass = this.onValidateArriveTrackSpot();

					if (arriveTrackSpotDidPass) {
						return _this.finalizeArrival();
					} else {
						return;
					}

				}

				if (nextStep === "workorders") {
					oTabBar.getItems()[2].setEnabled(true);
				} else {
					oTabBar.getItems()[3].setEnabled(true);
				}

				if (nextStep === "trackspot") {
					//refresh spots just before opening last tab
					_this.onRefreshAvailableSpots(function () {
						oTabBar.setSelectedKey(nextStep);
					});
				} else {
					oTabBar.setSelectedKey(nextStep);
				}
			},

			/**
			 *	Arrival process step 0 : shops 
			 */
			onValidateArriveShopsList: function () {
				var oShopSelect = sap.ui.getCore().byId('arriveDialogShopSelect');
				var oShop = oShopSelect.getSelectedItem().getBindingContext().getObject();
				if (oShop) {
					var oModel = _this._oArriveProcessDialog.getModel();
					oModel.setProperty("/Shop", oShop);
					_this.oModel.setProperty("/Shop", oShop);
					// Start - SHE0272: LLM2.29 - Road/Yard Repair
					if (_this.oModel.getProperty("/ArrivalType") && _this.oModel.getProperty("/ArrivalType") === "roadYardRepair" && !_this.oModel.getProperty(
							"/MandatoryNote")) {
						return false;
					} else if (_this.oModel.getProperty("/ArrivalType") && _this.oModel.getProperty("/ArrivalType") === "roadYardRepair" && _this.oModel
						.getProperty("/MandatoryNote") && !this.onValidateMandatoryNoteSelected()) {
						return false;
					} else {
						return true;
					}
					// End - SHE0272: LLM2.29 - Road/Yard Repair
				}
				return false;
			},

			/**
			 *	Arrival process step 1 : defects 
			 */
			onValidateArriveDefectsList: function () {
				var currentShopId = _this.oModel.getProperty("/Shop").Id;

				if (_this.type === "service") {
					//Service Work Order validation
					var oSelect = sap.ui.getCore().byId("arriveDefectsListServiceWorkOrderSelect");
					var oItem = oSelect.getSelectedItem();

					if (!oItem) {
						ErrorManager.handleError("", "Select a Service Work Order");
						return false;
					}
				} else {
					//Shopped defects list validation
					var didPass = true;
					var primaryActionSelected = false;	// SHE0272: LLM2.23 - Primary Defect - Main reason selection check
					var oTable = sap.ui.getCore().byId('arriveDialogDefectsTable');
					oTable.getItems().forEach(function (r) {
						var obj = r.getBindingContext().getObject();
						var cb = r.$().find('.sapMCb');
						var oCb = sap.ui.getCore().byId(cb.attr('id'));
						var oCbChecked = oCb.getSelected();

						//if unchecked verify that there is a deferral code or that the work is already planned at another shop
						if (!oCbChecked) {
							if (!obj.DeferralCode || obj.DeferralCode === "") { //no deferral code
								if (obj.Shop === currentShopId || !obj.WorkOrderNo || obj.WorkOrderNo === "") {
									//	didPass = false; //commented by sandhya lmp2-20
								}
							}
						}
						// Start SHE0272: LLM2.23 - Primary Defect - Main reason selection check
						var rb = r.getCells()[2];
						if (_this.type === "shopped" && !primaryActionSelected && (rb && rb.getSelected())) {
							primaryActionSelected = true;
						}
						// End SHE0272: LLM2.23 - Primary Defect - Main reason selection check
					});

					if (didPass !== true) {
						ErrorManager.handleError("", "Unselected defects requires a Deferral Code");
						return false;
					}
					// Start SHE0272: LLM2.23 - Primary Defect - Main reason selection check
					if (_this.type === "shopped" && oTable.getItems().length > 0 && !primaryActionSelected) {
						ErrorManager.handleError("", "Select a Main Shop Reason");
						return false;
					}
					// End SHE0272: LLM2.23 - Primary Defect - Main reason selection check
				}
				return true;
			},

			/** KIR0084 LMP2-30 Event handler for loading servicing notifications */
			onServiceTasklistSelect: function (event) {
				var i18nModel = event.getSource().getModel("i18n");

				var currentShopId = _this.oModel.getProperty("/Shop").Id;
				var oLocomotive = _this.oModel.getProperty("/Locomotive");
				var equipment = oLocomotive.Equipment || oLocomotive.EquipNo;
				var tasklistGroupKey = event.getSource().getSelectedKey();

				TrackSpotModel.fetchServicingTasklistNotifications(currentShopId, equipment, tasklistGroupKey,
					function (oData) {
						if (oData.results.length === 0) {
							_this.oModel.setProperty("/ServicingNotification", {});
						} else if (oData.results.length === 1) {
							_this.oModel.setProperty("/ServicingNotification", oData.results[0]);
						} else if (oData.results.length > 1) {
							_this.oModel.setProperty("/ServicingNotification", {});

							var errorMessage = i18nModel.getProperty("MULTIPLE_SERVICE_NOTIF_ERROR");

							var errorDetails = "";
							oData.results.forEach(function (result) {
								errorDetails += result.DefectNo || result.Notification + "\n";
							});

							ErrorManager.handleError("", errorMessage, errorDetails);
						}
					}.bind(this),
					null);
			},

			/**
			 * toggle checkbox
			 */
			onToggleArriveDialogCB: function (oEvent) {
				//start : commented by Sandhya : LMP2-18 20
				for (var i = 0; i < oEvent.getParameters().listItems.length; i++) {
					var oListItem = oEvent.getParameters().listItems[i];
					var oContext = oListItem.getBindingContext();
					var oDefect = oContext.oModel.getProperty(oContext.sPath);

					var select = oListItem.$().find('.arriveDialogDeferalCodesSelect');
					var oSelect = sap.ui.getCore().byId(select.attr('id'));
					var enabled = oSelect.getEnabled();

					var checked = oListItem.getProperty("selected");

					var isSelectVisible = true;

					var hasWorkOrder = false;
					// if (oDefect.WorkOrderNo && oDefect.WorkOrderNo !== "") {
					// 	hasWorkOrder = true;
					// 	isSelectVisible = false;
					// }

					// if (!checked) {
					// 	if (!hasWorkOrder) {
					// 		enabled = true;
					// 	}
					// } else {
					// 	enabled = hasWorkOrder;
					// }

					oDefect.Selected = checked;
				}
				// _this._defaultDeferalCodesSelect(oSelect,oDefect,enabled,isSelectVisible);
				//end:commented by Sandhya : LMP2-18 20
			},

			/**
			 * Change Deferal Code
			 */
			onChangeDeferalCode: function (oEvent) {

				var oParent = oEvent.getSource().getParent();

				var oParentContext = oParent.getBindingContext();
				var oDefect = oParentContext.getObject();

				var oItem = oEvent.getSource().getSelectedItem();
				var oContext = oItem.getBindingContext();
				var oObj = oContext.getObject();

				oDefect.DeferralCode = oObj.Value;
			},

			/**
			 * Change work order checkbox
			 */
			onSWOCheckBoxChange: function (oEvent) {
				var checked = oEvent.getParameters().selected;

				var oSelect = sap.ui.getCore().byId("arriveDefectsListServiceWorkOrderSelect");
				oSelect.setSelectedItem(null);

				setTimeout(function () {
					_this.applyVisible(checked, oSelect);
				}, 200);
			},

			/**
			 * Arrival process step 2 : workorders 
			 */
			onValidateArriveWorkOrders: function () {
				var oModel = _this._oArriveProcessDialog.getModel();
				var aDefects = oModel.getProperty("/MissingWODefects");

				for (var i = 0; i < aDefects.length; i++) {
					var oDefect = aDefects[i];

					if (!oDefect.OrderType || oDefect.OrderType.length === 0) {
						ErrorManager.handleError("", "Select a Work Order Type for all Defects");

						return false;
					}
				}

				return true;
			},

			/**
			 * change work order Type
			 */
			onChangeWorkOrderType: function (oEvent) {
				var oParent = oEvent.getSource().getParent();
				var oParentContext = oParent.getBindingContext();
				var oDefect = oParentContext.getObject();

				var oItem = oEvent.getSource().getSelectedItem();
				var oContext = oItem.getBindingContext();
				var oObj = oContext.getObject();

				oDefect.OrderType = oObj.Value;
			},

			/**
			 * Arrival process step 3 (final): trackspots 
			 */
			// refresh available spots for locomotive arrival
			onRefreshAvailableSpots: function (fSuccess) {
				var oShop = _this.oModel.getProperty("/Shop");

				var oLocomotive = _this.oModel.getProperty("/Locomotive");
				var sLocoTrack;
				var sLocoSpot;
				var sLocoDirection;
				var bReshop = _this._oGlobalModel.getProperty("/relLocoFirst");

				if ((oLocomotive && oLocomotive.ShopStatus === "R") || bReshop) {
					sLocoTrack = oLocomotive.Track;
					sLocoSpot = oLocomotive.Spot;
					sLocoDirection = oLocomotive.Direction;
				}

				// Start - SHE0272: LLM2.29 - Road/Yard Repair - New method of TrackSpotModel being called to get the data for both RYR and Non-RYR process. Changed the method from "fetchAvailableTracksSpots" to "fetchAvailableProcessSpecificTracksSpots"
				var urlParameters = {
					"$expand": "AvailTrackSet/AvailSpots",
					"$format": "json"
				};
				var url = "/ShopSet('" + oShop.Id + "')";
				if (_this.type === "roadYardRepair") {
					urlParameters = {
						"$filter": "Id eq '" + oShop.Id + "' and Name eq 'RYR'",
						"$expand": "AvailTrackSet/AvailSpots",
						"$format": "json"
					};
					url = "/ShopSet";
				}
				TrackSpotModel.fetchAvailableProcessSpecificTracksSpots(url, urlParameters,
					function (oData) {
						var successResult = oData;
						if (_this.type === "roadYardRepair") {
							successResult = oData.results[0];
						}
						var aTrackSet = successResult.AvailTrackSet.results;

						//reinject released loco track/spot
						if (sLocoTrack && sLocoSpot) {
							for (var i = 0; i < aTrackSet.length; i++) {
								var oTrackSet = aTrackSet[i];
								if (oTrackSet.Track === sLocoTrack) {
									oTrackSet.AvailSpots.results.push({
										"Spot": sLocoSpot
									});

									setTimeout(function () {
										var trackSelect = sap.ui.getCore().byId('arriveDialogFinishTrackSelect');
										var spotSelect = sap.ui.getCore().byId('arriveDialogFinishSpotSelect');
										var directionSelect = sap.ui.getCore().byId('arriveDialogFinishDirectionSegmentedButton');

										trackSelect.setSelectedKey(sLocoTrack);
										var spotSet = _this.filterSpots(sLocoTrack);
										_this.dialogSetProperty("/AvailableSpotSet", spotSet);
										spotSelect.setEnabled(true);
										spotSelect.setSelectedKey(sLocoSpot);
										directionSelect.setSelectedKey(sLocoDirection);
									}, 200);

									break;
								}
							}
						} else {
							var trackSelect = sap.ui.getCore().byId('arriveDialogFinishTrackSelect');
							var spotSelect = sap.ui.getCore().byId('arriveDialogFinishSpotSelect');
							var directionSelect = sap.ui.getCore().byId('arriveDialogFinishDirectionSegmentedButton');

							trackSelect.setSelectedKey(null);
							spotSelect.setSelectedKey(null);
							spotSelect.setEnabled(false);
							directionSelect.setSelectedKey(null);
						}

						_this.dialogSetProperty("/AvailableTrackSet", aTrackSet);
						fSuccess();
					},
					null
				);

				// End - SHE0272: LLM2.29 - Road/Yard Repair - New method of TrackSpotModel being called to get the data for both RYR and Non-RYR process
			},

			/**
			 * change track 
			 */
			onChangeTrack: function (oEvent) {
				var key = oEvent.getSource().getSelectedKey();
				var spotSelect = sap.ui.getCore().byId('arriveDialogFinishSpotSelect');
				var spotSet = _this.filterSpots(key);
				_this.dialogSetProperty("/AvailableSpotSet", spotSet);

				spotSelect.setEnabled(true);
				spotSelect.setSelectedItem(null);
			},

			/**
			 * Validate choosen arrival Track/Spot
			 */
			onValidateArriveTrackSpot: function () {
				var trackSelect = sap.ui.getCore().byId('arriveDialogFinishTrackSelect');
				var track = trackSelect.getSelectedKey();

				var spotSelect = sap.ui.getCore().byId('arriveDialogFinishSpotSelect');
				var spot = spotSelect.getSelectedKey();

				var arriveDialogFinishSTA = sap.ui.getCore().byId('arriveDialogFinishSTA');
				var shoppedTimestamp = arriveDialogFinishSTA.getValue();

				var arriveDialogFinishETR = sap.ui.getCore().byId('arriveDialogFinishETR');
				var etrTimestamp = arriveDialogFinishETR.getValue();

				if (!track || track.length === 0 || !spot || spot.length === 0 || !shoppedTimestamp || shoppedTimestamp.length === 0 || !
					etrTimestamp || etrTimestamp.length === 0) {
					ErrorManager.handleError("", "Please fill in all fields");
					return false;
				}

				if (shoppedTimestamp > etrTimestamp) {
					ErrorManager.handleError("", "Estimated Release Time cannot be earlier than Shopped Time");
					return false;
				}

				return true;
			},

			/**
			 * arrival backend successful callback
			 */
			onArriveInboundLocomotiveSuccess: function (oData) {
				_this._oArriveProcessDialog.close();

				BusyIndicator.hideBusyIndicator();

				var oLocomotive = _this.oModel.getProperty("/Locomotive");

				if (_this.type === "service") {
					oLocomotive.ShopReason = "S";
				}
				// Start - SHE0272: LLM2.29 - Road/Yard Repair - Updated Shop Reason to 'R' for Road/Yard Repair
				else if (_this.type === "roadYardRepair") {
					oLocomotive.ShopReason = "R";
				}
				// End - SHE0272: LLM2.29 - Road/Yard Repair - Updated Shop Reason to 'R' for Road/Yard Repair
				else {
					oLocomotive.ShopReason = "M";
				}

				var oEventBus = sap.ui.getCore().getEventBus();
				oEventBus.publish("ArriveManager", "arriveLocomotiveDone", {
					"origin": _this.origin,
					"locomotive": oLocomotive,
					"success": true
				});
			},

			/**
			 * arrival backend failure callback
			 */
			onArriveInboundLocomotiveFailure: function (oError) {

				BusyIndicator.hideBusyIndicator();

				// var oEventBus = sap.ui.getCore().getEventBus();
				// oEventBus.publish("ArriveManager", "arriveLocomotiveDone", {
				// 	"origin": _this.origin,
				// 	"success": false
				// });
			},

			/* Start KIR0084 LMP2-28 */
			/**
			 * confirm inbound backend successful callback
			 */
			onConfirmInboundLocomotiveSuccess: function (oData) {
				_this._oArriveProcessDialog.close();

				BusyIndicator.hideBusyIndicator();

				var oLocomotive = _this.oModel.getProperty("/Locomotive");

				var oEventBus = sap.ui.getCore().getEventBus();
				oEventBus.publish("ArriveManager", "confirmInboundLocomotiveDone", {
					"origin": _this.origin,
					"locomotive": oLocomotive,
					"success": true
				});
			},

			/**
			 * confirm inbound backend failure callback
			 */
			onArriveInboundonConfirmInboundLocomotiveFailureLocomotiveFailure: function (oError) {

				BusyIndicator.hideBusyIndicator();

				var oEventBus = sap.ui.getCore().getEventBus();
				oEventBus.publish("ArriveManager", "confirmInboundLocomotiveDone", {
					"origin": _this.origin,
					"success": false
				});
			},
			/* End KIR0084 LMP2-28 */

			// Start - SHE0272: LLM2.29 - New service call to get the mandatory note suggestion
			fnFetchMandatoryNote: function (oEvent) {
				var suggestionValue = oEvent.getSource().getValue();
				if (suggestionValue && suggestionValue.length > 2) {
					LocomotiveDataModel.fetchMandatoryNote(suggestionValue, _this.searchMandatoryNoteSuccess, null, _this);
				}
			},

			searchMandatoryNoteSuccess: function (oData) {
				if (oData) {
					_this.oModel.setProperty("/MandatoryNoteListResult", oData.results);
				}
			},

			onValidateMandatoryNoteSelected: function () {
				var MandatoryNoteListResult = _this.oModel.getProperty("/MandatoryNoteListResult");
				var MandatoryNote = _this.oModel.getProperty("/MandatoryNote");
				var dataExist = false;
				for (var i = 0; i < MandatoryNoteListResult.length; i++) {
					if (MandatoryNoteListResult[i].StationName === MandatoryNote) {
						dataExist = true;
						return dataExist;
					}
				}
				return dataExist;
			},
			// End - SHE0272: LLM2.29 - New service call to get the mandatory note suggestion
			
			// Start SHE0272: LLM2.23 - Primary Defect - Hide/Unhide primary action checkbox
			fnOnDefectSelection: function (oEvent) {
				if (_this.oModel && _this.oModel.getProperty("/ArrivalType") && _this.oModel.getProperty("/ArrivalType") ===
					"shopped") {
					var selectedItems = sap.ui.getCore().byId("arriveDialogDefectsTable").getItems();
					selectedItems.forEach(function (oSelContext) {
						var oSelObject = oSelContext.getSelected();
						if (oSelObject) {
							oSelContext.getCells()[2].setVisible(true);
						} else {
							oSelContext.getCells()[2].setVisible(false);
							oSelContext.getCells()[2].setSelected(false);
						}
					});
				}
			}
			// End SHE0272: LLM2.23 - Primary Defect - Hide/Unhide primary action checkbox
		};
	});