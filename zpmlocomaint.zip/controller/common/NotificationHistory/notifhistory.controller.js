/*&---------------------------------------------------------------------*    
* Author         : SAT0008						                        *
* Date           : 6-June-2019                                          *
* Project        : Locomotive Maintenance                               *
* Description    : This is the controller for the Notif History View    *
*&----------------------------------------------------------------------*/

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/util/ErrorManager",
	"com/sap/cp/lm/util/Helper",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel"
], function(Controller, Constants, Formatter, BusyIndicator, ErrorManager, Helper, LocomotiveDataModel)
 {
	"use strict";

	var _this;

	return Controller.extend("com.sap.cp.lm.controller.common.NotificationHistory.notifhistory", {
		
		//----------------------------------------------------------------------
		// Initialize functions
		//----------------------------------------------------------------------
		
		/**
		 * Initializes the controller
		 */
		onInit: function() {
			_this = this;

			this.getView().setModel(new sap.ui.model.json.JSONModel());
			this._oModel = this.getView().getModel();
			this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
			this._oI18nModel = this.getOwnerComponent().getModel("i18n");

			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());

			this._resetModelProperty();

		},
		
		//----------------------------------------------------------------------
		// Private functions
		//----------------------------------------------------------------------
		
		/**
		 * Reset the dates from and to for initial values
		 */
		_resetModelProperty: function() {
			var WOHistoryBuffer = _this._oGlobalModel.getProperty(Constants.ZPM_LM_WO_HISTORY_DAYS);
			var dNow = new Date();
			var dOld = Helper.removeDays(dNow, WOHistoryBuffer);
			_this.getView().getModel().setProperty("/WODateFrom", dOld);
			_this.getView().getModel().setProperty("/WODateTo", dNow);
		},
		
		/**
		 * load the work order history for current locomotive
		 */
		fetchNotifHistory: function(oLocomotive) {
			BusyIndicator.showBusyIndicator();

			var dStartDate = _this.getView().getModel().getProperty("/WODateFrom");
			var dEndDate = _this.getView().getModel().getProperty("/WODateTo");

			if(oLocomotive) {
				_this.oLocomotive = oLocomotive;				
			} else {
				_this.oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
			}
			
			if (_this.oLocomotive) {
				var sEquipNo;
				if (_this.oLocomotive.Equipment) {
					sEquipNo = _this.oLocomotive.Equipment;
				} else {
					sEquipNo = _this.oLocomotive.EquipNo;
				}
				if (sEquipNo && dStartDate && dEndDate) {

					var oPayload = {
						"EquipNo": sEquipNo,
						"OrderCategory": "H",
						"StartDate": dStartDate,
						"EndDate": dEndDate
					};

					LocomotiveDataModel.fetchWOHistory(oPayload, _this.loadNotifHistorySuccess, _this.loadNotifHistoryFailure,
						_this);
				} 
			}
		},
		
		/**
		 * history loading success callback
		 */
		loadNotifHistorySuccess: function(oData) {
			var dStartDate = _this.getView().getModel().getProperty("/WODateFrom");
			var dEndDate = _this.getView().getModel().getProperty("/WODateTo");
			var oData1 = [];

            for (var i = 0; i < oData.length; i++) {
            	if ( oData[i].DefectNo === "") {
            		
            	}else {
            		oData1.push(oData[i]);
            	}
            }
			if (oData1) {
				var oDetailsData = {
					"detailsData": {
						"results": oData1
					}
				};
				_this.getView().getModel().setData(oDetailsData);

				_this.getView().getModel().setProperty("/WODateFrom", dStartDate);
				_this.getView().getModel().setProperty("/WODateTo", dEndDate);

				var sEquipNo = _this.oLocomotive.Equipment;
				if(!sEquipNo) {
					sEquipNo = _this.oLocomotive.EquipNo;
				}
				
				var oParameters = {
					bindPath: "/detailsData/results",
					model: _this.getView().getModel(),
					locomotiveNumber: _this.oLocomotive.LocomotiveId,
					equipmentNo: sEquipNo,
					Description: _this.getView().getModel().getData().detailsData.Description,
					shiftlist: true
				};
				this.byId("notifHistory").getController().loadData(oParameters); //Added by Sandha LMP2-03
			}
		},
		
		/**
		 * history loading failed callback
		 */
		loadNotifHistoryFailure: function() {
			BusyIndicator.hideBusyIndicator();
		},
		
		//----------------------------------------------------------------------
		// Event handlers
		//----------------------------------------------------------------------

		onAfterRendering: function() {
			_this._resetModelProperty();
			// _this.fetchWOHistory();
		},
		
		

		/**
		 * handle date range selector
		 */
		onWODateRangeChange: function(oEvent) {
			var dFrom = oEvent.getParameter("from");
			var dTo = oEvent.getParameter("to");

			_this.getView().getModel().setProperty("/WODateFrom", dFrom);
			_this.getView().getModel().setProperty("/WODateTo", dTo);

			_this.fetchNotifHistory();
		}
	});
});