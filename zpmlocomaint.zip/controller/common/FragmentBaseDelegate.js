/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.21                                           *
* Project        : Locomotive Maintenance                               *
* Description    : Base Delegate for all the controllers Fragments      *
*                  common services like instantiating the fragments,    *
*                  Destroying & Initializing.                           *
*                  @extends sap.ui.base.EventProvider                   *
*                  @name rsh.eam.details1.controller.BaseDelegate       *
*&----------------------------------------------------------------------*/

// #DontDelete : Daya  New control class dont delete any method in this file
 
sap.ui.define([
		"sap/ui/base/EventProvider"
	], function(EventProvider) {
		"use strict";

		return EventProvider.extend("rsh.eam.details1.controller.BaseDelegate", {

			_oFragment: null,
			_sFragmentId: null,
			_sFragmentName: null,
			oParameters: null,
			
			//--------------------------------------------------------------------
			// Life cycle functions
			//--------------------------------------------------------------------
			
			/**
			 * Constructor will executed whenever new fragment instance is created
			 */
			constructor: function(mParameters) {
				sap.ui.base.EventProvider.prototype.constructor.apply(this, arguments);

				if ((!mParameters || !mParameters.fragmentName) && !this._sFragmentName) {
					throw new Error("Fragment name has to be provided");
				} else if (!this._sFragmentName) {
					this._sFragmentName = mParameters.fragmentName;
				}
				this.oParameters = mParameters;
			},

			getParameters: function() {
				return this.oParameters;
			},

			/**
			 * Destroys the objects and releases all object references.
			 */
			destroy: function() {
				// Invoke lifefycle hook
				this.onExit();

				// Destroy objects
				if (this._oFragment) {
					// Detach other lifecycle hooks
					this._oFragment.removeEventDelegate(this, this);
					this._oFragment.destroy();
				}

				// Reset properties
				this._oFragment = null;

				sap.ui.base.EventProvider.prototype.destroy.apply(this, arguments);
			},

			/**
			 * Hook method invoked once when the fragment is created.
			 */
			onInit: function() {},

			/**
			 * Hook method invoked before the fragment is rendered.
			 */
			onBeforeRendering: function() {},

			/**
			 * Hook method invoked after the fragment is rendered.
			 */
			onAfterRendering: function() {},

			/**
			 * Hook method invoked once when the delegate is destroyed.
			 */
			onExit: function() {},
			
			//----------------------------------------------------------------------
			// Private functions
			//----------------------------------------------------------------------
			
			/**
			 * Creates the fragment from the fragment name provided to the delegate and assigns a generated id.
			 * @private
			 *
			 * @returns {sap.ui.core.Element|sap.ui.core.Element[]} the root element of the fragment or an array of elements.
			 */
			_createFragment: function() {
				$.sap.assert(this._sFragmentName, "Trying to instantiate fragment but fragmentName is not provided.");
				this._sFragmentId = $.sap.uid();
				this._oFragment = sap.ui.xmlfragment(this._sFragmentId, this._sFragmentName, this);

				// Invoke lifecycle hook
				this.onInit();

				// Register other looks like onBeforeRendering, etc.
				this._oFragment.addEventDelegate(this, this);

				return this._oFragment;
			},

			/**
			 * Internal utility functionfor accessing an element inside the fragment by its id.
			 *
			 * @param {string}
			 *            sId the id of the element inside the fragment.
			 * @returns {sap.ui.core.Element} the element matching the id.
			 */
			byId: function(sId) {
				return sap.ui.core.Fragment.byId(this._sFragmentId, sId);
			},

			/**
			 * Internal utility functionfor creating an id for an element inside the fragment.
			 *
			 * @param {string}
			 *            sId the id of the element inside the fragment.
			 * @returns {string} the id.
			 */
			createId: function(sId) {
				return sap.ui.core.Fragment.createId(this._sFragmentId, sId);
			},

			/**
			 * Returns the fragment.
			 *
			 * @returns {sap.ui.core.Element} the root element of the fragment.
			 */
			getFragment: function() {
				if (!this._oFragment) {
					this._createFragment();
				}
				return this._oFragment;
			},

			/**
			 * Checks whether the fragment has already been created.
			 *
			 * @returns {boolean} true of fragment has been created, false otherwise.
			 */
			isFragmentCreated: function() {
				return !!this._oFragment;
			}

		});
	}

);