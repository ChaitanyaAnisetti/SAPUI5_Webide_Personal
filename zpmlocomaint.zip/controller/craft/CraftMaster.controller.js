/*&---------------------------------------------------------------------*    
 * Author         : SAP Custom Development                               *
 * Date           : 2017.12.21                                           *
 * Project        : Locomotive Maintenance                               *
 * Description    : Controller for the Craft Master view used            *
 *                  on Craft page.                                       *
 *&----------------------------------------------------------------------*/
// #DontDelete : Daya New controller class , Do not delete any method in this class

sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"com/sap/cp/lm/util/Constants",
		"com/sap/cp/lm/util/Formatter",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
		"com/sap/cp/lm/model/craft/CraftDataModel",
		"com/sap/cp/lm/controller/locomotives/LocomotiveManager",
    	'sap/m/MessageBox',
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"com/sap/cp/lm/controller/craft/CraftSearchManager"
	],

	function (Controller, Constants, Formatter, BusyIndicator, LocomotiveDataModel, CraftDataModel, LocomotiveManager, MessageBox, Filter, FilterOperator,
		CraftSearchManager) {
		"use strict";
		var _this;

		return Controller.extend("com.sap.cp.lm.controller.craft.CraftMaster", {

			//--------------------------------------------------------------------
			// Life cycle functions
			//--------------------------------------------------------------------

			onInit: function () {
				_this = this;

				// set an empty model to avoid premature requests
				this.getView().setModel(new sap.ui.model.json.JSONModel());
				this._oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());

				this._oI18nModel = this.getOwnerComponent().getModel("i18n");

				this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
				this._oGlobalLocomotiveModel = this.getOwnerComponent().getGlobalLocomotiveModel();

				var binding = new sap.ui.model.Binding(this._oGlobalLocomotiveModel, "/", this._oGlobalLocomotiveModel.getContext("/"));
				this._oGlobalModel.setProperty("/CraftMasterController", this);
				_this.loadMasterCraftData();

				binding.attachChange(function () {
					_this.loadMasterCraftData();
				});

				this._oViewPropertiesModel = new sap.ui.model.json.JSONModel();
				this._initViewPropertiesModel();
				this.getView().setModel(this._oViewPropertiesModel, "viewProperties");
				// listen to event when list need refreshing
				var oEventBus = sap.ui.getCore().getEventBus();
				oEventBus.subscribe("craftMasterPage", "onRefreshMasterList", _this.onRefreshMasterList, _this);

				_this.loadCraftSearchFragment();
			},

			//----------------------------------------------------------------------
			// Private functions
			//----------------------------------------------------------------------

			/**
			 * Load the the list in master page when the plant/shop selection is changed
			 */
			loadMasterCraftData: function () {

				if (this._oGlobalModel.getProperty("/sSelectedView") !== Constants.CRAFT) {
					return;
				}

				if (_this._isReloadRequired()) {
					_this.fetchCraftList(_this.sCurrentShopId);
				} else {
        		    if (!_this._oGlobalModel.getProperty("/currentCraft")) {
    					window.setTimeout(function () {
    						_this._oRouter.getTargets().display("CraftBlankDetails");
    					}, 0);
        		    }
				}
			},

			/**
			 * Check whether reload locomotives required
			 */
			_isReloadRequired: function () {
				var sNewShopID;
				if (_this._oGlobalModel.getProperty("/currentShop")) {
					sNewShopID = _this._oGlobalModel.getProperty("/currentShop").Id;
				} else if (_this._oGlobalModel.getProperty("/newShop")) {
					sNewShopID = _this._oGlobalModel.getProperty("/newShop").Id;
				}

				if (_this.sCurrentShopId !== sNewShopID) {
					_this.sCurrentShopId = sNewShopID;
					return true;
				}

				return false;
			},

			/**
			 * Create the view properties model for this view. 
			 */
			_initViewPropertiesModel: function () {
				var bHideMaster = false;
				if (this.getOwnerComponent().isIPadMode()) {
					bHideMaster = true;
				}
				this._oViewPropertiesModel.setProperty("/HideMaster", bHideMaster);

			},

			/**
			 * Load Craft Search Manager and display fragment
			 */
			loadCraftSearchFragment: function () {
				if (_this._oCraftSearchManager) {
					_this._oCraftSearchManager.destroy();
				}
				_this._oCraftSearchManager = new CraftSearchManager();
				_this._oCraftSearchManager = _this._oCraftSearchManager.init(_this, _this.onRefreshMasterList, _this.getView().byId("craftList"));

				if (_this._oCraftSearchFragment) {
					_this._oCraftSearchFragment.destroy();
				}
				_this._oCraftSearchFragment = _this._oCraftSearchManager.getFragment();
				_this.getView().byId("craftSearchToolbar").addContent(_this._oCraftSearchFragment);

				_this._oCraftSearchManager.onFirstPass();
			},

			fetchCraftList: function (sShopId, bNoNavigate) {
				LocomotiveDataModel.fetchCraftWorkPlanList(function(data, oResponse) {
				    _this.onSuccessCraftList(data, oResponse, bNoNavigate);
				}, null, this, sShopId);
			},

			loadWorkPlan: function (sSelectedItemPath) {
				var oCraft = this.getView().getModel().getProperty(sSelectedItemPath);
				_this._oGlobalModel.setProperty("/currentCraft", oCraft);

				BusyIndicator.showBusyIndicator();
				window.setTimeout(function () {
					_this._oRouter.getTargets().display("CraftDetails", oCraft);
				}, 0);
			},

			//----------------------------------------------------------------------
			// Event handlers
			//----------------------------------------------------------------------

			onHideMaster: function () {
				var oEventBus = sap.ui.getCore().getEventBus();
				oEventBus.publish("CraftSC", "toggleSplitContainerShowMaster", {
					"hideMaster": true
				});
			},
			
			onEndCraftAssignmentPress: function() {
				MessageBox.show(this._oI18nModel.getProperty("CONFIRM_END_CRAFT_ASSIGNMENT"), {
    		      	icon: MessageBox.Icon.CONFIRM,
    			    title: this._oI18nModel.getProperty("CONFIRM_END_CRAFT_ASSIGNMENT_TITLE"),
    			    actions: [MessageBox.Action.CANCEL, MessageBox.Action.OK],
    			    onClose: function(oEvent) {
        				var sCurrentShopId = this._oGlobalModel.getProperty("/currentShop").Id;
    			        if (oEvent === MessageBox.Action.OK) {
    			            LocomotiveDataModel.removeCraftsForShiftEnd({
    			                Shop: sCurrentShopId,
    			                ShiftEndTime: new Date()
    			            }, function() {
    			                MessageBox.success(this._oI18nModel.getProperty("END_CRAFT_ASSIGNMENT_SUCCESS"));
                				LocomotiveDataModel.fetchCraftWorkPlanList(function(data, oResponse) {
                				    _this.onSuccessCraftList(data, oResponse, true);
                				}, null, this, sCurrentShopId);
    			            }.bind(this), function(error) {
    			                MessageBox.error(error.message);
    			            }, true);
    			        }
    			    }.bind(this)
    			});
			},

			/**
			 * Function gets fired which refresh list is clicked
			 */

			onRefreshMasterList: function (bNoNavigate) {
				var sCurrentShopId = this._oGlobalModel.getProperty("/currentShop").Id;
				_this.fetchCraftList(sCurrentShopId, bNoNavigate);
			},

			onSuccessCraftList: function (oData, oResponse, bNoNavigate) {
				_this.getView().getModel().setProperty("/CraftList", oData.results);
				
				if (bNoNavigate  !== true) {
    				window.setTimeout(function () {
    					_this._oRouter.getTargets().display("CraftBlankDetails");
    				}, 0);
				}
			},

			onSelectCraft: function (oEvent) {
				var sSelectedItemPath = oEvent.getSource().getSelectedItem().getBindingContext().getPath();
				this.loadWorkPlan(sSelectedItemPath);
			}
		});
	});