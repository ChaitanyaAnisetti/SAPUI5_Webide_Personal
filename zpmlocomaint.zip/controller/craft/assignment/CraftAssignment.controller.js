/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.21                                           *
* Project        : Locomotive Maintenance                               *
* Description    : Controller for the Notes fragment on the Craft       *
*                  page for a worker.                                   *
*&----------------------------------------------------------------------*/

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/controller/craft/craftAssignment/CraftAssignmentManager",
	"com/sap/cp/lm/controller/map/MapManagerObject",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel"
], function(Controller, Constants, Formatter, BusyIndicator, CraftAssignmentManager, MapManager, LocomotiveDataModel) {
	"use strict";


	return Controller.extend("com.sap.cp.lm.controller.craft.assignment.CraftAssignment", {
		
		//--------------------------------------------------------------------
		// Life cycle functions
		//--------------------------------------------------------------------
		MapManager: undefined,
		_sViewName: "craft",
		/**
		 * Initializes the controller
		 */
		onInit: function() {
			if (this.getOwnerComponent()) {
				this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
				this._oGlobalLocomotiveModel = this.getOwnerComponent().getGlobalLocomotiveModel();
    			this._oI18nModel = this.getOwnerComponent().getModel("i18n");
			}
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());

			this._oDrag = null;
			this._oZoom = null;
			
			this._spots = this._oGlobalModel.getProperty("/spots");
			
			this._initViewPropertiesModel();
			
			this._setupShopChangeListener(); 
		},
		
		onAfterRendering: function() {
			var mapContainer = this.getView().byId("CraftAssignmentMapContainer");
			this._oMapManager = new MapManager(mapContainer);
			this._drawMap();
		},
			
		showMapWarning: function(aMissingSpots) {
			this._oViewPropertiesModel.setProperty("/ShowMapWarning", true);
			this._oViewPropertiesModel.setProperty("/MissingSpots", aMissingSpots);
		},

		hideMapWarning: function() {
			this._oViewPropertiesModel.setProperty("/ShowMapWarning", false);
			this._oViewPropertiesModel.setProperty("/MissingSpots", null);
		},
		
		_drawMap: function() {
		    setTimeout(this._refreshMap.bind(this), 1);
		    setTimeout(this._drawMyShopMap.bind(this), 500);
			setTimeout(this._fetchMapLocomotives.bind(this), 1000);	
			this.handleWindowResize();
		} ,
		
		//--------------------------------------------------------------------
		// Private functions
		//--------------------------------------------------------------------
			
		/** 
		 * Draw the my shop map with the locomotives
		 */
		_drawMyShopMap: function() {
			// console.log("_drawMyShopMap");

			var mapContainer = this.getView().byId("CraftAssignmentMapContainer");
				$(window).on('resize', $.proxy(this.handleWindowResize, this));

			var oDragNZoom = this._oMapManager.drawMap({
				globalModel: this._oGlobalModel,
				container: mapContainer,
				svgWidth: this._d3Width,
				svgHeight: this._d3Height,
				parentController: this,
				requestSpot: false
			});

			if (oDragNZoom) {
				this._oDrag = oDragNZoom.drag;
				this._oZoom = oDragNZoom.zoom;
			}
		},
		
		/**
		 * Sets height of the shop page
		 */
		handleWindowResize: function() {
            var frame = $("[id$=--CraftDetailPageTabBar-content]");
			var mapContainer = $(this.getView().byId("CraftAssignmentMapContainer").getIdForLabel());
			// calculate the width and height to be used in the SVG
			mapContainer.height(frame.height());
			mapContainer.width(frame.width());
			this._d3Width = frame.width(); //1024
			this._d3Height = frame.height(); //416
		},
			
		_refreshMap: function() {
			var main = d3.select("#CraftAssignmentMain");
			// set the main <g>, zoom, drag n drop function calls to the map manger
			var oParameters = {
				main: main,
				fZoom: this._oZoom,
				fDrag: this._oDrag,
				mode: "CraftAssignment",
				onSpotPress: this.onSpotPress.bind(this),
				onLocomotivePress: this.onLocomotivePress.bind(this),
				onConflictPress: this.onConflictPress.bind(this),
				onMoveLocomotive: this.onMoveLocomotive.bind(this),
				oContext: this
			};
			                 
			this._oMapManager.setSVGMain(oParameters);
			// load the locomotives for the shop
			// if (this._shopId !== "") {
			// 	// check if the spots needs to be rerendered in case where the spots have been disabled 
			// 	var renderMap = this._oGlobalModel.getProperty("/renderMap");
			// 	if (renderMap) {
			// 		MapManager.resetSpots();
			// 		this._oGlobalModel.setProperty("/renderMap", !renderMap);
			// 	}
			//	this._fetchMapLocomotives();
			// }
			// show/hide spot text
			this._oMapManager.toggleSpotText.call(this._oMapManager, false);
		},
			
		_shopChanged:function() {
			var oShift = this._oGlobalModel.getProperty("/currentShift");
			this._applyShift(oShift);
			
		},
		
		_reloadCurrentShift:function() {
			var oShift = this._oGlobalModel.getProperty("/currentShift");
			this._setShiftTime(oShift);
		},

		_setShiftTime: function(oShift) {
			if (oShift) {
				this._oViewPropertiesModel.setProperty("/ShiftStartTime", oShift.ShiftStart);
				this._oViewPropertiesModel.setProperty("/ShiftEndTime", oShift.ShiftEnd);
			}
		},
			
		/**
		 * Create the view properties model for this view. 
		 */
		_initViewPropertiesModel: function() {
			this._oViewPropertiesModel = new sap.ui.model.json.JSONModel();
			this._oViewPropertiesModel.setProperty("/IsCurrentShift", true);
			this._oViewPropertiesModel.setProperty("/ShowMapWarning", false);
			this.getView().setModel(this._oViewPropertiesModel, "viewProperties");
			this._reloadCurrentShift();
			
		},

		/**
		 * Empty Spot pressed on the map
		 * @param(string) sSpot is the spot number
		 */
		onSpotPress: function(sSpot) {

		},

		/**
		 * Adapt map drag/drop behavior depending on user role
		 */
		canDrag: function() {
			return false;
		},

		/**
		 * Locomotive press on the map
		 * @param(object) oLocomotive is the data of the locomotive
		 */
		onLocomotivePress: function(oLocomotive) {
			var oCraftAssignmentManager = CraftAssignmentManager.init(this);

			if (!this._oCraftAssignmentDialog) {
				this._oCraftAssignmentDialog = sap.ui.xmlfragment("com.sap.cp.lm.view.craft.craftAssignment.CraftAssignmentListDialog",
					oCraftAssignmentManager);
				this.getView().addDependent(this._oCraftAssignmentDialog);
			}

			oCraftAssignmentManager.openDialog({
			    craft: this._oGlobalModel.getProperty("/currentCraft"),
			    locomotive: oLocomotive
			});
		},
			
		onConflictPress: function(oLocomotive) {
			var trackSpot = oLocomotive.TrackSpot;
			var plannedTrackSpot = oLocomotive.PlannedTrack + "/" + oLocomotive.PlannedSpot;
			console.error("Conflict : " + oLocomotive.LocomotiveId + " is at " + trackSpot + " but was planned at " + plannedTrackSpot);
		},

		onMoveLocomotive: function(oLocomotive, oPayload, fSuccess, fFailure) {
			if (this._oViewPropertiesModel.getProperty("/IsCurrentShift") !== true) {
				var dStartShift = this._oViewPropertiesModel.getProperty("/ShiftStartTime");
				oPayload["ShiftStartTs"] = Formatter.changeToUTCTimestamp(dStartShift);
			}

			LocomotiveDataModel.moveSelectedLocomotive(oPayload, fSuccess, fFailure, this);
		},
		
		_setupShopChangeListener: function() {
			var oEventBus = sap.ui.getCore().getEventBus();
			
		    var fnShoppedLocomotivesSuccess = function(oData) {
				this._oGlobalLocomotiveModel.setProperty("/Shopped", oData.results);
				BusyIndicator.hideBusyIndicator();
		        this._drawMap();
		    }.bind(this);
		    
			var sShopId = this._oGlobalModel.getProperty("/currentShop").Id;
			
			oEventBus.subscribe("ShopChanged", "shopCraftChangedDone", LocomotiveDataModel.fetchShoppedLocomotives.bind(LocomotiveDataModel, sShopId, fnShoppedLocomotivesSuccess, this._showError, this), this);
		},
		
        _fetchMapLocomotives: function() {
			if(!this._oViewPropertiesModel) {
				console.log("_fetchMapLocomotives cancelled");
				return;
			}
			
			this.aDrawingLocomotives = [];
			var aLocomotives = [];

			var isCurrentShift = this._oViewPropertiesModel.getProperty("/IsCurrentShift");

			if (isCurrentShift) {
				aLocomotives = this._oGlobalLocomotiveModel.getProperty("/Shopped");
			} else {
				aLocomotives = this._oGlobalLocomotiveModel.getProperty("/Planned");
			}

			$.each(aLocomotives, function(i, loco) {
				if (loco.Track && loco.Spot && loco.Track !== "" && loco.Spot !== "") {
					loco.TrackSpot = loco.Track + "-" + loco.Spot;
					this.aDrawingLocomotives.push(loco);
				}
			}.bind(this));

			if (this.aDrawingLocomotives && this.aDrawingLocomotives.length > 0) {
				if (this._oViewPropertiesModel.getProperty("/IsCurrentShift")) {
					this._oMapManager.drawLocomotives(this.aDrawingLocomotives);
				} else {
					this._oMapManager.displayPlannedLocomotives(this.aDrawingLocomotives);
				}
			}
        }
	});
});