/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.05                                           *
* Project        : Locomotive Maintenance                               *
* Description    : This is the manager for view Craft Blank Details.    *
*&----------------------------------------------------------------------*/

sap.ui.define([
	"sap/ui/core/mvc/Controller"

], function(Controller) {
	"use strict";

	return Controller.extend("com.sap.cp.lm.controller.craft.CraftBlankDetails", {

		/**
		 * Function is called when Controller is loaded only for the first time 
		 */
		onInit: function() {

		}

	});
});