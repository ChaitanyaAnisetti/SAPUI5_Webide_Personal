// #DontDelete : Daya New controller class , Do not delete any method in this class
/*&----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2019.02.03                                           *
 * Incidinet      : EAM-ASR3413183 - PM Loco Main phase 2                *
 * Description    : Logic added for the Over Time                        *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2020.10.26                                           *
 * Incidinet      : Time entry error message                             *
 * Description    : Revised logic for time entry error message processing*
 *&----------------------------------------------------------------------*/
jQuery.sap.declare("com.sap.cp.lm.controller.craft.CraftManager");

sap.ui.define([
		"com/sap/cp/lm/util/Constants",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
		"com/sap/cp/lm/util/Formatter",
		"com/sap/cp/lm/model/craft/CraftDataModel",
		"com/sap/cp/lm/util/BusyIndicator",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"sap/ui/model/Sorter",
		"com/sap/cp/lm/controller/myShop/shopped/addMaterial/AddMaterial",
		"com/sap/cp/lm/util/ErrorManager"
	],
	function (Constants, LocomotiveDataModel, Formatter, CraftDataModel, BusyIndicator, Filter, FilterOperator, Sorter, AddMaterial,
		ErrorManager) {
		"use strict";

		var _this;

		return com.sap.cp.lm.controller.craft.CraftManager = {

			//--------------------------------------------------------------------
			// Life cycle functions
			//--------------------------------------------------------------------

			/**
			 * Initialize of CraftManager class
			 */
			init: function (oMainModel, oGlobalModel, oGlobalMyWorkModel) {
				_this = this;
				this._oMainModel = oMainModel;
				_this._oGlobalModel = oGlobalModel;

			},

			//--------------------------------------------------------------------
			// Private functions
			//--------------------------------------------------------------------

			/**
			 * Fetch List of Operations assigned to Craft
			 */
			openCraftListView: function (oSourceViewController) {
				_this._oSourceViewController = oSourceViewController;
				var sShopId = this._oGlobalModel.getProperty("/currentShop").Id;
				CraftDataModel.fetchCraftworkPlanListView(_this.onSuccessLoadCraftList, _this.onErrorLoadCraftList, sShopId);
			},

			/**
			 * Send request to confirm operation
			 */
			beginOperation: function () {
				var oPayload = this.prepareBeginOperationPayload();
				LocomotiveDataModel.ConfirmOperation(oPayload, _this.onSuccessBeginOperation, _this.onErrorSubmitOperation, _this);
			},

			/**
			 * Get operation materials and open dialog
			 */
			openMatWindow: function () {
				if (!this._oMatWindow) {
					this._oMatWindow = sap.ui.xmlfragment(
						"com.sap.cp.lm.view.myWork.MaterialsAdjustment",
						this
					);
				}

				var aMaterials = this._oSelectedContext.getObject().MaterialSet.results;
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setProperty("/craftOperationMat", aMaterials);

				this._oSourceViewController.getView().addDependent(this._oMatWindow);
				this._oMatWindow.setModel(oModel);
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this._oSourceViewController.getView(), this._oMatWindow);
				this._oMatWindow.open();
			},

			/**
			 * Time recording window
			 */
			openCatsWindow: function (bFinalConfirmation) {
				if (!_this._oCompleteOperation) {
					_this._oCompleteOperation = sap.ui.xmlfragment(
						"com.sap.cp.lm.view.myWork.endOperation",
						this
					);
				}

				var oDataObject = {};
				oDataObject.PlannedDuration = _this._oSelectedContext.getObject().PlanWorkDur;
				oDataObject.CatsAmount = "";
				oDataObject.bOverTime = false; //""; lmp2-29
				oDataObject.bFinalConfirmation = bFinalConfirmation || false;

				oDataObject.bApplyToServGr = false; //""; //LMP2-29

				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setProperty("/PlannedDuration", oDataObject.PlannedDuration);
				oModel.setProperty("/CATSAMOUNT", oDataObject.CatsAmount);
				/*Added by Vikram	*/
				oModel.setProperty("/bOverTime", oDataObject.bOverTime);
				/*Added by Vikram	*/
				oModel.setProperty("/bFinalConfirmation", oDataObject.bFinalConfirmation);
				oModel.setProperty("/bApplyToServGr", oDataObject.bApplyToServGr); //LMP2-29
				_this._oSourceViewController.getView().addDependent(_this._oCompleteOperation);
				_this._oCompleteOperation.setModel(oModel);
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this._oSourceViewController.getView(), this._oCompleteOperation);
				this._oCompleteOperation.open();
			},

			/**
			 * Create time entries in model
			 */
			submitTime: function (aDuration) {
				//Start : LMP2-29
				// var oTimeSheetModel = this._oSourceViewController.getOwnerComponent().getModel("pmTimeSheetModel");
				// if (aDuration.bApplyToServGr) {
				// 	var aServGroup = this._oGlobalModel.getProperty("/ServiceGroupList");
				// 	var j = aServGroup.length;
				// 	var k = aDuration.CATSAMOUNT;
				// 	k = k / j;
				// 	aDuration.CATSAMOUNT = k.toString();
				// } else {
				// 	j = 1;
				// }
				//END : LMP2-29
				var oTimeSheetModel = this._oSourceViewController.getOwnerComponent().getModel("pmTimeSheetModel");
				BusyIndicator.showBusyIndicator();
				//	oTimeSheetModel.setUseBatch(false);

				// for (var i = 0; i < j; i++) {
				var oPayload = this.preparePayload(aDuration);

				// if (aDuration.bApplyToServGr) {
				// 	oPayload.TimeEntryDataFields.RAUFNR = aServGroup[i].OrderNo;
				// }
				//	oTimeSheetModel.setUseBatch(true);

				oTimeSheetModel.create("/TimeEntries",
					oPayload, {
						success: function (oData) {
							BusyIndicator.hideBusyIndicator();
							_this._oCompleteOperation.close();
							_this.reloadData();
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							_this._oCompleteOperation.close();
							ErrorManager.handleError(oError);
							_this.reloadData();
						}
					}
				);
				// 	setTimeout(function(){
				// 		_this._oCompleteOperation.close();
				// 	}, 150000);
				// }
			},

			//KIR0084 LMP2 Submit time before completing operation to prevent errors
			submitTimeEntries: function (aDuration, fnSuccessCallback, fnErrorCallback) {
				var oTimeSheetModel = this._oSourceViewController.getOwnerComponent().getModel("pmTimeSheetModel");
				BusyIndicator.showBusyIndicator();
				//	oTimeSheetModel.setUseBatch(false);

				// for (var i = 0; i < j; i++) {
				var oPayload = this.preparePayload(aDuration);

				// if (aDuration.bApplyToServGr) {
				// 	oPayload.TimeEntryDataFields.RAUFNR = aServGroup[i].OrderNo;
				// }
				//	oTimeSheetModel.setUseBatch(true);

				oTimeSheetModel.create("/TimeEntries",
					oPayload, {
						success: function (oData) {
							_this._oCompleteOperation.close();
							BusyIndicator.hideBusyIndicator();

							if (fnSuccessCallback) {
								fnSuccessCallback.call(this);
							}
						},
						error: function (oError) {
							BusyIndicator.hideBusyIndicator();
							// start- baj0018 - time entry fix
							//		if (oError.responseText.includes("SY/530")) {
							if ((oError.responseText.includes("severity")) && (oError.responseText.includes("warning"))) {
								// end- baj0018 - time entry fix		
								ErrorManager.handleError(oError, undefined, undefined, "Warning");
								_this._oCompleteOperation.close();
								fnSuccessCallback.call(this);
							} else {
								ErrorManager.handleError(oError);
								this.reloadData();

								if (fnErrorCallback) {
									fnErrorCallback.call(this, oError);
								}
							}
						}
					}
				);
			},
			//KIR0084 LMP2 Submit time before completing operation to prevent errors

			/**
			 * Send request to confirm an operation
			 */
			confirmOperation: function (aDuration) {
				// KIR0084 Fixed type in FinaConfirmation to be FinalConfirmation
				//	var oPayload = this.prepareOperationConfirmationPayload(aDuration.bFinalConfirmation); //LMP2-29:Commented
				var oPayload = this.prepareOperationConfirmationPayload(aDuration.bFinalConfirmation, aDuration.bApplyToServGr, aDuration.CATSAMOUNT); //LMP2-29:Added
				// KIR0084 Check if there is a callback function set up, if so perform callback before continuing	
				if (_this.onEndWorkforOperationCallback) {
					// Call the call back function before submitting the operation, call back function should be to submit the time
					_this.onEndWorkforOperationCallback(function () {
						LocomotiveDataModel.ConfirmOperation(oPayload, _this.onSuccessSubmitOperation, _this.onErrorSubmitOperation, _this);
					});
					_this.onEndWorkforOperationCallback = undefined;
				} else {
					LocomotiveDataModel.ConfirmOperation(oPayload, _this.onSuccessSubmitOperation, _this.onErrorSubmitOperation, _this);
				}
			},

			/**
			 * Send request to adjust material with changes
			 */
			submitMaterialChanges: function () {

				var oPayload = this.prepareMaterialsPayload();
				LocomotiveDataModel.AdjustMaterials(oPayload, _this.onSuccessMaterials, _this.onErrorMaterials, _this);
			},

			/**
			 * Reload the target view
			 */
			reloadData: function () {
				if (_this._oGlobalModel.getProperty("/sSelectedView") === Constants.MYWORK) {
					if (this._oSourceViewController.refreshMyWork) {
						this._oSourceViewController.refreshMyWork(true);
					} else if (this._oSourceViewController._fetchAndRefreshView) {
						this._oSourceViewController._fetchAndRefreshView();
					}
				} else {
					var oParentOrder = this._oSelectedContext.getModel().getObject(this._oSelectedContext.sPath.split("/OperationSet")[0]);
					this._oSourceViewController.refreshViewfromServiceGroup(oParentOrder.LocoId, oParentOrder.EquipNo);
				}
			},

			//--------------------------------------------------------------------
			// Event handlers
			//--------------------------------------------------------------------

			/**
			 * Success Call back
			 */
			onSuccessLoadCraftList: function (oData) {

			},

			/**
			 * On user click Begin Operation
			 */
			onBeginWorkforOperation: function (oContext, oSourceViewController) {
				_this._oSourceViewController = oSourceViewController;
				this._oSelectedContext = oContext;
				this.beginOperation();
			},

			/**
			 * On User click End Operation
			 */
			onEndWorkforOperation: function (oContext, oSourceViewController, bFinalConfirmation, onEndWorkforOperation) {
				_this._oSourceViewController = oSourceViewController;
				this._oSelectedContext = oContext;

				_this.onEndWorkforOperationCallback = onEndWorkforOperation;

				// this.openMatWindow();
				_this.openCatsWindow(bFinalConfirmation);
			},

			/**
			 * When user select to add new materials
			 */
			onAddMaterials: function (oEvent) {
				if (!_this._oAddMaterialDialog) {
					_this._oAddMaterialDialog = AddMaterial.init(_this, _this.onAfterSelectingMaterials);
				}
				var oSelectedOperation = this._oSelectedContext.getObject();
				_this.isFromMyWork = true;
				_this._oAddMaterialDialog.onAddMaterialDialogOpen(oSelectedOperation);
			},

			/**
			 * After adding the materials to Operation update them in the current material window
			 */
			onAfterSelectingMaterials: function () {
				var oMaterialsforAdjust = _this._oMatWindow.getModel().getProperty("/craftOperationMat");
				_this.oSelectedMat.forEach(function (oItem) {
					oMaterialsforAdjust.push(oItem);
				});
				var oModel = _this._oMatWindow.getModel();
				oModel.setProperty("/craftOperationMat", oMaterialsforAdjust);
			},

			/**
			 * Close material popup
			 */
			onCancelMaterialsPopup: function () {
				_this._oMatWindow.close();
			},

			/**
			 * After adjusting materials open CatsX window
			 * Dont trigger call to update materials at this point
			 */
			onModifyMaterialsPoup: function () {
				_this._oMatWindow.close();
				_this.openCatsWindow();
			},

			/**
			 * When user click on Save send Both Adjusted Materials  & Operation confirmation
			 */
			onCompleteOperation: function (oEvent) {
				var oOperationModel = oEvent.getSource().getModel();
				var aDuration = {};

				aDuration.CATSAMOUNT = oOperationModel.getProperty("/CATSAMOUNT");
				/*Added by Vikram	*/
				// if (aDuration.wageType) {
				// 	aDuration.wageType = oOperationModel.getProperty("/wageType");
				// 	aDuration.wageType = aDuration.wageType.split("(")[1].split(")")[0];
				// }
				aDuration.bOverTime = oOperationModel.getProperty("/bOverTime");
				/*Added by Vikram	*/
				// KIR0084 Fixed type in FinaConfirmation to be FinalConfirmation
				aDuration.bFinalConfirmation = oOperationModel.getProperty("/bFinalConfirmation");
				//Start : LMP2-29:Apply to servicing group
				aDuration.bApplyToServGr = oOperationModel.getProperty("/bApplyToServGr");
				aDuration.OrderCount = this._oGlobalModel.getProperty("/OrderCount");
				//End:LMP2-29 
				this._aDuration = aDuration;

				// KIR0084 Switch to submit time sheet first
				if (aDuration.bApplyToServGr) {
					this.confirmOperation(this._aDuration);
				} else {
					this.submitTimeEntries(aDuration, this.confirmOperation.bind(this, aDuration));
				}
				// this.submitMaterialChanges();
				// this.confirmOperation(this._aDuration);
			},

			/**
			 * Close Dialog
			 */
			onCancelCompleteOperation: function (oEvent) {
				this._oCompleteOperation.close();
			},

			/**
			 * Reload the data
			 */
			onSuccessBeginOperation: function () {
				this.reloadData();
			},

			/**
			 * After successfull updation of Operation confirmation record the time
			 */
			onSuccessSubmitOperation: function (oResponse) {
				if (_this._aDuration.bApplyToServGr) {
					_this._oCompleteOperation.close();
					_this.reloadData();
				} else {
					_this.reloadData();
					//_this.submitTime(_this._aDuration);
				}
			},

			onErrorSubmitOperation: function () {
				_this._oCompleteOperation.close();
				_this.reloadData();
			},

			onSuccessMaterials: function () {

			},

			onErrorMaterials: function () {

			},
			/*Added by Vikram	*/
			// onWageTypeValueHelp: function (oEvent) {
			// 	// check if value help is already retrieved
			// 	var oWageTypeValueHelp = this._oGlobalModel.getProperty("/wageTypeVH");
			// 	if (!oWageTypeValueHelp) {
			// 		var oTimeEntryModel = this._oSourceViewController.getOwnerComponent().getModel("pmTimeSheetModel");
			// 		var oDate = new Date();
			// 		var oMonth = (oDate.getMonth() + 1).toString();
			// 		oMonth = (oMonth[1] ? oMonth : "0" + oMonth[0]);
			// 		var oDay = oDate.getDate().toString();
			// 		oDay = (oDay[1] ? oDay : "0" + oDay[0]);
			// 		var sDate = oDate.getFullYear() + oMonth + oDay;
			// 		BusyIndicator.showBusyIndicator();
			// 		var oGlobalModel = this._oGlobalModel;
			// 		var openWageTypeFn = this._openWageTypeValueHelp;
			// 		var oCurrentViewController = this;
			// 		oTimeEntryModel.read("/ValueHelpList", {
			// 			urlParameters: {
			// 				"$filter": "Pernr eq '" + this._oSelectedContext.getObject().PersonNo +
			// 					"' and FieldName eq 'LGART' and StartDate eq '" + sDate +
			// 					"' and EndDate eq '" + sDate + "'"
			// 			},
			// 			success: function (oData) {
			// 				BusyIndicator.hideBusyIndicator();
			// 				oGlobalModel.setProperty("/wageTypeVH", oData.results);
			// 				openWageTypeFn(oCurrentViewController);
			// 			},
			// 			error: function (oError) {
			// 				BusyIndicator.hideBusyIndicator();
			// 				ErrorManager.handleError(oError);
			// 			}
			// 		});
			// 	}

			// 	//create fragment and open it
			// 	else {
			// 		this._openWageTypeValueHelp(this);
			// 	}

			// },

			// _openWageTypeValueHelp: function (oCurrentViewController) {
			// 	if (!oCurrentViewController.wageTypeFragment) {
			// 		//Instantiate a new fragment
			// 		oCurrentViewController.wageTypeFragment = sap.ui.xmlfragment("com.sap.cp.lm.view.myWork.wageTypeVH", oCurrentViewController);
			// 		oCurrentViewController._oSourceViewController.getView().addDependent(oCurrentViewController.wageTypeFragment);
			// 	}
			// 	oCurrentViewController.wageTypeFragment.open();
			// },

			// handleCloseWageTypeVH: function (oEvent) {
			// 	var aContexts = oEvent.getParameter("selectedContexts");
			// 	var selectedWageType = aContexts[0].getProperty("FieldValue") + "(" + aContexts[0].getProperty("FieldId") + ")";
			// 	if (this._oSourceViewController.getView().getDependents()[1].getModel().getData()) {
			// 		this._oSourceViewController.getView().getDependents()[1].getModel().setProperty("/wageType", selectedWageType);
			// 	} else {
			// 		this._oSourceViewController.getView().getDependents()[0].getModel().setProperty("/wageType", selectedWageType);
			// 	}
			// 	oEvent.getSource().getBinding("items").filter([]);
			// },

			// handleSearchWageTypeVH: function (oEvent) {
			// 	var sValue = oEvent.getParameter("value");
			// 	var oFilter = new Filter("FieldValue", sap.ui.model.FilterOperator.Contains, sValue);
			// 	var oBinding = oEvent.getSource().getBinding("items");
			// 	oBinding.filter([oFilter]);
			// },
			/*Added by Vikram	*/
			//----------------------------------------------------------------------
			// Payload preparation functions
			//----------------------------------------------------------------------

			/**
			 * Preparting payload for Time recording
			 */
			preparePayload: function (aDuration) {
				var aSelRecord = this._oSelectedContext.getObject();
				var aPayload = {};

				// var aServGroup = this._oGlobalModel.getProperty("/ServiceGroupList"); //New LMP2-29
				// var j = aServGroup.length; //New LMP2-29

				// for (var i = 0; i < j; i++) {
				aPayload.Pernr = aSelRecord.PersonNo;
				aPayload.Counter = "";
				aPayload.TimeEntryOperation = "C";
				aPayload.TimeEntryDataFields = {};
				aPayload.TimeEntryDataFields.WORKDATE = _this.getDateTimeStr();
				aPayload.TimeEntryDataFields.CATSAMOUNT = aDuration.CATSAMOUNT;

				/*Added by Vikram	*/
				// aPayload.TimeEntryDataFields.LGART = aDuration.wageType;
				if (aDuration.bOverTime) {
					aPayload.TimeEntryDataFields.ZOTCODE = "T01";
					aPayload.TimeEntryDataFields.ZOTCOND = "T01A";
					aPayload.TimeEntryDataFields.AWART = "1115";
				}
				/*Added by Vikram	*/
				aPayload.TimeEntryDataFields.RAUFNR = aSelRecord.OrderNo;
				aPayload.TimeEntryDataFields.VORNR = aSelRecord.Activity;
				aPayload.TimeEntryDataFields.LSTAR = aSelRecord.ActivityType;
				aPayload.TimeEntryRelease = "";
				return aPayload;
			},

			// preparePayload: function (aDuration) {
			// 	var aSelRecord = this._oSelectedContext.getObject();
			// 	var aPayload = {};
			// 	var aPayloads = [];
			// 	var aTimeEntries = [];
			// 	var aTimeEntry = {};

			// 	var aServGroup = this._oGlobalModel.getProperty("/ServiceGroupList"); //New LMP2-29
			// 	var j = aServGroup.length; //New LMP2-29
			// 	j = 1;

			// 		aPayload.Pernr = aSelRecord.PersonNo;
			// 		aPayload.Counter = "";
			// 		aPayload.TimeEntryOperation = "C";
			// 		aPayload.TimeEntryDataFields = {};
			// 		for (var i = 0; i < j; i++) {
			// 			aTimeEntry.WORKDAT = _this.getDateTimeStr();
			// 			aTimeEntry.CATSAMOUNT = "2";

			// 	//	aPayload.TimeEntryDataFields[i].WORKDATE = _this.getDateTimeStr();
			// 	//	aPayload.TimeEntryDataFields[i].CATSAMOUNT = aDuration.CATSAMOUNT;
			// 	//	aPayload.TimeEntryDataFields.CATSAMOUNT = "2"; //aDuration.CATSAMOUNT;
			// 		/*Added by Vikram	*/
			// 		// aPayload.TimeEntryDataFields.LGART = aDuration.wageType;
			// 		if (aDuration.bOverTime) {
			// 			aTimeEntry.ZOTCODE = "T01";
			// 			aTimeEntry.ZOTCOND = "T01A";
			// 			aTimeEntry.AWART = "1115";
			// 		}
			// 		/*Added by Vikram	*/
			// 		aTimeEntry.RAUFNR = aSelRecord.OrderNo;
			// 		aTimeEntry.VORNR = aSelRecord.Activity;
			// 		aTimeEntry.LSTAR = aSelRecord.ActivityType;
			// 		aTimeEntries.push(aTimeEntry);
			// 		}
			// 		aPayload.TimeEntryRelease = "";
			//                 aPayload.TimeEntryDataFields = aTimeEntries;

			// 	return aPayload;
			// },

			getDateTimeStr: function () {
				var date = new Date();
				//START - BAJ0018
				//For US shops time entry needs to happen for previous day for the last shift
				var sShopId = this._oGlobalModel.getProperty("/currentShop").Id;
				if (sShopId === "3035" && date.getHours() < 7) {
					date.setDate(date.getDate() - 1);
				}
				//END -BAJ0018
				return "" + date.getFullYear() + "-" + ("" + (date.getMonth() + 101)).substring(1) + "-" + ("" + (date.getDate() + 100)).substring(1) +
					"T00:00:00";
			},

			/**
			 * Preparing payload for updating Operation Begin
			 */
			// KIR0084 Adding parameter so this can be passed in from outside of class
			prepareBeginOperationPayload: function (aParamObject) {
				var aSelRecord = aParamObject || this._oSelectedContext.getObject();
				var aPayload = {};
				aPayload.ConfirmationSet = [];

				var aConfirmation = {};
				aConfirmation.OrderNumber = aSelRecord.OrderNo;
				aConfirmation.OperationNumber = aSelRecord.Activity;

				aPayload.ConfirmationSet.push(aConfirmation);

				return aPayload;
			},

			/**
			 * Preparing payload for Operation confirmation
			 */
			//	 prepareOperationConfirmationPayload: function (bFinalConfirmation){ //LMP2-29 : Commented
			prepareOperationConfirmationPayload: function (bFinalConfirmation, bApplyToServGr, iCatHours) { //LMP2-29 : Added
				var aPayload = {};
				var aConfirmation = {};
				var aSelRecord = this._oSelectedContext.getObject();
				aPayload.OrderNo = aSelRecord.OrderNo;
				aPayload.ConfirmationSet = [];

				aConfirmation.OrderNumber = aSelRecord.OrderNo;
				aConfirmation.OperationNumber = aSelRecord.Activity;
				aConfirmation.EndWork = true;
				if (bFinalConfirmation) {
					aConfirmation.FinalConfirmation = true;
				}
				//Start : LMp2-29
				if (bApplyToServGr) {
					aConfirmation.applytoservgr = 'X'; //true; // Commented for Start ASR3414325 (Complete the SubOps in the servicing group);
					//odata field applytoservgr is changed from boolean to character in ecc for this ASR 
				}
				aConfirmation.empno = aSelRecord.PersonNo;
				aConfirmation.cathours = iCatHours;
				//End:LMP2-29
				aPayload.ConfirmationSet.push(aConfirmation);
				return aPayload;
			},

			/**
			 * Payload for adjusting materials
			 */
			prepareMaterialsPayload: function () {
				var aPayload = {};
				var aOperationHeader = this._oSelectedContext.getObject();
				aPayload.OpNode = aOperationHeader.OpNode;
				aPayload.OrderNo = aOperationHeader.OrderNo;
				aPayload.RoutingNo = aOperationHeader.RoutingNo;
				aPayload.Activity = aOperationHeader.Activity;
				aPayload.MaterialSet = [];
				var aMaterial = {};
				var oMaterials = this._oMatWindow.getModel().getProperty("/craftOperationMat");
				oMaterials.forEach(function (oItem) {
					aMaterial = {};
					aMaterial.ItemNo = oItem.ItemNo;
					aMaterial.RoutingNo = oItem.RoutingNo;
					aMaterial.OpNode = oItem.OpNode;
					aMaterial.MaterialNo = oItem.MaterialNo;
					aMaterial.RequiredQty = oItem.RequiredQty;
					aPayload.MaterialSet.push(aMaterial);
				});
				return aPayload;
			}

		};
	});