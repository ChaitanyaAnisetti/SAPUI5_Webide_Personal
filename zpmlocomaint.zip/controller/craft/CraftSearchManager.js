/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.05                                           *
* Project        : Locomotive Maintenance                               *
* Description    : This is the manager for the search fragment for      *
*                  craft. This fragment and manager is used multiple    *
*                  times on the app.                                    *
*&----------------------------------------------------------------------*/
/*&---------------------------------------------------------------------*    
* Author         : KIR0084                                              *
* Date           : 2019.08.05                                           *
* Project        : LMP2 Phase 3                                         *
* Description    : Remove N/A from Craft Filters                        *
*&----------------------------------------------------------------------*/
/*&---------------------------------------------------------------------*    
* Author         : KIR0084                                              *
* Date           : 2019.12.15                                           *
* Project        : LMP2 Phase 3                                         *
* Description    : Remove shift from filters if it is not visible       *
*&----------------------------------------------------------------------*/

sap.ui.define([
	"com/sap/cp/lm/controller/common/FragmentBaseDelegate",
	"com/sap/cp/lm/util/Constants",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/ui/model/json/JSONModel"
], function(BaseDelegate, Constants, Filter, FilterOperator, Sorter, JSONModel) {
	"use strict";
	
	return BaseDelegate.extend("com.sap.cp.lm.controller.craft.CraftSearchManager", {
		
		_sFragmentName: "com.sap.cp.lm.view.craft.CraftSearch",
		
		//--------------------------------------------------------------------
		// Life cycle functions
		//--------------------------------------------------------------------
		
		onInit: function() {
			
		},
		
		// #DontDelete : Q
		init: function(oParentController, fnRefreshWorkers, oListElement) {
			this._oParentController = oParentController;
			this._aFilters = [];
			this._fnRefreshWorkers = fnRefreshWorkers;
			this._oListElement = oListElement;
			
			
			return this;
		},
		
		//----------------------------------------------------------------------
		// Private functions
		//----------------------------------------------------------------------
		
		// #DontDelete : Q
		/**
		 * Create filter for search bar query and update filter
		 */
		_searchWorker: function(query) {
		    var aFilters = [];
		    if (query && query.length > 0) {
			    aFilters.push(new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, query));
		    }          
		    
		    /* KIR0084 LMP2 Only filter on shifts if shift button is visible */
		    if (this.byId("craftSearchHBox").getVisible()) {
			    aFilters.push(new sap.ui.model.Filter("Shift", sap.ui.model.FilterOperator.EQ, this.byId("craftSearchShiftFilter").getSelectedItem().getKey()));
		    }
		    /* KIR0084 LMP2 Only filter on shifts if shift button is visible */
			this._filterItems(aFilters);
		},
		
		_searchShift: function(query) {
		    var aFilters = [];
		    if (this.byId("craftSearchTextField").getValue() && this.byId("craftSearchTextField").getValue().length > 0) {
			    aFilters.push(new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, this.byId("craftSearchTextField").getValue()));
		    }
			aFilters.push(new sap.ui.model.Filter("Shift", sap.ui.model.FilterOperator.EQ, query));
			this._filterItems(aFilters);
		},
		
		onFirstPass: function() {
		    /* KIR0084 LMP2 Only filter on shifts if shift button is visible */
		    if (this.byId("craftSearchHBox").getVisible()) {
    		    var currentShift = this._oParentController._oGlobalModel.getProperty("/currentShift").ShiftName;
    		    this.byId("craftSearchShiftFilter").setSelectedKey(currentShift);
    		    this._searchShift(currentShift);
		    }
		    /* KIR0084 LMP2 Only filter on shifts if shift button is visible */
			
		    var sortObjectList = [new Sorter("AvailabilityStatus", false), new Sorter("Name", false)];
			this._sortList(sortObjectList);
		}, 
		
		// #DontDelete : Q
		/**
		 * Refresh workers with a request to backend
		 */
		_refreshWorkers: function() {
			this._fnRefreshWorkers.apply(this._oParentController);
		},
		
		// #DontDelete : Q
		/**
		 * Add filter in parameters to global filter array
		 */
		_addToFilterArray: function(sKey, oFilter) {
			this._removeElementFromFilters(sKey);
			this._aFilters.push({key : sKey, filter : oFilter});
		},
		
		// #DontDelete : Q
		/**
		 * Remove filter from array based on sKey paramater
		 */
		_removeElementFromFilters: function(sKey) {
			var f = false;
			var i = 0;
			
			while(i < this._aFilters.length && !f) {
				if(this._aFilters[i].key === sKey) {
					this._aFilters.splice(i, 1);
					f = true;
				}
				
				i++;
			}
		},
		
		// #DontDelete : Q
		/**
		 * Filter items using filters in variable _aFilters
		 */
		_filterItems: function(aFiltersFormatted) {
			console.log("_filterItems");
			
			var binding = this._oListElement.getBinding("items");
			
			var oFilter = new Filter({
				filters: aFiltersFormatted,
				and: true
			});
			binding.filter(oFilter);
			
		},
		
		//----------------------------------------------------------------------
		// Event handlers
		//----------------------------------------------------------------------
		
		// #DontDelete : Q
		/**
		 * Fired when search is triggered
		 */
		onSearch: function(oEvent) {
			var refreshButtonPressed = oEvent.getParameter("refreshButtonPressed");
			var query = oEvent.getParameter("query");
			
			if(refreshButtonPressed) {
				this._refreshWorkers();
				this._searchWorker(query, false);
			} else {
				this._searchWorker(query, true);
			}
		},
		
		// #DontDelete : Q
		/**
		 * Fired when search value change
		 */
		onSearchLiveChange: function(oEvent) {
			var query = oEvent.getParameter("newValue");
			this._searchWorker(query);
		},
			
	    /* KIR0084 LMP2-33 Sort Dialog for crafts */
		onShowSortDialogPress: function(oEvent) {
			if (!this._oFilterDialog) {
				this._oFilterDialog = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.craft.CraftFilterDialog",
					this
				);
			}

			this._oFilterDialog.open();
		},
		
		sortCraftList: function(oEvent) {
		    var sortDialog = oEvent.getSource();
		    var desc = sortDialog.getSortDescending();
		    var sortObjectList = [new Sorter("AvailabilityStatus", false)];
		    var sortKey = "";
		    
		    sortObjectList = sortObjectList.concat(sortDialog.getSortItems().filter(function(item) { 
		        return item.getSelected();
		    }).map(function(item) {
		        sortKey = item.getKey();
		        return new Sorter(sortKey, desc);
		    }));
		    
		    // If sorting unavailable reasons, put unavailable crafts at the top
		    if (sortKey === "UnavailReason") {
		        sortObjectList[0] = new Sorter("AvailabilityStatus", true);
		    }
		    
		    this._sortList(sortObjectList);
		},
		
		_sortList: function(aSortList) {
		    this._oListElement.getBinding("items").sort(aSortList);
		},
		
		onEndCraftAssignmentPress: function() {
		    this._oParentController.onEndCraftAssignmentPress();
		},
	    /* KIR0084 LMP2-33 Sort Dialog for crafts */

		
		// #DontDelete : Q
		/**
		 * Fired when a chekbox is selected/unselected
		 */
		onFilterShift: function(oEvent) {
		    // KIR0084 Changed to use dropdown instead of checkboxes for filtering
		    var selectedItemName = oEvent.getSource().getSelectedItem().getKey();
		    this._searchShift(selectedItemName);
		}
		
	});
});