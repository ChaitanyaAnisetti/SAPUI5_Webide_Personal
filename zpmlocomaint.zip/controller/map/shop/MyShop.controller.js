/* #DontDelete : Yann */
/*&----------------------------------------------------------------------*    
 * Author         : KIR0084                                              *
 * Date           : 2019.04.01                                           *
 * Incidinet      : LMP2-34 - PM Loco Main phase 2              	     *
 * Description    : Remove N/A from top of page during loading			 *
 *                  Fix bug where shift not returning properly			 *
 * Search Term    : LMP2-34                                              *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : KIR0084                                              *
 * Date           : 2019.06.01                                           *
 * Incidinet      : LMP2-32 - Turnover Doc  		              	     *
 * Description    : Turnover Doc                                         *
 * Search Term    : LMP2-32                                              *
 *&----------------------------------------------------------------------*/
 /*&----------------------------------------------------------------------*    
 * Author         : SHE0272                                              *
 * Date           : 16.Jun.2021                                          *
 * Incidinet      : LLM2.29 - Road/Yard Repair			              	 *
 * Description    : Navigate to service tab for RYR process				 *
 * Search Term    : LLM2.29                                              *
 *&----------------------------------------------------------------------*/
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/controller/map/MapManager",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
	"com/sap/cp/lm/controller/craft/CraftManager",
	"com/sap/cp/lm/controller/locomotives/LocomotiveManager",
	"com/sap/cp/lm/model/craft/CraftDataModel",
	"sap/m/MessageToast",
	"com/sap/cp/lm/controller/common/ArriveManager",
	"com/sap/cp/lm/controller/common/PrintManager"

], function(Controller, Constants, Formatter, MapManager, BusyIndicator, LocomotiveDataModel,
	CraftManager, LocomotiveManager, CraftDataModel, MessageToast, ArriveManager, PrintManager) {
	"use strict";

	var _this;

	return Controller.extend(
		"com.sap.cp.lm.controller.map.shop.MyShop", {
			
			//--------------------------------------------------------------------
			// Life cycle functions
			//--------------------------------------------------------------------
			
			/**
			 * Initializes the controller
			 */
			onInit: function() {
				_this = this;
				
				_this.didArrive = false;
					
				$(window).on('resize', $.proxy(this.handleWindowResize, this));

				this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
				this._oGlobalLocomotiveModel = this.getOwnerComponent().getGlobalLocomotiveModel();

				this._oGlobalShiftModel = this.getOwnerComponent().getGlobalShiftModel();
				this.oEventBus = sap.ui.getCore().getEventBus();

				this._shopId = "";

				this.oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());

				this._oDrag = null;
				this._oZoom = null;

				this._oViewPropertiesModel = new sap.ui.model.json.JSONModel();
				this._initViewPropertiesModel();
				this.getView().setModel(this._oViewPropertiesModel, "viewProperties");
				
				this._oGlobalModel.setProperty("/needDrawMap", true);

				// register the method to get notified when the MyShop is visible
				this.oRouter.getTargets().attachDisplay(function(oEvent) {
					if (oEvent.getParameter("name") === "myShop") {
					    if (!_this.bEventsBound) {
					        _this.bEventsBound = true;
					        
            				// register to listen to change events of the globalmodel which contain the currentShop
            				var binding = new sap.ui.model.Binding(this._oGlobalModel, "/", this._oGlobalModel.getContext("/"));
            				binding.attachChange(function() {
            					_this.onGlobalModelChange();
            				});
            
            				// register to listen to change events of the global locomotive model which contain the locomotives
            				var lBinding = new sap.ui.model.Binding(this._oGlobalLocomotiveModel, "/", this._oGlobalLocomotiveModel.getContext("/"));
            				lBinding.attachChange(function() {
            					_this.onGlobalLocomotiveModelChange();
            				});
					    } 
					    
						_this._onMyShopRouteMatched();
					}
				}.bind(this));

				var oEventBus = sap.ui.getCore().getEventBus();
				
				oEventBus.subscribe("ShopChanged", "shopChangedDone", this._shopChanged, this);
				oEventBus.subscribe("ArriveManager", "arriveLocomotiveDone", this.arriveLocomotiveDone, this);
				oEventBus.subscribe("ReleaseProcess", "releaseProcessDone", this.releaseProcessDone, this);
				oEventBus.subscribe("RemoveProcess", "removeProcessDone", this.removeProcessDone, this);
			},
			
			//--------------------------------------------------------------------
			// Private functions
			//--------------------------------------------------------------------
			
			/**
			 * Create the view properties model for this view. 
			 */
			_initViewPropertiesModel: function() {
				this._oViewPropertiesModel.setProperty("/IsCurrentShift", true);
				this._oViewPropertiesModel.setProperty("/ShowMapWarning", false);
				
				this._reloadCurrentShift();
			},
			
			_shopChanged:function() {
				var oShift = _this._oGlobalModel.getProperty("/currentShift");
				_this._applyShift(oShift);
				
			},
			
			_reloadCurrentShift:function() {
				var oShift = _this._oGlobalModel.getProperty("/currentShift");
				this._setShiftTime(oShift);
			},

			_setShiftTime: function(oShift) {
				if (oShift) {
					this._oViewPropertiesModel.setProperty("/ShiftStartTime", oShift.ShiftStart);
					this._oViewPropertiesModel.setProperty("/ShiftEndTime", oShift.ShiftEnd);
				}
			},
			
			showMapWarning: function(aMissingSpots) {
				this._oViewPropertiesModel.setProperty("/ShowMapWarning", true);
				this._oViewPropertiesModel.setProperty("/MissingSpots", aMissingSpots);
			},

			hideMapWarning: function() {
				this._oViewPropertiesModel.setProperty("/ShowMapWarning", false);
				this._oViewPropertiesModel.setProperty("/MissingSpots", null);
			},
			
			_refreshMap: function() {
				var main = d3.select("#MyShopMain");
				// set the main <g>, zoom, drag n drop function calls to the map manger
				var oParameters = {
					main: main,
					fZoom: _this._oZoom,
					fDrag: _this._oDrag,
					mode: Constants.MYSHOP,
					onSpotPress: _this.onSpotPress,
					onLocomotivePress: _this.onLocomotivePress,
					onConflictPress: _this.onConflictPress,
					onMoveLocomotive: _this.onMoveLocomotive,
					oContext: _this
				};
				MapManager.setSVGMain(oParameters);
				// load the locomotives for the shop
				// if (_this._shopId !== "") {
				// 	// check if the spots needs to be rerendered in case where the spots have been disabled 
				// 	var renderMap = _this._oGlobalModel.getProperty("/renderMap");
				// 	if (renderMap) {
				// 		MapManager.resetSpots();
				// 		_this._oGlobalModel.setProperty("/renderMap", !renderMap);
				// 	}
				//	_this._fetchMapLocomotives();
				// }
				// show/hide spot text
				MapManager.toggleSpotText(_this.byId("spotSwitch").getState());
			},
			
			/**
			 * Draw map and locomotives on my shop view
			 */
			_drawLocomotives: function() {
				MapManager.drawLocomotives(this._locomotives);
			},

			/**
			 * Adapt map drag/drop behavior depending on user role
			 */
			canDrag: function() {
				if (this._role === Constants.ROLE.CRAFT) {
					return false;
				}
				return true;
			},

			/**
			 * Release locomotive dialog
			 */
			showDepartDialog: function(oLocomotive) {
				var oView = this.getView();

				if (!this._departDialog) {
					this._departDialog = sap.ui.xmlfragment("com.sap.cp.lm.view.map.shop.DepartDialog", this);
					this._parentView = oView;
					this._departDialog.parentView = oView;
					oView.addDependent(this._departDialog);
				}

				this._departDialog.setModel(oLocomotive);
				this._departDialog.open();
			},
			
			arriveLocomotiveDone: function(sChannel, oEvent, oData) {
				_this.didArrive = true;
				_this.waitCount = 0;
				_this.oArrivedLocomotive = oData.locomotive;
				this.refreshShoppedLocomotives();
				this._oGlobalModel.setProperty("/needDrawMap", true);
			},

			releaseProcessDone: function(sChannel, oEvent, oData) {
				this.refreshShoppedLocomotives();
				this._oGlobalModel.setProperty("/needDrawMap", true);
			},
			
			removeProcessDone: function(sChannel, oEvent, oData) {
				this.refreshShoppedLocomotives();
				this._oGlobalModel.setProperty("/needDrawMap", true);
			},
			
			/** 
			 * Draw the my shop map with the locomotives
			 */
			_drawMyShopMap: function() {
				// console.log("_drawMyShopMap");

				var mapContainer = _this.getView().byId("MyShopMapContainer");

				var oDragNZoom = MapManager.drawMap({
					globalModel: _this._oGlobalModel,
					container: mapContainer,
					svgWidth: _this._d3Width,
					svgHeight: _this._d3Height,
					parentController: _this,
					requestSpot: false
				});

				if (oDragNZoom) {
					_this._oDrag = oDragNZoom.drag;
					_this._oZoom = oDragNZoom.zoom;
				}
			},
			
			/**
			 * Set date for my shop view
			 */
			_setMyShopDate: function() {
				//Start KIR0084: Remove N/A from top of page
				//var text = "N/A";
				var text = "";
				//END KIR0084: Remove N/A from top of page

				var startDateUTC = this._oViewPropertiesModel.getProperty("/ShiftStartTime");
				var endDateUTC = this._oViewPropertiesModel.getProperty("/ShiftEndTime");

				if (!startDateUTC || !endDateUTC) {
					var oShift = _this._oGlobalModel.getProperty("/currentShift");
					this._setShiftTime(oShift);
					startDateUTC = this._oViewPropertiesModel.getProperty("/ShiftStartTime");
					endDateUTC = this._oViewPropertiesModel.getProperty("/ShiftEndTime");
				}

				if (startDateUTC && endDateUTC) {
					var localStartDateAtShop = Formatter.localDateAtCurrentShop(startDateUTC);
					var localEndDateAtShop = Formatter.localDateAtCurrentShop(endDateUTC);
					
					text = Formatter.changeDateFormatDayMMDDYY(localStartDateAtShop);
					text = text + " " + Formatter.changeDateFormatHHMM(localStartDateAtShop);
					text = text + " - " + Formatter.changeDateFormatHHMM(localEndDateAtShop);

					this.byId("myShopCurrentDate").setEnabled(true);
				} else {
					this.byId("myShopCurrentDate").setEnabled(false);
				}
				
				this.byId("myShopCurrentDate").setText(text);
			},
			
			_applyShift: function(oShift) {
				this.byId("myShopCurrentDate").removeStyleClass("lmDefectMandatory");

				// check if the shift selected is the current shift if not go fetch the planned locomotives and adjust the footer accordingly
				var nowDate = new Date();
				if (nowDate > oShift.ShiftStart && nowDate <= oShift.ShiftEnd) {
					// current shift	
					this._oViewPropertiesModel.setProperty("/IsCurrentShift", true);
					MapManager.removeLocomotives();
				} else {
					// future shifts
					this._oViewPropertiesModel.setProperty("/IsCurrentShift", false);
					this.byId("myShopCurrentDate").addStyleClass("lmDefectMandatory");
				}

				this._setShiftTime(oShift);
				this._setMyShopDate();
				
				//Start KIR0084: Shift not getting set properly in top of myShop after returning to view
				this._oGlobalModel.setProperty("/currentShift", oShift);
				//End KIR0084: Shift not getting set properly in top of myShop after returning to view
				
				// fetch the locomotives for the selected new shift
				this.refreshLocomotives();
			},
			
			getShiftIndex: function() {
				
				var oShiftModel = this._oGlobalShiftModel.getData();
				var startTime   = this._oViewPropertiesModel.getProperty("/ShiftStartTime");
			
				for (var iShiftIndex = 0; iShiftIndex < oShiftModel.results.length; iShiftIndex++) {
					var shift = oShiftModel.results[iShiftIndex];
					if (startTime === shift.ShiftStart) {
						return iShiftIndex;
					}
				}
				
				return null;
			},

			/**
			 * Refresh the locomotives of the map
			 */
			refreshLocomotives: function() {
				BusyIndicator.showBusyIndicator();
				if (this._oViewPropertiesModel.getProperty("/IsCurrentShift")) {
					_this.refreshShoppedLocomotives();
				} else {
					_this.fetchPlannedLocomotives();
				}
			},

			refreshShoppedLocomotives: function() {
				_this.fetchShoppedLocomotives();
				_this.fetchServicedLocomotives();
			},
			
			/**
			 * Fetch list of servicing locomotives in current shift
			 */
			fetchServicedLocomotives: function() {
				// console.log("fetchServicedLocomotives");
				var sShopId = this._oGlobalModel.getProperty("/currentShop").Id;
				LocomotiveDataModel.fetchServiceLocomotives(sShopId, _this._fetchServicedLocomotivesSuccess, _this._fetchServicedLocomotivesFailure,
					_this);
			},

			_fetchServicedLocomotivesSuccess: function(oData) {
				_this._oGlobalLocomotiveModel.setProperty("/Servicing", oData.results);
				BusyIndicator.hideBusyIndicator();
				
				if(_this.didArrive === true) {
					_this.waitCount += 1;
					_this.checkWaitCount();
				}
			},

			_fetchServicedLocomotivesFailure: function() {
				BusyIndicator.hideBusyIndicator();
			},
			
			checkWaitCount: function() {
				if(_this.waitCount > 1) {
					_this.didArrive = false;
					_this.forceLocomotiveDetail(_this.oArrivedLocomotive);
				}
			},
			/**
			 * Fetch list of shopped locomotives in current shift
			 */
			fetchShoppedLocomotives: function() {
				var sShopId = this._oGlobalModel.getProperty("/currentShop").Id;
				LocomotiveDataModel.fetchShoppedLocomotives(sShopId, _this._fetchShoppedLocomotivesSuccess, _this._fetchShoppedLocomotivesFailure,
					_this);
			},

			_fetchShoppedLocomotivesSuccess: function(oData) {
				_this._oGlobalLocomotiveModel.setProperty("/Shopped", oData.results);
				BusyIndicator.hideBusyIndicator();
				
				if(_this.didArrive === true) {
					_this.waitCount += 1;
					_this.checkWaitCount();
				}

			},

			_fetchShoppedLocomotivesFailure: function() {
				BusyIndicator.hideBusyIndicator();
			},

			/**
			 * Fetch list of planned locomotives
			 */
			fetchPlannedLocomotives: function() {
				var dStartTime = this._oViewPropertiesModel.getProperty("/ShiftStartTime");
				var sShopId = this._oGlobalModel.getProperty("/currentShop").Id;
				var sStartTime = Formatter.changeToUTCTimestamp(dStartTime);

				LocomotiveDataModel.fetchPlannedLocomotives(sShopId, sStartTime, _this._fetchPlannedLocomotivesSuccess, _this._fetchPlannedLocomotivesFailure,
					_this);
			},

			_fetchPlannedLocomotivesSuccess: function(oData) {
				_this._oGlobalLocomotiveModel.setProperty("/Planned", oData.results);
				BusyIndicator.hideBusyIndicator();
			},

			_fetchPlannedLocomotivesFailure: function() {
				BusyIndicator.hideBusyIndicator();
			},

			/**
			 * Filter locomotives to draw on the map 
			 */
			_fetchMapLocomotives: function() {
				// console.log("_fetchMapLocomotives");
				
				if(!_this._oViewPropertiesModel) {
					console.log("_fetchMapLocomotives cancelled");
					return;
				}
				
				_this.aDrawingLocomotives = [];
				var aLocomotives = [];

				var isCurrentShift = _this._oViewPropertiesModel.getProperty("/IsCurrentShift");

				if (isCurrentShift) {
					aLocomotives = _this._oGlobalLocomotiveModel.getProperty("/Shopped");
				} else {
					aLocomotives = _this._oGlobalLocomotiveModel.getProperty("/Planned");
				}

				$.each(aLocomotives, function(i, loco) {
					if (loco.Track && loco.Spot && loco.Track !== "" && loco.Spot !== "") {
						loco.TrackSpot = loco.Track + "-" + loco.Spot;
						_this.aDrawingLocomotives.push(loco);
					}
				});

				if (_this.aDrawingLocomotives && _this.aDrawingLocomotives.length > 0) {
					if (_this._oViewPropertiesModel.getProperty("/IsCurrentShift")) {
						MapManager.drawLocomotives(_this.aDrawingLocomotives);
					} else {
						MapManager.displayPlannedLocomotives(_this.aDrawingLocomotives);
					}
				}
			},
			
			//--------------------------------------------------------------------
			// Event handlers
			//--------------------------------------------------------------------

			/**
			 * Sets height of the shop page
			 */
			handleWindowResize: function() {
				this._myShopPage = this.byId("MyShopPage");
				var myShopMapContainer = this.byId("MyShopMapContainer");
				var myShopToolbar = this.byId("MyShopToolbar");
				var myShopFooter =  this.byId("MyShopFooter");
				
				if (myShopMapContainer && myShopToolbar && myShopFooter) {
    				// adjust the height of the MyShop view
    				var frameHeight = $(window).height();
    				var headerToolbar = $("#" + myShopToolbar.sId);
    				var footerToolbar = $("#" + myShopFooter.sId);
    				//$("#" + this._myShopPage.sId).height(frameHeight - headerToolbar.height());
    
    				// adjust the height of the Map Container
    				$("#" + myShopMapContainer.sId).height($("#" + this._myShopPage.sId).height() - headerToolbar.height() - footerToolbar.outerHeight());
    
    				// calculate the width and height to be used in the SVG
    				this._d3Width = $(window).width(); //1024
    				this._d3Height = $("#" + myShopMapContainer.sId).height(); //416
				}
			},
			
			onMapWarningPress: function(oEvent) {
				var aMissingSpots = this._oViewPropertiesModel.getProperty("/MissingSpots");
				alert("Spots not on the map " + aMissingSpots);
			},

			/**
			 * When the global locomotive model is changed
			 */
			onGlobalLocomotiveModelChange: function() {
				if (this._shopId && _this._oGlobalModel.getProperty("/currentShop")) {
					this._fetchMapLocomotives();
				}
			},

			/**
			 * When the global model is changed
			 */
			onGlobalModelChange: function() {
				var oShift = _this._oGlobalModel.getProperty("/currentShift");
				this._setShiftTime(oShift);
				
				//display shift date
				this._setMyShopDate();

				var tempCurrentShop = this._oGlobalModel.getProperty("/currentShop");
				var tempCurrentRole = this._oGlobalModel.getProperty("/role");

				// check if the currentShop is different and if so reload the map
				if (tempCurrentShop && tempCurrentShop.Id !== this._shopId) {
					// the initial load of the application window.height is incorrect at onAfterRendering and calculating the height later
					this.handleWindowResize();
					this._locoWidth  = this._oGlobalModel.getProperty("/mapLocoWidth");
					this._locoHeight = this._oGlobalModel.getProperty("/mapLocoHeight");
					this._shopId = tempCurrentShop.Id;
					this._locomotives = this._oGlobalModel.getProperty("/locomotives");
					this._spots = this._oGlobalModel.getProperty("/spots");
					this._drawMyShopMap();
					this._fetchMapLocomotives();

					// show/hide spot text
					MapManager.toggleSpotText(_this.byId("spotSwitch").getState());
				}
				// check if the currentRole is different and if so reload the locomotives
				if (this._shopId && tempCurrentRole && tempCurrentRole !== this._role) {
					this._role = this._oGlobalModel.getProperty("/role");
					// show/hide Map and List button depending the role
					if (this._role === Constants.ROLE.CRAFT) {
					    /* KIR0084 LMP2-32 Hide buttons for displaying Detail Overview because its replaced by TO Doc */
						//hide the List, Map buttons and people icon
				// 		$("#" + this.byId("MyShopMapButton").sId).hide();
				// 		$("#" + this.byId("MyShopListButton").sId).hide();
					    /* KIR0084 LMP2-32 Hide buttons for displaying Detail Overview because its replaced by TO Doc */
						if (this.byId("idRefresh")) {
							this.byId("idRefresh").addStyleClass("lmRefreshIconCraftRole");
						}
					} else {
					    /* KIR0084 LMP2-32 Hide buttons for displaying Detail Overview because its replaced by TO Doc */
						//show the List, Map buttons and people icon
				// 		$("#" + this.byId("MyShopMapButton").sId).show();
				// 		$("#" + this.byId("MyShopListButton").sId).show();
					    /* KIR0084 LMP2-32 Hide buttons for displaying Detail Overview because its replaced by TO Doc */
					}
					this._fetchMapLocomotives();
				}
			},

			/**
			 * Called when the MyShop screen is invoked.
			 */
			_onMyShopRouteMatched: function() {
				BusyIndicator.hideBusyIndicator();

				this._oGlobalModel.setProperty("/isMapView", true);
				this._oGlobalModel.setProperty("/sSelectedView", "MyShop");
				
				// _this._refreshMap();
				
				var needRedraw = false;
				
				//force redraw for craft first visit on map
				if (this._oGlobalModel.getProperty("/role") === Constants.ROLE.CRAFT && MapManager.isLocoSizeSet() === false) {
					needRedraw = true;
				} 
				
				//force redraw if global need set
				if(this._oGlobalModel.getProperty("/needDrawMap") === true) {
                    _this._oGlobalModel.setProperty("/needDrawMap", false);
					needRedraw = true;
				}
                
                /** LMP2-36 KIR0084 Make map refresh on craft change */
                var fnFinally = function() {
    				//do redraw according to need defined above
    				if(needRedraw === true){
        			    setTimeout(_this._refreshMap, 1);
        			    setTimeout(_this._drawMyShopMap, 500);
        				setTimeout(_this._fetchMapLocomotives, 1000);	
    				}
    				
    				// setTimeout(_this._refreshMap, 500);
    			 //   _this._fetchMapLocomotives();
    			 //   _this._drawMyShopMap();
                };
                
                // If there is a need to refresh the data, setup callbacks for after loading data
				if(this._oGlobalModel.getProperty("/needRefreshMapData") === true) {
                    _this._oGlobalModel.setProperty("/needRefreshMapData", false);
    				var sShopId = this._oGlobalModel.getProperty("/currentShop").Id;
    				var isCurrentShift = _this._oViewPropertiesModel.getProperty("/IsCurrentShift");
    
    				if (isCurrentShift) {
    				    var fnShoppedLocomotivesSuccess = function(oData) {
            				_this._oGlobalLocomotiveModel.setProperty("/Shopped", oData.results);
            				BusyIndicator.hideBusyIndicator();
            				
            				if(_this.didArrive === true) {
            					_this.waitCount += 1;
            					_this.checkWaitCount();
            				}
    				        
    				        fnFinally();
    				    }.bind(this);
    				    
        				LocomotiveDataModel.fetchShoppedLocomotives(sShopId, fnShoppedLocomotivesSuccess, _this._fetchShoppedLocomotivesFailure,
        					_this);
    				} else {
    				    var fnPlannedLocomotivesSuccess = function(oData) {
            				_this._oGlobalLocomotiveModel.setProperty("/Planned", oData.results);
            				BusyIndicator.hideBusyIndicator();
    				        
    				        fnFinally();
    				    }.bind(this);
    				    
        				var dStartTime = this._oViewPropertiesModel.getProperty("/ShiftStartTime");
        				var sStartTime = Formatter.changeToUTCTimestamp(dStartTime);
        
        				LocomotiveDataModel.fetchPlannedLocomotives(sShopId, sStartTime, fnPlannedLocomotivesSuccess, _this._fetchPlannedLocomotivesFailure,
        					_this);
    				}
				}
				else {
				    // Just refresh map if no need to refresh
				    fnFinally(); 
				}
                /** LMP2-36 KIR0084 Make map refresh on craft change */
				
			},

			onSearchLocomotiveOnMap: function(oEvent) {
				//If we're waiting to perform a search and the function 
				if (this._oSearchDelayTimeout) {
					clearTimeout(this._oSearchDelayTimeout);
				}
				// get the value entered as user type or on press enter
				var sSearchString = oEvent.getParameter("newValue") || oEvent.getParameter("query");
				//Otherwise we save the timer and perform a search after a small delay
				//this avoids that the jams the application when typing fast
				this._oSearchDelayTimeout = setTimeout(function(_oEvent) {
					MapManager.filterLocomotives(sSearchString);
				}, 250);
			},

			/**
			 * Toggle the Spot Text switch
			 * @param(event) oEvent is the listener of the event
			 */
			onSpotSwitchChange: function(oEvent) {
				MapManager.toggleSpotText(oEvent.getSource().getState());
			},

			/**
			 * Print map
			 * @param(event) oEvent is the listener of the event
			 */
			onPressMapPrint: function(oEvent) {
			    
			    var FULL_MAP_LEGAL = "FULL_MAP_LEGAL";
			    var FULL_MAP_LETTER = "FULL_MAP_LETTER";
			    var SCREEN_LEGAL = "SCREEN_LEGAL";
			    var SCREEN_LETTER = "SCREEN_LETTER";
			    var printType = oEvent.getParameter("item").getKey();
			    
				var mapSVG = $("#" + this.byId("MyShopMapContainer").sId + " .lmShopSVG")[0];
				var width = parseFloat(mapSVG.getAttribute("width"));
				var height = parseFloat(mapSVG.getAttribute("height"));
				
				var pageHeight = 0;
				var pageWidth = 0;
				if (printType === FULL_MAP_LEGAL || printType === SCREEN_LEGAL) {
				    pageHeight = 92*8.5;
				    pageWidth = 92*14;
				}
				else {
				    pageHeight = 92*8.5;
				    pageWidth = 92*11;
				}
				
				var zoom = 0;
				if (pageWidth/width < pageHeight/height) {
				    zoom = pageWidth/width;
				} else {
				    zoom = pageHeight/height;
				}
                
				var sHtmlContent = '';

				if (mapSVG.firstChild.innerHTML) {

					// Modern browsers
					sHtmlContent += '<svg id="printMap" width="' + pageHeight + '" height="' + pageWidth + '">';

					// map is rotated 90 degrees so its printed vertically
					
					if (printType === FULL_MAP_LEGAL || printType === FULL_MAP_LETTER) {
    					sHtmlContent += '<g transform="scale(' + zoom + ')" transform-origin="top left">';
					}
				    sHtmlContent += '<g transform="translate(' + height + ',0) scale(1) rotate(90)">';
				    if (printType === SCREEN_LETTER || printType === SCREEN_LEGAL) {
					    sHtmlContent += '<g transform="' + mapSVG.firstChild.getAttribute("transform") + '" transform-origin="top left">';
					} 
					sHtmlContent += mapSVG.firstChild.innerHTML;
                    sHtmlContent += '</g>';
                    sHtmlContent += '</g>';
				} else {

					// IE
					var oMapSvgFirstChild = $("#" + this.byId("MyShopMapContainer").sId + " .lmShopSVG #MyShopMain")[0];
					var sMapSvgFirstChildHtml = new XMLSerializer().serializeToString(oMapSvgFirstChild);

					sHtmlContent += '<svg id="printMap" width="' + width + '" height="' + height + '">';
					sHtmlContent += sMapSvgFirstChildHtml;
				}

				sHtmlContent += '</svg>';
				var sTitle = "Map print";
				PrintManager.createPrintPage(sTitle, sHtmlContent, 1000);
			},

			/**
			 * Supervisor option to re-service a loco after release
			 */
			onReservice: function(oEvent) {
				var oLocomotive = oEvent.getSource().getModel();
				_this._oGlobalModel.setProperty("/currentLocomotive", oLocomotive);
				_this._departDialog.close();
				LocomotiveDataModel.fetchLocomotiveDefects(oLocomotive, _this.onFetchLocomotiveDefectsSuccessForService, _this.onFetchLocomotiveDefectsFailure,
					_this);
			},
		
			/**
			 * Supervisor option to re-arrive a loco after release
			 */
			onReshop: function(oEvent) {
				var oLocomotive = oEvent.getSource().getModel();
				_this._oGlobalModel.setProperty("/currentLocomotive", oLocomotive);
				_this._departDialog.close();
				LocomotiveDataModel.fetchLocomotiveDefects(oLocomotive, _this.onFetchLocomotiveDefectsSuccess, _this.onFetchLocomotiveDefectsFailure,
					_this);
			},
			
			/* START KIR0084 LMP2-30 */
			onFetchLocomotiveDefectsSuccessForService: function(oData) {
				if (!_this.oArriveManager) {
					_this.oArriveManager = ArriveManager.init("myShop","service");
				}
				
				var oShop = _this._oGlobalModel.getProperty("/currentShop");
				var oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");

				_this.oArriveManager.setType("service");
				_this.oArriveManager.onArriveProcessDialogOpen(oData.results,oShop,oLocomotive, _this);
			},
			/* END KIR0084 LMP2-30 */
			
			onFetchLocomotiveDefectsSuccess: function(oData) {
				if (!_this.oArriveManager) {
					_this.oArriveManager = ArriveManager.init("myShop","shopped");
				}
				
				var oShop = _this._oGlobalModel.getProperty("/currentShop");
				var oLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");

				_this.oArriveManager.setType("shopped");
				_this.oArriveManager.onArriveProcessDialogOpen(oData.results,oShop,oLocomotive, _this);
			},

			onFetchLocomotiveDefectsFailure: function() {

			},
			
			/**
			 * Supervisor option to remove loco from map after release
			 */
			onRemove: function(oEvent) {
				var sShopId = this._oGlobalModel.getProperty("/currentShop").Id;
				var oLocomotive = oEvent.getSource().getModel();
				
				var oPayload = {
					"ShopId":sShopId,
					"LocoId":oLocomotive.LocomotiveId
				};
				
				LocomotiveDataModel.departLocomotive(oPayload, _this.onDepartLocomotiveSuccess, _this.onDepartLocomotiveFailure, _this);
					
				this._departDialog.close();
			},
			
			onDepartLocomotiveSuccess:function(oData) {
				this.refreshLocomotives();
			},
			
			onDepartLocomotiveFailure:function(oError) {
				
			},
			
			/** 
			 * Cancel closes the release dialog
			 */
			onClickCancel: function(oEvent) {
				this._departDialog.close();
			},

			/**
			 * Empty Spot pressed on the map
			 * @param(string) sSpot is the spot number
			 */
			onSpotPress: function(sSpot) {

			},

			/**
			 * Locomotive press on the map
			 * @param(object) oLocomotive is the data of the locomotive
			 */
			onLocomotivePress: function(oLocomotive) {
				
				if (oLocomotive.ShopStatus === "R") {
					_this.showDepartDialog(oLocomotive);
				} else {
					_this.forceLocomotiveDetail(oLocomotive);
				}
			},

			forceLocomotiveDetail: function(oLocomotive) {
				var tab = Constants.TEXT_SHOPPED;
				if(oLocomotive.ShopReason === "S") {
					tab = Constants.TEXT_SERVICING;
					oLocomotive.isServiceGroupSelected = false;	
				}
				else if(oLocomotive.ShopReason === "R" || oLocomotive.ShopReasonDet === "R") {	// SHE0272: LLM2.29 - Road/Yard Repair - Navigate to service tab for RYR process
					tab = Constants.TEXT_SERVICING;
					oLocomotive.isServiceGroupSelected = false;
				}
				_this._oGlobalModel.setProperty("/forcedLocomotive", {
					"tab": tab
				});

				var oEventBus = sap.ui.getCore().getEventBus();
				oEventBus.publish("MyShopPage", "onLocomotiveDetail", {
					"oLocomotive": oLocomotive
				});
			},
			
			onConflictPress: function(oLocomotive) {
				var trackSpot = oLocomotive.TrackSpot;
				var plannedTrackSpot = oLocomotive.PlannedTrack + "/" + oLocomotive.PlannedSpot;
				alert("Conflict : " + oLocomotive.LocomotiveId + " is at " + trackSpot + " but was planned at " + plannedTrackSpot);
			},

			onMoveLocomotive: function(oLocomotive, oPayload, fSuccess, fFailure) {
				if (this._oViewPropertiesModel.getProperty("/IsCurrentShift") !== true) {
					var dStartShift = this._oViewPropertiesModel.getProperty("/ShiftStartTime");
					oPayload["ShiftStartTs"] = Formatter.changeToUTCTimestamp(dStartShift);
				}

				LocomotiveDataModel.moveSelectedLocomotive(oPayload, fSuccess, fFailure, _this);
			},

			/**
			 * Map button pressed
			 */
			onMapPress: function() {
				this.refreshLocomotives();
			},

			/**
			 * List button pressed
			 */
			onListPress: function() {
				_this.oRouter.getTargets().display("detailOverview");
			},

			/**
			 * Display a dialog containing all the possible shifts to be selected
			 */
			onShiftSelectMenuPress: function(oEvent) {
				var oButton = oEvent.getSource();
				if (!this.oShiftSelectPopover) {
					this.oShiftSelectPopover = sap.ui.xmlfragment("idMyShopShiftSelect", "com.sap.cp.lm.view.map.SelectShift", this);
					this.getView().addDependent(this.oShiftSelectPopover);
					this.oShiftSelectPopover.attachAfterOpen(function(oEvt) {
						_this.afterOpen = true;
						var oShiftList = sap.ui.core.Fragment.byId("idMyShopShiftSelect", "idShiftList");
						var iShiftIndex = _this.getShiftIndex();
						oShiftList.setSelectedItem(oShiftList.getItems()[iShiftIndex], true, true);
					});
				}
				this.oShiftSelectPopover.setModel(this._oGlobalShiftModel, "Shift");
				this.oShiftSelectPopover.openBy(oButton);
			},

			/**
			 * New shift is selected
			 */
			onShiftSelectionChange: function(oEvent) {
				if (_this.afterOpen === true) {
					_this.afterOpen = false;
				} else {
					var bPath = oEvent.getSource().getSelectedItem().getBindingContext("Shift").sPath;
					var oShift = this.oShiftSelectPopover.getModel("Shift").getProperty(bPath);
					this._applyShift(oShift);
				}
			},

			/**
			 *  Refresh button is pressed
			 */
			onRefreshPress: function() {
				_this.refreshLocomotives();
			}
		});
});