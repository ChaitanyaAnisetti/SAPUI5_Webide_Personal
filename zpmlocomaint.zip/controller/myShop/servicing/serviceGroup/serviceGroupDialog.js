/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.21                                           *
* Project        : Locomotive Maintenance                               *
* Description    : Controller for Service Group dialogs. Hook methods   *
*                  of view life cycle can be imeplemented for fragment  *
*                  life cycle.                                          *
*&----------------------------------------------------------------------*/

sap.ui.define([
		"com/sap/cp/lm/controller/common/FragmentBaseDelegate",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"com/sap/cp/lm/util/ErrorManager"
	], function(BaseDelegate, BusyIndicator, LocomotiveDataModel, Filter, FilterOperator, ErrorManager) {
		"use strict";
		var _this;
		return BaseDelegate.extend("com.sap.cp.lm.controller.myShop.servicing.serviceGroup.serviceGroupDialog", {

			_sFragmentName: "com.sap.cp.lm.view.myShop.servicing.serviceGroup.serviceGroupDialog",
			oSourceViewController: null,
			/**
			 * Fragment Initialization method
			 * 
			 */
			onInit: function() {
				_this = this;
				this._initParameters();
				LocomotiveDataModel.fetchUngroupedLocomotives(this._fnsucessfetchUngroupedLoco, "", this);
			},

			//Initialize the Parameters 

			_initParameters: function() {

				//Shopped loco master controller instance which is required to reload the master page on successfull creation
				this.oSourceViewController = this.oParameters.oSourceViewController;

				this.oSourceViewController = this.oSourceViewController._oGlobalModel.getProperty("/locomotiveMasterController");
				this._oGlobalModel = this.oSourceViewController._oGlobalModel;
				//Task list type Drop down field
				this._oDropDown = this.getFragment().getContent()[0].getItems()[0].getItems()[1].getItems()[1];
				//Ungrouped Locomotives Table
				this._oTable = this.getFragment().getContent()[0].getItems()[1];
				//Group Description Input field
				this._oGroupDesc = this.getFragment().getContent()[0].getItems()[0].getItems()[0].getItems()[1];

				if (this._oGlobalModel.getProperty("/currentServiceLocomotive")) {
					//In Service group edit mode , disable the tasklist type Dropdown
					if (this._oGlobalModel.getProperty("/currentServiceLocomotive").isServiceGroupSelected && !this.oParameters.isCreateServiceGroup) {
						this._sMode = "EDIT";
						this._oDropDown.setEnabled(false);
						this.getFragment().getButtons()[1].setVisible(false);
					} else {
						this._sMode = "CREATE";
						this.getFragment().getButtons()[2].setVisible(false);
					}
				} else {
					this.getFragment().getButtons()[2].setVisible(false);
				}

			},

			//Initialize the list incase of service group list is in edit mode.

			setSelectedLocos: function(oList, aGroupHeader) {
				_this._oGroupDesc.setValue(aGroupHeader.sSrvcGrpDescr);
				//Get the list of locomotives in Master Page for selected Group
				//Iterate through the list and set selected item
				//Change the Create Button Text to Savw
				_this._oGlobalModel.getProperty("/currentServiceLocomotive").ServiceGroupItemSet.results.forEach(function(oGroupedItem) {
					_this._oTable.getItems().forEach(function(oItem) {
						if (oItem.getBindingContext().getObject().LocomotiveId === oGroupedItem.LocomotiveId) {
							oItem.setSelected(true);
						}
					});
				});

			},

			_fnsucessfetchUngroupedLoco: function(oResponse) {

				var aTaskListType = [];
				var bRecordExist = false;
				var aItem = {};
				var oLocos = oResponse.results;
				var aTaskKey = "";

				if (this._sMode === "EDIT") {
					this._oGlobalModel.getProperty("/currentServiceLocomotive").ServiceGroupItemSet.results.forEach(function(oItem) {
						oLocos.push(oItem);
					});
					aTaskKey = this._oGlobalModel.getProperty("/currentServiceLocomotive").TasklistGroupKey;

				} else {
					if (oResponse.results.length > 0) {

						aTaskKey = oResponse.results[0].TasklistGroupKey;
					}
				}

				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setProperty("/ungroupedLocomotives", oResponse.results);
				//Prepare the drop Down Values for task List type
				oLocos.forEach(function(oItem) {
					aItem = {};
					bRecordExist = false;
					aItem.TasklistGroupKey = oItem.TasklistGroupKey;
					aItem.TasklistCounter = oItem.TasklistCounter;
					aItem.TasklistType = oItem.TasklistType;
					aItem.TasklistDescription = oItem.TasklistDescription;
					aTaskListType.forEach(function(oTaskItem) {
						if (aItem.TasklistGroupKey === oTaskItem.TasklistGroupKey) {
							bRecordExist = true;
						}
					});
					if (!bRecordExist) {

						aTaskListType.push(aItem);
					}
				});
				oModel.setProperty("/taskListType", aTaskListType);
				this.getFragment().setModel(oModel);
				_this._oDropDown.setSelectedKey(aTaskKey);
				_this.filterLoco(aTaskKey);
				if (this._sMode === "EDIT") {

					this.setSelectedLocos("", this._oGlobalModel.getProperty("/currentServiceLocomotive"));
				}

			},
			onDialogClose: function() {
				this.getFragment().close();
			},

			onAfterRendering: function() {
				BusyIndicator.hideBusyIndicator();
			},
			filterLoco: function(sSelectedKey) {
				var aFilters = [];
				aFilters = [
					new Filter("TasklistGroupKey", FilterOperator.EQ, sSelectedKey)
				];
				_this._oTable.removeSelections();
				_this._oTable.getBinding("items").filter(aFilters);
			},
			onChangeDropDownFilter: function(oEvent) {
				var oSelObject = oEvent.getParameter("selectedItem").getBindingContext().getObject();
				_this.filterLoco(oSelObject.TasklistGroupKey);
			},

			onAddReportingGroup: function(oEvent) {
				if (this.validate()) {

					var oPayload = _this.preparePayload();
					LocomotiveDataModel.createServiceGroup(oPayload, _this.onSuccessServiceGroupCreate, _this.onErrorServiceGroupCreate, _this);
				}

			},

			onSuccessServiceGroupCreate: function() {

				this.getFragment().close();
				this.oSourceViewController.onRefreshMasterList();
			},
			onErrorServiceGroupCreate: function() {

			},

			onSaveGroup: function(oEvent) {
				if (this.validate()) {
					var oPayload = _this.preparePayload();
					LocomotiveDataModel.createServiceGroup(oPayload, _this.onSuccessServiceGroupCreate, _this.onErrorServiceGroupCreate, _this);
				}

			},

			validate: function(oEvent) {
				if (!this._oGroupDesc.getValue()) {
					ErrorManager.handleError("", "Group description cannot be Empty.");
					return false;
				}
				if (this._oTable.getSelectedContexts().length < 2) {
					ErrorManager.handleError("", "You must select more than one Locomotive.");
					return false;
				}
				return true;
			},

			preparePayload: function() {
				if (this._oTable.getSelectedContexts().length > 0) {
					var oPayload = {};
					if (this._sMode === "EDIT") {
						oPayload.SrvcGrpId = this._oGlobalModel.getProperty("/currentServiceLocomotive").SrvcGrpId;
					} else {
						oPayload.SrvcGrpId = "9999999999999999999999";
					}

					var aSelTaskList = this._oDropDown.getSelectedItem().getBindingContext().getObject();
					oPayload.TasklistType = aSelTaskList.TasklistType;
					oPayload.TasklistGroupKey = aSelTaskList.TasklistGroupKey;
					oPayload.TasklistCounter = aSelTaskList.TasklistCounter;
					oPayload.TasklistDescription = aSelTaskList.TasklistDescription;

					oPayload.SrvcGrpDescr = this._oGroupDesc.getValue();
					oPayload.Shop = this.oSourceViewController._oGlobalModel.getProperty("/currentShop").Id;
					oPayload.ServiceGroupItemSet = [];

					this._oTable.getSelectedContexts().forEach(function(oSelContext) {
						var aSelData = {};
						var oSelObject = oSelContext.getObject();
						aSelData.EquipNo = oSelObject.EquipNo;
						aSelData.TasklistType = oSelObject.TasklistType;
						aSelData.OrderNo = oSelObject.OrderNo;
						aSelData.TasklistGroupKey = oSelObject.TasklistGroupKey;
						if (_this._sMode === "EDIT") {
							aSelData.SrvcGrpId = oSelObject.SrvcGrpId;
						} else {
							aSelData.SrvcGrpId = "9999999999999999999999";
						}
						aSelData.TasklistCounter = oSelObject.TasklistCounter;
						aSelData.LocomotiveId = oSelObject.LocomotiveId;
						oPayload.ServiceGroupItemSet.push(aSelData);
					});
					return oPayload;
				} else {

				}
			}

		});
	}

);