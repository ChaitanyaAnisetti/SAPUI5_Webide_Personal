/*&----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2019.03.07                                           *
 * Incidinet      : EAM-ASR3413183 - PM Loco Main phase 2                *
 * Description    : Commented shopped sort order based on ETR's          *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : KIR0094                                              *
 * Date           : 2019.04.01                                           *
 * Incidinet      : LMP2-34 Add Train Name to Servicing Groups           *
 * Description    : Commented shopped sort order based on ETR's          *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : KIR0094                                              *
 * Date           : 2019.04.12                                           *
 * Incidinet      : LMP2-28 Confirm Inbound Data			             *
 * Description    : New event handler for confirm inbound locos          *
 *&----------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
* Author/Changed By   : BAJ0018				        		       		  *
* Date                : 6-June-2019                                       *
* Project             : Locomotive Maintenance Phase 2                    *
* Description         : Added logic for system view and productivity      *
/*&-----------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*    
* Author/Changed By   : BAJ0018				        		       		  *
* Date                : 21-August-2019                                    *
* Project             : Locomotive Maintenance Phase 3                    *
* Description         : Added logic for shopped KPI                       *
/*&-----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : SHE0272                                              *
 * Date           : 07.Jun.2021                                          *
 * Incidinet      : LLM2.29 - Road/Yard Repair			              	 *
 * Description    : Added a sorting condition to sort data for			 *
					V and R in servicing tab							 *
 * Search Term    : LLM2.29                                              *
 *&----------------------------------------------------------------------*/
sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"com/sap/cp/lm/util/Constants",
		"com/sap/cp/lm/util/Formatter",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
		"com/sap/cp/lm/model/craft/CraftDataModel",
		"com/sap/cp/lm/controller/locomotives/LocomotiveManager",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		'sap/m/VBox',
		'sap/m/List',
		'sap/m/Button',
		"sap/m/Label",
		"sap/m/StandardListItem",
		"sap/m/Bar",
		"sap/m/HBox",
		"sap/m/Panel",
		"sap/m/Toolbar",
		"com/sap/cp/lm/controller/myShop/servicing/serviceGroup/serviceGroupDialog"

	],

	function (Controller, Constants, Formatter, BusyIndicator, LocomotiveDataModel, CraftDataModel, LocomotiveManager, Filter, FilterOperator,
		VBox, List, Button, Label, StandardListItem, Bar, HBox, Panel, Toolbar, serviceGroupDialog) {
		"use strict";
		var _this;

		return Controller.extend("com.sap.cp.lm.controller.myShop.Master", {
			/**
			 * Initializes the controller
			 */
			onInit: function () {

				_this = this;
				// set an empty model to avoid premature requests
				this.getView().setModel(new sap.ui.model.json.JSONModel());
				this._oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());

				this._oI18nModel = this.getOwnerComponent().getModel("i18n");

				this._inboundList = this.getView().byId("inboundList");
				this._inboundList.attachEvent("updateFinished", this.inboundListUpdated.bind(this));

				this._shoppedList = this.getView().byId("shoppedList");
				this._shoppedList.attachEvent("updateFinished", this.shoppedListUpdated.bind(this));

				this._servicingList = this.getView().byId("serviceUngroupedLocomotives");
				this._servicingList.attachEvent("updateFinished", this.servicingListUpdated.bind(this));

				this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
				this._oGlobalLocomotiveModel = this.getOwnerComponent().getGlobalLocomotiveModel();
				this._oServiceUngroupedList = this.getView().byId("serviceUngroupedLocomotives");
				this._oServicegroupedList = this.getView().byId("servicegroupedLocomotives");
				_this._oGlobalModel.setProperty("/locomotiveMasterController", _this);
				_this.sCurrentShopId = this._oGlobalModel.getProperty("/currentShop").Id;
            	// Engine manf. JSON data 
				this._oEngManfModel = this.getOwnerComponent().getEngManfJsonModel();
				this.byId("locomotiveListSearchBar").setValue("");

				var binding = new sap.ui.model.Binding(this._oGlobalLocomotiveModel, "/", this._oGlobalLocomotiveModel.getContext("/"));
				binding.attachChange(function () {
					_this.refreshShopData();
				});

				this._oViewPropertiesModel = new sap.ui.model.json.JSONModel();
				this._initViewPropertiesModel();
				this.getView().setModel(this._oViewPropertiesModel, "viewProperties");

				// listen to event when list need refreshing
				var oEventBus = sap.ui.getCore().getEventBus();
				oEventBus.subscribe("MyShopMasterPage", "onRefreshMasterList", _this.onRefreshMasterList, _this);
				oEventBus.subscribe("ArriveManager", "arriveLocomotiveDone", _this.arriveLocomotiveDone, this);
				//Start : Added by KIR0084 : Confirm Inbound: LMP2-28
				oEventBus.subscribe("ArriveManager", "confirmInboundLocomotiveDone", _this.confirmInboundLocomotivesDone, this);
				oEventBus.subscribe("FleetDetails", "cancelInboundLocomotiveDone", _this.confirmInboundLocomotivesDone, this);
				oEventBus.subscribe("Fleet", "cancelInboundLocomotiveDone", _this.confirmInboundLocomotivesDone, this);
				oEventBus.subscribe("InboundDetails", "cancelInboundLocomotiveDone", _this.confirmInboundLocomotivesDone, this);
				//End : Added by KIR0084 : Confirm Inbound: LMP2-28

				_this.onRefreshMasterList();

			},

			refreshShopData: function () {
				var sSelectedSeg = _this.getView().byId("locomotiveListSegmentedButton").getSelectedKey();

				//Added KIR0084 Shop KPI change on shop change
				var oCurrentShop = _this._oGlobalModel.getProperty("/currentShop") || _this._oGlobalModel.getProperty("/newShop");
				var sCurrentShopId = oCurrentShop.Id;
				LocomotiveDataModel.fetchSystemViewKPIs(sCurrentShopId, _this.onRefreshShoppedKpiSuccess, null,
					this);
                 // Engine Manf. Odata call start 
					LocomotiveDataModel.fetchEngineManfacturer( _this.onfetchEngineManfacturerSuccess, null,
					this);
				var forcedLocomotive = _this._oGlobalModel.getProperty("/forcedLocomotive");
				if (forcedLocomotive) {
					sSelectedSeg = forcedLocomotive.tab;
				}

				if (!sSelectedSeg) {
					sSelectedSeg = Constants.TEXT_INBOUND;
				}

				_this.loadMasterShopData(sSelectedSeg, false);
			},

			/**
			 * Event handle for Segmented Button on Locomotive list.
			 * This method filters Shopped or Servicing.
			 * @param {Event}   oEvent is the event passed when the segment button is selected
			 */
			onClickSegmentedButton: function (oEvent) {
				_this._oGlobalModel.setProperty("/currentLocomotive", null);
				_this._oGlobalModel.setProperty("/currentServiceLocomotive", null);

				var sKey = oEvent.getParameter("key");
				this.loadMasterShopData(sKey, true);
			},

			/**
			 * Load the the list in master page when the plant/shop selection is changed
			 */
			loadMasterShopData: function (sKey, bNavigate) {

				BusyIndicator.showBusyIndicator();

				if ($(".lmEnableDetails")[0] && jQuery($(".lmEnableDetails")[0]).control()[0]) {
					jQuery($(".lmEnableDetails")[0]).control()[0].setEnabled(false);
				}
				//This propery is used in Details view (myShop/common/details) to control the visibility of Visit Details
				this.getView().getModel("global").setProperty("/selectedMyShopTab", sKey);
				// reset the searchbar values
				var oSearchField = this.byId("locomotiveListSearchBar");
				oSearchField.setValue("");
				_this._oGlobalModel.setProperty("/locomotiveMasterController", _this);
				switch (sKey) {
				case Constants.TEXT_INBOUND:
					_this._inboundList.removeSelections();
					_this._fetchInboundData();
					if (bNavigate) {
						window.setTimeout(function () {
							_this._oRouter.getTargets().display("locomotivesInboundBlankDetails");
						}, 0);
					}
					break;
				case Constants.TEXT_SHOPPED:
					_this._shoppedList.removeSelections();
					_this._fetchShoppedData();
					if (bNavigate) {
						window.setTimeout(function () {
							_this._oRouter.getTargets().display("locomotivesShoppedBlankDetails");
						}, 0);
					}
					break;
				case Constants.TEXT_SERVICING:
					_this.getView().byId("serviceUngroupedLocomotives").removeSelections();
					_this.getView().byId("servicegroupedLocomotives").removeSelections();
					this._fetchServiceData();
					if (bNavigate) {
						window.setTimeout(function () {
							_this._oRouter.getTargets().display("locomotivesShoppedBlankDetails");
						}, 0);
					}
					break;
				default:
				}

				BusyIndicator.hideBusyIndicator();
			},

			onHideMaster: function () {
				var oEventBus = sap.ui.getCore().getEventBus();
				oEventBus.publish("MyShopSC", "toggleSplitContainerShowMaster", {
					"hideMaster": true
				});
			},

			/**
			 * Create the view properties model for this view. 
			 */
			_initViewPropertiesModel: function () {
				var bHideMaster = false;
				if (this.getOwnerComponent().isIPadMode()) {
					bHideMaster = true;
				}
				this._oViewPropertiesModel.setProperty("/HideMaster", bHideMaster);
				//The SelectedTab context is the currently selected tab in the view (SHOPPED OR SERVICING)
				//by default we set it to SHOPPED
				var sInbound = this._oI18nModel.getProperty("INBOUND");
				this._oViewPropertiesModel.setProperty("/SelectedTab", sInbound);
				//The servicing groups search value
				this._oViewPropertiesModel.setProperty("/ServicingGroupsSearchValue", "");
				var aAvailableTabs = [];
				aAvailableTabs.push({
					key: this._oI18nModel.getProperty("INBOUND"),
					text: this._oI18nModel.getProperty("INBOUND")
				});
				aAvailableTabs.push({
					key: this._oI18nModel.getProperty("SHOPPED"),
					text: this._oI18nModel.getProperty("SHOPPED")
				});
				aAvailableTabs.push({
					key: this._oI18nModel.getProperty("SERVICING"),
					text: this._oI18nModel.getProperty("SERVICING")
				});
				this._oViewPropertiesModel.setProperty("/AvailableTabs", aAvailableTabs);
			},

			// START KIR0084 LMP2-28 Add handlers for filter dialog
			/**
			 * Display Filter Dialog
			 */
			onShowFilterDialogPress: function (oEvent) {
				if (!_this._oFilterDialog) {
					_this._oFilterDialog = sap.ui.xmlfragment(
						"com.sap.cp.lm.view.myShop.inbound.InboundFilterDialog",
						_this

					);

					// Add dialog view as dependent to main app
					_this.getView().addDependent(_this._oFilterDialog);
				}

				if (!_this._oFilterModel) {
					_this._oFilterModel = new sap.ui.model.json.JSONModel();
					_this.getView().setModel(_this._oFilterModel, "filterModel");
				}

				_this._oFilterDialog.open();
			},

			/**
			 * Handle user pressing OK on filter dialog
			 */
			onConfirmFilterPress: function (oEvent) {
				_this._oFilterDialog.close();
				_this.onRefreshMasterList();
			},

			/**
			 * Handle user closing the filter dialog
			 */
			onCloseFilterDialogPress: function (oEvent) {
				_this._oFilterDialog.close();
			},

			/**
			 * Prepare filter model for loading inbound list
			 */
			_prepareInboundFilterObject: function (sCurrentShopId) {
				var filterModel = _this.getView().getModel("filterModel");

				// If filter model does not exist, simply return the shop id
				if (!filterModel) {
					return sCurrentShopId
				}

				var retObj = {
					plant: sCurrentShopId
				}

				var mechanicalStatus = filterModel.getProperty("/MechanicalStatus");
				var inboundOnly = filterModel.getProperty("/InboundStatus") === "INBOUND";
				var trainSymbol = filterModel.getProperty("/TrainSymbol");

				if (mechanicalStatus) {
					retObj.DefectUsrStatus = mechanicalStatus;
				}
				if (inboundOnly) {
					retObj.InboundOnly = inboundOnly;
				}
				if (trainSymbol) {
					retObj.TrainName = trainSymbol;
				}

				return retObj;
			},
			// END KIR0084 LMP2-28 Add handlers for filter dialog

			/**
			 * function gets fired which refresh list is clicked				 */
			onRefresh: function (oEvent) {
				if (oEvent.getParameter("refreshButtonPressed")) {
					// START KIR0084 LMP2-28 Only clear filter model if it exists
					if (_this.getView().getModel("filterModel")) {
						_this.getView().getModel("filterModel").setData({});
					}
					// END KIR0084 LMP2-28 Only clear filter model if it exists
					_this.onRefreshMasterList();
				}
			},

			onRefreshMasterList: function () {
				// Added - Vikram Set the tab to shopped if system view locomotive
				if (this._oGlobalModel.getProperty("/systemViewLocomotive")) {
					this._oGlobalModel.setProperty("/forcedLocomotive", {
						"tab": Constants.TEXT_SHOPPED
					});
				}
				// End Vikram

				var forcedLocomotive = this._oGlobalModel.getProperty("/forcedLocomotive");

				if (forcedLocomotive) {
					_this._oViewPropertiesModel.setProperty("/SelectedTab", forcedLocomotive.tab);
					_this.getView().byId("locomotiveListSegmentedButton").setSelectedKey(forcedLocomotive.tab);
				}

				_this.doRefreshMasterList();
			},

			doRefreshMasterList: function () {
				// BusyIndicator.showBusyIndicator();     // LMP2-28 Remove this because it causes app to stay busy on failure
				var sCurrentShopId = _this._oGlobalModel.getProperty("/currentShop").Id;
				var sCurrentTab = _this._oViewPropertiesModel.getProperty("/SelectedTab");

				//Added BAJ0018 Shop KPI
				LocomotiveDataModel.fetchSystemViewKPIs(sCurrentShopId, _this.onRefreshShoppedKpiSuccess, null,
					this);
				switch (sCurrentTab) {
				case Constants.TEXT_INBOUND:
					_this.onRefreshInboundLocomotives(sCurrentShopId);
					break;
				case Constants.TEXT_SHOPPED:
					_this.onRefreshShoppedLocomotives(sCurrentShopId);
					break;
				case Constants.TEXT_SERVICING:
					_this.getView().byId("serviceUngroupedLocomotives").getBinding("items").filter([]);
					_this.getView().byId("servicegroupedLocomotives").getBinding("items").filter([]);
					_this.onRefreshServiceLocomotives(sCurrentShopId);
					break;
				default:
				}

				// set the locomotive type filter and sorter dialog to the defaults values (Shopped List)
				if (_this._oShoppedSortDialog) {
					_this._oShoppedSortDialog.destroy();
					_this._oShoppedSortDialog = null;
				}
			},

			//Check whether reload locomotives required
			_isReloadRequired: function (aData, bFromBindingChange) {
				var sNewShopID;
				if (_this._oGlobalModel.getProperty("/currentShop")) {
					sNewShopID = _this._oGlobalModel.getProperty("/currentShop").Id;
				} else if (_this._oGlobalModel.getProperty("/newShop")) {
					sNewShopID = _this._oGlobalModel.getProperty("/newShop").Id;
				}

				if (_this.sCurrentShopId !== sNewShopID) {
					_this.sCurrentShopId = sNewShopID;
					var sCurrentTab = this._oViewPropertiesModel.getProperty("/SelectedTab");

					switch (sCurrentTab) {
					case Constants.TEXT_INBOUND:
						_this._oGlobalLocomotiveModel.setProperty("/Servicing", null);
						break;
					case Constants.TEXT_SHOPPED:
						_this._oGlobalLocomotiveModel.setProperty("/Inbound", null);
						_this._oGlobalLocomotiveModel.setProperty("/Servicing", null);
						break;
					case Constants.TEXT_SERVICING:
						_this._oGlobalLocomotiveModel.setProperty("/Inbound", null);
						break;
					default:
					}
					return true;
				}

				if (!aData && !bFromBindingChange) {
					return true;
				}

				return false;
			},

			onRefreshInboundLocomotives: function (sCurrentShopId) {
				//console.log("onRefreshInboundLocomotives: "+sCurrentShopId);
				LocomotiveDataModel.fetchInboundLocomotives(_this._prepareInboundFilterObject(sCurrentShopId), _this.onRefreshInboundLocomotivesSuccess,
					null, _this);
			},

			onRefreshShoppedLocomotives: function (sCurrentShopId) {
				//console.log("onRefreshShoppedLocomotives: "+sCurrentShopId);
				LocomotiveDataModel.fetchShoppedLocomotives(sCurrentShopId, _this.onRefreshShoppedLocomotivesSuccess,
					null, _this);
				//Added BAJ0018 Shop KPI
				LocomotiveDataModel.fetchSystemViewKPIs(sCurrentShopId, _this.onRefreshShoppedKpiSuccess, null,
					this);

			},

			onRefreshServiceLocomotives: function (sCurrentShopId) {
				LocomotiveDataModel.fetchServiceLocomotives(sCurrentShopId, _this.onRefreshServiceLocomotivesSuccess,
					null, _this);
			},

			onRefreshPostArrival: function (sCurrentShopId) {
				//console.log("onRefreshPostArrival: "+sCurrentShopId);
				LocomotiveDataModel.fetchShoppedLocomotives(sCurrentShopId, _this.onRefreshShoppedPostArrivalSuccess,
					null, _this);
				LocomotiveDataModel.fetchInboundLocomotives(sCurrentShopId, _this.onRefreshInboundPostArrivalSuccess,
					null, _this);
				LocomotiveDataModel.fetchServiceLocomotives(sCurrentShopId, _this.onRefreshServicedPostArrivalSuccess,
					null, _this);
			},

			/**
			 * refresh data after arrival
			 */
			arriveLocomotiveDone: function (sChannel, oEvent, oData) {
				_this.onRefreshPostArrival(_this.sCurrentShopId);

				if (oData.success === true) {
					if (oData.origin === "defectsTable") {
						_this._fetchInboundData();
						if (this.getView().getModel("global").getProperty("/selectedMyShopTab") === Constants.TEXT_INBOUND) {
							window.setTimeout(function () {
								_this._oRouter.getTargets().display("locomotivesInboundBlankDetails");
							}, 0);
						}
					} else if (oData.origin === "workPlan") {
						_this._fetchShoppedData();
					}
				}
			},

			//Start : Added by KIR0084 : Confirm Inbound Confirmation callback event callback handler: LMP2-28
			/**
			 * refresh data after confirm inbound
			 */
			confirmInboundLocomotivesDone: function (sChannel, oEvent, oData) {
				_this._fetchInboundData(true);
			},
			//End : Added by KIR0084 : Confirm Inbound: LMP2-28

			onRefreshInboundPostArrivalSuccess: function (oData) {
				_this._oGlobalLocomotiveModel.setProperty("/Inbound", oData.results);
				BusyIndicator.hideBusyIndicator();
			},

			onRefreshShoppedPostArrivalSuccess: function (oData) {
				_this._oGlobalLocomotiveModel.setProperty("/Shopped", oData.results);
				BusyIndicator.hideBusyIndicator();
			},

			onRefreshServicedPostArrivalSuccess: function (oData) {
				_this._oGlobalLocomotiveModel.setProperty("/Servicing", oData.results);
				BusyIndicator.hideBusyIndicator();
			},

			/**
			 * refreshing Inbound locomotives completed
			 * @param(object) oData is the data returned via the call
			 */
			onRefreshInboundLocomotivesSuccess: function (oData) {
				_this._oGlobalLocomotiveModel.setProperty("/Inbound", oData.results);
				_this._fetchInboundData();
				//BusyIndicator.hideBusyIndicator     // LMP2-28 Remove this because it causes app to stay busy on failure
			},

			/**
			 * refreshing Shopped locomotives completed
			 * @param(object) oData is the data returned via the call
			 */
			onRefreshShoppedLocomotivesSuccess: function (oData) {
				_this._oGlobalLocomotiveModel.setProperty("/Shopped", oData.results);
				_this._fetchShoppedData();
				//BusyIndicator.hideBusyIndicator();     // LMP2-28 Remove this because it causes app to stay busy on failure
			},
			//Added BAJ0018 Shopped KPI
			onRefreshShoppedKpiSuccess: function (oData) {
				this._oGlobalModel.setProperty("/kpiInformation", oData.results[0]);
			},
			//End BAJ0018 Shopped KPI
			
			//Engine Manufacturer dropdown 
				onfetchEngineManfacturerSuccess: function (oData) {
				this._oEngManfModel.setData(oData.results);
			},

			
			/**
			 * refreshing Servicing locomotives completed
			 * @param(object) oData is the data returned via the call
			 */
			onRefreshServiceLocomotivesSuccess: function (oData) {
				_this._oGlobalLocomotiveModel.setProperty("/Servicing", oData.results);
				_this._fetchServiceData();
				//BusyIndicator.hideBusyIndicator();     // LMP2-28 Remove this because it causes app to stay busy on failure
			},

			/**
			 * Load the servicing list when the servicing tab is selected
			 */
			_fetchServiceData: function () {
				var aServiceData = this._oGlobalLocomotiveModel.getProperty("/Servicing");
				// Check whether service data is already loaded
				if (this._isReloadRequired(aServiceData)) {
					this.onRefreshServiceLocomotives(_this.sCurrentShopId);
				} else {
					this.initServiceList(aServiceData);

					this.getView().byId("serviceUngroupedLocomotives").removeSelections();
					this.getView().byId("servicegroupedLocomotives").removeSelections();
				}

				if (aServiceData) {
					var aUnGroupedLoco = this.getView().getModel().getProperty("/serviceUnGroupedLoco");
					if (aUnGroupedLoco) {
						_this.refreshCurrentLocomotive(aUnGroupedLoco);
					}
				}
			},
			//Initialze the service list with grouped and ungrouped locomotives
			initServiceList: function (oListData) {

				var aGroupedLoco = [];
				var aUnGroupedLoco = [];

				oListData.forEach(function (oRecord) {
					// if SrvcGrpId === "9999999999999999999999" then the locomotives are ungrouped
					if (oRecord.SrvcGrpId === "9999999999999999999999") {
						oRecord.ServiceGroupItemSet.results.forEach(function (aRecord) {
							aUnGroupedLoco.push(aRecord);
						});
					} else {

						var sLocoDescs = "";
						//Start : Added by KIR0084 : Add Train Name to Servicing Groups : LMP2-34
						var sLocoTrainName = "";
						//End : Added by KIR0084 : Add Train Name to Servicing Groups : LMP2-34

						oRecord.ServiceGroupItemSet.results.forEach(function (aRecord) {
							// aGroupedLoco.push(aRecord);
							if (sLocoDescs) {
								sLocoDescs = sLocoDescs + ", " + aRecord.LocomotiveId;
							} else {
								sLocoDescs = aRecord.LocomotiveId;
							}
							//Start : Added by KIR0084 : Add Train Name to Servicing Groups : LMP2-34
							if (sLocoTrainName) {
								// Check string before adding new value to prevent duplicates
								if (!sLocoTrainName.includes(aRecord.TrainName)) {
									sLocoTrainName = sLocoTrainName + ", " + aRecord.TrainName;
								}
							} else {
								sLocoTrainName = aRecord.TrainName;
							}
							//End : Added by KIR0084 : Add Train Name to Servicing Groups : LMP2-34
						});
						oRecord.locoDesc = sLocoDescs;
						//Start : Added by KIR0084 : Add Train Name to Servicing Groups : LMP2-34
						oRecord.trainNameDesc = sLocoTrainName;
						//End : Added by KIR0084 : Add Train Name to Servicing Groups : LMP2-34
						aGroupedLoco.push(oRecord);
					}
				});

				// var oModel = new sap.ui.model.json.JSONModel({
				// 	serviceUnGroupedLoco: aUnGroupedLoco,
				// 	serviceGroupedLoco: aGroupedLoco
				// });

				this.getView().getModel().setProperty("/serviceUnGroupedLoco", aUnGroupedLoco);
				this.getView().getModel().setProperty("/serviceGroupedLoco", aGroupedLoco);
			},

			/**
			 * Fetch Inbound data
			 */
			_fetchInboundData: function (forceRefresh) { // LMP2-28
				var inbound = this._oGlobalLocomotiveModel.getProperty("/Inbound");
				if (forceRefresh || this._isReloadRequired(inbound)) {
					this.onRefreshInboundLocomotives(_this.sCurrentShopId);
				} else {
					var oModel = new sap.ui.model.json.JSONModel({
						inboundData: inbound
					});
					this.getView().setModel(oModel);
					_this.refreshCurrentLocomotive(inbound);
				}
			},

			/**
			 * Fetch Shoppped data
			 */

			_compareEtrTs: function (a, b) {
				if (a.EtrTs < b.EtrTs)
					return -1;
				if (a.EtrTs > b.EtrTs)
					return 1;
				return 0;
			},

			_sortShoppedData: function (aRawShopped) {

				var aSorted = [];
				var aBNB = [];
				var aISRV = [];
				var aOther = [];

				for (var i = 0; i < aRawShopped.length; i++) {
					var oLocomotive = aRawShopped[i];
					// SHE0272 - LLM2.29 - Road/Yard Repair	- Added a sorting condition to sort data for V and R in servicing tab
					if (oLocomotive.ShopReason !== "S" && oLocomotive.ShopReasonDet !== "V" && oLocomotive.ShopReasonDet !== "R") { // skip servicing loco
						if (oLocomotive.LocoUserStatus && oLocomotive.LocoUserStatus === "ISRV") {
							aISRV.push(oLocomotive);
						} else {
							if (oLocomotive.LocoUserStatus && oLocomotive.LocoUserStatus === "BNB") {
								aBNB.push(oLocomotive);
							} else {
								aOther.push(oLocomotive);
							}
						}
					}
				}
				/*Commented by Vikram - Fixed sort order*/
				//	aISRV.sort(_this._compareEtrTs);
				//	aOther.sort(_this._compareEtrTs);
				/*Commented by Vikram - Fixed sort order*/

				aSorted = aBNB;

				for (var j = 0; j < aISRV.length; j++) {
					var oISRV = aISRV[j];
					aSorted.push(oISRV);
				}

				//	aSorted = aISRV;

				for (j = 0; j < aOther.length; j++) {
					var oOther = aOther[j];
					aSorted.push(oOther);
				}

				return aSorted;
			},

			_fetchShoppedData: function () {
				var aRawShopped = this._oGlobalLocomotiveModel.getProperty("/Shopped");

				var aShopped = _this._sortShoppedData(aRawShopped);
				var oModel = new sap.ui.model.json.JSONModel({
					shoppedData: aShopped
				});

				this.getView().setModel(oModel);
				_this.refreshCurrentLocomotive(aShopped);

				//Added  vikram set the default locomotive from system view 
				if (this._oGlobalModel.getProperty("/systemViewLocomotive")) {
					var oLocomotive = {
						"LocomotiveId": this._oGlobalModel.getProperty("/systemViewLocomotive")
					};
					var oShoppedList = this.getView().byId("shoppedList");

					if (oShoppedList && oLocomotive) {
						oShoppedList.getItems().forEach(function (oItem) {
							if (oItem.getBindingContext().getObject().LocomotiveId === oLocomotive.LocomotiveId) {
								oShoppedList.setSelectedItem(oItem, true, true);
							}
						});
					}
				}

				//End  Vikram

			},

			refreshCurrentLocomotive: function (aLocomotives) {
				var oCurrentLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");

				// START KIR0084 LMP2-28 Ensure loco is in list instead of just checking if it exists.
				var oCurrentLocoInList = oCurrentLocomotive && aLocomotives.filter(function (oLocomotive) {
					return (oLocomotive.LocomotiveId === oCurrentLocomotive.LocomotiveId);
				});

				if (oCurrentLocoInList && oCurrentLocoInList.length === 1) {
					var oLocomotive = oCurrentLocoInList[0];
					// END KIR0084 LMP2-28 Ensure loco is in list instead of just checking if it exists.
					_this._oGlobalModel.setProperty("/currentLocomotive", oLocomotive);
					if (oLocomotive.ShopReason === "S" || oLocomotive.ShopReason === "R") { // SHE0272: LLM2.29 - Road/Yard Repair - Added condition 'R'
						_this._oGlobalModel.setProperty("/currentServiceLocomotive", oLocomotive);
					}
					_this.setSelectedLocomotive(oLocomotive);
					return;
				} else {
					if (_this._oGlobalModel.getProperty("/sSelectedView") !== Constants.LOCOMOTIVES) {
						return;
					}

					window.setTimeout(function () {
						var sCurrentTab = _this._oViewPropertiesModel.getProperty("/SelectedTab");

						switch (sCurrentTab) {
						case Constants.TEXT_INBOUND:
							_this._oRouter.getTargets().display("locomotivesInboundBlankDetails");
							break;
						case Constants.TEXT_SHOPPED:
							_this._oRouter.getTargets().display("locomotivesShoppedBlankDetails");
							break;
						case Constants.TEXT_SERVICING:
							_this._oRouter.getTargets().display("locomotivesServicingBlankDetails");
							break;
						default:
						}
					}, 0);
				}
			},

			/**
			 * Set the current Selected locomotive in the List
			 */

			setSelectedLocomotive: function (oLocomotive) {

				var sCurrentTab = _this._oViewPropertiesModel.getProperty("/SelectedTab");

				var oList;
				switch (sCurrentTab) {
				case Constants.TEXT_SHOPPED:
					oList = _this.getView().byId("shoppedList");
					break;
				case Constants.TEXT_INBOUND:
					oList = _this.getView().byId("inboundList");
					break;
				case Constants.TEXT_SERVICING:
					oList = _this.getView().byId("serviceUngroupedLocomotives");
					break;
				default:
				}

				if (oList && oLocomotive) {
					oList.getItems().forEach(function (oItem) {
						if (oItem.getBindingContext().getObject().LocomotiveId === oLocomotive.LocomotiveId) {
							oList.setSelectedItem(oItem);
						}
					});
				}
			},

			/**
			 * Scroll the table to show the selected row on the list
			 */

			genericListUpdated: function (oListItem) {
				if (oListItem) {
					jQuery.sap.delayedCall(0, null, function () {
						oListItem.focus();
					});
				}
			},

			/**
			 * Inbound list updated
			 */
			inboundListUpdated: function () {
				var oListItem = this._inboundList.getSelectedItem();
				this.genericListUpdated(oListItem);
			},

			/**
			 * Shopped list updated
			 */
			shoppedListUpdated: function () {
				var oListItem = this._shoppedList.getSelectedItem();
				this.genericListUpdated(oListItem);
			},

			/**
			 * Servicing list updated
			 */
			servicingListUpdated: function () {
				var oListItem = this._servicingList.getSelectedItem();
				this.genericListUpdated(oListItem);
			},

			/**
			 * Event handle for Inbound Locomotive list when the list item
			 * is selected. This method navigates to the appropriate
			 * details page.
			 */

			onSelectInbound: function () {
				var sSelectedItemPath = this._inboundList.getSelectedItem().getBindingContext().getPath();
				var oLocomotive = this.getView().getModel().getProperty(sSelectedItemPath);
				_this._oGlobalModel.setProperty("/currentLocomotive", oLocomotive);
				_this._oGlobalModel.setProperty("/currentServiceLocomotive", null);
				_this._oGlobalModel.setProperty("/forcedLocomotive", null);
				_this._oGlobalModel.setProperty("/isGroup", null);

				BusyIndicator.showBusyIndicator();
				window.setTimeout(function () {
					_this._oRouter.getTargets().display("locomotivesInboundHome", oLocomotive);
				}, 0);
			},
			/**
			 * Event handle when the search text changes in the
			 * search bar on Locomotive list.
			 * @param {Event} oEvent is the event passed when the search
			 *            	  text is changed in the search bar.
			 */
			onSearchTextChanged: function (oEvent) {
				//If we're waiting to perform a search and the function 
				if (this._oSearchDelayTimeout) {
					clearTimeout(this._oSearchDelayTimeout);
				}
				// get the value entered as user type or on press enter
				var sSearchString = oEvent.getParameter("newValue") || oEvent.getParameter("query");
				//Otherwise we save the timer and perform a search after a small delay
				//this avoids that the jams the application when typing fast
				this._oSearchDelayTimeout = setTimeout(function (oEvent) {
					_this._filterList(sSearchString);
				}, 250);
			},

			/**
			 * Filter the list based on the searchString
			 * */
			_filterList: function (sSearchString) {
				_this._oGlobalModel.setProperty("/forcedLocomotive", null);

				var oFinalFilter;
				var oOrFilter = new sap.ui.model.Filter(this.prepareFilter(sSearchString), false);
				oFinalFilter = new Filter(oOrFilter, true);
				var sSelectedSeg = this.getView().byId("locomotiveListSegmentedButton").getSelectedKey();
				switch (sSelectedSeg) {
				case Constants.TEXT_INBOUND:
					this.getView().byId("inboundList").getBinding("items").filter(oFinalFilter);
					break;
				case Constants.TEXT_SHOPPED:
					this.getView().byId("shoppedList").getBinding("items").filter(oFinalFilter);
					break;
				case Constants.TEXT_SERVICING:
					var aFilters = new sap.ui.model.Filter(_this.prepareServiceFilter(sSearchString), false);
					var oFinalFilterunGrouped = new Filter(aFilters, true);
					var aServiceGrpFilters = new sap.ui.model.Filter(_this.prepareServiceGroupFilter(sSearchString), false);
					oFinalFilter = new Filter(aServiceGrpFilters, true);
					this.getView().byId("serviceUngroupedLocomotives").getBinding("items").filter(oFinalFilterunGrouped);
					this.getView().byId("servicegroupedLocomotives").getBinding("items").filter(oFinalFilter);
					// _this.filterServiceLoco(aFilters);
					break;
				default:
				}
			},
			filterServiceLoco: function (aFilter) {
				var Items = this.getView().byId("idServiceGroup").getItems();
				Items.forEach(function (oItem) {
					oItem.getContent()[0].getBinding("items").filter(aFilter);
				});
			},

			filterPanel: function (sSearchString) {
				var Items = this.getView().byId("idServiceGroup").getItems();
				var regExp = "/" + sSearchString + "/g";
				var sRes = "";
				Items.forEach(function (oItem) {
					oItem.getItems(0).getContent()[0].getItems().forEach(function (item) {
						item.getTitle();
					});
					sRes = oItem.getContent()[0].getItems()[0].getTitle().match(sSearchString);
				});
			},

			/**
			 * Prepare filters
			 * */
			prepareServiceFilter: function (sSearchString) {
				sSearchString = sSearchString ? sSearchString : "";
				var aOrFilters = [];
				aOrFilters = [
					new Filter("LocomotiveId", FilterOperator.Contains, sSearchString)
				];
				return aOrFilters;
			},
			prepareServiceGroupFilter: function (sSearchString) {
				sSearchString = sSearchString ? sSearchString : "";
				var aOrFilters = [];
				aOrFilters = [
					new Filter("locoDesc", FilterOperator.Contains, sSearchString),
					new Filter("SrvcGrpDescr", FilterOperator.Contains, sSearchString)
				];
				return aOrFilters;
			},
			/**
			 * Prepare filters
			 * */
			prepareFilter: function (sSearchString) {
				sSearchString = sSearchString ? sSearchString : "";
				var aOrFilters = [];
				aOrFilters = [
					new Filter("LocomotiveId", FilterOperator.Contains, sSearchString),
					new Filter("TrainName", FilterOperator.Contains, sSearchString)
				];
				return aOrFilters;
			},

			onSelectLocomotive: function (oEvent) {
				//set global current locomotive 
				var sSelectedItemPath = this._shoppedList.getSelectedItem().getBindingContext().getPath();
				var oLocomotive = this.getView().getModel().getProperty(sSelectedItemPath);

				_this._oGlobalModel.setProperty("/currentLocomotive", oLocomotive);
				_this._oGlobalModel.setProperty("/currentServiceLocomotive", null);
				_this._oGlobalModel.setProperty("/forcedLocomotive", null);
				_this._oGlobalModel.setProperty("/isGroup", null);

				window.setTimeout(function () {
					_this._oRouter.getTargets().display("locomotivesShoppedHome", oLocomotive);
				}, 0);
			},
			//Servicing****************************************************
			onSelectUnGroupedLocomotive: function (oEvent) {
				this.getView().byId("servicegroupedLocomotives").removeSelections();

				var sSelectedItemPath = oEvent.getSource().getSelectedItem().getBindingContext().getPath();
				var oLocomotive = this.getView().getModel().getProperty(sSelectedItemPath);
				oLocomotive.isServiceGroupSelected = false;
				_this._oGlobalModel.setProperty("/currentServiceLocomotive", oLocomotive);
				_this._oGlobalModel.setProperty("/currentLocomotive", oLocomotive);
				_this._oGlobalModel.setProperty("/isGroup", false);
				_this._oGlobalModel.setProperty("/forcedLocomotive", null);

				window.setTimeout(function () {
					_this._oRouter.getTargets().display("locomotivesServicingHome", oLocomotive);
				}, 0);
			},

			onSelectGroupedLocomotive: function (oEvent) {
				this.getView().byId("serviceUngroupedLocomotives").removeSelections();

				var oGroupObject = oEvent.getSource().getSelectedItem().getBindingContext().getObject();
				oGroupObject.isServiceGroupSelected = true;
				oGroupObject.oServiceGroupList = oGroupObject.ServiceGroupItemSet;

				var sSrvcGrpDescr = oGroupObject.SrvcGrpDescr;
				oGroupObject.sSrvcGrpDescr = sSrvcGrpDescr;
				oGroupObject.oMasterController = _this;

				_this._oGlobalModel.setProperty("/currentLocomotive", null);
				_this._oGlobalModel.setProperty("/currentServiceLocomotive", oGroupObject);
				_this._oGlobalModel.setProperty("/isGroup", true);
				_this._oGlobalModel.setProperty("/forcedLocomotive", null);

				//Start : LMP2-29
				var iOrderCount = oGroupObject.oServiceGroupList.results.length;
				//	_this._oGlobalModel.setProperty("/OrderCount", iOrderCount);
				this._oGlobalModel.setProperty("/ServiceGroupList", oGroupObject.oServiceGroupList.results);
				//End: LMP2-29
				window.setTimeout(function () {
					_this._oRouter.getTargets().display("locomotivesServicingHome", oGroupObject);
				}, 0);
			},

			onCreateServicingGroupPress: function (oEvent) {
				var aData = {};
				aData.oSourceViewController = this;
				aData.isCreateServiceGroup = true;
				aData.isServiceGroupSelected = false;
				var oServiceGroupDialog = new serviceGroupDialog(aData);
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oServiceGroupDialog);
				oServiceGroupDialog.getFragment().setContentWidth("40%");
				oServiceGroupDialog.getFragment().open();
			},

			onUnselectList: function () {
				var selectedMyShopTab = _this._oGlobalModel.getProperty("/selectedMyShopTab");
				switch (selectedMyShopTab) {
				case Constants.TEXT_INBOUND:
					_this._inboundList.removeSelections();
					window.setTimeout(function () {
						_this._oRouter.getTargets().display("locomotivesInboundBlankDetails");
					}, 0);
					break;
				case Constants.TEXT_SHOPPED:
					_this._shoppedList.removeSelections();
					window.setTimeout(function () {
						_this._oRouter.getTargets().display("locomotivesShoppedBlankDetails");
					}, 0);
					break;
				case Constants.TEXT_SERVICING:
					_this.getView().byId("serviceUngroupedLocomotives").removeSelections();
					_this.getView().byId("servicegroupedLocomotives").removeSelections();
					window.setTimeout(function () {
						_this._oRouter.getTargets().display("locomotivesShoppedBlankDetails");
					}, 0);
					break;
				default:
				}
			}

		});
	});