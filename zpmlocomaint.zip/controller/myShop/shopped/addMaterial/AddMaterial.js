/*///////////////////////// Change Log /////////////////////////////////     
Author         : SAP Custom Development                               
Date           : 2017.12.05                                           
Project        : Locomotive Maintenance                               
Description    : This is the manager for the Add Material dialog.     
                 Fetch material on OEM search and call service to add 
                 material to appropriate Work Order.                  
*************************************************************************  
Author/Changed By   : Sandesh Shirode(SHI0087)	               		 
Date                : 29-May-2019                                     
Project             : Locomotive Maintenance Phase 2                  
Description         : LMP2-8a: Issue Reserve Material			     
*************************************************************************
Changed By       : Steve Palme(PAL0121)
Change Code      : ASR3414893
Business Analyst : Soon Hong Cheah
Trans. Req.      : YD1K904915
Charm Request ID : 2000008938
Date             : 3/3/20
Purpose          : Add storage loc for materials
Details          : Add storage loc as input when adding material
*************************************************************************  
Author/Changed By   : SHE0272	               		 
Date                : 19-Aug-2021                                     
Project             : Display Permissable storage location                  
Description         : LLMBNB3.0: Fetch only ASSM location material	
*************************************************************************
* Author/Changed By   : SHE0272				        		       		   *
* Date                : 15-Sep-2021	                                       *
* Project             : Locomotive Maintenance Phase 2                     *
* Description         : Refresh issue with cross navigation		           *
* Search Term         : INC0110700                                         *
*///////////////////////////////////////////////////////////////////////

jQuery.sap.declare("com.sap.cp.lm.controller.myShop.shopped.addMaterial.AddMaterial");
jQuery.sap.require("sap.ndc.BarcodeScanner");
sap.ui.define([
	"com/sap/cp/lm/controller/common/FragmentBaseDelegate",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
	"com/sap/cp/lm/util/ErrorManager",
	"com/sap/cp/lm/model/material/MaterialModel",
	"sap/m/MessageBox"
], function (BaseDelegate, BusyIndicator, LocomotiveDataModel, ErrorManager, MaterialModel, MessageBox) {
	"use strict";
	var _this;

	return com.sap.cp.lm.controller.myShop.shopped.addMaterial.AddMaterial = {

		//----------------------------------------------------------------------
		// Initialize controller and dialog
		//----------------------------------------------------------------------

		/**
		 * Fragment Initialization method
		 */
		init: function (oContext, fReloadOwnerView) {
			_this = this;
			_this._oContext = oContext;
			_this._fReloadOwnerView = fReloadOwnerView;
			if (_this._oContext.getOwnerComponent) {
				_this._oGlobalModel = _this._oContext.getOwnerComponent().getGlobalModel();
			} else {
				_this._oGlobalModel = oContext._oGlobalModel;
			}

			return _this;
		},

		/*
		 * Add material dialog open
		 */
		onAddMaterialDialogOpen: function (oWorkOrder) {
			BusyIndicator.showBusyIndicator();

			if (!_this._oAddMaterialDialog) {
				_this._oAddMaterialDialog = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.shopped.addMaterial.AddMaterial",
					_this
				);
			}

			if (!_this._oContext.isFromMyWork) {
				_this._oOperationsList = oWorkOrder.OperationSet.results;
			} else {
				_this._oOperationsList = [];
				_this._oOperationsList.push(oWorkOrder);
				var oDropDown = sap.ui.getCore().byId("selectOperation");
				oDropDown.setSelectedKey(oWorkOrder.Activity);
			}

			_this.oModel = new sap.ui.model.json.JSONModel();
			_this.oModel.setProperty("/OperationSet", _this._oOperationsList);
			_this.oModel.setProperty("/DefaultOperation", _this._oOperationsList[0].Activity);
			_this.oModel.setProperty("/GMPSvisibility", oWorkOrder.GmpsStatus); // LMP2-8a
			_this.oModel.setProperty("/SelectedOrder", oWorkOrder.OrderNo); // LMP2-8a
			_this.oModel.setProperty("/SelectedShop", oWorkOrder.ShopId); // LMP2-8a
			_this.oModel.setProperty("/MatReservisibility", oWorkOrder.MatResStatus); // LMP2-8a
			var sOrderId = oWorkOrder.OrderNo; // LMP2-8
			MaterialModel.fetchGMPSinfo(sOrderId, _this); // LMP2-8

			_this._oAddMaterialDialog.setModel(_this.oModel);
			
			MaterialModel.FetchBNBMaterial(_this); // SHE0272 - LLMBNB3.0

			// Reset dialog content
			sap.ui.getCore().byId("addMaterialSearchBar").setValue("");

			var i18nModel = new sap.ui.model.resource.ResourceModel({
				bundleName: "com.sap.cp.lm.i18n.i18n"
			});
			_this._oAddMaterialDialog.setModel(i18nModel, "i18n");

			_this._oAddMaterialDialog.setContentWidth("50%");

			// _this._oContext.addDependent(_this._oAddMaterialDialog);

			_this._oAddMaterialDialog.open();

			var oInput = sap.ui.getCore().byId("issueMatInputId");
			oInput.attachBrowserEvent("mousewheel", function (oEvent) {
				oEvent.preventDefault();
			});
			oInput.attachBrowserEvent("keydown", function (oEvent) {
				if (oEvent.which === 38 || oEvent.which === 40) {
					oEvent.preventDefault();
				}
			});

			this.initTableProperties();

			BusyIndicator.hideBusyIndicator();
		},
		/*
		 * LMP2-8a Reserve material dialog open  
		 */
		onReserveMaterialDialogOpen: function (oEvent) {
			BusyIndicator.showBusyIndicator();

			var sOrderId = _this.oModel.getData().SelectedOrder;
			var sShopId = _this.oModel.getData().SelectedShop;
			// var sActivity = sap.ui.getCore().byId('selectOperation').getSelectedItem().getKey();
			_this.oResMatModel = new sap.ui.model.json.JSONModel();
			MaterialModel.fetchReserveMatDetails(sOrderId, sShopId, _this);
			// MaterialModel.fetchReserveMatDetails(sOrderId, sShopId, _this, sActivity);
			if (!_this._oReserveMaterialDialog) {
				_this._oReserveMaterialDialog = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.shopped.addMaterial.ReserveMaterialList",
					_this
				);
			}

			_this._oReserveMaterialDialog.setModel(_this.oResMatModel);
			var i18nModel = new sap.ui.model.resource.ResourceModel({
				bundleName: "com.sap.cp.lm.i18n.i18n"
			});

			_this._oReserveMaterialDialog.setModel(i18nModel, "i18n");
			_this._oReserveMaterialDialog.open();
			BusyIndicator.hideBusyIndicator();
		},
		//----------------------------------------------------------------------
		// Private functions
		//----------------------------------------------------------------------

		/*
		 * Initialize table and model
		 */
		_initializeTable: function (oCpPartNumberData) {
			_this.oModel.setProperty("/CpPartNumbers", oCpPartNumberData.results);
			_this._oAddMaterialDialog.setModel(_this.oModel);
		},

		/**
		 * Update table data
		 * [USED TO FILTER RESULTS FROM TABLE WHEN DATA WAS FULLY LOADED AND INSERTED TO TABLE ITEMS]
		 */
		/*_updateTable: function(sQuery) {
			var aFilters = [];
			
			if (sQuery && sQuery.length > 0) {
	            var filter = new sap.ui.model.Filter("Descr", sap.ui.model.FilterOperator.Contains, sQuery);
	            aFilters.push(filter);
	        }
	        
	        var list = sap.ui.getCore().byId("materialsTable");
	        var binding = list.getBinding("items");
	        binding.filter(aFilters, false);
		},*/

		/*
		 * Validate all form fields
		 */
		_validateForm: function () {
			var isValid = true;
			var oPayload = {};
			var oReturn = {};

			var oOperationsSelectedItem = sap.ui.getCore().byId('selectOperation').getSelectedItem();

			if (oOperationsSelectedItem) {
				var oOperation = _this._oOperationsList.filter(function (oOperationsListItem) {
					return oOperationsListItem.Activity === oOperationsSelectedItem.getKey();
				});

				oOperation = oOperation[0];

				if (oOperation) {
					oPayload.RoutingNo = oOperation.RoutingNo;
					oPayload.OpNode = oOperation.OpNode;

					var iRowIndex = 0;
					var iCountSelectedRow = 0;
					var oMaterialsTable = sap.ui.getCore().byId('materialsTable'),
						aMaterialItems = oMaterialsTable.getItems();
					var aMatList = _this.oModel.getProperty("/CpPartNumbers"); // Get all the records of material

					if (aMaterialItems.length > 0) {
						while (iRowIndex < aMaterialItems.length) {
							var oCurrentMat = aMatList[iRowIndex];
							var oMaterialItem = aMaterialItems[iRowIndex];
							var oMaterialItemContext = oMaterialItem.getBindingContext();
							var oMaterialItemObj = oMaterialItemContext.getObject();
							var oMaterialItemAggregations = oMaterialItem.mAggregations;

							if (oMaterialItemAggregations) {
								var oMaterialItemQuantityCell = oMaterialItemAggregations.cells[8];
								var oMaterialSerialNumCell = oMaterialItemAggregations.cells[9];
								if (oMaterialItemQuantityCell) {
									var iMaterialItemQuantity = oMaterialItemQuantityCell._lastValue;

									if (iMaterialItemQuantity > 0) {
										iCountSelectedRow++;
										var iAvailableQty = oMaterialItemObj.Available;
										var iIssueQty = iMaterialItemQuantity - iAvailableQty;
										if (iIssueQty > 0) {
											oPayload.WithdrawnQty = iAvailableQty; // Qty to be issued
											oPayload.RequiredQty = iIssueQty.toString(); // Reserve Qty
										} else {
											oPayload.WithdrawnQty = iMaterialItemQuantity;
											oPayload.RequiredQty = "0";
										}
										var sSerialNumTxt = oMaterialSerialNumCell._lastValue;
										if (sSerialNumTxt.length > 0) {
											oPayload.SerialNum = sSerialNumTxt;
										}
										oPayload.MaterialNo = oMaterialItemObj.MaterialNo;
										if (oCurrentMat.ValType.length > 0) {
											oPayload.By = oCurrentMat.ValType; // For backend to determine valution type from this field
										}

										oPayload.QtyUom = oMaterialItemObj.UOM;
										oPayload.Descr = oMaterialItemObj.Description;
										oPayload.StorageLoc = oMaterialItemObj.Sloc;					//ASR3414893
									}
								}
							}

							iRowIndex++;
						}

						if (iCountSelectedRow > 1) {
							isValid = false;
							ErrorManager.handleError("", "Fill quantity only for one material row.");
						} else if (iCountSelectedRow !== 1) {
							isValid = false;
							ErrorManager.handleError("", "Fill quantity for choosed material.");
						}
					} else {
						isValid = false;
						ErrorManager.handleError("", "No material to add. Search material with OEM Part Number/Material Number/Material Description.");
					}
				} else {
					isValid = false;
					ErrorManager.handleError("", "Selected Operation is invalid.");
				}
			} else {
				isValid = false;
				ErrorManager.handleError("", "Selected Operation is invalid.");
			}

			if (isValid) {
				$.each(oPayload, function (index, value) {
					if (isValid) {
						if (!value || value.length === 0) {
							isValid = false;
							ErrorManager.handleError("", "Please fill in all fields.");
						}
					}
				});
			}

			oReturn.isValid = isValid;
			oReturn.oPayload = oPayload;

			return oReturn;
		},

		/*
		 * Add material on submit
		 */
		_submitData: function (oPayload) {
			MaterialModel.addMaterialToOperation(oPayload, _this._endSubmitOnSuccess, null, _this);
		},

		/*
		 * Close dialog and launch refresh of context view
		 */
		_endSubmitOnSuccess: function (oResponse) {

			if (_this._oContext.isFromMyWork) {
				_this._oContext.isFromMyWork = false;
				_this._oContext.oSelectedMat = [];
				_this._oContext.oSelectedMat.push(oResponse);

			}

			_this._oAddMaterialDialog.close();

			if (_this._fReloadOwnerView && _this._oContext) {
				_this._fReloadOwnerView.apply(_this._oContext, null);
			}

		},

		//----------------------------------------------------------------------
		// Event handlers
		//----------------------------------------------------------------------

		/**
		 * Close dialog view
		 */
		onCloseAddMaterialDialog: function (Oevent) {
			if (_this._oContext.isFromMyWork) {
				_this._oContext.isFromMyWork = false;
			}
			_this._oAddMaterialDialog.close();

		},
		// LMP2-8a
		onCloseReserveMaterialDialog: function (oEvent) {
			_this._oReserveMaterialDialog.close();
		},
		/**
		 * Update table on search field change if query is valid
		 */
		onSearch: function (oEvent) {
			var sQuery = oEvent.getSource().getValue();

			var sShopId = _this._oGlobalModel.getProperty("/currentShop").Id;
			// Start - SHE0272 - LLMBNB3.0 - Added a new bnbFilter to pass in the service call
			var bnbFilter = "";
			if (!_this._oGlobalModel.getProperty("/currentLocomotive/BnbLoco")) {
				bnbFilter = _this.oModel.getProperty("/BNBMaterial");
			}
			// End - SHE0272 - LLMBNB3.0 - Added a new bnbFilter to pass in the service call
			MaterialModel.fetchCpPartNumber(sQuery, sShopId, _this._initializeTable, null, _this, bnbFilter);

			// if (sQuery && sQuery.length > 3) {
			// 	// eg values
			// 	// 10478827
			// 	// 10478828
			// 	// 10478806

			// 	var sShopId = _this._oGlobalModel.getProperty("/currentShop").Id;
			// 	MaterialModel.fetchCpPartNumber(sQuery, sShopId, _this._initializeTable, null, _this);

			// 	//_this._updateTable(sQuery);
			// } else if (sQuery.length > 0) {
			// 	ErrorManager.handleError("", "OEM Part Number is invalid.");
			// }
		},

		/**
		 * Submit form data
		 */
		onAddMaterialDialogConfirm: function (oEvent) {

			var oFormData = _this._validateForm();
			if (oFormData.isValid) {
				// Start LMP2-8a Check the Confirmation if user is ready to submit the Add material ( Issue/Reserve request )

				MessageBox.show(oFormData.oPayload.WithdrawnQty + " Material(s) will be issued and " +
					oFormData.oPayload.RequiredQty + " Material(s) will be reserve. Continue ?", {
						icon: MessageBox.Icon.CONFIRM,
						title: "Do you want to Continue?",
						actions: [MessageBox.Action.CANCEL, MessageBox.Action.OK],
						onClose: function (oEvent1) {
							if (oEvent1 === MessageBox.Action.OK) {
								_this._submitData(oFormData.oPayload);
							}
						}
					});
			}
		},
		//Start - LMP2-8a : Issue the reserve material for available qty
		onAddReserveMaterialDialogConfirm: function (oEvent) {
			var aReserveMatItems = this.oResMatModel.getProperty("/ReserveMat");
			var aPayloads = [];
			var oLoad = {};
			var isValid = "true";
			var aReserveMatTable = sap.ui.getCore().byId("IssueReserveTbl").getItems();

			if (aReserveMatTable.length > 0) {
				var iRowIndex = 0,
					iRowCounter = 0;
				while (iRowIndex < aReserveMatTable.length) {
					// oLoad.WithdrawnQty = aReserveMatTable[iRowIndex].getCells()[6].getValue(); // Issue
					// oLoad.SerialNum = aReserveMatTable[iRowIndex].getCells()[7].getValue();
					//Changing the cell number from 6 to 8 and 7 to 9 due to addition of columns
					oLoad.WithdrawnQty = aReserveMatTable[iRowIndex].getCells()[7].getValue(); // Issue
					oLoad.SerialNum = aReserveMatTable[iRowIndex].getCells()[8].getValue();
					oLoad.Bwart = aReserveMatItems[iRowIndex].Bwart;
					oLoad.By = aReserveMatItems[iRowIndex].By; // Using this field to let Backend know that to put this value into BATCH field of BAPI
					oLoad.ConfirmedQty = aReserveMatItems[iRowIndex].ConfirmedQty; // Available
					oLoad.StorageLoc   = aReserveMatItems[iRowIndex].StorageLoc;   // ij1
					oLoad.Descr = aReserveMatItems[iRowIndex].Descr;
					oLoad.Dmbtr = aReserveMatItems[iRowIndex].Dmbtr;
					oLoad.ItemNo = aReserveMatItems[iRowIndex].ItemNo;
					oLoad.MaterialNo = aReserveMatItems[iRowIndex].MaterialNo;
					oLoad.OpNode = aReserveMatItems[iRowIndex].OpNode;
					oLoad.QtyUom = aReserveMatItems[iRowIndex].QtyUom;
					oLoad.RequiredQty = aReserveMatItems[iRowIndex].RequiredQty; //  Reserve Qty
					oLoad.RoutingNo = aReserveMatItems[iRowIndex].RoutingNo;

					// Validate if issue qty is GREATER than Available Qty  	
					if (parseInt(oLoad.WithdrawnQty, 10) > parseInt(oLoad.ConfirmedQty, 10)) { // SHE0272 - Chnaged from string compare to integer check - INC0110700   

						ErrorManager.handleError("", "Material(s) Cannot be issued greater than available Quantity");
						isValid = "false";
					}

					// This condition is to avoid additional check at backend and reduce additional traffic on batch request
					if (oLoad.WithdrawnQty > 0) {
						aPayloads[iRowCounter] = oLoad;
						iRowCounter++;
					}
					oLoad = {}; // clear the workarea
					iRowIndex++;
				}
			}
			if (isValid === "true") {
				MaterialModel.AddReserveMaterial(aPayloads, this);
			}
		},
		//End - LMP2-8a
		initTableProperties: function () {
			var oTable = sap.ui.getCore().byId("materialsTable");
			var oDropDown = sap.ui.getCore().byId("selectOperation");
			if (_this._oContext.isFromMyWork) {
				// oTable.setMode("MultiSelect");
				oDropDown.setEnabled(false);
			} else {

				oDropDown.setEnabled(true);
				oTable.setMode("None");
			}

		},
		onSelectionofMaterial: function (oEvent) {
			var oSelItem = oEvent.getParameter("listItem");
			oSelItem.getCells()[2].setEnabled(oEvent.getParameter("selected"));
		},
		// Start LMP2-168_169
		onApplicableAssetPress: function (oEvent) {

			var sBindPath = oEvent.getSource().getBindingContext().sPath;
			var oData = _this._oAddMaterialDialog.getModel().getObject(sBindPath);
			var sMaterialNo, sPlant;

			sMaterialNo = oData.MaterialNo;
			sPlant = oData.p_shop_id;
			_this.oAppAssetModel = new sap.ui.model.json.JSONModel();
			_this._getSource = oEvent.getSource();

			MaterialModel.fetchAppAssetsInfo(sMaterialNo, sPlant, _this._setApplAssetoDataModel, null, _this);

		},

		_setApplAssetoDataModel: function (oAppAssetoData) {

			// Logic to pass data to PopOver
			if (!_this._oApplicableAssetsPopOver) {

				_this._oApplicableAssetsPopOver = sap.ui.xmlfragment(
					"com.sap.cp.lm.view.myShop.shopped.addMaterial.ApplicableAssets", _this);
				_this._oAddMaterialDialog.addDependent(_this._oApplicableAssetsPopOver);
			}

			_this.oAppAssetModel.setProperty("/ApplicableAssets", oAppAssetoData.results);
			_this._oApplicableAssetsPopOver.setModel(_this.oAppAssetModel);
			_this._oApplicableAssetsPopOver.openBy(_this._getSource);

		}
		// End LMP2-168_169
		// SCAN BAR CODE functionality
		// 	onScanPress: function (oEvent) {
		// 	sap.ndc.BarcodeScanner.scan(
		// 		function (mResult) {
		// 			alert("We got a bar code\n" +
		// 				"Result: " + mResult.text + "\n" +
		// 				"Format: " + mResult.format + "\n" +
		// 				"Cancelled: " + mResult.cancelled);
		// 		},
		// 		function (Error) {
		// 			alert("Scanning failed: " + Error);
		// 		}
		// 	);
		// }
		
	};
});