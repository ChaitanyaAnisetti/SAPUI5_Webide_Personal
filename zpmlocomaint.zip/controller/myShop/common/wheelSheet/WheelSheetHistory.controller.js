/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.21                                           *
* Project        : Locomotive Maintenance                               *
* Description    : Controller for Wheel Sheet History fragment tab      *
*                  on a Locomotive view. (Shopped and Inbound)          *
*&----------------------------------------------------------------------*/
/*&---------------------------------------------------------------------*    
 * Author         : SHE0272				                                 *
 * Date           : 26-Aug-2021                                          *
 * Project        : INC0107443 - Refresh Incident                        *
 * Description    : Replaced local model with global model as local 	 *
 *					model is failing when navigating between fleet, 	 *
 *					inbound, shopped and serving tab    				 *
 *                  Characteristics                                      *
 * Search Term    : INC0107443
 *&----------------------------------------------------------------------*/
/* #DontDelete : Yann */

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
	"com/sap/cp/lm/controller/common/PrintManager"
], function(Controller, Constants, Formatter, BusyIndicator, LocomotiveDataModel, PrintManager) {
	"use strict";

	var _this;

	return Controller.extend("com.sap.cp.lm.controller.myShop.common.wheelSheet.WheelSheetHistory", {

		/**
		 * Initializes the controller
		 */
		onInit: function() {
			_this = this;
			

			var oModel = new sap.ui.model.json.JSONModel();
			
			_this.oModel = oModel;
			_this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
			_this.getView().setModel(oModel);
			_this.wheelSheetDialogId = "WheelSheetDialog";
		},

		/*
		 * pass window resize to dialog
		 */
		handleWindowResize: function() {
			if (_this.oDialog) {
				_this.resizeDialog();
			}
		},

		/*
		 * get Locomotive Wheel Sheet History
		 */
		fetchLocomotiveWheelSheetHistory: function(oLocomotive) {
			_this.getView().byId("wheelSheetsList").removeSelections(true);

			var oCurrentLocomotive = oLocomotive;
			if(!oCurrentLocomotive) {
				oCurrentLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
			}
			LocomotiveDataModel.fetchLocomotiveWheelSheetHistory(oCurrentLocomotive, _this.fetchLocomotiveWheelSheetHistorySuccess, _this.fetchLocomotiveWheelSheetHistoryFailure,
				_this);
		},

		fetchLocomotiveWheelSheetHistorySuccess: function(oData) {
			// _this.oModel.setProperty("/WheelSheetHistory", oData.results);
			_this.getView().getModel("global").setProperty("/WheelSheetHistory", oData.results);  // SHE0272 - INC0107443 - Setting the data to global model
			setTimeout(function() {
				_this.oModel.refresh(true);
			}, 100);
		},

		fetchLocomotiveWheelSheetHistoryFailure: function(oData) {

		},

		onSelectWheelSheet: function(oEvent) {

			var wheelSheetsList = this.getView().byId("wheelSheetsList");
			var sSelectedItemPath = wheelSheetsList.getSelectedItem().getBindingContext("global").getPath();  // SHE0272 - INC0107443 - Changed to global model
			var oWheelSheet = this.getView().getModel("global").getProperty(sSelectedItemPath);  // SHE0272 - INC0107443 - Changed to global model

			BusyIndicator.showBusyIndicator();

			_this.onOpenWheelSheet(oWheelSheet);

		},

		resizeDialog: function() {
			var frameHeight = $(window).height();
			var frameWidth = $(window).width();

			var oItem = sap.ui.getCore().byId(_this.wheelSheetDialogId);

			oItem.setContentHeight(frameHeight * 0.75 + "px");
			oItem.setContentWidth(frameWidth * 0.75 + "px");
		},

		onOpenWheelSheet: function(oData) {

			var oWSHeader = {
				"MsetType": oData.MsetType,
				"OperationNbr": oData.OperationNbr,
				"OrderNbr": oData.OrderNbr,
				"SubOperNbr": oData.SubOperNbr,
				"EquipNbr": oData.EquipNbr
			};

			if (!_this.WSSaveBtnId) {
				_this.WSSaveBtnId = this.createId("WSSaveBtn");
			}

			if (!_this.WSSubmitBtnId) {
				_this.WSSubmitBtnId = this.createId("WSSubmitBtn");
			}

			if (!_this.oDialog) {

				_this.oDialog = new sap.m.Dialog({
					title: "{i18n>WHEELSHEET}",
					height: "100%",
					width: "100%",
					content: [],
					buttons: [
						new sap.m.Button({
							icon: "sap-icon://print",
							press: _this._onPressPrintWheelSheet
						}).addStyleClass("lmFooterButtonLeft"),
						new sap.m.Button({
							text: "{i18n>CLOSE}",
							press: function() {
								_this.oDialog.close();
							}
						}),
						new sap.m.Button(_this.WSSaveBtnId, {
							text: "{i18n>SAVE}",
							press: function() {
								var oController = _this.oDialog.getContent()[0].getController();
								oController.onSaveWheelSheet();
							}
						}),
						new sap.m.Button(_this.WSSubmitBtnId, {
							text: "{i18n>SUBMIT}",
							enabled: false,
							type: "Emphasized",
							press: function() {
								var oController = _this.oDialog.getContent()[0].getController();
								oController.onSubmitWheelSheet();
							}
						})
					],
					afterOpen: _this.resizeDialog
				});

				_this.wheelSheetDialogId = _this.oDialog.sId;

				var oContent = new sap.ui.xmlview({
					viewName: "com.sap.cp.lm.view.myShop.common.wheelSheet.WheelSheet"
				});

				_this.oDialog.addContent(oContent);

			}

			var oCurrentLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");

			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setProperty("/WSHeader", oWSHeader);
			oModel.setProperty("/WSSaveBtnId", _this.WSSaveBtnId);
			oModel.setProperty("/WSSubmitBtnId", _this.WSSubmitBtnId);
			_this.oDialog.setModel(oModel);
			_this.getView().addDependent(_this.oDialog);
			_this.oDialog.open();

			var oController = _this.oDialog.getContent()[0].getController();
			oController.fetchLocomotiveWheelSheet(oCurrentLocomotive);
		},

		_onPressPrintWheelSheet: function() {
			var oHtmlDialog = $("#" + _this.oDialog.sId + " .sapMDialogSection .lmWheelSheetView section");
			var sHtmlContent = oHtmlDialog[0].outerHTML;
			var sTitle = "Wheel Sheet print";

			PrintManager.createPrintPage(sTitle, sHtmlContent, 1000);
		}

	});
});