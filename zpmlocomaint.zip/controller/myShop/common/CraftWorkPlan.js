/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.21                                           *
* Project        : Locomotive Maintenance                               *
* Description    : Controller for Work Plan view for Craft.             *
*&----------------------------------------------------------------------*/
/*&---------------------------------------------------------------------*    
* Author         : KIR0084                                              *
* Date           : 2019.09.12                                           *
* Project        : LMP2-37 Do not show shift filter on select craft     *
*&----------------------------------------------------------------------*/

// #DontDelete : Daya New controller class , Do not delete any method in this class

sap.ui.define([
		"com/sap/cp/lm/controller/common/FragmentBaseDelegate",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"com/sap/cp/lm/controller/craft/CraftSearchManager"
	], function(BaseDelegate, BusyIndicator, LocomotiveDataModel, Filter, FilterOperator, CraftSearchManager) {
		"use strict";
		var _this;
		return BaseDelegate.extend("com.sap.cp.lm.controller.myShop.common.CraftWorkPlan", {
			
			_sFragmentName: "com.sap.cp.lm.view.myShop.common.crafts.CraftWorkPlan",
			/**
			 * Fragment Initialization method
			 */
			onInit: function() {
				BusyIndicator.showBusyIndicator();
				this._initParameters();
				
				_this = this;
				_this.loadCraftSearchFragment();
				_this.refreshWorkersList();
			},

			_initParameters: function() {
				this._oGlobalModel = this.oParameters.oSourceViewController.getController()._oGlobalModel;
				this._oSourceViewController = this.oParameters.oSourceViewController;
			},
			
			// #DontDelete : Q
			/**
			 * Load Craft Search Manager and display fragment
			 */
			loadCraftSearchFragment: function() {
				if (_this._oCraftSearchManager) {
					_this._oCraftSearchManager.destroy();
				}
				_this._oCraftSearchManager = new CraftSearchManager();
				_this._oCraftSearchManager = _this._oCraftSearchManager.init(_this, _this.refreshWorkersList, this.byId("idCraftWorkPlanList"));
				
				if (_this._oCraftSearchFragment) {
					_this._oCraftSearchFragment.destroy();
				}
				_this._oCraftSearchFragment = _this._oCraftSearchManager.getFragment();
				this.byId("craftWorkPlanSearchToolbar").addContent(_this._oCraftSearchFragment);
				
				//LMP2-37 Do not show remove assignment button on craft assignment list screen
				_this._oCraftSearchFragment.getItems()[1].setVisible(false);
			},
			
			// #DontDelete : Q
			/**
			 * Load Workers from service to backend
			 */
			refreshWorkersList: function() {
				LocomotiveDataModel.fetchCraftWorkPlanList(this._onSucccessCraftList, this._onErrorCraftList, this, this._oGlobalModel.getProperty(
					"/currentShop").Id);
			},

			_onSucccessCraftList: function(oData) {
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(oData.results);
				this.getFragment().setModel(oModel, "workPlanCrafts");
				BusyIndicator.hideBusyIndicator();
			},
			
			_onErrorCraftList: function() {

			},
		
			onCloseCrafts: function() {
				this.getFragment().close();
			},
			
			onAssignCrafts: function(oEvent) {
				var oSelContexts = this.getFragment().getContent()[0].getItems()[2].getContent()[0].getSelectedContexts();
				var oFragModel = oEvent.getSource().getModel("workPlanCrafts");
				var aAssignments = [];
				var oAssignment = {};
				var aOperationHeader = {};
				aOperationHeader.OpNode = this.oParameters.OpNode;
				aOperationHeader.Activity = this.oParameters.Activity;
				aOperationHeader.OrderNo = this.oParameters.OrderNo;
				aOperationHeader.PlanWorkDur = this.oParameters.PlanWorkDur;
				aOperationHeader.PlanWorkUom = this.oParameters.PlanWorkUom;
				aOperationHeader.RoutingNo = this.oParameters.RoutingNo;
				aOperationHeader.PlanStartTs = this.oParameters.PlanStartTs;
				aOperationHeader.PlanStartTz = this.oParameters.PlanStartTz;
				aOperationHeader.Shop = this.oParameters.shopId;
				oSelContexts.forEach(function(oSelContext) {
					oAssignment = {};
					oAssignment.RoutingNo = aOperationHeader.RoutingNo;
					oAssignment.OpNode = aOperationHeader.OpNode;
					oAssignment.PersonNo = oFragModel.getObject(oSelContext.sPath).PersonNo;
					aAssignments.push(oAssignment);
				});
				aOperationHeader.AssignmentSet = aAssignments;
				//get the selected rows
				//prepare the payload
				//call the 
				LocomotiveDataModel.upDateCraftAssignments(aOperationHeader, this._oSourceViewController.getController().onOperationUpdateSucesss,
					this._updateCraftPlanError,
					this._oSourceViewController.getController());

				this.getFragment().close();

			},

			_updateCraftPlanError: function() {

			}

		});
	}

);