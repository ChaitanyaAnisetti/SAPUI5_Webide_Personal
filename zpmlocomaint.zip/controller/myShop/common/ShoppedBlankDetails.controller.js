/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.21                                           *
* Project        : Locomotive Maintenance                               *
* Description    : Controller for the Blank Details view when there is  *
*                  no selected locomotive in Shopped tab.               *
*&----------------------------------------------------------------------*/

// #DontDelete : Daya New controller class , Do not delete any method in this class

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/BusyIndicator"
], function(Controller, Constants, BusyIndicator) {
	"use strict";

	return Controller.extend("com.sap.cp.lm.controller.myShop.shopped.ShoppedBlankDetails", {

		/**
		 * Function is called when Controller is loaded only for the first time 
		 */
		onInit: function() {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this.getView());
			BusyIndicator.hideBusyIndicator();
		},
		
		/**
		 * Navigate back to the map view
		 */ 
		onMapPress: function(){
			this.getOwnerComponent().getGlobalModel().setProperty("/MyShopMap", true);
			this._oRouter.getTargets().display("locomotivesShoppedMap");
		},
		
		onShoppedDetailsPress: function(){
			this.getOwnerComponent().getGlobalModel().setProperty("/MyShopMap", false);
			this._oRouter.getTargets().display("locomotivesShoppedHome");
		}
	});
});