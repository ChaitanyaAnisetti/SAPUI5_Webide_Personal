/*&---------------------------------------------------------------------*    
 * Author         : SAP Custom Development                               *
 * Date           : 2017.12.21                                           *
 * Project        : Locomotive Maintenance                               *
 * Description    : Controller for Details fragment tab for a Locomotive *
 *                  view (inbound or shopped).                           *
 *&----------------------------------------------------------------------*/
/*&---------------------------------------------------------------------*    
 * Author         : Sandhya satavalekar                                  *
 * Date           : 02-Feb-2019                                          *
 * Project        : Locomotive Maintenance Phase 2                       *
 * Description    : LMP2-05: Change the Loco User Status                 *
 * Search Term    : LMP2-05
 *&----------------------------------------------------------------------*/
/*&---------------------------------------------------------------------*    
 * Author         : Sandhya satavalekar                                  *
 * Date           : 10-Feb-2019                                          *
 * Project        : Locomotive Maintenance Phase 2                       *
 * Description    : LMP2-16: Added the font and padding for the Loco     *
 *                  Characteristics                                      *
 * Search Term    : LMP2-16
 *&----------------------------------------------------------------------*/
/*&---------------------------------------------------------------------*    
 * Author         : Mike Kirk                                            *
 * Date           : 30-Apr-2019                                          *
 * Project        : Locomotive Maintenance Phase 2                       *
 * Description    : LMP2-28: Refresh inboundShop in current locomotive   *
 *&----------------------------------------------------------------------*/
/*&---------------------------------------------------------------------*    
 * Author         : Sandhya Satavalekar                                  *
 * Date           : 27-May-2019                                          *
 * Project        : Locomotive Maintenance Phase 2                       *
 * Description    : 3D POC                                               *
 *&----------------------------------------------------------------------*/
 /*&---------------------------------------------------------------------*    
 * Author         : SHE0272				                                 *
 * Date           : 24-Aug-2021                                          *
 * Project        : INC0107443 - Refresh Incident                        *
 * Description    : Replaced local model with global model as local 	 *
 *					model is failing when navigating between fleet, 	 *
 *					inbound, shopped and serving tab    				 *
 *                  Characteristics                                      *
 * Search Term    : INC0107443
 *&----------------------------------------------------------------------*/

/* #DontDelete : Yann */

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/locomotives/LocomotiveDataModel",
	// "sap/ui/vk/ContentResource",
	// "sap/ui/vk/ContentConnector",
	// "sap/ui/vk/ViewStateManager",
	"sap/ui/table/Column"
], function (Controller, Constants, Formatter, BusyIndicator, LocomotiveDataModel, Column) {
	"use strict";

	var _this;

	return Controller.extend("com.sap.cp.lm.controller.myShop.common.details.Details", {

		/**
		 * Initializes the controller
		 */
		onInit: function () {
			_this = this;
			_this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
			_this.getView().setModel(_this._oGlobalModel, "global"); // SHE0272 - INC0107443 - Model is set to the view

			var oModel = new sap.ui.model.json.JSONModel();
			_this.getView().setModel(oModel);

			var oModel1 = new sap.ui.model.json.JSONModel();
			_this.getView().setModel(oModel1, "locoDetails");

			this._sEquip = "";
			//  //Added by Sandhya : 3D POC
			// _this.getView().byId("lv1VBox").setVisible(false);
			// _this.getView().byId("lv2VBox").setVisible(false);
			// _this.getView().byId("lv3VBox").setVisible(false);
			// //End:Added by Sandhya : 3D POC
		},
		
		// SHE0272 - INC0107443 - This method will not be used. Instead data picked while clicking the link. Hence commented.
		setBlueCardURL: function (sEquipNo) {
			// var oBlueCardLink = this.getView().byId("idBlueCardLink");
			// var sEquipment = sEquipNo;
			// var oDate = new Date();
			// var sYear = oDate.getFullYear();
			// var sLink = "/sap/opu/odata/sap/ZPM_FRACARD_SRV/pdfSet(equipment='" + sEquipment + "',year='" + sYear + "')/$value";
			// oBlueCardLink.setHref(sLink);
		},
		
		// SHE0272 - INC0107443 - New method to load the PDF
		onClickFRACard: function () {
			var oDate = new Date();
			var sYear = oDate.getFullYear();
			var sLink = "/sap/opu/odata/sap/ZPM_FRACARD_SRV/pdfSet(equipment='" + this._sEquip + "',year='" + sYear + "')/$value";
			window.open(sLink);
		},

		fetchDetails: function (oLocomotive) {
			var sEquip;
			if (oLocomotive) {
				if (oLocomotive.Equipment) {
					sEquip = oLocomotive.Equipment;
				} else {
					sEquip = oLocomotive.EquipNo;
				}
			}
			_this.fetchLocomotiveDetails(sEquip);
		},

		fetchLocomotiveDetails: function (sEquip, sShopId) {

			if (!sEquip) {
				var oLocomotive = this._oGlobalModel.getProperty("/currentLocomotive");
				if (oLocomotive) {
					if (oLocomotive.Equipment) {
						sEquip = oLocomotive.Equipment;
					} else {
						sEquip = oLocomotive.EquipNo;
					}
				}
			}

			if (!sShopId) {
				sShopId = this._oGlobalModel.getProperty("/currentShop").Id;
			}

			if (sEquip && sShopId) {

				var oParam = {};
				oParam.Equipment = sEquip;
				oParam.ShopId = sShopId;

				LocomotiveDataModel.fetchLocoHeader(_this.loadLocoHeader, _this.onloadDataError, this, oParam);
				LocomotiveDataModel.fetchLocoMegaWattHours(_this.loadData, _this.onloadDataError, this, sEquip);
				//Added by Sandhya : LMP2-16 : Get the Loco Characteristics
				LocomotiveDataModel.fetchLocoChar(_this.loadLocoChar, _this.onloadDataError, this, oParam);
				//End:Added by Sandhya : LMP2-16 : Get the Loco Characteristics
				this._sEquip = sEquip;	// SHE0272 - INC0107443 - Setting the quipmnet value to a global variable. Used this later for loading the PDF
			}

		},
		//Added by Sandhya : LMP2-05: Change the user status of the Loco
		onLocoStatChange: function (oEvent) {
			var oData1 = _this.getView().getModel("global").getProperty("/locomotiveDetailsData"); // SHE0272 - INC0107443 - Local model is changed to global
			LocomotiveDataModel.saveLocoStat(oData1);
		},
		//End:Added by Sandhya : LMP2-05

		loadLocoHeader: function (oData) {
			// _this.getView().getModel().setData(oData);
			this._oGlobalModel.setProperty("/locomotiveDetailsData", oData); // SHE0272 - INC0107443 - Local model is changed to global

			// KIR0084 Updating currentLocomotive with new data
			var oLocomotive = this._oGlobalModel.getProperty("/currentLocomotive");
			if (oLocomotive) {
				this._oGlobalModel.setProperty("/currentLocomotive", oData);
			}
			// KIR0084 Updating currentLocomotive with new data

			_this.getView().getModel("global").refresh(true); // SHE0272 - INC0107443 - Local model is changed to global
			_this.setBlueCardURL(oData.Equipment);
			//Added by Sandhya: To populate the drop down for the Loco User Status: LMP2-05
			///LocoStat is populated in the main.controller
			var lcstat = _this.getView().getModel().getProperty("/LocoUserStatus");
			var oData1 = {
				LocoStat: _this._oGlobalModel.getProperty("/LocoStat")
			};
			var LocoStat = new sap.ui.model.json.JSONModel(oData1);
			_this.getView().setModel(LocoStat, "status");
			//END:Added by Sandhya : LMP2-05

		// 	//Added by Sandhya 3D
		// 	var view = this.getView();
		// 	var oViewport = view.byId("viewport");
		// 	// var sVersionPath = com.sap.cp.lm.util.Formatter.getVersionPath();
		// 	// var sVds = sVersionPath + "/mimes/loco10.vds";
		// 	var contentResource = new ContentResource({
		// 	//	 source: "/mimes/loco10.vds",
		// 	//    source: "/sap/bc/ui5_ui5/sap/zpmlocomaint/model/loco10.vds",
		// 		//  source: "/sap/bc/ui5_ui5/sap/zpmlocomaint/model/SAPKnife.vds",
		// //	  source: "model/loco10.vds",
		// 	 //  source: "/sapdata/interfaces/VDS/loco10.vds",
		// //	source: "/sap/bc/ui5_ui5/sap/zpmlocomaint/mimes/loco10.vds",
		// 	   //source: "com/sap/cp/lm/model/loco10.vds",
		// 	 // 	source: "\sap\bc\ui5_ui5\sap\zpmlocomaint\model\loco10.vds",
		// 	  //	source: "/sap/bc/ui5_ui5/sap/zpmlocomaint/model/loco10.vds",
			
		// 	 // source: "/sap/bc/ui5_ui5/sap/zpmlocomaint/model/loco10.vds",
		// 	//source: "model/loco10.vds",
		// 	source: "https://webidetesting5402244-b955c0454.dispatcher.us1.hana.ondemand.com/~1580402713000~/model/loco10.vds",
		// 	  	sourceType: "vds",
		// 		sourceId: "abc123"
		// 	});
		// 	//Constructor for a new content connector
		// 	var contentConnector = new ContentConnector("abcd");
		// 	//Manages the visibility and the selection states of nodes in the scene.
		// 	var viewStateManager = new ViewStateManager("vsmA", {
		// 		contentConnector: contentConnector
		// 	});

		// 	 //Set content connector and viewStateManager for viewport
		// 	oViewport.setContentConnector(contentConnector);
		// 	oViewport.setViewStateManager(viewStateManager);
		// 	view.addDependent(contentConnector).addDependent(viewStateManager);
		// 	//Add resource to load to content connector
		// 	contentConnector.addContentResource(contentResource);

		// 	// oViewport.setSelectionMode('none'); 
		// 	var controller = this;
		// 	controller.selectedNodeList = [];

		// 	oViewport.attachNodesPicked(function (oEvent) {
		// 		var pickedNode = oEvent.getParameter('picked');
		// 		if (pickedNode.length == 0) {
		// 			// Clear the tit color for currently selected objects
		// 			//	console.log(controller.selectedNodeList);
		// 			viewStateManager.setTintColor(controller.selectedNodeList, null, true);
		// 			// Clear the list if user clicked on empty viewport
		// 			controller.selectedNodeList = [];
		// 		} else {
		// 			// Maitain the selected node list (CUSTOM SELECTION BEHAVIOUR)
		// 			var selectedNodeIndex = controller.selectedNodeList.indexOf(pickedNode[0]);
		// 			if (selectedNodeIndex >= 0) {
		// 				controller.selectedNodeList.splice(selectedNodeIndex, 1);
		// 			} else {
		// 				controller.selectedNodeList.push(pickedNode[0]);
		// 			}

		// 			//2. with selection mode set to 'none', we will use the ViewStateManager to hide the selected nodes and highlight parent node in a different color
		// 			//viewStateManager.setVisibilityState(pickedNode, false, true); 
		// 			//	if (oViewport.getSelectionMode() == 'none') {
		// 			//	console.log(highlightColorPicker.getColorString());
		// 			//	viewStateManager.setTintColor(pickedNode, highlightColorPicker.getColorString(), true);
		// 			//	};
		// 	 	}
		// 	});

		// 	// Attach to the selection changed event of the viewstatemanager to be notified about any selection change (whether they are triggered programmatically or by direct interaction from the user)

		// 	viewStateManager.attachSelectionChanged(function (oEvent) {
		// 		var selectedNodes = oEvent.getParameter("selected");
		// 		var unselectedNodes = oEvent.getParameter("unselected");
		// 		var oData1 = _this.getView().getModel().oData;
		// 		if (selectedNodes.length != 0) {
		// 			// Get node heirarchy reference and create a node proxy for the first selected item
		// 			// In 1.50 you would get node heirarchy for the scene from a View State Manager 
		// 			var nodeHeirarchy = viewStateManager.getNodeHierarchy();
		// 			var nodeProxy = nodeHeirarchy.createNodeProxy(selectedNodes[0]);
		// 			var nodeMetadata = nodeProxy.getNodeMetadata();
		// 			var nodeIds = nodeProxy.getVeIds();
		// 			var nodeName = nodeProxy.getName();
		// 			if (nodeMetadata.loco) {
		// 				if (nodeMetadata.loco.loco_det === "det") {
		// 					_this.getView().byId("lv1VBox").setVisible(true);
		// 					_this.getView().byId("lv2VBox").setVisible(false);
		// 					_this.getView().byId("lv3VBox").setVisible(false);
		// 					// var lv1 = oData.TrainName;
		// 					// var lv2 = oData.ModelNo;
		// 					// sap.m.MessageToast.show("Train Symbol: " + lv1 + "        " + 
		// 					//                         "Model Number: " + lv2 + 
		// 					//                         "Horsepower: " + oData.HorsePower);
		// 				} else if (nodeMetadata.loco.loco_det === "char") {
		// 					_this.getView().byId("lv1VBox").setVisible(false);
		// 					_this.getView().byId("lv2VBox").setVisible(true);
		// 					_this.getView().byId("lv3VBox").setVisible(false);
		// 					// var model = _this.getView().getModel("loco3d");
		// 					//                  //model.setProperty("/lv1", true);
		// 					//                  var model = _this.getView().getModel("locoDetails");
		// 					//                  	var lv_train = model.getProperty("/TrainName");
		// 				} else if (nodeMetadata.loco.loco_det === "mw") {
		// 					_this.getView().byId("lv1VBox").setVisible(false);
		// 					_this.getView().byId("lv2VBox").setVisible(false);
		// 					_this.getView().byId("lv3VBox").setVisible(true);
		// 				}
		// 			}
		// 			// Destroy the node proxy to avoid memory leaks!
		// 			//	nodeHeirarchy.destroyNodeProxy(nodeProxy);
		// 			// sap.m.MessageToast.show("Name: " + JSON.stringify(nodeName, undefined, 4) + "\rIds: " + JSON.stringify(nodeIds, undefined, 4) +
		// 			// 	"\rMetadata: " + JSON.stringify(nodeMetadata, undefined, 4));
		// 			// oResultOutput.setValue("Name: " + JSON.stringify(nodeName, undefined, 4) + "\rIds: " + JSON.stringify(nodeIds, undefined, 4) + "\rMetadata: " + JSON.stringify(nodeMetadata, undefined, 4)); 
		// 			//nodeproxy
		// 		}
		// 	});
		// 	//End:Added by Sandhya 3D
			BusyIndicator.hideBusyIndicator();
		},

		//Added by Sandhya : LMP2-16:Loading the characteristics
		loadLocoChar: function (oData) {
			// var oPRTModel = new sap.ui.model.json.JSONModel();
			// oPRTModel.setSizeLimit(10000);
			// oPRTModel.setData(oData);
			// _this.getView().byId("table1").setModel(oPRTModel, "lChar");
			this._oGlobalModel.setProperty("/locomotiveCharacteristics", oData.results); // SHE0272 - INC0107443 - Setting the data in global model instead of local
			BusyIndicator.hideBusyIndicator();
		},
		//End:Added by Sandhya: LMP2-16:Loading the characteristics

		loadData: function (oData) {
			// _this.getView().getModel("locoDetails").setData(oData.results);
			// _this.getView().getModel("locoDetails").refresh(true);
			this._oGlobalModel.setProperty("/locomotiveDetailsMotoringData", oData.results); // SHE0272 - INC0107443 - Setting the data in global model instead of local

			BusyIndicator.hideBusyIndicator();
		},

		onPress: function (oEvent) {
			var oData1 = _this.getView().getModel().oData;
			var oData2 = this.getView().getModel().oData;
			//Added by Sandhya 3D Visual
		// 	var oData2 = { lv1: true };
		// 	var Loco3D = new sap.ui.model.json.JSONModel(oData2);
		// 	_this.getView().setModel(Loco3D, "loco3d");
		// 		_this.getView().byId("lv1VBox").setVisible(false);

		// 		var view = this.getView();
		// 		var oViewport = view.byId("viewport");
		// 		// var sceneTree = view.byId("scenetree");
		// 	//	var oResultOutput = this.getView().byId("txtNodeInfo");
		// 		// Constructor for a new content resource. procides an object that owns content resouces, tracks changes, loads and destroys
		// 		// content built from the content resource.
		// 		var contentResource = new ContentResource({
		// 			source: "model/loco10.vds",
		// 			sourceType: "vds",
		// 			sourceId: "abc123"
		// 		});
		// 		_this._oGlobalModel.setProperty("/3dlocodet", false);
		// 		_this._oGlobalModel.setProperty("/3dlocochar", false);

		// 		// Constructor for a new content connector
		// 		var contentConnector = new ContentConnector("abcd");

		// 		// Manages the visibility and the selection states of nodes in the scene.
		// 		var viewStateManager = new ViewStateManager("vsmA", {
		// 			contentConnector: contentConnector
		// 		});

		// 		// Set content connector and viewStateManager for viewport
		// 		oViewport.setContentConnector(contentConnector);
		// 		oViewport.setViewStateManager(viewStateManager);

		// 		// Set scene tree content connector and viewStateManager
		// 		// sceneTree.setContentConnector(contentConnector);
		// 		// sceneTree.setViewStateManager(viewStateManager);

		// 		view.addDependent(contentConnector).addDependent(viewStateManager);
		// 		// Add resource to load to content connector
		// 		contentConnector.addContentResource(contentResource);

		// 	****
		// 	oViewport.attachNodesPicked(function (oEvent) {
		// 		var pickedNode = oEvent.getParameter('picked');

		// 		_this.getView().byId("lv1VBox").setVisible(true);
		// 		//var selectedNodes = oEvent.getParameter("selected");
		// 		sap.m.MessageToast.show(JSON.stringify(pickedNode) + ", selectionMode: " + oViewport.getSelectionMode());

		// 		//2. with selection mode set to 'none', we will use the ViewStateManager to hide the selected nodes and highlight parent node in a different color
		// 		//3. viewStateManager.setVisibilityState(pickedNode, false, true); 
		// 		//4. ViewStateManager.prototype.setSelectionState = function(nodeRefs, selected, recursive) 
		// 		if (oViewport.getSelectionMode() == 'none') {
		// 			// ViewStateManager.prototype.setTintColor = function(nodeRefs, tintColor, recursive) 
		// 			viewStateManager.setTintColor(pickedNode, 'pink', true);
		// 		};

		// 	var model = _this.getView().getModel("loco3d");
		// 	                     model.setProperty("/lv1", false);
		// 	var selectedNodeIndex = controller.selectedNodeList.indexOf(pickedNode[0]);
		// 	if (selectedNodeIndex >= 0) {
		// 		controller.selectedNodeList.splice(selectedNodeIndex, 1);
		// 	}
		// 	var nodeHeirarchy = viewStateManager.getNodeHierarchy();
		// 	var nodeProxy = nodeHeirarchy.createNodeProxy(pickedNode[0]);
		// 	var nodeMetadata = nodeProxy.getNodeMetadata();
		// 	var nodeIds = nodeProxy.getVeIds();
		// 	var nodeName = nodeProxy.getName();

		// 	if (nodeMetadata.loco.loco_det === "det") {
		// 		_this._oGlobalModel.setProperty("/3dlocodet", true);
		// 		_this._oGlobalModel.setProperty("/3dlocochar", false);
		// 		var oData2 = {
		// 			lv1: "false"
		// 		};
		// 		var Loco3D = new sap.ui.model.json.JSONModel(oData2);
		// 		_this.getView().setModel(Loco3D, "loco3d");

		// 	} else if (nodeMetadata.loco.loco_det === "char") {
		// 		_this._oGlobalModel.setProperty("/3dlocodet", false);
		// 		_this._oGlobalModel.setProperty("/3dlocochar", true);
		// 	}

		// 	Destroy the node proxy to avoid memory leaks!
		// 		nodeHeirarchy.destroyNodeProxy(nodeProxy);
		// 	});
		// 	nodeproxy
		// 	var oResultOutput = this.getView().byId("txtNodeInfo"); 
		// 	var firstConnector = this.getView().byId("first-connector"); 
		// 	var viewStateManager = this.getView().byId("vsmA");

		// //	Attach to the selection changed event of the viewstatemanager to be notified about any selection change (whether they are triggered programmatically or by direct interaction from the user)
		// 	//new comment
		// 	viewStateManager.attachSelectionChanged(function (oEvent) {
		// 		var selectedNodes = oEvent.getParameter("selected");
		// 		var unselectedNodes = oEvent.getParameter("unselected");
		// 	            _this.getView().byId("lv1VBox").setVisible(true);
		// 		if (selectedNodes.length != 0) {
		// 			// Get node heirarchy reference and create a node proxy for the first selected item
		// 			// In 1.50 you would get node heirarchy for the scene from a View State Manager 
		// 			var nodeHeirarchy = viewStateManager.getNodeHierarchy();

		// 			// In SAPUI5 1.52+ you can get one directly from the event object, because this returns a scene 
		// 			// var oScene = firstConnector.getContent(); 
		// 			// var nodeHeirarchy = oScene.scene.getDefaultNodeHierarchy();

		// 			var nodeProxy = nodeHeirarchy.createNodeProxy(selectedNodes[0]);
		// 			var nodeMetadata = nodeProxy.getNodeMetadata();
		// 			var nodeIds = nodeProxy.getVeIds();
		// 			var nodeName = nodeProxy.getName();

		// 	                    //var model = _this.getView().getModel("loco3d");
		// 	                    // model.setProperty("/lv1", false);
		// 			if (nodeMetadata.loco.loco_det === "det") {
		// 				_this._oGlobalModel.setProperty("/3dlocodet", true);
		// 				_this._oGlobalModel.setProperty("/3dlocochar", false);
		// 				//  oData2 = {	lv1: true };
		// 				//  Loco3D = new sap.ui.model.json.JSONModel(oData2);
		// 				// _this.getView().setModel(Loco3D, "loco3d");
		// 				var model = _this.getView().getModel("loco3d");
		// 	                     //model.setProperty("/lv1", true);

		// 	                     	var model = _this.getView().getModel("locoDetails");
		// 	                     	var lv_train = model.getProperty("/TrainName");
		// 	                     //model.setProperty("/lv1", true);
		// 	                     //var lv2 = _this.getView().getModel("loco3d");
		// 	                     //var lv3 = lv2.
		// 	                     //sap.m.MessageToast.show("Train Symbol: " + oViewport.getSelectionMode());
		// 			} else if (nodeMetadata.loco.loco_det === "char") {
		// 				_this._oGlobalModel.setProperty("/3dlocodet", false);
		// 				_this._oGlobalModel.setProperty("/3dlocochar", true);
		// 					var model = _this.getView().getModel("loco3d");
		// 	                     //model.setProperty("/lv1", true);
		// 	                     var model = _this.getView().getModel("locoDetails");
		// 	                     	var lv_train = model.getProperty("/TrainName");
		// 			}

		// 			// Destroy the node proxy to avoid memory leaks!
		// 			nodeHeirarchy.destroyNodeProxy(nodeProxy);
		// 			// sap.m.MessageToast.show("Name: " + JSON.stringify(nodeName, undefined, 4) + "\rIds: " + JSON.stringify(nodeIds, undefined, 4) +
		// 			// 	"\rMetadata: " + JSON.stringify(nodeMetadata, undefined, 4));
		// 			// oResultOutput.setValue("Name: " + JSON.stringify(nodeName, undefined, 4) + "\rIds: " + JSON.stringify(nodeIds, undefined, 4) + "\rMetadata: " + JSON.stringify(nodeMetadata, undefined, 4)); 

		// 			//nodeproxy
		// 		}
		// 	});
		// 	//end:new comment

		// 	Attach to the selection changed event of the viewstatemanager to be notified about any selection change (whether they are triggered programmatically or by direct interaction from the user)
		// 	viewStateManager.attachSelectionChanged(function(oEvent) {
		// 	  var selectedNodes = oEvent.getParameter("selected"); 
		// 	  var unselectedNodes = oEvent.getParameter("unselected"); 

		// 	  sap.m.MessageToast.show("selected: " + selectedNodes.join(',') + ", unselected: " + unselectedNodes.join(',') );

		// 	});
		// 	****
		// 	//End:Added by Sandhya
		
		},
	});
});