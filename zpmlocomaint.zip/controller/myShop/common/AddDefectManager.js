/*&---------------------------------------------------------------------*    
 * Author         : SAP Custom Development                               *
 * Date           : 2017.12.06                                           *
 * Project        : Locomotive Maintenance                               *
 * Description    : This controller is associated to Add Defect and      *
 *                  Add Work Order dialogs.                              *
 *&----------------------------------------------------------------------*/
/*&----------------------------------------------------------------------*    
 * Author         : BAJ0018                                              *
 * Date           : 2019.03.04                                           *
 * Incidinet      : EAM-ASR3413183 - PM Loco Main phase 2                *
 * Description    : Logic revised for ISOL status for dynamic brakes     *
 *                  monitoring code   
 *&----------------------------------------------------------------------*/
 /*&--------------------------------------------------------------------------*    
* Author/Changed By   : VYA0004			                                     *
* Date                : 31-July-2019                                         *
* Project             : Locomotive Hierarchy Project                         *
* Description         : LMP2-HIE-002 : Update TaskList logic                        *
* Search Term         : VYA0004 LMP2-HIE-002                                        *
*&---------------------------------------------------------------------------*/
/*&-----------------------------------------------------------------------*   
 * Author/Changed By   : SHE0272											*
 * Date                : 09 - Sep -2021										*
 * Project             : INC0110701 - Incident Fix							*
 * Description         : Incident Fix										*
 * Search Term         : INC0110701											*
 *&-------------------------------------------------------------------------*/
jQuery.sap.declare("com.sap.cp.lm.controller.common.AddDefectManager");

sap.ui.define([
		"com/sap/cp/lm/util/Constants",
		"com/sap/cp/lm/util/BusyIndicator",
		"com/sap/cp/lm/util/Formatter",
		"com/sap/cp/lm/util/ErrorManager",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/Filter",
	    "sap/ui/model/FilterOperator",
		"com/sap/cp/lm/model/locomotives/LocomotiveDataModel"
	],
	function (Constants, BusyIndicator, Formatter, ErrorManager, JSONModel, Filter, FilterOperator, LocomotiveDataModel) {
		"use strict";
		var _this;

		return com.sap.cp.lm.controller.common.AddDefectManager = {

			//----------------------------------------------------------------------
			// Initialize controller and dialog
			//----------------------------------------------------------------------

			init: function (oContext, fReloadOwnerView) {
				_this = this;
				_this.oModel = new sap.ui.model.json.JSONModel();

				_this._oGlobalModel = oContext.getOwnerComponent().getGlobalModel();
				_this._oI18nModel = oContext.getOwnerComponent().getModel("i18n");

				_this._oContext = oContext;
				_this._fReloadOwnerView = fReloadOwnerView;

				return _this;
			},

			// #DontDelete : Q
			/*
			 * Add defect dialog open
			 */
			onAddAffectDialogOpen: function (sScenario) {
				BusyIndicator.showBusyIndicator();

				_this._sScenario = sScenario;

				if (!_this._oAddDefectDialog) {
					_this._oAddDefectDialog = sap.ui.xmlfragment(
						"com.sap.cp.lm.view.myShop.common.AddDefect",
						_this
					);
				}

				_this._oCurrentLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
				//Commented below line for VYA0004 LMP2-HIE-002
				// LocomotiveDataModel.fetchTaskLists(_this._oCurrentLocomotive, _this.initDialog, null, _this);
               	_this.initDialog();//VYA0004 LMP2-HIE-002

				_this._oContext.getView().addDependent(_this._oAddDefectDialog);
			},

			// #DontDelete : Q
			/*
			 * Populate form data and display dialog when fecthing task lists request to backend succeed
			 */
			initDialog: function (oData) {
				if (_this._oAddDefectDialog) {
					sap.ui.getCore().byId("selectDefectType").setSelectedKey("");
					sap.ui.getCore().byId("selectDefectTypeCode").setSelectedKey("");
					sap.ui.getCore().byId("selectDefectMonitoringCode").setSelectedKey("");
					// Added By Vikram
					// sap.ui.getCore().byId('selectStatus').setEnabled(true);
					// Added By Vikram
					sap.ui.getCore().byId("selectStatus").setSelectedKey("");
					sap.ui.getCore().byId("selectTasklist").setValue("");
					sap.ui.getCore().byId("selectOrderType").setSelectedKey("");

					var title = _this._oI18nModel.getProperty("ADD_DEFECT");
					if (_this._sScenario === "WORK_ORDER") {
						title = _this._oI18nModel.getProperty("ADD_WORK_ORDER");
					}

					var aDefectTypes = _this._oGlobalModel.getProperty("/DefectTypes");
					var aDefectTypeCodes = _this._oGlobalModel.getProperty("/DefectTypeCodes");
					var aDefectMonitorCodes = _this._oGlobalModel.getProperty("/DefectMonitorCodes");
					var aDefectStatus = _this._oGlobalModel.getProperty("/DefectStatus");
					var aDefectOrderType = _this._oGlobalModel.getProperty("/DefectToOrderTypes");
					// var aTaskLists = oData.results; //Commented Swarim Mod

					var oModel = new sap.ui.model.json.JSONModel({
						Scenario: _this._sScenario,
						Title: title
					});
					oModel.setProperty("/DefectTypes", aDefectTypes);
					oModel.setProperty("/DefectTypeCodes", aDefectTypeCodes);
					oModel.setProperty("/DefectMonitorCodes", aDefectMonitorCodes);
					oModel.setProperty("/DefectStatus", aDefectStatus);
					oModel.setProperty("/DefectToOrderTypes", aDefectOrderType);
					// oModel.setProperty("/TaskLists", aTaskLists); //Commented Swarim Mod
					oModel.setProperty("/currentRole", _this._oGlobalModel.getProperty("/currentUser").CurrentRole);

					_this._setDefaultSelectedKey(aDefectTypes, "selectDefectType");
					if (_this._oGlobalModel.getProperty("/role") === 'CRAFT') {
						_this._setDefaultSelectedKey(aDefectTypeCodes, "selectDefectTypeCode"); // Start - SHE0272 - INC0110701 - Commented default set
					}
					_this._setDefaultSelectedKey(aDefectStatus, "selectStatus", true);
					//START - BAJ0018 
					oModel.setSizeLimit(1500);
					//END - BAJ0018 
					_this._oAddDefectDialog.setModel(oModel);
					_this._oAddDefectDialog.getModel().refresh();
					_this._oAddDefectDialog.getModel().updateBindings(true);

					sap.ui.getCore().byId("selectTasklist").setFilterFunction(function (sTerm, oItem) {
						// A case-insensitive 'string contains' style filter
						return oItem.getText().match(new RegExp(sTerm, "i"));
					});
				}

				_this._oAddDefectDialog.open();

				// Update form for Defect Type selected as default
				var sDefectTypeKey = sap.ui.getCore().byId('selectDefectType').getSelectedKey();
				if (sDefectTypeKey && sDefectTypeKey.length !== 0) {
					_this._updateFormForDefectType(sDefectTypeKey);
				}

				BusyIndicator.hideBusyIndicator();
			},

			//----------------------------------------------------------------------
			// Private functions
			//----------------------------------------------------------------------

			/**
			 * Select default key depending on parameters
			 */
			_setDefaultSelectedKey: function (aSelectData, sSelectId, bUseValue) {
				var i = 0;
				var bFound = false;
				while (!bFound && i < aSelectData.length) {
					var oCurrentData = aSelectData[i];
					if (aSelectData[i].getBindingContext) {
						oCurrentData = aSelectData[i].getBindingContext().getObject();
					}
					if (oCurrentData.DefaultSelection === true) {
						bFound = true;
						var key = oCurrentData.Key;
						if (bUseValue && bUseValue === true) {
							key = oCurrentData.Value;
						}
						sap.ui.getCore().byId(sSelectId).setSelectedKey(key);
					}
					i++;
				}
			},

			// #DontDelete : Q
			/*
			 * Validate all form fields
			 */
			_onValidateForm: function () {
				var isValid = true;
				var oPayload = {};
				var oReturn = {};
				var errorMessage = "";

				var sEquipNo = _this._oCurrentLocomotive.Equipment;
				if (!sEquipNo) {
					sEquipNo = _this._oCurrentLocomotive.EquipNo;
				}
				oPayload.EquipNo = sEquipNo;
				oPayload.DefectType = sap.ui.getCore().byId('selectDefectType').getSelectedKey();
				oPayload.DefectDescr = sap.ui.getCore().byId('inputDescription').getValue();
				oPayload.DefectCodeType = sap.ui.getCore().byId('selectDefectTypeCode').getSelectedKey();
				oPayload.DefectMonitorCode = sap.ui.getCore().byId('selectDefectMonitoringCode').getSelectedKey();
				oPayload.DefectUserStatus = sap.ui.getCore().byId('selectStatus').getSelectedKey();

				var oTaskListsSeletedItemId = sap.ui.getCore().byId('selectTasklist').getSelectedItem();
				var oTaskListsSuggestionsItems = sap.ui.getCore().byId('selectTasklist').getSuggestionItems();
				var oTaskListsSelectedItem = oTaskListsSuggestionsItems.filter(function (oTaskListsItem) {
					return oTaskListsItem.sId === oTaskListsSeletedItemId;
				});
				oTaskListsSelectedItem = oTaskListsSelectedItem[0];

				if (oTaskListsSelectedItem) {
					var oTaskListsContext = oTaskListsSelectedItem.getBindingContext();
					var oTaskListsObj = oTaskListsContext.getObject();

					oPayload.TasklistType = oTaskListsObj.TasklistType;
					oPayload.TasklistGroupKey = oTaskListsObj.TasklistGroupKey;
					oPayload.TasklistCounter = oTaskListsObj.TasklistCounter;
				} else {
					isValid = false;
					errorMessage = "Selected Tasklist is invalid \n";
					// ErrorManager.handleError("", "Selected Tasklist is invalid");
				}

				if (this._sScenario === "WORK_ORDER") {
					oPayload.OrderType = sap.ui.getCore().byId('selectOrderType').getSelectedKey();
				}
				
				// Start - SHE0272 - INC0110701 - Validate for notification type code
				if (!sap.ui.getCore().byId('selectDefectTypeCode').getSelectedKey()) {
					isValid = false;
					errorMessage = errorMessage + "Select a Notification Type Code";
				}
				// End - SHE0272 - INC0110701 - Validate for notification type code

				if (isValid) {

					$.each(oPayload, function (index, value) {
						if (isValid) {
							if (!value || value.length === 0) {
								isValid = false;
								console.log(index + " " + value);
								ErrorManager.handleError("", "Please fill in all fields");
							}
						}
					});

				} else {
					ErrorManager.handleError("", errorMessage);
				}

				oReturn.isValid = isValid;
				oReturn.oPayload = oPayload;

				return oReturn;
			},

			// #DontDelete : Q
			/*
			 * Create defect/workorder on submit
			 */
			_submitData: function (oPayload) {
				LocomotiveDataModel.createDefectSet(oPayload, _this._endSubmitOnSuccess, null, _this);
			},

			// #DontDelete : Q
			/*
			 * Update select values depending on selected Defect Type
			 */
			_updateFormForDefectType: function (sDefectTypeKey) {
				var oSelect = sap.ui.getCore().byId("selectStatus");

				var oNewItem = new sap.ui.core.Item({
					key: "{Value}",
					text: "{Text}"
				});

				var oFilter = new sap.ui.model.Filter("Key", "EQ", sDefectTypeKey);

				oSelect.bindAggregation("items", {
					path: "/DefectStatus",
					template: oNewItem,
					filters: oFilter
				});

				oSelect = sap.ui.getCore().byId("selectOrderType");

				oSelect.bindAggregation("items", {
					path: "/DefectToOrderTypes",
					template: oNewItem,
					filters: oFilter
				});
			},

			// #DontDelete : Q
			/*
			 * Close dialog and launch refresh of context view
			 */
			_endSubmitOnSuccess: function (oData) {
				_this._oAddDefectDialog.close();

				if (_this._fReloadOwnerView && _this._oContext) {
					_this._fReloadOwnerView.apply(_this._oContext, null);
				}
			},

			//----------------------------------------------------------------------
			// Event handlers
			//----------------------------------------------------------------------

			// #DontDelete : Q
			/*
			 * Close dialog
			 */
			onAddDefectDialogCancel: function (oEvent) {
				_this._oContext.bAddWorkOrder = false;
				_this._oAddDefectDialog.close();
			},

			// #DontDelete : Q
			/*
			 * Validate form submitted data before calling appropriated service
			 */
			onAddDefectDialogConfirm: function (oEvent) {
				var oFormData = _this._onValidateForm();

				if (oFormData.isValid) {
					_this._submitData(oFormData.oPayload);
				}
			},

			// #DontDelete : Q
			/*
			 * Update form when a defect type has been selected
			 */
			onChangeSelectDefectType: function (oEvent) {
					var sDefectTypeKey = oEvent.getSource().getSelectedKey();

					if (sDefectTypeKey && sDefectTypeKey.length !== 0) {
						sap.ui.getCore().byId("selectOrderType").setSelectedKey(null);
						_this._updateFormForDefectType(sDefectTypeKey);
					}
				},
				// Start Added by VYA0004 LMP2-HIE-002
				onChangeSelectDefectMonitoringCode: function (oEvent) {
					var sDefectMonitoringCodeKey = oEvent.getSource().getSelectedKey();
					if (sDefectMonitoringCodeKey && sDefectMonitoringCodeKey.length !== 0) {
					//Equipment No.	
					_this._oCurrentLocomotive = _this._oGlobalModel.getProperty("/currentLocomotive");
					//Call FetchTaskLists method to get TaskLists corresponding to Model No. and Monitoring Code.
					// LocomotiveDataModel.fetchTaskLists(_this._oCurrentLocomotive, _this.setTaskLists, null, _this);
				    LocomotiveDataModel.fetchTaskListsNew(_this._oCurrentLocomotive, sDefectMonitoringCodeKey, _this.setTaskLists, null, _this);
					}
				},
				//This method will be called from LocomotiveDataModel.fetchTaskLists
				setTaskLists: function (oData){
					//Records retrieved from method GetLocoTasklists
					var aTaskLists = oData.results;
					//Reset selected Tasklist
					sap.ui.getCore().byId("selectTasklist").setSelectedKey("");
					//Update Tasklist results
                    _this._oAddDefectDialog.getModel().setProperty("/TaskLists", aTaskLists);
				}
				//End Added by VYA0004 LMP2-HIE-002
				//,
				// Added By Vikram
				// onChangeDefectMonitoringCode: function (oEvent) {
				// 		// set default status to ISOL for dynamic brake system monitoring code
				// 		if (sap.ui.getCore().byId('selectDefectMonitoringCode').getSelectedKey() === "830") {
				// 			sap.ui.getCore().byId('selectStatus').setSelectedKey("E0003");
				// 			sap.ui.getCore().byId('selectStatus').setEnabled(false);
				// 		} else {
				// 			sap.ui.getCore().byId('selectStatus').setEnabled(true);
				// 		}
				// 	}
				// Added By Vikram
		};
	});