/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.06                                           *
* Project        : Locomotive Maintenance                               *
* Description    : This controller is used for My Links dialog. This    *
*                  dialog can be open from navigation.                  *
*&----------------------------------------------------------------------*/

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/cp/lm/util/ErrorManager",
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/Formatter",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/model/main/PersonalLinkModel",
	"sap/ui/model/json/JSONModel"
], function(Controller, ErrorManager, Constants, Formatter, BusyIndicator,
		PersonalLinkModel, JSONModel) {
	"use strict";

	return Controller.extend("com.sap.cp.lm.controller.main.PersonalLink", {
		
		//--------------------------------------------------------------------
		// Life cycle functions
		//--------------------------------------------------------------------
		
		/**
		 * Called when a controller is instantiated
		 */
		onInit: function() {
			//References
			this._oLinkTable = this.byId("sapPersonaLinkListTable");
			
			//Default values
			this._oLinkTable.setBusyIndicatorDelay(0);
			
			//Models
			this._oDataModel = this.getOwnerComponent().getModel(Constants.ZPMLM_MODEL);
			this._oGlobalModel = this.getOwnerComponent().getGlobalModel();
			
			//I18n model
			this._oI18nModel = this.getOwnerComponent().getModel("i18n");

			//Initialize the main model
			PersonalLinkModel.init(this.getOwnerComponent());

			//Avoid premature requests
			this.getView().setModel(new JSONModel());
			this._oLinkTable.setModel(new JSONModel());

			//the view properties model
			this._oViewPropertiesModel = new JSONModel();
			this._initViewPropertiesModel();
			this.getView().setModel(this._oViewPropertiesModel, "viewProperties");
		},
		
		//--------------------------------------------------------------------
		// Controller methods that are used from other view controllers
		//--------------------------------------------------------------------
		
		openPopover: function(oControl){
			this._oPersonalLinkPopover = this.byId("personalLinkPopover");
			
			//Load the dialog data
			this._bindLinkTable();

			//Reinitialize the view properties whenever this dialog is open
			this._initViewPropertiesModel();
						
			this._oPersonalLinkPopover.openBy(oControl);
		},
		
		//--------------------------------------------------------------------
		// Private functions
		//--------------------------------------------------------------------
		
		/**
		 * Bind the link table to the odata model, garantees that the service will be called
		 * and the the notifications table will display the information returned from the service.
		 * Garantees that the _updateDropdownModel will be called when the data is loaded which will
		 * create the filters dropdown
		 */
		_bindLinkTable: function() {
			
			this._oLinkTable.setModel(this._oDataModel);
			var oItemsBindingInfo = this._oLinkTable.getBindingInfo("items");
			
			this._oLinkTable.unbindItems();
			
			//Bind the items
			this._oLinkTable.bindItems(oItemsBindingInfo);

			//Attach a handler for when the data is refreshed
			//this._oLinkTable.getBinding("items").attachDataReceived(this._afterDataReceived, this);
		},
		
		/**
		 * Create the view properties model for this view. 
		 */
		_initViewPropertiesModel: function() {
			this._oViewPropertiesModel.setProperty("/Guid","");
			this._oViewPropertiesModel.setProperty("/Description","");
			this._oViewPropertiesModel.setProperty("/Url","");
		},
		
		//--------------------------------------------------------------------
		// Event handlers
		//--------------------------------------------------------------------
		
		/**
		 * Cancel pressed on the Create/Update dialog
		 */
		onLinkCancel: function(){
			this._createLinkPopover.close();
		},
		
		/**
		 * Update link success
		 */
		onLinkModifySuccess: function(){
			this._createLinkPopover.close();
		},
		
		/**
		 * Delete link success
		 */
		onLinkDeleteSuccess: function(){
			this._bindLinkTable();
		},
		
		/**
		 * Method called to perform the DELETE request
		 */
		onLinkDelete: function(oEvent){
			var oModel = this._oLinkTable.getModel();
			var path = oEvent.getSource().getBindingContext().getPath();
			var oLink = oModel.getProperty(path);
			PersonalLinkModel.deleteLink(oLink.Guid, this.onLinkDeleteSuccess.bind(this));		
		},
		
		/**
		 * Method called to perform the POST/PUT request
		 */
		onLinkSave: function(){
			var sLinkGUID = this._oViewPropertiesModel.getProperty("/Guid");
			var sLinkDescription = this._oViewPropertiesModel.getProperty("/Description");
			var sLinkURL = this._oViewPropertiesModel.getProperty("/Url");
			
			// URL Whitelisting 
			
			jQuery.sap.addUrlWhitelist("http",undefined,undefined,undefined);
			jQuery.sap.addUrlWhitelist("https",undefined,undefined,undefined);
			
			// validte the URL
			if (jQuery.sap.validateUrl(sLinkURL)){
				//Payload that will be sent to the oData service
				var oPayload = {
						Guid: sLinkGUID,
						Description: sLinkDescription,
						Url: sLinkURL
				};
				if (sLinkGUID === ""){
					PersonalLinkModel.createLink(oPayload, this.onLinkModifySuccess.bind(this));
				}else{
					PersonalLinkModel.updateLink(oPayload, this.onLinkModifySuccess.bind(this));
				}
			}else{
				var sMessage = this._oI18nModel.getProperty("PERSONAL_LINK_URL_WHITELIST_ERROR");
				ErrorManager.showErrorMessage(sMessage);
			}
			
			jQuery.sap.clearUrlWhitelist(); 

		},
		
		/**
		 * Open the Create/Update Link Dialog
		 */
		onLinkCreate: function(){
			if (!this._createLinkPopover) {
				this._createLinkPopover = sap.ui.xmlfragment("idCreateLinkDialog", "com.sap.cp.lm.view.main.CreatePersonalLinkDialog",this);
				this.getView().addDependent(this._createLinkPopover);
			}
			this._oViewPropertiesModel.setProperty("/Guid","");
			
			var sTitle = this._oI18nModel.getProperty("CREATE_LINK");
			this._oViewPropertiesModel.setProperty("/Title",sTitle);

			this._createLinkPopover.open();
		},
		
		/**
		 * Edit Link pressed
		 */
		onLinkEdit: function(oEvent){
			if (!this._createLinkPopover) {
				this._createLinkPopover = sap.ui.xmlfragment("idCreateLinkDialog", "com.sap.cp.lm.view.main.CreatePersonalLinkDialog",this);
				this.getView().addDependent(this._createLinkPopover);
			}
			var oModel = this._oLinkTable.getModel();
			var path = oEvent.getSource().getBindingContext().getPath();
			var oLink = oModel.getProperty(path);
			this._oViewPropertiesModel.setProperty("/Guid",oLink.Guid);
			this._oViewPropertiesModel.setProperty("/Description",oLink.Description);
			this._oViewPropertiesModel.setProperty("/Url",oLink.Url);
			var sTitle = this._oI18nModel.getProperty("UPDATE_LINK");
			this._oViewPropertiesModel.setProperty("/Title",sTitle);
			this._createLinkPopover.open();
		},
		
		/**
		 * Close the popover
		 */
		onLinkClose: function(){
			this._oPersonalLinkPopover.close();
		}
	});
});