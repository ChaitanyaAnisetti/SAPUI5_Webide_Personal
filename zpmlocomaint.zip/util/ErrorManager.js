/**
 * Author         : KIR0084                                              *
 * Date           : 2019.04.01                                           *
 * Incidinet      : BUG errors not being displayed and incorrect error going to console   	     *
 * Search Term    : BUG KIR0084                                          *
*/
/**
 * Author         : KIR0084                                              *
 * Date           : 2019.10.01                                           *
 * Incidinet      : LMP2-35 Allow error messages to have details 	     *
 * Search Term    : KIR0084                                          *
*/

jQuery.sap.declare("com.sap.cp.lm.util.ErrorManager");

sap.ui.define(
	['sap/m/MessageBox'],
	function (MessageBox) {
		"use strict";
		return com.sap.cp.lm.util.ErrorManager = {

		handleError : function(oError,SCustomError,sCustomDetails, type) {
			var sMessage ="";
			if(SCustomError){
			 sMessage = SCustomError;
			}
			else{
			 sMessage = this._extractMessage(oError);
				}
			
			/* KIR0084 Handle Details */
			var oErrorOpts;
			if (type === "Warning") {
    			oErrorOpts = {
        				icon : MessageBox.Icon.WARNING,
        				title : "Warning",
        				styleClass: "errorMessage",
        				actions : [ MessageBox.Action.OK ]
        			};
			}
			else {
    			oErrorOpts = {
        				icon : MessageBox.Icon.ERROR,
        				title : "Error",
        				styleClass: "errorMessage",
        				actions : [ MessageBox.Action.OK ]
        			};
			}
    			
    	    if (sCustomDetails) {
    	        oErrorOpts.details = sCustomDetails;
    	    }
			/* KIR0084 Handle Details */
			
			/* START BUG KIR0084 Only show error dialog if message text exists */
			if (sMessage) {
    			MessageBox.show(sMessage, oErrorOpts);
			}
			/* END BUG KIR0084 Only show error dialog if message text exists */
		},

		_extractMessage: function (oError) {

			var sMessage = "";

			// If oError has no properties responseText, set a default one
			if (!oError.responseText)
				oError.responseText = "";

			if (oError.statusCode == 500 && oError.statusText) {
				return oError.statusText;
			}

			//added if else (if(oError.responseText != "") condition as function was not working when responseText was null or Empty
			if (oError.responseText != "") {
				/* START BUG KIR0084 Only show error dialog if message text exists */
				try {
					/* END BUG KIR0084 Only show error dialog if message text exists */
					var oResponse = JSON.parse(oError.responseText);
					if (oResponse) {

						if (oResponse.error && oResponse.error.innererror && oResponse.error.innererror.errordetails) {
							var aErrorDetails = oResponse.error.innererror.errordetails;
							$.each(aErrorDetails, function (index, error) {
								if (error.code === "ZCX_ZPMLM_EXCEPTION") {
									sMessage = error.message;
								}
								// Start LMP2-UAT-177
								if (error.severity === "warning") {
									if (error.message) {
										 sMessage = error.message + ", " + sMessage; 
										}
								}
								if (error.severity === "error") {
									if (error.message) {
										 sMessage = error.message + ", " + sMessage; 
										}
								}
								// End LMP2-UAT-177
							});

						}

						if (sMessage.length === 0) {
							sMessage = oResponse.error.message.value;
						}
					}
					/* START BUG KIR0084 Only show error dialog if message text exists */
				} catch (e) {
					console.error(oError);
					sMessage = "";
				}
				/* END BUG KIR0084 Only show error dialog if message text exists */
			} else {
				sMessage = oError.message;
			}
			return sMessage;
		},

		showErrorMessage: function (sMessage, fClose) {

	//		console.log(sMessage); //Commented as a part of the Veracode scan recommendation

			/*
			MessageBox.show(sMessage, {
				icon : MessageBox.Icon.ERROR,
				title : "Error",
				actions : [ MessageBox.Action.OK ],
				onClose : fClose ? fClose : null,
				styleClass: "errorMessage",
			});
			*/
		}};
	});