(function() {
	"use strict";
	/**
	 * 
	 */
	$.sap.declare("com.sap.cp.lm.util.BusyIndicator");

	com.sap.cp.lm.util.BusyIndicator = {
			
			// KIR0084 Busy indicator starting undefined
			_iBusyCounter: 0,
			
			/**
			 * Reset the busy indicator count
			 */
			resetBusyIndicator: function() {
				this._iBusyCounter = 0;
			},
			
			/**
			 * Shows the busy indicator.
			 */
			showBusyIndicator: function() {
				// increment the busy counter
				this._iBusyCounter++;
				
				// show the busy indicator	
				if (this._iBusyCounter == 1) {
					sap.ui.core.BusyIndicator.show(0);
				}
			},
			
			/**
			 * Hides the busy indicator.
			 */
			hideBusyIndicator: function() {
				var self = this;
				// hide the busy indicator (hide it after a timeout
				// to give enough time for the next operation to increase the busy counter
				// before the busy indicator disappears, if needed)
				window.setTimeout(function() {
					self._iBusyCounter--;
					if (self._iBusyCounter <= 0) {
						self._iBusyCounter = 0;
						sap.ui.core.BusyIndicator.hide();									
					}
				}, 20);
			}
	};
})();