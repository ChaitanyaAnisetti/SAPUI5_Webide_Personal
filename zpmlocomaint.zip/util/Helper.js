/*&---------------------------------------------------------------------*    
* Author         : SAP Custom Development                               *
* Date           : 2017.12.06                                           *
* Project        : Locomotive Maintenance                               *
* Description    : This file contains helpfull methos that are being    *
*                  called at multiple places in project.                *
*&----------------------------------------------------------------------*/


jQuery.sap.declare("com.sap.cp.lm.util.Helper");
sap.ui.define(
	["com/sap/cp/lm/util/Formatter", "com/sap/cp/lm/util/Constants"],
	function(Helper, Constants) {
		"use strict";
		return com.sap.cp.lm.util.Helper = {
			
			/**
			 * add Days to date
			 */
			addDays: function(date, days) {
			  var result = new Date(date);
			  result.setDate(result.getDate() + days);
			  return result;
			},
			
			/**
			 * remove Days to date
			 */
			removeDays: function(date, days) {
			  var result = new Date(date);
			  result.setDate(result.getDate() - days);
			  return result;
			},
			
			/**
			 * Open long text dialog on button click
			 */
			openLongTextDialog: function(oDataObject){
				if(oDataObject) {
					var oDialog = new sap.m.Dialog({
						title: oDataObject.Descr
					});
					
					var links = oDataObject.Links;
					/*
					The Links attribute should be formatted the same way as the variable commented below.
					
					var links = [
						{
							LinkText: "Open an external link 1",
							LinkHref: "https://www.google.ca"
						},
						{
							LinkText: "Open an external link 2",
							LinkHref: "https://www.google.ca"
						},
						{
							LinkText: "Open an external link 3",
							LinkHref: "https://www.google.ca"
						},
						{
							LinkText: "Open an external link 4",
							LinkHref: "https://www.google.ca"
						}
					];*/
					
					if(oDataObject.LongText && oDataObject.LongText.length > 0) {
						var longTextContent = new sap.m.HBox({
							width: "100%",
							items: [
								new sap.m.Text({
									text: oDataObject.LongText
								})
							]
						});
						
						if(links && links.length > 0) {
							longTextContent.addStyleClass("lmMarginBottom30");
						}
					}
					
					oDialog.addContent(longTextContent);
					
					if(links && links.length > 0) {
						$.each(links, function (linkKey, linkItem) {
							oDialog.addContent(
								new sap.m.HBox({
									width: "100%",
									items: [
										new sap.m.Link({
											text:linkItem.LinkText,
											target: "_blank",
											href: linkItem.LinkHref
										})
									]
								})
							);
						});
					}
					
					oDialog.addButton(new sap.m.Button({text: "Ok", press:function(){oDialog.close(); }}));
					
					oDialog.setContentHeight("500px");
					
					oDialog.open();
				}
			}

		};
	});