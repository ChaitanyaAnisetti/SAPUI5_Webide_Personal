/* #DontDelete : Yann */
sap.ui.define([
	"com/sap/cp/lm/util/Constants",
	"com/sap/cp/lm/util/BusyIndicator",
	"com/sap/cp/lm/util/ErrorManager"
], function(Constants, BusyIndicator, ErrorManager) {
	"use strict";

	jQuery.sap.declare("com.sap.cp.lm.model.alert.AlertDataModel");
	
	var _this;
	
	return com.sap.cp.lm.model.locomotives.AlertDataModel = {
		
		/* #DontDelete : Yann */
		/**
		 * Initializes this manager
		 */
		init: function(oMainModel) {
			_this = this;
			_this._oModel = oMainModel;
			_this._oModel.useBatch = true;
			
			_this.groupId = "UpdateAlertsBatchGroupId";
			
			var aDeferedGroup = this._oModel.getDeferredGroups();
			
			// Add our batch group to the list if it does not exist yet
			if (aDeferedGroup.indexOf(_this.groupId) === -1) {
				aDeferedGroup.push(_this.groupId);
			}
			
			_this._oModel.setDeferredGroups(aDeferedGroup);
		},
		
		/* #DontDelete : Yann */
		/**
		 * Read the alerts for a defined user ID
		 * @userId {object} the user which alerts will be read
		 * @successCallback {Function} successCallback is a callback when the operation is successful  
		 */
		readAlertsForUser: function(userId, successCallback) {
			//BusyIndicator.showBusyIndicator();		
			this._oModel.read("/AlertSet", {
				success: function(oData) {
					BusyIndicator.hideBusyIndicator();
					var unread = 0;
					if (oData.results && oData.results.length > 0) {
						for (var i = 0; oData.results.length > i; i++) {
							if (oData.results[i].ReadFlag === false) {
								unread++;
							}
						}
					}
					oData.unread = unread;
					
					successCallback(oData);
				},
				error: function(oError) {
					BusyIndicator.hideBusyIndicator();
					ErrorManager.handleError(oError);
				}
			});
		},


		/**
		 * Create the request alert message 
		 * @params(string) oPayload is the message payload from the user to the receiver
		 * @params(string) sSenderNumber is the sender personnel number
		 * @params(string) sReceiverNumber is the receiver personnel number
		 */
		
		createMaterialRequestAlertMessage: function(oPayload, sSenderNumber, sReceiverNumber) {

			var jsonPayload = {};
			jsonPayload.Sender = sSenderNumber;
			jsonPayload.Receiver = sReceiverNumber;
			
			var sLocomotiveId	= this._oI18nModel.getProperty("LOCOMOTIVE_NUMBER");
			var sWODescription	= this._oI18nModel.getProperty("WO_DESCRIPTION");
			var sOpNumber		= this._oI18nModel.getProperty("OPERATION_NUMBER");
			var sMatNumber		= this._oI18nModel.getProperty("MATERIAL_NUMBER");
			var sQty			= this._oI18nModel.getProperty("MISSING_QTY");
			
			var sMessage = "";
			sMessage += sLocomotiveId +":"+oPayload["LOCOMOTIVE_NUMBER"]+"\n";
			sMessage += sWODescription +":"+oPayload["WO_DESCRIPTION"]+"\n";
			sMessage += sOpNumber +":"+oPayload["OPERATION_NUMBER"]+"\n";
			sMessage += sMatNumber +":"+oPayload["MATERIAL_NUMBER"]+"\n";
			sMessage += sQty +":"+oPayload["MISSING_QTY"]+"\n";

			jsonPayload.Text = sMessage;
			return jsonPayload;

		},
		
		/* #DontDelete : Yann */
		/**
		 * Create the general alert message from one person to another
		 * @params(string) sMessage is the message from the user to the receiver
		 * @params(string) sSenderNumber is the sender personnel number
		 * @params(string) sReceiverNumber is the receiver personnel number
		 */
		createPersonalAlertMessage: function(sMessage, sSenderNumber, sReceiverNumber, sAlertType) {
			var jsonPayload = {};
			jsonPayload.Sender = sSenderNumber;
			jsonPayload.Receiver = sReceiverNumber;
			jsonPayload.Text = sMessage;
			jsonPayload.AlertType = sAlertType;
			return jsonPayload;
		},

		/* #DontDelete : Yann */
		/**
		 * Create 
		 * @params() oAlert is the 
		 * @params() isRead is the 
		 */
		createAlertUpdatePayload: function(oAlert, isRead) {
			var jsonPayload = {};
			jsonPayload.Id = oAlert.Id;
			jsonPayload.Sender = oAlert.Sender;
			jsonPayload.Receiver = oAlert.Receiver;
			jsonPayload.Timestamp = oAlert.Timestamp; //Today?
			jsonPayload.Text = oAlert.Text;
			jsonPayload.ReadFlag = isRead;
			return jsonPayload;
		},

		/* #DontDelete : Yann */
		/** 
		 * Create the alert message
		 * @param {function} successCallBack is the callback function that would be executed on OData success callback
		 * @param {object}   oContext is the controller object that implements the error and success call backs
		 * @param {object}   oMessagePayLoad is the pay load generated.
		 */
		createAlertsMessage: function(successCallBack, oContext, oMessagePayLoad) {
			BusyIndicator.showBusyIndicator();
			this._oModel.create("/AlertSet",
				oMessagePayLoad, {
					async: false,
					success: function(oData) {
						BusyIndicator.hideBusyIndicator();
						if (successCallBack && oContext) {
							successCallBack.apply(oContext);
						}
					},
					error: function(oError) {
						BusyIndicator.hideBusyIndicator();
						ErrorManager.handleError(oError);
					}
				});
		},

		/* #DontDelete : Yann */
		/** 
		 * Create the alert message
		 * @param {object}   oMessagePayLoad is the pay load generated.	 
		 */
		onUpdateAlertMessage: function(oMessagePayload, fnCallBack, oContext) {
			this._oModel.update("/AlertSet('" + oMessagePayload.Id + "')",
				oMessagePayload,
				{
					groupId: _this.groupId,
					//merge: false,
					success: function(oData) {
						if (fnCallBack && oContext) {
							fnCallBack.apply(oContext);
						}
					},
					error: function(oError) {
						if (fnCallBack && oContext) {
							fnCallBack.apply(oContext);
						}
					}
				}
			);
		},

		/* #DontDelete : Yann */
		/** 
		 * delete the alert message
		 * @params {object} oAlert is the alert to delete	 
		 */
		deleteAlertMessage: function(oAlert, fnCallBack, oContext) {
			this._oModel.remove("/AlertSet('" + oAlert.Id + "')",
				{
					groupId: _this.groupId,
					success: function(oData) {
						if (fnCallBack && oContext) {
							fnCallBack.apply(oContext);
						}
					},
					error: function(oError) {
						if (fnCallBack && oContext) {
							fnCallBack.apply(oContext);
						}
					}
				}
			);
		},

		/* #DontDelete : Yann */
		/** 
		 * Create the alert message
		 * @param {object}   batchGroupId is the Id of the batch group which will be updated.
		 * @param {function} successCallBack is the callback function that would be executed on OData success callback
		 * @param {object}   oContext is the controller in which context the update operation is executed		 
		 */
		submitUpdateAlertsBatch: function(fnSuccessCallBack, oContext) {
			this._oModel.submitChanges({
				groupId: _this.groupId
			});
		}

	};
});