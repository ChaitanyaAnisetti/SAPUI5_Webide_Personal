jQuery.sap.declare("com.sap.cp.lm.model.work.WorkDataModel");

sap.ui.define(["com/sap/cp/lm/util/Constants",
		"com/sap/cp/lm/util/Formatter",
		"com/sap/cp/lm/util/ErrorManager",
		"com/sap/cp/lm/util/BusyIndicator"
	],
	function(Constants, Formatter, ErrorManager, BusyIndicator) {
		"use strict";

		var _this;
		return com.sap.cp.lm.model.work.WorkDataModel = {
			init: function(oMainModel, oGlobalModel) {
				_this = this;
				this._oModel = oMainModel;
				this.oGlobalModel = oGlobalModel;
			},

			/**
			 * fetch the updated operations 
			 * @param {function} fnSuccessCallBack is the callback function that would be executed on OData success callback
			 * @param {object} oContext is the controller object that implements the error and success call backs
			 * @param {string} sWorkOrderNum is the work order number
			 * @param {string} sOperationNumber is the operation number
			 * @param {string} sTimeReprtedPath is the reported time path
			 */
			fetchUpdatedOperations: function(fnSuccessCallBack, oContext, sWorkOrderNum, sOperationNumber, sTimeReprtedPath, sTaskPath) {

				this._oModel.read("/OperationSet(WorkOrderNum='" + sWorkOrderNum + "',OperationNumber='" + sOperationNumber + "')", {
					urlParameters: {
						"$expand": "TaskSet,MaterialSet,AssignmentSet"
					},

					success: function(oData) {

						var oOperationModel = new sap.ui.model.json.JSONModel({
							detailsData: oData
						});

						if (fnSuccessCallBack && oContext) {
							fnSuccessCallBack.apply(oContext, [oOperationModel, sTimeReprtedPath, sTaskPath]);
						}
					},
					error: function(oError) {
						BusyIndicator
							.hideBusyIndicator();
						ErrorManager
							.handleError(oError);

					}
				});

			},
			/**
			 * Fetches the data for the Measuring Point
			 * @params{function} successCallBack is the callback function that would be executed on OData success callback
			 * @params{function} fnErrorCallBack is the callback function that would be executed on OData error callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * @params{string}   sMeasuringPoint is the Point to fetch data for
			 */
			fetchMeasuringPointData: function(successCallBack, fnErrorCallBack, oContext, sMeasuringPoint) {
				this._oModel.read("/MeasuringPointSet('" + sMeasuringPoint + "')", {
					urlParameters: {
						"$expand": "Documents,Values"
					},
					success: function(oData) {
						if (successCallBack && oContext) {
							successCallBack.apply(oContext, [oData]);
						}
					},
					error: function(oError) {
						ErrorManager.handleError(oError);
						if (fnErrorCallBack && oContext) {
							fnErrorCallBack.apply(oContext);
						}
					}
				});
			},
			/**
			 * Fetches the data for the Measuring Point
			 * @params{function} fnSuccessCallBack is the callback function that would be executed on OData success callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * @params{string}   oMeasuringPointPayload is the payload sent for Measuring Point creation
			 */
			createMeasuringPoint: function(fnSuccessCallBack, oContext, oMeasuringPointPayload) {
				this._oModel.create("/MeasurementDocumentSet",
					oMeasuringPointPayload, {
						success: function(oData) {
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData]);
							}
						},
						error: function(oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager
								.handleError(oError);
						}
					});
			},
			/**
			 * Fetches the data for the Measuring Point History
			 * @params{function} fnSuccessCallBack is the callback function that would be executed on OData success callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * @params{string}   sMeasuringPoint is the Measuring Point to fetch documents for
			 * @params{string}   sDocumentNumber is the Document Number for that point
			 */
			fetchMeasurementDocument: function(fnSuccessCallBack, oContext, sMeasuringPoint, sDocumentNumber) {
				this._oModel.read("/MeasurementDocumentSet(MeasuringPoint='" + sMeasuringPoint + "',DocumentNumber='" +
					sDocumentNumber + "')", {
						success: function(oData) {
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData]);
							}
						},
						error: function(oError) {
							BusyIndicator.hideBusyIndicator();
							ErrorManager
								.handleError(oError);
						}
					});
			},

			/**
			 * Send a list of tasks to set them as completed
			 * @params{function} fnSuccessCallBack is the callback function that would be executed on OData success callback
			 * @params{function} fnErrorCallBack is the callback function that would be executed on OData error callback
			 * @param {object}   oContext is the controller object that implements the error and success call backs
			 * @params{string}   oPayload is the Task data to post
			 */
			completeTasks: function(fnSuccessCallBack, fnErrorCallBack, oContext, oPayload) {
				BusyIndicator.showBusyIndicator();

				this._oModel.create("/OrderSet",
					oPayload, {
						success: function(oData) {
							BusyIndicator.hideBusyIndicator();
							if (fnSuccessCallBack && oContext) {
								fnSuccessCallBack.apply(oContext, [oData]);
							}
						},
						error: function(oError) {
							BusyIndicator.hideBusyIndicator();
							if (fnErrorCallBack && oContext) {
								fnErrorCallBack.apply(oContext, [oError]);
							}
						}
					}
				);
			}

		};
	});