//Dont Delete Main Model
jQuery.sap.declare("com.sap.cp.lm.model.LocomotiveMaintenanceModel");
jQuery.sap.require("sap.ui.model.odata.v2.ODataModel");
jQuery.sap.require("sap.ui.model.odata.ODataUtils");

/**
 * Base class for view models.
 */
sap.ui.model.odata.v2.ODataModel.extend("com.sap.cp.lm.model.LocomotiveMaintenanceModel", {
	/**
	 * Trigger a request to the function import odata service that was specified in the model constructor.
	 *
	 * If the ReturnType of the function import is either an EntityType or a collection of EntityType the
	 * changes are reflected in the model, otherwise they are ignored, and the <code>response</code> can
	 * be processed in the successHandler.
	 *
	 * @param {string} sFunctionName A string containing the name of the function to call. The name is concatenated to the sServiceUrl which was
	 *        specified in the model constructor.
	 * @param {map} [mParameters] Optional parameter map containing any of the following properties:
	 * @param {string} [mParameters.method] A string containing the type of method to call this function with
	 * @param {map} [mParameters.urlParameters] A map containing the parameters that will be passed as query strings
	 * @param {function} [mParameters.success] a callback function which is called when the data has been successfully retrieved. The handler can have
	 *        the following parameters: <code>oData<code> and <code>response</code>.
	 * @param {function} [mParameters.error] a callback function which is called when the request failed.
	 *		The handler can have the parameter: <code>oError</code> which contains additional error information.
	 * @param {string} [mParameters.batchGroupId] batchGroupId for this request
	 * @param {string} [mParameters.changeSetId] changeSetId for this request
	 *
	 * @return {object} oRequestHandle An object which has an <code>abort</code> function to abort the current request.
	 *
	 * @public
	 */
	callFunction: function (sFunctionName, mParameters) {
		var oRequest, sUrl,
			oFunctionMetadata,
			mRequests,
			mUrlParams,
			aUrlParams, 
			fnSuccess, fnError,
			sMethod = "GET",
			aUrlParams,
			mInputParams = {},
			sBatchGroupId,
			sChangeSetId,
			mHeaders,
			that = this;

		if (mParameters) {
			sBatchGroupId 	= mParameters.batchGroupId;
			sChangeSetId 	= mParameters.changeSetId;
			sMethod			= mParameters.method ? mParameters.method : sMethod;
			mUrlParams		= mParameters.urlParameters;
			fnSuccess		= mParameters.success;
			fnError			= mParameters.error;
			mHeaders		= mParameters.headers;
		}

		if (!jQuery.sap.startsWith(sFunctionName, "/")) {
			jQuery.sap.log.fatal(this + " callFunction: path '" + sFunctionName + "' must be absolute!");
			return;
		}

		mHeaders = this._getHeaders(mHeaders);

		return this._processRequest(function() {
			oFunctionMetadata = that.oMetadata._getFunctionImportMetadata(sFunctionName, sMethod);
			jQuery.sap.assert(oFunctionMetadata, that + ": Function " + sFunctionName + " not found in the metadata !");
			if (!oFunctionMetadata) {
				return;
			}
			
			if (oFunctionMetadata.parameter != null) {
				jQuery.each(mUrlParams, function (sParameterName, oParameterValue) {
					var matchingParams = jQuery.grep(oFunctionMetadata.parameter, function (oParameter) {
						return oParameter.name === sParameterName && 
								(!oParameter.mode || oParameter.mode === "In");
					});
					if (matchingParams != null && matchingParams.length > 0) {
						mInputParams[sParameterName] = sap.ui.model.odata.ODataUtils.formatValue(oParameterValue, matchingParams[0].type);
					} else {
						/**
						 * Overwrite UI5 logic to let $expand attribute to be added to the request url.
						 */
						if(sParameterName == "$expand"){
							mInputParams[sParameterName] = oParameterValue;
						} else {
							jQuery.sap.log.warning(that + " - Parameter '" + sParameterName + "' is not defined for function call '" + sFunctionName + "'!");
						}
						
					}
				});
			}
			aUrlParams = sap.ui.model.odata.ODataUtils._createUrlParamsArray(mInputParams);

			sUrl = that._createRequestUrl(sFunctionName, null, aUrlParams, that.bUseBatch);
			oRequest = that._createRequest(sUrl, sMethod, mHeaders, undefined);

			mRequests = that.mRequests;
			// don't know where mDeferredBatchGroups is defined 
			/*
			if (sBatchGroupId in that.mDeferredBatchGroups) {
				mRequests = that.mDeferredRequests;
			}
			*/
			that._pushToRequestQueue(mRequests, sBatchGroupId, sChangeSetId, oRequest, fnSuccess, fnError);

			return oRequest;
		});
	}
});