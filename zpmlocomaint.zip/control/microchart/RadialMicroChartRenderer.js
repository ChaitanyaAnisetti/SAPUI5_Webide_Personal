sap.ui.define('com/sap/cp/lm/control/microchart/RadialMicroChartRenderer', 
		["jquery.sap.global"],
	function(q) {
	    "use strict";
	    var R = {};
	    R.FORM_RATIO = 1000;
	    R.BACKGROUND_CIRCLE_BORDER_WIDTH = 1;
	    R.BACKGROUND_CIRCLE_RADIUS = 500;
	    R.CIRCLE_BORDER_WIDTH = 87.5;
	    R.CIRCLE_RADIUS = 441.75;
	    R.SVG_VIEWBOX_CENTER_FACTOR = "50%";
	    R.X_ROTATION = 0;
	    R.SWEEP_FLAG = 1;
	    R.PADDING_WIDTH = 0.22;
	    R.NUMBER_FONT_SIZE = 235;
	    R.EDGE_CASE_SIZE_ACCESSIBLE_COLOR = 54;
	    R.EDGE_CASE_SIZE_SHOW_TEXT = 46;
	    R.EDGE_CASE_SIZE_MICRO_CHART = 24;
	    R.render = function(r, c) {
	        this._writeDivStartElement(c, r);
	        this._writeSVGStartElement(r);
	        this._writeBackground(r);
	        if (this._renderingOfInnerContentIsRequired(c)) {
	            this._writeBorders(r);
	            if (this._innerCircleRequired(c)) {
	                this._writeCircle(c, r);
	            } else {
	                this._writeCircleWithPathElements(c, r);
	            }
	            this._writeText(c, r);
	        }
	        r.write("</svg>");
	        r.write("</div>");
	    };
	    
	    R._writeDivStartElement = function(c, r) {
	        r.write("<div");
	        r.writeControlData(c);
	        var t = c._getTooltipText();
	        if (t) {
	            r.writeAttributeEscaped("title", t);
	        }
	        r.writeAttribute("role", "img");
	        r.writeAttributeEscaped("aria-label", c._getAriaText());
	        if (c.hasListeners("press")) {
	            r.addClass("sapSuiteUiMicroChartPointer");
	            r.writeAttribute("tabindex", "0");
	        }
	        r.addClass("sapSuiteRMC");
	        r.writeClasses();
	        r.writeStyles();
	        r.write(">");
	    };
	    
	    R._writeSVGStartElement = function(r) {
	        var p;
	        if (!sap.ui.getCore().getConfiguration().getRTL()) {
	            p = "xMaxYMid meet";
	        } else {
	            p = "xMinYMid meet";
	        }
	        r.write("<svg width=\"100%\" height=\"100%\" viewBox=\"0 0 " + R.FORM_RATIO + ' ' + R.FORM_RATIO + "\" preserveAspectRatio=\"" + p + "\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\">");
	    };
	    
	    R._writeBackground = function(r) {
	        r.write("<circle class=\"sapSuiteRMCCircleBackground\" cx=\"" + R.SVG_VIEWBOX_CENTER_FACTOR + "\" cy=\"" + R.SVG_VIEWBOX_CENTER_FACTOR + "\" r=\"" + R.BACKGROUND_CIRCLE_RADIUS + "\" stroke-width=\"" + this.BACKGROUND_CIRCLE_BORDER_WIDTH + "\" />");
	    };
	    
	    R._writeBorders = function(r) {
	        r.write("<circle class=\"sapSuiteRMCHCBIncompleteBorder\" cx=\"" + R.SVG_VIEWBOX_CENTER_FACTOR + "\" cy=\"" + R.SVG_VIEWBOX_CENTER_FACTOR + "\" r=\"" + (R.CIRCLE_RADIUS + R.CIRCLE_BORDER_WIDTH / 2.0 - R.BACKGROUND_CIRCLE_BORDER_WIDTH) + "\" stroke-width=\"" + R.BACKGROUND_CIRCLE_BORDER_WIDTH + "\" />");
	        r.write("<circle class=\"sapSuiteRMCHCBIncompleteBorder\" cx=\"" + R.SVG_VIEWBOX_CENTER_FACTOR + "\" cy=\"" + R.SVG_VIEWBOX_CENTER_FACTOR + "\" r=\"" + (R.CIRCLE_RADIUS - R.CIRCLE_BORDER_WIDTH / 2.0 + R.BACKGROUND_CIRCLE_BORDER_WIDTH) + "\" stroke-width=\"" + R.BACKGROUND_CIRCLE_BORDER_WIDTH + "\" />");
	    };
	    
	    R._writeCircle = function(c, r) {
	        r.write("<circle class=\"" + this._getSVGStringForColor(this._getFullCircleColor(c), c) + "\" cx=\"" + R.SVG_VIEWBOX_CENTER_FACTOR + "\" cy=\"" + R.SVG_VIEWBOX_CENTER_FACTOR + "\" r=\"" + R.CIRCLE_RADIUS + "\" fill=\"transparent\" stroke-width=\"" + R.CIRCLE_BORDER_WIDTH + "px\" />");
	    };
	    
	    R._writeCircleWithPathElements = function(c, r) {
	        var l = c.getPercentage() > 50 ? 1 : 0;
	        var p = this._getPercentageForCircleRendering(c) - R.PADDING_WIDTH;
	        var P = this._calculatePathCoordinates(c, p, false);
	        this._writePath1(l, P, c, r);
	        p = this._getPercentageForCircleRendering(c) + R.PADDING_WIDTH;
	        P = this._calculatePathCoordinates(c, p, true);
	        this._writePath2(l, P, c, r);
	    };
	    
	    R._writePath1 = function(l, p, c, r) {
	        var P = "M" + p[0] + " " + p[1] + " A " + R.CIRCLE_RADIUS + " " + R.CIRCLE_RADIUS + ", " + R.X_ROTATION + ", " + l + ", " + R.SWEEP_FLAG + ", " + p[2] + " " + p[3];
	        r.write("<path class=\"sapSuiteRMCPath" + this._getSVGStringForColor(this._getPathColor(c), c) + "d=\"" + P + "\" fill=\"transparent\" stroke-width=\"" + R.CIRCLE_BORDER_WIDTH + "px\" />");
	    };
	    
	    R._writePath2 = function(l, p, c, r) {
	        var P = "M" + p[2] + " " + p[3] + " A " + R.CIRCLE_RADIUS + " " + R.CIRCLE_RADIUS + ", " + R.X_ROTATION + ", " + (1 - l) + ", " + R.SWEEP_FLAG + ", " + p[0] + " " + p[1];
	        r.write("<path class=\"sapSuiteRMCPath sapSuiteRMCPathIncomplete\" d=\"" + P + "\" fill=\"transparent\" stroke-width=\"" + R.CIRCLE_BORDER_WIDTH + "px\" />");
	    };
	    
	    R._writeText = function(c, r) {
	        r.write("<text class=\"sapSuiteRMCFont\" aria-hidden=\"true\" text-anchor=\"middle\" alignment-baseline=\"middle\"" + "\" font-size=\"" + R.NUMBER_FONT_SIZE + "\" x=\"" + R.SVG_VIEWBOX_CENTER_FACTOR + "\" y=\"" + this._getVerticalViewboxCenterFactorForText() + "\"> " + this._generateTextContent(c) + "</text>");
	    };
	    
	    R._renderingOfInnerContentIsRequired = function(c) {
	        if (c._getPercentageMode() || (c.getTotal() !== 0)) {
	            return true;
	        } else {
	            return false;
	        }
	    };
	    
	    R._getSVGStringForColor = function(c, a) {
	        if (a._isValueColorInstanceOfValueColor()) {
	            return " " + c + "\"";
	        } else if (c === "sapSuiteRMCPathIncomplete") {
	            return " " + c + "\"";
	        } else {
	            return "\" stroke=\"" + c + "\"";
	        }
	    };
	    
	    R._getVerticalViewboxCenterFactorForText = function() {
	        if (sap.ui.Device.browser.msie) {
	            return "55%";
	        } else if (sap.ui.Device.browser.mozilla) {
	            return "56%";
	        } else {
	            return "51%";
	        }
	    };
	    
	    R._innerCircleRequired = function(c) {
	        if (c.getPercentage() >= 100 || c.getPercentage() <= 0) {
	            return true;
	        } else {
	            return false;
	        }
	    };
	    
	    R._calculatePathCoordinates = function(c, p, i) {
	        var C = [];
	        var P = 0;
	        if (i) {
	            P = 2 * R.PADDING_WIDTH / 100 * 2 * Math.PI;
	        }
	        C.push(R.FORM_RATIO / 2 + R.CIRCLE_RADIUS * Math.cos(-Math.PI / 2.0 - P));
	        C.push(R.FORM_RATIO / 2 + R.CIRCLE_RADIUS * Math.sin(-Math.PI / 2.0 - P));
	        C.push(R.FORM_RATIO / 2 + R.CIRCLE_RADIUS * Math.cos(-Math.PI / 2.0 + p / 100 * 2 * Math.PI));
	        C.push(R.FORM_RATIO / 2 + R.CIRCLE_RADIUS * Math.sin(-Math.PI / 2.0 + p / 100 * 2 * Math.PI));
	        return C;
	    };
	    
	    R._getPercentageForCircleRendering = function(c) {
	        var p = c.getPercentage();
	        var P = p;
	        if (p > 99 - R.PADDING_WIDTH) {
	            P = 99 - R.PADDING_WIDTH;
	        }
	        if (p < 1 + R.PADDING_WIDTH) {
	            P = 1 + R.PADDING_WIDTH;
	        }
	        return P;
	    };
	    
	    R._handleOnAfterRendering = function(c) {
	        var p;
	        if (c.getParent() !== undefined && c.getParent() !== null && c.getParent().getHeight !== undefined && c.getParent().getHeight !== null ) {
	        	var P = parseFloat(c.getParent().$().height()) - 2;
	            c.$().height(P);
	            c.$().children("svg").height(P);
	        }
	        if (c.getParent() !== undefined && c.getParent() !== null && c.getParent().getWidth !== undefined && c.getParent().getWidth !== null ) {
	            p = parseFloat(c.getParent().$().width()) - 2;
	            c.$().width(p);
	            c.$().children("svg").width(p);
	        }
	
	        if (parseInt(c.$().children("svg").css("height"), 10) < R.EDGE_CASE_SIZE_MICRO_CHART || parseInt(c.$().children("svg").css("width"), 10) < R.EDGE_CASE_SIZE_MICRO_CHART) {
	            c.$().hide();
	            return;
	        }
	        var t = c.$().find("text");
	        var s = c.$().children("svg");
	        if (parseInt(s.css("height"), 10) <= R.EDGE_CASE_SIZE_SHOW_TEXT || parseInt(s.css("width"), 10) <= R.EDGE_CASE_SIZE_SHOW_TEXT) {
	            t.hide();
	        } else {
	            var T = this._getTextColorClass(c);
	            var C = s.attr("class") || "";
	            if (C.indexOf(T) < 0) {
	                var n = C + " " + T;
	                var S = parseInt(s.css("height"), 10);
	                if (S <= R.EDGE_CASE_SIZE_ACCESSIBLE_COLOR) {
	                    n += " sapSuiteRMCSmallFont";
	                }
	                s.attr("class", n);
	            }
	        }
	    };
	    
	    R._adjustToTileContent = function(c) {
	        var p = c.getParent().$().css("min-width");
	        c.getParent().$().width(p);
	        if (sap.ui.Device.browser.msie || sap.ui.Device.browser.edge) {
	            c.$().width(parseInt(p, 10) - 16);
	        }
	    };
	    
	    R._adjustToTileContent = function(c) {
	        var p = c.getParent().$().css("min-width");
	        c.getParent().$().width(p);
	        if (sap.ui.Device.browser.msie || sap.ui.Device.browser.edge) {
	            c.$().width(parseInt(p, 10) - 16);
	        }
	    };
	    
	    R._getTextColorClass = function(c) {
	        var s = parseInt(q.sap.byId(c.getId()).children("svg").css("height"), 10);
	        if (s <= R.EDGE_CASE_SIZE_ACCESSIBLE_COLOR && (!c._isValueColorInstanceOfValueColor() || c.getValueColor() === sap.suite.ui.commons.ValueStatus.Good)) {
	            return "sapSuiteRMCAccessibleTextColor";
	        } else {
	            switch (c.getValueColor()) {
	            case "Good":
	                return "sapSuiteRMCGoodTextColor";
	            case "Warning":
	                return "sapSuiteRMCErrorTextColor";
	            case "Critical":
	                return "sapSuiteRMCCriticalTextColor";
	            default:
	                return "sapSuiteRMCNeutralTextColor";
	            }
	        }
	    };
	    
	    R._getFullCircleColor = function(c) {
	        if (c.getPercentage() >= 100) {
	            return this._getPathColor(c);
	        }
	        if (c.getPercentage() <= 0) {
	            return "sapSuiteRMCPathIncomplete";
	        }
	    };
	    
	    R._getPathColor = function(c) {
	        var v = c.getValueColor();
            switch (v) {
            	case "Good":
            		return "sapSuiteRMCPathGood";
	            case "Warning":
	                return "sapSuiteRMCPathError";
	            case "Critical":
	                return "sapSuiteRMCPathCritical";
	            default:
	                return "sapSuiteRMCPathNeutral";
            }
	    };	    
	    
	    R._generateTextContent = function(c) {
	        return c.getPercentage() + "%";
	    };
	    
	    return R;
	}, 
	true
);