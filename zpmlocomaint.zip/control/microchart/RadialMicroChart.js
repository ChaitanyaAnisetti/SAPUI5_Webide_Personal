sap.ui.define('com/sap/cp/lm/control/microchart/RadialMicroChart', [
		'jquery.sap.global', 
		//'./library', 
		'sap/ui/core/Control', 
		'com/sap/cp/lm/control/microchart/RadialMicroChartRenderer'], 
	function(q, C, R) {
	    "use strict";
	    var a = C.extend("com.sap.cp.lm.control.microchart.RadialMicroChart", {
	        constructor: function(i, s) {
	            var p;
	            if (s && typeof s.percentage === "number") {
	                p = true;
	            } else if (i && typeof i.percentage === "number") {
	                p = true;
	            } else {
	                p = false;
	            }
	            try {
	                C.apply(this, arguments);
	                this._bPercentageMode = p;
	            } catch (e) {
	                this.destroy();
	                throw e;
	            }
	        },
	        metadata: {            
	            properties: {
	                total: {
	                    group: "Data",
	                    type: "float",
	                    defaultValue: "1.0"
	                },
	                fraction: {
	                    group: "Data",
	                    type: "float",
	                    defaultValue: null
	                },
	                percentage: {
	                    group: "Data",
	                    type: "float",
	                    defaultValue: null
	                },
	                valueColor: {
	                    group: "Appearance",
	                    type: "string",
	                    defaultValue: "Good"
	                }
	            },
	            events: {
	                press: {}
	            }
	        }
	    });
	    a.prototype.init = function() {        
	        this._bPercentageMode;
	    };
	    
	    a.prototype.onBeforeRendering = function() {
	        if (!this._bPercentageMode) {
	            if (this.getTotal() === 0) {
	                q.sap.log.error("Total can not be 0, please add a valid total value");
	            } else {
	                this.setProperty("percentage", Math.round((this.getFraction() * 100 / this.getTotal()) * 10) / 10, true);
	            }
	        }
	    };
	    
	    a.prototype.onAfterRendering = function() {
	        R._handleOnAfterRendering(this);
	    };
	    
	    a.prototype.ontap = function(e) {
	        if (sap.ui.Device.browser.internet_explorer) {
	            this.$().focus();
	        }
	        this.firePress();
	    };
	    
	    a.prototype.onkeydown = function(e) {
	        if (e.which === q.sap.KeyCodes.SPACE) {
	            e.preventDefault();
	        }
	    };
	    
	    a.prototype.onkeyup = function(e) {
	        if (e.which === q.sap.KeyCodes.ENTER || e.which === q.sap.KeyCodes.SPACE) {
	            this.firePress();
	            e.preventDefault();
	        }
	    };
	    
	    a.prototype.attachEvent = function(e, d, f, b) {
	        sap.ui.core.Control.prototype.attachEvent.call(this, e, d, f, b);
	        if (e === "press") {
	            this.rerender();
	        }
	        return this;
	    };
	    
	    a.prototype.detachEvent = function(e, f, b) {
	        sap.ui.core.Control.prototype.detachEvent.call(this, e, f, b);
	        if (e === "press") {
	            this.rerender();
	        }
	        return this;
	    };
	    
	    a.prototype._getPercentageMode = function() {
	        return this._bPercentageMode;
	    };
	    
	    a.prototype.setPercentage = function(p) {
	        if (p) {
	            if (p !== this.getPercentage()) {
	                this._bPercentageMode = true;
	                this.setProperty("percentage", p);
	            }
	        } else {
	            this._bPercentageMode = false;
	            this.setProperty("percentage", null );
	        }
	    };
	    
	    a.prototype.getTooltip_AsString = function() {
	        return this._getTooltipText();
	    };
	    
	    a.prototype._isValueColorInstanceOfValueColor = function() {
	        //var v = this.getValueColor();
	        return true;
	    };
	    
	    a.prototype._getTooltipText = function() {
	        var t = this.getTooltip_Text();
	        if (!t) {
	            t = this._getAriaAndTooltipText();
	        } else if (this._isTooltipSuppressed()) {
	            t = null ;
	        }
	        return t;
	    };
	    
	    a.prototype._getAriaText = function() {
	        var A = this.getTooltip_Text();
	        if (!A || this._isTooltipSuppressed()) {
	            A = this._getAriaAndTooltipText();
	        }
	        return A;
	    };
	    
	    a.prototype._isTooltipSuppressed = function() {
	        var t = this.getTooltip_Text();
	        if (t && q.trim(t).length === 0) {
	            return true;
	        } else {
	            return false;
	        }
	    };
	    
	    a.prototype._getAriaAndTooltipText = function() {
	        var t = "Good";
	        var p = this.getPercentage();
	        if (p > 100) {
	            p = 100;
	        } else if (p < 0) {
	            p = 0;
	        }
	        return t;
	    };
	    
	    a.prototype._getStatusText = function() {
	        var v = this.getValueColor();
	        switch (v) {
	        case "Warning":
	            return "SEMANTIC_COLOR_ERROR";
	        case "Critical":
	            return "SEMANTIC_COLOR_CRITICAL";
	        case "Good":
	            return "SEMANTIC_COLOR_GOOD";
	        default:
	            return "SEMANTIC_COLOR_NEUTRAL";
	        }
	    };
	    return a;
	}
);