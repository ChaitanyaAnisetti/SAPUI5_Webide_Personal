sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"YMM_P2P_StatusList/Formatter/Formatter",
	"sap/m/Token"
], function (Controller, Filter, Formatter, Token) {
	"use strict";

	return Controller.extend("YMM_P2P_StatusList.controller.View1", {

		onInit: function () {

			this.url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

			var that = this;
			that.oDataModel = new sap.ui.model.odata.ODataModel(that.url, true);
			that.getOwnerComponent().oDataModel = that.oDataModel;

			var path = "/ymm_userSet";
			that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

				var oObjemodel1 = oData.results;

				var oLoggeduserModel = new sap.ui.model.json.JSONModel(oObjemodel1);
				oLoggeduserModel.setSizeLimit(1000);

				that.getView().byId("oLogdusr1Id").setModel(oLoggeduserModel, "oUserDetails");
				that.Loggeduser = that.getView().byId("oLogdusr1Id").getModel("oUserDetails").getData()[0].SYUSER;
			//	that.Loggeduser = "RU0895";
				//	that.Loggeduser ="SD46735"
				//	 that.Loggeduser = "DU10001";
				//	that.Loggeduser =  "DS54706";
				//that.Loggeduser =	"PN53745";

				//		that.Loggeduser = "RM58634";

			}, function (error) {

			});

			that.getView().byId("idRecords").setSelectedKey(0);

			var path1 = "/ymm_manager_setSet";
			that.oDataModel.read(path1, null, null, false, function (oData, oResponse) {

				var oManagerModel = oData.results;

				that.oFIlterResultsManager = oManagerModel.filter(function (x) {
					return x.User == that.Loggeduser;

				});

			}, function (error) {

			});

			var path2 = "/YMM_PR_HAMSet";
			that.oDataModel.read(path2, null, null, false, function (oData, oResponse) {
				var oHamModel = oData.results;

				that.oFIlterResultsHam = oHamModel.filter(function (x) {
					return x.AFNAM == that.Loggeduser;

				});

			}, function (error) {

			});

			var path3 = "/YMM_PR_SAMSet";
			that.oDataModel.read(path3, null, null, false, function (oData, oResponse) {
				var oSamModel = oData.results;

				that.oFIlterResultsSam = oSamModel.filter(function (x) {
					return x.AFNAM == that.Loggeduser;

				});

			}, function (error) {

			});
			var path4 = "/YMM_PR_BUYER_IDSet";
			that.oDataModel.read(path4, null, null, false, function (oData, oResponse) {
				var oBuyerModel = oData.results;

				that.oFIlterResultsBuyer = oBuyerModel.filter(function (x) {
					return x.afnam == that.Loggeduser;

				});

			}, function (error) {

			});

			var url = "/sap/opu/odata/sap/YMM_PR_FIORI_LOG_STATUS_SRV";

			that.oRecrds = that.getView().byId("idRecords").getSelectedKey();
			that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);
			var path = "/ymm_fiori_setSet?$top=" + that.oRecrds;
			that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

				var oObjemodelX = oData.results;
				var Allusermodels = [];
				if (that.oFIlterResultsManager && that.oFIlterResultsManager.length) {
					Allusermodels.push("Pending With manager");
				}
				if (that.oFIlterResultsSam && that.oFIlterResultsSam.length) {
					Allusermodels.push("Pending With SAM");
				}
				if (that.oFIlterResultsHam && that.oFIlterResultsHam.length) {
					Allusermodels.push("Pending With HAM");
				}
				if (that.oFIlterResultsBuyer && that.oFIlterResultsBuyer.length) {
					Allusermodels.push("Pending With buyer");
				}

				var OModel = [];
				for (var i = 0; i < oObjemodelX.length; i++) {
					for (var j = 0; j < Allusermodels.length; j++) {
						if (oObjemodelX[i].Status === Allusermodels[j]) {
							OModel.push(oObjemodelX[i]);
						}

					}

				}

				that.OModelRef = OModel;
				that.RefAllusermodels = Allusermodels;

			});

			var OBuyeruser = that.RefAllusermodels.filter(function (x) {
				return x === "Pending With buyer";
			});
			var OSamuser = that.RefAllusermodels.filter(function (x) {
				return x === "Pending With SAM";
			});
			var OHamuser = that.RefAllusermodels.filter(function (x) {
				return x === "Pending With HAM";
			});
			var OManageruser = that.RefAllusermodels.filter(function (x) {
				return x === "Pending With manager";
			});

			var MergedData = [];
			if (OBuyeruser.length) {

				var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";

				that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);
				var path = "/zmmsh_categorySet";
				that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

					var oCatgModel = oData.results;

					that.oCatModl = oCatgModel.filter(function (x) {
						return x.Buyer_id == that.Loggeduser;
					});

					var oFiltplant = that.oCatModl;
					var oDumplant = oFiltplant.filter(function (a) {
						var key = a.category + '|' + a.plant;
						if (!this[key]) {
							this[key] = true;
							return true;
						}
					}, Object.create(null));
					var oSmodel = that.OModelRef;
					for (var i = 0; i < oSmodel.length; i++) {
						for (var j = 0; j < oDumplant.length; j++) {
							if (oDumplant[j].plant == oSmodel[i].Plant && oDumplant[j].category == oSmodel[i].Reqcategory) {
								MergedData.push(oSmodel[i]);
							}

						}

					}

				}, function (error) {

				});
			}

			if (OSamuser.length) {

				var oDumplant = that.RefAllusermodels;

				var oSmodel = that.OModelRef;
				that.oSamoObjemodel = [];
				for (var i = 0; i < oSmodel.length; i++) {
					for (var j = 0; j < oDumplant.length; j++) {
						if (oDumplant[j] == oSmodel[i].Status) {
							MergedData.push(oSmodel[i]);
						}

					}

				}

			}
			if (OHamuser.length) {

				var oDumplant = that.RefAllusermodels;

				var oSmodel = that.OModelRef;
				that.oHamoObjemodel = [];
				for (var i = 0; i < oSmodel.length; i++) {
					for (var j = 0; j < oDumplant.length; j++) {
						if (oDumplant[j] == oSmodel[i].Status) {
							MergedData.push(oSmodel[i]);
						}

					}

				}

			}
			if (OManageruser.length) {

				var oDumplant = that.RefAllusermodels;

				var oSmodel = that.OModelRef;

				for (var i = 0; i < oSmodel.length; i++) {
					for (var j = 0; j < oDumplant.length; j++) {
						if (oDumplant[j] == oSmodel[i].Status) {
							MergedData.push(oSmodel[i]);
						}

					}

				}

			}
			MergedData = MergedData.filter(function (a) {
				var key = a.Prnumber + '|' + a.Pritem + '|' + a.Status;
				if (!this[key]) {
					this[key] = true;
					return true;
				}
			}, Object.create(null));

			var obj = {};

			for (var i = 0, len = MergedData.length; i < len; i++)
				obj[MergedData[i]['Plant']] = MergedData[i];

			var plant = new Array();
			for (var key in obj)
				plant.push(obj[key]);

			var F4DataModel = new sap.ui.model.json.JSONModel();
			that.getView().setModel(F4DataModel, "F4DataModel");
			that.getView().getModel("F4DataModel").setProperty("/PlantF4", plant);
			var PlantF4Id = that.getView().byId("InputValuePlant");

			for (var a = 0; a < plant.length; a++) {
				var defToken = new sap.m.Token({
					text: plant[a].Plant,
					key: plant[a].Plant
				});
				// Add created token to the Plant field
				PlantF4Id.addToken(defToken);
			}

			var obj = {};

			for (var i = 0, len = MergedData.length; i < len; i++)
				obj[MergedData[i]['Prnumber']] = MergedData[i];

			var oPrnumber = new Array();
			for (var key in obj)
				oPrnumber.push(obj[key]);

			var PrF4DataModel = new sap.ui.model.json.JSONModel();
			that.getView().setModel(PrF4DataModel, "PrF4DataModel");
			that.getView().getModel("PrF4DataModel").setProperty("/PrnumsF4", oPrnumber);

			var obj = {};
			for (var i = 0, len = MergedData.length; i < len; i++)
				obj[MergedData[i]['Buname']] = MergedData[i];
			var oBusUniname = new Array();
			for (var key in obj)
				oBusUniname.push(obj[key]);

			var BunameF4DataModel = new sap.ui.model.json.JSONModel();
			that.getView().setModel(BunameF4DataModel, "BunameF4DataModel");
			that.getView().getModel("BunameF4DataModel").setProperty("/BunamesF4", oBusUniname);
			var BunamesF4Id = that.getView().byId("InputValueBuname");

			for (var a = 0; a < oBusUniname.length; a++) {
				var defToken = new sap.m.Token({
					text: oBusUniname[a].Buname,
					key: oBusUniname[a].Buname
				});
				// Add created token to the Plant field
				BunamesF4Id.addToken(defToken);
			}

			var obj = {};
			for (var i = 0, len = MergedData.length; i < len; i++)
				obj[MergedData[i]['Status']] = MergedData[i];
			var oStatus = new Array();
			for (var key in obj)
				if (key == "") {
					/*oStatus.pop();*/
				} else {

					oStatus.push(obj[key]);
				}

			var oStatusF4DataModel = new sap.ui.model.json.JSONModel();
			that.getView().setModel(oStatusF4DataModel, "oStatusF4DataModel");

			//	var termmanager = "manager";
			//	var omanagername = oStatus.filter(x => new RegExp(termmanager, 'i').test(x.Status));
			//	var omanagername1 = "";
			/*	oStatus.find(function (value, index) {
						if (value.Status.indexOf(termmanager)!=-1){
						
							omanagername1 =value.Status;
						}
					});*/

			that.getView().getModel("oStatusF4DataModel").setProperty("/StatusF4", oStatus);

			var obj = {};
			for (var i = 0, len = MergedData.length; i < len; i++)
				obj[MergedData[i]['ItNonitStatus']] = MergedData[i];

			var oItnonStatus = new Array();
			for (var key in obj)
				if (key == "") {
					oItnonStatus.pop();
				} else {

					oItnonStatus.push(obj[key]);
				}

			var oItnonStatusF4DataModel = new sap.ui.model.json.JSONModel();
			that.getView().setModel(oItnonStatusF4DataModel, "oItnonStatusF4DataModel");
			that.getView().getModel("oItnonStatusF4DataModel").setProperty("/ItnonStatusF4", oItnonStatus);

			var obj = {};
			for (var i = 0, len = MergedData.length; i < len; i++)
				obj[MergedData[i]['ReqMgrStatus']] = MergedData[i];
			var oReqmangStatus = new Array();
			for (var key in obj)
				if (key == "") {
					oReqmangStatus.pop();
				} else {

					oReqmangStatus.push(obj[key]);
				}

			var oReqmangStatusF4DataModel = new sap.ui.model.json.JSONModel();
			that.getView().setModel(oReqmangStatusF4DataModel, "oReqmangStatusF4DataModel");
			that.getView().getModel("oReqmangStatusF4DataModel").setProperty("/ReqmangStatusF4", oReqmangStatus);

			var obj = {};
			for (var i = 0, len = MergedData.length; i < len; i++)
				obj[MergedData[i]['Reqcategory']] = MergedData[i];
			var oReqcate = new Array();
			for (var key in obj)

				oReqcate.push(obj[key]);

			var oReqcateF4DataModel = new sap.ui.model.json.JSONModel();
			that.getView().setModel(oReqcateF4DataModel, "oReqcateF4DataModel");
			that.getView().getModel("oReqcateF4DataModel").setProperty("/oReqcateF4", oReqcate);

			var ReqcateFF4Id = that.getView().byId("InputValueReqcatry");

			for (var a = 0; a < oReqcate.length; a++) {
				var defToken = new sap.m.Token({
					text: oReqcate[a].Reqcategory,
					key: oReqcate[a].Reqcategory
				});
				// Add created token to the Reqcategory field
				ReqcateFF4Id.addToken(defToken);
			}

			var oModel = new sap.ui.model.json.JSONModel(MergedData);
			oModel.setSizeLimit(200000);

			that.getView().byId("oMainTable").setModel(oModel, "oPRframe1Model");

			that.getView().byId("idRecords").setSelectedKey(that.oRecrds);

			that.getView().byId("Items").setText("Items(" + "" + MergedData.length + "" + ")"); //	var oObjemodel = that.OModelRef;

		},
		handleValueHelpPrnumber: function (oEvent) {

			var sInputValue2 = oEvent.getSource().getValue();
			if (!this._valueHelpDialog2) {
				this._valueHelpDialog2 = sap.ui.xmlfragment(
					"YMM_P2P_StatusList.Fragment.Prnumber",
					this
				);
				this.getView().addDependent(this._valueHelpDialog2);
			}
			var that = this;

			var oPrsModel = that.getView().byId("oMainTable").getModel("oPRframe1Model").getData();

			var oFIlterResults = oPrsModel.filter(function (x) {
				return x.Prnumber;

			});

			var oPrnumodel = new sap.ui.model.json.JSONModel(oFIlterResults);
			sap.ui.getCore().byId("oidPrnos").setModel(oPrnumodel);
			that._valueHelpDialog2.open(sInputValue2);

		},
		onPrCancel: function () {
			this._valueHelpDialog2.destroy(true);
			this._valueHelpDialog2 = undefined;
		},

		onPrConfirm: function (oEvent) {
			this.oSelectedItem = oEvent.getParameters().selectedItem.mProperties.title;

			this.getView().byId("InputValuePrno").setValue(this.oSelectedItem);

			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialog2.destroy(true);
			this._valueHelpDialog2 = undefined;
		},

		handlePrConfSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oidPrnos");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([

					new sap.ui.model.Filter("Prnumber", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},

		handleValueHelpPlnt: function (oEvent) {

			var sInputValueP = oEvent.getSource().getValue();
			if (!this._valueHelpDialogP) {
				this._valueHelpDialogP = sap.ui.xmlfragment(
					"YMM_P2P_StatusList.Fragment.Plant",
					this
				);
				this.getView().addDependent(this._valueHelpDialogP);
			}
			var that = this;
			var oPlntModel = that.oPlantmodelfilterd;
			var obj = {};

			var oTokens = this.getView().byId("InputValuePlant").getTokens();
			var PlantData = sap.ui.getCore().byId("olPlntidfrg").getAggregation("items");
			if (oTokens.length && PlantData && PlantData.length) {
				for (var i = 0; i < oTokens.length; i++) {
					for (var j = 0; j < PlantData.length; j++) {
						if (oTokens[i].getText() === PlantData[j].getTitle()) {
							sap.ui.getCore().byId("olPlntidfrg").getAggregation("items")[j].setSelected(true);
						}
					}
				}
			}

			for (var i = 0, len = oPlntModel.length; i < len; i++)
				obj[oPlntModel[i]['Plant']] = oPlntModel[i];

			var plant = new Array();
			for (var key in obj)
				plant.push(obj[key]);

			var F4DataModel = new sap.ui.model.json.JSONModel();
			that.getView().setModel(F4DataModel, "F4DataModel");
			that.getView().getModel("F4DataModel").setProperty("/PlantF4", plant);

			var oPlntmodela = new sap.ui.model.json.JSONModel(F4DataModel);
			sap.ui.getCore().byId("olPlntidfrg").setModel(oPlntmodela);
			that._valueHelpDialogP.open(sInputValueP);

		},

		_handlePlntHelpClose: function () {
			this._valueHelpDialogP.destroy(true);
			this._valueHelpDialogP = undefined;

		},
		//Plant  Fragment Confirm Press event Start
		onPlantConfirm: function (oEvent) {

			//	this.oSelectedItemplt = oEvent.getParameters().selectedItem.mProperties.title;
			this.oSelectedItemplt = oEvent.getParameter("selectedItems");
			for (var a = 0; a < this.oSelectedItemplt.length; a++) {
				var defToken = new sap.m.Token({
					text: this.oSelectedItemplt[a].getTitle(),
					key: this.oSelectedItemplt[a].getTitle()
				});
				// Add created token to the Plant field
				this.getView().byId("InputValuePlant").addToken(defToken);
			}

			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialogP.destroy(true);
			this._valueHelpDialogP = undefined;
		},

		handleplantConfSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("olPlntidfrg");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, sQuery)
					//	new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sQuery)

				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},

		handleValueHelpBuname: function (oEvent) {

			var sInputValueBU = oEvent.getSource().getValue();
			if (!this._valueHelpDialogBU) {
				this._valueHelpDialogBU = sap.ui.xmlfragment(
					"YMM_P2P_StatusList.Fragment.BUname",
					this
				);
				this.getView().addDependent(this._valueHelpDialogBU);
			}
			var that = this;

			var oBunamModel = that.getView().byId("oMainTable").getModel("oPRframe1Model").getData();

			var oFIlterResults3 = oBunamModel.filter(function (x) {
				return x.Buname;

			});
			var oBumodel = new sap.ui.model.json.JSONModel(oFIlterResults3);
			sap.ui.getCore().byId("odBunameFrag").setModel(oBumodel);
			that._valueHelpDialogBU.open(sInputValueBU);

		},

		onBunameCancel: function () {
			this._valueHelpDialogBU.destroy(true);
			this._valueHelpDialogBU = undefined;

		},

		onBunameConfirm: function (oEvent) {
			/*	this.oSelectedBuname = oEvent.getParameters().selectedItem.mProperties.title;
				this.getView().byId("InputValueBuname").setValue(this.oSelectedBuname);
				oEvent.getSource().getBinding("items").filter([]);*/

			this.oSelectedBuname = oEvent.getParameter("selectedItems");
			for (var a = 0; a < this.oSelectedBuname.length; a++) {
				var defToken = new sap.m.Token({
					text: this.oSelectedBuname[a].getTitle(),
					key: this.oSelectedBuname[a].getTitle()
				});
				// Add created token to the Plant field
				this.getView().byId("InputValueBuname").addToken(defToken);
			}

			oEvent.getSource().getBinding("items").filter([]);

			this._valueHelpDialogBU.destroy(true);
			this._valueHelpDialogBU = undefined;
		},

		handleBunameConfSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("odBunameFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("Buname", sap.ui.model.FilterOperator.Contains, sQuery)

				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},

		handleValueHelpPrstatus: function (oEvent) {

			var sInputValueST = oEvent.getSource().getValue();
			if (!this._valueHelpDialogSt) {
				this._valueHelpDialogSt = sap.ui.xmlfragment(
					"YMM_P2P_StatusList.Fragment.PRStatus",
					this
				);
				this.getView().addDependent(this._valueHelpDialogSt);
			}
			var that = this;

			var oStatsModel = that.getView().byId("oMainTable").getModel("oPRframe1Model").getData();

			var oFIlterResults4 = oStatsModel.filter(function (x) {
				return x.Status;

			});
			var oStatmodel = new sap.ui.model.json.JSONModel(oFIlterResults4);
			sap.ui.getCore().byId("oidStatus").setModel(oStatmodel);
			that._valueHelpDialogSt.open(sInputValueST);

		},

		onStatusCancel: function () {
			this._valueHelpDialogSt.destroy(true);
			this._valueHelpDialogSt = undefined;

		},

		onStatusConfirm: function (oEvent) {
			this.oSelectedBuname = oEvent.getParameters().selectedItem.mProperties.title;
			this.getView().byId("InputValuePrstatus").setValue(this.oSelectedBuname);
			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialogSt.destroy(true);
			this._valueHelpDialogSt = undefined;
		},

		handleStatusConfSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oidStatus");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.Contains, sQuery)

				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},

		handleValueHelpITnonItrevstat: function (oEvent) {

			var sInputValueIT = oEvent.getSource().getValue();
			if (!this._valueHelpDialogIT) {
				this._valueHelpDialogIT = sap.ui.xmlfragment(
					"YMM_P2P_StatusList.Fragment.ITNReviewStatus",
					this
				);
				this.getView().addDependent(this._valueHelpDialogIT);
			}
			var that = this;

			var oITNStatsModel = that.getView().byId("oMainTable").getModel("oPRframe1Model").getData();

			var oFIlterResults5 = oITNStatsModel.filter(function (x) {
				return x.Status;

			});
			var oITStatmodel = new sap.ui.model.json.JSONModel(oFIlterResults5);
			sap.ui.getCore().byId("oidNonITstats").setModel(oITStatmodel);
			that._valueHelpDialogIT.open(sInputValueIT);

		},

		onITNonSCancel: function () {
			this._valueHelpDialogIT.destroy(true);
			this._valueHelpDialogIT = undefined;

		},

		onITNonStConfirm: function (oEvent) {
			this.oSelectedITnonstat = oEvent.getParameters().selectedItem.mProperties.title;
			this.getView().byId("InputValueItnonrevStas").setValue(this.oSelectedITnonstat);
			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialogIT.destroy(true);
			this._valueHelpDialogIT = undefined;
		},

		handleITNonSSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oidNonITstats");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("ItNonitStatus", sap.ui.model.FilterOperator.Contains, sQuery)

				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},

		handleValueHelpReqmanrevstat: function (oEvent) {

			var sInputValueRIT = oEvent.getSource().getValue();
			if (!this._valueHelpDialogRIT) {
				this._valueHelpDialogRIT = sap.ui.xmlfragment(
					"YMM_P2P_StatusList.Fragment.ManagerReviewStatus",
					this
				);
				this.getView().addDependent(this._valueHelpDialogRIT);
			}
			var that = this;

			var oReqStatsModel = that.getView().byId("oMainTable").getModel("oPRframe1Model").getData();

			var oFIlterResults6 = oReqStatsModel.filter(function (x) {
				return x.ReqMgrStatus;

			});
			var oReqTStatmodel = new sap.ui.model.json.JSONModel(oFIlterResults6);
			sap.ui.getCore().byId("oIdReqManStatFrag").setModel(oReqTStatmodel);
			that._valueHelpDialogRIT.open(sInputValueRIT);

		},

		onRemngrstatCancel: function () {
			this._valueHelpDialogRIT.destroy(true);

		},

		onRemngrstatConfirm: function (oEvent) {
			this.oSelectedIReqmanstat = oEvent.getParameters().selectedItem.mProperties.title;
			this.getView().byId("InputValueReqMaRestat").setValue(this.oSelectedIReqmanstat);
			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialogRIT.destroy(true);
			this._valueHelpDialogRIT = undefined;
		},

		handleRemngrstatSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("oIdReqManStatFrag");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("ReqMgrStatus", sap.ui.model.FilterOperator.Contains, sQuery)

				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},

		handleValueHelpReqCategry: function (oEvent) {

			var sInputValueRC = oEvent.getSource().getValue();
			if (!this._valueHelpDialogRC) {
				this._valueHelpDialogRC = sap.ui.xmlfragment(
					"YMM_P2P_StatusList.Fragment.ReqCategory",
					this
				);
				this.getView().addDependent(this._valueHelpDialogRC);
			}
			var that = this;

			var oReqstcatmodel = that.oPlantmodelfilterd;
			var obj = {};
			for (var i = 0, len = oReqstcatmodel.length; i < len; i++)
				obj[oReqstcatmodel[i]['Reqcategory']] = oReqstcatmodel[i];
			var oReqcate = new Array();
			for (var key in obj)

				oReqcate.push(obj[key]);

			var oReqcateF4DataModel = new sap.ui.model.json.JSONModel();
			that.getView().setModel(oReqcateF4DataModel, "oReqcateF4DataModel");
			that.getView().getModel("oReqcateF4DataModel").setProperty("/oReqcateF4", oReqcate);

			/*var ReqcateFF4Id = that.getView().byId("InputValueReqcatry");
								for (var a = 0; a < oReqcate.length; a++) {
									var defToken = new sap.m.Token({
										text: oReqcate[a].Reqcategory,
										key: oReqcate[a].Reqcategory
									});
			
									ReqcateFF4Id.addToken(defToken);
								}*/

			/*	var oReqcateModel = that.getView().byId("oMainTable").getModel("oPRframe1Model").getData();

				var oFIlterResults7 = oReqcateModel.filter(function (x) {
					return x.Reqcategory;

				});*/
			var oReqcatmodel = new sap.ui.model.json.JSONModel(oReqcateF4DataModel);
			sap.ui.getCore().byId("oReqCategryfrag").setModel(oReqcatmodel);
			that._valueHelpDialogRC.open(sInputValueRC);

		},

		onReqcateCancel: function () {
			this._valueHelpDialogRC.destroy(true);
			this._valueHelpDialogRC = undefined;

		},

		onReqcateConfirm: function (oEvent) {

			//	this.oSelectedIReqcat = oEvent.getParameters().selectedItem.mProperties.title;
			//		this.getView().byId("InputValueReqcatry").setValue(this.oSelectedIReqcat);
			this.oSelectedIReqcat = oEvent.getParameter("selectedItems");
			for (var a = 0; a < this.oSelectedIReqcat.length; a++) {
				var defToken = new sap.m.Token({
					text: this.oSelectedIReqcat[a].getTitle(),
					key: this.oSelectedIReqcat[a].getTitle()
				});
				// Add created token to the Plant field
				this.getView().byId("InputValueReqcatry").addToken(defToken);
			}

			oEvent.getSource().getBinding("items").filter([]);
			this._valueHelpDialogRC.destroy(true);
			this._valueHelpDialogRC = undefined;
		},

		handleReqcateConfSearch_Press: function (oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getParameter("value");
			var list = sap.ui.getCore().byId("InputValueReqcatry");
			var binding = list.getBinding("items");
			if (sQuery && sQuery.length > 0) {

				binding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("Reqcategory", sap.ui.model.FilterOperator.Contains, sQuery)

				], false)]);

			} else if (!(sQuery && sQuery.length > 0)) {
				binding.filter([]);
			}

			binding.filter(aFilters, "Application");

		},

		onFilterChange2: function (oEvt, oRecords) {
			/* this.oRecrds = this.getView().byId("idRecords").getSelectedkey();*/
			var url = "/sap/opu/odata/sap/YMM_PR_FIORI_LOG_STATUS_SRV";
			var that = this;
			that.oRecrds = oEvt;
			that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

			var path = "/ymm_fiori_setSet?$top=" + that.oRecrds;
			/*	this.oBusyIn = new sap.m.BusyDialog();
				this.oBusyIn.open(true);*/

			that.oDataModel.read(path, null, null, false, function (oData, oResponse) {
				var oObjemodel = oData.results;

				/*var oObjemodel = oFIlterResults.filter(function (x) {
					return x.Status == "Pending With manager";
				});*/

				var obj = {};

				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['Plant']] = oObjemodel[i];

				var plant = new Array();
				for (var key in obj)
					plant.push(obj[key]);

				var F4DataModel = new sap.ui.model.json.JSONModel();
				that.getView().setModel(F4DataModel, "F4DataModel");
				that.getView().getModel("F4DataModel").setProperty("/PlantF4", plant);
				var PlantF4Id = that.getView().byId("InputValuePlant");

				for (var a = 0; a < plant.length; a++) {
					var defToken = new sap.m.Token({
						text: plant[a].Plant,
						key: plant[a].Plant
					});
					// Add created token to the Plant field
					PlantF4Id.addToken(defToken);
				}

				var obj = {};

				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['Prnumber']] = oObjemodel[i];

				var oPrnumber = new Array();
				for (var key in obj)
					oPrnumber.push(obj[key]);

				var PrF4DataModel = new sap.ui.model.json.JSONModel();
				that.getView().setModel(PrF4DataModel, "PrF4DataModel");
				that.getView().getModel("PrF4DataModel").setProperty("/PrnumsF4", oPrnumber);

				var obj = {};
				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['Buname']] = oObjemodel[i];
				var oBusUniname = new Array();
				for (var key in obj)
					oBusUniname.push(obj[key]);

				var BunameF4DataModel = new sap.ui.model.json.JSONModel();
				that.getView().setModel(BunameF4DataModel, "BunameF4DataModel");
				that.getView().getModel("BunameF4DataModel").setProperty("/BunamesF4", oBusUniname);
				var BunamesF4Id = that.getView().byId("InputValueBuname");

				for (var a = 0; a < oBusUniname.length; a++) {
					var defToken = new sap.m.Token({
						text: oBusUniname[a].Buname,
						key: oBusUniname[a].Buname
					});
					// Add created token to the Plant field
					BunamesF4Id.addToken(defToken);
				}

				var obj = {};
				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['Status']] = oObjemodel[i];
				var oStatus = new Array();
				for (var key in obj)
					if (key == "") {
						/*oStatus.pop();*/
					} else {

						oStatus.push(obj[key]);
					}

				var oStatusF4DataModel = new sap.ui.model.json.JSONModel();
				that.getView().setModel(oStatusF4DataModel, "oStatusF4DataModel");

				//	var termmanager = "manager";
				//	var omanagername = oStatus.filter(x => new RegExp(termmanager, 'i').test(x.Status));
				//	var omanagername1 = "";
				/*	oStatus.find(function (value, index) {
							if (value.Status.indexOf(termmanager)!=-1){
							
								omanagername1 =value.Status;
							}
						});*/

				that.getView().getModel("oStatusF4DataModel").setProperty("/StatusF4", oStatus);

				var obj = {};
				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['ItNonitStatus']] = oObjemodel[i];

				var oItnonStatus = new Array();
				for (var key in obj)
					if (key == "") {
						oItnonStatus.pop();
					} else {

						oItnonStatus.push(obj[key]);
					}

				var oItnonStatusF4DataModel = new sap.ui.model.json.JSONModel();
				that.getView().setModel(oItnonStatusF4DataModel, "oItnonStatusF4DataModel");
				that.getView().getModel("oItnonStatusF4DataModel").setProperty("/ItnonStatusF4", oItnonStatus);

				var obj = {};
				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['ReqMgrStatus']] = oObjemodel[i];
				var oReqmangStatus = new Array();
				for (var key in obj)
					if (key == "") {
						oReqmangStatus.pop();
					} else {

						oReqmangStatus.push(obj[key]);
					}

				var oReqmangStatusF4DataModel = new sap.ui.model.json.JSONModel();
				that.getView().setModel(oReqmangStatusF4DataModel, "oReqmangStatusF4DataModel");
				that.getView().getModel("oReqmangStatusF4DataModel").setProperty("/ReqmangStatusF4", oReqmangStatus);

				var obj = {};
				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['Reqcategory']] = oObjemodel[i];
				var oReqcate = new Array();
				for (var key in obj)

					oReqcate.push(obj[key]);

				var oReqcateF4DataModel = new sap.ui.model.json.JSONModel();
				that.getView().setModel(oReqcateF4DataModel, "oReqcateF4DataModel");
				that.getView().getModel("oReqcateF4DataModel").setProperty("/oReqcateF4", oReqcate);

				var ReqcateFF4Id = that.getView().byId("InputValueReqcatry");

				for (var a = 0; a < oReqcate.length; a++) {
					var defToken = new sap.m.Token({
						text: oReqcate[a].Reqcategory,
						key: oReqcate[a].Reqcategory
					});
					// Add created token to the Reqcategory field
					ReqcateFF4Id.addToken(defToken);
				}

				var oModel = new sap.ui.model.json.JSONModel(oObjemodel);
				oModel.setSizeLimit(200000);

				that.getView().byId("oMainTable").setModel(oModel, "oPRframe1Model");

				that.getView().byId("idRecords").setSelectedKey(that.oRecrds);

				that.getView().byId("Items").setText("Items(" + "" + oObjemodel.length + "" + ")");

			}, function (error) {

			});

			// add filter for search
			/*	var aFilters = [];

				var Prnum = this.getView().byId("InputValuePrno").getValue();
				if (Prnum != "") {
					var filter1 = new Filter("Prnumber", sap.ui.model.FilterOperator.EQ, Prnum);
					aFilters.push(filter1);
				}
				var oPlant = this.getView().byId("InputValuePlant").getTokens();
				for (var a = 0; a < oPlant.length; a++) {
					var filter2 = new Filter("Plant", sap.ui.model.FilterOperator.EQ, oPlant[a].getText());
					aFilters.push(filter2);
				}

				var BUname = this.getView().byId("InputValueBuname").getTokens();
				for (var a = 0; a < BUname.length; a++) {
					var filter3 = new Filter("Buname", sap.ui.model.FilterOperator.EQ, BUname[a].getText());
					aFilters.push(filter3);
				}

				var oStatus = this.getView().byId("InputValuePrstatus").getValue();
				if (oStatus != "") {
					var filter4 = new Filter("Status", sap.ui.model.FilterOperator.EQ, oStatus);
					aFilters.push(filter4);
				}

				var ItnonStats = this.getView().byId("InputValueItnonrevStas").getValue();
				if (ItnonStats != "") {
					var filter5 = new Filter("ItNonitStatus", sap.ui.model.FilterOperator.EQ, ItnonStats);
					aFilters.push(filter5);
				}

				var oReqmrgStat = this.getView().byId("InputValueReqMaRestat").getValue();
				if (oReqmrgStat != "") {
					var filter6 = new Filter("ReqMgrStatus", sap.ui.model.FilterOperator.EQ, oReqmrgStat);
					aFilters.push(filter6);
				}

				var oReqCategory = this.getView().byId("InputValueReqcatry").getTokens();

				for (var a = 0; a < oReqCategory.length; a++) {
					var filter7 = new Filter("Reqcategory", sap.ui.model.FilterOperator.EQ, oReqCategory[a].getText());
					aFilters.push(filter7);
				}

		
				var table = this.getView().byId("oMainTable");
				var binding = table.getBinding("rows");
				this.oBab = binding.filter(aFilters, "Application");

				this.getView().byId("Items").setText("Items(" + "" + binding.aIndices.length + "" + ")");*/
		},

		onFilterChange: function (oEvt) {
			debugger
			var that = this;
			// add filter for search
			var aFilters = [];

			var Prnum = this.getView().byId("InputValuePrno").getValue();
			if (Prnum != "") {
				var filter1 = new Filter("Prnumber", sap.ui.model.FilterOperator.EQ, Prnum);
				aFilters.push(filter1);
			}
			var oPlant = this.getView().byId("InputValuePlant").getTokens();
			for (var a = 0; a < oPlant.length; a++) {
				var filter2 = new Filter("Plant", sap.ui.model.FilterOperator.EQ, oPlant[a].getText());
				aFilters.push(filter2);
			}
			var BUname = this.getView().byId("InputValueBuname").getTokens();
			for (var a = 0; a < BUname.length; a++) {
				var filter3 = new Filter("Buname", sap.ui.model.FilterOperator.EQ, BUname[a].getText());
				aFilters.push(filter3);
			}

			var oStatus = this.getView().byId("InputValuePrstatus").getValue();
			if (oStatus != "") {
				var filter4 = new Filter("Status", sap.ui.model.FilterOperator.EQ, oStatus);
				aFilters.push(filter4);
			}

			var ItnonStats = this.getView().byId("InputValueItnonrevStas").getValue();
			if (ItnonStats != "") {
				var filter5 = new Filter("ItNonitStatus", sap.ui.model.FilterOperator.EQ, ItnonStats);
				aFilters.push(filter5);
			}

			var oReqmrgStat = this.getView().byId("InputValueReqMaRestat").getValue();
			if (oReqmrgStat != "") {
				var filter6 = new Filter("ReqMgrStatus", sap.ui.model.FilterOperator.EQ, oReqmrgStat);
				aFilters.push(filter6);
			}

			var oReqCategory = this.getView().byId("InputValueReqcatry").getTokens();

			for (var a = 0; a < oReqCategory.length; a++) {
				var filter7 = new Filter("Reqcategory", sap.ui.model.FilterOperator.EQ, oReqCategory[a].getText());
				aFilters.push(filter7);
			}

			// update table binding
			var table = this.getView().byId("oMainTable");
			var binding = table.getBinding("rows");
			this.oBab = binding.filter(aFilters, "Application");

			this.getView().byId("Items").setText("Items(" + "" + binding.aIndices.length + "" + ")");
		},

		onClearAll: function () {
			this.getView().byId("idRecords").setSelectedKey("0");
			this.getView().byId("InputValuePrno").setValue("");
			this.getView().byId("InputValuePlant").destroyTokens(true);
			this.getView().byId("InputValuePlant").setValue("");
			this.getView().byId("InputValueBuname").destroyTokens(true);
			this.getView().byId("InputValueBuname").setValue("");
			this.getView().byId("InputValuePrstatus").setValue("");
			this.getView().byId("InputValueItnonrevStas").setValue("");
			this.getView().byId("InputValueReqMaRestat").setValue("");
			this.getView().byId("InputValueReqcatry").destroyTokens(true);
			this.getView().byId("InputValueReqcatry").setValue("");

			this.onClearAllFilterChange();

		},
		onClearAllFilterChange: function () {

			var url = "/sap/opu/odata/sap/YMM_PR_FIORI_LOG_STATUS_SRV";
			var that = this;
			that.oRecrds = this.getView().byId("idRecords").getSelectedKey();

			that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

			var path = "/ymm_fiori_setSet?$top=" + that.oRecrds;
			that.oDataModel.read(path, null, null, false, function (oData, oResponse) {
				var oObjemodel = oData.results;

				var obj = {};

				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['Plant']] = oObjemodel[i];

				var plant = new Array();
				for (var key in obj)
					plant.push(obj[key]);

				var F4DataModel = new sap.ui.model.json.JSONModel();
				that.getView().setModel(F4DataModel, "F4DataModel");
				that.getView().getModel("F4DataModel").setProperty("/PlantF4", plant);
				var obj = {};

				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['Prnumber']] = oObjemodel[i];

				var oPrnumber = new Array();
				for (var key in obj)
					oPrnumber.push(obj[key]);

				var PrF4DataModel = new sap.ui.model.json.JSONModel();
				that.getView().setModel(PrF4DataModel, "PrF4DataModel");
				that.getView().getModel("PrF4DataModel").setProperty("/PrnumsF4", oPrnumber);

				var obj = {};
				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['Buname']] = oObjemodel[i];
				var oBusUniname = new Array();
				for (var key in obj)
					oBusUniname.push(obj[key]);

				var BunameF4DataModel = new sap.ui.model.json.JSONModel();
				that.getView().setModel(BunameF4DataModel, "BunameF4DataModel");
				that.getView().getModel("BunameF4DataModel").setProperty("/BunamesF4", oBusUniname);

				var obj = {};
				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['Status']] = oObjemodel[i];
				var oStatus = new Array();
				for (var key in obj)
					if (key == "") {
						/*oStatus.pop();*/
					} else {

						oStatus.push(obj[key]);
					}

				var oStatusF4DataModel = new sap.ui.model.json.JSONModel();
				that.getView().setModel(oStatusF4DataModel, "oStatusF4DataModel");
				that.getView().getModel("oStatusF4DataModel").setProperty("/StatusF4", oStatus);

				var obj = {};
				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['ItNonitStatus']] = oObjemodel[i];

				var oItnonStatus = new Array();
				for (var key in obj)
					if (key == "") {
						oItnonStatus.pop();
					} else {

						oItnonStatus.push(obj[key]);
					}

				var oItnonStatusF4DataModel = new sap.ui.model.json.JSONModel();
				that.getView().setModel(oItnonStatusF4DataModel, "oItnonStatusF4DataModel");
				that.getView().getModel("oItnonStatusF4DataModel").setProperty("/ItnonStatusF4", oItnonStatus);

				var obj = {};
				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['ReqMgrStatus']] = oObjemodel[i];
				var oReqmangStatus = new Array();
				for (var key in obj)
					if (key == "") {
						oReqmangStatus.pop();
					} else {

						oReqmangStatus.push(obj[key]);
					}

				var oReqmangStatusF4DataModel = new sap.ui.model.json.JSONModel();
				that.getView().setModel(oReqmangStatusF4DataModel, "oReqmangStatusF4DataModel");
				that.getView().getModel("oReqmangStatusF4DataModel").setProperty("/ReqmangStatusF4", oReqmangStatus);

				var obj = {};
				for (var i = 0, len = oObjemodel.length; i < len; i++)
					obj[oObjemodel[i]['Reqcategory']] = oObjemodel[i];
				var oReqcate = new Array();
				for (var key in obj)

					oReqcate.push(obj[key]);

				var oReqcateF4DataModel = new sap.ui.model.json.JSONModel();
				that.getView().setModel(oReqcateF4DataModel, "oReqcateF4DataModel");
				that.getView().getModel("oReqcateF4DataModel").setProperty("/oReqcateF4", oReqcate);
				var oModel = new sap.ui.model.json.JSONModel(oObjemodel);

				oModel.setSizeLimit(oObjemodel.length);

				that.getView().byId("oMainTable").setModel(oModel, "oPRframe1Model");

				that.getView().byId("idRecords").setSelectedKey(that.oRecrds);

				that.getView().byId("Items").setText("Items(" + "" + oObjemodel.length + "" + ")");

			}, function (error) {

			});

			// add filter for search
			/*	var aFilters = [];

				var Prnum = this.getView().byId("InputValuePrno").getValue();
				if (Prnum != "") {
					var filter1 = new Filter("Prnumber", sap.ui.model.FilterOperator.EQ, Prnum);
					aFilters.push(filter1);
				}
				var oPlant = this.getView().byId("InputValuePlant").getTokens();
				for (var a = 0; a < oPlant.length; a++) {
					var filter2 = new Filter("Plant", sap.ui.model.FilterOperator.EQ, oPlant[a].getText());
					aFilters.push(filter2);
				}

				var BUname = this.getView().byId("InputValueBuname").getTokens();
				for (var a = 0; a < BUname.length; a++) {
					var filter3 = new Filter("Buname", sap.ui.model.FilterOperator.EQ, BUname[a].getText());
					aFilters.push(filter3);
				}

				var oStatus = this.getView().byId("InputValuePrstatus").getValue();
				if (oStatus != "") {
					var filter4 = new Filter("Status", sap.ui.model.FilterOperator.EQ, oStatus);
					aFilters.push(filter4);
				}

				var ItnonStats = this.getView().byId("InputValueItnonrevStas").getValue();
				if (ItnonStats != "") {
					var filter5 = new Filter("ItNonitStatus", sap.ui.model.FilterOperator.EQ, ItnonStats);
					aFilters.push(filter5);
				}

				var oReqmrgStat = this.getView().byId("InputValueReqMaRestat").getValue();
				if (oReqmrgStat != "") {
					var filter6 = new Filter("ReqMgrStatus", sap.ui.model.FilterOperator.EQ, oReqmrgStat);
					aFilters.push(filter6);
				}

				var oReqCategory = this.getView().byId("InputValueReqcatry").getTokens();

				for (var a = 0; a < oReqCategory.length; a++) {
					var filter7 = new Filter("Reqcategory", sap.ui.model.FilterOperator.EQ, oReqCategory[a].getText());
					aFilters.push(filter7);
				}

		
				var table = this.getView().byId("oMainTable");
				var binding = table.getBinding("rows");
				this.oBab = binding.filter(aFilters, "Application");

				this.getView().byId("Items").setText("Items(" + "" + binding.aIndices.length + "" + ")");*/
		},
		onLinkPress: function (oEvt) {

			var oSelectedPr = oEvt.oSource.getText();
			var that = this;
			that.Loggeduser;

			var oCrossAppNavigator = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService && sap.ushell.Container.getService(
				"CrossApplicationNavigation");
			oCrossAppNavigator.isIntentSupported(["P2PEdit-display"])
				.done(function (aResponses) {

				})
				.fail(function () {
					new sap.m.MessageToast("Provide corresponding intent to navigate");
				});
			// generate the Hash to display P2PEdit
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "P2PEdit",
					/*	semanticObject: "P2P_Status"*/
					action: "display"
				},
				params: {
					"PurReq": oSelectedPr,
					"LoggedUser": that.Loggeduser,
					"PreviousIntent": window.hasher.getHash().split("-")[0]

				}
			})) || "";
			//Generate a  URL for the second application
			//var url = window.location.href.split('#')[0] + hash;
			//Navigate to second app
			//	sap.m.URLHelper.redirect(url, true);
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});

		},

		ExporttoExcellsheet: function () {

			//	var Context = this.getView().byId("oMainTable").getAggregation("rows");
			//	 var Context = this.getView().byId("oMainTable").getModel("oPRframe1Model").getData();
			var Context = this.getView().byId("oMainTable").getBinding("rows").getContexts();
			if (Context.length == 0) {
				sap.m.MessageBox.error("No data available to export");
				return;
			} else {
				var rows = Context.map(function (oEvent) {
					return oEvent.getObject();
					//	return oEvent;
				});
				this.JSONToCSVConvertor(rows, "", true);
			}
		},
		JSONToCSVConvertor: function (JSONData, ReportTitle, ShowLabel) {
			//		var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
			var arrData = JSONData;
			var CSV = "";
			if (ShowLabel) {
				var row = "";
				row = row.slice(0, -1);
			}

			row += "Purchase Requisition" + ",";
			row += "Purchase Order" + ",";
			row += "PR Item" + ",";
			row += "Plant" + ",";
			row += "Plant Name" + ",";
			row += "BU Name" + ",";
			row += "Parked Status" + ",";
			row += "IT/NON IT Status" + ",";
			row += "Manager Review Status" + ",";
			row += "Expense Type" + ",";
			row += "Item Type" + ",";
			row += "Quantity" + ",";
			row += "Price" + ",";
			row += "Currency" + ",";
			row += "Net Value" + ",";
			row += "Cost Center" + ",";
			row += "WBS Element" + ",";
			row += "Created By" + ",";
			row += "Created Date" + ",";
			row += "Req.Category" + ",";
			row += "Action By" + ",";
			row += "Action Date" + ",";
			row += "Buyer Note" + ",";
			row += "Buyer Remarks" + ",";
			row += "IT/NonIT Action By" + ",";
			row += "IT/NonIT Action Date" + ",";
			row += "IT/NonIT Note" + ",";
			row += "IT/NonIT Remarks" + ",";
			row += "Manager Action By" + ",";
			row += "Manager Action Date" + ",";
			row += "Manager Action Note" + ",";
			row += "Manager Remarks" + ",";

			CSV += row + '\r\n';
			//loop is to extract each row
			for (var i = 0; i < arrData.length; i++) {

				var row = "";
				var Createddate;
				if (arrData[i].Createddate != null) {

					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "dd/MM/yyyy"
					});
					var Createddate1 = oDateFormat.format(new Date(arrData[i].Createddate));

				}

				var Actiondate;
				if (arrData[i].Actiondate != null) {

					var oDateFormat1a = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "dd/MM/yyyy"
					});
					var Actiondate = oDateFormat1a.format(new Date(arrData[i].Actiondate));

				}
				var ItNonitActionDate;
				if (arrData[i].ItNonitActionDate != null) {

					var oDateFormat1b = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "dd/MM/yyyy"
					});
					var ItNonitActionDate = oDateFormat1b.format(new Date(arrData[i].ItNonitActionDate));

				}
				var ReqMgrActionDate;
				if (arrData[i].ReqMgrActionDate != null) {

					var oDateFormat1c = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "dd/MM/yyyy"
					});
					var ReqMgrActionDate = oDateFormat1c.format(new Date(arrData[i].ReqMgrActionDate));

				}

				row += '"' + arrData[i].Prnumber + '","' + arrData[i].Ponumber + '","' + arrData[i].Pritem + '","' + arrData[i].Plant +
					'","' + arrData[i].Name1 + '","' + arrData[i].Buname + '","' +
					arrData[i].Status + '","' +
					arrData[i].ItNonitStatus + '","' + arrData[i].ReqMgrStatus + '","' + arrData[i].Expensetype + '","' +
					arrData[i].Itemtype + '","' + arrData[i].Qty + '","' + arrData[i].Price + '","' + arrData[i].Currency + '","' + arrData[i].Netvalue +
					'","' + arrData[i].Costcenter + '","' + arrData[i].Wbselement + '","' + arrData[i].Createdby + '","' + (Createddate ||
						"") +
					'","' + arrData[i].Reqcategory + '","' + arrData[i].Actionby + '","' + (Actiondate || "") + '","' + arrData[i].Buyernote +
					'","' + arrData[i].Buyerremarks + '","' + arrData[i].ItNonitActionBy + '","' + (ItNonitActionDate || "") + '","' +
					arrData[i].ItNonitNote +
					'","' + arrData[i].ItNonitRemarks + '","' + arrData[i].ReqMgrActionBy + '","' + (ReqMgrActionDate || "") + '","' +
					arrData[i].ReqMgrActionNote +
					'","' + arrData[i].ReqMgrActionRemarks +
					'",';
				//}
				row.slice(1, row.length);
				CSV += row + '\r\n';
			}
			if (CSV == "") {
				/*	alert("Invalid data");*/
				return;
			}
			var fileName = "PR Status List Report";
			fileName += ReportTitle.replace(/ /g, "_");
			// Initialize file format you want csv or xls

			var blob = new Blob(["\ufeff" + CSV], {
				type: "text/csv;charset=utf-8,"
			});
			if (sap.ui.Device.browser.name === "ie" || sap.ui.Device.browser.name === "ed") { // IE 10+ , Edge (IE 12+)
				navigator.msSaveBlob(blob, "Report.csv");
			} else {
				var uri = 'data:text/csv;charset=utf-8,' + "\ufeff" + encodeURIComponent(CSV); //'data:application/vnd.ms-excel,' + escape(CSV);
				var link = document.createElement("a");

				link.href = uri;
				link.style = "visibility:hidden";
				link.download = fileName + ".csv";
				document.body.appendChild(link);
				link.click();
				document.body.removeChild(link);
			}

		},
		onAfterRendering: function () {

			var that = this;
			var url = "/sap/opu/odata/sap/YMM_PR_FIORI_LOG_STATUS_SRV";

			that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);

			var path = "/ymm_fiori_setSet?$top=";
			that.oDataModel.read(path, null, null, false, function (oData, oResponse) {
				that.oPlantmodelfilterd = oData.results;
			});

			/*var obj = {};

			for (var i = 0, len = oPlntModel.length; i < len; i++)
				obj[oPlntModel[i]['Plant']] = oPlntModel[i];

			var plant = new Array();
			for (var key in obj)
				plant.push(obj[key]);

			var F4DataModel = new sap.ui.model.json.JSONModel();
			that.getView().setModel(F4DataModel, "F4DataModel");
			that.getView().getModel("F4DataModel").setProperty("/PlantF4", plant);*/

			/*	var url = "/sap/opu/odata/sap/YMM_PR_FIORI_LOG_STATUS_SRV";
				var that = this;
				that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);
				var path = "/ymm_fiori_setSet";
				that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

					var oObjemodel = oData.results;

					var oModel = new sap.ui.model.json.JSONModel(oObjemodel);
					oModel.setSizeLimit(200000);

					that.getView().byId("oMainTable").setModel(oModel, "oPRframe1Model");

					that.getView().byId("Items").setText("Items(" + "" + oObjemodel.length + "" + ")");
					var obj = {};

					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Plant']] = oObjemodel[i];

					var plant = new Array();
					for (var key in obj)
						plant.push(obj[key]);

					var F4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(F4DataModel, "F4DataModel");
					that.getView().getModel("F4DataModel").setProperty("/PlantF4", plant);

					var obj = {};

					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Prnumber']] = oObjemodel[i];

					var oPrnumber = new Array();
					for (var key in obj)
						oPrnumber.push(obj[key]);

					var PrF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(PrF4DataModel, "PrF4DataModel");
					that.getView().getModel("PrF4DataModel").setProperty("/PrnumsF4", oPrnumber);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Buname']] = oObjemodel[i];
					var oBusUniname = new Array();
					for (var key in obj)
						oBusUniname.push(obj[key]);

					var BunameF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(BunameF4DataModel, "BunameF4DataModel");
					that.getView().getModel("BunameF4DataModel").setProperty("/BunamesF4", oBusUniname);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Status']] = oObjemodel[i];
					var oStatus = new Array();
					for (var key in obj)
						if (key == "") {
							oStatus.pop();
						} else {

							oStatus.push(obj[key]);
						}

					var oStatusF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oStatusF4DataModel, "oStatusF4DataModel");
					that.getView().getModel("oStatusF4DataModel").setProperty("/StatusF4", oStatus);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['ItNonitStatus']] = oObjemodel[i];

					var oItnonStatus = new Array();
					for (var key in obj)
						if (key == "") {
							oItnonStatus.pop();
						} else {

							oItnonStatus.push(obj[key]);
						}

					var oItnonStatusF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oItnonStatusF4DataModel, "oItnonStatusF4DataModel");
					that.getView().getModel("oItnonStatusF4DataModel").setProperty("/ItnonStatusF4", oItnonStatus);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['ReqMgrStatus']] = oObjemodel[i];
					var oReqmangStatus = new Array();
					for (var key in obj)
						if (key == "") {
							oReqmangStatus.pop();
						} else {

							oReqmangStatus.push(obj[key]);
						}

					var oReqmangStatusF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oReqmangStatusF4DataModel, "oReqmangStatusF4DataModel");
					that.getView().getModel("oReqmangStatusF4DataModel").setProperty("/ReqmangStatusF4", oReqmangStatus);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Reqcategory']] = oObjemodel[i];
					var oReqcate = new Array();
					for (var key in obj)
					
						oReqcate.push(obj[key]);

					var oReqcateF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oReqcateF4DataModel, "oReqcateF4DataModel");
					that.getView().getModel("oReqcateF4DataModel").setProperty("/oReqcateF4", oReqcate);

				});*/

		},
		onRecordsclick: function () {
			this.getView().byId("InputValuePrno").setValue("");
			this.getView().byId("InputValuePlant").destroyTokens(true);
			this.getView().byId("InputValueBuname").destroyTokens(true);
			this.getView().byId("InputValuePrstatus").setValue("");
			this.getView().byId("InputValueItnonrevStas").setValue("");
			this.getView().byId("InputValueReqMaRestat").setValue("");
			this.getView().byId("InputValueReqcatry").destroyTokens(true);
			var that = this;

			if (that.oFIlterResultsManager.length > 0) {

				var url = "/sap/opu/odata/sap/YMM_PR_FIORI_LOG_STATUS_SRV";

				that.oRecrds = that.getView().byId("idRecords").getSelectedKey();
				that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);
				var path = "/ymm_fiori_setSet?$top=" + that.oRecrds;
				that.oDataModel.read(path, null, null, false, function (oData, oResponse) {
					var oObjemodel = oData.results;

					/*	var oObjemodel = oFIlterResults.filter(function (x) {
							return x.Status == "Pending With manager";
						});*/

					var obj = {};

					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Plant']] = oObjemodel[i];

					var plant = new Array();
					for (var key in obj)
						plant.push(obj[key]);

					var F4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(F4DataModel, "F4DataModel");
					that.getView().getModel("F4DataModel").setProperty("/PlantF4", plant);
					var PlantF4Id = that.getView().byId("InputValuePlant");

					for (var a = 0; a < plant.length; a++) {
						var defToken = new sap.m.Token({
							text: plant[a].Plant,
							key: plant[a].Plant
						});
						// Add created token to the Plant field
						PlantF4Id.addToken(defToken);
					}

					var obj = {};

					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Prnumber']] = oObjemodel[i];

					var oPrnumber = new Array();
					for (var key in obj)
						oPrnumber.push(obj[key]);

					var PrF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(PrF4DataModel, "PrF4DataModel");
					that.getView().getModel("PrF4DataModel").setProperty("/PrnumsF4", oPrnumber);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Buname']] = oObjemodel[i];
					var oBusUniname = new Array();
					for (var key in obj)
						oBusUniname.push(obj[key]);

					var BunameF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(BunameF4DataModel, "BunameF4DataModel");
					that.getView().getModel("BunameF4DataModel").setProperty("/BunamesF4", oBusUniname);
					var BunamesF4Id = that.getView().byId("InputValueBuname");

					for (var a = 0; a < oBusUniname.length; a++) {
						var defToken = new sap.m.Token({
							text: oBusUniname[a].Buname,
							key: oBusUniname[a].Buname
						});
						// Add created token to the Plant field
						BunamesF4Id.addToken(defToken);
					}

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Status']] = oObjemodel[i];
					var oStatus = new Array();
					for (var key in obj)
						if (key == "") {
							/*oStatus.pop();*/
						} else {

							oStatus.push(obj[key]);
						}

					var oStatusF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oStatusF4DataModel, "oStatusF4DataModel");

					//	var termmanager = "manager";
					//	var omanagername = oStatus.filter(x => new RegExp(termmanager, 'i').test(x.Status));
					//	var omanagername1 = "";
					/*	oStatus.find(function (value, index) {
								if (value.Status.indexOf(termmanager)!=-1){
								
									omanagername1 =value.Status;
								}
							});*/

					/*	var termmanager = oStatus.filter(function (x) {
							return x.Status === "Pending With manager";
						});

						var omanagername1 = termmanager[0].Status;

						that.getView().byId("InputValuePrstatus").setValue(omanagername1);*/

					that.getView().getModel("oStatusF4DataModel").setProperty("/StatusF4", oStatus);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['ItNonitStatus']] = oObjemodel[i];

					var oItnonStatus = new Array();
					for (var key in obj)
						if (key == "") {
							oItnonStatus.pop();
						} else {

							oItnonStatus.push(obj[key]);
						}

					var oItnonStatusF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oItnonStatusF4DataModel, "oItnonStatusF4DataModel");
					that.getView().getModel("oItnonStatusF4DataModel").setProperty("/ItnonStatusF4", oItnonStatus);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['ReqMgrStatus']] = oObjemodel[i];
					var oReqmangStatus = new Array();
					for (var key in obj)
						if (key == "") {
							oReqmangStatus.pop();
						} else {

							oReqmangStatus.push(obj[key]);
						}

					var oReqmangStatusF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oReqmangStatusF4DataModel, "oReqmangStatusF4DataModel");
					that.getView().getModel("oReqmangStatusF4DataModel").setProperty("/ReqmangStatusF4", oReqmangStatus);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Reqcategory']] = oObjemodel[i];
					var oReqcate = new Array();
					for (var key in obj)

						oReqcate.push(obj[key]);

					var oReqcateF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oReqcateF4DataModel, "oReqcateF4DataModel");
					that.getView().getModel("oReqcateF4DataModel").setProperty("/oReqcateF4", oReqcate);

					var ReqcateFF4Id = that.getView().byId("InputValueReqcatry");

					for (var a = 0; a < oReqcate.length; a++) {
						var defToken = new sap.m.Token({
							text: oReqcate[a].Reqcategory,
							key: oReqcate[a].Reqcategory
						});
						// Add created token to the Reqcategory field
						ReqcateFF4Id.addToken(defToken);
					}

					/*	var oFIlterResults = oData.results;

							var oObjemodel = oFIlterResults.filter(function (x) {
								return x.Status == "Pending With manager";
							});*/

					var oModel = new sap.ui.model.json.JSONModel(oObjemodel);
					oModel.setSizeLimit(200000);

					that.getView().byId("oMainTable").setModel(oModel, "oPRframe1Model");

					that.getView().byId("idRecords").setSelectedKey(that.oRecrds);

					that.getView().byId("Items").setText("Items(" + "" + oObjemodel.length + "" + ")");

				}, function (error) {

				});

			} else if (that.oFIlterResultsHam.length > 0) {

				var url = "/sap/opu/odata/sap/YMM_PR_FIORI_LOG_STATUS_SRV";

				that.oRecrds = that.getView().byId("idRecords").getSelectedKey();
				that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);
				var path = "/ymm_fiori_setSet?$top=" + that.oRecrds;
				that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

					var oObjemodel = oData.results;

					var obj = {};

					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Plant']] = oObjemodel[i];

					var plant = new Array();
					for (var key in obj)
						plant.push(obj[key]);

					var F4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(F4DataModel, "F4DataModel");
					that.getView().getModel("F4DataModel").setProperty("/PlantF4", plant);
					var PlantF4Id = that.getView().byId("InputValuePlant");

					for (var a = 0; a < plant.length; a++) {
						var defToken = new sap.m.Token({
							text: plant[a].Plant,
							key: plant[a].Plant
						});
						// Add created token to the Plant field
						PlantF4Id.addToken(defToken);
					}

					var obj = {};

					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Prnumber']] = oObjemodel[i];

					var oPrnumber = new Array();
					for (var key in obj)
						oPrnumber.push(obj[key]);

					var PrF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(PrF4DataModel, "PrF4DataModel");
					that.getView().getModel("PrF4DataModel").setProperty("/PrnumsF4", oPrnumber);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Buname']] = oObjemodel[i];
					var oBusUniname = new Array();
					for (var key in obj)
						oBusUniname.push(obj[key]);

					var BunameF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(BunameF4DataModel, "BunameF4DataModel");
					that.getView().getModel("BunameF4DataModel").setProperty("/BunamesF4", oBusUniname);
					var BunamesF4Id = that.getView().byId("InputValueBuname");

					for (var a = 0; a < oBusUniname.length; a++) {
						var defToken = new sap.m.Token({
							text: oBusUniname[a].Buname,
							key: oBusUniname[a].Buname
						});
						// Add created token to the Plant field
						BunamesF4Id.addToken(defToken);
					}

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Status']] = oObjemodel[i];
					var oStatus = new Array();
					for (var key in obj)
						if (key == "") {
							/*	oStatus.pop();*/
						} else {

							oStatus.push(obj[key]);
						}

					var oStatusF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oStatusF4DataModel, "oStatusF4DataModel");

					/*	var oHamname1 = "Pending With HAM";
					that.getView().byId("InputValuePrstatus").setValue(oHamname1);
*/
					that.getView().getModel("oStatusF4DataModel").setProperty("/StatusF4", oStatus);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['ItNonitStatus']] = oObjemodel[i];

					var oItnonStatus = new Array();
					for (var key in obj)
						if (key == "") {
							oItnonStatus.pop();
						} else {

							oItnonStatus.push(obj[key]);
						}

					var oItnonStatusF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oItnonStatusF4DataModel, "oItnonStatusF4DataModel");
					that.getView().getModel("oItnonStatusF4DataModel").setProperty("/ItnonStatusF4", oItnonStatus);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['ReqMgrStatus']] = oObjemodel[i];
					var oReqmangStatus = new Array();
					for (var key in obj)
						if (key == "") {
							oReqmangStatus.pop();
						} else {

							oReqmangStatus.push(obj[key]);
						}

					var oReqmangStatusF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oReqmangStatusF4DataModel, "oReqmangStatusF4DataModel");
					that.getView().getModel("oReqmangStatusF4DataModel").setProperty("/ReqmangStatusF4", oReqmangStatus);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Reqcategory']] = oObjemodel[i];
					var oReqcate = new Array();
					for (var key in obj)

						oReqcate.push(obj[key]);

					var oReqcateF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oReqcateF4DataModel, "oReqcateF4DataModel");
					that.getView().getModel("oReqcateF4DataModel").setProperty("/oReqcateF4", oReqcate);
					var ReqcateFF4Id = that.getView().byId("InputValueReqcatry");

					for (var a = 0; a < oReqcate.length; a++) {
						var defToken = new sap.m.Token({
							text: oReqcate[a].Reqcategory,
							key: oReqcate[a].Reqcategory
						});
						// Add created token to the Reqcategory field
						ReqcateFF4Id.addToken(defToken);
					}

					var oFIlterResults = oData.results;

					/*var oObjemodel = oFIlterResults.filter(function (x) {
						return x.Status == "Pending With HAM";
					});*/

					var oModel = new sap.ui.model.json.JSONModel(oObjemodel);
					oModel.setSizeLimit(200000);

					that.getView().byId("oMainTable").setModel(oModel, "oPRframe1Model");

					that.getView().byId("idRecords").setSelectedKey(that.oRecrds);

					that.getView().byId("Items").setText("Items(" + "" + oObjemodel.length + "" + ")");

				}, function (error) {

				});

			} else if (that.oFIlterResultsSam.length > 0) {
				var url = "/sap/opu/odata/sap/YMM_PR_FIORI_LOG_STATUS_SRV";

				that.oRecrds = that.getView().byId("idRecords").getSelectedKey();
				that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);
				var path = "/ymm_fiori_setSet?$top=" + that.oRecrds;
				that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

					var oObjemodel = oData.results;

					var obj = {};

					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Plant']] = oObjemodel[i];

					var plant = new Array();
					for (var key in obj)
						plant.push(obj[key]);

					var F4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(F4DataModel, "F4DataModel");
					that.getView().getModel("F4DataModel").setProperty("/PlantF4", plant);
					var PlantF4Id = that.getView().byId("InputValuePlant");

					for (var a = 0; a < plant.length; a++) {
						var defToken = new sap.m.Token({
							text: plant[a].Plant,
							key: plant[a].Plant
						});
						// Add created token to the Plant field
						PlantF4Id.addToken(defToken);
					}

					var obj = {};

					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Prnumber']] = oObjemodel[i];

					var oPrnumber = new Array();
					for (var key in obj)
						oPrnumber.push(obj[key]);

					var PrF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(PrF4DataModel, "PrF4DataModel");
					that.getView().getModel("PrF4DataModel").setProperty("/PrnumsF4", oPrnumber);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Buname']] = oObjemodel[i];
					var oBusUniname = new Array();
					for (var key in obj)
						oBusUniname.push(obj[key]);

					var BunameF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(BunameF4DataModel, "BunameF4DataModel");
					that.getView().getModel("BunameF4DataModel").setProperty("/BunamesF4", oBusUniname);
					var BunamesF4Id = that.getView().byId("InputValueBuname");

					for (var a = 0; a < oBusUniname.length; a++) {
						var defToken = new sap.m.Token({
							text: oBusUniname[a].Buname,
							key: oBusUniname[a].Buname
						});
						// Add created token to the Plant field
						BunamesF4Id.addToken(defToken);
					}

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Status']] = oObjemodel[i];
					var oStatus = new Array();
					for (var key in obj)
						if (key == "") {
							/*oStatus.pop();*/
						} else {

							oStatus.push(obj[key]);
						}

					var oStatusF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oStatusF4DataModel, "oStatusF4DataModel");
					//var termsam = "sam";
					/*working
					     var oSamname = oStatus.filter(x => new RegExp(termsam, 'i').test(x.Status));
						var oSamname1 = oSamname[0].Status;
						working*/

					that.getView().getModel("oStatusF4DataModel").setProperty("/StatusF4", oStatus);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['ItNonitStatus']] = oObjemodel[i];

					var oItnonStatus = new Array();
					for (var key in obj)
						if (key == "") {
							oItnonStatus.pop();
						} else {

							oItnonStatus.push(obj[key]);
						}

					var oItnonStatusF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oItnonStatusF4DataModel, "oItnonStatusF4DataModel");
					that.getView().getModel("oItnonStatusF4DataModel").setProperty("/ItnonStatusF4", oItnonStatus);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['ReqMgrStatus']] = oObjemodel[i];
					var oReqmangStatus = new Array();
					for (var key in obj)
						if (key == "") {
							oReqmangStatus.pop();
						} else {

							oReqmangStatus.push(obj[key]);
						}

					var oReqmangStatusF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oReqmangStatusF4DataModel, "oReqmangStatusF4DataModel");
					that.getView().getModel("oReqmangStatusF4DataModel").setProperty("/ReqmangStatusF4", oReqmangStatus);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Reqcategory']] = oObjemodel[i];
					var oReqcate = new Array();
					for (var key in obj)

						oReqcate.push(obj[key]);

					var oReqcateF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oReqcateF4DataModel, "oReqcateF4DataModel");
					that.getView().getModel("oReqcateF4DataModel").setProperty("/oReqcateF4", oReqcate);
					var ReqcateFF4Id = that.getView().byId("InputValueReqcatry");

					for (var a = 0; a < oReqcate.length; a++) {
						var defToken = new sap.m.Token({
							text: oReqcate[a].Reqcategory,
							key: oReqcate[a].Reqcategory
						});
						// Add created token to the Reqcategory field
						ReqcateFF4Id.addToken(defToken);
					}

					var oFIlterResults = oData.results;

					/*	var oObjemodel = oFIlterResults.filter(function (x) {
							return x.Status == "Pending With SAM";
						});*/

					var oModel = new sap.ui.model.json.JSONModel(oObjemodel);
					oModel.setSizeLimit(200000);

					that.getView().byId("oMainTable").setModel(oModel, "oPRframe1Model");

					that.getView().byId("idRecords").setSelectedKey(that.oRecrds);

					that.getView().byId("Items").setText("Items(" + "" + oObjemodel.length + "" + ")");

				}, function (error) {

				});

			} else if (that.oFIlterResultsBuyer.length > 0) {
				var url = "/sap/opu/odata/sap/YMM_PR_CREATION_ASSOCIATION_SRV";
				var path = "/zmmsh_categorySet";
				that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

					var oCatgModel = oData.results;

					that.oCatModl = oCatgModel.filter(function (x) {
						return x.Buyer_id == that.Loggeduser;
					});

					/*	var oObjemodel = oCatgModel.filter(function (x) {
							return x.Buyer_id == that.Loggeduser;
						});
						
							var obj = {};

						for (var i = 0, len = oObjemodel.length; i < len; i++)
							obj[oObjemodel[i]['plant']] = oObjemodel[i];

						var plant = new Array();
						for (var key in obj)
							plant.push(obj[key]);

						var F4DataModel = new sap.ui.model.json.JSONModel();
						that.getView().setModel(F4DataModel, "F4DataModel");
						that.getView().getModel("F4DataModel").setProperty("/PlantF4", plant);

						var PlantF4Id = that.getView().byId("InputValuePlant");

						
						for (var a = 0; a < plant.length; a++) {
							var defToken = new sap.m.Token({
								text: plant[a].Plant,
								key: plant[a].Plant
							});
						
							PlantF4Id.addToken(defToken);
						}
						*/

					/*	that.oCategbuyermodel = oCatgModel.filter(function (x) {
							return x.Buyer_id == that.Loggeduser;
						});*/
					/*	that.oCategry = that.oCategbuyermodel[0].category;
						that.oPlnt = that.oCategbuyermodel[0].plant;
						that.oCatbuyr = that.oCategbuyermodel[0].Buyer_id;*/
					/*	that.oCategmodel = oCatgModel.filter(function (x) {
							return x.category==	that.oCategbuyermodel[0].category;               
						});*/

				}, function (error) {

				});

				var url = "/sap/opu/odata/sap/YMM_PR_FIORI_LOG_STATUS_SRV";

				that.oRecrds = that.getView().byId("idRecords").getSelectedKey();
				that.oDataModel = new sap.ui.model.odata.ODataModel(url, true);
				var path = "/ymm_fiori_setSet?$top=" + that.oRecrds;
				that.oDataModel.read(path, null, null, false, function (oData, oResponse) {

					var oObjemodelX = oData.results;

					/*	var filtered_zone = [];
						for (var i = 0; i < SelectedZone.length; i++) {
							for (var j = 0; j < a.length; j++) {
								if (SelectedZone[i] == a[j].vkbur) {
									filtered_zone.push(a[j]);

								}

							}

						}*/

					var oFiltplant = that.oCatModl;
					/*	var obj = {};

						for (var i = 0, len = oFiltplant.length; i < len; i++)
							obj[oFiltplant[i]['plant']] = oFiltplant[i];

						var oDumplant = new Array();
						for (var key in obj)
							oDumplant.push(obj[key]);*/
					var oDumplant = oFiltplant.filter(function (a) {
						var key = a.category + '|' + a.plant;
						if (!this[key]) {
							this[key] = true;
							return true;
						}
					}, Object.create(null));

					/*	for (var i = 0; i < oDumplant.length; i++) {
							for (var j = 0; j < oObjemodelX.length; j++) {
							if(oObjemodelX[j].Plant == oDumplant[i].plant && oObjemodelX[j].Reqcategory == oDumplant[i].category)
								{
										oObjemodel.push(oDumplant[i]);
								}
								
							}

						}*/
					var oObjemodel = [];
					for (var i = 0; i < oObjemodelX.length; i++) {
						for (var j = 0; j < oDumplant.length; j++) {
							if (oDumplant[j].plant == oObjemodelX[i].Plant && oDumplant[j].category == oObjemodelX[i].Reqcategory) {
								oObjemodel.push(oObjemodelX[i]);
							}

						}

					}

					var obj = {};

					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Plant']] = oObjemodel[i];

					var plant = new Array();
					for (var key in obj)
						plant.push(obj[key]);

					var F4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(F4DataModel, "F4DataModel");
					that.getView().getModel("F4DataModel").setProperty("/PlantF4", plant);

					var PlantF4Id = that.getView().byId("InputValuePlant");

					for (var a = 0; a < plant.length; a++) {
						var defToken = new sap.m.Token({
							text: plant[a].Plant,
							key: plant[a].Plant
						});
						// Add created token to the Plant field
						PlantF4Id.addToken(defToken);
					}

					var obj = {};

					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Prnumber']] = oObjemodel[i];

					var oPrnumber = new Array();
					for (var key in obj)
						oPrnumber.push(obj[key]);

					var PrF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(PrF4DataModel, "PrF4DataModel");
					that.getView().getModel("PrF4DataModel").setProperty("/PrnumsF4", oPrnumber);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Buname']] = oObjemodel[i];
					var oBusUniname = new Array();
					for (var key in obj)
						oBusUniname.push(obj[key]);

					var BunameF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(BunameF4DataModel, "BunameF4DataModel");
					that.getView().getModel("BunameF4DataModel").setProperty("/BunamesF4", oBusUniname);
					var BunamesF4Id = that.getView().byId("InputValueBuname");

					for (var a = 0; a < oBusUniname.length; a++) {
						var defToken = new sap.m.Token({
							text: oBusUniname[a].Buname,
							key: oBusUniname[a].Buname
						});
						// Add created token to the Plant field
						BunamesF4Id.addToken(defToken);
					}

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Status']] = oObjemodel[i];
					var oStatus = new Array();
					for (var key in obj)
						if (key == "") {

						} else {

							oStatus.push(obj[key]);
						}

					var oStatusF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oStatusF4DataModel, "oStatusF4DataModel");
					//	var termbuyer = "buyer";
					/*	working
					     var oBuyname = oStatus.filter(x => new RegExp(termbuyer, 'i').test(x.Status));
						var oBuyname1 = oBuyname[0].Status;*/
					/*	var oBuyname1 = "Pending With buyer";
						that.getView().byId("InputValuePrstatus").setValue(oBuyname1);*/
					that.getView().getModel("oStatusF4DataModel").setProperty("/StatusF4", oStatus);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['ItNonitStatus']] = oObjemodel[i];

					var oItnonStatus = new Array();
					for (var key in obj)
						if (key == "") {
							oItnonStatus.pop();
						} else {

							oItnonStatus.push(obj[key]);
						}

					var oItnonStatusF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oItnonStatusF4DataModel, "oItnonStatusF4DataModel");
					that.getView().getModel("oItnonStatusF4DataModel").setProperty("/ItnonStatusF4", oItnonStatus);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['ReqMgrStatus']] = oObjemodel[i];
					var oReqmangStatus = new Array();
					for (var key in obj)
						if (key == "") {
							oReqmangStatus.pop();
						} else {

							oReqmangStatus.push(obj[key]);
						}

					var oReqmangStatusF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oReqmangStatusF4DataModel, "oReqmangStatusF4DataModel");
					that.getView().getModel("oReqmangStatusF4DataModel").setProperty("/ReqmangStatusF4", oReqmangStatus);

					var obj = {};
					for (var i = 0, len = oObjemodel.length; i < len; i++)
						obj[oObjemodel[i]['Reqcategory']] = oObjemodel[i];
					var oReqcate = new Array();
					for (var key in obj)

						oReqcate.push(obj[key]);

					var oReqcateF4DataModel = new sap.ui.model.json.JSONModel();
					that.getView().setModel(oReqcateF4DataModel, "oReqcateF4DataModel");
					that.getView().getModel("oReqcateF4DataModel").setProperty("/oReqcateF4", oReqcate);
					var ReqcateFF4Id = that.getView().byId("InputValueReqcatry");

					for (var a = 0; a < oReqcate.length; a++) {
						var defToken = new sap.m.Token({
							text: oReqcate[a].Reqcategory,
							key: oReqcate[a].Reqcategory
						});
						// Add created token to the Reqcategory field
						ReqcateFF4Id.addToken(defToken);
					}

					/*	var oFIlterResults = oData.results;

						var oObjemodel = oFIlterResults.filter(function (x) {
							return x.Status == "Pending With buyer";
						});*/

					var oModel = new sap.ui.model.json.JSONModel(oObjemodel);
					oModel.setSizeLimit(200000);

					that.getView().byId("oMainTable").setModel(oModel, "oPRframe1Model");

					that.getView().byId("idRecords").setSelectedKey(that.oRecrds);

					var filters = [];
					var list = that.getView().byId("InputValuePlant");
					var binding = list.getSuggestionItems("items");

					/*			for (var a = 0; a < binding.length; a++) {
				var defToken = new sap.m.Token({
					text: binding[a].getText()
			
				});
			
			}
			
        		if (defToken && defToken.length > 0) {
						for(var l=0;l<defToken.length;l++){
						var nameFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, defToken[l].getText());
							filters.push(nameFilter);
						}

					
					}*/

					if (binding && binding.length > 0) {
						for (var l = 0; l < binding.length; l++) {
							var nameFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, binding[l].getText());
							filters.push(nameFilter);
						}

					}

					var list = that.getView().byId("oMainTable");
					var binding = that.getView().byId("oMainTable").getBinding("rows");
					binding.filter(filters, sap.ui.model.FilterType.Application);

					that.getView().byId("Items").setText("Items(" + "" + binding.aIndices.length + "" + ")");

				}, function (error) {

				});

			} else {

				var oRecords = that.getView().byId("idRecords").getSelectedKey();
				that.onFilterChange2(oRecords);
			}

		}

	});

});