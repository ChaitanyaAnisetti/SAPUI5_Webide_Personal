sap.ui.define(function () {
	var Formatter = {

		CreatDate: function (Createddate) {

			if (Createddate) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var Datevalue = oDateFormat.format(new Date(Createddate));
				return Datevalue;

			} else {

				return "";

			}

		},
		Actiondate: function (Actiondate) {

			if (Actiondate) {
				var oDateFormat1 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var Datevalue1 = oDateFormat1.format(new Date(Actiondate));
				return Datevalue1;
			} else {

				return "";

			}

		},
		ItNonitActionDate: function (ItNonitActionDate) {

			if (ItNonitActionDate) {
				var oDateFormat2 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var Datevalue2 = oDateFormat2.format(new Date(ItNonitActionDate));
				return Datevalue2;
		} else {

				return  "";
			}

		},
			IntDelDt: function (IntDelDt) {

			if (IntDelDt) {
				var oDateFormatDel = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var DatevalueDel = oDateFormatDel.format(new Date(IntDelDt));
				return DatevalueDel;
			} else {

				return "";
			}

		},
		ReqMgrActionDate: function (ReqMgrActionDate) {

			if (ReqMgrActionDate) {
				var oDateFormat3 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var Datevalue3 = oDateFormat3.format(new Date(ReqMgrActionDate));
				return Datevalue3;
			} else {

				return "";
			}

		},

		ExpDeldate: function (ExpDelDt) {
			if (ExpDelDt)
			{
				var oDateFormat2 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
			var Datevalue2 = oDateFormat2.format(new Date(ExpDelDt));
			return Datevalue2;
			}	 else {

				return "";

			}

		},
		oServiceNum: function (ASNUM) {
			if (ASNUM) {
				var oServceText = ASNUM.replace(/\b0+/g, '');
				return oServceText;
			};

		},
		UnitPrice: function (UnitPrice) {

			if (UnitPrice != null && UnitPrice != undefined) {

				return Number(UnitPrice).toFixed(3);

			};

		},

		Price: function (Price) {
			if (Price != null && Price != undefined) {

				return Number(Price).toFixed(3);

			};

		},

		Netvalue: function (Netvalue) {
			if (Netvalue != null && Netvalue != undefined) {

				return Number(Netvalue).toFixed(3);

			};

		},

	
		TableDelDate: function (oDp2ref) {
			if (oDp2ref) {
				var oDateFormat2 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
				var Datevalue2 = oDateFormat2.format(new Date(oDp2ref));
				return Datevalue2;
			} else {
				return "";
			}
		},

		formatDate: function (v) {

			if (v != null && v != "00000000") {
				var d = new Date(v);
				var day = d.getDate();
				var q = d.getFullYear();
				var w = d.getMonth();

				var myYear = q;
				// var sptdate = String(w).split(" ");
				var ab = w;
				var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
				var myMonth = months[ab];
				var combineDatestr = myMonth + " " + day + "," + myYear;
				return combineDatestr;

			} else {
				return "";
			}
		},

		DateofInvc: function (DateOfInvoice) {
			if (DateOfInvoice)
			{
				var oDateFormatA = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
			var DatevalueA = oDateFormatA.format(new Date(DateOfInvoice));
			return DatevalueA;
			} else {

				return "";

			}

		},
		Dateofposting: function (DateOfPosting) {
			if (DateOfPosting)
			{
				var oDateFormat3 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
			var Datevalue3 = oDateFormat3.format(new Date(DateOfPosting));
			return Datevalue3;
			} else {

				return "";

			}

		},
		GrEnvDate: function (GrEnvDate) {
			if (GrEnvDate)
			{
				var oDateFormat4 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
			var Datevalue4 = oDateFormat4.format(new Date(GrEnvDate));
			return Datevalue4;
			
		} else {

				return "";

			}

		},
		InboundDelDate: function (InboundDelDate) {
			if (InboundDelDate)
			{
				var oDateFormat5 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
			var Datevalue5 = oDateFormat5.format(new Date(InboundDelDate));
			return Datevalue5;
			} else {

				return "";

			}

		},
		IntDelDate: function (IntDelDate) {
			if (IntDelDate)
			{
				var oDateFormat6 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
			var Datevalue6 = oDateFormat6.format(new Date(IntDelDate));
			return Datevalue6;
			} else {

				return "";

			}

		},
		InvEntryDate: function (InvEntryDate) {
			if (InvEntryDate)
			{
				var oDateFormat7 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
			var Datevalue7 = oDateFormat7.format(new Date(InvEntryDate));
			return Datevalue7;
			} else {

				return "";

			}

		},
		OrdConfirmDate: function (OrdConfirmDate) {
			if (OrdConfirmDate)
			{
				var oDateFormat8 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
			var Datevalue8 = oDateFormat8.format(new Date(OrdConfirmDate));
			return Datevalue8;
			} else {

				return "";

			}

		},
		DateOfPost: function (DateOfPost) {
			if (DateOfPost)
			{
				var oDateFormat9 = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/yyyy"
				});
			var Datevalue9 = oDateFormat9.format(new Date(DateOfPost));
			return Datevalue9;
			} else {

				return "";

			}

		},
		matnr: function (matnr) {
			if (matnr != undefined && matnr != null && matnr != "") {
				return matnr.replace(/\b0+/g, '');
			} else {
				return "";
			}
		}


	};

	return Formatter;
}, true);