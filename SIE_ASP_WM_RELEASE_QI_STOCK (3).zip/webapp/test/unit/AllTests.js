sap.ui.define([
	"Releaseqistock/SIE_ASP_WM_RELEASE_QI_STOCK/test/unit/controller/Mainview.controller"
], function () {
	"use strict";
});