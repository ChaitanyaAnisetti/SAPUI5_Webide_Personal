/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"Releaseqistock/SIE_ASP_WM_RELEASE_QI_STOCK/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});