sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel"
], function (Controller, History, JSONModel) {
	"use strict";

	return Controller.extend("Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.controller.Mainview", {
		onInit: function () {
			
		
		},

		onWHProcess: function (oEvent) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("InternalWHprocess", {
				WarehouseNo: this.getOwnerComponent().getModel("localModel").getProperty("/LoginUserInfo/WarehouseNo"),
				Plant: this.getOwnerComponent().getModel("localModel").getProperty("/LoginUserInfo/Plant")
			});
		}

	});
});