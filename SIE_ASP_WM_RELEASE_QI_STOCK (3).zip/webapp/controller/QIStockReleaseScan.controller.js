/*jQuery.sap.require("sap.ndc.BarcodeScanner");*/
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	'sap/m/MessageBox',
	'sap/m/MessagePopover',
	'sap/m/MessageItem',
	"sap/ndc/BarcodeScanner",
	"sap/m/library"
], function (Controller, JSONModel, MessageBox, MessagePopover, MessageItem, BarcodeScanner, mobileLibrary) {
	"use strict";

	return Controller.extend("Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.controller.QIStockReleaseScan", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.view.QIStockReleaseScan
		 */
		onInit: function () {

			this.oFioriClient = this.getOwnerComponent().getFioriClient();
			this.oBusyDialog = new sap.m.BusyDialog();
			var oViewModel = new JSONModel({
				isFioriClientAvailable: this.oFioriClient.isAvailable()
					//	isFioriClientAvailable:true
			});
			this.getView().setModel(oViewModel, "QIStockReleaseScan");

			//		var Gid = sap.ushell.Container.getService("UserInfo").getId();
			var Gid = this.getOwnerComponent().getModel("localModel").getProperty("/Gid");
			var path1 = "/UserDefaultSet('" + Gid + "')";
			this.oBusyDialog.open();
			this.getOwnerComponent().getModel("RELEASE_QI_STOCK_SRV").read(path1, {
				success: function (oData, oResponse) {
					if (oData.MsgType === "S") {
						this.WarehouseNo = oData.WarehouseNo;
						this.getOwnerComponent().getModel("localModel").setProperty("/LoginUserInfo", oData);
						this.oBusyDialog.close();
						if (!this.getView().byId("worklistGrid").getContent().length) {
							this.onCreateGridLayout();
						}
						this.StorageType(this.WarehouseNo);
					} else {
						this.oBusyDialog.close();
						sap.m.MessageBox.show(
							oData.MsgDesc, {
								icon: sap.m.MessageBox.Icon.ERROR,

								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);
					}
				}.bind(this),
				error: function (err) {
					this.oBusyDialog.close();
					sap.m.MessageBox.show(
						"OData error in UserDefaultSet", {
							icon: sap.m.MessageBox.Icon.ERROR,

							actions: [sap.m.MessageBox.Action.CLOSE],
							onClose: function (oAction) {}
						}
					);

				}.bind(this)
			});
		},
		StorageType: function (WarehouseNo) {

			var sTr = "WarehouseNo eq '" + WarehouseNo + "'";
			var oBindingInfo = {
				filters: null,
				urlParameters: {
					"$filter": sTr
				},
				success: function (oData, oResponse) {
					this.oBusyDialog.close();

					if (oData.results) {
						var oStoragetypemodel = new JSONModel(oData.results);
						this.getView().setModel(oStoragetypemodel, "oStoragetypemodel");
					} else {
						var oStoragetypemodel = new JSONModel([]);
						this.getView().setModel(oStoragetypemodel, "oStoragetypemodel");
						sap.m.MessageBox.show(
							oResponse.data.results[0].MsgDesc, {
								icon: sap.m.MessageBox.Icon.ERROR,
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {

								}

							}
						);
					}
				}.bind(this),
				error: function (oError) {

					this.oBusyDialog.close();
					sap.m.MessageBox.error("Error");
				}.bind(this)
			};

			this.getOwnerComponent().getModel("RELEASE_QI_STOCK_SRV").read("/Storage_listSet", oBindingInfo);

		},
		/*_onObjectMatched: function (oEvent) {
			if (oEvent.getParameter("arguments").WarehouseNo) {
				this.WarehouseNo = oEvent.getParameter("arguments").WarehouseNo;
			}
		},*/
		onBackpress: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Mainview", {

			});
		},

		/*var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("QIStockReleaseDispaly", {

				});*/

		onMaterialChange: function () {
			var SelectedMaterial = sap.ui.getCore().byId("oMatenoinput").getValue();
			var Plant = this.getOwnerComponent().getModel("localModel").getProperty("/LoginUserInfo/Plant"),
				Batchno = "",
				SpecialStockNo = "",
				Specialstockind = "";
			//(oSelectedMaterial,Plant,specialStockInd,specialStockNum,BatchNo
			this._CheckMaterial(SelectedMaterial, Plant, Specialstockind, SpecialStockNo, Batchno);
		},
		//barcode scanner functionalities....
		onBarCodeScan: function () {
			

			if (cordova && cordova.plugins && cordova.plugins.barcodeScanner) {
				
				var that = this;
				cordova.plugins.barcodeScanner.scan(
					/*	function (format) {
						var data = format;
						if (data.text && data.cancelled == false) {
							var Matyear = data.text.split("|")[1];
							var Matdocno = data.text.split("|")[2];
							var Matitem = data.text.split("|")[3];

							var WarehouseNo = that.WarehouseNo;
							sap.ui.getCore().byId("oMatenoinput").setValue(Matdocno);

							that._getMatDetail(WarehouseNo, Matyear, Matdocno, Matitem);
						} else if (data.cancelled) {
							sap.m.MessageToast.show("Scan Cancelled");
						}
					}, function (error) {
						var a = error;
					}, {
						formats: "QR_CODE,PDF_417"
					}*/
					this.onScanSuccess.bind(this),
					this.Error.bind(this));
			} else {
				BarcodeScanner.scan(
					this.onScanSuccess.bind(this),
					this.Error.bind(this)
					/*, {
											formats: "QR_CODE,PDF_417"
										}*/
				);
			}
		},
		onCreateGridLayout: function () {

			var that = this;
			var oGrid = this.getView().byId("worklistGrid");
			oGrid.destroyContent();
			var oMaterialdocInput, oMaterialiteminput, that = this;

			var VBoxMatedocno = new sap.m.VBox();
			VBoxMatedocno.destroyItems();
			VBoxMatedocno.addItem(
				new sap.m.ObjectIdentifier({
					title: "Mat.No.",
					titleActive: false
				})
			);

			var VBoxStoragetype = new sap.m.VBox();
			VBoxStoragetype.destroyItems();
			VBoxStoragetype.addItem(
				new sap.m.ObjectIdentifier({
					title: "Storage type",
					titleActive: false
				})
			);
			var VBoxFilter = new sap.m.VBox();
			VBoxFilter.destroyItems();
			VBoxFilter.addItem(
				new sap.m.ObjectIdentifier({
					title: "",
					titleActive: false
				}).addStyleClass("sapUiTinyMarginBottom")
			);

			if (this.getView().getModel("QIStockReleaseScan").getProperty("/isFioriClientAvailable")) {
				if (sap.ui.getCore().byId("oMatenoinput")) {
					sap.ui.getCore().byId("oMatenoinput").destroy(true);
				}
				oMaterialdocInput = new sap.m.Input("oMatenoinput", {
					enabled: true,
					editable: true,
					value: "",
					showValueHelp: true,
					valueHelpOnly: false,
					change: function (ovt) {
						that.onChangeMaterialdoc(ovt);
					},
					liveChange: function (ovt) {
						that.onlivechekvalueMaterialdoc(ovt);
					},
					valueHelpRequest: function (ovt) {
						that.onBarCodeScanInputFields(ovt, "materialDoc");
					}
				}).addEventDelegate({
					onfocusin: function (oEvt) {
						var oComId = oEvt.srcControl.getId();
						jQuery("#" + oComId).scannerDetection({
							timeBeforeScanTest: 200, // wait for the next character for upto 200ms
							//startChar: [120], // Prefix character for the cabled scanner (OPL6845R)
							endChar: [13], // be sure the scan is complete if key 13 (enter) is detected
							avgTimeByChar: 40, // it's not a barcode if a character takes longer than 40ms
							onComplete: function (barcode, qty) {

								var oArrstings;
								oArrstings = barcode.split("|");
								jQuery("#" + oEvt.srcControl.getId()).find('input').val("");
								jQuery("#" + oEvt.srcControl.getId()).find('input').val(oArrstings[4]);

							}, // main callback function
							onError: function (string) {
								//console.log("Error:" + string);
							}
						});

					},
					onsapfocusleave: function (oEvt) {
						var oComId = oEvt.srcControl.getId();
						jQuery("#" + oComId).scannerDetection(false);
					}
				});
				oMaterialdocInput._getValueHelpIcon().setSrc("sap-icon://bar-code");
				VBoxMatedocno.addItem(oMaterialdocInput);
				if (sap.ui.getCore().byId("oStoragebinComboId")) {
					sap.ui.getCore().byId("oStoragebinComboId").destroy(true);
				}
				var oStorageBin = new sap.m.ComboBox("oStoragebinComboId", {
				showSecondaryValues:true,
					
					items: {
						path: "oStoragetypemodel>/",
						template: new sap.ui.core.ListItem({
								text: "{oStoragetypemodel>Storagetype}",
							key: "{oStoragetypemodel>Storagetype}",
						
							additionalText:"{oStoragetypemodel>StotypeName}"
						})
					}

				});
				VBoxStoragetype.addItem(oStorageBin);
				var oFilterButton = new sap.m.Button({
					icon: "sap-icon://filter",
					text: "Filter",
					type: "Emphasized",
					iconFirst: true,
					tooltip: "Filter",
					press: function (evt) {

						that.onFilter(evt);
					}
				}).addStyleClass("sapUiTinyMarginTop");
				VBoxFilter.addItem(oFilterButton);
			} else {
				if (sap.ui.getCore().byId("oMatenoinput")) {
					sap.ui.getCore().byId("oMatenoinput").destroy(true);
				}

				oMaterialdocInput = new sap.m.Input("oMatenoinput", {
					value: ""
				});
				VBoxMatedocno.addItem(oMaterialdocInput);
				if (sap.ui.getCore().byId("oStoragebinComboId")) {
					sap.ui.getCore().byId("oStoragebinComboId").destroy(true);
				}
				var oStorageBin = new sap.m.ComboBox("oStoragebinComboId", {
					showSecondaryValues: true,
				
					items: {
						path: "oStoragetypemodel>/",
						template: new sap.ui.core.ListItem({
								text: "{oStoragetypemodel>Storagetype}",
							key: "{oStoragetypemodel>Storagetype}",
						
							additionalText:"{oStoragetypemodel>StotypeName}"
						})
					}

				});
				VBoxStoragetype.addItem(oStorageBin);
						var oFilterButton = new sap.m.Button({
					icon: "sap-icon://filter",
					text: "Filter",
					type: "Emphasized",
					iconFirst: true,
					tooltip: "Filter",
					press: function (evt) {

						that.onFilter(evt);
					}
				}).addStyleClass("sapUiTinyMarginTop");
				VBoxFilter.addItem(oFilterButton);
			}
			oGrid.destroyContent();

			oGrid.addContent(VBoxMatedocno);
			oGrid.addContent(VBoxStoragetype);
			oGrid.addContent(VBoxFilter);

		},
		onFilter: function () {
			var Storagetype =sap.ui.getCore().byId("oStoragebinComboId").getSelectedKey();
			var Material = sap.ui.getCore().byId("oMatenoinput").getValue();

                    	var sTr =   "WarehouseNo eq '"+this.WarehouseNo+"'and  Storagetype eq '"+Storagetype+"'and Material  eq '"+Material+"'";
		//	var sTr = "WarehouseNo eq '" + this.WarehouseNo + "' and  Storagetype eq '" + Storagetype + "' and Material  eq '" + Material + "'";
			var oBindingInfo = {
				filters: null,
				urlParameters: {
					"$filter": sTr
				},
				success: function (oData, oResponse) {
					this.oBusyDialog.close();
					if (oData.results[0].MsgType === "S" || oResponse.data.results[0].MsgType === "") {
						var oMatModel = new JSONModel(oData.results);
						this.getView().setModel(oMatModel, "oMatModel");
					} else {
						var oMatModel = new JSONModel([]);
						this.getView().setModel(oMatModel, "oMatModel");
						sap.m.MessageBox.show(
							oResponse.data.results[0].MsgDesc, {
								icon: sap.m.MessageBox.Icon.ERROR,
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {

								}

							}
						);
					}
				}.bind(this),
				error: function (oError) {

					this.oBusyDialog.close();
					sap.m.MessageBox.error("Error");
				}.bind(this)
			};

			this.getOwnerComponent().getModel("RELEASE_QI_STOCK_SRV").read("/Storage_detailSet", oBindingInfo);

		},
		onChangeMaterialdoc: function (oEvent) {

			var sFValue = "";
			sFValue = oEvent.getSource().getValue();
			var sSourceControl = oEvent.getSource();
			if (sFValue.length <= 18) {
				sSourceControl.setValueState("None");
				var SelectedMaterial = sap.ui.getCore().byId("oMatenoinput").getValue();
				var Plant = this.getOwnerComponent().getModel("localModel").getProperty("/LoginUserInfo/Plant"),
					Batchno = "",
					SpecialStockNo = "",
					Specialstockind = "";
				//(oSelectedMaterial,Plant,specialStockInd,specialStockNum,BatchNo
		//		this._CheckMaterial(SelectedMaterial, Plant, Specialstockind, SpecialStockNo, Batchno);

			} else if (sFValue.length > 18) {
				sSourceControl.setValueState("Error");
				sap.m.MessageToast.show("Material document no. max length is 18");
			}

		},

		onlivechekvalueMaterialdoc: function (oEvent) {
			var that = this;
			var sFValue = "";
			sFValue = oEvent.getSource().getValue();
			var sSourceControl = oEvent.getSource();

			if (sFValue.length > 0) {
				sap.ui.getCore().byId(oEvent.getSource().getId()).onsapenter = function (e) {

					if (sFValue.slice(0, 3) === "]d2") /// read  GS1 data matrix.
					{
						that.onDecodeStringtoValue(sSourceControl, sFValue);

					} else { /// read QR Code..
						var oArrstings = sFValue.split("|");
						if (oArrstings.length > 1 && oArrstings[4]) {
							sSourceControl.setValue("");
							sSourceControl.setValue(oArrstings[4]);
							that.onChangeMaterialdoc(new sap.ui.base.Event("PutawaymateDoc", sSourceControl, {}));
						} else if (oArrstings.length === 1) {
							sSourceControl.setValue("");
							sSourceControl.setValue(oArrstings[0]);
							that.onChangeMaterialdoc(new sap.ui.base.Event("PutawaymateDoc", sSourceControl, {}));
						}

					}

				};
			}
		},
		onDecodeStringtoValue: function (oComponent, oStrings) {
			//sap.m.MessageToast.show("onDecoder funciton");
			if (oStrings !== "" && oStrings.slice(0, 3) === "]d2") {
				var objArray = parseBarcode(oStrings).parsedCodeItems;
				var obj = jQuery.grep(objArray, function (e) {
					return e.ai === "91";
				})[0];
				if (obj && obj.data && obj.data.length > 0) {
					oComponent.setValue(obj.data);
					this.onChangeMaterialNumber(new sap.ui.base.Event("PutawaymateDoc", oComponent, {}));
				} else {
					if (obj === undefined) {
						sap.m.MessageToast.show("AI 91 not found in barcode");
						oComponent.setValue("");
					}

					if (obj.data && obj.data.length === 0) {
						sap.m.MessageToast.show("Material number value not found in barcode");
						oComponent.setValue("");
					}
				}
			}
		},

		// onSuccess Callback 
		/*onScanSuccess: function (result) {
			var bCancelled = result.cancelled;
			sap.ui.getCore().byId("oMatenoinput").setValue("");
				sap.ui.getCore().byId("oMateIteminput").setValue("");
			if (result.text && bCancelled == false) {
				//	var WarehouseNo = "A04";
				var WarehouseNo = this.WarehouseNo;
				var Matyear = result.text.split("|")[0];
				var Matdocno = result.text.split("|")[1];
				var Matitem = result.text.split("|")[2];
					sap.ui.getCore().byId("oMatenoinput").setValue(Matdocno);
					sap.ui.getCore().byId("oMateIteminput").setValue(Matitem);
				this._getMatDetail(WarehouseNo, Matyear, Matdocno, Matitem);
			} else if (bCancelled) {
				sap.m.MessageToast.show("Scan Cancelled");
			}

		},*/
		// onSuccess Callback 
		onScanSuccess: function (result) {
			
			var bCancelled = result.cancelled;
			sap.ui.getCore().byId("oMatenoinput").setValue("");
			if (result.text && bCancelled == false) {

				sap.ui.getCore().byId("oMatenoinput").setValue(result.text.split("|")[2]);

				var SelectedMaterial = sap.ui.getCore().byId("oMatenoinput").getValue();
				var Plant = result.text.split("|")[5] || "",
					Batchno = result.text.split("|")[10] || "",
					SpecialStockNo = result.text.split("|")[8] || "",
					Specialstockind = result.text.split("|")[7] || "";

				this._CheckMaterial(SelectedMaterial, Plant, Specialstockind, SpecialStockNo, Batchno);
			} else if (bCancelled) {
				sap.m.MessageToast.show("Scan Cancelled");
			}

		},

		// onError Callback
		onError: function (error) {
			sap.m.MessageToast.show(error, "Error");
		},
		onBarCodeScanInputFields: function (oEvent, oCustomData) {
			this.destinationtype = "";
			this.destinationtype = oCustomData;
			this.desctinationCntl = oEvent.getSource();

			BarcodeScanner.scan(
				this.onSuccess.bind(this),
				this.onError.bind(this)
			);
		},
		// onSuccess Callback 
		onSuccess: function (result) {
			var bCancelled = result.cancelled;
			this.onRetrieveStingFromScannerInfo(result.text);

			if (bCancelled) {
				sap.m.MessageToast.show("Scan Cancelled");
				this.desctinationCntl.setValueHelpOnly(false); // cancel button pressed. allow user to input manually.
			}
		},

		onRetrieveStingFromScannerInfo: function (oStirngs) {

			var oArrstings;
			switch (this.destinationtype) {

			case "materialDoc":

				if (oStirngs.slice(0, 1) === "\x1D") {
					var oResult = "]d2" + oStirngs.replaceAll("\x1D", "|");
					var objArray = parseBarcode(oResult).parsedCodeItems;
					var obj = jQuery.grep(objArray, function (e) {
						return e.ai === "91";
					})[0];
					if (obj && obj.data && obj.data.length > 0) {
						this.desctinationCntl.setValue(obj.data);
						this.onChangeMaterialdoc(new sap.ui.base.Event("PutawaymateDoc", this.desctinationCntl, {}));

					} else {
						if (obj === undefined) {
							sap.m.MessageToast.show("AI 91 not found in barcode");
							this.desctinationCntl.setValue("");
						}

						if (obj.data && obj.data.length === 0) {
							sap.m.MessageToast.show("Material document not found in barcode");
							this.desctinationCntl.setValue("");
						}
					}
				} else {
					oArrstings = oStirngs.split("|");
					if (oArrstings.length > 1 && oArrstings[4]) {
						this.desctinationCntl.setValue("");
						this.desctinationCntl.setValue(oArrstings[4]);
						this.onChangeMaterialdoc(new sap.ui.base.Event("PutawaymateDoc", this.desctinationCntl, {}));
					} else if (oArrstings.length === 1) {
						this.desctinationCntl.setValue("");
						this.desctinationCntl.setValue(oArrstings[0]);
						this.onChangeMaterialdoc(new sap.ui.base.Event("PutawaymateDoc", this.desctinationCntl, {}));
					}

				}

				break;
			default:
				// code block
			}
		},
		_CheckMaterial: function (oSelectedMaterial, Plant, specialStockInd, specialStockNum, BatchNo) {
			var oSelectedMaterial = oSelectedMaterial,
				Plant = Plant,
				specialStockInd = specialStockInd,
				specialStockNum = specialStockNum,
				BatchNo = BatchNo;

			this.oBusyDialog.open();
			var oBindingInfo = {
				success: function (oData, oResponse) {
					this.oBusyDialog.close();

					if (oData.MsgType === "S") {
						this.oBusyDialog.close();
						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						oRouter.navTo("QIStockReleaseDispaly", {
							WarehouseNo: this.getOwnerComponent().getModel("localModel").getProperty("/LoginUserInfo/WarehouseNo"),
							MaterialNum: oSelectedMaterial,
							Plant: Plant,
							Batchno: BatchNo,
							SpecialStockNo: specialStockNum,
							Specialstockind: specialStockInd
						});
					} else {
						this.oBusyDialog.close();
						sap.m.MessageBox.show(
							oData.MsgDesc, {
								icon: sap.m.MessageBox.Icon.ERROR,
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);
					}
				}.bind(this),
				error: function (oError) {
					this.oBusyDialog.close();
					sap.m.MessageBox.error("Error");
				}.bind(this)
			};

			/*Plant =Plant, 
			    specialStockInd =specialStockInd, 
			    specialStockNum = specialStockNum, 
			    BatchNo=BatchNo;*/
			//Chk_MaterialSet(WarehouseNo='A04',Material='100000070',Plant='9CB3',Batchno='0000000798',SpecialStockNo=' ',Specialstockind=' ')
			this.getOwnerComponent().getModel("RELEASE_QI_STOCK_SRV").read("/Chk_MaterialSet(WarehouseNo='" + this.WarehouseNo + "',Material='" +
				oSelectedMaterial + "',Plant='" + Plant + "',Batchno='" + BatchNo + "',SpecialStockNo='" + specialStockNum +
				"',Specialstockind='" + specialStockInd + "')", oBindingInfo);

		},
		handleMaterialPress:function(oEvt){
			var SelectedObj = oEvt.getSource().getBindingContext("oMatModel").getObject();
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						oRouter.navTo("QIStockReleaseDispaly", {
							WarehouseNo:SelectedObj.WarehouseNo,
							MaterialNum: SelectedObj.Material,
							Plant: SelectedObj.Plant,
							Batchno:SelectedObj.Batchno,
							SpecialStockNo: SelectedObj.SpecialStockNo,
							Specialstockind:SelectedObj.Specialstockindss
						});
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.view.QIStockReleaseScan
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.view.QIStockReleaseScan
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.view.QIStockReleaseScan
		 */
		//	onExit: function() {
		//
		//	}

	});

});