sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageBox',
	'sap/m/MessagePopover',
	'sap/m/MessageItem',
	"sap/ui/model/json/JSONModel",
	"sap/ndc/BarcodeScanner",
	"sap/m/library",
	"Releaseqistock/SIE_ASP_WM_RELEASE_QI_STOCK/Formatter/Formatter",
	"sap/m/MessageToast"

], function (Controller, MessageBox, MessagePopover, MessageItem, JSONModel, BarcodeScanner, library, Formatter,MessageToast) {
	"use strict";

	return Controller.extend("Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.controller.QIStockReleaseDispaly", {

		/**
		 * Called when a controller is instantiatecrossd and its View controls (if available) are already created.
		 * Can be used to modify the View before it is manageed, to bind event handlers and do other one-time initialization.
		 * @memberOf Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.view.QIStockReleaseDispaly
		 */

		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oFioriClient = this.getOwnerComponent().getFioriClient();
			oRouter.getRoute("QIStockReleaseDispaly").attachPatternMatched(this._onObjectMatched, this);
			this.oBusyDialog = new sap.m.BusyDialog();
			var oMatyear = new Date().getFullYear();
			this.Matyear = oMatyear.toString();
		},
		_onObjectMatched: function (oEvent) {
			if (oEvent.getParameter("arguments").WarehouseNo && oEvent.getParameter("arguments").MaterialNum) {
				this.WarehouseNo = oEvent.getParameter("arguments").WarehouseNo;
				this.MaterialNum = oEvent.getParameter("arguments").MaterialNum;
				//	this.Indicator = oEvent.getParameter("arguments").Indicator || "";
				this.Plant = oEvent.getParameter("arguments").Plant || "";
				this.Batchno = oEvent.getParameter("arguments").Batchno || "";
				this.SpecialStockNo = oEvent.getParameter("arguments").SpecialStockNo || "";
				this.Specialstockind = oEvent.getParameter("arguments").Specialstockind || "";
				this.Storagetype = oEvent.getParameter("arguments").Storagetype || "";
				this.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", null);
				this.oBusyDialog.open();

				var oBindingInfo = {
					success: function (oData, oResponse) {
						this.oBusyDialog.close();

						if (oData.MsgType1 === "S" || oData.MsgType1 === "") {
							this.oBusyDialog.close();

							this.getOwnerComponent().getModel("localModel").setProperty("/oQistockreleasedData", oData);
						} else {
							this.oBusyDialog.close();

							this.getOwnerComponent().getModel("localModel").setProperty("/oQistockreleasedData", "");
							sap.m.MessageBox.show(
								oData.MsgDesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					}.bind(this),
					error: function (oError) {
						this.oBusyDialog.close();
					}.bind(this)
				};

				/*//	(WarehouseNo='A04',Material='100000 073',Plant='9CB3',Batchno=' ',SpecialStockNo='3000001004000100',Specialstockind='E')*/
				this.getOwnerComponent().getModel("RELEASE_QI_STOCK_SRV").read("/Item_detailsSet(WarehouseNo='" + this.WarehouseNo +
					"',Material='" + this.MaterialNum + "',Plant='" + this.Plant + "',Batchno='" + this.Batchno + "',SpecialStockNo='" + this.SpecialStockNo +
					"',Specialstockind='" + this.Specialstockind + "')/?$expand=ITEM_SERIAL_NAV", oBindingInfo);
			}

		},
		onPressback: function () {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("QIStockReleaseScan");

		},

		onStockQunatitychange: function (oEvt) {

			var sValue1 = oEvt.getParameter("value");
			var sValue = Number(sValue1).toFixed(3);
			this.getView().byId("oStockQty").setText(sValue);
			oEvt.getSource().setValue(sValue);
		},

		onQItoBlock: function () {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");
			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("B");
			} else {
				var oPayload = {

					//	"UserGID": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/UserGID"),
					//  "UserGID":  sap.ushell.Container.getService("UserInfo").getId(),
					//"UserGID": "Z004C4CT",
					"MatDesc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MatDesc"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Material"),
					"MsgDesc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MsgDesc"),
					"MsgType1": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MsgType1"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Serialno"),
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStock"),
					"Specialstockind": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Specialstockind"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Stockcat"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"SpecialStoc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStoc"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/WarehouseNo"),
					"Action": "B",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Batchno"),
					"Matyear": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matyear"),
					"Matitem": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matitem"),
					"Matdoc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matdoc"),
					"Indicator": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Indicator"),
					"ITEM_SERIAL_NAV": []

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("RELEASE_QI_STOCK_SRV").create("/Item_detailsSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.MsgType1 === "S") {

							that.oBusyDialog.close();
							if (that.Storagetype === "") {
								sap.m.MessageBox.success(oData.MsgDesc, {
									//actions: ["Go to Putaway process", "Go to QI Stock Release", "Close"],

									actions: ["Go to QI Stock Release", "Close"],
									title: "Success",
									onClose: function (oAction) {

										if (oAction == "Go to QI Stock Release") {

											//	that.onPutawayprocess(oData);
											that.onBack();

										} else {
											that.onBackhome();
										}

									}

								});
							} else if (that.Storagetype === "Q01") {
								sap.m.MessageBox.success(oData.MsgDesc, {
									//actions: ["Go to Putaway process", "Go to QI Stock Release", "Close"],

									actions: ["Go to QI Stock Release", "Go to Putaway", "Close"],
									title: "Success",
									onClose: function (oAction) {

										if (oAction == "Go to QI Stock Release") {

											//	that.onPutawayprocess(oData);
											that.onBack();

										} else if (oAction == "Go to Putaway") {
											that.onPutawayprocess(oData);
										} else {
											that.onBackhome();
										}

									}

								});
							} else if (that.Storagetype === "Q02") {
								sap.m.MessageBox.success(oData.MsgDesc, {
									//actions: ["Go to Putaway process", "Go to QI Stock Release", "Close"],

									actions: ["Go to QI Stock Release", "Go to Bin to Bin", "Close"],
									title: "Success",
									onClose: function (oAction) {

										if (oAction == "Go to QI Stock Release") {

											that.onBack();

										} else if (oAction == "Go to Bin to Bin") {
											that.onBintobin(oData);
										} else {
											that.onBackhome();
										}

									}

								});
							}
						} else {
							that.oBusyDialog.close();
							sap.m.MessageBox.show(
								oData.MsgDesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						sap.m.MessageBox.error("Error");
						that.getOwnerComponent().getModel("localModel").setProperty("/oQistockreleasedData", []);
					}
				});
			}
		},

		onQitour: function () {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("U");
			} else {
				var oPayload = {
					//	"UserGID": "Z004C4CT",
					//    "UserGID":  sap.ushell.Container.getService("UserInfo").getId(),
					//	"UserGID": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/UserGID"),
					"MatDesc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MatDesc"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Material"),
					"MsgDesc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MsgDesc"),
					"MsgType1": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MsgType1"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Serialno"),
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStock"),

					/*	"Indicator": "",*/
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStockNo"),
					"Specialstockind": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Specialstockind"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Stockcat"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"SpecialStoc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStoc"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/WarehouseNo"),
					/*	"Action":  this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Action"),*/
					"Action": "U",

					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Batchno"),
					"Matyear": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matyear"),
					"Matitem": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matitem"),
					"Matdoc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matdoc"),
					"Indicator": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Indicator"),
					"ITEM_SERIAL_NAV": []

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("RELEASE_QI_STOCK_SRV").create("/Item_detailsSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.MsgType1 === "S") {
							that.oBusyDialog.close();
							/*sap.m.MessageBox.success(oData.MsgDesc, {

								actions: ["Go to QI Stock Release", "Close"],
								title: "Success",
								onClose: function (oAction) {

									if (oAction == "Go to QI Stock Release") {

										//	that.onPutawayprocess(oData);
										that.onBack();

									} else {
										that.onBackhome();
									}

								}

							});*/
							if (that.Storagetype === "") {
								sap.m.MessageBox.success(oData.MsgDesc, {
									//actions: ["Go to Putaway process", "Go to QI Stock Release", "Close"],

									actions: ["Go to QI Stock Release", "Close"],
									title: "Success",
									onClose: function (oAction) {

										if (oAction == "Go to QI Stock Release") {

											//	that.onPutawayprocess(oData);
											that.onBack();

										} else {
											that.onBackhome();
										}

									}

								});
							} else if (that.Storagetype === "Q01") {
								sap.m.MessageBox.success(oData.MsgDesc, {
									//actions: ["Go to Putaway process", "Go to QI Stock Release", "Close"],

									actions: ["Go to QI Stock Release", "Go to Putaway", "Close"],
									title: "Success",
									onClose: function (oAction) {

										if (oAction == "Go to QI Stock Release") {

											//	that.onPutawayprocess(oData);
											that.onBack();

										} else if (oAction == "Go to Putaway") {
											that.onPutawayprocess(oData);
										} else {
											that.onBackhome();
										}

									}

								});
							} else if (that.Storagetype === "Q02") {
								sap.m.MessageBox.success(oData.MsgDesc, {
									//actions: ["Go to Putaway process", "Go to QI Stock Release", "Close"],

									actions: ["Go to QI Stock Release", "Go to Bin to Bin", "Close"],
									title: "Success",
									onClose: function (oAction) {

										if (oAction == "Go to QI Stock Release") {

											that.onBack();

										} else if (oAction == "Go to Bin to Bin") {
											that.onBintobin(oData);
										} else {
											that.onBackhome();
										}

									}

								});
							}
						} else {
							that.oBusyDialog.close();
							sap.m.MessageBox.show(
								oData.MsgDesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						sap.m.MessageBox.error("Error");
						that.getOwnerComponent().getModel("localModel").setProperty("/oQistockreleasedData", []);
					}
				});
			}
		},
		onMaintainserialno: function () {
			var that = this;
			var oVal = this.getView().byId("oStockQtychange").getValue();
			var bindVal = "";
			if (oVal) {
				oVal = Number(Number(oVal).toFixed(0));
				if (oVal <= 1) {
					var loopoVal = 1;
					//	bindVal = oVal;
				} else {
					var loopoVal = oVal;
				}
			} else {
				var loopoVal = 0;
			}
			if (!this._Dialog1) {
				this._Dialog1 = sap.ui.xmlfragment(
					"Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.Fragment.MultipleQuantitieRows",
					this
				);
				this.getView().addDependent(this._Dialog1);
			}
			this._Dialog1.open();
			var oTable = sap.ui.getCore().byId("oRelaseStrtTable");
			var oColumn1 = new sap.m.Column({
				header: new sap.m.Label({
					text: "ID"
				})
			});
			var oColumn2 = new sap.m.Column({
				header: new sap.m.Label({
					text: "Serial No.s",
					required: true
				})
			});

			oTable.addColumn(oColumn1);
			oTable.addColumn(oColumn2);

			var oCell = [];
			var Data = [];
			var cell1 = new sap.m.Label({
				text: "{oSerialNoModel>ID}",
				design: "Bold"
			});
			var cell2 = new sap.m.Input({
				//	maxLength:18,
				placeholder: "Maintain SN ",
				value: "{oSerialNoModel>Serialno}",
				icon: "sap-icon://bar-code",
				showValueHelp: true,
				valueHelpOnly: false,
				valueHelpRequest: function (ovt) {
					var Index = parseInt(sap.ui.getCore().byId(ovt.getSource().getId()).getBindingContext("oSerialNoModel").getPath().split("/")[1],
						10);
					that.onBarCodeScanInputFields(ovt, "SerialNo", Index);
				},
				change: function (oEvt) {
					that.onChangeValueSN(oEvt);
				},
				liveChange: function (ovt) {
					that.onlivechekvaluefor(ovt);
				}
			}).addEventDelegate({
				onfocusin: function (oEvt) {

					var oComId = oEvt.srcControl.getId();
					var oIndex = parseInt(sap.ui.getCore().byId(oComId).getBindingContext("oSerialNoModel").getPath().split("/")[1], 10);

					jQuery("#" + oComId).scannerDetection({
						timeBeforeScanTest: 200, // wait for the next character for upto 200ms
						//startChar: [120], // Prefix character for the cabled scanner (OPL6845R)
						//endChar: [9,10,13,126], // be sure the scan is complete if key 13 (enter) is detected
						endChar: [13], // be sure the scan is complete if key 13 (enter) is detected
						avgTimeByChar: 40, // it's not a barcode if a character takes longer than 40ms
						onComplete: function (barcode, qty) {
							var oArrstings;
							oArrstings = barcode.split("|");

							if (oArrstings.length > 1 && oArrstings[9]) {
								jQuery("#" + oEvt.srcControl.getId()).find('input').val("");
								jQuery("#" + oEvt.srcControl.getId()).find('input').val(oArrstings[9]);
							} else if (oArrstings.length === 1) {
								jQuery("#" + oEvt.srcControl.getId()).find('input').val("");
								jQuery("#" + oEvt.srcControl.getId()).find('input').val(oArrstings[0]);
							}
							if (sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1]) {
								var oId = sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1].getCells()[1].getId();
								jQuery.sap.delayedCall(300, this, function () {
									sap.ui.getCore().byId(oId).focus();
								});
							}

						}, // main callback function
						onError: function (string) {
							//console.log("Error:" + string);
						}
					});

					//that.onDetecScanner(oEvt.srcControl.getId(),true);
				},
				onsapfocusleave: function (oEvt) {
					var oComId = oEvt.srcControl.getId();
					jQuery("#" + oComId).scannerDetection(false);

				}
			});
			cell2._getValueHelpIcon().setSrc("sap-icon://bar-code");
			oCell.push(cell1);
			oCell.push(cell2);
if(this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData")&&this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData").length){
for (var i = 0; i < loopoVal; i++) {
	var Snro="";
	if(this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData")[i]){
	Snro=this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData")[i].Serialno;
	}
				var obj = {
					"Serialno":Snro ,
					"ID": i + 1
				};
				Data.push(obj);
			}
	
}
else{
			for (var i = 0; i < loopoVal; i++) {
				var obj = {
					"Serialno": bindVal,
					"ID": i + 1
				};
				Data.push(obj);
			}
		}
			var Model = new sap.ui.model.json.JSONModel(Data);
			oTable.setModel(Model, "oSerialNoModel");
			var aColList = new sap.m.ColumnListItem("", {
				cells: oCell
			});
			oTable.bindItems("oSerialNoModel>/", aColList);

		},
		onMaterialChangeStockClear: function () {
			var that = this;
			var oVal = this.getView().byId("oStockQtychange").getValue();
				this.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData",null);
			var bindVal = "";
			if (oVal) {
				if (oVal <= 1) {
					var loopoVal = 1;
					//	bindVal = oVal;
				} else {
					var loopoVal = oVal;
				}
			} else {
				var loopoVal = 0;
			}

			var oTable = sap.ui.getCore().byId("oRelaseStrtTable");
			oTable.destroyItems();
			oTable.unbindItems();
			oTable.removeAllColumns();
			var oTable = sap.ui.getCore().byId("oRelaseStrtTable");
			var oColumn1 = new sap.m.Column({
				header: new sap.m.Label({
					text: "ID"
				})
			});
			var oColumn2 = new sap.m.Column({
				header: new sap.m.Label({
					text: "Serial No.s",
					required: true
				})
			});

			oTable.addColumn(oColumn1);
			oTable.addColumn(oColumn2);

			var oCell = [];
			var Data = [];
			var cell1 = new sap.m.Label({
				text: "{oSerialNoModel>ID}",
				design: "Bold"
			});
			var cell2 = new sap.m.Input({
				//	maxLength:18,
				placeholder: "Maintain SN ",
				value: "{oSerialNoModel>Serialno}",
				icon: "sap-icon://bar-code",
				showValueHelp: true,
				valueHelpOnly: false,
				valueHelpRequest: function (ovt) {
					var Index = parseInt(sap.ui.getCore().byId(ovt.getSource().getId()).getBindingContext("oSerialNoModel").getPath().split("/")[1],
						10);
					that.onBarCodeScanInputFields(ovt, "SerialNo", Index);
				},
				change: function (oEvt) {
					that.onChangeValueSN(oEvt);
				},
				liveChange: function (ovt) {
					that.onlivechekvaluefor(ovt);
				}
			}).addEventDelegate({
				onfocusin: function (oEvt) {

					var oComId = oEvt.srcControl.getId();
					var oIndex = parseInt(sap.ui.getCore().byId(oComId).getBindingContext("oSerialNoModel").getPath().split("/")[1], 10);

					jQuery("#" + oComId).scannerDetection({
						timeBeforeScanTest: 200, // wait for the next character for upto 200ms
						//startChar: [120], // Prefix character for the cabled scanner (OPL6845R)
						//endChar: [9,10,13,126], // be sure the scan is complete if key 13 (enter) is detected
						endChar: [13], // be sure the scan is complete if key 13 (enter) is detected
						avgTimeByChar: 40, // it's not a barcode if a character takes longer than 40ms
						onComplete: function (barcode, qty) {
							/*	sap.ui.getCore().byId(oComId).setValue(barcode);*/
							var oArrstings;
							oArrstings = barcode.split("|");
							if (oArrstings.length > 1 && oArrstings[9]) {
								jQuery("#" + oEvt.srcControl.getId()).find('input').val("");
								jQuery("#" + oEvt.srcControl.getId()).find('input').val(oArrstings[9]);
							} else if (oArrstings.length === 1) {
								jQuery("#" + oEvt.srcControl.getId()).find('input').val("");
								jQuery("#" + oEvt.srcControl.getId()).find('input').val(oArrstings[0]);
							}
							if (sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1]) {
								var oId = sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1].getCells()[1].getId();
								jQuery.sap.delayedCall(300, this, function () {
									sap.ui.getCore().byId(oId).focus();
								});
							}

						}, // main callback function
						onError: function (string) {
							//console.log("Error:" + string);
						}
					});

					//that.onDetecScanner(oEvt.srcControl.getId(),true);
				},
				onsapfocusleave: function (oEvt) {
					var oComId = oEvt.srcControl.getId();
					jQuery("#" + oComId).scannerDetection(false);

				}
			});
			cell2._getValueHelpIcon().setSrc("sap-icon://bar-code");
			oCell.push(cell1);
			oCell.push(cell2);

			for (var i = 0; i < loopoVal; i++) {
				var obj = {
					"Serialno": bindVal,
					"ID": i + 1
				};
				Data.push(obj);
			}
			var Model = new sap.ui.model.json.JSONModel(Data);
			oTable.setModel(Model, "oSerialNoModel");
			var aColList = new sap.m.ColumnListItem("", {
				cells: oCell
			});
			oTable.bindItems("oSerialNoModel>/", aColList);
		},
		onMaterialChangeStockSave: function () {
			var oTable = sap.ui.getCore().byId("oRelaseStrtTable").getModel("oSerialNoModel").getData().filter(function (x) {
				return x.Serialno === "";
			});
			if (!oTable.length) {
				var MaintainedSrnoData = sap.ui.getCore().byId("oRelaseStrtTable").getModel("oSerialNoModel").getData();
				MaintainedSrnoData.forEach(function (v) {
					delete v.ID;
				});

				this.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", MaintainedSrnoData);
				this._Dialog1.destroy(true);
				this._Dialog1 = undefined;
			} else {
				sap.m.MessageBox.show(
					"Please enter Serial No.s", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.CLOSE],
						onClose: function (oAction) {}

					}
				);
			}

		},

		oMaintianSerialNoBtnPost: function (Action) {
				var oSeraiNumData=this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");
				oSeraiNumData.forEach(function (v) {
					delete v.ID;
				});
			if (Action === "B" || Action === "U") {
				var oPayload = {
					//	"UserGID": "Z004C4CT",
					//	 "UserGID":  sap.ushell.Container.getService("UserInfo").getId(),
					//	"UserGID": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/UserGID"),
					"MatDesc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MatDesc"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Material"),
					"MsgDesc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MsgDesc"),
					"MsgType1": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/MsgType1"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Sloc"),
					"Specialstockind": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Specialstockind"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStock"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStockNo"),
					//	"SpecialStockNo": "",
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Stockcat"),

					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"SpecialStoc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/SpecialStoc"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/WarehouseNo"),
					"Action": Action,
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Batchno"),
					"Matyear": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matyear"),
					"Matitem": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matitem"),
					"Matdoc": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Matdoc"),
					"Indicator": this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/Indicator"),
					"ITEM_SERIAL_NAV": oSeraiNumData

				};

				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("RELEASE_QI_STOCK_SRV").create("/Item_detailsSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.MsgType1 === "S") {

							that.oBusyDialog.close();
							/*sap.m.MessageBox.success(oData.MsgDesc, {

								actions: ["Go to QI Stock Release", "Close"],
								title: "Success",
								onClose: function (oAction) {

									if (oAction == "Go to QI Stock Release") {

										//	that.onPutawayprocess(oData);
										that.onBack();

									} else {
										that.onBackhome();
									}

								}

							});*/
							if (that.Storagetype === "") {
								sap.m.MessageBox.success(oData.MsgDesc, {
									//actions: ["Go to Putaway process", "Go to QI Stock Release", "Close"],

									actions: ["Go to QI Stock Release", "Close"],
									title: "Success",
									onClose: function (oAction) {

										if (oAction == "Go to QI Stock Release") {

											//	that.onPutawayprocess(oData);
											that.onBack();

										} else {
											that.onBackhome();
										}

									}

								});
							} else if (that.Storagetype === "Q01") {
								sap.m.MessageBox.success(oData.MsgDesc, {
									//actions: ["Go to Putaway process", "Go to QI Stock Release", "Close"],

									actions: ["Go to QI Stock Release", "Go to Putaway", "Close"],
									title: "Success",
									onClose: function (oAction) {

										if (oAction == "Go to QI Stock Release") {

											//	that.onPutawayprocess(oData);
											that.onBack();

										} else if (oAction == "Go to Putaway") {
											that.onPutawayprocess(oData);
										} else {
											that.onBackhome();
										}

									}

								});
							} else if (that.Storagetype === "Q02") {
								sap.m.MessageBox.success(oData.MsgDesc, {
									//actions: ["Go to Putaway process", "Go to QI Stock Release", "Close"],

									actions: ["Go to QI Stock Release", "Go to Bin to Bin", "Close"],
									title: "Success",
									onClose: function (oAction) {

										if (oAction == "Go to QI Stock Release") {

											that.onBack();

										} else if (oAction == "Go to Bin to Bin") {
											that.onBintobin(oData);
										} else {
											that.onBackhome();
										}

									}

								});
							}
						} else {
							that.oBusyDialog.close();
							sap.m.MessageBox.show(
								oData.MsgDesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						sap.m.MessageBox.error("Error");
						that.getOwnerComponent().getModel("localModel").setProperty("/oQistockreleasedData", []);
					}
				});

			}
		},
		onMaterialChangeStockBack: function () {
			this._Dialog1.destroy(true);
			this._Dialog1 = undefined;
		},
		onBackhome: function () {

			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNavigator.toExternal({
				target: {
					semanticObject: "#"
						//	target: {shellHash: "#Shell-home"}
				}
			});

		},
		onPutawayprocess: function (oData) {
			var that = this;
			//	var Gid = that.getOwnerComponent().getModel("localModel").getProperty("/Gid");
			var Matdoc = oData.Matdoc;
			var Matitem = oData.Matitem;
			var Matyear = oData.Matyear;
			var WarehouseNo = this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/WarehouseNo");
			var oCrossAppNavigator = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService && sap.ushell.Container.getService(
				"CrossApplicationNavigation");
			oCrossAppNavigator.isIntentSupported(["ZASP_WM_Putaway-manage"])
				.done(function (aResponses) {

				})
				.fail(function () {
					new sap.m.MessageToast("Provide corresponding intent to navigate");
				});
			// generate the Hash to manage ZASP_WM_Putaway
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "ZASP_WM_Putaway",
					action: "manage"
				},
				params: {
					"Matdoc":(Matdoc * 1).toString(),
					"Matitem": Matitem,
					"Matyear": Matyear,
					"WarehouseNo": WarehouseNo

					/*	"PreviousIntent": window.hasher.getHash().split("-")[0]*/

				}
			})) || "";
			//################ Outbound Navigation################//
			//Generate a  URL for the second application
			//var url = window.location.href.split('#')[0] + hash;
			//Navigate to second app 
			//	sap.m.URLHelper.redirect(url, true);
			//################ Outbound Navigation End################//
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});

		},
		onBintobin: function (oData) {

			var that = this;
			//	var Gid = that.getOwnerComponent().getModel("localModel").getProperty("/Gid");
			var StorageBin = oData.StorageBin;
			var Material = oData.Material;
			var SpecialStock = oData.SpecialStock;
		//	var WarehouseNo = this.getOwnerComponent().getModel("localModel").getProperty("/oQistockreleasedData/WarehouseNo");
			var oCrossAppNavigator = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService && sap.ushell.Container.getService(
				"CrossApplicationNavigation");
			oCrossAppNavigator.isIntentSupported(["ZASP_WM_TRANS_Bin_to_Bin-manage"])
				.done(function (aResponses) {

				})
				.fail(function () {
					new sap.m.MessageToast("Provide corresponding intent to navigate");
				});
			// generate the Hash to manage ZASP_WM_TRANS_Bin_to_Bin
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "ZASP_WM_TRANS_Bin_to_Bin",
					action: "manage"
				},
				params: {

					"StorageBin": StorageBin,
					"Material": (Material*1).toString(),
					"SpecialStock": SpecialStock

					/*	"PreviousIntent": window.hasher.getHash().split("-")[0]*/

				}
			})) || "";
			//################ Outbound Navigation################//
			//Generate a  URL for the second application
			//var url = window.location.href.split('#')[0] + hash;
			//Navigate to second app 
			//	sap.m.URLHelper.redirect(url, true);
			//################ Outbound Navigation End################//
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});

		},
		onBack: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("QIStockReleaseScan", {});
		},
		onChangeValueSN: function (oEvent) {

			var oIndex = parseInt(oEvent.getSource().getBindingContext("oSerialNoModel").getPath().split("/")[1], 10);
			var oStrings = oEvent.getSource().getValue();
			if (oStrings !== "" && oStrings.slice(0, 3) === "]d2") {

				var objArray = parseBarcode(oStrings).parsedCodeItems;

				var obj = jQuery.grep(objArray, function (e) {
					return e.ai === "21";
				})[0];

				if (obj && obj.data && obj.data.length > 0) {
					//sap.m.MessageToast.show("Condition Validate");
					oEvent.getSource().setValue(obj.data);
					if (sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1]) {
						var oId = sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1].getCells()[1].getId();
						jQuery.sap.delayedCall(300, this, function () {
							sap.ui.getCore().byId(oId).focus();
						});
					}
				} else {
					if (obj === undefined) {
						sap.m.MessageToast.show("AI 21 not found in barcode");
						oEvent.getSource().setValue("");
					}

					if (obj.data && obj.data.length === 0) {
						sap.m.MessageToast.show("Serial number value not found in barcode");
						oEvent.getSource().setValue("");
					}
				}
			}
		},

		onlivechekvaluefor: function (oEvent) {
			//console.log(oEvent.which);
			var that = this;
			var sFValue = "";
			sFValue = oEvent.getSource().getValue();
			var sSourceControl = oEvent.getSource();
			var oIndex = oEvent.getSource().getBindingContext("oSerialNoModel").getPath().split("/")[1];
			if (sFValue.length > 0) {
				/*	sap.ui.getCore().byId(oEvent.getSource().getId()).onsapenter = function (e) {
						if (sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1]) {
							sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1].getContent()[0].getItems()[0].focus();
						} else {
							that.onDecodeStringtoValue(sSourceControl, sFValue);
						}
					};*/
				sap.ui.getCore().byId(oEvent.getSource().getId()).onsapenter = function (e) {
					if (sFValue.slice(0, 3) === "]d2") /// read  GS1 data matrix.
					{
						that.onDecodeStringtoValue(sSourceControl, sFValue);
						if (sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1]) {
							//	sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1].getContent()[0].getItems()[0].focus();
							var oId = sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1].getCells()[1].getId();
							jQuery.sap.delayedCall(300, this, function () {
								sap.ui.getCore().byId(oId).focus();
							});
						}

					} else { /// read QR Code..
						var oArrstings;
						oArrstings = sFValue.split("|");
						if (oArrstings.length > 1 && oArrstings[9]) {
							sSourceControl.setValue("");
							sSourceControl.setValue(oArrstings[9]);

						} else if (oArrstings.length === 1) {
							sSourceControl.setValue("");
							sSourceControl.setValue(oArrstings[0]);
						}
						if (sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1]) {
							//	sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1].getContent()[0].getItems()[0].focus();
							var oId = sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1].getCells()[1].getId();
							jQuery.sap.delayedCall(300, this, function () {
								sap.ui.getCore().byId(oId).focus();
							});
						}
					}

				};
			}
		},
		onDecodeStringtoValue: function (oComponent, oStrings) {
			if (oStrings !== "" && oStrings.slice(0, 3) === "]d2") {

				var objArray = parseBarcode(oStrings).parsedCodeItems;

				var obj = jQuery.grep(objArray, function (e) {
					return e.ai === "21";
				})[0];

				if (obj && obj.data && obj.data.length > 0) {
					oComponent.setValue(obj.data);

				} else {
					if (obj === undefined) {
						sap.m.MessageToast.show("AI 21 not found in barcode");
						oComponent.setValue("");
					}

					if (obj.data && obj.data.length === 0) {
						sap.m.MessageToast.show("Serial number value not found in barcode");
						oComponent.setValue("");
					}
				}
			}
		},
		onBarCodeScanInputFields: function (oEvent, oCustomData, Index) {
			this.destinationtype = "";
			this.destinationtype = oCustomData;
			this.desctinationCntl = oEvent.getSource();
			this.oIndex = Index;
			BarcodeScanner.scan(
				this.onSuccess.bind(this),
				this.onError.bind(this)
			);
		},
		// onSuccess Callback 
		onSuccess: function (result) {
			var bCancelled = result.cancelled;
			this.onRetrieveStingFromScannerInfo(result.text);

			if (bCancelled) {
				sap.m.MessageToast.show("Scan Cancelled");
				this.desctinationCntl.setValueHelpOnly(false); // cancel button pressed. allow user to input manually.
			}
		},
		// onError Callback
		onError: function (error) {
			sap.m.MessageToast.show(error, "Error");
		},
		onRetrieveStingFromScannerInfo: function (oStirngs) {

			var oArrstings;
			switch (this.destinationtype) {

			case "SerialNo":

				if (oStirngs.slice(0, 1) === "\x1D") {
					var oResult = "]d2" + oStirngs.replaceAll("\x1D", "|");
					var objArray = parseBarcode(oResult).parsedCodeItems;

					var obj = jQuery.grep(objArray, function (e) {
						return e.ai === "21";
					})[0];
					if (obj && obj.data && obj.data.length > 0) {
						this.desctinationCntl.setValue(obj.data);
						if (sap.ui.getCore().byId("oRelaseStrtTable").getItems()[this.oIndex + 1]) {
							var oId = sap.ui.getCore().byId("oRelaseStrtTable").getItems()[this.oIndex + 1].getCells()[1].getId();
							jQuery.sap.delayedCall(300, this, function () {
								sap.ui.getCore().byId(oId).focus();
							});
						}
					} else {
						if (obj === undefined) {
							sap.m.MessageToast.show("AI 21 not found in barcode");
							this.desctinationCntl.setValue("");
						}
					}
				} else {
					oArrstings = oStirngs.split("|");
					if (oArrstings.length > 1 && oArrstings[9]) {
						this.desctinationCntl.setValue("");
						this.desctinationCntl.setValue(oArrstings[9]);
					} else if (oArrstings.length === 1) {
						this.desctinationCntl.setValue("");
						this.desctinationCntl.setValue(oArrstings[0]);
					}
					if (sap.ui.getCore().byId("oRelaseStrtTable").getItems()[this.oIndex + 1]) {
						var oId = sap.ui.getCore().byId("oRelaseStrtTable").getItems()[this.oIndex + 1].getCells()[1].getId();
						jQuery.sap.delayedCall(300, this, function () {
							sap.ui.getCore().byId(oId).focus();
						});
					}
				}

				break;

			default:
				// code block
			}
		},
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.view.QIStockReleaseDispaly
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.view.QIStockReleaseDispaly
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.view.QIStockReleaseDispaly
		 */
		//	onExit: function() {
		//
		//	}

	});

});