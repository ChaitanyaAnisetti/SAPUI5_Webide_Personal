sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"Releaseqistock/SIE_ASP_WM_RELEASE_QI_STOCK/model/models",
	"sap/ui/model/json/JSONModel",
	"./util/FioriClient"
], function (UIComponent, Device, models, JSONModel, FioriClient) {
	"use strict";

	return UIComponent.extend("Releaseqistock.SIE_ASP_WM_RELEASE_QI_STOCK.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();
			this._oFioriClient = new FioriClient();
			var oLocalSet = new JSONModel();
			oLocalSet.setSizeLimit(10000);
			this.setModel(oLocalSet, "localModel");
         	var Gid ="";
			if(sap&&sap.ushell){
		    Gid = sap.ushell.Container.getService("UserInfo").getId();
		    //  Gid = "Z004C4CT";
		//   Gid = "Z003DXZR";
			}
			else{
		   //Gid = "Z004C4CT"; /* Gid for local testing*/
		     Gid = "Z003DXZR";
		}
			this.getModel("localModel").setProperty("/Gid", Gid);
			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
		},
		getFioriClient: function() {
			return this._oFioriClient;
		}
	});
});