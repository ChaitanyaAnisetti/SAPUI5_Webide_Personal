sap.ui.define(function () {
	var Formatter = {

		Material: function (Material) {

			if (Material) {

				return (Material * 1).toString();
			} else {
				return "";
			}

		}

	};

	return Formatter;
}, true);