sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageBox',
	'sap/m/MessagePopover',
	'sap/m/MessageItem',
	"sap/ui/model/json/JSONModel",
	"sap/ndc/BarcodeScanner",
     "sap/m/library",
     "putaway/SIE_ASP_WM_PutawayProcess/Formatter/Formatter"
], function (Controller, MessageBox, MessagePopover, MessageItem, JSONModel, BarcodeScanner, mobileLibrary,Formatter) {
	"use strict";

	return Controller.extend("putaway.SIE_ASP_WM_PutawayProcess.controller.PutawayConfirmto", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf putaway.SIE_ASP_WM_PutawayProcess.view.PutawayConfirmto
		 */
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oFioriClient = this.getOwnerComponent().getFioriClient();
			oRouter.getRoute("PutawayConfirmto").attachPatternMatched(this._onObjectMatched, this);
			this.oBusyDialog = new sap.m.BusyDialog();
		//	sap.ui.getCore().byId("oConfirmbin").setValue("");
		},
		_onObjectMatched: function (oEvent) {
				var oViewModel = new JSONModel({
				isFioriClientAvailable: this.oFioriClient.isAvailable()
			//	isFioriClientAvailable:true
			});
			this.getView().setModel(oViewModel, "PutawayConfirmto");
			//sap.ui.getCore().byId("oConfirmbin").setValue("");
			if (oEvent.getParameter("arguments").WarehouseNo && oEvent.getParameter("arguments").Matdoc) {
				var WarehouseNo = oEvent.getParameter("arguments").WarehouseNo || "";
				var Matdoc = oEvent.getParameter("arguments").Matdoc || "";
				var Matyear = oEvent.getParameter("arguments").Matyear || "";
				var Material = oEvent.getParameter("arguments").Material || "";
				var TOitem = oEvent.getParameter("arguments").TOitem || "";
				var TOno = oEvent.getParameter("arguments").TOno || "";
				this.WarehouseNo = WarehouseNo;
				this.oBusyDialog.open();
				var oBindingInfo = {
					success: function (oData, oResponse) {
						this.oBusyDialog.close();
						this.getOwnerComponent().getModel("localModel").setProperty("/PutawayMaterialProcess", oData);
						this.onCreateGridLayout();
					}.bind(this),
					error: function (oError) {
						this.oBusyDialog.close();
						this.getOwnerComponent().getModel("localModel").setProperty("/PutawayMaterialProcess", "");
					}.bind(this)
				};
 
				this.getOwnerComponent().getModel("ASP_WM_PUTAWAY").read("/Putaway_detailsSet(WarehouseNo='" + WarehouseNo +
					"',TOno='" + TOno + "',TOitem='" + TOitem + "')", oBindingInfo);

			}
		},
			onCreateGridLayout:function(){
			
			var that = this;
			var oHbox = this.getView().byId("hBoxConfirmBin");
				oHbox.destroyItems();
		   var oCinfirmLabel,OConfirmInput;
			/* oHbox.addItem(
									new sap.m.Label({
										text:"{i18n>view2.ConfirmBin}"
									}) 
			); */
		
			if(this.getView().getModel("PutawayConfirmto").getProperty("/isFioriClientAvailable"))
			{
					if(sap.ui.getCore().byId("oConfirmbin")){
					sap.ui.getCore().byId("oConfirmbin").destroy(true);
				}
				OConfirmInput = new sap.m.Input("oConfirmbin",{
											enabled :true,
											editable:true,
											value:"",
											showValueHelp:true,
											valueHelpOnly:false,
											change:function(ovt){
												that.onChangeConfirmbin(ovt);
											},
											liveChange:function(ovt)
			                                {
			                                		that.onlivechekvalueConfirmbin(ovt);
			                                },
											valueHelpRequest:function(ovt){
												that.onBarCodeScanInputFields(ovt,"confirmBin");
											}
										}).addEventDelegate({
													onfocusin: function(oEvt) 
													{ 
														var oComId = oEvt.srcControl.getId();
														jQuery("#"+oComId).scannerDetection({
																		timeBeforeScanTest: 200, // wait for the next character for upto 200ms
																		//startChar: [120], // Prefix character for the cabled scanner (OPL6845R)
																		endChar: [13], // be sure the scan is complete if key 13 (enter) is detected
																		avgTimeByChar: 40, // it's not a barcode if a character takes longer than 40ms
																		onComplete: function(barcode, qty)
																		{
																			
																			var oArrstings;
																	    	oArrstings = barcode.split("|");
																	    	jQuery("#"+oEvt.srcControl.getId()).find('input').val("");
																	    	jQuery("#"+oEvt.srcControl.getId()).find('input').val(oArrstings[0]);
																	    	
							
																		}, // main callback function
																		onError: function(string){ 
																			//console.log("Error:" + string);
																		}
														});
														
													},
													onsapfocusleave: function(oEvt) { 
														var oComId = oEvt.srcControl.getId();
														jQuery("#"+oComId).scannerDetection(false);
													}
											});
				OConfirmInput._getValueHelpIcon().setSrc("sap-icon://bar-code");
				oHbox.addItem(OConfirmInput);
			}else{
				if(sap.ui.getCore().byId("oConfirmbin")){
					sap.ui.getCore().byId("oConfirmbin").destroy(true);
				}
				OConfirmInput = new sap.m.Input("oConfirmbin",{value:""});
				oHbox.addItem(OConfirmInput);
			
			}
		},
			onlivechekvalueConfirmbin:function(oEvent){
			var that = this;
				var sFValue = "";
					sFValue = oEvent.getSource().getValue();
				var	sSourceControl = oEvent.getSource(); 

					if(sFValue.length > 0 ) 
					{
							sap.ui.getCore().byId(oEvent.getSource().getId()).onsapenter = function(e)
							{
									
									if(sFValue.slice(0,3) === "]d2") /// read  GS1 data matrix.
									{
										that.onDecodeStringtoValue(sSourceControl,sFValue);
									
									}else
									{  /// read QR Code..
										var oArrstings;
										if(oArrstings.length > 1 &&  oArrstings[4])
										{
											sSourceControl.setValue("");
							    			sSourceControl.setValue(oArrstings[4]);
							    			that.onChangeConfirmbin(new sap.ui.base.Event("PutawayconfirmBin", sSourceControl, {}));
										}else if(oArrstings.length === 1){
											sSourceControl.setValue("");
							    			sSourceControl.setValue(oArrstings[0]);
							    			that.onChangeConfirmbin(new sap.ui.base.Event("PutawayconfirmBin", sSourceControl, {}));
										}
										
										
									}
									
							};
					}
		},
			onDecodeStringtoValue:function(oComponent,oStrings){
			//sap.m.MessageToast.show("onDecoder funciton");
			if(oStrings !== "" && oStrings.slice(0, 3) === "]d2")
			{
				
					sap.m.MessageBox.warning("Please scan valid Barcode");
			/*
				var objArray = parseBarcode(oStrings).parsedCodeItems;
				var obj = jQuery.grep(objArray, function(e){return e.ai === "91";})[0];
				if(obj && obj.data && obj.data.length > 0 )
				{
					oComponent.setValue(obj.data);
					this.onChangeMaterialNumber(new sap.ui.base.Event("PutawayconfirmBin", oComponent, {}));			
				}else
				{
					if(obj === undefined){
						sap.m.MessageToast.show("AI 91 not found in barcode");
						oComponent.setValue("");
					}
									
					if(obj.data && obj.data.length === 0){
						sap.m.MessageToast.show("Material number value not found in barcode");
						oComponent.setValue("");
					}
				}*/
			}
		},
			onChangeConfirmbin:function(oEvent){
				
				var sFValue = "";
					sFValue = oEvent.getSource().getValue();
				var	sSourceControl = oEvent.getSource(); 
				if(sFValue.length <= 10){
					sSourceControl.setValueState("None");	
				}else if (sFValue.length > 10){
					sSourceControl.setValueState("Error");
					sap.m.MessageToast.show("Confirm bin no. max length is 10");
				}
					
		},
			onRetrieveStingFromScannerInfo:function(oStirngs) {
			
				var oArrstings;
				switch(this.destinationtype) {
				 
				  case "confirmBin":
				  		
			
				  		if(oStirngs.slice(0,1) === "\x1D")
						{
								sap.m.MessageBox.warning("Please scan valid Barcode");
						/*
							var oResult ="]d2"+oStirngs.replaceAll("\x1D","|");
							var objArray = parseBarcode(oResult).parsedCodeItems;
							var obj = jQuery.grep(objArray, function(e){return e.ai === "91";})[0];
							if(obj && obj.data && obj.data.length > 0 )
							{
								this.desctinationCntl.setValue(obj.data);
								this.onChangeConfirmbin(new sap.ui.base.Event("PutawayconfirmBin", this.desctinationCntl, {}));
												
							}else
							{
								if(obj === undefined){
									sap.m.MessageToast.show("AI 91 not found in barcode");
									this.desctinationCntl.setValue("");
								}
												
								if(obj.data && obj.data.length === 0){
									sap.m.MessageToast.show("Confirm bin not found in barcode");
									this.desctinationCntl.setValue("");
								}
							}
						*/}else{
							oArrstings = oStirngs.split("|");
							if(oArrstings.length === 1 &&  oArrstings[0]){
								this.desctinationCntl.setValue("");
				    			this.desctinationCntl.setValue(oArrstings[0]);
				    			this.onChangeConfirmbin(new sap.ui.base.Event("PutawayconfirmBin", this.desctinationCntl, {}));
							}else if(oArrstings.length === 1){
								this.desctinationCntl.setValue("");
				    			this.desctinationCntl.setValue(oArrstings[0]);
				    			this.onChangeConfirmbin(new sap.ui.base.Event("PutawayconfirmBin", this.desctinationCntl, {}));
							}
							
						}
				  		
				    break;
				 
				  default:
				    // code block
				}
		},
		// onError Callback
	/*	onError: function (error) {
			sap.m.MessageToast.show(error, "Error");
		},*/
			onBarCodeScanInputFields: function(oEvent,oCustomData) 
		{
				 this.destinationtype = "";
				 this.destinationtype = oCustomData;
				 this.desctinationCntl = oEvent.getSource();
				
				BarcodeScanner.scan(
						this.onSuccess.bind(this),
						this.onError.bind(this)
				);
		},
			// onSuccess Callback 
		onSuccess: function(result) {
					var bCancelled = result.cancelled;
					this.onRetrieveStingFromScannerInfo(result.text);
					
					if (bCancelled) {
						sap.m.MessageToast.show("Scan Cancelled");
						this.desctinationCntl.setValueHelpOnly(false);  // cancel button pressed. allow user to input manually.
					}
		},
		// onError Callback
		onError: function(error) {
					sap.m.MessageToast.show(error, "Error");
		},
		
		onPressback: function () {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Putawaymain", {
				
				WarehouseNo: this.WarehouseNo

			});
		},

		onConfirmTO: function () {
			
			if(sap.ui.getCore().byId("oConfirmbin").getValue()===""){
				MessageBox.warning("Empty value cannot be processed, please enter valid Bin");
				return;
			}

			var oPayload = {

				"UserGID": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/UserGID"),
				"MatDesc": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/MatDesc"),
				"Material": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/Material"),
				"MsgDesc": "",
				"MsgType1": "",
				"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/Plant"),
				"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/Sloc"),
				"Qty": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/Qty"),
				"QtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/QtyUOM"),
				"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/Stockcat"),
				"SpecialStoc": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/SpecialStoc"),
				"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/StorageBin"),
				"StorageBindes": sap.ui.getCore().byId("oConfirmbin").getValue(),
				"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/WarehouseNo"),
				"TOno": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/TOno"),
				"TOitem": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/TOitem"),
				"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/PutawayMaterialProcess/Batchno")

			};
			this.oBusyDialog.open();
			var that = this;

			this.getOwnerComponent().getModel("ASP_WM_PUTAWAY").create("/Putaway_detailsSet", oPayload, {
				success: function (oData, oResponse) {

					if (oData.MsgType1 === "S" || oData.MsgType1 === "") {
					sap.ui.getCore().byId("oConfirmbin").setValue("");

						that.oBusyDialog.close();
						sap.m.MessageBox.success(oData.MsgDesc, {

							actions: ["Back to Main Menu"],
							title: "Success",
							onClose: function (oAction) {

								if (oAction === "Back to Main Menu") {
                          that.getOwnerComponent().getModel("localModel").setProperty("/pressBack","X");
									that.onPressback();

								} else {
								//	that.onBackmainmenu();
								}

							}

						});
					} else {

						that.oBusyDialog.close();
						sap.m.MessageBox.show(
							oData.MsgDesc, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Error",
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);
					}
				},
				error: function (oError) {
					that.oBusyDialog.close();
					var sMsg;
				if (oError.responseText && JSON.parse(oError.responseText).error && JSON.parse(oError.responseText).error.message) {
					sMsg = JSON.parse(oError.responseText).error.message.value;
				}
				else{
					sMsg="Error";
				}
					sap.m.MessageBox.error(sMsg);
					
				}
			});

		},

		onBackmainmenu: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Putawaymain", {

			});

		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf putaway.SIE_ASP_WM_PutawayProcess.view.PutawayConfirmto
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf putaway.SIE_ASP_WM_PutawayProcess.view.PutawayConfirmto
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf putaway.SIE_ASP_WM_PutawayProcess.view.PutawayConfirmto
		 */
		//	onExit: function() {
		//
		//	}

	});

});