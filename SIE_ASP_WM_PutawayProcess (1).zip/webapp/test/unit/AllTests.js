sap.ui.define([
	"putaway/SIE_ASP_WM_PutawayProcess/test/unit/controller/View1.controller"
], function () {
	"use strict";
});