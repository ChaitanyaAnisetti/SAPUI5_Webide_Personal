jQuery.sap.require("sap.ui.core.format.NumberFormat");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageBox',
	'sap/m/MessagePopover',
	'sap/m/MessageItem',
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
		"sap/ndc/BarcodeScanner",
		"sap/m/library"
], function (Controller, MessageBox, MessagePopover, MessageItem, JSONModel, MessageToast,BarcodeScanner,library) {
	"use strict";

	return Controller.extend("SIE_ASP_WM_Stock_update.SIE_ASP_WM_Stock_update.controller.ChangestockcatDisplay", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf SIE_ASP_WM_Stock_update.SIE_ASP_WM_Stock_update.view.ChangestockcatDisplay
		 */
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("ChangestockcatDisplay").attachPatternMatched(this._onObjectMatched, this);
			this.oBusyDialog = new sap.m.BusyDialog();
				var oViewModel = new JSONModel({
					//isFioriClientAvailable: this.oFioriClient.isAvailable(),
					isFioriClientAvailable: true
				});
				this.getView().setModel(oViewModel, "objectView");
		},
		_onObjectMatched: function (oEvent) {

			if (oEvent.getParameter("arguments").WarehouseNo && oEvent.getParameter("arguments").Plant) {
				this.WarehouseNo = oEvent.getParameter("arguments").WarehouseNo || "";
				this.Plant = oEvent.getParameter("arguments").Plant || "";
				this.StorageBin = oEvent.getParameter("arguments").StorageBin || "";
				this.Material = oEvent.getParameter("arguments").Material || "";
				this.Sloc = oEvent.getParameter("arguments").Sloc || "";
				this.Batchno = oEvent.getParameter("arguments").Batchno || "";
				this.SpecialStock = oEvent.getParameter("arguments").SpecialStoc || "";
				var Stockcat = oEvent.getParameter("arguments").Stockcat || "";
				var SpecialStockIndicator = "";
				this.SpecialStockNo = "";
				if (this.SpecialStock != "" && this.SpecialStock != "undefined") {
					SpecialStockIndicator = this.SpecialStock.split(" ")[0];
					this.SpecialStockNo = this.SpecialStock.split(" ")[1];
				}
				this.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", null);
				var Indicator = oEvent.getParameter("arguments").Indicator || "";
				this.getOwnerComponent().getModel("localModel").setProperty("/Indicator", Indicator);
				var SelectedCategoryBtn = oEvent.getParameter("arguments").SelectedCategoryBtn;
				if (SelectedCategoryBtn === "Change Stock Category") {
					if (SelectedCategoryBtn === "Change Stock Category" && Stockcat === "Q") {
						this.getView().byId("oBtnQitour").setVisible(true);
						this.getView().byId("oBtnQItoBlock").setVisible(true);
						this.getView().byId("oBtnURtoQI").setVisible(false);
						this.getView().byId("oBtnURtoBlock").setVisible(false);
						this.getView().byId("oBtnBlocktoUR").setVisible(false);
						this.getView().byId("oBtnBlocktoQI").setVisible(false);
					} else if (SelectedCategoryBtn === "Change Stock Category" && Stockcat === "") {
						this.getView().byId("oBtnQitour").setVisible(false);
						this.getView().byId("oBtnQItoBlock").setVisible(false);
						this.getView().byId("oBtnURtoQI").setVisible(true);
						this.getView().byId("oBtnURtoBlock").setVisible(true);
						this.getView().byId("oBtnBlocktoUR").setVisible(false);
						this.getView().byId("oBtnBlocktoQI").setVisible(false);
					} else if (SelectedCategoryBtn === "Change Stock Category" && Stockcat === "S") {
						this.getView().byId("oBtnQitour").setVisible(false);
						this.getView().byId("oBtnQItoBlock").setVisible(false);
						this.getView().byId("oBtnURtoQI").setVisible(false);
						this.getView().byId("oBtnURtoBlock").setVisible(false);
						this.getView().byId("oBtnBlocktoUR").setVisible(true);
						this.getView().byId("oBtnBlocktoQI").setVisible(true);
					}
				} else {
					this.getView().byId("oBtnQitour").setVisible(false);
					this.getView().byId("oBtnQItoBlock").setVisible(false);
					this.getView().byId("oBtnURtoQI").setVisible(false);
					this.getView().byId("oBtnURtoBlock").setVisible(false);
					this.getView().byId("oBtnBlocktoUR").setVisible(false);
					this.getView().byId("oBtnBlocktoQI").setVisible(false);
				}
				this.getOwnerComponent().getModel("localModel").setProperty("/SelectedCategoryBtn", SelectedCategoryBtn);
				this.getOwnerComponent().getModel("localModel").setProperty("/SpecialStockIndicator", SpecialStockIndicator);
				this.getOwnerComponent().getModel("localModel").setProperty("/SpecialStockNo", this.SpecialStockNo);
				//	this.Batchno = "";
				var that = this;
				if (SelectedCategoryBtn === "Change Stock Category") {
					this.oBusyDialog.open();
					var Tr = "Stockcat eq '" + Stockcat + "'";
					var oBindingInfo = {
						filters: null,
						urlParameters: {
							"$filter": Tr
						},
						success: function (oData, oResponse) {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", oData);
						},
						error: function (oError) {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
						}
					};

					this.getOwnerComponent().getModel("STOCK_INFO_SRV").read("/ItemDetailSet(WarehouseNo='" + this.WarehouseNo +
						"',StorageBin='" + this.StorageBin + "',Material='" + this.Material + "',Plant='" + this.Plant +
						"',Sloc='" + this.Sloc + "',SpecialStockNo='" + this.SpecialStock + "',Batchno='" + this.Batchno +
						"')/?$expand=ITEM_SERIAL_NAV", oBindingInfo);
				} else if (SelectedCategoryBtn === "Change Batch Number") {

					this.oBusyDialog.open();
					var oBindingInfo = {

						success: function (oData, oResponse) {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", oData);
						},
						error: function (oError) {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
						}
					};

					//	this.getOwnerComponent().getModel("STOCK_INFO_SRV").read("/ItemDetailSet(WarehouseNo='A03',StorageBin='65A',Material='100000063',Plant='9DB3',Sloc='0001',SpecialStockNo='',Batchno='0000000651')/?$expand=ITEM_SERIAL_NAV,ITEMTOBATCH_NAV",oBindingInfo);

					this.getOwnerComponent().getModel("STOCK_INFO_SRV").read("/ItemDetailSet(WarehouseNo='" + this.WarehouseNo +
						"',StorageBin='" + this.StorageBin + "',Material='" + this.Material + "',Plant='" + this.Plant +
						"',Sloc='" + this.Sloc + "',SpecialStockNo='" + this.SpecialStock + "',Batchno='" + this.Batchno +
						"')/?$expand=ITEM_SERIAL_NAV", oBindingInfo);
				} else if (SelectedCategoryBtn === "Change Special Stock") {

					this.oBusyDialog.open();
					var oBindingInfo = {

						success: function (oData, oResponse) {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", oData);
						},
						error: function (oError) {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
						}
					};

					/*	this.getOwnerComponent().getModel("STOCK_INFO_SRV").read("/ItemDetailSet(WarehouseNo='" + this.WarehouseNo +
							"',StorageBin='" + this.StorageBin + "',Material='" + this.Material + "',Plant='" + this.Plant +
							"',Sloc='" + this.Sloc + "',SpecialStockNo='" + this.SpecialStockNo + "',Batchno='" + this.Batchno +
							"')/?$expand=ITEM_SERIAL_NAV", oBindingInfo);*/

					this.getOwnerComponent().getModel("STOCK_INFO_SRV").read("/ItemDetailSet(WarehouseNo='" + this.WarehouseNo +
						"',StorageBin='" + this.StorageBin + "',Material='" + this.Material + "',Plant='" + this.Plant +
						"',Sloc='" + this.Sloc + "',SpecialStockNo='" + this.SpecialStock + "',Batchno='" + this.Batchno +
						"')/?$expand=ITEM_SERIAL_NAV", oBindingInfo);

				}

			}
		},
		onQitour: function () {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("U");
			} else {
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					//	"SpecialStockNo": "",
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					//	"Stockcat": "",
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": "U",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": [],
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": {}

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.Msgtype === "S") {

							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.success(oData.Msgdesc, {

								actions: ["Change Stock Category", "Go Back to Main Menu"],
								title: "Change Stock Category",
								onClose: function (oAction) {

									if (oAction == "Change Stock Category") {

										that.ChangeStockcategory();

									} else {
										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.show(
								oData.Msgdesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
					}
				});
			}

		},
		onURtoQI: function () {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("U");
			} else {
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					//	"Stockcat": "",
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": "U",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": [],
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": {}

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.Msgtype === "S") {

							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.success(oData.Msgdesc, {

								actions: ["Change Stock Category", "Go Back to Main Menu"],
								title: "Change Stock Category",
								onClose: function (oAction) {

									if (oAction == "Change Stock Category") {

										that.ChangeStockcategory();

									} else {
										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.show(
								oData.Msgdesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
						that.oBusyDialog.close();
						that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
					}
				});
			}

		},
		onURtoBlock: function () {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("Q");
			} else {
				var oPayload = {

					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					//	"Stockcat": "",
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": "Q",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": [],
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": {}

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.Msgtype === "S") {
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							that.oBusyDialog.close();
							sap.m.MessageBox.success(oData.Msgdesc, {

								actions: ["Change Stock Category", "Go Back to Main Menu"],
								title: "Change Stock Category",
								onClose: function (oAction) {

									if (oAction == "Change Stock Category") {

										that.ChangeStockcategory();

									} else {
										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.show(
								oData.Msgdesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
						that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
					}
				});
			}

		},
		onBlocktoUR: function () {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("U");
			} else {
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					//	"Stockcat": "",
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": "U",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": [],
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": {}

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.Msgtype === "S") {
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							that.oBusyDialog.close();
							sap.m.MessageBox.success(oData.Msgdesc, {

								actions: ["Change Stock Category", "Go Back to Main Menu"],
								title: "Change Stock Category",
								onClose: function (oAction) {

									if (oAction == "Change Stock Category") {

										that.ChangeStockcategory();

									} else {
										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.show(
								oData.Msgdesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
						that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
					}
				});
			}
		},
		onBlocktoQI: function () {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("Q");
			} else {
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					//	"Stockcat": "",
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": "Q",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": [],
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": {}

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.Msgtype === "S") {
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							that.oBusyDialog.close();
							sap.m.MessageBox.success(oData.Msgdesc, {

								actions: ["Change Stock Category", "Go Back to Main Menu"],
								title: "Change Stock Category",
								onClose: function (oAction) {

									if (oAction == "Change Stock Category") {

										that.ChangeStockcategory();

									} else {
										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.show(
								oData.Msgdesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
						that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
					}
				});
			}
		},

		onSerialnoSave: function () {

		},
		onMaterialChangeStockSave: function () {
			var oTable = sap.ui.getCore().byId("oRelaseStrtTable").getModel("oSerialNoModel").getData().filter(function (x) {
				return x.Serialno === "";
			});
			if (!oTable.length) {
				var MaintainedSrnoData = sap.ui.getCore().byId("oRelaseStrtTable").getModel("oSerialNoModel").getData();
				MaintainedSrnoData.forEach(function(v){
            delete v.ID;
            });
				this.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", MaintainedSrnoData);
				//	this.oMaintianSerialNoBtnPost();
				this._Dialog1.destroy(true);
				this._Dialog1 = undefined;
			} else {
				sap.m.MessageBox.show(
					"Please enter valid Serial No.s", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.CLOSE],
						onClose: function (oAction) {}
					}
				);
			}

		},
		onMaterialChangeStockBack: function () {
			this._Dialog1.destroy(true);
			this._Dialog1 = undefined;
		},

		onQItoBlock: function () {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("Q");
			} else {
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					//	"Stockcat": "",
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": "Q",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": [],
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": {}
				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.Msgtype === "S") {
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							that.oBusyDialog.close();
							sap.m.MessageBox.success(oData.Msgdesc, {

								actions: ["Change Stock Category", "Go Back to Main Menu"],
								title: "Change Stock Category",
								onClose: function (oAction) {

									if (oAction == "Change Stock Category") {

										that.ChangeStockcategory();

									} else {

										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.show(
								oData.Msgdesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}

					},
					error: function (oError) {
						that.oBusyDialog.close();
						that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
					}
				});
			}

		},

		ChangeStockcategory: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ChangeStockcategory", {

			});

		},
		onBack: function () {

			/*	this._Dialog.destroy(true);
				this._Dialog = undefined;*/

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ChangeStockInfo", {

			});

		},
		onStockQunatitychange: function (oEvt) {

			var sValue1 = oEvt.getParameter("value");
			var sValue = Number(sValue1).toFixed(3);
			this.getView().byId("oStockQty").setText(sValue);
			oEvt.getSource().setValue(sValue);
		},
		onMaintainserialno: function () {
			var that = this;
			var oVal = this.getView().byId("oStockQtychange").getValue();
			var bindVal = "";
			if (oVal) {
				oVal = Number(Number(oVal).toFixed(0));
				if (oVal <= 1) {
					var loopoVal = 1;
					//	bindVal = oVal;
				} else {
					var loopoVal = oVal;
				}
			} else {
				loopoVal = 0;
			}
			if (!this._Dialog1) {
				this._Dialog1 = sap.ui.xmlfragment(
					"SIE_ASP_WM_Stock_update.SIE_ASP_WM_Stock_update.Fragment.MultipleQuantitieRows",
					this
				);
				this.getView().addDependent(this._Dialog1);
			}
			this._Dialog1.open();
			var oTable = sap.ui.getCore().byId("oRelaseStrtTable");
			var oColumn1 = new sap.m.Column({
				header: new sap.m.Label({
					text: "ID"
				})
			});
			var oColumn2 = new sap.m.Column({
				header: new sap.m.Label({
					text: "Serial No.s",
					required: true
				})
			});

			oTable.addColumn(oColumn1);
			oTable.addColumn(oColumn2);

			var oCell = [];
			var Data = [];
			var cell1 = new sap.m.Label({
				text: "{oSerialNoModel>ID}",
				design: "Bold"
			});
			var cell2 = new sap.m.Input({
				//	maxLength:18,
				placeholder: "Maintain SN ",
				value: "{oSerialNoModel>Serialno}",
				icon: "sap-icon://bar-code",
				showValueHelp: true,
				valueHelpOnly: false,
				valueHelpRequest: function (ovt) {
					that.onBarCodeScanInputFields(ovt, "SerialNo");
				},
				change: function (oEvt) {
					that.onChangeValueSN(oEvt);
				},
				liveChange: function (ovt) {
					that.onlivechekvaluefor(ovt);
				}
			}).addEventDelegate({
				onfocusin: function (oEvt) {

					var oComId = oEvt.srcControl.getId();
					var oIndex = parseInt(sap.ui.getCore().byId(oComId).getBindingContext("oSerialNoModel").getPath().split("/")[2], 10);

					jQuery("#" + oComId).scannerDetection({
						timeBeforeScanTest: 200, // wait for the next character for upto 200ms
						//startChar: [120], // Prefix character for the cabled scanner (OPL6845R)
						//endChar: [9,10,13,126], // be sure the scan is complete if key 13 (enter) is detected
						endChar: [13], // be sure the scan is complete if key 13 (enter) is detected
						avgTimeByChar: 40, // it's not a barcode if a character takes longer than 40ms
						onComplete: function (barcode, qty) {
						//	sap.ui.getCore().byId(oComId).setValue(barcode);
							var oArrstings;
											oArrstings = barcode.split("|");
											jQuery("#"+oEvt.srcControl.getId()).find('input').val("");
										jQuery("#"+oEvt.srcControl.getId()).find('input').val(oArrstings[9]);
							if (sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1]) {
								sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1].getContent()[0].getItems()[0].focus();
							}

						}, // main callback function
						onError: function (string) {
							//console.log("Error:" + string);
						}
					});

					//that.onDetecScanner(oEvt.srcControl.getId(),true);
				},
				onsapfocusleave: function (oEvt) {
					var oComId = oEvt.srcControl.getId();
					jQuery("#" + oComId).scannerDetection(false);

				}
			});
			cell2._getValueHelpIcon().setSrc("sap-icon://bar-code");
			oCell.push(cell1);
			oCell.push(cell2);

			for (var i = 0; i < loopoVal; i++) {
				var obj = {
					"Serialno": bindVal,
					"ID": i + 1
				};
				Data.push(obj);
			}
			var Model = new sap.ui.model.json.JSONModel(Data);
			oTable.setModel(Model, "oSerialNoModel");
			var aColList = new sap.m.ColumnListItem("", {
				cells: oCell
			});
			oTable.bindItems("oSerialNoModel>/", aColList);
		},
		onPressback: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ChangeStockcategory", {

			});

		},
		onMaterialChangeStockClear: function () {
			var that = this;
			var oVal = this.getView().byId("oStockQtychange").getValue();
			var bindVal="";
			if (oVal) {
				oVal = Number(Number(oVal).toFixed(0));
				if (oVal <= 1) {
					var loopoVal = 1;
					//	bindVal = oVal;
				} else {
					var loopoVal = oVal;
				}
			} else {
				var loopoVal = 0;
			}

			var oTable = sap.ui.getCore().byId("oRelaseStrtTable");
			oTable.destroyItems();
			oTable.unbindItems();
			oTable.removeAllColumns();
			var oColumn1 = new sap.m.Column({
				header: new sap.m.Label({
					text: "ID"
				})
			});
			var oColumn2 = new sap.m.Column({
				header: new sap.m.Label({
					text: "Serial No.s",
					required: true
				})
			});

			oTable.addColumn(oColumn1);
			oTable.addColumn(oColumn2);

			var oCell = [];
			var Data = [];
			var cell1 = new sap.m.Label({
				text: "{oSerialNoModel>ID}",
				design: "Bold"
			});
			var cell2 = new sap.m.Input({
				//	maxLength:18,
				placeholder: "Maintain SN ",
				value: "{oSerialNoModel>Serialno}",
				icon: "sap-icon://bar-code",
				showValueHelp: true,
				valueHelpOnly: false,
				valueHelpRequest: function (ovt) {
					that.onBarCodeScanInputFields(ovt, "SerialNo");
				},
				change: function (oEvt) {
					that.onChangeValueSN(oEvt);
				},
				liveChange: function (ovt) {
					that.onlivechekvaluefor(ovt);
				}
			}).addEventDelegate({
				onfocusin: function (oEvt) {

					var oComId = oEvt.srcControl.getId();
					var oIndex = parseInt(sap.ui.getCore().byId(oComId).getBindingContext("oSerialNoModel").getPath().split("/")[2], 10);

					jQuery("#" + oComId).scannerDetection({
						timeBeforeScanTest: 200, // wait for the next character for upto 200ms
						//startChar: [120], // Prefix character for the cabled scanner (OPL6845R)
						//endChar: [9,10,13,126], // be sure the scan is complete if key 13 (enter) is detected
						endChar: [13], // be sure the scan is complete if key 13 (enter) is detected
						avgTimeByChar: 40, // it's not a barcode if a character takes longer than 40ms
						onComplete: function (barcode, qty) {
						var	oArrstings = barcode.split("|");
											jQuery("#"+oEvt.srcControl.getId()).find('input').val("");
										jQuery("#"+oEvt.srcControl.getId()).find('input').val(oArrstings[9]);
							if (sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1]) {
								sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1].getContent()[0].getItems()[0].focus();
							}

						}, // main callback function
						onError: function (string) {
							//console.log("Error:" + string);
						}
					});

					//that.onDetecScanner(oEvt.srcControl.getId(),true);
				},
				onsapfocusleave: function (oEvt) {
					var oComId = oEvt.srcControl.getId();
					jQuery("#" + oComId).scannerDetection(false);

				}
			});
			cell2._getValueHelpIcon().setSrc("sap-icon://bar-code");
			oCell.push(cell1);
			oCell.push(cell2);

			for (var i = 0; i < loopoVal; i++) {
				var obj = {
					"Serialno": bindVal,
					"ID": i + 1
				};
				Data.push(obj);
			}
			var Model = new sap.ui.model.json.JSONModel(Data);
			oTable.setModel(Model, "oSerialNoModel");
			var aColList = new sap.m.ColumnListItem("", {
				cells: oCell
			});
			oTable.bindItems("oSerialNoModel>/", aColList);
		},
		onChangebatchno: function (oEvent) {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else {
				if (!this._DialogCB) {
					this._DialogCB = sap.ui.xmlfragment(
						"SIE_ASP_WM_Stock_update.SIE_ASP_WM_Stock_update.Fragment.ChangebatchNo_ChngBtchNo",
						this
					);
					this.getView().addDependent(this._DialogCB);
				}
				this.CreateNewBatchNo();
				this._DialogCB.open();
			}

		},
		CreateNewBatchNo:function(){
			var VboxNewbatch=sap.ui.getCore().byId("VBoxNewbatch");
			VboxNewbatch.destroyItems();
			var that=this;
				var oBatchInputCntl;
						if(that.getView().getModel("objectView").getProperty("/isFioriClientAvailable")){
						 	oBatchInputCntl = new sap.m.Input("oNewbatchno1",{
											
												editable:true,
												value:"",
												showValueHelp:true,
												valueHelpOnly:false,
												change:function(evt){
														that.onChangeLineItemBatchNo(evt);
												}, 
												liveChange:function(ovt)
			                                	{
			                                		that.onlivechekvalueBatchNumber(ovt);
			                                	},
												valueHelpRequest:function(ovt){
													that.onBarCodeScanInputFields(ovt,"batchNumber");
												}
											}).addEventDelegate({
													onfocusin: function(oEvt) 
													{ 
														var oComId = oEvt.srcControl.getId();
														//console.log(oComId)
														jQuery("#"+oComId).scannerDetection({
																		timeBeforeScanTest: 200, // wait for the next character for upto 200ms
																		//startChar: [120], // Prefix character for the cabled scanner (OPL6845R)
																		endChar: [13], // be sure the scan is complete if key 13 (enter) is detected
																		avgTimeByChar: 40, // it's not a barcode if a character takes longer than 40ms
																		onComplete: function(barcode, qty)
																		{
																		var oArrstings;
																	    	oArrstings = barcode.split("|");
																	    	jQuery("#"+oEvt.srcControl.getId()).find('input').val("");
																	    	jQuery("#"+oEvt.srcControl.getId()).find('input').val(oArrstings[10]);
																	    //	that.getModel("localModel").getProperty("/ProdItemsList")[0].BatchNo = oArrstings[10];
							
																		}, // main callback function
																		onError: function(string){ 
																			//console.log("Error:" + string);
																		}
														});
														
													},
													onsapfocusleave: function(oEvt) { 
														var oComId = oEvt.srcControl.getId();
														jQuery("#"+oComId).scannerDetection(false);
													}
											});
							oBatchInputCntl._getValueHelpIcon().setSrc("sap-icon://bar-code");
						 }else{
						 	oBatchInputCntl = new sap.m.Input("oNewbatchno1",{
													type:"Text",
													
													value:"",
													change:function(evt){
														that.onChangeLineItemBatchNo(evt);
													}                
												});
						 }
						 VboxNewbatch.addItem(oBatchInputCntl);
		},
		onChangespeicalstock: function (oEvent) {
			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");

			if (IndicatorMaintSNo == "X" && !MaintainedSrnoData) {
				sap.m.MessageBox.warning("Please maintain Serial No's.");
			} else {
				if (!this._DialogSSI) {
					this._DialogSSI = sap.ui.xmlfragment(
						"SIE_ASP_WM_Stock_update.SIE_ASP_WM_Stock_update.Fragment.Specialstockindicator",
						this
					);
					this.getView().addDependent(this._DialogSSI);
				}
				this._DialogSSI.open();
			}
		},
		onChangebatchnSave: function () {

			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");
			if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("B");
				this._DialogCB.close();
				this._DialogCB.destroy();
				this._DialogCB = undefined;
			} else {
				var ChngBatchNum = {
					"BatchNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ChgBatchNo": sap.ui.getCore().byId("oNewbatchno1").getValue()
				};
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					//"Stockcat": "",
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": "B",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": [],
					"ITEMTOBATCH_NAV": ChngBatchNum,
					"ITEMTOSPECIALSTOCK_NAV": {}

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.Msgtype === "S") {

							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.success(oData.Msgdesc, {

								actions: ["Change batch and Special stock", "Go Back to Main Menu"],
								title: "Change batch and Special stock",
								onClose: function (oAction) {
									that._DialogCB.close();
									that._DialogCB.destroy();
									that._DialogCB = undefined;
									if (oAction == "Change batch and Special stock") {
										that.ChangeStockcategory();

									} else {
										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.show(
								oData.Msgdesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						sap.m.MessageBox.error("Error");
						that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
						that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
					}
				});
			}

		},
		onChangebatchnClear: function () {
			sap.ui.getCore().byId("oNewbatchno1").setValue("");
		},
		onchangebatchnBack: function () {
			var that = this;
			that._DialogCB.close();
			that._DialogCB.destroy();
			that._DialogCB = undefined;
		},
		onSpecialStockindSave: function () {

			var IndicatorMaintSNo = this.getOwnerComponent().getModel("localModel").getProperty("/Indicator");
			var MaintainedSrnoData = this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData");
			if (IndicatorMaintSNo == "X" && MaintainedSrnoData) {
				this.oMaintianSerialNoBtnPost("S");
				this._DialogSSI.close();
				this._DialogSSI.destroy();
				this._DialogSSI = undefined;
			} else {
				var ChngSpecialstockdetails = {

					/*	"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
						"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
						"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
						"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
							"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
								"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),*/

					"SpecialStockInd": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),

					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),

					"SpecialStockIndChg": sap.ui.getCore().byId("oNewSpecialstockind1").getValue(),
					"SpecialStockNoChg": sap.ui.getCore().byId("oNewSpecialstocknoval").getValue()
				};
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					//	"Stockcat": "",

					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": "S",
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": [],
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": ChngSpecialstockdetails

				};
				this.oBusyDialog.open();
				var that = this;
				this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
					success: function (oData, oResponse) {
						if (oData.Msgtype === "S") {
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							that.oBusyDialog.close();
							sap.m.MessageBox.success(oData.Msgdesc, {

								actions: ["Change batch and Special stock", "Go Back to Main Menu"],
								title: "Change batch and Special stock",
								onClose: function (oAction) {
									that._DialogSSI.close();
									that._DialogSSI.destroy();
									that._DialogSSI = undefined;
									if (oAction == "Change batch and Special stock") {
										that.ChangeStockcategory();

									} else {
										that.onBack();
									}

								}

							});
						} else {
							that.oBusyDialog.close();
							that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
							sap.m.MessageBox.show(
								oData.Msgdesc, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function (oAction) {}

								}
							);
						}
					},
					error: function (oError) {
						that.oBusyDialog.close();
						sap.m.MessageBox.error("Error");
						that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", []);
						that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
					}
				});
			}

		},
		onSpecialStockindClear: function () {
			sap.ui.getCore().byId("oNewSpecialstockind1").setValue("");
			sap.ui.getCore().byId("oNewSpecialstocknoval").setValue("");
		},
		onBack1: function () {
			var that = this;
			that._DialogSSI.close();
			that._DialogSSI.destroy();
			that._DialogSSI = undefined;

		},
		//Serial number post operation
		oMaintianSerialNoBtnPost: function (Action) {
			//	var Action = this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Action");
			if (Action === "Q" || Action === "U") {
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),

					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": Action,
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData"),
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": {}

				};
			} else if (Action === "B") {
				var ChngBatchNum = {
					"BatchNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ChgBatchNo": sap.ui.getCore().byId("oNewbatchno1").getValue()
				};
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),

					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": Action,
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData"),
					"ITEMTOBATCH_NAV": ChngBatchNum,
					"ITEMTOSPECIALSTOCK_NAV": {}

				};
			} else if (Action === "S") {

				var ChngSpecialstockdetails = {
					"SpecialStockInd": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),

					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockIndChg": sap.ui.getCore().byId("oNewSpecialstockind1").getValue(),
					"SpecialStockNoChg": sap.ui.getCore().byId("oNewSpecialstocknoval").getValue()
				};
				var oPayload = {
					"MatDes": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/MatDes"),
					"Material": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Material"),
					"Msgdesc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgdesc"),
					"Msgtype": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Msgtype"),
					"Plant": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Plant"),
					"Serialno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Serialno"),
					//	"Serialno": "",
					"Sloc": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Sloc"),
					"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStock": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStock"),
					//	"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"SpecialStockNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/SpecialStockNo"),
					"StockQty": this.getView().byId("oStockQty").getText(),
					"Stockcat": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Stockcat"),
					"StockqtyUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockqtyUOM"),
					"Stockqtychg": this.getView().byId("oStockQtychange").getValue(),
					"StockchgUOM": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StockchgUOM"),
					"StorageBin": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/StorageBin"),
					"WarehouseNo": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/WarehouseNo"),
					"Action": Action,
					"Batchno": this.getOwnerComponent().getModel("localModel").getProperty("/selectedMaterialProcess/Batchno"),
					"ITEM_SERIAL_NAV": this.getOwnerComponent().getModel("localModel").getProperty("/MaintainedSrnoData"),
					"ITEMTOBATCH_NAV": {},
					"ITEMTOSPECIALSTOCK_NAV": ChngSpecialstockdetails

				};

			}
			this.oBusyDialog.open();
			var that = this;
			this.getOwnerComponent().getModel("STOCK_INFO_SRV").create("/ItemDetailSet", oPayload, {
				success: function (oData, oResponse) {
					if (oData.Msgtype === "S") {

						that.oBusyDialog.close();
						that.getOwnerComponent().getModel("localModel").setProperty("/MaintainedSrnoData", null);
						sap.m.MessageBox.show(oData.Msgdesc, {

							actions: ["Change Stock Category", "Go Back to Main Menu"],
							title: "Change Stock Category",
							onClose: function (oAction) {

								if (oAction == "Change Stock Category") {

									that.ChangeStockcategory();

								} else {
									that.onBack();
								}

							}

						});
					} else {
						that.oBusyDialog.close();
						sap.m.MessageBox.show(
							oData.Msgdesc, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Error",
								actions: [sap.m.MessageBox.Action.CLOSE],
								onClose: function (oAction) {}

							}
						);
					}
				},
				error: function (oError) {
					that.oBusyDialog.close();
					that.getOwnerComponent().getModel("localModel").setProperty("/selectedMaterialProcess", []);
				}
			});

		},
		onChangeValueSN: function (oEvent) {

			var oIndex = parseInt(oEvent.getSource().getBindingContext("oSerialNoModel").getPath().split("/")[2], 10);
			var oStrings = oEvent.getSource().getValue();
			if (oStrings !== "" && oStrings.slice(0, 3) === "]d2") {
				var objArray = parseBarcode(oStrings).parsedCodeItems;
				var obj = jQuery.grep(objArray, function (e) {
					return e.ai === "21";
				})[0];
				//sap.m.MessageToast.show(obj.data + " ---"+ obj.ai);
				if (obj && obj.data && obj.data.length > 0) {
					//sap.m.MessageToast.show("Condition Validate");
					oEvent.getSource().setValue(obj.data);

				} else {
					if (obj === undefined) {
						sap.m.MessageToast.show("AI 21 not found in barcode");
						oEvent.getSource().setValue("");
					}

					if (obj.data && obj.data.length === 0) {
						sap.m.MessageToast.show("Serial number value not found in barcode");
						oEvent.getSource().setValue("");
					}
				}
			}
		},

		onlivechekvaluefor: function (oEvent) {
			//console.log(oEvent.which);
			var that = this;
			var sFValue = "";
			sFValue = oEvent.getSource().getValue();
			var sSourceControl = oEvent.getSource();
			var oIndex = parseInt(oEvent.getSource().getBindingContext("oSerialNoModel").getPath().split("/")[2], 10);
			if (sFValue.length > 0) {
				sap.ui.getCore().byId(oEvent.getSource().getId()).onsapenter = function (e) {

				/*	if (sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1]) {
						sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1].getContent()[0].getItems()[0].focus();
					} else {
						that.onDecodeStringtoValue(sSourceControl, sFValue);
					}*/
						if (sFValue.slice(0, 3) === "]d2") /// read  GS1 data matrix.
					{
						that.onDecodeStringtoValue(sSourceControl, sFValue);

					} else { /// read QR Code..
						var oArrstings;
						oArrstings = sFValue.split("|");
						if (oArrstings.length > 1 && oArrstings[9]) {
							sSourceControl.setValue("");
							sSourceControl.setValue(oArrstings[9]);
						
						} else if (oArrstings.length === 1) {
							sSourceControl.setValue("");
							sSourceControl.setValue(oArrstings[0]);
						}

					}
					if (sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1]) {
						sap.ui.getCore().byId("oRelaseStrtTable").getItems()[oIndex + 1].getContent()[0].getItems()[0].focus();
					}
				};
			}
		},
		onDecodeStringtoValue: function (oComponent, oStrings) {
			//sap.m.MessageToast.show("onDecoder funciton");
			if (oStrings !== "" && oStrings.slice(0, 3) === "]d2") {
				var objArray = parseBarcode(oStrings).parsedCodeItems;
				var obj = jQuery.grep(objArray, function (e) {
					return e.ai === "21";
				})[0];
				if (obj && obj.data && obj.data.length > 0) {
					oComponent.setValue(obj.data);

				} else {
					if (obj === undefined) {
						sap.m.MessageToast.show("AI 21 not found in barcode");
						oComponent.setValue("");
					}

					if (obj.data && obj.data.length === 0) {
						sap.m.MessageToast.show("Serial number value not found in barcode");
						oComponent.setValue("");
					}
				}
			}
		},
		onBarCodeScanInputFields: function (oEvent, oCustomData) {
			this.destinationtype = "";
			this.destinationtype = oCustomData;
			this.desctinationCntl = oEvent.getSource();

			BarcodeScanner.scan(
				this.onSuccess.bind(this),
				this.onError.bind(this)
			);
		},
		// onSuccess Callback 
		onSuccess: function (result) {
			var bCancelled = result.cancelled;
			this.onRetrieveStingFromScannerInfo(result.text);

			if (bCancelled) {
				sap.m.MessageToast.show("Scan Cancelled");
				this.desctinationCntl.setValueHelpOnly(false); // cancel button pressed. allow user to input manually.
			}
		},
		// onError Callback
		onError: function (error) {
			sap.m.MessageToast.show(error, "Error");
		},
		onRetrieveStingFromScannerInfo: function (oStirngs) {

			var oArrstings;
			switch (this.destinationtype) {
				case  "batchNumber":

							if (oStirngs.slice(0, 1) === "\x1D") {
					var oResult = "]d2" + oStirngs.replaceAll("\x1D", "|");
					var objArray = parseBarcode(oResult).parsedCodeItems;
					var obj = jQuery.grep(objArray, function (e) {
						return e.ai === "10";
					})[0];
					if (obj && obj.data && obj.data.length > 0) {
						this.desctinationCntl.setValue(obj.data);
					} else {
						if (obj === undefined) {
							sap.m.MessageToast.show("AI 10 not found in barcode");
							this.desctinationCntl.setValue("");
						}
					}
				} else {
					oArrstings = oStirngs.split("|");
					if (oArrstings.length > 1 && oArrstings[10]) {
						this.desctinationCntl.setValue("");
						this.desctinationCntl.setValue(oArrstings[10]);
					} else if (oArrstings.length === 1) {
						this.desctinationCntl.setValue("");
						this.desctinationCntl.setValue(oArrstings[0]);
					}

				}
				 break;   	
			case "SerialNo":

				if (oStirngs.slice(0, 1) === "\x1D") {
					var oResult = "]d2" + oStirngs.replaceAll("\x1D", "|");
					var objArray = parseBarcode(oResult).parsedCodeItems;
					var obj = jQuery.grep(objArray, function (e) {
						return e.ai === "21";
					})[0];
					if (obj && obj.data && obj.data.length > 0) {
						this.desctinationCntl.setValue(obj.data);
					} else {
						if (obj === undefined) {
							sap.m.MessageToast.show("AI 21 not found in barcode");
							this.desctinationCntl.setValue("");
						}
					}
				} else {
					oArrstings = oStirngs.split("|");
					if (oArrstings.length > 1 && oArrstings[9]) {
						this.desctinationCntl.setValue("");
						this.desctinationCntl.setValue(oArrstings[9]);
					} else if (oArrstings.length === 1) {
						this.desctinationCntl.setValue("");
						this.desctinationCntl.setValue(oArrstings[0]);
					}

				}

				break;

			default:
				// code block
			}
		},
			onChangeLineItemBatchNo:function(oEvent){
				var oBatchValue = oEvent.getSource().getValue();
				/*if(oBatchValue.length <= 10){
					oEvent.getSource().setValueState("None");
				}else{
					oEvent.getSource().setValueState("Error");
					sap.m.MessageToast.show("Batch max length");
				}*/
			
		},
			onlivechekvalueBatchNumber:function(oEvent){
			var that = this;
				var sFValue = "";
					sFValue = oEvent.getSource().getValue();
				var	sSourceControl = oEvent.getSource(); 

					if(sFValue.length > 0 ) 
					{
							sap.ui.getCore().byId(oEvent.getSource().getId()).onsapenter = function(e)
							{
											if (sFValue.slice(0, 1) === "\x1D") {
					var oResult = "]d2" + sFValue.replaceAll("\x1D", "|");
					var objArray = parseBarcode(oResult).parsedCodeItems;
					var obj = jQuery.grep(objArray, function (e) {
						return e.ai === "10";
					})[0];
					if (obj && obj.data && obj.data.length > 0) {
						sSourceControl.setValue(obj.data);
					} else {
						if (obj === undefined) {
							sap.m.MessageToast.show("AI 10 not found in barcode");
							sSourceControl.setValue("");
						}
					}
				} else {
				var	oArrstings = sFValue.split("|");
					if (oArrstings.length > 1 && oArrstings[10]) {
					sSourceControl.setValue("");
						sSourceControl.setValue(oArrstings[10]);
					} else if (oArrstings.length === 1) {
						sSourceControl.setValue("");
					sSourceControl.setValue(oArrstings[0]);
					}

				}
							};
					}
		}

	});

});