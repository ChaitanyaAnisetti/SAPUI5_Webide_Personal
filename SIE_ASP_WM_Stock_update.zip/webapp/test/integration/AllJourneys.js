sap.ui.define([
	"sap/ui/test/Opa5",
	"./arrangements/Startup",
	"./NavigationJourney"
], function (Opa5, Startup) {
	"use strict";

	Opa5.extendConfig({
		arrangements: new Startup(),
		viewNamespace: "SIE_ASP_WM_Stock_update.SIE_ASP_WM_Stock_update.view.",
		autoWait: true
	});
});