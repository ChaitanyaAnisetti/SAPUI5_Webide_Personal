sap.ui.define([
	"SIE_ASP_WM_Stock_update/SIE_ASP_WM_Stock_update/test/unit/controller/Mainview.controller"
], function () {
	"use strict";
});